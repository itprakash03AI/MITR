import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box, TextField, Button, Typography, Alert, CircularProgress, Divider,
} from '@mui/material';
import {
  BoltOutlined as BoltIcon,
  CloudQueue as CloudIcon,
  QueryStats as QueryIcon,
  Dashboard as DashboardIcon,
  FileDownload as ExportIcon,
  Security as SecurityIcon,
  ArrowForward as ArrowIcon,
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

// ── Keyframe definitions ───────────────────────────────────────────────────────
const fadeInUp = {
  '@keyframes fadeInUp': {
    from: { opacity: 0, transform: 'translateY(16px)' },
    to:   { opacity: 1, transform: 'translateY(0)' },
  },
};
const floatAnim = {
  '@keyframes float': {
    '0%, 100%': { transform: 'translateY(0px)' },
    '50%':      { transform: 'translateY(-7px)' },
  },
};
const arrowAnim = {
  '@keyframes arrowSlide': {
    '0%, 100%': { transform: 'translateX(0)',   opacity: 0.3 },
    '50%':      { transform: 'translateX(5px)', opacity: 0.8 },
  },
};
const pingAnim = {
  '@keyframes ping': {
    '0%':   { transform: 'scale(1)',    opacity: 0.55 },
    '100%': { transform: 'scale(1.75)', opacity: 0 },
  },
};
const pulseGlow = {
  '@keyframes pulseGlow': {
    '0%, 100%': { filter: 'drop-shadow(0 3px 12px rgba(0,175,236,0.35))' },
    '50%':      { filter: 'drop-shadow(0 4px 22px rgba(0,175,236,0.7))' },
  },
};
const shimmerBg = {
  '@keyframes shimmerBg': {
    '0%':   { backgroundPosition: '-200% center' },
    '100%': { backgroundPosition: '200% center' },
  },
};

// ── Process flow step ──────────────────────────────────────────────────────────
interface FlowStepProps {
  icon: React.ReactNode;
  title: string;
  desc: string;
  bg: string;
  glow: string;
  glowHover: string;
  delay: number;
  floatDuration: number;
}
function FlowStep({ icon, title, desc, bg, glow, glowHover, delay, floatDuration }: FlowStepProps) {
  const [hovered, setHovered] = useState(false);
  return (
    <Box
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      sx={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1.25, flex: 1,
        animation: `fadeInUp 0.55s ease ${delay}s both`,
        ...fadeInUp,
        cursor: 'default',
      }}
    >
      <Box sx={{
        position: 'relative',
        animation: `float ${floatDuration}s ease-in-out infinite`,
        animationDelay: `${delay * 0.5}s`,
        animationPlayState: hovered ? 'paused' : 'running',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        ...floatAnim,
      }}>
        {hovered && (
          <Box sx={{
            position: 'absolute',
            width: 84, height: 84, borderRadius: '50%',
            border: `2px solid ${glowHover}`,
            animation: 'ping 0.7s ease-out forwards',
            ...pingAnim,
            pointerEvents: 'none',
          }} />
        )}
        <Box sx={{
          width: 84, height: 84, borderRadius: '50%',
          background: bg,
          boxShadow: hovered ? `0 14px 36px ${glowHover}` : `0 6px 20px ${glow}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transform: hovered ? 'scale(1.12)' : 'scale(1)',
          transition: 'transform 0.25s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.25s ease',
        }}>
          {icon}
        </Box>
      </Box>
      <Typography sx={{
        fontWeight: 700, fontSize: 14,
        color: hovered ? '#00AFEC' : '#1e293b',
        textAlign: 'center', lineHeight: 1.3, mt: 0.5,
        transition: 'color 0.2s ease',
      }}>
        {title}
      </Typography>
      <Typography sx={{ fontSize: 12, color: '#64748b', textAlign: 'center', lineHeight: 1.6, px: 0.5 }}>
        {desc}
      </Typography>
    </Box>
  );
}

const FLOW_STEPS: Omit<FlowStepProps, 'delay' | 'floatDuration'>[] = [
  {
    icon:      <CloudIcon sx={{ fontSize: 38, color: '#0090C4' }} />,
    bg:        'linear-gradient(135deg, #e0f7ff 0%, #bae6fd 100%)',
    glow:      'rgba(0,175,236,0.22)',
    glowHover: 'rgba(0,175,236,0.55)',
    title: 'Connect Sources',
    desc:  'S3, Snowflake, Databricks, Trino, Oracle & local files',
  },
  {
    icon:      <QueryIcon sx={{ fontSize: 38, color: '#059669' }} />,
    bg:        'linear-gradient(135deg, #d1fae5 0%, #6ee7b7 100%)',
    glow:      'rgba(16,185,129,0.22)',
    glowHover: 'rgba(16,185,129,0.55)',
    title: 'Build Queries',
    desc:  'Visual builder or SQL editor with autocomplete & history',
  },
  {
    icon:      <DashboardIcon sx={{ fontSize: 38, color: '#b45309' }} />,
    bg:        'linear-gradient(135deg, #fef3c7 0%, #fcd34d 100%)',
    glow:      'rgba(245,158,11,0.22)',
    glowHover: 'rgba(245,158,11,0.55)',
    title: 'Visualise Results',
    desc:  'Live charts, KPI cards & collaborative dashboards',
  },
  {
    icon:      <ExportIcon sx={{ fontSize: 38, color: '#6d28d9' }} />,
    bg:        'linear-gradient(135deg, #ede9fe 0%, #c4b5fd 100%)',
    glow:      'rgba(139,92,246,0.22)',
    glowHover: 'rgba(139,92,246,0.55)',
    title: 'Export & Automate',
    desc:  'CSV, Excel, JSON · scheduled emails · share links',
  },
];

const FLOAT_SPEEDS = [3.2, 3.8, 3.5, 4.0];

// ── Login page ─────────────────────────────────────────────────────────────────
const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error,    setError]    = useState('');
  const [loading,  setLoading]  = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    setError('');
    try {
      await login(username.trim(), password);
      navigate('/', { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: '#f8fafc' }}>

      {/* ── Barclays header ─────────────────────────────────────────────────── */}
      <Box sx={{
        px: 4, py: 1,
        bgcolor: '#00AFEC',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexShrink: 0,
      }}>
        <img
          src="/company-logo.svg"
          alt="Barclays"
          style={{ height: 34, width: 'auto', display: 'block' }}
          onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
        <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.8)', fontSize: 11, letterSpacing: 0.5 }}>
          Enterprise Data Platform
        </Typography>
      </Box>

      {/* ── Two-column body ─────────────────────────────────────────────────── */}
      <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* ── LEFT PANEL — brand + process flow ───────────────────────────── */}
        <Box sx={{
          flex: 1,
          display: { xs: 'none', md: 'flex' },
          flexDirection: 'column',
          justifyContent: 'flex-start',
          overflowY: 'auto',
          px: { md: 5, lg: 9 },
          pt: 4, pb: 5,
        }}>
          {/* Brand mark */}
          <Box sx={{ mb: 3, animation: 'fadeInUp 0.5s ease 0.05s both', ...fadeInUp, display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <BoltIcon sx={{ fontSize: 52, color: '#00AFEC', animation: 'pulseGlow 2.8s ease-in-out infinite', ...pulseGlow }} />
            <Box>
              <Typography sx={{ fontWeight: 800, fontSize: 26, color: '#1e293b', lineHeight: 1.1, letterSpacing: '-0.5px' }}>
                QueryStudio
              </Typography>
              <Typography sx={{ fontSize: 11, color: '#64748b', letterSpacing: 0.5, mt: 0.3 }}>
                Enterprise Query Engine
              </Typography>
            </Box>
          </Box>

          {/* Headline + body */}
          <Box sx={{ animation: 'fadeInUp 0.55s ease 0.12s both', ...fadeInUp, mb: 4 }}>
            <Typography variant="h4" sx={{ fontWeight: 800, color: '#0f172a', lineHeight: 1.2, mb: 1.5, letterSpacing: '-0.5px' }}>
              From data to decisions,<br />without the wait
            </Typography>
            <Typography sx={{ fontSize: 15.5, color: '#475569', lineHeight: 1.8, maxWidth: 520 }}>
              Write SQL or use the visual query builder, explore results instantly across S3,
              Snowflake, Databricks and more — then pin KPIs to live dashboards or schedule
              automated exports. Powered by DuckDB and Parquet for fast, role-based analytics.
            </Typography>
          </Box>

          {/* "How it works" section header */}
          <Box sx={{ animation: 'fadeInUp 0.5s ease 0.22s both', ...fadeInUp, mb: 2.5, mt: 4 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Box sx={{ width: 20, height: 2.5, borderRadius: 2, bgcolor: '#00AFEC' }} />
              <Typography variant="overline" sx={{ color: '#00AFEC', letterSpacing: 2.5, fontSize: 10.5, lineHeight: 1, fontWeight: 700 }}>
                How it works
              </Typography>
              <Box sx={{ flex: 1, height: 1, bgcolor: 'divider' }} />
            </Box>
          </Box>

          {/* Process flow — full width, big icons */}
          <Box sx={{ display: 'flex', alignItems: 'flex-start', width: '100%', mt: 5, mb: 5 }}>
            {FLOW_STEPS.map((step, i) => (
              <React.Fragment key={step.title}>
                <FlowStep {...step} delay={0.3 + i * 0.1} floatDuration={FLOAT_SPEEDS[i]} />
                {i < 3 && (
                  <Box sx={{
                    pt: 3, px: 0.5, color: 'text.disabled', flexShrink: 0,
                    animation: 'arrowSlide 1.6s ease-in-out infinite',
                    animationDelay: `${i * 0.35}s`,
                    ...arrowAnim,
                  }}>
                    <ArrowIcon sx={{ fontSize: 16 }} />
                  </Box>
                )}
              </React.Fragment>
            ))}
          </Box>

          <Divider sx={{ mb: 2 }} />

          {/* Tech stack shimmer footer */}
          <Box sx={{ animation: 'fadeInUp 0.5s ease 0.75s both', ...fadeInUp }}>
            <Typography variant="caption" sx={{
              fontSize: 11,
              background: 'linear-gradient(90deg, #94a3b8 0%, #00AFEC 50%, #94a3b8 100%)',
              backgroundSize: '200% auto',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              animation: 'shimmerBg 4s linear infinite',
              ...shimmerBg,
            }}>
              Active Directory SSO · Role-based access control · DuckDB · FastAPI · React · v2.0 Enterprise
            </Typography>
          </Box>
        </Box>

        {/* ── RIGHT PANEL — login form ─────────────────────────────────────── */}
        <Box sx={{
          width: { xs: '100%', md: 400 },
          bgcolor: '#ffffff',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          px: { xs: 3, md: 4.5 },
          py: 6,
          borderLeft: { md: '1px solid #e2e8f0' },
          boxShadow: { md: '-4px 0 32px rgba(0,0,0,0.06)' },
          flexShrink: 0,
        }}>
          <Box sx={{ width: '100%', maxWidth: 300 }}>

            {/* Mobile brand */}
            <Box sx={{ display: { xs: 'flex', md: 'none' }, alignItems: 'center', gap: 1, mb: 4, justifyContent: 'center' }}>
              <BoltIcon sx={{ fontSize: 34, color: '#00AFEC', animation: 'pulseGlow 2.8s ease-in-out infinite', ...pulseGlow }} />
              <Typography sx={{ fontWeight: 800, fontSize: 20, color: '#1e293b' }}>QueryStudio</Typography>
            </Box>

            <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', mb: 0.5 }}>
              Sign in
            </Typography>
            <Typography variant="body2" sx={{ color: '#64748b', mb: 3.5 }}>
              Use your Active Directory credentials
            </Typography>

            {error && (
              <Alert severity="error" sx={{ mb: 2.5, fontSize: 13 }}>{error}</Alert>
            )}

            <Box component="form" onSubmit={handleSubmit}>
              <TextField
                label="Username"
                fullWidth
                size="small"
                sx={{
                  mb: 2,
                  '& .MuiInputLabel-root': { color: '#475569' },
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#cbd5e1' },
                    '&:hover fieldset': { borderColor: '#94a3b8' },
                  },
                  '& .MuiInputBase-input': { color: '#0f172a' },
                }}
                value={username}
                onChange={e => setUsername(e.target.value)}
                autoFocus
                autoComplete="username"
                disabled={loading}
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                size="small"
                sx={{
                  mb: 2.5,
                  '& .MuiInputLabel-root': { color: '#475569' },
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: '#cbd5e1' },
                    '&:hover fieldset': { borderColor: '#94a3b8' },
                  },
                  '& .MuiInputBase-input': { color: '#0f172a' },
                }}
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="current-password"
                disabled={loading}
              />
              <Button
                type="submit"
                variant="contained"
                fullWidth
                disabled={loading || !username.trim() || !password}
                sx={{
                  height: 44, fontWeight: 600,
                  background: 'linear-gradient(135deg, #0090C4 0%, #00AFEC 100%)',
                  boxShadow: '0 4px 14px rgba(0,175,236,0.35)',
                  transition: 'box-shadow 0.2s ease, transform 0.15s ease',
                  '&:hover:not(:disabled)': {
                    background: 'linear-gradient(135deg, #007aaa 0%, #0099d4 100%)',
                    boxShadow: '0 6px 20px rgba(0,175,236,0.5)',
                    transform: 'translateY(-1px)',
                  },
                  '&:active:not(:disabled)': { transform: 'translateY(0px)' },
                }}
              >
                {loading ? <CircularProgress size={20} color="inherit" /> : 'Sign In'}
              </Button>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mt: 2.5, justifyContent: 'center' }}>
              <SecurityIcon sx={{ fontSize: 13, color: '#94a3b8' }} />
              <Typography variant="caption" sx={{ color: '#94a3b8' }}>
                Secured via Active Directory
              </Typography>
            </Box>

            <Divider sx={{ my: 3 }} />

            <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', color: '#94a3b8', fontSize: 11 }}>
              Powered by <strong style={{ fontWeight: 600, color: '#64748b' }}>QueryStudio</strong>
            </Typography>
          </Box>
        </Box>

      </Box>
    </Box>
  );
};

export default LoginPage;
