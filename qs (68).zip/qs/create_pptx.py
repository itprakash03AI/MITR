"""
Generate a polished management demo presentation for Query Studio.
Run:  cd c:/DEV/outputs/backend && source venv/Scripts/activate && python ../create_pptx.py
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ── Colour palette ───────────────────────────────────────────────────────────
NAVY      = RGBColor(0x0F, 0x17, 0x2A)   # dark bg
DARK_BLUE = RGBColor(0x1E, 0x29, 0x3B)
BLUE      = RGBColor(0x38, 0x82, 0xF6)   # accent
LIGHT_BLUE= RGBColor(0x60, 0xA5, 0xFA)
CYAN      = RGBColor(0x22, 0xD3, 0xEE)
GREEN     = RGBColor(0x34, 0xD3, 0x99)
ORANGE    = RGBColor(0xFB, 0x92, 0x3C)
WHITE     = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY= RGBColor(0xCB, 0xD5, 0xE1)
MID_GRAY  = RGBColor(0x94, 0xA3, 0xB8)
CARD_BG   = RGBColor(0x1E, 0x29, 0x3B)
RED       = RGBColor(0xEF, 0x44, 0x44)

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)

# ── Helpers ──────────────────────────────────────────────────────────────────

def _solid_bg(slide, color):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def _add_shape(slide, left, top, width, height, fill_color, border_color=None, radius=None):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
        left, top, width, height
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(1)
    else:
        shape.line.fill.background()
    return shape

def _text_box(slide, left, top, width, height, text, font_size=14,
              color=WHITE, bold=False, alignment=PP_ALIGN.LEFT, font_name="Segoe UI"):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = alignment
    return txBox

def _bullet_slide_items(tf, items, font_size=16, color=WHITE, spacing=Pt(8),
                         font_name="Segoe UI", bold_prefix=True):
    """Add bullet items. Each item can be 'Bold Part | rest' or plain text."""
    for i, item in enumerate(items):
        p = tf.add_paragraph() if i > 0 or tf.paragraphs[0].text else tf.paragraphs[0]
        p.space_after = spacing
        p.level = 0
        if "|" in item and bold_prefix:
            bold_part, rest = item.split("|", 1)
            run1 = p.add_run()
            run1.text = bold_part.strip()
            run1.font.size = Pt(font_size)
            run1.font.color.rgb = CYAN
            run1.font.bold = True
            run1.font.name = font_name
            run2 = p.add_run()
            run2.text = " " + rest.strip()
            run2.font.size = Pt(font_size)
            run2.font.color.rgb = color
            run2.font.name = font_name
        else:
            run = p.add_run()
            run.text = item
            run.font.size = Pt(font_size)
            run.font.color.rgb = color
            run.font.name = font_name

def _section_header(slide, text, top=Inches(0.4)):
    """Small section label at the top."""
    _text_box(slide, Inches(0.8), top, Inches(5), Inches(0.4),
              text, font_size=11, color=BLUE, bold=True)

def _icon_card(slide, left, top, width, height, icon_text, title, desc,
               accent=BLUE):
    """Card with emoji icon, title, and description."""
    card = _add_shape(slide, left, top, width, height, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Icon circle
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
        left + Inches(0.3), top + Inches(0.35), Inches(0.55), Inches(0.55))
    circle.fill.solid()
    circle.fill.fore_color.rgb = accent
    circle.line.fill.background()
    # Icon text
    _text_box(slide, left + Inches(0.3), top + Inches(0.38), Inches(0.55), Inches(0.55),
              icon_text, font_size=18, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    # Title
    _text_box(slide, left + Inches(1.05), top + Inches(0.25), width - Inches(1.3), Inches(0.4),
              title, font_size=15, color=WHITE, bold=True)
    # Desc
    _text_box(slide, left + Inches(1.05), top + Inches(0.62), width - Inches(1.3), height - Inches(0.8),
              desc, font_size=11, color=LIGHT_GRAY)

def _metric_card(slide, left, top, number, label, accent=BLUE):
    w, h = Inches(2.5), Inches(1.6)
    card = _add_shape(slide, left, top, w, h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Accent top bar
    bar = _add_shape(slide, left, top, w, Inches(0.05), accent)
    _text_box(slide, left, top + Inches(0.3), w, Inches(0.7),
              number, font_size=36, color=accent, bold=True, alignment=PP_ALIGN.CENTER)
    _text_box(slide, left, top + Inches(1.0), w, Inches(0.45),
              label, font_size=12, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 1 — Title
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
_solid_bg(slide, NAVY)

# Accent line
_add_shape(slide, Inches(0.8), Inches(2.3), Inches(0.8), Inches(0.06), BLUE)

_text_box(slide, Inches(0.8), Inches(2.5), Inches(10), Inches(1.2),
          "Query Studio", font_size=52, color=WHITE, bold=True)
_text_box(slide, Inches(0.8), Inches(3.6), Inches(10), Inches(0.8),
          "Enterprise Self-Service Analytics Platform", font_size=24, color=LIGHT_BLUE)
_text_box(slide, Inches(0.8), Inches(4.5), Inches(10), Inches(0.6),
          "Query any data source. Export any format. Schedule & automate.",
          font_size=16, color=MID_GRAY)

# Version / date badge
badge = _add_shape(slide, Inches(0.8), Inches(5.5), Inches(2.4), Inches(0.45), DARK_BLUE, border_color=RGBColor(0x33, 0x3E, 0x55))
_text_box(slide, Inches(0.8), Inches(5.53), Inches(2.4), Inches(0.4),
          "v1.0  |  March 2026", font_size=12, color=MID_GRAY, alignment=PP_ALIGN.CENTER)

# Decorative right-side gradient block
_add_shape(slide, Inches(10.5), Inches(0), Inches(2.833), Inches(7.5), BLUE)
_text_box(slide, Inches(10.5), Inches(3.2), Inches(2.833), Inches(1),
          "QS", font_size=72, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 2 — The Problem: Existing Tools Fall Short
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "THE CHALLENGE")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Why Existing Tools Fall Short", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(11), Inches(0.45),
          "Starburst, Snowflake, and Databricks are powerful engines — but they weren't designed for self-service analytics.",
          font_size=15, color=LIGHT_GRAY)

# Tool comparison — each tool and its limitations
tool_problems = [
    ("Starburst / Trino", "$$$", [
        "Expensive per-query compute pricing",
        "No built-in export to CSV / Excel / Parquet",
        "Cannot join data across Starburst + Snowflake",
        "No visual query builder for business users",
        "No scheduling or automated report delivery",
    ], RED),
    ("Snowflake", "$$$", [
        "Pay-per-second warehouse costs add up fast",
        "Locked inside Snowflake — can't join with S3 Iceberg",
        "Export requires SQL + external tooling (Python, dbt)",
        "No native scheduling with email delivery",
        "Business users need SQL training to use it",
    ], ORANGE),
    ("Databricks", "$$$", [
        "Notebook-centric — not designed for ad-hoc queries",
        "Cannot join Databricks tables with Snowflake tables",
        "No simple export button for business users",
        "Requires engineering to set up jobs & workflows",
        "Expensive DBU costs for simple reporting queries",
    ], ORANGE),
]

tool_w = Inches(3.7)
tool_h = Inches(3.4)
tool_y = Inches(2.4)

for idx, (tool_name, cost, problems, accent) in enumerate(tool_problems):
    x = Inches(0.8) + (tool_w + Inches(0.4)) * idx
    card = _add_shape(slide, x, tool_y, tool_w, tool_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Red accent top bar
    _add_shape(slide, x, tool_y, tool_w, Inches(0.05), accent)
    # Tool name
    _text_box(slide, x + Inches(0.25), tool_y + Inches(0.18), tool_w - Inches(1.2), Inches(0.35),
              tool_name, font_size=17, color=WHITE, bold=True)
    # Cost badge
    cost_badge = _add_shape(slide, x + tool_w - Inches(0.85), tool_y + Inches(0.15),
                             Inches(0.65), Inches(0.32), RED)
    _text_box(slide, x + tool_w - Inches(0.85), tool_y + Inches(0.16),
              Inches(0.65), Inches(0.32),
              cost, font_size=11, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    # Problem list
    for i, problem in enumerate(problems):
        bullet_y = tool_y + Inches(0.7) + Inches(i * 0.48)
        # X mark
        _text_box(slide, x + Inches(0.2), bullet_y, Inches(0.3), Inches(0.3),
                  "X", font_size=12, color=RED, bold=True)
        _text_box(slide, x + Inches(0.5), bullet_y, tool_w - Inches(0.7), Inches(0.4),
                  problem, font_size=11, color=LIGHT_GRAY)

# Bottom — the gap
frustration_y = Inches(6.1)
frust_box = _add_shape(slide, Inches(0.8), frustration_y, Inches(11.5), Inches(0.7),
                         DARK_BLUE, border_color=BLUE)
_text_box(slide, Inches(0.8), frustration_y + Inches(0.05), Inches(11.5), Inches(0.6),
          "These are great data engines — but there's no unified layer for analysts to query across them,\n"
          "export results in one click, or schedule automated reports. That's the gap Query Studio fills.",
          font_size=13, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 2b — What Analysts Actually Need
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "THE GAP")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "What Analysts Actually Need", font_size=36, color=WHITE, bold=True)

# Left side — requirements
needs_x = Inches(0.8)
needs_w = Inches(5.5)
needs_y = Inches(2.0)
needs_box = _add_shape(slide, needs_x, needs_y, needs_w, Inches(4.5), CARD_BG, border_color=CYAN)
_text_box(slide, needs_x, needs_y + Inches(0.15), needs_w, Inches(0.35),
          "DAILY ANALYST REQUIREMENTS", font_size=12, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)

analyst_needs = [
    ("Query across sources", "Join fact table in S3 Iceberg with dimension\ntable in Snowflake — in one query."),
    ("No SQL required", "Point-and-click: select columns, add filters,\npick partitions — generate SQL automatically."),
    ("One-click export", "Download results as CSV, Excel, JSON, or\nParquet. No Python scripts, no command line."),
    ("Scheduled reports", "Set up a cron job: run every Monday 8 AM,\nemail results to the team automatically."),
    ("Fast iteration", "Change a filter, re-run, see results in seconds.\nNot wait 5 minutes for Starburst to spin up."),
]

for i, (title, desc) in enumerate(analyst_needs):
    item_y = needs_y + Inches(0.6) + Inches(i * 0.75)
    # Checkmark
    check = _add_shape(slide, needs_x + Inches(0.2), item_y + Inches(0.02),
                        Inches(0.3), Inches(0.28), GREEN)
    _text_box(slide, needs_x + Inches(0.2), item_y + Inches(0.0),
              Inches(0.3), Inches(0.28),
              "OK", font_size=9, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    _text_box(slide, needs_x + Inches(0.65), item_y - Inches(0.03), needs_w - Inches(1), Inches(0.28),
              title, font_size=14, color=WHITE, bold=True)
    _text_box(slide, needs_x + Inches(0.65), item_y + Inches(0.25), needs_w - Inches(1), Inches(0.48),
              desc, font_size=10, color=LIGHT_GRAY)

# Right side — comparison table header
comp_x = Inches(6.8)
comp_w = Inches(5.7)
comp_y = Inches(2.0)

# Comparison table
comp_box = _add_shape(slide, comp_x, comp_y, comp_w, Inches(4.5), CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
_text_box(slide, comp_x, comp_y + Inches(0.15), comp_w, Inches(0.35),
          "CAN EXISTING TOOLS DO THIS?", font_size=12, color=ORANGE, bold=True, alignment=PP_ALIGN.CENTER)

# Table header
hdr_y = comp_y + Inches(0.55)
_add_shape(slide, comp_x + Inches(0.1), hdr_y, comp_w - Inches(0.2), Inches(0.35), DARK_BLUE)
col_positions = [comp_x + Inches(0.2), comp_x + Inches(2.1), comp_x + Inches(3.2),
                 comp_x + Inches(4.2)]
headers = ["Capability", "Starburst", "Snowflake", "Query Studio"]
header_colors = [LIGHT_GRAY, LIGHT_GRAY, LIGHT_GRAY, CYAN]
for i, (hdr, hdr_c) in enumerate(zip(headers, header_colors)):
    _text_box(slide, col_positions[i], hdr_y + Inches(0.03),
              Inches(1.2) if i == 0 else Inches(0.9), Inches(0.3),
              hdr, font_size=10, color=hdr_c, bold=True)

# Table rows
comparison_rows = [
    ("Cross-source joins",     "X", "X", "YES"),
    ("Visual query builder",   "X", "X", "YES"),
    ("One-click CSV/Excel",    "X", "X", "YES"),
    ("Parquet export",         "X", "X", "YES"),
    ("Cron scheduling",        "X", "X", "YES"),
    ("Email report delivery",  "X", "X", "YES"),
    ("Partition pruning (S3)", "~",  "X", "YES"),
    ("No per-query cost",      "X", "X", "YES"),
]

for r_idx, (cap, star, snow, qs) in enumerate(comparison_rows):
    row_y = hdr_y + Inches(0.45) + Inches(r_idx * 0.42)
    if r_idx % 2 == 0:
        _add_shape(slide, comp_x + Inches(0.1), row_y, comp_w - Inches(0.2), Inches(0.38),
                   RGBColor(0x16, 0x20, 0x30))
    _text_box(slide, col_positions[0], row_y + Inches(0.05), Inches(1.8), Inches(0.3),
              cap, font_size=10, color=WHITE)
    for c_idx, val in enumerate([star, snow, qs]):
        cx = col_positions[1 + c_idx]
        val_color = RED if val == "X" else (GREEN if val == "YES" else ORANGE)
        _text_box(slide, cx, row_y + Inches(0.05), Inches(0.9), Inches(0.3),
                  val, font_size=11, color=val_color, bold=True, alignment=PP_ALIGN.CENTER)

# Bottom callout
_text_box(slide, Inches(0.8), Inches(6.8), Inches(11.5), Inches(0.4),
          "Query Studio fills the gap — one unified tool that works across every data source, with zero per-query cost.",
          font_size=14, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 3 — Solution Overview
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "THE SOLUTION")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "One Platform, Every Data Source", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(10), Inches(0.5),
          "Query Studio connects to your entire data ecosystem through a single, browser-based interface.",
          font_size=15, color=LIGHT_GRAY)

# Architecture flow — simplified boxes
flow_y = Inches(2.8)
box_h = Inches(3.2)

# Left: Data Sources
src_box = _add_shape(slide, Inches(0.5), flow_y, Inches(2.5), box_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
_text_box(slide, Inches(0.5), flow_y + Inches(0.15), Inches(2.5), Inches(0.35),
          "DATA SOURCES", font_size=11, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)

sources = ["Amazon S3 / Iceberg", "Snowflake", "Databricks", "Trino / Presto", "Oracle DB", "Local Files"]
for i, src in enumerate(sources):
    pill = _add_shape(slide, Inches(0.7), flow_y + Inches(0.6) + Inches(i * 0.4),
                      Inches(2.1), Inches(0.32), DARK_BLUE, border_color=RGBColor(0x33, 0x3E, 0x55))
    _text_box(slide, Inches(0.7), flow_y + Inches(0.61) + Inches(i * 0.4),
              Inches(2.1), Inches(0.32), src, font_size=11, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)

# Arrow
_text_box(slide, Inches(3.1), Inches(3.8), Inches(0.8), Inches(0.5),
          ">>>", font_size=24, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)

# Center: Query Studio
qs_box = _add_shape(slide, Inches(3.9), flow_y, Inches(4.5), box_h, DARK_BLUE, border_color=BLUE)
_text_box(slide, Inches(3.9), flow_y + Inches(0.15), Inches(4.5), Inches(0.4),
          "QUERY STUDIO", font_size=14, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)

qs_features = [
    "Visual Query Builder — drag & drop",
    "Raw SQL Editor with IntelliSense",
    "Iceberg Partition Pruning",
    "Table Joins & Aggregations",
    "Real-time Preview (first 500 rows)",
    "Cron Scheduler + Email Delivery",
    "Download Center (CSV, XLSX, JSON, Parquet)",
]
for i, feat in enumerate(qs_features):
    _text_box(slide, Inches(4.2), flow_y + Inches(0.65) + Inches(i * 0.35),
              Inches(4), Inches(0.32),
              feat, font_size=12, color=WHITE if i % 2 == 0 else LIGHT_GRAY)

# Arrow
_text_box(slide, Inches(8.5), Inches(3.8), Inches(0.8), Inches(0.5),
          ">>>", font_size=24, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)

# Right: Output
out_box = _add_shape(slide, Inches(9.3), flow_y, Inches(3.5), box_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
_text_box(slide, Inches(9.3), flow_y + Inches(0.15), Inches(3.5), Inches(0.35),
          "OUTPUTS", font_size=11, color=GREEN, bold=True, alignment=PP_ALIGN.CENTER)

outputs = [
    ("Interactive Grid", "Sort, filter, paginate"),
    ("CSV / Excel Export", "One-click download"),
    ("Parquet Files", "Columnar, compressed"),
    ("Scheduled Reports", "Cron + email delivery"),
    ("Dashboard Charts", "Bar, line, pie, area"),
    ("REST API", "Programmatic access"),
]
for i, (title, desc) in enumerate(outputs):
    _text_box(slide, Inches(9.5), flow_y + Inches(0.6) + Inches(i * 0.4),
              Inches(3.1), Inches(0.2), title, font_size=12, color=WHITE, bold=True)
    _text_box(slide, Inches(9.5), flow_y + Inches(0.8) + Inches(i * 0.4),
              Inches(3.1), Inches(0.2), desc, font_size=9, color=MID_GRAY)

# Bottom tagline
_text_box(slide, Inches(0.8), Inches(6.4), Inches(11), Inches(0.5),
          "Zero infrastructure changes required — deploys on OpenShift alongside existing services.",
          font_size=13, color=MID_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 4 — Key Features (detailed)
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "KEY FEATURES")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Built for Enterprise", font_size=36, color=WHITE, bold=True)

features = [
    ("DB",  "Multi-Source Connectivity",
     "S3, Snowflake, Databricks, Trino, Oracle — one unified interface.\nIceberg table support with automatic partition pruning.", BLUE),
    ("QB",  "Visual Query Builder",
     "Point-and-click query construction. Select columns, add filters,\njoins, aggregations — no SQL knowledge required.", CYAN),
    ("SQL", "Raw SQL Editor",
     "Full SQL editor with syntax highlighting for power users.\nCross-source queries with parameterized filters.", GREEN),
    ("DL",  "Export & Download Center",
     "Export to CSV, Excel, JSON, or Parquet. Track all downloads\nwith expiry management and storage quotas.", ORANGE),
    ("CK",  "Scheduler & Automation",
     "Cron and interval scheduling with APScheduler.\nAutomatic email delivery of reports to stakeholders.", LIGHT_BLUE),
    ("AD",  "Authentication & Governance",
     "Active Directory integration. Query versioning with\nfull audit trail. Role-based access control.", RED),
]

col_w = Inches(3.7)
card_h = Inches(1.55)
x_starts = [Inches(0.8), Inches(4.7), Inches(8.6)]
y_starts = [Inches(2.0), Inches(3.8)]

for idx, (icon, title, desc, accent) in enumerate(features):
    col = idx % 3
    row = idx // 3
    x, y = x_starts[col], y_starts[row]
    card = _add_shape(slide, x, y, col_w, card_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Icon badge
    ibadge = _add_shape(slide, x + Inches(0.2), y + Inches(0.2), Inches(0.5), Inches(0.42), accent)
    _text_box(slide, x + Inches(0.2), y + Inches(0.22), Inches(0.5), Inches(0.42),
              icon, font_size=11, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    _text_box(slide, x + Inches(0.85), y + Inches(0.18), col_w - Inches(1.1), Inches(0.35),
              title, font_size=14, color=WHITE, bold=True)
    _text_box(slide, x + Inches(0.85), y + Inches(0.55), col_w - Inches(1.1), card_h - Inches(0.65),
              desc, font_size=11, color=LIGHT_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 5a — How It Works (User Workflow)
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "HOW IT WORKS")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "From Data to Insight in 4 Steps", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(10), Inches(0.45),
          "No engineering help needed. Any analyst can go from raw data to scheduled report in minutes.",
          font_size=15, color=LIGHT_GRAY)

# 4 workflow steps — large horizontal cards with arrows
workflow_steps = [
    ("1", "CONNECT", "Pick a data source",
     "Choose from S3 Iceberg, Snowflake,\nDatabricks, Trino, or Oracle.\nConnections are pre-configured by admin\n— analysts just pick from a dropdown.",
     BLUE),
    ("2", "BUILD", "Create your query",
     "Visual builder: select tables, pick columns,\nadd filters, set partition values.\nOr write raw SQL if you prefer.\nNo coding skills required.",
     CYAN),
    ("3", "EXECUTE", "See results instantly",
     "First 500 rows appear in ~2 seconds.\nFull dataset loads in background.\nSort, filter, paginate interactively.\nPreview before downloading.",
     GREEN),
    ("4", "DELIVER", "Export or schedule",
     "One-click download: CSV, Excel, Parquet.\nOr schedule it: daily, weekly, monthly.\nAutomatic email delivery to your team.\nDownload Center tracks all exports.",
     ORANGE),
]

step_w = Inches(2.7)
step_h = Inches(3.6)
step_y = Inches(2.5)

for idx, (num, label, subtitle, desc, accent) in enumerate(workflow_steps):
    x = Inches(0.5) + (step_w + Inches(0.55)) * idx
    card = _add_shape(slide, x, step_y, step_w, step_h, CARD_BG, border_color=accent)

    # Number circle at top
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
        x + Inches(0.95), step_y + Inches(0.2), Inches(0.6), Inches(0.6))
    circle.fill.solid()
    circle.fill.fore_color.rgb = accent
    circle.line.fill.background()
    _text_box(slide, x + Inches(0.95), step_y + Inches(0.23), Inches(0.6), Inches(0.6),
              num, font_size=22, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Label
    _text_box(slide, x, step_y + Inches(0.9), step_w, Inches(0.35),
              label, font_size=15, color=accent, bold=True, alignment=PP_ALIGN.CENTER)

    # Subtitle
    _text_box(slide, x, step_y + Inches(1.2), step_w, Inches(0.3),
              subtitle, font_size=11, color=WHITE, alignment=PP_ALIGN.CENTER)

    # Description
    _text_box(slide, x + Inches(0.2), step_y + Inches(1.6), step_w - Inches(0.4), Inches(1.8),
              desc, font_size=11, color=LIGHT_GRAY)

    # Arrow between steps
    if idx < 3:
        arrow_x = x + step_w + Inches(0.1)
        _text_box(slide, arrow_x, Inches(3.9), Inches(0.4), Inches(0.5),
                  ">>", font_size=16, color=MID_GRAY, bold=True, alignment=PP_ALIGN.CENTER)

# Bottom callout
_text_box(slide, Inches(0.8), Inches(6.4), Inches(11.5), Inches(0.4),
          "Average time from login to first results: under 60 seconds.",
          font_size=14, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 5b — Feature Highlights (Query Builder + Iceberg + Scheduling)
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "FEATURE HIGHLIGHTS")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Features That Make the Difference", font_size=36, color=WHITE, bold=True)

# Three tall feature cards
feat_details = [
    ("Visual Query Builder", BLUE, [
        ("Tables & Columns", "Browse registered tables, expand to see\nall columns with data types. Click to select."),
        ("Filters & Joins", "Add WHERE filters with dropdown operators.\nJoin multiple tables on matching columns."),
        ("Aggregations", "GROUP BY, SUM, COUNT, AVG — all via\ndropdowns. No SQL syntax to remember."),
        ("Generated SQL", "See the auto-generated SQL in real-time.\nPower users can switch to raw SQL mode."),
    ]),
    ("Iceberg & Partition Intelligence", CYAN, [
        ("Partition Pruning", "Select only the partitions you need.\nQuery reads 100 files instead of 10,000."),
        ("Auto Latest Partition", "No filter selected? Query Studio picks\nthe latest partition automatically."),
        ("Cached Metadata", "Partition info cached in DB (5-hour TTL).\nBackground refresh every 5 hours."),
        ("Manifest Scanning", "Reads Iceberg manifests to resolve\nactive data files — no full table scan."),
    ]),
    ("Scheduling & Delivery", GREEN, [
        ("Cron Schedules", "Standard cron expressions: every Monday\n8 AM, first of month, every 6 hours."),
        ("Email Delivery", "Results emailed as attachments to any\nnumber of recipients automatically."),
        ("Download Center", "All exports tracked with expiry dates.\nCSV, Excel, JSON, Parquet formats."),
        ("Execution History", "Full log of every query run — timing,\nrow counts, status, output files."),
    ]),
]

feat_w = Inches(3.7)
feat_h = Inches(4.3)
feat_y = Inches(2.0)

for idx, (title, accent, sub_features) in enumerate(feat_details):
    x = Inches(0.8) + (feat_w + Inches(0.4)) * idx
    card = _add_shape(slide, x, feat_y, feat_w, feat_h, CARD_BG, border_color=accent)
    # Title bar
    _add_shape(slide, x, feat_y, feat_w, Inches(0.5), accent)
    _text_box(slide, x + Inches(0.2), feat_y + Inches(0.08), feat_w - Inches(0.4), Inches(0.4),
              title, font_size=14, color=WHITE, bold=True)

    for i, (sub_title, sub_desc) in enumerate(sub_features):
        sy = feat_y + Inches(0.7) + Inches(i * 0.88)
        _text_box(slide, x + Inches(0.2), sy, feat_w - Inches(0.4), Inches(0.28),
                  sub_title, font_size=12, color=WHITE, bold=True)
        _text_box(slide, x + Inches(0.2), sy + Inches(0.28), feat_w - Inches(0.4), Inches(0.55),
                  sub_desc, font_size=10, color=LIGHT_GRAY)

# Bottom
_text_box(slide, Inches(0.8), Inches(6.6), Inches(11.5), Inches(0.4),
          "Every feature designed to reduce time-to-insight and eliminate manual work.",
          font_size=13, color=MID_GRAY, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE — Technical Architecture
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "ARCHITECTURE")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Production-Ready Architecture", font_size=36, color=WHITE, bold=True)

# Three tier boxes
tier_w = Inches(3.6)
tier_h = Inches(4.0)
tier_gap = Inches(0.4)
tier_y = Inches(2.2)

# Frontend tier
t1 = _add_shape(slide, Inches(0.8), tier_y, tier_w, tier_h, CARD_BG, border_color=CYAN)
_text_box(slide, Inches(0.8), tier_y + Inches(0.15), tier_w, Inches(0.35),
          "FRONTEND", font_size=13, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)
fe_items = [
    "React 18 + TypeScript",
    "Material UI v7 (MUI)",
    "Vite build system",
    "WebSocket real-time updates",
    "Responsive (laptop to 32\")",
    "Interactive data grid",
    "Dashboard with charts",
    "Download center",
]
for i, item in enumerate(fe_items):
    _text_box(slide, Inches(1.1), tier_y + Inches(0.6) + Inches(i * 0.38),
              tier_w - Inches(0.6), Inches(0.35),
              item, font_size=12, color=LIGHT_GRAY if i % 2 else WHITE)

# Backend tier
t2_x = Inches(0.8) + tier_w + tier_gap
t2 = _add_shape(slide, t2_x, tier_y, tier_w, tier_h, CARD_BG, border_color=BLUE)
_text_box(slide, t2_x, tier_y + Inches(0.15), tier_w, Inches(0.35),
          "BACKEND", font_size=13, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)
be_items = [
    "Python FastAPI (async)",
    "DuckDB query engine",
    "SQLite metadata store",
    "APScheduler (cron jobs)",
    "Crash-isolated subprocess",
    "SMTP email service",
    "Prometheus metrics",
    "JSON structured logging",
]
for i, item in enumerate(be_items):
    _text_box(slide, t2_x + Inches(0.3), tier_y + Inches(0.6) + Inches(i * 0.38),
              tier_w - Inches(0.6), Inches(0.35),
              item, font_size=12, color=LIGHT_GRAY if i % 2 else WHITE)

# Infrastructure tier
t3_x = t2_x + tier_w + tier_gap
t3 = _add_shape(slide, t3_x, tier_y, tier_w, tier_h, CARD_BG, border_color=GREEN)
_text_box(slide, t3_x, tier_y + Inches(0.15), tier_w, Inches(0.35),
          "INFRASTRUCTURE", font_size=13, color=GREEN, bold=True, alignment=PP_ALIGN.CENTER)
infra_items = [
    "OpenShift / Kubernetes",
    "Multi-stage Docker build",
    "Non-root container",
    "Health check endpoints",
    "nginx TLS termination",
    "Rate limiting & CORS",
    "Configurable via env vars",
    "Zero external dependencies",
]
for i, item in enumerate(infra_items):
    _text_box(slide, t3_x + Inches(0.3), tier_y + Inches(0.6) + Inches(i * 0.38),
              tier_w - Inches(0.6), Inches(0.35),
              item, font_size=12, color=LIGHT_GRAY if i % 2 else WHITE)

# Bottom note
_text_box(slide, Inches(0.8), Inches(6.5), Inches(11), Inches(0.5),
          "Single pod deployment for 10-15 users  |  Multi-pod worker architecture ready for Phase 2 scaling",
          font_size=13, color=MID_GRAY, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 6 — Data Source Deep Dive
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "CONNECTORS")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Enterprise Data Source Connectors", font_size=36, color=WHITE, bold=True)

connectors = [
    ("S3 / Iceberg", "Read Parquet, CSV, Iceberg tables from any S3-compatible store.\nAutomatic partition pruning. DuckDB httpfs for high-throughput reads.", BLUE,
     ["Parquet & CSV auto-detect", "Iceberg manifest scanning", "Partition filter push-down", "Cached partition metadata"]),
    ("Snowflake", "Native Snowflake connector with warehouse auto-suspend awareness.\nLarge result set streaming to local Parquet.", CYAN,
     ["OAuth & key-pair auth", "Warehouse selection", "Schema browser", "Result caching"]),
    ("Databricks", "Connect to Databricks SQL warehouses.\nUnity Catalog and Hive metastore support.", ORANGE,
     ["Token authentication", "Catalog.schema.table browse", "SQL warehouse routing", "Large result streaming"]),
    ("Trino / Oracle", "Enterprise Trino clusters and Oracle databases.\nCross-source query federation.", GREEN,
     ["Kerberos & LDAP auth", "Catalog exploration", "Oracle TNS support", "Connection pooling"]),
]

card_w = Inches(5.8)
card_h = Inches(2.1)
positions = [
    (Inches(0.5), Inches(2.0)),   (Inches(6.8), Inches(2.0)),
    (Inches(0.5), Inches(4.4)),   (Inches(6.8), Inches(4.4)),
]

for idx, (title, desc, accent, bullets) in enumerate(connectors):
    x, y = positions[idx]
    card = _add_shape(slide, x, y, card_w, card_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Accent left bar
    _add_shape(slide, x, y, Inches(0.06), card_h, accent)
    _text_box(slide, x + Inches(0.25), y + Inches(0.12), card_w - Inches(0.4), Inches(0.35),
              title, font_size=16, color=accent, bold=True)
    _text_box(slide, x + Inches(0.25), y + Inches(0.48), card_w - Inches(0.4), Inches(0.5),
              desc, font_size=10, color=LIGHT_GRAY)
    # Bullet features
    for i, b in enumerate(bullets):
        col_x = x + Inches(0.25) + (Inches(2.8) if i >= 2 else 0)
        row_y = y + Inches(1.3) + (Inches(0.28) * (i % 2))
        _text_box(slide, col_x, row_y, Inches(2.7), Inches(0.25),
                  f"  {b}", font_size=10, color=WHITE)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 7 — Performance & Caching
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "PERFORMANCE")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Optimized for Speed", font_size=36, color=WHITE, bold=True)

# Metrics row
_metric_card(slide, Inches(0.8),  Inches(2.0), "<2s",   "Preview (first 500 rows)", CYAN)
_metric_card(slide, Inches(3.6),  Inches(2.0), "5-min",  "L1 In-Memory Cache", BLUE)
_metric_card(slide, Inches(6.4),  Inches(2.0), "5-hour", "L2 SQLite Persistent Cache", GREEN)
_metric_card(slide, Inches(9.2),  Inches(2.0), "5-hour", "Background Auto-Refresh", ORANGE)

# Caching architecture
cache_y = Inches(4.0)
cache_box = _add_shape(slide, Inches(0.8), cache_y, Inches(11.5), Inches(2.8), CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))

_text_box(slide, Inches(1.1), cache_y + Inches(0.15), Inches(5), Inches(0.35),
          "Multi-Layer Caching Strategy", font_size=16, color=WHITE, bold=True)

cache_items = [
    ("L1 In-Memory", "Partition values + Iceberg file lists. 5-min TTL.\nInstant response for repeated requests.", CYAN),
    ("L2 SQLite", "Persistent DB cache. 5-hour TTL.\nSurvives server restarts — no cold-start penalty.", BLUE),
    ("Background Refresh", "APScheduler scans ALL Iceberg tables every 5 hours.\nPre-loads partition metadata before TTL expires.", GREEN),
    ("On-Demand Refresh", "Admin or user can trigger immediate refresh.\nPer-table or bulk refresh for entire connection.", ORANGE),
]

for i, (title, desc, accent) in enumerate(cache_items):
    cx = Inches(1.1) + (Inches(2.85) * i)
    # Accent dot
    _add_shape(slide, cx, cache_y + Inches(0.7), Inches(0.12), Inches(0.12), accent)
    _text_box(slide, cx + Inches(0.2), cache_y + Inches(0.62), Inches(2.5), Inches(0.3),
              title, font_size=13, color=accent, bold=True)
    _text_box(slide, cx + Inches(0.2), cache_y + Inches(0.95), Inches(2.5), Inches(0.8),
              desc, font_size=10, color=LIGHT_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 8 — Security & Governance
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "SECURITY & GOVERNANCE")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Enterprise-Grade Security", font_size=36, color=WHITE, bold=True)

sec_features = [
    ("Active Directory Auth", "LDAP/AD integration for user authentication.\nSession management with configurable TTL.\nSeamless SSO for corporate users.", BLUE),
    ("Credential Encryption", "All connection credentials encrypted at rest\nusing Fernet symmetric encryption.\nAPI never exposes raw credentials.", CYAN),
    ("Query Versioning", "Full version history for every saved query.\nChange tracking with author and timestamp.\nOne-click rollback to any version.", GREEN),
    ("Audit Trail", "Structured JSON logging of all operations.\nQuery execution history with timing metrics.\nPrometheus metrics for monitoring.", ORANGE),
    ("Rate Limiting", "Configurable rate limits per endpoint.\n50 concurrent queries global limit.\n10 per-user concurrent query limit.", RED),
    ("Container Security", "Non-root Docker container. Read-only filesystem.\nnginx TLS termination with security headers.\nOpenShift-compatible security context.", LIGHT_BLUE),
]

card_w = Inches(3.7)
card_h = Inches(1.8)
x_starts = [Inches(0.8), Inches(4.7), Inches(8.6)]
y_starts = [Inches(2.0), Inches(4.1)]

for idx, (title, desc, accent) in enumerate(sec_features):
    col = idx % 3
    row = idx // 3
    x, y = x_starts[col], y_starts[row]
    card = _add_shape(slide, x, y, card_w, card_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Accent top bar
    _add_shape(slide, x, y, card_w, Inches(0.05), accent)
    _text_box(slide, x + Inches(0.25), y + Inches(0.2), card_w - Inches(0.5), Inches(0.35),
              title, font_size=15, color=accent, bold=True)
    _text_box(slide, x + Inches(0.25), y + Inches(0.6), card_w - Inches(0.5), card_h - Inches(0.7),
              desc, font_size=11, color=LIGHT_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 9 — Scaling Roadmap
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "ROADMAP")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Scaling Strategy", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(10), Inches(0.5),
          "Three-phase plan to scale from 10 users to enterprise-wide deployment.",
          font_size=15, color=LIGHT_GRAY)

# Phase cards — horizontal timeline
phases = [
    ("PHASE 1", "Worker Pod Extraction", "Q2 2026", [
        "Separate DuckDB worker pods",
        "NFS shared storage for results",
        "Oracle queue for job dispatch",
        "4 CPU / 16 GB per worker pod",
    ], GREEN, "10-50 users"),
    ("PHASE 2", "Distributed API", "Q3 2026", [
        "Redis for session & cache sharing",
        "Multiple API pod replicas",
        "Sticky WebSocket routing",
        "Horizontal pod autoscaling",
    ], BLUE, "50-200 users"),
    ("PHASE 3", "Event-Driven Scale", "Q4 2026", [
        "Kafka for job queue",
        "KEDA auto-scale workers",
        "Multi-region deployment",
        "Unlimited horizontal scale",
    ], CYAN, "200+ users"),
]

phase_w = Inches(3.7)
phase_h = Inches(3.6)
phase_y = Inches(2.5)

for idx, (phase, title, timeline, items, accent, scale) in enumerate(phases):
    x = Inches(0.8) + (phase_w + Inches(0.4)) * idx

    card = _add_shape(slide, x, phase_y, phase_w, phase_h, CARD_BG, border_color=accent)

    # Phase badge
    _add_shape(slide, x + Inches(0.2), phase_y + Inches(0.2), Inches(1.2), Inches(0.35), accent)
    _text_box(slide, x + Inches(0.2), phase_y + Inches(0.22), Inches(1.2), Inches(0.35),
              phase, font_size=11, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Timeline
    _text_box(slide, x + Inches(1.6), phase_y + Inches(0.22), Inches(1.5), Inches(0.35),
              timeline, font_size=11, color=MID_GRAY)

    _text_box(slide, x + Inches(0.25), phase_y + Inches(0.7), phase_w - Inches(0.5), Inches(0.35),
              title, font_size=16, color=WHITE, bold=True)

    for i, item in enumerate(items):
        _text_box(slide, x + Inches(0.4), phase_y + Inches(1.2) + Inches(i * 0.35),
                  phase_w - Inches(0.6), Inches(0.32),
                  f"  {item}", font_size=12, color=LIGHT_GRAY)

    # Scale badge at bottom
    scale_badge = _add_shape(slide, x + Inches(0.8), phase_y + phase_h - Inches(0.55),
                              Inches(2.1), Inches(0.35), accent)
    _text_box(slide, x + Inches(0.8), phase_y + phase_h - Inches(0.53),
              Inches(2.1), Inches(0.35),
              scale, font_size=12, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    # Arrow between phases
    if idx < 2:
        arrow_x = x + phase_w + Inches(0.05)
        _text_box(slide, arrow_x, Inches(4.0), Inches(0.35), Inches(0.5),
                  ">>", font_size=18, color=accent, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 10 — Demo Agenda
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "LIVE DEMO")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Demo Walkthrough", font_size=36, color=WHITE, bold=True)

demo_steps = [
    ("1", "Login & Navigation", "Active Directory login. Sidebar navigation.\nResponsive layout on laptop and large monitor.", BLUE),
    ("2", "Connection Setup", "Create S3 connection with Iceberg tables.\nAutomatic table discovery and schema detection.", CYAN),
    ("3", "Visual Query Builder", "Select tables, columns, filters, joins.\nIceberg partition selection with cached metadata.", GREEN),
    ("4", "Execute & Preview", "Instant preview of first 500 rows.\nFull dataset loads in background.", LIGHT_BLUE),
    ("5", "Export & Download", "Export to CSV, Excel, JSON, or Parquet.\nDownload Center with file management.", ORANGE),
    ("6", "Schedule & Automate", "Create cron schedule. Configure email recipients.\nAutomatic report generation and delivery.", RED),
]

for idx, (num, title, desc, accent) in enumerate(demo_steps):
    y = Inches(2.0) + Inches(idx * 0.85)
    # Number circle
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
        Inches(1.0), y + Inches(0.05), Inches(0.5), Inches(0.5))
    circle.fill.solid()
    circle.fill.fore_color.rgb = accent
    circle.line.fill.background()
    _text_box(slide, Inches(1.0), y + Inches(0.08), Inches(0.5), Inches(0.5),
              num, font_size=18, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    # Connecting line (except last)
    if idx < len(demo_steps) - 1:
        _add_shape(slide, Inches(1.22), y + Inches(0.55), Inches(0.06), Inches(0.35), RGBColor(0x33, 0x3E, 0x55))
    # Title + desc
    _text_box(slide, Inches(1.8), y, Inches(3), Inches(0.35),
              title, font_size=16, color=WHITE, bold=True)
    _text_box(slide, Inches(1.8), y + Inches(0.35), Inches(4.5), Inches(0.5),
              desc, font_size=11, color=LIGHT_GRAY)


# Right side — key talking points box
tp_x = Inches(7.5)
tp_y = Inches(2.0)
tp_box = _add_shape(slide, tp_x, tp_y, Inches(5), Inches(4.8), CARD_BG, border_color=BLUE)
_text_box(slide, tp_x + Inches(0.3), tp_y + Inches(0.2), Inches(4.4), Inches(0.35),
          "KEY TALKING POINTS", font_size=13, color=BLUE, bold=True)

talking_points = [
    "Self-service — analysts don't need engineering help",
    "6 data sources unified in one browser tab",
    "Iceberg partition pruning = fast queries on huge datasets",
    "Scheduling eliminates manual report runs",
    "AD authentication — no new passwords for users",
    "Production-ready today for 10-15 users",
    "Scaling roadmap to 200+ users planned",
    "Zero external dependency — runs on existing OpenShift",
]
for i, tp in enumerate(talking_points):
    _text_box(slide, tp_x + Inches(0.3), tp_y + Inches(0.7) + Inches(i * 0.48),
              Inches(4.4), Inches(0.4),
              f"  {tp}", font_size=12, color=WHITE if i % 2 == 0 else LIGHT_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 11 — Benefits
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "BENEFITS")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "What Query Studio Brings to the Table", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(11), Inches(0.45),
          "A unified layer on top of your existing data platforms — not a replacement.",
          font_size=15, color=LIGHT_GRAY)

# Benefit cards — 2 rows x 3 columns, simple and direct
benefits = [
    ("Unified Access",
     "One browser tab to query S3 Iceberg,\nSnowflake, Databricks, Trino, and Oracle.\nNo tool switching. No context switching.",
     BLUE),
    ("Self-Service for Analysts",
     "Visual query builder — no SQL needed.\nSelect columns, add filters, pick partitions.\nAnalysts don't wait on engineering.",
     CYAN),
    ("One-Click Export",
     "Download results as CSV, Excel, JSON,\nor Parquet. Click a button — done.\nNo Python scripts, no CLI tools.",
     GREEN),
    ("Automated Reporting",
     "Schedule any query to run daily, weekly,\nor monthly. Results emailed to stakeholders\nautomatically. No manual effort.",
     ORANGE),
    ("Cross-Source Joins",
     "Join an S3 Iceberg fact table with a\nSnowflake dimension table in one query.\nSomething no existing tool can do.",
     LIGHT_BLUE),
    ("Zero Additional Cost",
     "Runs on existing OpenShift infrastructure.\nNo per-query compute charges.\nNo new vendor licenses needed.",
     GREEN),
]

card_w = Inches(3.7)
card_h = Inches(1.8)
x_starts = [Inches(0.8), Inches(4.7), Inches(8.6)]
y_starts = [Inches(2.4), Inches(4.5)]

for idx, (title, desc, accent) in enumerate(benefits):
    col = idx % 3
    row = idx // 3
    x, y = x_starts[col], y_starts[row]
    card = _add_shape(slide, x, y, card_w, card_h, CARD_BG, border_color=RGBColor(0x33, 0x3E, 0x55))
    # Accent left bar
    _add_shape(slide, x, y, Inches(0.06), card_h, accent)
    # Title
    _text_box(slide, x + Inches(0.25), y + Inches(0.2), card_w - Inches(0.5), Inches(0.35),
              title, font_size=16, color=accent, bold=True)
    # Description
    _text_box(slide, x + Inches(0.25), y + Inches(0.6), card_w - Inches(0.5), card_h - Inches(0.7),
              desc, font_size=12, color=LIGHT_GRAY)

# Bottom tagline
_text_box(slide, Inches(0.8), Inches(6.6), Inches(11.5), Inches(0.4),
          "Query Studio makes your existing data investments more accessible to everyone in the organization.",
          font_size=14, color=CYAN, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE — Deployment: AWS Advantage
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)
_section_header(slide, "DEPLOYMENT")

_text_box(slide, Inches(0.8), Inches(0.9), Inches(11), Inches(0.8),
          "Deploy on AWS — S3 is Right Next Door", font_size=36, color=WHITE, bold=True)

_text_box(slide, Inches(0.8), Inches(1.7), Inches(11), Inches(0.45),
          "Query Studio + AWS same-region = S3 data travels at network speed, not internet speed.",
          font_size=15, color=LIGHT_GRAY)

# The key insight — big visual
insight_y = Inches(2.5)
insight_box = _add_shape(slide, Inches(0.8), insight_y, Inches(11.5), Inches(1.2), CARD_BG, border_color=GREEN)

# On-prem path
_text_box(slide, Inches(1.2), insight_y + Inches(0.1), Inches(4.5), Inches(0.35),
          "On-Prem / Cross-Region", font_size=13, color=ORANGE, bold=True)
_text_box(slide, Inches(1.2), insight_y + Inches(0.45), Inches(4.5), Inches(0.6),
          "App  ---internet/VPN--->  S3\n~50-200ms latency  |  100-500 MB/s  |  queries take minutes",
          font_size=12, color=LIGHT_GRAY)

# AWS same-region path
_text_box(slide, Inches(6.8), insight_y + Inches(0.1), Inches(4.5), Inches(0.35),
          "AWS Same-Region (EC2 / EKS)", font_size=13, color=GREEN, bold=True)
_text_box(slide, Inches(6.8), insight_y + Inches(0.45), Inches(4.5), Inches(0.6),
          "App  ---VPC--->  S3\n~1-5ms latency  |  5-10 GB/s  |  queries take seconds",
          font_size=12, color=WHITE)

# Performance comparison table
table_y = Inches(4.0)
table_box = _add_shape(slide, Inches(0.8), table_y, Inches(7.5), Inches(3.0), CARD_BG,
                         border_color=RGBColor(0x33, 0x3E, 0x55))
_text_box(slide, Inches(0.8), table_y + Inches(0.1), Inches(7.5), Inches(0.35),
          "EXPECTED PERFORMANCE COMPARISON", font_size=12, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)

# Table header
th_y = table_y + Inches(0.5)
_add_shape(slide, Inches(0.9), th_y, Inches(7.3), Inches(0.35), DARK_BLUE)
_text_box(slide, Inches(1.1), th_y + Inches(0.04), Inches(2.5), Inches(0.3),
          "Operation", font_size=11, color=LIGHT_GRAY, bold=True)
_text_box(slide, Inches(3.6), th_y + Inches(0.04), Inches(2), Inches(0.3),
          "On-Prem / Cross-Region", font_size=11, color=ORANGE, bold=True)
_text_box(slide, Inches(5.8), th_y + Inches(0.04), Inches(2.2), Inches(0.3),
          "AWS Same-Region", font_size=11, color=GREEN, bold=True)

perf_rows = [
    ("Partition metadata scan",  "3 - 8 seconds",    "< 1 second"),
    ("Read 500 Parquet files",   "30 - 90 seconds",  "3 - 10 seconds"),
    ("Full dataset export",      "2 - 5 minutes",    "15 - 45 seconds"),
    ("Preview (first 500 rows)", "5 - 15 seconds",   "1 - 3 seconds"),
    ("Iceberg manifest scan",    "5 - 20 seconds",   "< 2 seconds"),
]

for r_idx, (op, on_prem, aws) in enumerate(perf_rows):
    ry = th_y + Inches(0.45) + Inches(r_idx * 0.42)
    if r_idx % 2 == 0:
        _add_shape(slide, Inches(0.9), ry, Inches(7.3), Inches(0.38), RGBColor(0x16, 0x20, 0x30))
    _text_box(slide, Inches(1.1), ry + Inches(0.05), Inches(2.4), Inches(0.3),
              op, font_size=11, color=WHITE)
    _text_box(slide, Inches(3.6), ry + Inches(0.05), Inches(2), Inches(0.3),
              on_prem, font_size=11, color=ORANGE)
    _text_box(slide, Inches(5.8), ry + Inches(0.05), Inches(2.2), Inches(0.3),
              aws, font_size=11, color=GREEN, bold=True)

# Right side — recommended instance
rec_x = Inches(8.8)
rec_y = Inches(4.0)
rec_box = _add_shape(slide, rec_x, rec_y, Inches(3.5), Inches(3.0), CARD_BG, border_color=BLUE)
_text_box(slide, rec_x, rec_y + Inches(0.1), Inches(3.5), Inches(0.35),
          "RECOMMENDED", font_size=11, color=BLUE, bold=True, alignment=PP_ALIGN.CENTER)

# Instance card
inst_y = rec_y + Inches(0.55)
_add_shape(slide, rec_x + Inches(0.2), inst_y, Inches(3.1), Inches(0.9), DARK_BLUE, border_color=GREEN)
_text_box(slide, rec_x + Inches(0.2), inst_y + Inches(0.05), Inches(3.1), Inches(0.3),
          "m5.2xlarge", font_size=18, color=GREEN, bold=True, alignment=PP_ALIGN.CENTER)
_text_box(slide, rec_x + Inches(0.2), inst_y + Inches(0.38), Inches(3.1), Inches(0.5),
          "8 vCPU  |  32 GB RAM\n~$280/month (on-demand)", font_size=11, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)

# Why it works
why_items = [
    "8 cores = 2x current setup",
    "32 GB for DuckDB in-memory ops",
    "Same-region S3 = 10x faster I/O",
    "Supports 10-15 concurrent users",
]
for i, item in enumerate(why_items):
    _text_box(slide, rec_x + Inches(0.3), inst_y + Inches(1.1) + Inches(i * 0.32),
              Inches(3), Inches(0.28),
              f"  {item}", font_size=11, color=LIGHT_GRAY)


# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE — Next Steps / Thank You
# ═══════════════════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
_solid_bg(slide, NAVY)

# Accent line
_add_shape(slide, Inches(0.8), Inches(2.0), Inches(0.8), Inches(0.06), BLUE)

_text_box(slide, Inches(0.8), Inches(2.2), Inches(10), Inches(1),
          "Next Steps", font_size=42, color=WHITE, bold=True)

steps = [
    ("1", "Go-Live", "Deploy to OpenShift for pilot group (10-15 users)", GREEN),
    ("2", "Feedback Sprint", "Collect user feedback over 2-4 weeks", BLUE),
    ("3", "Phase 1 Scaling", "Introduce worker pods for higher concurrency", CYAN),
    ("4", "Enterprise Rollout", "Expand to wider teams with AD group-based access", ORANGE),
]

for i, (num, title, desc, accent) in enumerate(steps):
    y = Inches(3.5) + Inches(i * 0.7)
    # Number
    nbadge = _add_shape(slide, Inches(1.2), y, Inches(0.5), Inches(0.42), accent)
    _text_box(slide, Inches(1.2), y + Inches(0.02), Inches(0.5), Inches(0.42),
              num, font_size=16, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    _text_box(slide, Inches(2.0), y, Inches(3), Inches(0.35),
              title, font_size=18, color=WHITE, bold=True)
    _text_box(slide, Inches(2.0), y + Inches(0.32), Inches(7), Inches(0.35),
              desc, font_size=14, color=LIGHT_GRAY)

# Decorative right block
_add_shape(slide, Inches(10.5), Inches(0), Inches(2.833), Inches(7.5), BLUE)
_text_box(slide, Inches(10.5), Inches(2.8), Inches(2.833), Inches(1),
          "QS", font_size=72, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
_text_box(slide, Inches(10.5), Inches(3.9), Inches(2.833), Inches(0.5),
          "Query Studio", font_size=16, color=WHITE, alignment=PP_ALIGN.CENTER)
_text_box(slide, Inches(10.5), Inches(4.5), Inches(2.833), Inches(0.5),
          "Thank You", font_size=20, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════════════════════════════════
# Save
# ═══════════════════════════════════════════════════════════════════════════════
output_path = r"c:\DEV\outputs\QueryStudio_Demo_v2.pptx"
prs.save(output_path)
print(f"Presentation saved to: {output_path}")
print(f"Slides: {len(prs.slides)}")
