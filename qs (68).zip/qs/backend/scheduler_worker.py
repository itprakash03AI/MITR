"""
QueryStudio Scheduler Worker — standalone process.

Runs APScheduler + system maintenance jobs in an independent process,
isolated from the main FastAPI HTTP server.  Communicates with FastAPI
via a shared SQLite DB (WAL mode) and a ``pending_notifications`` table.

Usage:
    python scheduler_worker.py

The worker exposes a small internal FastAPI control API on
``scheduler.worker_host:scheduler.worker_port`` (default 127.0.0.1:8001)
for health checks, pause/resume, and job management.

This process is only needed when ``scheduler.mode = "external"`` in
config.json.  When ``scheduler.mode = "embedded"`` (default), the
scheduler runs inside the main FastAPI process as before.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

# Ensure the backend directory is on sys.path so ``core.*`` imports work
_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

logger = logging.getLogger("scheduler_worker")

# ── Globals (set during lifespan) ────────────────────────────────────────────
_db_manager = None
_db_url: str = ""


# ── Pydantic models for control API ─────────────────────────────────────────

class AddJobRequest(BaseModel):
    schedule_id: int
    trigger_config: dict
    name: str = ""


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup: init DB + APScheduler.  Shutdown: stop scheduler."""
    global _db_manager, _db_url

    # ── Load config ──────────────────────────────────────────────────────
    from core.config import paths as _paths, scheduler as _sched_cfg

    # ── Logging ──────────────────────────────────────────────────────────
    log_level = os.getenv("QUERYSTUDIO_SERVER_LOG_LEVEL", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Database ─────────────────────────────────────────────────────────
    db_file = Path(_paths.db_file).resolve()
    _db_url = f"sqlite:///{db_file.as_posix()}"

    from core.database import DatabaseManager
    _db_manager = DatabaseManager(db_url=_db_url)
    logger.info("Database: %s", _db_url)

    # ── Wire broadcast to notification queue ─────────────────────────────
    from core.scheduler import set_broadcast_fn, init_scheduler
    from core.notification_queue import enqueue

    def _queue_broadcast(payload: dict):
        enqueue(_db_manager.SessionLocal, payload)

    set_broadcast_fn(_queue_broadcast)

    # ── Start APScheduler ────────────────────────────────────────────────
    def _start_scheduler():
        try:
            init_scheduler(_db_manager, db_url=_db_url)
            logger.info("APScheduler started in worker process")
        except Exception as exc:
            logger.error("APScheduler startup failed: %s", exc, exc_info=True)

    threading.Thread(target=_start_scheduler, daemon=True).start()

    # Give scheduler a moment to initialise before accepting control requests
    await asyncio.sleep(0.5)

    logger.info(
        "Scheduler worker ready on %s:%d",
        _sched_cfg.worker_host, _sched_cfg.worker_port,
    )

    yield  # ── App is running ──

    # ── Shutdown ─────────────────────────────────────────────────────────
    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()
    logger.info("Scheduler worker stopped")


# ── FastAPI control app ──────────────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio Scheduler Worker",
    docs_url=None,
    redoc_url=None,
    lifespan=_lifespan,
)


@control_app.get("/health")
async def health():
    """Liveness probe — always 200 if process is up."""
    from core.scheduler import get_scheduler_status
    status = get_scheduler_status()
    return {"status": "ok", **status}


@control_app.get("/control/status")
async def scheduler_status():
    """Full scheduler state: running, paused, job list with next_run times."""
    from core.scheduler import get_scheduler_status
    return get_scheduler_status()


@control_app.post("/control/pause")
async def pause():
    """Pause all job triggers. Running jobs finish normally."""
    from core.scheduler import pause_scheduler
    ok = pause_scheduler()
    if not ok:
        raise HTTPException(400, "Scheduler not running")
    return {"message": "Scheduler paused"}


@control_app.post("/control/resume")
async def resume():
    """Resume all job triggers."""
    from core.scheduler import resume_scheduler
    ok = resume_scheduler()
    if not ok:
        raise HTTPException(400, "Scheduler not initialised")
    return {"message": "Scheduler resumed"}


@control_app.post("/control/add-job")
async def add_job(req: AddJobRequest):
    """Register a new APScheduler job from a DB schedule record."""
    from core.scheduler import add_schedule
    # Build a minimal schedule record dict matching what add_schedule expects
    record = {
        "id": req.schedule_id,
        "trigger_config": req.trigger_config,
        "name": req.name or f"schedule_{req.schedule_id}",
    }
    try:
        job_id = add_schedule(record)
    except Exception as exc:
        raise HTTPException(500, f"Failed to register job: {exc}")
    return {"job_id": job_id}


@control_app.post("/control/remove-job/{job_id}")
async def remove_job(job_id: str):
    """Remove an APScheduler job by its job ID."""
    from core.scheduler import remove_schedule
    try:
        remove_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to remove job: {exc}")
    return {"message": "Removed", "job_id": job_id}


@control_app.post("/control/pause-job/{job_id}")
async def pause_job(job_id: str):
    """Pause a specific job (keeps trigger, stops firing)."""
    from core.scheduler import pause_schedule
    try:
        pause_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to pause job: {exc}")
    return {"message": "Paused", "job_id": job_id}


@control_app.post("/control/resume-job/{job_id}")
async def resume_job(job_id: str):
    """Resume a paused job."""
    from core.scheduler import resume_schedule
    try:
        next_run = resume_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to resume job: {exc}")
    return {
        "message": "Resumed",
        "job_id": job_id,
        "next_run": next_run.isoformat() if next_run else None,
    }


@control_app.post("/control/run-now/{schedule_id}")
async def run_now(schedule_id: int):
    """Trigger an immediate out-of-schedule run."""
    from core.scheduler import run_now as _run_now
    try:
        _run_now(schedule_id)
    except Exception as exc:
        raise HTTPException(500, f"Immediate run failed: {exc}")
    return {"message": "Triggered", "schedule_id": schedule_id}


@control_app.post("/control/shutdown")
async def shutdown():
    """Graceful shutdown — stop scheduler and exit."""
    logger.info("Shutdown requested via control API")
    # Schedule the actual exit after response is sent
    def _delayed_exit():
        import time
        time.sleep(1)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return {"message": "Shutting down"}


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    import uvicorn
    from core.config import scheduler as _sched_cfg

    host = _sched_cfg.worker_host
    port = _sched_cfg.worker_port

    print(f"[scheduler_worker] Starting on {host}:{port}")

    # Windows Ctrl+C handling
    if sys.platform == "win32":
        def _sigint_handler(signum, frame):
            print("\n[scheduler_worker] Ctrl+C — stopping…")
            os._exit(0)
        signal.signal(signal.SIGINT, _sigint_handler)
        try:
            signal.signal(signal.SIGBREAK, _sigint_handler)
        except (AttributeError, OSError):
            pass

    uvicorn.run(
        control_app,
        host=host,
        port=port,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
