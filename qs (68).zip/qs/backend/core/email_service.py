"""
Email Notification Service — SMTP-based

Sends HTML emails for:
  - Scheduled job completion / failure
  - Query execution completion (optional)
  - System alerts

Configuration (highest → lowest priority):
  1. Runtime override via configure_email() (API call)
  2. config.json  email.*  section
  3. Environment variables (legacy):
       SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD,
       SMTP_USE_TLS, SMTP_USE_SSL, EMAIL_FROM, EMAIL_FROM_NAME
"""

from __future__ import annotations

import html as _html_mod
import logging
import os
import re as _re
import smtplib
import ssl
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Optional

logger = logging.getLogger(__name__)


def _cfg(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


def _cfg_bool(key: str, default: bool = True) -> bool:
    val = os.environ.get(key, "").strip().lower()
    if not val:
        return default
    return val in ("1", "true", "yes", "on")


def _cfg_int(key: str, default: int = 587) -> int:
    try:
        return int(os.environ.get(key, str(default)))
    except ValueError:
        return default


# ─── Runtime config (can be overridden via /api/email/configure) ─────────────
# Resolution order: config.json email.* > legacy SMTP_* env vars > built-in defaults
def _init_email_config() -> dict:
    try:
        from core.config import email as _ecfg
        host = _ecfg.host or _cfg("SMTP_HOST", "")
        port = _ecfg.port if _ecfg.host else _cfg_int("SMTP_PORT", 587)
        user = _ecfg.user or _cfg("SMTP_USER")
        pwd  = _ecfg.password or _cfg("SMTP_PASSWORD")
        from_addr = _ecfg.from_address or _cfg("EMAIL_FROM", "noreply@queryengine.local")
        use_tls = _ecfg.use_tls if _ecfg.host else _cfg_bool("SMTP_USE_TLS", True)
    except Exception:
        # Fallback to pure env vars if config module unavailable
        host = _cfg("SMTP_HOST", "")
        port = _cfg_int("SMTP_PORT", 587)
        user = _cfg("SMTP_USER")
        pwd  = _cfg("SMTP_PASSWORD")
        from_addr = _cfg("EMAIL_FROM", "noreply@queryengine.local")
        use_tls = _cfg_bool("SMTP_USE_TLS", True)
    return {
        "host":      host,
        "port":      port,
        "user":      user,
        "password":  pwd,
        "use_tls":   use_tls,
        "use_ssl":   _cfg_bool("SMTP_USE_SSL", False),
        "from_addr": from_addr,
        "from_name": _cfg("EMAIL_FROM_NAME", "Query Engine"),
        "enabled":   bool(host),
    }

_email_config: dict = _init_email_config()


def configure_email(config: dict) -> None:
    """Update runtime SMTP configuration."""
    global _email_config
    _email_config.update(config)
    _email_config["enabled"] = bool(_email_config.get("host"))
    logger.info("Email configuration updated (host=%s, port=%s)", _email_config["host"], _email_config["port"])


def get_email_config() -> dict:
    """Return current config (password masked)."""
    safe = dict(_email_config)
    if safe.get("password"):
        safe["password"] = "••••••"
    return safe


def is_email_enabled() -> bool:
    return bool(_email_config.get("enabled") and _email_config.get("host"))


# ─── Core send function ───────────────────────────────────────────────────────

def send_email(
    to_addresses: List[str],
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
) -> bool:
    """
    Send an HTML email. Returns True on success, False on failure.
    Never raises — logs errors instead.
    """
    if not is_email_enabled():
        logger.debug("Email not configured — skipping send to %s", to_addresses)
        return False

    if not to_addresses:
        return False

    # Validate email addresses — reject header injection attempts
    _email_re = _re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')
    validated = [a for a in to_addresses if _email_re.match(a.strip())]
    if not validated:
        logger.warning("No valid email addresses after validation: %s", to_addresses)
        return False
    to_addresses = validated

    cfg = _email_config
    from_header = f"{cfg['from_name']} <{cfg['from_addr']}>" if cfg.get("from_name") else cfg["from_addr"]

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = from_header
    msg["To"]      = ", ".join(to_addresses)
    msg["Date"]    = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")

    # Plain-text fallback
    plain = text_body or _html_to_plain(html_body)
    msg.attach(MIMEText(plain, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html",  "utf-8"))

    try:
        if cfg.get("use_ssl"):
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=context) as server:
                _auth_and_send(server, cfg, from_header, to_addresses, msg)
        else:
            with smtplib.SMTP(cfg["host"], cfg["port"], timeout=15) as server:
                server.ehlo()
                if cfg.get("use_tls"):
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                _auth_and_send(server, cfg, from_header, to_addresses, msg)

        logger.info("Email sent to %s — %r", to_addresses, subject)
        return True

    except Exception as exc:
        logger.error("Failed to send email to %s: %s", to_addresses, exc)
        return False


def _auth_and_send(server: smtplib.SMTP, cfg: dict, from_addr: str, to_addrs: List[str], msg) -> None:
    if cfg.get("user") and cfg.get("password"):
        server.login(cfg["user"], cfg["password"])
    server.sendmail(from_addr, to_addrs, msg.as_string())


def _html_to_plain(html: str) -> str:
    """Very basic HTML → plain text fallback."""
    import re
    text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&amp;",  "&",  text)
    text = re.sub(r"&lt;",   "<",  text)
    text = re.sub(r"&gt;",   ">",  text)
    text = re.sub(r"&nbsp;", " ",  text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ─── SMTP connection test ──────────────────────────────────────────────────────

def test_smtp_connection() -> dict:
    """Test SMTP connectivity. Returns {success, message}."""
    cfg = _email_config
    if not cfg.get("host"):
        return {"success": False, "message": "SMTP host not configured"}
    try:
        if cfg.get("use_ssl"):
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=context, timeout=10) as s:
                if cfg.get("user") and cfg.get("password"):
                    s.login(cfg["user"], cfg["password"])
        else:
            with smtplib.SMTP(cfg["host"], cfg["port"], timeout=10) as s:
                s.ehlo()
                if cfg.get("use_tls"):
                    s.starttls(context=ssl.create_default_context())
                    s.ehlo()
                if cfg.get("user") and cfg.get("password"):
                    s.login(cfg["user"], cfg["password"])
        return {"success": True, "message": f"Connected to {cfg['host']}:{cfg['port']} successfully"}
    except Exception as exc:
        return {"success": False, "message": str(exc)}


# ─── HTML email templates ──────────────────────────────────────────────────────

_BASE_STYLE = """
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
       background: #f8fafc; margin: 0; padding: 24px; color: #0f172a; }
.card { background: #fff; border-radius: 8px; padding: 32px; max-width: 600px;
        margin: 0 auto; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
.header { border-bottom: 2px solid #e2e8f0; padding-bottom: 16px; margin-bottom: 24px; }
.title { font-size: 20px; font-weight: 700; color: #1565c0; }
.label { font-size: 12px; color: #64748b; text-transform: uppercase;
         letter-spacing: .05em; margin-bottom: 4px; }
.value { font-size: 14px; color: #0f172a; margin-bottom: 16px; }
.badge-success { background: #d1fae5; color: #065f46; padding: 4px 10px;
                 border-radius: 12px; font-size: 12px; font-weight: 600; }
.badge-error   { background: #fee2e2; color: #991b1b; padding: 4px 10px;
                 border-radius: 12px; font-size: 12px; font-weight: 600; }
.footer { font-size: 12px; color: #94a3b8; margin-top: 24px; padding-top: 16px;
          border-top: 1px solid #e2e8f0; }
"""


def build_schedule_completion_email(
    schedule_name: str,
    status: str,           # "completed" | "failed"
    output_file: Optional[str],
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
    run_at: Optional[str],
) -> tuple[str, str]:
    """Returns (subject, html_body)."""
    ok = status == "completed"
    badge_cls = "badge-success" if ok else "badge-error"
    status_label = "Completed" if ok else "Failed"

    # Sanitize user-controlled strings to prevent email header injection and HTML injection
    _safe_name = _html_mod.escape(str(schedule_name).replace("\r", "").replace("\n", ""))
    subject = f"[Query Engine] Schedule '{_safe_name}' {status_label}"

    rows_html = ""
    if row_count is not None:
        rows_html = f"<div class='label'>Rows Exported</div><div class='value'>{int(row_count):,}</div>"

    duration_html = ""
    if duration_seconds is not None:
        secs = int(duration_seconds)
        duration_html = f"<div class='label'>Duration</div><div class='value'>{secs}s</div>"

    file_html = ""
    if output_file:
        fname = _html_mod.escape(output_file.rsplit("/", 1)[-1].rsplit("\\", 1)[-1])
        file_html = f"<div class='label'>Output File</div><div class='value'>{fname}</div>"

    error_html = ""
    if not ok and error_message:
        _safe_err = _html_mod.escape(str(error_message)[:500])  # truncate to prevent huge emails
        error_html = f"""
        <div class='label'>Error</div>
        <div class='value' style='color:#991b1b;background:#fee2e2;padding:12px;border-radius:6px;font-size:13px;'>
            {_safe_err}
        </div>"""

    run_html = ""
    if run_at:
        try:
            dt = datetime.fromisoformat(run_at.replace("Z", "+00:00"))
            run_html = f"<div class='label'>Run At</div><div class='value'>{dt.strftime('%Y-%m-%d %H:%M UTC')}</div>"
        except Exception as exc:
            logging.getLogger(__name__).warning("%s failed: %s", "email_service", exc, exc_info=True)

    html = f"""<!DOCTYPE html><html><head><style>{_BASE_STYLE}</style></head><body>
<div class='card'>
  <div class='header'>
    <div class='title'>Scheduled Job Notification</div>
  </div>
  <div class='label'>Schedule</div>
  <div class='value' style='font-weight:600;'>{_safe_name}</div>
  <div class='label'>Status</div>
  <div class='value'><span class='{badge_cls}'>{status_label}</span></div>
  {run_html}
  {rows_html}
  {duration_html}
  {file_html}
  {error_html}
  <div class='footer'>Query Studio · Automated notification · Do not reply</div>
</div>
</body></html>"""
    return subject, html


def build_execution_completion_email(
    query_name: str,
    status: str,
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
) -> tuple[str, str]:
    """Returns (subject, html_body)."""
    ok = status == "completed"
    _safe_name = _html_mod.escape(str(query_name).replace("\r", "").replace("\n", ""))
    subject = f"[Query Engine] Query '{_safe_name}' {'completed' if ok else 'failed'}"

    rows_html = f"<div class='label'>Rows</div><div class='value'>{int(row_count):,}</div>" if row_count else ""
    dur_html  = f"<div class='label'>Duration</div><div class='value'>{int(duration_seconds or 0)}s</div>" if duration_seconds else ""
    _safe_err = _html_mod.escape(str(error_message)[:500]) if error_message else ""
    err_html  = (f"<div class='label'>Error</div><div class='value' style='color:#991b1b;'>{_safe_err}</div>"
                 if not ok and _safe_err else "")

    html = f"""<!DOCTYPE html><html><head><style>{_BASE_STYLE}</style></head><body>
<div class='card'>
  <div class='header'><div class='title'>Query Execution Notification</div></div>
  <div class='label'>Query</div>
  <div class='value' style='font-weight:600;'>{_safe_name}</div>
  <div class='label'>Status</div>
  <div class='value'><span class='{'badge-success' if ok else 'badge-error'}'>{'Completed' if ok else 'Failed'}</span></div>
  {rows_html}{dur_html}{err_html}
  <div class='footer'>Query Studio · Automated notification</div>
</div></body></html>"""
    return subject, html
