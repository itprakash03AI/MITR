"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, Index, event as sa_event, text as sa_text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
import json
from contextlib import contextmanager
from pathlib import Path

Base = declarative_base()


class SavedQuery(Base):
    """Model for saved queries"""
    __tablename__ = "saved_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    query_config = Column(JSON, nullable=False)  # Stores QueryConfig as JSON
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)
    is_favorite = Column(Boolean, default=False)
    is_shared = Column(Boolean, default=False)
    execution_count = Column(Integer, default=0)
    last_executed_at = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "query_config": self.query_config,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
            "is_favorite": self.is_favorite or False,
            "is_shared": self.is_shared or False,
            "execution_count": self.execution_count,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None
        }


class QueryExecution(Base):
    """Model for tracking query executions"""
    __tablename__ = "query_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, nullable=True)  # Reference to SavedQuery if applicable
    execution_id = Column(String(100), unique=True, nullable=False, index=True)
    query_config = Column(JSON, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    total_rows = Column(Integer, default=0)
    chunks_processed = Column(Integer, default=0)
    output_file = Column(String(500), nullable=True)
    file_size_bytes = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    executed_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "query_id": self.query_id,
            "execution_id": self.execution_id,
            "query_config": self.query_config,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "total_rows": self.total_rows,
            "chunks_processed": self.chunks_processed,
            "output_file": self.output_file,
            "file_size_bytes": self.file_size_bytes,
            "error_message": self.error_message,
            "executed_by": self.executed_by
        }


class AuditLog(Base):
    """Immutable audit trail — who did what, when, from where."""
    __tablename__ = "audit_log"

    id            = Column(Integer, primary_key=True, index=True)
    timestamp     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    username      = Column(String(100), nullable=False, index=True)
    action        = Column(String(100), nullable=False, index=True)  # execute_query, cancel_query, save_query…
    resource_type = Column(String(50),  nullable=True)               # query, execution, dashboard, connection
    resource_id   = Column(String(200), nullable=True)
    ip_address    = Column(String(50),  nullable=True)
    user_agent    = Column(String(500), nullable=True)
    details       = Column(JSON, nullable=True)                      # arbitrary extra context

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "timestamp":     self.timestamp.isoformat() if self.timestamp else None,
            "username":      self.username,
            "action":        self.action,
            "resource_type": self.resource_type,
            "resource_id":   self.resource_id,
            "ip_address":    self.ip_address,
            "details":       self.details,
        }


class DownloadFile(Base):
    """Model for tracking downloadable files"""
    __tablename__ = "download_files"
    
    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String(100), unique=True, nullable=False, index=True)
    execution_id = Column(String(100), nullable=True, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, default=0)
    status = Column(String(50), default="available")  # available, downloaded, expired, deleted
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at = Column(DateTime, nullable=True)
    download_count = Column(Integer, default=0)
    last_downloaded_at = Column(DateTime, nullable=True)
    created_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "execution_id": self.execution_id,
            "filename": self.filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "download_count": self.download_count,
            "last_downloaded_at": self.last_downloaded_at.isoformat() if self.last_downloaded_at else None,
            "created_by": self.created_by
        }


class SqlSavedQuery(Base):
    """Model for SQL queries executed against SQL connectors (Trino, Snowflake, Databricks)."""
    __tablename__ = "sql_saved_queries"

    id                     = Column(Integer,     primary_key=True, index=True)
    name                   = Column(String(255), nullable=False,   index=True)
    description            = Column(Text,        nullable=True)
    # Primary source
    primary_connection_id  = Column(Integer,     nullable=False)
    primary_sql            = Column(Text,        nullable=False)
    # Optional secondary source for cross-source joins
    secondary_connection_id = Column(Integer,    nullable=True)
    secondary_sql          = Column(Text,        nullable=True)
    # Join config: { how, left_on, right_on, suffixes }
    join_config            = Column(JSON,        nullable=True)
    # Metadata
    created_by             = Column(String(100), nullable=True)
    created_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active              = Column(Boolean,     default=True)
    is_shared              = Column(Boolean,     default=False)
    execution_count        = Column(Integer,     default=0)
    last_executed_at       = Column(DateTime,    nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "primary_connection_id":   self.primary_connection_id,
            "primary_sql":             self.primary_sql,
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_sql":           self.secondary_sql,
            "join_config":             self.join_config,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "is_active":               self.is_active,
            "is_shared":               self.is_shared or False,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
        }


class Connection(Base):
    """Model for data source connections"""
    __tablename__ = "connections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    connection_type = Column(String(50), nullable=False)
    config = Column(JSON, nullable=False)   # sensitive fields stored encrypted
    is_active = Column(Boolean, default=True)
    is_shared = Column(Boolean, default=False)  # shared with all users
    created_by = Column(String(100), nullable=True)
    last_tested_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(50), nullable=True)  # 'success' or 'failed'
    last_test_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary (config may contain encrypted values)."""
        return {
            "id": self.id,
            "name": self.name,
            "connection_type": self.connection_type,
            "config": self.config,
            "is_active": self.is_active,
            "is_shared": self.is_shared or False,
            "created_by": self.created_by,
            "last_tested_at": self.last_tested_at.isoformat() if self.last_tested_at else None,
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


class Report(Base):
    """Named parametric report — wraps a saved query or SQL query with a parameter schema."""
    __tablename__ = "reports"

    id                 = Column(Integer,     primary_key=True, index=True)
    name               = Column(String(255), nullable=False,   index=True)
    description        = Column(Text,        nullable=True)

    # Exactly one source is set
    saved_query_id     = Column(Integer, nullable=True)        # → SavedQuery (parquet)
    sql_saved_query_id = Column(Integer, nullable=True)        # → SqlSavedQuery

    # Parameter schema: [{ name, label, type, required, default_value, description }]
    # type: string | number | date | boolean | select
    # If type == select, include options: ["val1", "val2", ...]
    parameters         = Column(JSON, nullable=False, default=list)

    # Optional SQL override (replaces source query's SQL at execution time)
    sql_override       = Column(Text, nullable=True)

    is_active          = Column(Boolean,     default=True)
    is_public          = Column(Boolean,     default=True)
    created_by         = Column(String(100), nullable=True)
    created_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    execution_count    = Column(Integer,     default=0)
    last_executed_at   = Column(DateTime,    nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                   self.id,
            "name":                 self.name,
            "description":          self.description,
            "saved_query_id":       self.saved_query_id,
            "sql_saved_query_id":   self.sql_saved_query_id,
            "parameters":           self.parameters or [],
            "sql_override":         self.sql_override,
            "is_active":            self.is_active,
            "is_public":            self.is_public,
            "created_by":           self.created_by,
            "created_at":           self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":           self.updated_at.isoformat()  if self.updated_at  else None,
            "execution_count":      self.execution_count,
            "last_executed_at":     self.last_executed_at.isoformat() if self.last_executed_at else None,
        }


class Schedule(Base):
    """Scheduled automatic query/report execution → downloads directory."""
    __tablename__ = "schedules"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    is_active       = Column(Boolean,     default=True)
    is_shared       = Column(Boolean,     default=False)

    # Source type: "saved_query" | "sql_query" | "report"
    source_type     = Column(String(50),  nullable=False)
    source_id       = Column(Integer,     nullable=False)

    # Parameter values to pass to the source at run time
    param_values    = Column(JSON, nullable=True)

    # Trigger config:
    #   { "type": "cron",     "cron_expr": "0 8 * * 1-5" }
    #   { "type": "interval", "minutes": 60 }
    trigger_config  = Column(JSON, nullable=False)

    # Output filename template — {date} is replaced with YYYYMMDD_HHMMSS
    output_filename_template = Column(String(255), nullable=True)

    # APScheduler job ID (stored so we can pause/remove specific jobs)
    apscheduler_job_id = Column(String(100), nullable=True, unique=True)

    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Run tracking
    last_run_at     = Column(DateTime, nullable=True)
    last_run_status = Column(String(50), nullable=True)   # success | failed
    last_run_file_id= Column(String(100), nullable=True)
    last_error      = Column(Text, nullable=True)
    run_count       = Column(Integer, default=0)
    next_run_at     = Column(DateTime, nullable=True)

    # Email notifications — comma-separated list of addresses to notify on completion/failure
    notify_emails   = Column(Text, nullable=True)   # e.g. "alice@corp.com,bob@corp.com"
    # Webhook URL for Slack/Teams/generic HTTP POST notifications
    notify_webhook  = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "description":      self.description,
            "is_active":        self.is_active,
            "is_shared":        self.is_shared or False,
            "source_type":      self.source_type,
            "source_id":        self.source_id,
            "param_values":     self.param_values,
            "trigger_config":   self.trigger_config,
            "output_filename_template": self.output_filename_template,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
            "last_run_at":      self.last_run_at.isoformat() if self.last_run_at else None,
            "last_run_status":  self.last_run_status,
            "last_run_file_id": self.last_run_file_id,
            "last_error":       self.last_error,
            "run_count":        self.run_count,
            "next_run_at":      self.next_run_at.isoformat() if self.next_run_at else None,
            "notify_emails":    self.notify_emails,
            "notify_webhook":   self.notify_webhook,
        }


# ── New enterprise models ─────────────────────────────────────────────────────

class QueryCacheEntry(Base):
    """Disk-backed parquet cache keyed by sha256 of canonical query_config JSON."""
    __tablename__ = "query_result_cache"

    cache_key       = Column(String(64), primary_key=True)
    file_path       = Column(String(500), nullable=False)
    row_count       = Column(Integer, default=0)
    file_size_bytes = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at      = Column(DateTime, nullable=True)
    query_config    = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cache_key":       self.cache_key,
            "file_path":       self.file_path,
            "row_count":       self.row_count,
            "file_size_bytes": self.file_size_bytes,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "expires_at":      self.expires_at.isoformat() if self.expires_at else None,
        }


class PartitionCache(Base):
    """Persistent cache for Iceberg partition metadata — survives restarts."""
    __tablename__ = "partition_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    scan_type       = Column(String(10), default="fast")   # "fast" or "full"
    partition_data  = Column(JSON, nullable=False)          # full response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_partition_cache_lookup', 'connection_id', 'table_name', 'scan_type', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "scan_type":      self.scan_type,
            "partition_data": self.partition_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergFileCache(Base):
    """Persistent L2 cache for Iceberg data-file lists — avoids re-scanning S3 manifests."""
    __tablename__ = "iceberg_file_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    filters_hash    = Column(String(512), nullable=False, default="")
    file_list       = Column(JSON, nullable=False)          # list of S3 file paths
    file_count      = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_file_cache_lookup', 'connection_id', 'table_name', 'filters_hash', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "filters_hash":   self.filters_hash,
            "file_list":      self.file_list,
            "file_count":     self.file_count,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class SchemaCache(Base):
    """Persistent cache for registered table schemas — avoids repeated S3 metadata reads."""
    __tablename__ = "schema_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    table_format    = Column(String(20), default="iceberg")     # iceberg, parquet, csv
    schema_data     = Column(JSON, nullable=False)              # full schema response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_schema_cache_lookup', 'connection_id', 'table_name', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "table_format":   self.table_format,
            "schema_data":    self.schema_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class QueryVersion(Base):
    """Immutable snapshot of a SavedQuery before each update."""
    __tablename__ = "query_versions"

    id             = Column(Integer, primary_key=True, index=True)
    query_id       = Column(Integer, nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    name           = Column(String(255), nullable=True)
    description    = Column(Text, nullable=True)
    query_config   = Column(JSON, nullable=True)
    changed_by     = Column(String(100), nullable=True)
    changed_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    change_note    = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "query_id":       self.query_id,
            "version_number": self.version_number,
            "name":           self.name,
            "description":    self.description,
            "query_config":   self.query_config,
            "changed_by":     self.changed_by,
            "changed_at":     self.changed_at.isoformat() if self.changed_at else None,
            "change_note":    self.change_note,
        }


class QueryShare(Base):
    """Share token for a saved query — allows public access via /api/shared/{token}."""
    __tablename__ = "query_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    query_id     = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "query_id":     self.query_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class DashboardShare(Base):
    """Share token for a dashboard — allows public access via /api/shared-dashboard/{token}."""
    __tablename__ = "dashboard_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "dashboard_id": self.dashboard_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class Dashboard(Base):
    """Named canvas that holds multiple report widgets."""
    __tablename__ = "dashboards"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active   = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "is_active":   self.is_active,
        }


class DashboardWidget(Base):
    """Single widget on a dashboard canvas — references a saved query / SQL query / report."""
    __tablename__ = "dashboard_widgets"

    id           = Column(Integer, primary_key=True, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    # "saved_query" | "sql_query" | "report"
    widget_type  = Column(String(50), nullable=False)
    source_id    = Column(Integer, nullable=False)
    title        = Column(String(255), nullable=True)
    # react-grid-layout position: {x, y, w, h}
    layout       = Column(JSON, nullable=True)
    # "grid" | "bar" | "line" | "area" | "pie" | "scatter" | "metric"
    chart_type   = Column(String(50), default="grid")
    # chart config: axis fields, colors, aggregation
    chart_config = Column(JSON, nullable=True)
    # parameter overrides for report widgets
    param_values = Column(JSON, nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "dashboard_id": self.dashboard_id,
            "widget_type":  self.widget_type,
            "source_id":    self.source_id,
            "title":        self.title,
            "layout":       self.layout or {"x": 0, "y": 0, "w": 6, "h": 4},
            "chart_type":   self.chart_type or "grid",
            "chart_config": self.chart_config or {},
            "param_values": self.param_values or {},
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class PendingNotification(Base):
    """Cross-process notification queue.

    The scheduler worker writes notifications here (scheduled job started/completed/failed).
    The FastAPI process polls undelivered rows and broadcasts them via WebSocket,
    then marks them as delivered.  Used when scheduler.mode = "external".
    """
    __tablename__ = "pending_notifications"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    payload      = Column(JSON, nullable=False)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered    = Column(Boolean, default=False, index=True)
    delivered_at = Column(DateTime, nullable=True)


class DatabaseManager:
    """Database manager for handling all database operations"""
    
    def __init__(self, db_url: str = "sqlite:///./data/parquet_query_engine.db"):
        """
        Initialize database manager

        Args:
            db_url: Database connection URL
        """
        # Ensure data directory exists — resolve the path so UNC paths
        # (\\server\share\...) are handled correctly on Windows.
        raw_path = db_url.replace("sqlite:///", "")
        db_path = Path(raw_path).resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        # Rebuild the URL with the resolved absolute path so SQLite's C library
        # never sees a relative or UNC-relative path.
        if "sqlite" in db_url:
            db_url = "sqlite:///" + db_path.as_posix()
        
        is_sqlite = "sqlite" in db_url

        self.engine = create_engine(
            db_url,
            connect_args={"check_same_thread": False} if is_sqlite else {},
            pool_pre_ping=True,
            # pool_size / max_overflow are ignored for SQLite's StaticPool,
            # but kept for potential future migration to PostgreSQL.
            pool_size=20,
            max_overflow=30
        )

        # Enable WAL journal mode for SQLite so concurrent readers never block
        # each other, and writers only block other writers (not readers).
        # busy_timeout makes writers retry for up to 30 s instead of failing
        # immediately when another writer holds the lock.
        if is_sqlite:
            @sa_event.listens_for(self.engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _conn_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA busy_timeout=30000")
                cursor.execute("PRAGMA wal_autocheckpoint=1000")  # checkpoint every 1000 pages
                cursor.close()

            # Checkpoint WAL on startup to consolidate any leftover WAL from
            # a previous unclean shutdown (prevents "malformed" errors).
            # Also run an integrity check — if the DB is corrupt, back it up
            # and start fresh so the app doesn't crash on every write.
            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("PRAGMA wal_checkpoint(TRUNCATE)"))
                    _conn.commit()
                    _ic = _conn.execute(sa_text("PRAGMA integrity_check")).fetchone()
                    if _ic and _ic[0] != "ok":
                        raise RuntimeError(f"integrity_check failed: {_ic[0]}")
            except Exception as _db_err:
                import logging as _log
                _log.getLogger(__name__).warning(
                    "SQLite DB corrupt or unreadable (%s) — backing up and recreating.", _db_err
                )
                # Dispose all engine connections so the file is unlocked
                self.engine.dispose()
                # Move corrupt files aside
                import shutil as _shutil
                _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                for _suffix in ("", "-wal", "-shm", "-journal"):
                    _f = Path(str(db_path) + _suffix)
                    if _f.exists():
                        _f.rename(_f.with_suffix(f".corrupt_{_ts}{_suffix}"))
                # Recreate engine against a now-empty path
                self.engine = create_engine(
                    db_url,
                    connect_args={"check_same_thread": False},
                    pool_pre_ping=True,
                    pool_size=20, max_overflow=30,
                )
                # Re-register the pragma listener on the fresh engine
                @sa_event.listens_for(self.engine, "connect")
                def _set_sqlite_pragmas_fresh(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=30000")
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                    cursor.close()

        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

        # Create tables (only creates tables that don't exist yet)
        Base.metadata.create_all(bind=self.engine)

        # Safe schema migration for SQLite — add any columns that existing
        # tables might be missing when the schema is updated after initial
        # creation.  Base.metadata.create_all never alters existing tables,
        # so new columns must be applied manually.
        if is_sqlite:
            self._apply_sqlite_migrations()

    def _apply_sqlite_migrations(self):
        """Add columns that may be missing from older DB versions (SQLite only).

        Uses a raw sqlite3 connection (bypasses SQLAlchemy version differences)
        so this works identically with SQLAlchemy 1.x and 2.x.
        """
        import sqlite3 as _sqlite3
        db_file = str(self.engine.url).replace("sqlite:///", "")
        if not db_file or db_file == ":memory:":
            return

        # table → list of (column_name, sqlite_type)
        # Extend this dict whenever a new column is added to an existing model.
        migrations: dict = {
            "reports": [
                ("sql_saved_query_id", "INTEGER"),
                ("sql_override",       "TEXT"),
                ("last_executed_at",   "TIMESTAMP"),
            ],
            "schedules": [
                ("notify_emails",  "TEXT"),
                ("notify_webhook", "TEXT"),
                ("is_shared",      "BOOLEAN DEFAULT 0"),
            ],
            # audit_log created fresh by Base.metadata.create_all;
            # listed here only to add any future columns to existing audit_log tables.
            "audit_log": [],
            "saved_queries": [
                ("is_favorite", "BOOLEAN DEFAULT 0"),
                ("is_shared",   "BOOLEAN DEFAULT 0"),
            ],
            "sql_saved_queries": [
                ("is_shared",   "BOOLEAN DEFAULT 0"),
            ],
            "connections": [
                ("is_shared",   "BOOLEAN DEFAULT 0"),
                ("created_by",  "VARCHAR(100)"),
            ],
            "query_executions": [
                ("executed_by", "VARCHAR(100)"),
            ],
            "download_files": [
                ("created_by",  "VARCHAR(100)"),
            ],
            "query_shares": [
                ("created_by",  "VARCHAR(100)"),
            ],
            "dashboard_shares": [
                ("created_by",  "VARCHAR(100)"),
            ],
            "dashboards": [
                ("created_by",  "VARCHAR(100)"),
            ],
        }
        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        try:
            con = _sqlite3.connect(db_file)
            cur = con.cursor()
            for table, columns in migrations.items():
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    existing = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue  # table doesn't exist yet — create_all will handle it
                for col_name, col_type in columns:
                    if col_name not in existing:
                        try:
                            cur.execute(
                                f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"
                            )
                            _mig_log.info("Migration: added %s.%s (%s)", table, col_name, col_type)
                        except Exception as exc:
                            _mig_log.warning("Migration: failed to add %s.%s: %s", table, col_name, exc)
            con.commit()
            con.close()
        except Exception as exc:
            _mig_log.error("SQLite migration failed: %s", exc, exc_info=True)

    @contextmanager
    def get_session(self) -> Session:
        """
        Context manager for database sessions
        
        Yields:
            Database session
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    # SavedQuery operations
    def create_query(self, name: str, query_config: Dict[str, Any],
                    description: Optional[str] = None,
                    created_by: Optional[str] = None) -> SavedQuery:
        """Create a new saved query"""
        with self.get_session() as session:
            query = SavedQuery(
                name=name,
                description=description,
                query_config=query_config,
                created_by=created_by
            )
            session.add(query)
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def get_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a saved query by ID"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            return query.to_dict() if query else None
    
    def list_queries(self, active_only: bool = True,
                    limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all saved queries"""
        with self.get_session() as session:
            query = session.query(SavedQuery)
            
            if active_only:
                query = query.filter(SavedQuery.is_active == True)
            
            query = query.order_by(SavedQuery.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [q.to_dict() for q in query.all()]
    
    def update_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return None
            
            for key, value in kwargs.items():
                if hasattr(query, key):
                    setattr(query, key, value)
            
            query.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def toggle_favorite(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Toggle is_favorite flag on a saved query."""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not query:
                return None
            query.is_favorite = not query.is_favorite
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def delete_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return False
            
            if soft_delete:
                query.is_active = False
                query.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(query)
            
            return True
    
    def increment_execution_count(self, query_id: int) -> None:
        """Increment execution count for a query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if query:
                query.execution_count += 1
                query.last_executed_at = datetime.now(timezone.utc)
    
    # QueryExecution operations
    def create_execution(self, execution_id: str, query_config: Dict[str, Any],
                        query_id: Optional[int] = None,
                        executed_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a new query execution record"""
        with self.get_session() as session:
            execution = QueryExecution(
                execution_id=execution_id,
                query_id=query_id,
                query_config=query_config,
                executed_by=executed_by
            )
            session.add(execution)
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def update_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a query execution"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            
            if not execution:
                return None
            
            for key, value in kwargs.items():
                if hasattr(execution, key):
                    setattr(execution, key, value)
            
            if kwargs.get("status") in ["completed", "failed"]:
                execution.completed_at = datetime.now(timezone.utc)
            
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution by ID"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            return execution.to_dict() if execution else None
    
    def list_executions(self, limit: int = 100, offset: int = 0,
                       status: Optional[str] = None) -> List[Dict[str, Any]]:
        """List query executions"""
        with self.get_session() as session:
            query = session.query(QueryExecution)
            
            if status:
                query = query.filter(QueryExecution.status == status)
            
            query = query.order_by(QueryExecution.started_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [e.to_dict() for e in query.all()]
    
    # DownloadFile operations
    def create_download_file(self, file_id: str, filename: str, file_path: str,
                           file_size_bytes: int, execution_id: Optional[str] = None,
                           expires_at: Optional[datetime] = None,
                           created_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a download file record"""
        with self.get_session() as session:
            download_file = DownloadFile(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=file_path,
                file_size_bytes=file_size_bytes,
                expires_at=expires_at,
                created_by=created_by
            )
            session.add(download_file)
            session.flush()
            session.refresh(download_file)
            return download_file.to_dict()
    
    def get_download_file(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get download file by ID"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            return file.to_dict() if file else None
    
    def list_download_files(self, status: Optional[str] = "available",
                          limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List download files"""
        with self.get_session() as session:
            query = session.query(DownloadFile)
            
            if status:
                query = query.filter(DownloadFile.status == status)
            
            query = query.order_by(DownloadFile.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [f.to_dict() for f in query.all()]
    
    def update_download_file(self, file_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update download file"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            
            if not file:
                return None
            
            for key, value in kwargs.items():
                if hasattr(file, key):
                    setattr(file, key, value)
            
            session.flush()
            session.refresh(file)
            return file.to_dict()
    
    def increment_download_count(self, file_id: str) -> None:
        """Increment download count"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            if file:
                file.download_count += 1
                file.last_downloaded_at = datetime.now(timezone.utc)

    # ── Connection operations ──────────────────────────────────────────────────

    def create_connection(self, name: str, connection_type: str,
                         config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new connection — encrypts sensitive config fields at rest."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = Connection(
                name=name,
                connection_type=connection_type,
                config=encrypt_config(config),
            )
            session.add(connection)
            session.flush()
            session.refresh(connection)
            d = connection.to_dict()
            d["config"] = mask_config(config)   # return masked to caller
            return d

    def get_connection(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials MASKED — safe for API responses to the browser."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = mask_config(decrypt_config(d["config"]))
            return d

    def get_connection_raw(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials DECRYPTED — for internal engine/connector use only.
        Never return this directly to API clients."""
        from core.crypto import decrypt_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = decrypt_config(d["config"])
            return d

    def list_connections(self, active_only: bool = True,
                        limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List connections with credentials masked."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            q = session.query(Connection)
            if active_only:
                q = q.filter(Connection.is_active == True)
            q = q.order_by(Connection.created_at.desc()).limit(limit).offset(offset)
            result = []
            for c in q.all():
                d = c.to_dict()
                d["config"] = mask_config(decrypt_config(d["config"]))
                result.append(d)
            return result

    def update_connection(self, connection_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a connection — re-encrypts config if provided."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return None
            # Encrypt config before persisting
            if "config" in kwargs and isinstance(kwargs["config"], dict):
                kwargs["config"] = encrypt_config(kwargs["config"])
            for key, value in kwargs.items():
                if hasattr(connection, key):
                    setattr(connection, key, value)
            connection.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(connection)
            return connection.to_dict()

    def delete_connection(self, connection_id: int, soft_delete: bool = True) -> bool:
        """Delete a connection."""
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return False
            if soft_delete:
                connection.is_active = False
                connection.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(connection)
            return True

    # ── Report operations ──────────────────────────────────────────────────────

    def create_report(self, **kwargs) -> Dict[str, Any]:
        """Create a new parametric report."""
        with self.get_session() as session:
            report = Report(**kwargs)
            session.add(report)
            session.flush()
            session.refresh(report)
            return report.to_dict()

    def get_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            return r.to_dict() if r else None

    def list_reports(self, active_only: bool = True,
                     limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Report)
            if active_only:
                q = q.filter(Report.is_active == True)
            rows = q.order_by(Report.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def update_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(r, key):
                    setattr(r, key, value)
            r.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def delete_report(self, report_id: int, soft_delete: bool = True) -> bool:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return False
            if soft_delete:
                r.is_active = False
            else:
                session.delete(r)
            return True

    def increment_report_execution(self, report_id: int):
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if r:
                r.execution_count = (r.execution_count or 0) + 1
                r.last_executed_at = datetime.now(timezone.utc)

    # ── Schedule operations ────────────────────────────────────────────────────

    def create_schedule(self, **kwargs) -> Dict[str, Any]:
        """Create a new schedule record."""
        with self.get_session() as session:
            s = Schedule(**kwargs)
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_schedule(self, schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            return s.to_dict() if s else None

    def list_schedules(self, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Schedule)
            if active_only:
                q = q.filter(Schedule.is_active == True)
            rows = q.order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def list_all_schedules(self, limit: int = 500, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(Schedule).order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def update_schedule(self, schedule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            s.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    def increment_schedule_run_count(self, schedule_id: int):
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if s:
                s.run_count = (s.run_count or 0) + 1

    def list_downloads_enriched(
        self,
        status: Optional[str] = "available",
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Returns download files enriched with linked execution metadata.

        Single LEFT JOIN query — no N+1 lookups.
        Extra fields added to each record:
          - duration_seconds  (execution completed_at - started_at)
          - total_rows        (rows written by the query engine)
          - format            ('csv' | 'excel' | 'json' derived from filename)
        """
        with self.get_session() as session:
            query = (
                session.query(DownloadFile, QueryExecution)
                .outerjoin(
                    QueryExecution,
                    DownloadFile.execution_id == QueryExecution.execution_id,
                )
            )
            if status:
                query = query.filter(DownloadFile.status == status)

            query = (
                query.order_by(DownloadFile.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = []
            for dl, ex in query.all():
                d = dl.to_dict()

                # Execution metadata
                if ex:
                    if ex.started_at and ex.completed_at:
                        d["duration_seconds"] = round(
                            (ex.completed_at - ex.started_at).total_seconds(), 2
                        )
                    else:
                        d["duration_seconds"] = None
                    d["total_rows"] = ex.total_rows or 0
                else:
                    d["duration_seconds"] = None
                    d["total_rows"] = None

                # Derive format from filename extension
                fname = (d.get("filename") or "").lower()
                if fname.endswith(".xlsx"):
                    d["format"] = "excel"
                elif fname.endswith(".json"):
                    d["format"] = "json"
                else:
                    d["format"] = "csv"

                result.append(d)

            return result

    # ── SQL Saved Queries (Trino / Snowflake / Databricks) ────────────────────

    def create_sql_query(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlSavedQuery record."""
        with self.get_session() as session:
            q = SqlSavedQuery(**kwargs)
            session.add(q)
            session.flush()
            return q.to_dict()

    def list_sql_queries(self, active_only: bool = True, limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL saved queries, newest first."""
        with self.get_session() as session:
            query = session.query(SqlSavedQuery)
            if active_only:
                query = query.filter(SqlSavedQuery.is_active == True)
            rows = query.order_by(SqlSavedQuery.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def get_sql_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL saved query by ID."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            return q.to_dict() if q else None

    def update_sql_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(q, key):
                    setattr(q, key, value)
            q.updated_at = datetime.now(timezone.utc)
            session.flush()
            return q.to_dict()

    def delete_sql_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return False
            if soft_delete:
                q.is_active = False
            else:
                session.delete(q)
            return True

    def increment_sql_query_execution(self, query_id: int):
        """Bump execution counter and last_executed_at timestamp."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if q:
                q.execution_count = (q.execution_count or 0) + 1
                q.last_executed_at = datetime.now(timezone.utc)

    # ── Query Cache operations ─────────────────────────────────────────────────

    def get_cache_entry(self, cache_key: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            return e.to_dict() if e else None

    def set_cache_entry(self, cache_key: str, file_path: str,
                        row_count: int = 0, file_size_bytes: int = 0,
                        expires_at: Optional[datetime] = None,
                        query_config: Optional[dict] = None) -> Dict[str, Any]:
        """Upsert a cache entry — safe for concurrent writers on the same key."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            # Try insert first; on PK conflict, update in place.
            try:
                e = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                # PK conflict — another thread inserted first; update instead.
                existing = session.query(QueryCacheEntry).filter(
                    QueryCacheEntry.cache_key == cache_key
                ).first()
                if existing:
                    existing.file_path = file_path
                    existing.row_count = row_count
                    existing.file_size_bytes = file_size_bytes
                    existing.expires_at = expires_at
                    existing.created_at = now
                    existing.query_config = query_config
                    session.flush()
                    return existing.to_dict()
                # Extremely unlikely: another thread deleted between our
                # failed insert and this query — just retry the insert.
                e2 = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_cache_entry(self, cache_key: str) -> bool:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            if not e:
                return False
            session.delete(e)
            return True

    def delete_expired_cache_entries(self) -> int:
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            expired = session.query(QueryCacheEntry).filter(
                QueryCacheEntry.expires_at != None,
                QueryCacheEntry.expires_at < now,
            ).all()
            count = len(expired)
            for e in expired:
                session.delete(e)
            return count

    def list_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(QueryCacheEntry).order_by(QueryCacheEntry.created_at.desc()).all()
            return [e.to_dict() for e in rows]

    # ── Partition Cache operations ────────────────────────────────────────────

    def get_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str = "fast") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(PartitionCache).filter(
                PartitionCache.connection_id == connection_id,
                PartitionCache.table_name == table_name,
                PartitionCache.scan_type == scan_type,
            ).first()
            return e.to_dict() if e else None

    def set_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str, partition_data: dict) -> Dict[str, Any]:
        """Upsert partition cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    scan_type=scan_type, partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(PartitionCache).filter(
                    PartitionCache.connection_id == connection_id,
                    PartitionCache.table_name == table_name,
                    PartitionCache.scan_type == scan_type,
                ).first()
                if existing:
                    existing.partition_data = partition_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    scan_type=scan_type, partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_partition_cache(self, connection_id: Optional[int] = None,
                               table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(PartitionCache)
            if connection_id is not None:
                q = q.filter(PartitionCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(PartitionCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_partition_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(PartitionCache).order_by(
                PartitionCache.updated_at.desc()
            ).all()
            return [e.to_dict() for e in rows]

    # ── Iceberg File Cache operations ────────────────────────────────────────

    def get_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(IcebergFileCache).filter(
                IcebergFileCache.connection_id == connection_id,
                IcebergFileCache.table_name == table_name,
                IcebergFileCache.filters_hash == filters_hash,
            ).first()
            return e.to_dict() if e else None

    def set_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str, file_list: list) -> Dict[str, Any]:
        """Upsert Iceberg file cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(IcebergFileCache).filter(
                    IcebergFileCache.connection_id == connection_id,
                    IcebergFileCache.table_name == table_name,
                    IcebergFileCache.filters_hash == filters_hash,
                ).first()
                if existing:
                    existing.file_list = file_list
                    existing.file_count = len(file_list)
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_iceberg_file_cache(self, connection_id: Optional[int] = None,
                                   table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergFileCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    # ── Schema cache ────────────────────────────────────────────────────────────

    def get_schema_cache(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.connection_id == connection_id,
                SchemaCache.table_name == table_name,
            ).first()
            return e.to_dict() if e else None

    def set_schema_cache(self, connection_id: int, table_name: str,
                         table_format: str, schema_data: dict) -> Dict[str, Any]:
        """Upsert schema cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(SchemaCache).filter(
                    SchemaCache.connection_id == connection_id,
                    SchemaCache.table_name == table_name,
                ).first()
                if existing:
                    existing.table_format = table_format
                    existing.schema_data = schema_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_schema_cache(self, connection_id: Optional[int] = None,
                            table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(SchemaCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_schema_cache_entries(self, connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            return [e.to_dict() for e in q.order_by(SchemaCache.updated_at.desc()).all()]

    # ── Execution history cleanup ──────────────────────────────────────────────

    def cleanup_old_executions(self, retention_days: int = 30):
        """Delete QueryExecution records older than retention_days.

        Only removes records whose status is terminal (completed / failed /
        cancelled) and whose started_at is older than the retention window.
        Pending / processing rows are never touched (they may still be running).

        Returns (count, [output_file_paths]) so the caller can delete the files.
        """
        import datetime as _dt
        cutoff = datetime.now(timezone.utc) - _dt.timedelta(days=retention_days)
        with self.get_session() as session:
            terminal = ("completed", "failed", "cancelled")
            expired_rows = (
                session.query(QueryExecution)
                .filter(
                    QueryExecution.status.in_(terminal),
                    QueryExecution.started_at < cutoff,
                )
                .all()
            )
            # Collect file paths BEFORE deleting rows (so we can unlink them)
            file_paths = [r.output_file for r in expired_rows if r.output_file]
            count = len(expired_rows)
            for row in expired_rows:
                session.delete(row)
            return count, file_paths

    def get_downloads_size_bytes(self) -> int:
        """Return total file_size_bytes of available download records."""
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .all()
            )
            return sum(r.file_size_bytes or 0 for r in rows)

    # ── Audit log ─────────────────────────────────────────────────────────────

    def audit(self, username: str, action: str,
              resource_type: str = None, resource_id: str = None,
              ip_address: str = None, user_agent: str = None,
              details: dict = None) -> None:
        """Append an immutable audit entry (fire-and-forget, never raises)."""
        try:
            with self.get_session() as session:
                session.add(AuditLog(
                    username=username or "unknown",
                    action=action,
                    resource_type=resource_type,
                    resource_id=str(resource_id) if resource_id is not None else None,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    details=details,
                ))
        except Exception:
            pass  # audit must never break the main flow

    def list_audit_log(self, username: str = None, action: str = None,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries newest-first, with optional filters."""
        with self.get_session() as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def mark_expired_downloads(self) -> int:
        """Mark download records as 'expired' where expires_at < now.

        Returns number of records marked expired.
        """
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(
                    DownloadFile.status == "available",
                    DownloadFile.expires_at != None,
                    DownloadFile.expires_at < now,
                )
                .all()
            )
            for row in rows:
                row.status = "expired"
            return len(rows)

    def expire_oldest_downloads(self, keep_count: int) -> int:
        """Mark oldest download records as expired until only keep_count remain.

        Returns number of records expired.
        """
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .order_by(DownloadFile.created_at.asc())
                .all()
            )
            to_expire = max(0, len(rows) - keep_count)
            for row in rows[:to_expire]:
                row.status = "expired"
            return to_expire

    # ── Query Version operations ───────────────────────────────────────────────

    def create_query_version(self, query_id: int, name: str = None, description: str = None,
                              query_config: dict = None, changed_by: str = None,
                              change_note: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Get next version number
            last = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .first())
            next_ver = (last.version_number + 1) if last else 1
            v = QueryVersion(
                query_id=query_id, version_number=next_ver,
                name=name, description=description, query_config=query_config,
                changed_by=changed_by, change_note=change_note,
            )
            session.add(v)
            session.flush()
            session.refresh(v)
            return v.to_dict()

    def list_query_versions(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .all())
            return [v.to_dict() for v in rows]

    def get_query_version(self, version_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            v = session.query(QueryVersion).filter(QueryVersion.id == version_id).first()
            return v.to_dict() if v else None

    # ── Query Share operations ─────────────────────────────────────────────────

    def create_share(self, query_id: int, created_by: str = None,
                     expires_at: Optional[datetime] = None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = QueryShare(
                token=_uuid.uuid4().hex,
                query_id=query_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            return s.to_dict() if s else None

    def increment_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    def list_shares(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(QueryShare)
                    .filter(QueryShare.query_id == query_id, QueryShare.is_active == True)
                    .order_by(QueryShare.created_at.desc())
                    .all())
            return [s.to_dict() for s in rows]

    def deactivate_share(self, token: str) -> bool:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if not s:
                return False
            s.is_active = False
            return True

    # ── Dashboard share operations ─────────────────────────────────────────────

    def create_dashboard_share(self, dashboard_id: int, created_by: str = None,
                               expires_at=None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = DashboardShare(
                token=_uuid.uuid4().hex,
                dashboard_id=dashboard_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_dashboard_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            return s.to_dict() if s else None

    def increment_dashboard_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    # ── Dashboard operations ───────────────────────────────────────────────────

    def create_dashboard(self, name: str, description: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = Dashboard(name=name, description=description, created_by=created_by)
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def get_dashboard(self, dashboard_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id, Dashboard.is_active == True).first()
            return d.to_dict() if d else None

    def list_dashboards(self, created_by: str = None, is_admin: bool = True) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Dashboard).filter(Dashboard.is_active == True)
            if not is_admin and created_by:
                q = q.filter(Dashboard.created_by == created_by)
            rows = q.order_by(Dashboard.updated_at.desc()).all()
            return [d.to_dict() for d in rows]

    def update_dashboard(self, dashboard_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return None
            for k, v in kwargs.items():
                if hasattr(d, k):
                    setattr(d, k, v)
            d.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def delete_dashboard(self, dashboard_id: int) -> bool:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return False
            d.is_active = False
            return True

    # ── Dashboard Widget operations ────────────────────────────────────────────

    def create_widget(self, dashboard_id: int, widget_type: str, source_id: int,
                      title: str = None, layout: dict = None, chart_type: str = "grid",
                      chart_config: dict = None, param_values: dict = None) -> Dict[str, Any]:
        with self.get_session() as session:
            w = DashboardWidget(
                dashboard_id=dashboard_id, widget_type=widget_type, source_id=source_id,
                title=title, layout=layout or {"x": 0, "y": 0, "w": 6, "h": 4},
                chart_type=chart_type, chart_config=chart_config, param_values=param_values,
            )
            session.add(w)
            session.flush()
            session.refresh(w)
            # Touch parent dashboard updated_at
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)
            return w.to_dict()

    def list_widgets(self, dashboard_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(DashboardWidget)
                    .filter(DashboardWidget.dashboard_id == dashboard_id)
                    .order_by(DashboardWidget.id)
                    .all())
            return [w.to_dict() for w in rows]

    def update_widget(self, widget_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return None
            for k, v in kwargs.items():
                if hasattr(w, k):
                    setattr(w, k, v)
            w.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(w)
            return w.to_dict()

    def delete_widget(self, widget_id: int) -> bool:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return False
            session.delete(w)
            return True

    def update_widget_layouts(self, dashboard_id: int, layouts: list) -> None:
        """Bulk update widget positions from react-grid-layout onChange."""
        with self.get_session() as session:
            layout_map = {str(item["i"]): item for item in layouts}
            widgets = (session.query(DashboardWidget)
                       .filter(DashboardWidget.dashboard_id == dashboard_id)
                       .all())
            for w in widgets:
                if str(w.id) in layout_map:
                    item = layout_map[str(w.id)]
                    w.layout = {"x": item.get("x", 0), "y": item.get("y", 0),
                                "w": item.get("w", 6), "h": item.get("h", 4)}
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)
