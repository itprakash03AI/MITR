"""
Cross-process notification queue backed by the ``pending_notifications`` table.

Writer side (scheduler_worker):  enqueue(session_factory, payload)
Reader side (FastAPI):           poll(session_factory) → list[(id, payload)]
                                 mark_delivered(session_factory, ids)
                                 cleanup_old(session_factory)

Both sides import this module — it is deliberately stateless (no globals).
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)


def enqueue(session_factory, payload: Dict[str, Any]) -> int:
    """Insert a notification into the queue.  Returns the row id."""
    from core.database import PendingNotification

    session = session_factory()
    try:
        row = PendingNotification(payload=payload)
        session.add(row)
        session.commit()
        return row.id
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def poll(session_factory, limit: int = 50) -> List[Tuple[int, Dict[str, Any]]]:
    """Fetch up to *limit* undelivered notifications ordered by id."""
    from core.database import PendingNotification

    session = session_factory()
    try:
        rows = (
            session.query(PendingNotification)
            .filter(PendingNotification.delivered == False)  # noqa: E712
            .order_by(PendingNotification.id)
            .limit(limit)
            .all()
        )
        return [(r.id, r.payload) for r in rows]
    finally:
        session.close()


def mark_delivered(session_factory, ids: List[int]) -> None:
    """Mark the given notification ids as delivered."""
    if not ids:
        return
    from core.database import PendingNotification

    session = session_factory()
    try:
        now = datetime.now(timezone.utc)
        session.query(PendingNotification).filter(
            PendingNotification.id.in_(ids)
        ).update(
            {"delivered": True, "delivered_at": now},
            synchronize_session=False,
        )
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def cleanup_old(session_factory, max_age_hours: int = 1) -> int:
    """Delete delivered notifications older than *max_age_hours*.  Returns count deleted."""
    from core.database import PendingNotification

    session = session_factory()
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        count = (
            session.query(PendingNotification)
            .filter(
                PendingNotification.delivered == True,  # noqa: E712
                PendingNotification.delivered_at < cutoff,
            )
            .delete(synchronize_session=False)
        )
        session.commit()
        return count
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
