"""QueryStudio — Enterprise Parquet Query Engine."""

__version__ = "1.0.0"
