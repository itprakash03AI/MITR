"""Allow ``python -m querystudio <command>``."""

from querystudio.cli import main

main()
