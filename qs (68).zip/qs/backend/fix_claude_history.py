import json, shutil, sys
from pathlib import Path

def strip_images(jsonl_path: str):
    path = Path(jsonl_path)
    backup = path.with_suffix(".jsonl.bak")
    
    # Backup first
    shutil.copy2(path, backup)
    print(f"✅ Backup saved: {backup}")

    cleaned_lines = []
    images_removed = 0

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                cleaned_lines.append(line)
                continue

            # Walk message content and strip image blocks
            for role in ["message", "assistant", "human"]:
                msg = entry.get(role, {})
                content = msg.get("content", [])
                if isinstance(content, list):
                    before = len(content)
                    msg["content"] = [
                        block for block in content
                        if not (isinstance(block, dict) and block.get("type") == "image")
                    ]
                    images_removed += before - len(msg["content"])

            cleaned_lines.append(json.dumps(entry))

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(cleaned_lines) + "\n")

    print(f"✅ Done — removed {images_removed} image blocks")
    print(f"✅ Text history fully preserved")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python fix_claude_history.py <path_to_file.jsonl>")
    else:
        strip_images(sys.argv[1])