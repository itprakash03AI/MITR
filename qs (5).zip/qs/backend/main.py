"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
import time as _time
import uuid
import logging
from pathlib import Path
import asyncio
import os
import sys
from dotenv import load_dotenv

# Windows ProactorEventLoop raises spurious OSError on socket shutdown — switch
# to SelectorEventLoop which avoids this.  Must be set before any event loop starts.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# ── Graceful shutdown on Windows + Linux ──────────────────────────────────────
# Do NOT override SIGINT/SIGTERM with os._exit() — that kills the process
# without releasing sockets, leaving port 8000 in TIME_WAIT and causing
# "Only one usage of each socket address" on the next restart.
# Let uvicorn handle SIGINT/SIGTERM naturally; the executor is shut down
# in the FastAPI shutdown event handler below.

from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
from api.sql_query_api import router as sql_router, set_sql_dependencies
from api.reports_api import router as reports_router, set_report_dependencies
from api.schedules_api import router as schedules_router, set_schedule_dependencies
from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
# Load environment variables
load_dotenv()

from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType
from core.s3_storage import S3Config
from core.database import DatabaseManager
from core.websocket_manager import WebSocketManager
from core.connection_manager import ConnectionManager as ConnManager, _normalize_path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ── Load centralised config (config.json + env var overrides) ─────────────────
from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg

# Ensure all data directories exist at startup
_paths.data_dir.mkdir(parents=True, exist_ok=True)
_paths.parquet_dir.mkdir(parents=True, exist_ok=True)
_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
_paths.upload_dir.mkdir(parents=True, exist_ok=True)

_DATA_DIR = _paths.data_dir   # kept for backward-compat references below
_DB_URL   = _db_cfg.db_url   # sqlite or oracle depending on config.json / env vars

# Initialize FastAPI app
app = FastAPI(
    title="QueryStudio API",
    description="Enterprise-grade query engine — S3, Iceberg, Snowflake, Trino, Databricks",
    version="2.0.0"
)

# GZip compression (~70% payload reduction for JSON responses)
app.add_middleware(GZipMiddleware, minimum_size=1024)

# CORS middleware — origins/methods/headers driven by config.json / env vars
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_cfg.allow_origins,
    allow_credentials=True,
    allow_methods=_cors_cfg.allow_methods,
    allow_headers=_cors_cfg.allow_headers,
)

# Thread pool for CPU-bound query execution
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)
app.include_router(data_grid_router)
app.include_router(sql_router)
app.include_router(reports_router)
app.include_router(schedules_router)
app.include_router(dashboards_router)

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL')
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# Per-execution cancellation registry
import threading as _threading
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency tracking
_user_query_counts: dict = {}    # username → int (active query count)
_user_query_lock = _threading.Lock()


# ── Active Directory / Auth helpers ───────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    password: str


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none" → always returns a guest user (no login required)
    - auth.type = "ad"   → requires Authorization: Basic/Bearer <base64(user:pass)>
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type != "ad":
        return {"username": "guest", "is_admin": True, "groups": []}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid AD credentials")
    return user


@app.post("/auth/login")
async def login(req: _LoginRequest):
    """
    Authenticate against Active Directory (or return guest info when auth is disabled).
    Returns user info including group memberships and admin flag.
    """
    from core.ad_auth import authenticate_user
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return user


@app.get("/auth/me")
async def whoami(request: Request):
    """Return the current user's identity (or guest when auth is disabled)."""
    return _get_current_user(request)


@app.get("/auth/config")
async def auth_config():
    """Return auth configuration visible to the frontend (type only — no secrets)."""
    return {"type": _auth_cfg.type, "domain": _auth_cfg.ad_domain}


# Pydantic Models
class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    endpoint_url: Optional[str] = None


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|contains)$")
    value: Any


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None


_ALL_CONN_TYPES = "^(s3|local|trino|starburst|snowflake|databricks|oracle)$"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# Helper functions
def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how
            )
            for j in config.joins
        ]
    
    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]
    
    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]
    
    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by
    )


async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest"):
    """Background task for query execution"""
    run_engine = active_engine or engine
    cancel_event = _threading.Event()
    _cancellation_flags[execution_id] = cancel_event
    try:
        db_manager.update_execution(execution_id, status="processing")
        
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            if is_terminal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet():
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0
            pq_writer = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                for chunk_df in run_engine.execute_query(query_config):
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    table = _pa.Table.from_pandas(chunk_df, preserve_index=False)
                    if pq_writer is None:
                        pq_writer = _pq.ParquetWriter(fh, table.schema, compression="snappy")
                    pq_writer.write_table(table)
                    total_rows += len(chunk_df)
                    chunks_processed += 1
            finally:
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # Ensure an empty file exists for 0-row results so downstream
                # readers don't get a FileNotFoundError.
                if total_rows == 0 and not output_file.exists():
                    output_file.touch()
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed"}

        _timeout = _qe_cfg.query_timeout_seconds
        try:
            stats = await asyncio.wait_for(
                loop.run_in_executor(query_executor, _exec_to_parquet),
                timeout=_timeout if _timeout > 0 else None,
            )
        except asyncio.TimeoutError:
            cancel_event.set()   # stop the thread at next chunk boundary
            raise TimeoutError(f"Query exceeded timeout of {_timeout}s")

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — no file copy, cache points to same parquet
        try:
            from core.query_cache import make_cache_key, store_result
            _ck = make_cache_key(query_config.__dict__ if hasattr(query_config, '__dict__') else {})
            if output_file.exists():
                store_result(_ck, output_file, {}, row_count=stats.get("total_rows", 0), copy=False)
        except Exception:
            pass

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        logger.info(f"Query execution completed: {execution_id}")
        
    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}")

        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )

        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        _cancellation_flags.pop(execution_id, None)
        _running_tasks.pop(execution_id, None)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 1) - 1)


# ── Audit helper ──────────────────────────────────────────────────────────────

def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        db_manager.audit(username, action, resource_type=resource_type,
                         resource_id=resource_id, ip_address=ip,
                         user_agent=ua[:500] if ua else None, details=details)
    except Exception:
        pass


# API Endpoints

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Parquet Query Engine API with S3",
        "version": "2.0.0",
        "status": "operational",
        "features": ["local_storage", "s3_storage", "websocket", "query_builder"]
    }


@app.get("/health")
async def health_check():
    """Health check — DB connectivity, disk space, active queries."""
    import shutil as _shutil

    # Database ping
    db_ok = False
    try:
        db_manager.get_execution("__health_probe__")   # returns None, never raises
        db_ok = True
    except Exception:
        pass

    # Disk usage for data directory
    try:
        _du = _shutil.disk_usage(str(_paths.data_dir))
        disk_free_gb  = round(_du.free  / (1024 ** 3), 2)
        disk_used_pct = round(_du.used  / _du.total * 100, 1)
        disk_warn     = disk_free_gb < 5.0
    except Exception:
        disk_free_gb = disk_used_pct = -1
        disk_warn = False

    # S3 connectivity (non-blocking, best-effort)
    s3_status = "not_configured"
    if engine.s3_handler:
        try:
            s3_status = "connected" if engine.s3_handler.test_connection().get("connected") else "error"
        except Exception:
            s3_status = "error"

    active_queries = len([t for t in _running_tasks.values() if not t.done()])
    overall = "healthy" if db_ok and not disk_warn else "degraded"

    return {
        "status":    overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database":  {"ok": db_ok},
        "disk":      {"free_gb": disk_free_gb, "used_pct": disk_used_pct, "warning": disk_warn},
        "queries":   {"active": active_queries, "max_workers": _qe_cfg.max_workers,
                      "per_user_limit": _qe_cfg.max_concurrent_per_user},
        "s3":        {"status": s3_status},
    }


# S3 Configuration Endpoints

@app.post("/api/s3/configure")
async def configure_s3(config: S3ConfigModel):
    """Configure or update S3 connection"""
    try:
        s3_config = S3Config(
            bucket_name=config.bucket_name,
            region_name=config.region_name,
            aws_access_key_id=config.aws_access_key_id,
            aws_secret_access_key=config.aws_secret_access_key,
            endpoint_url=config.endpoint_url
        )
        
        engine.set_s3_config(s3_config)
        
        # Test connection
        test_result = engine.s3_handler.test_connection()
        
        return {
            "message": "S3 configured successfully",
            "connection_test": test_result
        }
    except Exception as e:
        logger.error(f"Error configuring S3: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/test")
async def test_s3_connection():
    """Test S3 connection"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        result = engine.s3_handler.test_connection()
        return result
    except Exception as e:
        logger.error(f"Error testing S3 connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/folders")
async def list_s3_folders(prefix: str = ""):
    """List folders in S3 bucket"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        folders = engine.list_s3_folders(prefix)
        return folders
    except Exception as e:
        logger.error(f"Error listing S3 folders: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/files")
async def list_s3_files(folder: str = ""):
    """List parquet files in S3 folder"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        files = engine.list_s3_files(folder)
        return files
    except Exception as e:
        logger.error(f"Error listing S3 files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# File Management Endpoints

@app.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = ""):
    """List all available parquet files from local and/or S3"""
    try:
        files = engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str):
    """Get schema information for a specific file"""
    try:
        schema = engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error(f"Error getting file schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...), _user: dict = Depends(_get_current_user)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")
        
        file_path = Path(engine.base_path) / file.filename
        
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"File uploaded: {file.filename}")
        
        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Query Management Endpoints (same as before)
@app.post("/api/queries")
async def create_query(req: Request, request: SaveQueryRequest, _user: dict = Depends(_get_current_user)):
    """Save a new query"""
    try:
        # Do NOT validate file existence here — files may be on S3 or remote paths
        # that aren't accessible from the server at save time. Validation runs at
        # execution time when the engine actually needs the files.
        query = db_manager.create_query(
            name=request.name,
            description=request.description,
            query_config=request.query_config.model_dump(),
            created_by=request.created_by
        )
        _audit(_user, "save_query", req, "query", query["id"], {"name": request.name})
        logger.info(f"Query saved: {query['id']}")
        return query
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0,
                       request: Request = None):
    """List saved queries — filtered by owner when auth=ad and user is not admin."""
    try:
        queries = db_manager.list_queries(active_only=active_only, limit=limit, offset=offset)
        # Row-level security: non-admin AD users only see their own queries
        if _auth_cfg.type == "ad" and request:
            user = _get_current_user(request)
            if not user.get("is_admin"):
                queries = [q for q in queries if q.get("created_by") == user.get("username")]
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks, _user: dict = Depends(_get_current_user)):
    """Execute a query (saved or ad-hoc)"""
    try:
        if request.query_id:
            saved_query = db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.query_config:
            query_config_model = request.query_config
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id or query_config must be provided"
            )

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except Exception:
            pass   # non-fatal — proceed with original filters

        # Resolve engine: use connection's local path if connection_id provided
        active_engine = engine
        if request.connection_id:
            conn_record = db_manager.get_connection(request.connection_id)
            if conn_record and conn_record.get('connection_type') == 'local':
                local_path = str(_normalize_path(conn_record['config'].get('base_path', './data/parquet')))
                active_engine = ParquetQueryEngine(
                    base_path=local_path,
                    chunk_size=int(os.getenv('PARQUET_CHUNK_SIZE', 100000)),
                )

        engine_config = convert_query_config_to_engine(query_config_model)

        # Run validate_query off the event loop — it reads file schemas from disk
        # and can take 100 ms – 2 s per file, which would stall all other requests.
        _loop = asyncio.get_running_loop()
        validation = await _loop.run_in_executor(
            query_executor, active_engine.validate_query, engine_config
        )
        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )

        # ── Query result cache check ──────────────────────────────────────────
        # Only cache ad-hoc / saved_query executions (not custom connection queries)
        if not request.connection_id:
            from core.query_cache import make_cache_key, get_cached_result
            _cache_key = make_cache_key(query_config_model.model_dump())
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                db_manager.update_execution(execution_id, status="completed",
                                            output_file=str(_cached_path))
                db_manager.create_download_file(
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_path.stat().st_size,
                    expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                )
                await ws_manager.broadcast({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # Per-user concurrent query limit
        _username = _user.get("username", "guest") if _user else "guest"
        _max_per_user = _qe_cfg.max_concurrent_per_user
        with _user_query_lock:
            _active = _user_query_counts.get(_username, 0)
            if _active >= _max_per_user:
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                           "Wait for one to complete or cancel it first."
                )
            _user_query_counts[_username] = _active + 1

        execution_id = str(uuid.uuid4())
        execution = db_manager.create_execution(
            execution_id=execution_id,
            query_id=request.query_id,
            query_config=query_config_model.model_dump(),
            executed_by=request.executed_by or _username
        )

        # Use create_task (not background_tasks) so queries run truly concurrently.
        # background_tasks serializes tasks; create_task schedules them in parallel.
        _task = asyncio.create_task(
            execute_query_background(
                execution_id,
                engine_config,
                request.query_id,
                active_engine,
                executed_by=_username,
            )
        )
        _running_tasks[execution_id] = _task
        _task.add_done_callback(lambda t: _running_tasks.pop(execution_id, None))
        
        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0):
    """List available downloads"""
    try:
        downloads = db_manager.list_download_files(status=status, limit=limit, offset=offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads/{file_id}")
async def download_file(file_id: str):
    """Download a file"""
    try:
        download_info = db_manager.get_download_file(file_id)
        
        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")
        
        file_path = Path(download_info["file_path"])
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        db_manager.increment_download_count(file_id)
        
        logger.info(f"File downloaded: {file_id}")
        
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type="text/csv"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 1. GET /api/queries/{query_id}
#    ReportPage calls api.getSavedQuery(id) to load a report by ID
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}")
async def get_query(query_id: int):
    """Get a single saved query by ID"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 2. DELETE /api/queries/{query_id}
#    SavedQueries page delete button
#    Uses db_manager.delete_query() — soft delete, sets is_active=False
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, req: Request, _user: dict = Depends(_get_current_user)):
    """Soft-delete a saved query (sets is_active=False)"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        db_manager.delete_query(query_id, soft_delete=True)
        _audit(_user, "delete_query", req, "query", query_id, {"name": query.get("name")})
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# PUT /api/queries/{query_id}  — update + version snapshot
# ─────────────────────────────────────────────────────────────────────────────
class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None


@app.put("/api/queries/{query_id}")
async def update_query(query_id: int, request: UpdateQueryRequest,
                       _user: dict = Depends(_get_current_user)):
    """Update a saved query — auto-saves a version snapshot before changes."""
    try:
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only update their own queries
        if _auth_cfg.type == "ad" and not _user.get("is_admin"):
            if existing.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        # Snapshot before change
        db_manager.create_query_version(
            query_id=query_id,
            name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"],
            changed_by=_user.get("username"), change_note=request.change_note,
        )
        updates = {}
        if request.name is not None:        updates["name"] = request.name
        if request.description is not None: updates["description"] = request.description
        if request.query_config is not None:
            updates["query_config"] = request.query_config.model_dump()
        result = db_manager.update_query(query_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Version History endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}/versions")
async def list_query_versions(query_id: int, _user: dict = Depends(_get_current_user)):
    try:
        return db_manager.list_query_versions(query_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/queries/{query_id}/versions/{version_id}/restore")
async def restore_query_version(query_id: int, version_id: int,
                                _user: dict = Depends(_get_current_user)):
    try:
        v = db_manager.get_query_version(version_id)
        if not v or v["query_id"] != query_id:
            raise HTTPException(status_code=404, detail="Version not found")
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # Save current state as a version before restoring
        db_manager.create_query_version(
            query_id=query_id, name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"], changed_by=_user.get("username"),
            change_note=f"Auto-saved before restore to v{v['version_number']}",
        )
        db_manager.update_query(query_id, name=v["name"], description=v["description"],
                                query_config=v["query_config"])
        return {"message": f"Restored to version {v['version_number']}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Query Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/queries/{query_id}/share")
async def share_query(query_id: int, request: ShareQueryRequest,
                      _user: dict = Depends(_get_current_user)):
    q = db_manager.get_query(query_id)
    if not q:
        raise HTTPException(status_code=404, detail="Query not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_share(query_id, _user.get("username"), expires_at)
    return share


@app.get("/api/queries/{query_id}/shares")
async def list_query_shares(query_id: int, _user: dict = Depends(_get_current_user)):
    return db_manager.list_shares(query_id)


@app.delete("/api/queries/{query_id}/shares/{token}")
async def revoke_share(query_id: int, token: str, _user: dict = Depends(_get_current_user)):
    db_manager.deactivate_share(token)
    return {"message": "Share revoked"}


# PUBLIC endpoint — NO auth (accessible by anyone with the link)
@app.get("/api/shared/{token}")
async def get_shared_query(token: str):
    share = db_manager.get_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception:
            pass
    db_manager.increment_share_access(token)
    q = db_manager.get_query(share["query_id"])
    if not q:
        raise HTTPException(status_code=404, detail="Query no longer exists")
    return {"query": q, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/dashboards/{dashboard_id}/share")
async def share_dashboard(dashboard_id: int, request: ShareDashboardRequest,
                          _user: dict = Depends(_get_current_user)):
    d = db_manager.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_dashboard_share(dashboard_id, _user.get("username"), expires_at)
    return share


@app.get("/api/shared-dashboard/{token}")
async def get_shared_dashboard(token: str):
    """Public endpoint — no auth required."""
    share = db_manager.get_dashboard_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception:
            pass
    db_manager.increment_dashboard_share_access(token)
    d = db_manager.get_dashboard(share["dashboard_id"])
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard no longer exists")
    widgets = db_manager.list_widgets(share["dashboard_id"])
    return {"dashboard": d, "widgets": widgets, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Admin — Audit log endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/admin/audit-log")
async def get_audit_log(
    username: Optional[str] = None,
    action:   Optional[str] = None,
    limit:    int = 200,
    offset:   int = 0,
    _user: dict = Depends(_get_current_user),
):
    """Return audit log entries (admin only). Filterable by username and action."""
    if _auth_cfg.type == "ad" and not (_user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return db_manager.list_audit_log(username=username, action=action,
                                     limit=min(limit, 1000), offset=offset)


# ─────────────────────────────────────────────────────────────────────────────
# Cache management endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/cache/stats")
async def get_cache_stats(_user: dict = Depends(_get_current_user)):
    from core.query_cache import get_stats
    return get_stats()


@app.delete("/api/cache")
async def clear_cache(_user: dict = Depends(_get_current_user)):
    from core.query_cache import cleanup_expired
    count = cleanup_expired()
    return {"message": f"Removed {count} expired cache entries"}


@app.post("/api/webhooks/test")
async def test_webhook_url(body: dict, _user: dict = Depends(_get_current_user)):
    """Test a webhook URL by sending a sample notification."""
    url = body.get("url", "")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    from core.webhook_service import test_webhook
    return test_webhook(url)


# ─────────────────────────────────────────────────────────────────────────────
# 3. DELETE /api/downloads/{file_id}
#    Downloads page delete button
#    Uses update_download_file() to set status='deleted', removes file from disk
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str, _user: dict = Depends(_get_current_user)):
    """Mark a download as deleted and remove from disk"""
    try:
        download = db_manager.get_download_file(file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")

        # Remove file from disk if it exists
        file_path = Path(download["file_path"])
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        db_manager.update_download_file(file_id, status="deleted")

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 4. GET /api/executions
#    ExecutionHistory component — list recent executions
#    Uses list_executions(limit, offset, status) — all params optional
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions")
async def list_executions(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = None
):
    """List recent query executions"""
    try:
        executions = db_manager.list_executions(
            limit=limit,
            offset=offset,
            status=status if status else None
        )
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 5. GET /api/executions/{execution_id}
#    Single execution detail — used by ExecutionHistory detail view
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str):
    """Get a single execution record by ID"""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 6. GET /api/executions/{execution_id}/status
#    ReportPage polls this every 2 seconds to know when query finishes
#    Uses get_execution() — already tracked by execute_query_background()
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str):
    """
    Get status of an execution — polled by ReportPage.
    Returns: { execution_id, status, total_rows, started_at, completed_at, error_message }
    status values: pending | processing | completed | failed
    """
    try:
        execution = db_manager.get_execution(execution_id)

        if not execution:
            # Not in DB yet (just started) — check downloads as fallback
            downloads = db_manager.list_download_files(status="available", limit=500, offset=0)
            match = next(
                (d for d in downloads if d.get("execution_id") == execution_id),
                None
            )
            if match:
                return {
                    "execution_id": execution_id,
                    "status": "completed",
                    "file_id": match["file_id"],
                    "filename": match["filename"],
                    "total_rows": None,
                }
            return {"execution_id": execution_id, "status": "pending"}

        return {
            "execution_id": execution_id,
            "status": execution.get("status", "unknown"),
            "total_rows": execution.get("total_rows"),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "error_message": execution.get("error_message"),
        }

    except Exception as e:
        logger.error(f"Error getting execution status {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: The data_grid_api router already adds these routes via include_router:
#   GET /api/executions/{execution_id}/results  (pagination)
#   GET /api/executions/{execution_id}/export   (csv/excel/json)
#   GET /api/executions/{execution_id}/stats    (column stats)
# ─────────────────────────────────────────────────────────────────────────────


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """
    Cancel a running execution.
    Works by:
      1. Setting the threading.Event — stops the worker thread after the current chunk.
      2. Cancelling the asyncio.Task — stops the coroutine waiting on run_in_executor.
      3. Marking the DB record as cancelled immediately.
    """
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # 1. Signal the worker thread to stop between chunks
        cancel_event = _cancellation_flags.get(execution_id)
        if cancel_event:
            cancel_event.set()
            logger.info(f"Set cancellation flag for execution {execution_id}")

        # 2. Cancel the asyncio task (stops it from waiting on the executor)
        task = _running_tasks.get(execution_id)
        if task and not task.done():
            task.cancel()
            logger.info(f"Cancelled asyncio task for execution {execution_id}")

        # 3. Mark as cancelled in DB immediately (don't wait for thread to stop)
        db_manager.update_execution(
            execution_id,
            status="cancelled",
            error_message="Cancelled by user"
        )

        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        db_manager.audit("system", "cancel_query", resource_type="execution",
                         resource_id=execution_id)
        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 8. FIX: Downloads page shows EVERY query execution
#
# ROOT CAUSE: execute_query_background() calls db_manager.create_download_file()
# after every execution, so ALL results appear in the Downloads page.
#
# Downloads should only show EXPLICIT exports (xlsx/json/csv the user requested).
#
# SOLUTION: In execute_query_background(), change create_download_file to use
# status="internal" instead of status="available":
#
#   db_manager.create_download_file(
#       file_id=file_id,
#       execution_id=execution_id,
#       filename=f"query_result_{execution_id}.csv",
#       file_path=str(output_file),
#       file_size_bytes=stats["file_size_bytes"],
#       expires_at=datetime.now(timezone.utc) + timedelta(days=7),
#       # ADD THIS:
#       created_by="internal"       # ← use created_by field to tag internal files
#   )
#
# Then in list_download_files, the Downloads page already filters by status="available"
# by default — internal results use status="available" but we mark created_by="internal".
#
# SIMPLEST FIX (no DB schema change needed):
# Change the Downloads page list_downloads route filter to exclude internal records:
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/exports")
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').
    """
    try:
        all_files = db_manager.list_download_files(status=status, limit=limit*3, offset=0)
        # Exclude internal auto-generated results
        exports = [f for f in all_files if f.get("created_by") != "internal"]
        return exports[:limit]
    except Exception as e:
        logger.error(f"Error listing exports: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    
# ─────────────────────────────────────────────────────────────────────────────
# Connection Manager Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/connections")
async def list_connections(active_only: bool = True):
    """List all connections"""
    try:
        return db_manager.list_connections(active_only=active_only)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections")
async def create_connection(request: ConnectionConfigModel, _user: dict = Depends(_get_current_user)):
    """Create a new connection"""
    try:
        return db_manager.create_connection(
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@app.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest):
    """Test a connection configuration without saving — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_type = request.connection_type
    conn_cfg  = dict(request.config)

    # When editing a saved connection the browser sends "***" for any sensitive
    # field the user did not change.  Substitute those placeholders with the
    # real (decrypted) values from the DB so the test uses valid credentials.
    if request.connection_id is not None:
        raw = db_manager.get_connection_raw(request.connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            for k, v in conn_cfg.items():
                if v == "***" and k in raw_cfg:
                    conn_cfg[k] = raw_cfg[k]

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_cfg)
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_cfg)
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int):
    """Get a specific connection"""
    conn = db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@app.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel, _user: dict = Depends(_get_current_user)):
    """Update an existing connection"""
    try:
        conn = db_manager.update_connection(
            connection_id,
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int, _user: dict = Depends(_get_current_user)):
    """Delete a connection"""
    try:
        success = db_manager.delete_connection(connection_id)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection and persist the result — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    # Fetch raw creds synchronously (fast SQLite read) before entering executor
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw['connection_type']

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_raw['config'])
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_raw['config'])

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(query_executor, _do)
        db_manager.update_connection(
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result.get('message', '')
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = ""):
    """List parquet files — runs in thread (S3/local IO can take seconds)."""
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.list_files, connection_id, folder
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str):
    """Get schema — runs in thread (parquet metadata read is blocking IO)."""
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.get_schema, connection_id, file_path
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Iceberg S3 Endpoints
# ─────────────────────────────────────────────────────────────────────────────

def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config."""
    import boto3
    cfg = conn_raw.get('config', {})
    kwargs = {
        'region_name': cfg.get('region_name', 'us-east-1'),
    }
    if cfg.get('aws_access_key_id'):
        kwargs['aws_access_key_id']     = cfg['aws_access_key_id']
        kwargs['aws_secret_access_key'] = cfg.get('aws_secret_access_key', '')
    if cfg.get('endpoint_url'):
        kwargs['endpoint_url'] = cfg['endpoint_url']
    return boto3.client('s3', **kwargs)


@app.get("/api/connections/{connection_id}/iceberg/tables")
async def list_iceberg_tables(connection_id: int, prefix: str = ""):
    """
    Scan an S3 prefix for Iceberg table directories — runs in thread (S3 listing is blocking).
    Returns list of {name, prefix, type='iceberg_table', path} dicts.
    """
    from core.iceberg_reader import list_iceberg_tables as _list_iceberg_tables
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']
    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        tables = _list_iceberg_tables(s3, bucket, prefix)
        return {"tables": tables, "bucket": bucket, "prefix": prefix}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error listing Iceberg tables: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/iceberg/files")
async def list_iceberg_files(
    connection_id: int,
    table_prefix: str,
    partition_filter: Optional[str] = None,   # JSON: [{"col":"business_date","op":"equals","val":"${today}"}]
):
    """
    Read an Iceberg table's metadata chain — runs in thread (Avro + S3 reads are blocking).
    Returns list of {key, name, path, size_bytes, last_modified, folder, type='parquet'}.

    Optional partition_filter (JSON array) enables server-side manifest pruning so only
    files for the relevant partition(s) are returned.  Date expressions (${today}, etc.)
    in filter values are resolved at request time.
    """
    from core.iceberg_reader import get_iceberg_data_files
    from core.date_resolver import resolve_filter_dates
    import json as _json

    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']

    pfilters = None
    if partition_filter:
        try:
            pfilters = resolve_filter_dates(_json.loads(partition_filter))
        except Exception:
            pass

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        files = get_iceberg_data_files(s3, bucket, table_prefix, partition_filters=pfilters)
        return {"files": files, "bucket": bucket, "table_prefix": table_prefix, "count": len(files)}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error reading Iceberg data files: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # Start APScheduler (non-fatal — server starts regardless)
    from core.scheduler import init_scheduler
    import threading as _threading

    def _start_scheduler():
        try:
            init_scheduler(db_manager, ws_manager, loop,
                           db_url=_DB_URL)
        except Exception as exc:
            logger.error("APScheduler startup failed (non-fatal): %s", exc)

    _threading.Thread(target=_start_scheduler, daemon=True).start()


@app.on_event("shutdown")
async def _shutdown():
    logger.info("Shutdown: draining %d in-flight queries (10 s grace)…", len(_running_tasks))
    # Signal all threads to stop at next chunk boundary
    for _ev in list(_cancellation_flags.values()):
        _ev.set()
    # Cancel all asyncio tasks
    _pending = [t for t in _running_tasks.values() if not t.done()]
    for t in _pending:
        t.cancel()
    if _pending:
        await asyncio.gather(*_pending, return_exceptions=True)

    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()
    query_executor.shutdown(wait=True, cancel_futures=True)


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        logger.warning("WebSocket connection closed unexpectedly: %s", e)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    await _handle_ws(websocket)


if __name__ == "__main__":
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    uvicorn.run(
        app,
        host=_server_cfg.host,
        port=_server_cfg.port,
        log_level=_server_cfg.log_level,
        workers=_server_cfg.workers,
    )
