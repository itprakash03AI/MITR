# Create simple test file
from fastapi import FastAPI
import uvicorn

app = FastAPI(title="Parquet Query Engine API - Simple Test")

@app.get("/")
def root():
    return {"status": "API is working!", "message": "Packages installed successfully"}

@app.get("/health")
def health():
    import sys
    return {
        "status": "healthy",
        "python_version": sys.version,
        "packages": ["fastapi", "uvicorn", "boto3", "sqlalchemy"]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)


