"""
Enterprise Parquet Query Engine
Memory-efficient processing for large-scale parquet files
"""

import pyarrow.parquet as pq
import pyarrow.compute as pc
import pyarrow as pa
import pandas as pd
from typing import List, Dict, Any, Optional, Generator
from pathlib import Path
import logging
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class JoinConfig:
    """Configuration for joining parquet files"""
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = 'inner'  # inner, left, right, outer


@dataclass
class QueryConfig:
    """Configuration for query execution"""
    files: List[str]
    joins: Optional[List[JoinConfig]] = None
    filters: Optional[List[Dict[str, Any]]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[Dict[str, str]]] = None  # [{"column": "col1", "direction": "asc"}]


class ParquetQueryEngine:
    """
    Enterprise-grade Parquet Query Engine with memory-efficient operations
    Supports large-scale data processing with streaming capabilities
    """
    
    def __init__(self, base_path: str = "./data/parquet", chunk_size: int = 100000):
        """
        Initialize the Parquet Query Engine
        
        Args:
            base_path: Base directory for parquet files
            chunk_size: Number of rows to process at a time for memory efficiency
        """
        self.base_path = Path(base_path)
        self.chunk_size = chunk_size
        self.base_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"ParquetQueryEngine initialized with base_path: {self.base_path}")
    
    def list_files(self) -> List[Dict[str, Any]]:
        """
        List all available parquet files with metadata
        
        Returns:
            List of file information dictionaries
        """
        files = []
        for file_path in self.base_path.rglob("*.parquet"):
            try:
                parquet_file = pq.ParquetFile(file_path)
                metadata = parquet_file.metadata
                schema = parquet_file.schema_arrow
                
                files.append({
                    "name": file_path.name,
                    "path": str(file_path.relative_to(self.base_path)),
                    "size_bytes": file_path.stat().st_size,
                    "num_rows": metadata.num_rows,
                    "num_columns": len(schema),
                    "columns": [
                        {
                            "name": field.name,
                            "type": str(field.type)
                        }
                        for field in schema
                    ]
                })
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                continue
        
        return files
    
    def get_file_schema(self, file_path: str) -> Dict[str, Any]:
        """
        Get detailed schema information for a parquet file
        
        Args:
            file_path: Relative path to the parquet file
            
        Returns:
            Schema information dictionary
        """
        full_path = self.base_path / file_path
        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        parquet_file = pq.ParquetFile(full_path)
        schema = parquet_file.schema_arrow
        
        return {
            "file": file_path,
            "columns": [
                {
                    "name": field.name,
                    "type": str(field.type),
                    "nullable": field.nullable
                }
                for field in schema
            ],
            "num_rows": parquet_file.metadata.num_rows
        }
    
    def _apply_filters(self, table: pa.Table, filters: List[Dict[str, Any]]) -> pa.Table:
        """
        Apply filters to a PyArrow table
        
        Args:
            table: PyArrow table
            filters: List of filter conditions
            
        Returns:
            Filtered table
        """
        if not filters:
            return table
        
        mask = None
        
        for filter_condition in filters:
            column = filter_condition["column"]
            operator = filter_condition["operator"]
            value = filter_condition["value"]
            
            # Convert value to appropriate Arrow scalar
            col_type = table.schema.field(column).type
            
            if operator == "eq":
                condition = pc.equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "ne":
                condition = pc.not_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "gt":
                condition = pc.greater(table[column], pa.scalar(value, type=col_type))
            elif operator == "gte":
                condition = pc.greater_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "lt":
                condition = pc.less(table[column], pa.scalar(value, type=col_type))
            elif operator == "lte":
                condition = pc.less_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "in":
                condition = pc.is_in(table[column], pa.array(value))
            elif operator == "contains":
                condition = pc.match_substring(table[column], value)
            else:
                raise ValueError(f"Unsupported operator: {operator}")
            
            if mask is None:
                mask = condition
            else:
                mask = pc.and_(mask, condition)
        
        return table.filter(mask)
    
    def _read_parquet_chunked(self, file_path: str, 
                             columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file in chunks for memory efficiency
        
        Args:
            file_path: Path to parquet file
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        full_path = self.base_path / file_path
        parquet_file = pq.ParquetFile(full_path)
        
        for batch in parquet_file.iter_batches(batch_size=self.chunk_size, columns=columns):
            yield pa.Table.from_batches([batch])
    
    def execute_query(self, query_config: QueryConfig) -> Generator[pd.DataFrame, None, None]:
        """
        Execute a query with joins, filters, and projections
        Memory-efficient streaming implementation for large datasets
        
        Args:
            query_config: Query configuration object
            
        Yields:
            Pandas DataFrame chunks
        """
        logger.info(f"Executing query with config: {query_config}")
        
        # Start with the first file
        if not query_config.files:
            raise ValueError("At least one file must be specified")
        
        # Read first file
        primary_file = query_config.files[0]
        logger.info(f"Reading primary file: {primary_file}")
        
        # Determine columns to read
        read_columns = query_config.columns if query_config.columns else None
        
        # Process in chunks
        for chunk_idx, table_chunk in enumerate(self._read_parquet_chunked(primary_file, read_columns)):
            logger.info(f"Processing chunk {chunk_idx}, rows: {len(table_chunk)}")
            
            # Apply filters
            if query_config.filters:
                table_chunk = self._apply_filters(table_chunk, query_config.filters)
                if len(table_chunk) == 0:
                    continue
            
            # Perform joins if specified
            if query_config.joins:
                for join_config in query_config.joins:
                    table_chunk = self._perform_join(table_chunk, join_config)
                    if len(table_chunk) == 0:
                        break
            
            # Apply column selection
            if query_config.columns:
                available_cols = [col for col in query_config.columns if col in table_chunk.column_names]
                table_chunk = table_chunk.select(available_cols)
            
            # Apply ordering
            if query_config.order_by:
                table_chunk = self._apply_sorting(table_chunk, query_config.order_by)
            
            # Convert to pandas and yield
            if len(table_chunk) > 0:
                yield table_chunk.to_pandas()
    
    def _perform_join(self, left_table: pa.Table, join_config: JoinConfig) -> pa.Table:
        """
        Perform join operation between tables
        
        Args:
            left_table: Left table
            join_config: Join configuration
            
        Returns:
            Joined table
        """
        # Read the right file completely (consider chunking for very large files)
        right_path = self.base_path / join_config.right_file
        right_table = pq.read_table(right_path)
        
        # Convert to pandas for join (PyArrow join support is limited)
        left_df = left_table.to_pandas()
        right_df = right_table.to_pandas()
        
        # Perform join
        merged_df = left_df.merge(
            right_df,
            left_on=join_config.left_on,
            right_on=join_config.right_on,
            how=join_config.how,
            suffixes=('', '_right')
        )
        
        # Convert back to Arrow
        return pa.Table.from_pandas(merged_df)
    
    def _apply_sorting(self, table: pa.Table, order_by: List[Dict[str, str]]) -> pa.Table:
        """
        Apply sorting to table
        
        Args:
            table: PyArrow table
            order_by: List of sort specifications
            
        Returns:
            Sorted table
        """
        # Convert to pandas for sorting
        df = table.to_pandas()
        
        sort_columns = [item["column"] for item in order_by]
        sort_ascending = [item.get("direction", "asc") == "asc" for item in order_by]
        
        df = df.sort_values(by=sort_columns, ascending=sort_ascending)
        
        return pa.Table.from_pandas(df)
    
    def execute_query_to_csv(self, query_config: QueryConfig, output_path: str,
                            progress_callback: Optional[callable] = None) -> Dict[str, Any]:
        """
        Execute query and save results to CSV with streaming
        
        Args:
            query_config: Query configuration
            output_path: Path to save CSV file
            progress_callback: Optional callback for progress updates
            
        Returns:
            Execution statistics
        """
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        total_rows = 0
        chunk_count = 0
        first_chunk = True
        
        try:
            for chunk_df in self.execute_query(query_config):
                # Write to CSV
                chunk_df.to_csv(
                    output_file,
                    mode='w' if first_chunk else 'a',
                    header=first_chunk,
                    index=False
                )
                
                total_rows += len(chunk_df)
                chunk_count += 1
                first_chunk = False
                
                if progress_callback:
                    progress_callback({
                        "chunk": chunk_count,
                        "total_rows": total_rows,
                        "status": "processing"
                    })
                
                logger.info(f"Written chunk {chunk_count}, total rows: {total_rows}")
            
            stats = {
                "total_rows": total_rows,
                "chunks_processed": chunk_count,
                "output_file": str(output_file),
                "file_size_bytes": output_file.stat().st_size if output_file.exists() else 0,
                "status": "completed"
            }
            
            if progress_callback:
                progress_callback(stats)
            
            logger.info(f"Query execution completed: {stats}")
            return stats
            
        except Exception as e:
            logger.error(f"Error executing query: {e}")
            if progress_callback:
                progress_callback({
                    "status": "failed",
                    "error": str(e)
                })
            raise
    
    def generate_query_id(self, query_config: QueryConfig) -> str:
        """
        Generate unique ID for a query
        
        Args:
            query_config: Query configuration
            
        Returns:
            Unique query ID
        """
        query_str = json.dumps(query_config.__dict__, sort_keys=True, default=str)
        return hashlib.md5(query_str.encode()).hexdigest()
    
    def validate_query(self, query_config: QueryConfig) -> Dict[str, Any]:
        """
        Validate query configuration
        
        Args:
            query_config: Query configuration to validate
            
        Returns:
            Validation result with errors if any
        """
        errors = []
        warnings = []
        
        # Check if files exist
        for file in query_config.files:
            file_path = self.base_path / file
            if not file_path.exists():
                errors.append(f"File not found: {file}")
        
        # Validate join configurations
        if query_config.joins:
            for join in query_config.joins:
                right_file = self.base_path / join.right_file
                if not right_file.exists():
                    errors.append(f"Join file not found: {join.right_file}")
        
        # Validate columns if specified
        if query_config.columns and query_config.files:
            try:
                schema = self.get_file_schema(query_config.files[0])
                available_cols = {col["name"] for col in schema["columns"]}
                
                for col in query_config.columns:
                    if col not in available_cols:
                        warnings.append(f"Column '{col}' not found in primary file")
            except Exception as e:
                warnings.append(f"Could not validate columns: {str(e)}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
