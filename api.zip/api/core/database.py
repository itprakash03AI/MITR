"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, event as sa_event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
from typing import Optional, List, Dict, Any
import json
from contextlib import contextmanager
from pathlib import Path

Base = declarative_base()


class SavedQuery(Base):
    """Model for saved queries"""
    __tablename__ = "saved_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    query_config = Column(JSON, nullable=False)  # Stores QueryConfig as JSON
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    execution_count = Column(Integer, default=0)
    last_executed_at = Column(DateTime, nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "query_config": self.query_config,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
            "execution_count": self.execution_count,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None
        }


class QueryExecution(Base):
    """Model for tracking query executions"""
    __tablename__ = "query_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, nullable=True)  # Reference to SavedQuery if applicable
    execution_id = Column(String(100), unique=True, nullable=False, index=True)
    query_config = Column(JSON, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    total_rows = Column(Integer, default=0)
    chunks_processed = Column(Integer, default=0)
    output_file = Column(String(500), nullable=True)
    file_size_bytes = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    executed_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "query_id": self.query_id,
            "execution_id": self.execution_id,
            "query_config": self.query_config,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "total_rows": self.total_rows,
            "chunks_processed": self.chunks_processed,
            "output_file": self.output_file,
            "file_size_bytes": self.file_size_bytes,
            "error_message": self.error_message,
            "executed_by": self.executed_by
        }


class DownloadFile(Base):
    """Model for tracking downloadable files"""
    __tablename__ = "download_files"
    
    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String(100), unique=True, nullable=False, index=True)
    execution_id = Column(String(100), nullable=True, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, default=0)
    status = Column(String(50), default="available")  # available, downloaded, expired, deleted
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    download_count = Column(Integer, default=0)
    last_downloaded_at = Column(DateTime, nullable=True)
    created_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "execution_id": self.execution_id,
            "filename": self.filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "download_count": self.download_count,
            "last_downloaded_at": self.last_downloaded_at.isoformat() if self.last_downloaded_at else None,
            "created_by": self.created_by
        }


class SqlSavedQuery(Base):
    """Model for SQL queries executed against SQL connectors (Trino, Snowflake, Databricks)."""
    __tablename__ = "sql_saved_queries"

    id                     = Column(Integer,     primary_key=True, index=True)
    name                   = Column(String(255), nullable=False,   index=True)
    description            = Column(Text,        nullable=True)
    # Primary source
    primary_connection_id  = Column(Integer,     nullable=False)
    primary_sql            = Column(Text,        nullable=False)
    # Optional secondary source for cross-source joins
    secondary_connection_id = Column(Integer,    nullable=True)
    secondary_sql          = Column(Text,        nullable=True)
    # Join config: { how, left_on, right_on, suffixes }
    join_config            = Column(JSON,        nullable=True)
    # Metadata
    created_by             = Column(String(100), nullable=True)
    created_at             = Column(DateTime,    default=datetime.utcnow)
    updated_at             = Column(DateTime,    default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active              = Column(Boolean,     default=True)
    execution_count        = Column(Integer,     default=0)
    last_executed_at       = Column(DateTime,    nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "primary_connection_id":   self.primary_connection_id,
            "primary_sql":             self.primary_sql,
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_sql":           self.secondary_sql,
            "join_config":             self.join_config,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "is_active":               self.is_active,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
        }


class Connection(Base):
    """Model for data source connections"""
    __tablename__ = "connections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    connection_type = Column(String(50), nullable=False)
    config = Column(JSON, nullable=False)   # sensitive fields stored encrypted
    is_active = Column(Boolean, default=True)
    last_tested_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(50), nullable=True)  # 'success' or 'failed'
    last_test_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary (config may contain encrypted values)."""
        return {
            "id": self.id,
            "name": self.name,
            "connection_type": self.connection_type,
            "config": self.config,
            "is_active": self.is_active,
            "last_tested_at": self.last_tested_at.isoformat() if self.last_tested_at else None,
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


class Report(Base):
    """Named parametric report — wraps a saved query or SQL query with a parameter schema."""
    __tablename__ = "reports"

    id                 = Column(Integer,     primary_key=True, index=True)
    name               = Column(String(255), nullable=False,   index=True)
    description        = Column(Text,        nullable=True)

    # Exactly one source is set
    saved_query_id     = Column(Integer, nullable=True)        # → SavedQuery (parquet)
    sql_saved_query_id = Column(Integer, nullable=True)        # → SqlSavedQuery

    # Parameter schema: [{ name, label, type, required, default_value, description }]
    # type: string | number | date | boolean | select
    # If type == select, include options: ["val1", "val2", ...]
    parameters         = Column(JSON, nullable=False, default=list)

    # Optional SQL override (replaces source query's SQL at execution time)
    sql_override       = Column(Text, nullable=True)

    is_active          = Column(Boolean,     default=True)
    is_public          = Column(Boolean,     default=True)
    created_by         = Column(String(100), nullable=True)
    created_at         = Column(DateTime,    default=datetime.utcnow)
    updated_at         = Column(DateTime,    default=datetime.utcnow, onupdate=datetime.utcnow)
    execution_count    = Column(Integer,     default=0)
    last_executed_at   = Column(DateTime,    nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                   self.id,
            "name":                 self.name,
            "description":          self.description,
            "saved_query_id":       self.saved_query_id,
            "sql_saved_query_id":   self.sql_saved_query_id,
            "parameters":           self.parameters or [],
            "sql_override":         self.sql_override,
            "is_active":            self.is_active,
            "is_public":            self.is_public,
            "created_by":           self.created_by,
            "created_at":           self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":           self.updated_at.isoformat()  if self.updated_at  else None,
            "execution_count":      self.execution_count,
            "last_executed_at":     self.last_executed_at.isoformat() if self.last_executed_at else None,
        }


class Schedule(Base):
    """Scheduled automatic query/report execution → downloads directory."""
    __tablename__ = "schedules"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    is_active       = Column(Boolean,     default=True)

    # Source type: "saved_query" | "sql_query" | "report"
    source_type     = Column(String(50),  nullable=False)
    source_id       = Column(Integer,     nullable=False)

    # Parameter values to pass to the source at run time
    param_values    = Column(JSON, nullable=True)

    # Trigger config:
    #   { "type": "cron",     "cron_expr": "0 8 * * 1-5" }
    #   { "type": "interval", "minutes": 60 }
    trigger_config  = Column(JSON, nullable=False)

    # Output filename template — {date} is replaced with YYYYMMDD_HHMMSS
    output_filename_template = Column(String(255), nullable=True)

    # APScheduler job ID (stored so we can pause/remove specific jobs)
    apscheduler_job_id = Column(String(100), nullable=True, unique=True)

    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=datetime.utcnow)
    updated_at      = Column(DateTime,    default=datetime.utcnow, onupdate=datetime.utcnow)

    # Run tracking
    last_run_at     = Column(DateTime, nullable=True)
    last_run_status = Column(String(50), nullable=True)   # success | failed
    last_run_file_id= Column(String(100), nullable=True)
    last_error      = Column(Text, nullable=True)
    run_count       = Column(Integer, default=0)
    next_run_at     = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "description":      self.description,
            "is_active":        self.is_active,
            "source_type":      self.source_type,
            "source_id":        self.source_id,
            "param_values":     self.param_values,
            "trigger_config":   self.trigger_config,
            "output_filename_template": self.output_filename_template,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
            "last_run_at":      self.last_run_at.isoformat() if self.last_run_at else None,
            "last_run_status":  self.last_run_status,
            "last_run_file_id": self.last_run_file_id,
            "last_error":       self.last_error,
            "run_count":        self.run_count,
            "next_run_at":      self.next_run_at.isoformat() if self.next_run_at else None,
        }


class DatabaseManager:
    """Database manager for handling all database operations"""
    
    def __init__(self, db_url: str = "sqlite:///./data/parquet_query_engine.db"):
        """
        Initialize database manager
        
        Args:
            db_url: Database connection URL
        """
        # Ensure data directory exists
        db_path = Path(db_url.replace("sqlite:///", ""))
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        is_sqlite = "sqlite" in db_url

        self.engine = create_engine(
            db_url,
            connect_args={"check_same_thread": False} if is_sqlite else {},
            pool_pre_ping=True,
            # pool_size / max_overflow are ignored for SQLite's StaticPool,
            # but kept for potential future migration to PostgreSQL.
            pool_size=10,
            max_overflow=20
        )

        # Enable WAL journal mode for SQLite so concurrent readers never block
        # each other, and writers only block other writers (not readers).
        # busy_timeout makes writers retry for up to 30 s instead of failing
        # immediately when another writer holds the lock.
        if is_sqlite:
            @sa_event.listens_for(self.engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _conn_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA busy_timeout=30000")
                cursor.close()

        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

        # Create tables (only creates tables that don't exist yet)
        Base.metadata.create_all(bind=self.engine)

        # Safe schema migration for SQLite — add any columns that existing
        # tables might be missing when the schema is updated after initial
        # creation.  Base.metadata.create_all never alters existing tables,
        # so new columns must be applied manually.
        if is_sqlite:
            self._apply_sqlite_migrations()

    def _apply_sqlite_migrations(self):
        """Add columns that may be missing from older DB versions (SQLite only).

        Uses a raw sqlite3 connection (bypasses SQLAlchemy version differences)
        so this works identically with SQLAlchemy 1.x and 2.x.
        """
        import sqlite3 as _sqlite3
        db_file = str(self.engine.url).replace("sqlite:///", "")
        if not db_file or db_file == ":memory:":
            return

        # table → list of (column_name, sqlite_type)
        # Extend this dict whenever a new column is added to an existing model.
        migrations: dict = {
            "reports": [
                ("sql_saved_query_id", "INTEGER"),
                ("sql_override",       "TEXT"),
                ("last_executed_at",   "TIMESTAMP"),
            ],
        }
        try:
            con = _sqlite3.connect(db_file)
            cur = con.cursor()
            for table, columns in migrations.items():
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    existing = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue
                for col_name, col_type in columns:
                    if col_name not in existing:
                        try:
                            cur.execute(
                                f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"
                            )
                        except Exception:
                            pass  # already exists or table not yet created
            con.commit()
            con.close()
        except Exception:
            pass  # non-critical — server starts regardless

    @contextmanager
    def get_session(self) -> Session:
        """
        Context manager for database sessions
        
        Yields:
            Database session
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    # SavedQuery operations
    def create_query(self, name: str, query_config: Dict[str, Any],
                    description: Optional[str] = None,
                    created_by: Optional[str] = None) -> SavedQuery:
        """Create a new saved query"""
        with self.get_session() as session:
            query = SavedQuery(
                name=name,
                description=description,
                query_config=query_config,
                created_by=created_by
            )
            session.add(query)
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def get_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a saved query by ID"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            return query.to_dict() if query else None
    
    def list_queries(self, active_only: bool = True,
                    limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all saved queries"""
        with self.get_session() as session:
            query = session.query(SavedQuery)
            
            if active_only:
                query = query.filter(SavedQuery.is_active == True)
            
            query = query.order_by(SavedQuery.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [q.to_dict() for q in query.all()]
    
    def update_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return None
            
            for key, value in kwargs.items():
                if hasattr(query, key):
                    setattr(query, key, value)
            
            query.updated_at = datetime.utcnow()
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def delete_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return False
            
            if soft_delete:
                query.is_active = False
                query.updated_at = datetime.utcnow()
            else:
                session.delete(query)
            
            return True
    
    def increment_execution_count(self, query_id: int) -> None:
        """Increment execution count for a query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if query:
                query.execution_count += 1
                query.last_executed_at = datetime.utcnow()
    
    # QueryExecution operations
    def create_execution(self, execution_id: str, query_config: Dict[str, Any],
                        query_id: Optional[int] = None,
                        executed_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a new query execution record"""
        with self.get_session() as session:
            execution = QueryExecution(
                execution_id=execution_id,
                query_id=query_id,
                query_config=query_config,
                executed_by=executed_by
            )
            session.add(execution)
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def update_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a query execution"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            
            if not execution:
                return None
            
            for key, value in kwargs.items():
                if hasattr(execution, key):
                    setattr(execution, key, value)
            
            if kwargs.get("status") in ["completed", "failed"]:
                execution.completed_at = datetime.utcnow()
            
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution by ID"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            return execution.to_dict() if execution else None
    
    def list_executions(self, limit: int = 100, offset: int = 0,
                       status: Optional[str] = None) -> List[Dict[str, Any]]:
        """List query executions"""
        with self.get_session() as session:
            query = session.query(QueryExecution)
            
            if status:
                query = query.filter(QueryExecution.status == status)
            
            query = query.order_by(QueryExecution.started_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [e.to_dict() for e in query.all()]
    
    # DownloadFile operations
    def create_download_file(self, file_id: str, filename: str, file_path: str,
                           file_size_bytes: int, execution_id: Optional[str] = None,
                           expires_at: Optional[datetime] = None,
                           created_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a download file record"""
        with self.get_session() as session:
            download_file = DownloadFile(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=file_path,
                file_size_bytes=file_size_bytes,
                expires_at=expires_at,
                created_by=created_by
            )
            session.add(download_file)
            session.flush()
            session.refresh(download_file)
            return download_file.to_dict()
    
    def get_download_file(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get download file by ID"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            return file.to_dict() if file else None
    
    def list_download_files(self, status: Optional[str] = "available",
                          limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List download files"""
        with self.get_session() as session:
            query = session.query(DownloadFile)
            
            if status:
                query = query.filter(DownloadFile.status == status)
            
            query = query.order_by(DownloadFile.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [f.to_dict() for f in query.all()]
    
    def update_download_file(self, file_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update download file"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            
            if not file:
                return None
            
            for key, value in kwargs.items():
                if hasattr(file, key):
                    setattr(file, key, value)
            
            session.flush()
            session.refresh(file)
            return file.to_dict()
    
    def increment_download_count(self, file_id: str) -> None:
        """Increment download count"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            if file:
                file.download_count += 1
                file.last_downloaded_at = datetime.utcnow()

    # ── Connection operations ──────────────────────────────────────────────────

    def create_connection(self, name: str, connection_type: str,
                         config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new connection — encrypts sensitive config fields at rest."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = Connection(
                name=name,
                connection_type=connection_type,
                config=encrypt_config(config),
            )
            session.add(connection)
            session.flush()
            session.refresh(connection)
            d = connection.to_dict()
            d["config"] = mask_config(config)   # return masked to caller
            return d

    def get_connection(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials MASKED — safe for API responses to the browser."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = mask_config(decrypt_config(d["config"]))
            return d

    def get_connection_raw(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials DECRYPTED — for internal engine/connector use only.
        Never return this directly to API clients."""
        from core.crypto import decrypt_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = decrypt_config(d["config"])
            return d

    def list_connections(self, active_only: bool = True,
                        limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List connections with credentials masked."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            q = session.query(Connection)
            if active_only:
                q = q.filter(Connection.is_active == True)
            q = q.order_by(Connection.created_at.desc()).limit(limit).offset(offset)
            result = []
            for c in q.all():
                d = c.to_dict()
                d["config"] = mask_config(decrypt_config(d["config"]))
                result.append(d)
            return result

    def update_connection(self, connection_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a connection — re-encrypts config if provided."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return None
            # Encrypt config before persisting
            if "config" in kwargs and isinstance(kwargs["config"], dict):
                kwargs["config"] = encrypt_config(kwargs["config"])
            for key, value in kwargs.items():
                if hasattr(connection, key):
                    setattr(connection, key, value)
            connection.updated_at = datetime.utcnow()
            session.flush()
            session.refresh(connection)
            return connection.to_dict()

    def delete_connection(self, connection_id: int, soft_delete: bool = True) -> bool:
        """Delete a connection."""
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return False
            if soft_delete:
                connection.is_active = False
                connection.updated_at = datetime.utcnow()
            else:
                session.delete(connection)
            return True

    # ── Report operations ──────────────────────────────────────────────────────

    def create_report(self, **kwargs) -> Dict[str, Any]:
        """Create a new parametric report."""
        with self.get_session() as session:
            report = Report(**kwargs)
            session.add(report)
            session.flush()
            session.refresh(report)
            return report.to_dict()

    def get_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            return r.to_dict() if r else None

    def list_reports(self, active_only: bool = True,
                     limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Report)
            if active_only:
                q = q.filter(Report.is_active == True)
            rows = q.order_by(Report.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def update_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(r, key):
                    setattr(r, key, value)
            r.updated_at = datetime.utcnow()
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def delete_report(self, report_id: int, soft_delete: bool = True) -> bool:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return False
            if soft_delete:
                r.is_active = False
            else:
                session.delete(r)
            return True

    def increment_report_execution(self, report_id: int):
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if r:
                r.execution_count = (r.execution_count or 0) + 1
                r.last_executed_at = datetime.utcnow()

    # ── Schedule operations ────────────────────────────────────────────────────

    def create_schedule(self, **kwargs) -> Dict[str, Any]:
        """Create a new schedule record."""
        with self.get_session() as session:
            s = Schedule(**kwargs)
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_schedule(self, schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            return s.to_dict() if s else None

    def list_schedules(self, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Schedule)
            if active_only:
                q = q.filter(Schedule.is_active == True)
            rows = q.order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def list_all_schedules(self, limit: int = 500, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(Schedule).order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def update_schedule(self, schedule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            s.updated_at = datetime.utcnow()
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    def increment_schedule_run_count(self, schedule_id: int):
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if s:
                s.run_count = (s.run_count or 0) + 1

    def list_downloads_enriched(
        self,
        status: Optional[str] = "available",
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Returns download files enriched with linked execution metadata.

        Single LEFT JOIN query — no N+1 lookups.
        Extra fields added to each record:
          - duration_seconds  (execution completed_at - started_at)
          - total_rows        (rows written by the query engine)
          - format            ('csv' | 'excel' | 'json' derived from filename)
        """
        with self.get_session() as session:
            query = (
                session.query(DownloadFile, QueryExecution)
                .outerjoin(
                    QueryExecution,
                    DownloadFile.execution_id == QueryExecution.execution_id,
                )
            )
            if status:
                query = query.filter(DownloadFile.status == status)

            query = (
                query.order_by(DownloadFile.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = []
            for dl, ex in query.all():
                d = dl.to_dict()

                # Execution metadata
                if ex:
                    if ex.started_at and ex.completed_at:
                        d["duration_seconds"] = round(
                            (ex.completed_at - ex.started_at).total_seconds(), 2
                        )
                    else:
                        d["duration_seconds"] = None
                    d["total_rows"] = ex.total_rows or 0
                else:
                    d["duration_seconds"] = None
                    d["total_rows"] = None

                # Derive format from filename extension
                fname = (d.get("filename") or "").lower()
                if fname.endswith(".xlsx"):
                    d["format"] = "excel"
                elif fname.endswith(".json"):
                    d["format"] = "json"
                else:
                    d["format"] = "csv"

                result.append(d)

            return result

    # ── SQL Saved Queries (Trino / Snowflake / Databricks) ────────────────────

    def create_sql_query(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlSavedQuery record."""
        with self.get_session() as session:
            q = SqlSavedQuery(**kwargs)
            session.add(q)
            session.flush()
            return q.to_dict()

    def list_sql_queries(self, active_only: bool = True, limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL saved queries, newest first."""
        with self.get_session() as session:
            query = session.query(SqlSavedQuery)
            if active_only:
                query = query.filter(SqlSavedQuery.is_active == True)
            rows = query.order_by(SqlSavedQuery.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def get_sql_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL saved query by ID."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            return q.to_dict() if q else None

    def update_sql_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(q, key):
                    setattr(q, key, value)
            q.updated_at = datetime.utcnow()
            session.flush()
            return q.to_dict()

    def delete_sql_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return False
            if soft_delete:
                q.is_active = False
            else:
                session.delete(q)
            return True

    def increment_sql_query_execution(self, query_id: int):
        """Bump execution counter and last_executed_at timestamp."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if q:
                q.execution_count = (q.execution_count or 0) + 1
                q.last_executed_at = datetime.utcnow()
