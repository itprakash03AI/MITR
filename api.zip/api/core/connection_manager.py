"""
Connection Manager
Manages data source connections (S3 and local) for the Parquet Query Engine.
Provides per-connection file listing and schema retrieval.
"""

import logging
import re
import sys
import threading
from pathlib import Path
from typing import Dict, List, Any, Optional

import pyarrow.parquet as pq

from core.s3_storage import S3StorageHandler, S3Config
from core.database import DatabaseManager

logger = logging.getLogger(__name__)


def _normalize_path(path_str: str) -> Path:
    """
    Normalize a path string to a Path object, converting Windows-style paths
    to WSL/Linux paths when running on Linux (e.g. inside Docker or WSL).

    C:\\DEV\\foo  or  C:/DEV/foo  →  /mnt/c/DEV/foo  (on Linux)
    Falls through to Path() as-is on Windows or for native Linux paths.
    """
    if sys.platform != "win32":
        win_abs = re.match(r"^([a-zA-Z]):[/\\](.*)", path_str)
        if win_abs:
            drive = win_abs.group(1).lower()
            rest = win_abs.group(2).replace("\\", "/")
            return Path(f"/mnt/{drive}/{rest}")
    return Path(path_str)


class ConnectionManager:
    """
    Manages data source connections and provides file operations
    per connection. Caches S3 handler instances to avoid recreating
    boto3 sessions on every request.
    """

    def __init__(self, db_manager: DatabaseManager):
        """
        Initialize the connection manager.

        Args:
            db_manager: DatabaseManager instance for connection CRUD
        """
        self.db = db_manager
        self._s3_handlers: Dict[int, S3StorageHandler] = {}  # cache by connection_id
        self._s3_lock = threading.Lock()  # guards check-then-set on _s3_handlers

    def test_connection(self, connection_type: str, config: dict) -> dict:
        """
        Test a connection configuration without saving it.

        Args:
            connection_type: 's3' or 'local'
            config: Connection configuration dictionary

        Returns:
            Dict with 'success' (bool) and 'message' (str)
        """
        if connection_type == "s3":
            return self._test_s3_connection(config)
        elif connection_type == "local":
            return self._test_local_connection(config)
        else:
            return {
                "success": False,
                "message": f"Unsupported connection type: {connection_type}"
            }

    def _test_s3_connection(self, config: dict) -> dict:
        """Test an S3 connection configuration."""
        try:
            s3_cfg = S3Config(
                bucket_name=config["bucket_name"],
                region_name=config.get("region_name", "us-east-1"),
                aws_access_key_id=config.get("aws_access_key_id"),
                aws_secret_access_key=config.get("aws_secret_access_key"),
                endpoint_url=config.get("endpoint_url"),
            )
            handler = S3StorageHandler(s3_cfg)
            result = handler.test_connection()

            if result.get("connected"):
                return {
                    "success": True,
                    "message": f"Successfully connected to S3 bucket '{config['bucket_name']}'"
                }
            else:
                return {
                    "success": False,
                    "message": f"Failed to connect to S3: {result.get('error', 'Unknown error')}"
                }
        except Exception as e:
            logger.error(f"S3 connection test failed: {e}")
            return {
                "success": False,
                "message": f"S3 connection test failed: {str(e)}"
            }

    def _test_local_connection(self, config: dict) -> dict:
        """Test a local filesystem connection configuration."""
        try:
            base_path = config.get("base_path")
            if not base_path:
                return {
                    "success": False,
                    "message": "Missing 'base_path' in configuration"
                }

            path = _normalize_path(base_path)
            if not path.exists():
                return {
                    "success": False,
                    "message": f"Path does not exist: {base_path} (resolved: {path})"
                }

            if not path.is_dir():
                return {
                    "success": False,
                    "message": f"Path is not a directory: {base_path}"
                }

            return {
                "success": True,
                "message": f"Successfully connected to local path '{path}'"
            }
        except Exception as e:
            logger.error(f"Local connection test failed: {e}")
            return {
                "success": False,
                "message": f"Local connection test failed: {str(e)}"
            }

    def _get_s3_handler(self, connection_id: int, config: dict) -> S3StorageHandler:
        """
        Get or create a cached S3StorageHandler for the given connection.

        Uses a lock to prevent check-then-set races when multiple threads
        request the same connection simultaneously.

        Args:
            connection_id: Database ID of the connection
            config: S3 configuration dictionary

        Returns:
            Cached or newly created S3StorageHandler
        """
        # Fast path: handler already cached (no lock needed for reads on CPython due to GIL,
        # but we use double-checked locking for correctness across platforms)
        if connection_id in self._s3_handlers:
            return self._s3_handlers[connection_id]

        with self._s3_lock:
            # Re-check inside lock to handle concurrent first-creation
            if connection_id not in self._s3_handlers:
                s3_cfg = S3Config(
                    bucket_name=config["bucket_name"],
                    region_name=config.get("region_name", "us-east-1"),
                    aws_access_key_id=config.get("aws_access_key_id"),
                    aws_secret_access_key=config.get("aws_secret_access_key"),
                    endpoint_url=config.get("endpoint_url"),
                )
                self._s3_handlers[connection_id] = S3StorageHandler(s3_cfg)
        return self._s3_handlers[connection_id]

    def list_files(self, connection_id: int, folder: str = "") -> list:
        """
        List parquet files from the specified connection.

        Args:
            connection_id: Database ID of the connection
            folder: Optional subfolder/prefix to filter files

        Returns:
            List of file information dictionaries

        Raises:
            ValueError: If connection is not found
        """
        conn = self.db.get_connection(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            return handler.list_parquet_files(folder_path=folder)
        else:  # local
            return self._list_local_files(conn["config"], folder)

    _PREVIEWABLE_EXTS = {".parquet", ".csv", ".txt"}

    def _list_local_files(self, config: dict, folder: str = "") -> list:
        """
        List previewable files (.parquet, .csv, .txt) in a local directory.

        Args:
            config: Local connection configuration with 'base_path'
            folder: Optional subfolder relative to base_path

        Returns:
            List of file information dictionaries
        """
        base = _normalize_path(config["base_path"])
        search_path = base / folder if folder else base

        if not search_path.exists() or not search_path.is_dir():
            return []

        files = []
        for file_path in sorted(search_path.rglob("*")):
            if file_path.suffix.lower() not in self._PREVIEWABLE_EXTS:
                continue
            try:
                stat = file_path.stat()
                relative_path = file_path.relative_to(base)
                files.append({
                    "name": file_path.name,
                    "path": str(relative_path).replace("\\", "/"),
                    "size_bytes": stat.st_size,
                    "last_modified": stat.st_mtime,
                    "folder": str(relative_path.parent).replace("\\", "/") if relative_path.parent != Path(".") else "",
                })
            except OSError as e:
                logger.warning(f"Could not stat file {file_path}: {e}")
                continue

        logger.info(f"Found {len(files)} previewable files in local path '{search_path}'")
        return files

    def get_schema(self, connection_id: int, file_path: str) -> dict:
        """
        Get schema information for a file within a connection.

        Args:
            connection_id: Database ID of the connection
            file_path: Path to the parquet file (S3 key or local relative path)

        Returns:
            Schema information dictionary

        Raises:
            ValueError: If connection is not found
        """
        conn = self.db.get_connection(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            return handler.get_file_schema(file_path)
        else:  # local
            return self._get_local_schema(conn["config"], file_path)

    def _get_local_schema(self, config: dict, file_path: str) -> dict:
        """
        Get schema for a local parquet file using pyarrow.

        Args:
            config: Local connection configuration with 'base_path'
            file_path: Relative path to the parquet file

        Returns:
            Schema information dictionary
        """
        base = _normalize_path(config["base_path"])
        full_path = base / file_path

        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        schema = pq.read_schema(str(full_path))
        metadata = pq.read_metadata(str(full_path))

        return {
            "file": file_path,
            "columns": [
                {
                    "name": schema.field(i).name,
                    "type": str(schema.field(i).type),
                    "nullable": schema.field(i).nullable,
                }
                for i in range(len(schema))
            ],
            "num_rows": metadata.num_rows,
            "num_row_groups": metadata.num_row_groups,
            "size_bytes": full_path.stat().st_size,
        }

    def invalidate_cache(self, connection_id: int):
        """
        Remove cached S3 handler when connection config changes.

        Args:
            connection_id: Database ID of the connection to invalidate
        """
        with self._s3_lock:
            self._s3_handlers.pop(connection_id, None)
        logger.info(f"Invalidated cached handler for connection {connection_id}")
