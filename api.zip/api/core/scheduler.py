"""
Query Studio Scheduler — APScheduler 3.x wrapper.

Runs a BackgroundScheduler backed by SQLAlchemyJobStore (same SQLite DB).
Jobs are submitted to a dedicated 20-thread pool, isolated from the interactive
query_executor so scheduled jobs never starve interactive users.

Job dispatch pattern:
  parquet saved_query  → OptimizedParquetEngine.execute_query_to_csv
  sql_query            → cross_source_engine.execute_single_source_query
  report               → reports_api._run_parquet_report / _run_sql_report

All jobs:
  - record start / completion / failure in the Schedule DB record
  - register the output CSV in DownloadFile
  - broadcast a WebSocket notification
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Module-level references injected at startup ───────────────────────────────
_db_manager  = None
_ws_manager  = None
_main_loop: Optional[asyncio.AbstractEventLoop] = None
_scheduler   = None


def init_scheduler(db_manager, ws_manager, main_loop, db_url: str):
    """
    Create and start the APScheduler BackgroundScheduler.
    Called once during FastAPI startup.
    """
    global _db_manager, _ws_manager, _main_loop, _scheduler

    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = main_loop

    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
    from apscheduler.executors.pool import ThreadPoolExecutor as APSThreadPool
    from sqlalchemy import create_engine
    from sqlalchemy import event as _sa_event

    # Build a dedicated SQLAlchemy engine for the APS jobstore that has
    # the same SQLite pragmas as DatabaseManager: WAL mode + 30-second
    # busy_timeout so APS never fails with SQLITE_BUSY on restart.
    _aps_engine = create_engine(
        db_url,
        connect_args={"check_same_thread": False},
    )

    @_sa_event.listens_for(_aps_engine, "connect")
    def _set_aps_pragmas(dbapi_conn, _conn_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.close()

    jobstore  = SQLAlchemyJobStore(engine=_aps_engine)
    # Limit worker threads so scheduled jobs never starve interactive queries.
    executor  = APSThreadPool(max_workers=4)

    _scheduler = BackgroundScheduler(
        jobstores={"default": jobstore},
        executors={"default": executor},
        job_defaults={
            "coalesce": True,       # collapse missed fires into one
            "max_instances": 1,     # no overlapping runs for the same job
            # Short grace time: skip jobs missed while the server was down for
            # more than 30 s — prevents bulk-firing on restart which would
            # compete with interactive queries for CPU/IO.
            "misfire_grace_time": 30,
        },
        timezone="UTC",
    )
    _scheduler.start()
    logger.info("QueryScheduler started (APScheduler %s)", _aps_version())

    # Re-register all active schedules from DB (APScheduler jobstore already has
    # their trigger state from the previous run; this just refreshes next_run_at)
    schedules = db_manager.list_schedules(active_only=True, limit=1000)
    _bootstrap_schedules(schedules)
    logger.info("Loaded %d active schedule(s) from DB", len(schedules))

    return _scheduler


def shutdown_scheduler():
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("QueryScheduler stopped")


def _aps_version() -> str:
    try:
        import apscheduler
        return apscheduler.__version__
    except Exception:
        return "unknown"


def _bootstrap_schedules(schedules: list):
    """After restart, ensure all active schedules have a live APScheduler job."""
    for s in schedules:
        try:
            if s.get("apscheduler_job_id") and _scheduler.get_job(s["apscheduler_job_id"]):
                # Job already exists in jobstore — refresh next_run_at in DB
                job = _scheduler.get_job(s["apscheduler_job_id"])
                if job and job.next_run_time:
                    _db_manager.update_schedule(s["id"], next_run_at=job.next_run_time)
            else:
                # Missing from jobstore (e.g. memory store) — re-add
                job_id = add_schedule(s)
                _db_manager.update_schedule(s["id"], apscheduler_job_id=job_id)
        except Exception as e:
            logger.warning("Could not bootstrap schedule %s: %s", s["id"], e)


# ── Public API called from schedules_api.py ───────────────────────────────────

def add_schedule(schedule_record: dict) -> str:
    """Register a new APScheduler job. Returns the APS job_id."""
    job_id  = f"qs_{schedule_record['id']}_{uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_record["trigger_config"])
    _scheduler.add_job(
        func=_run_scheduled_job,
        trigger=trigger,
        id=job_id,
        args=[schedule_record["id"]],
        name=schedule_record.get("name", job_id),
        replace_existing=True,
    )
    job = _scheduler.get_job(job_id)
    if job and job.next_run_time:
        _db_manager.update_schedule(schedule_record["id"], next_run_at=job.next_run_time)
    return job_id


def remove_schedule(job_id: str):
    if _scheduler and job_id and _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)


def pause_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.pause_job(job_id)


def resume_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.resume_job(job_id)
        job = _scheduler.get_job(job_id)
        return job.next_run_time if job else None


def run_now(schedule_id: int):
    """Submit an immediate (out-of-schedule) run without affecting the trigger."""
    _rpt_executor().submit(_run_scheduled_job, schedule_id)


def get_next_run(job_id: str) -> Optional[datetime]:
    if not _scheduler or not job_id:
        return None
    job = _scheduler.get_job(job_id)
    return job.next_run_time if job else None


def get_scheduler_status() -> Dict[str, Any]:
    if not _scheduler:
        return {"running": False}
    jobs = _scheduler.get_jobs()
    return {
        "running": _scheduler.running,
        "total_jobs": len(jobs),
        "jobs": [
            {
                "id": j.id,
                "name": j.name,
                "next_run_time": j.next_run_time.isoformat() if j.next_run_time else None,
            }
            for j in jobs
        ],
    }


# ── Trigger builder ───────────────────────────────────────────────────────────

def _build_trigger(trigger_config: dict):
    from apscheduler.triggers.cron     import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger

    ttype = trigger_config.get("type")
    if ttype == "cron":
        expr = trigger_config.get("cron_expr", "")
        return CronTrigger.from_crontab(expr, timezone="UTC")
    elif ttype == "interval":
        kwargs = {k: v for k, v in trigger_config.items() if k not in ("type",)}
        return IntervalTrigger(**kwargs, timezone="UTC")
    raise ValueError(f"Unknown trigger type '{ttype}'. Use 'cron' or 'interval'.")


# ── Lazy executor reference (avoids circular import) ─────────────────────────

def _rpt_executor():
    from concurrent.futures import ThreadPoolExecutor
    # Use a module-level singleton so we don't create new pools each call
    if not hasattr(_rpt_executor, "_pool"):
        _rpt_executor._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_run_now")
    return _rpt_executor._pool


# ── WS broadcast helper ───────────────────────────────────────────────────────

def _broadcast(payload: dict):
    if _ws_manager and _main_loop:
        try:
            asyncio.run_coroutine_threadsafe(_ws_manager.broadcast(payload), _main_loop)
        except Exception:
            pass


# ── Job body — runs inside APScheduler's thread pool ─────────────────────────

def _run_scheduled_job(schedule_id: int):
    """
    Called by APScheduler in a worker thread.
    1. Loads schedule from DB
    2. Executes the source query with param_values
    3. Saves output to downloads directory
    4. Registers DownloadFile record
    5. Updates Schedule run tracking
    6. Broadcasts WebSocket notification
    """
    schedule = _db_manager.get_schedule(schedule_id)
    if not schedule or not schedule.get("is_active"):
        return

    execution_id  = str(uuid.uuid4())
    source_type   = schedule["source_type"]
    source_id     = schedule["source_id"]
    param_values  = schedule.get("param_values") or {}
    name          = schedule.get("name", f"schedule:{schedule_id}")

    logger.info("[scheduler] Starting schedule %s '%s' → exec %s", schedule_id, name, execution_id[:8])

    _broadcast({
        "type":          "scheduled_job_started",
        "schedule_id":   schedule_id,
        "schedule_name": name,
        "execution_id":  execution_id,
        "timestamp":     datetime.utcnow().isoformat(),
    })

    output_dir = Path("./data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Resolve business date shortcuts at job run time (today, month_start, -7d, etc.)
        from api.reports_api import resolve_business_dates
        param_values = resolve_business_dates(param_values)

        if source_type == "saved_query":
            output_path, total_rows = _exec_parquet_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "sql_query":
            output_path, total_rows = _exec_sql_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "report":
            output_path, total_rows = _exec_report(source_id, param_values, execution_id, output_dir)
        else:
            raise ValueError(f"Unknown source_type '{source_type}'")

        # Build filename from template
        template = schedule.get("output_filename_template") or \
                   f"sched_{{name}}_{{date}}.csv"
        filename = (
            template
            .replace("{name}", name.replace(" ", "_"))
            .replace("{date}", datetime.utcnow().strftime("%Y%m%d_%H%M%S"))
        )

        # Register in DownloadFile
        file_id = str(uuid.uuid4())
        csv_path = Path(output_path)
        if csv_path.exists():
            _db_manager.create_download_file(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=str(csv_path),
                file_size_bytes=csv_path.stat().st_size,
                expires_at=datetime.utcnow() + timedelta(days=7),
                created_by=f"scheduler:{name}",
            )

        # Update schedule run status
        next_run = get_next_run(schedule.get("apscheduler_job_id", ""))
        _db_manager.update_schedule(
            schedule_id,
            last_run_at=datetime.utcnow(),
            last_run_status="success",
            last_run_file_id=file_id,
            last_error=None,
            next_run_at=next_run,
        )
        _db_manager.increment_schedule_run_count(schedule_id)

        _broadcast({
            "type":          "scheduled_job_completed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "execution_id":  execution_id,
            "file_id":       file_id,
            "total_rows":    total_rows,
            "timestamp":     datetime.utcnow().isoformat(),
        })
        logger.info(
            "[scheduler] Schedule %s completed: %d rows → %s",
            schedule_id, total_rows, filename,
        )

    except Exception as exc:
        logger.exception("[scheduler] Schedule %s failed: %s", schedule_id, exc)
        _db_manager.update_schedule(
            schedule_id,
            last_run_at=datetime.utcnow(),
            last_run_status="failed",
            last_error=str(exc),
        )
        _broadcast({
            "type":          "scheduled_job_failed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "error":         str(exc),
            "timestamp":     datetime.utcnow().isoformat(),
        })


# ── Per-source execution helpers ──────────────────────────────────────────────

def _exec_parquet_query(query_id: int, param_values: dict,
                        execution_id: str, output_dir: Path):
    from core.optimized_engine import OptimizedParquetEngine, QueryConfig as OptQC
    from api.reports_api import substitute_filter_params

    saved_q = _db_manager.get_query(query_id)
    if not saved_q:
        raise ValueError(f"Saved query {query_id} not found")

    qc = dict(saved_q["query_config"])
    if param_values and qc.get("filters"):
        qc["filters"] = substitute_filter_params(qc["filters"], param_values)

    engine = OptimizedParquetEngine(data_dir="./data/parquet")
    config = OptQC(
        files=qc.get("files", []),
        columns=qc.get("columns"),
        filters=qc.get("filters"),
        joins=qc.get("joins"),
        order_by=qc.get("order_by"),
        limit=qc.get("limit") or 1_000_000,
        offset=qc.get("offset", 0),
    )
    output_path = str(output_dir / f"{execution_id}.csv")
    stats = engine.execute_query_to_csv(config, output_path)
    return output_path, stats.rows_output


def _exec_sql_query(query_id: int, param_values: dict,
                    execution_id: str, output_dir: Path):
    from core.cross_source_engine import execute_single_source_query, execute_cross_source_query
    from api.reports_api import substitute_sql_params

    sql_q = _db_manager.get_sql_query(query_id)
    if not sql_q:
        raise ValueError(f"SQL query {query_id} not found")

    primary_conn = _db_manager.get_connection_raw(sql_q["primary_connection_id"])
    if not primary_conn:
        raise ValueError(f"Connection {sql_q['primary_connection_id']} not found")

    primary_sql = substitute_sql_params(sql_q["primary_sql"], param_values, [])

    is_cross = bool(sql_q.get("secondary_connection_id") and sql_q.get("secondary_sql"))
    if is_cross:
        secondary_conn = _db_manager.get_connection_raw(sql_q["secondary_connection_id"])
        secondary_sql  = substitute_sql_params(sql_q["secondary_sql"], param_values, [])
        result = execute_cross_source_query(
            primary_conn_type=primary_conn["connection_type"],
            primary_conn_config=primary_conn["config"],
            primary_sql=primary_sql,
            secondary_conn_type=secondary_conn["connection_type"],
            secondary_conn_config=secondary_conn["config"],
            secondary_sql=secondary_sql,
            join_config=sql_q.get("join_config") or {},
            execution_id=execution_id,
            output_dir=str(output_dir),
        )
    else:
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            execution_id=execution_id,
            output_dir=str(output_dir),
        )
    return result.output_path, result.total_rows


def _exec_report(report_id: int, param_values: dict,
                 execution_id: str, output_dir: Path):
    from api.reports_api import (
        _run_parquet_report, _run_sql_report, substitute_filter_params
    )

    report = _db_manager.get_report(report_id)
    if not report:
        raise ValueError(f"Report {report_id} not found")

    output_path = str(output_dir / f"{execution_id}.csv")
    noop_emit = lambda _: None

    if report["saved_query_id"]:
        total_rows = _run_parquet_report(report, param_values, None, output_path, noop_emit)
    elif report["sql_saved_query_id"]:
        total_rows = _run_sql_report(report, param_values, None, execution_id, noop_emit)
        output_path = str(output_dir / f"{execution_id}.csv")
    else:
        raise ValueError(f"Report {report_id} has no source configured")

    return output_path, total_rows
