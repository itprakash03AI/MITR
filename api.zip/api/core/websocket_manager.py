"""
WebSocket Manager for real-time notifications
Handles multiple client connections and broadcasting
"""

from fastapi import WebSocket
from typing import List, Dict, Any
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)


class WebSocketManager:
    """
    Manages WebSocket connections and broadcasting
    """
    
    def __init__(self):
        """Initialize WebSocket manager"""
        self.active_connections: List[WebSocket] = []
        self.connection_info: Dict[WebSocket, Dict[str, Any]] = {}
    
    async def connect(self, websocket: WebSocket):
        """
        Accept and register a new WebSocket connection
        
        Args:
            websocket: WebSocket connection
        """
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_info[websocket] = {
            "connected_at": datetime.utcnow(),
            "message_count": 0
        }
        
        # Send welcome message
        await self.send_personal_message(
            {
                "type": "connection_established",
                "message": "Connected to Parquet Query Engine",
                "timestamp": datetime.utcnow().isoformat()
            },
            websocket
        )
        
        logger.info(f"New WebSocket connection. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        """
        Remove a WebSocket connection
        
        Args:
            websocket: WebSocket connection to remove
        """
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        
        if websocket in self.connection_info:
            del self.connection_info[websocket]
        
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        """
        Send a message to a specific client
        
        Args:
            message: Message to send
            websocket: Target WebSocket connection
        """
        try:
            await websocket.send_json(message)
            
            if websocket in self.connection_info:
                self.connection_info[websocket]["message_count"] += 1
                
        except Exception as e:
            logger.error(f"Error sending personal message: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, message: Dict[str, Any]):
        """
        Broadcast a message to all connected clients.

        Snapshots the connection list before iterating so that concurrent
        connects/disconnects (which can happen between await points) do not
        cause RuntimeError from list mutation during iteration.
        """
        # Take a snapshot so mutations during await points don't affect this pass
        connections = list(self.active_connections)
        disconnected = []

        for connection in connections:
            try:
                await connection.send_json(message)

                if connection in self.connection_info:
                    self.connection_info[connection]["message_count"] += 1

            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected.append(connection)

        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)

        if connections:
            logger.debug(f"Broadcast message to {len(connections)} clients")
    
    def get_connection_count(self) -> int:
        """
        Get the number of active connections
        
        Returns:
            Number of active connections
        """
        return len(self.active_connections)
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """
        Get connection statistics
        
        Returns:
            Connection statistics
        """
        return {
            "active_connections": len(self.active_connections),
            "total_messages_sent": sum(
                info["message_count"] for info in self.connection_info.values()
            ),
            "connections": [
                {
                    "connected_at": info["connected_at"].isoformat(),
                    "message_count": info["message_count"]
                }
                for info in self.connection_info.values()
            ]
        }
