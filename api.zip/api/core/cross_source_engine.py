"""
Cross-Source Engine.

Two modes:
  1. SQL cross-source  — execute SQL on two SqlConnector instances, then JOIN/UNION in-memory
  2. Parquet cross-connection — run the OptimizedParquetEngine on two different connection
     directories and UNION (stack rows) or JOIN (merge by key) the results in-memory

Both modes save the final DataFrame as a CSV to the downloads directory.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .connectors import get_connector

logger = logging.getLogger(__name__)


# ── Result model ──────────────────────────────────────────────────────────────

class CrossSourceResult:
    def __init__(
        self,
        execution_id: str,
        output_path: str,
        total_rows: int,
        columns: List[str],
        duration_seconds: float,
        primary_rows: int,
        secondary_rows: int,
    ):
        self.execution_id    = execution_id
        self.output_path     = output_path
        self.total_rows      = total_rows
        self.columns         = columns
        self.duration_seconds = duration_seconds
        self.primary_rows    = primary_rows
        self.secondary_rows  = secondary_rows

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id":     self.execution_id,
            "output_path":      self.output_path,
            "total_rows":       self.total_rows,
            "columns":          self.columns,
            "duration_seconds": self.duration_seconds,
            "primary_rows":     self.primary_rows,
            "secondary_rows":   self.secondary_rows,
        }


# ── Engine ────────────────────────────────────────────────────────────────────

def execute_cross_source_query(
    *,
    primary_conn_type:    str,
    primary_conn_config:  Dict[str, Any],
    primary_sql:          str,
    secondary_conn_type:  str,
    secondary_conn_config: Dict[str, Any],
    secondary_sql:        str,
    join_config:          Dict[str, Any],
    output_dir:           str = "./data/downloads",
    execution_id:         Optional[str] = None,
    row_limit:            Optional[int] = None,
    progress_callback=None,
) -> CrossSourceResult:
    """
    Execute SQL on two separate data sources and return a joined result.

    Args:
        primary_conn_type:    Connector type for source A ("trino", "snowflake", etc.)
        primary_conn_config:  Config dict for source A
        primary_sql:          SQL to run on source A
        secondary_conn_type:  Connector type for source B
        secondary_conn_config: Config dict for source B
        secondary_sql:        SQL to run on source B
        join_config: {
            "how":        "inner" | "left" | "right" | "outer",
            "left_on":    str | List[str],   -- column(s) in primary result
            "right_on":   str | List[str],   -- column(s) in secondary result
            "suffixes":   [str, str]         -- optional, default ["_a", "_b"]
        }
        output_dir:           Directory to write the CSV result
        execution_id:         Optional ID; generated if not provided
        row_limit:            Max rows per source query
        progress_callback:    Optional callable(dict) for progress updates

    Returns:
        CrossSourceResult with output CSV path and metadata
    """
    execution_id = execution_id or str(uuid.uuid4())
    t_start = datetime.utcnow()

    def _emit(step: str, **kwargs):
        if progress_callback:
            try:
                progress_callback({"step": step, "execution_id": execution_id, **kwargs})
            except Exception:
                pass

    _emit("starting", message="Initializing connectors")

    primary_connector   = None
    secondary_connector = None

    try:
        # ── Step 1: Execute primary query ─────────────────────────────────────
        _emit("primary_query", message="Executing primary source query")
        primary_connector = get_connector(primary_conn_type, primary_conn_config)
        primary_result = primary_connector.execute_query(primary_sql, limit=row_limit)
        df_a = pd.DataFrame(primary_result["rows"])
        _emit("primary_done", message=f"Primary: {len(df_a)} rows", primary_rows=len(df_a))
        logger.info(f"[{execution_id}] Primary query returned {len(df_a)} rows")

        # ── Step 2: Execute secondary query ───────────────────────────────────
        _emit("secondary_query", message="Executing secondary source query")
        secondary_connector = get_connector(secondary_conn_type, secondary_conn_config)
        secondary_result = secondary_connector.execute_query(secondary_sql, limit=row_limit)
        df_b = pd.DataFrame(secondary_result["rows"])
        _emit("secondary_done", message=f"Secondary: {len(df_b)} rows", secondary_rows=len(df_b))
        logger.info(f"[{execution_id}] Secondary query returned {len(df_b)} rows")

        # ── Step 3: In-memory join ────────────────────────────────────────────
        _emit("joining", message="Performing cross-source join")

        how      = join_config.get("how", "inner")
        left_on  = join_config.get("left_on")
        right_on = join_config.get("right_on")
        suffixes = join_config.get("suffixes", ["_a", "_b"])

        if not left_on or not right_on:
            raise ValueError("join_config must include 'left_on' and 'right_on'")

        if isinstance(left_on,  str): left_on  = [left_on]
        if isinstance(right_on, str): right_on = [right_on]

        df_joined = pd.merge(
            df_a, df_b,
            how=how,
            left_on=left_on,
            right_on=right_on,
            suffixes=suffixes,
        )

        total_rows = len(df_joined)
        logger.info(f"[{execution_id}] Join produced {total_rows} rows ({how})")

        # ── Step 4: Save CSV ──────────────────────────────────────────────────
        _emit("saving", message="Saving results")
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / f"{execution_id}.csv")
        df_joined.to_csv(output_path, index=False)

        duration = (datetime.utcnow() - t_start).total_seconds()
        _emit("completed",
              message=f"Completed: {total_rows} rows in {duration:.1f}s",
              total_rows=total_rows)

        return CrossSourceResult(
            execution_id=execution_id,
            output_path=output_path,
            total_rows=total_rows,
            columns=df_joined.columns.tolist(),
            duration_seconds=round(duration, 3),
            primary_rows=len(df_a),
            secondary_rows=len(df_b),
        )

    finally:
        if primary_connector:
            try:
                primary_connector.close()
            except Exception:
                pass
        if secondary_connector:
            try:
                secondary_connector.close()
            except Exception:
                pass


def execute_single_source_query(
    *,
    conn_type:   str,
    conn_config: Dict[str, Any],
    sql:         str,
    output_dir:  str = "./data/downloads",
    execution_id: Optional[str] = None,
    row_limit:   Optional[int] = None,
    progress_callback=None,
) -> CrossSourceResult:
    """
    Execute SQL on a single SQL connector (no join) and save result as CSV.
    Used when the query runs on exactly one SQL source.
    """
    execution_id = execution_id or str(uuid.uuid4())
    t_start = datetime.utcnow()

    def _emit(step: str, **kwargs):
        if progress_callback:
            try:
                progress_callback({"step": step, "execution_id": execution_id, **kwargs})
            except Exception:
                pass

    _emit("starting", message="Executing SQL query")
    connector = None
    try:
        connector = get_connector(conn_type, conn_config)
        result = connector.execute_query(sql, limit=row_limit)
        df = pd.DataFrame(result["rows"])
        _emit("query_done", message=f"{len(df)} rows returned", total_rows=len(df))

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / f"{execution_id}.csv")
        df.to_csv(output_path, index=False)

        duration = (datetime.utcnow() - t_start).total_seconds()
        _emit("completed", message=f"Completed in {duration:.1f}s", total_rows=len(df))

        return CrossSourceResult(
            execution_id=execution_id,
            output_path=output_path,
            total_rows=len(df),
            columns=df.columns.tolist(),
            duration_seconds=round(duration, 3),
            primary_rows=len(df),
            secondary_rows=0,
        )
    finally:
        if connector:
            try:
                connector.close()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════════════
# Parquet cross-connection UNION / JOIN
# ═══════════════════════════════════════════════════════════════════════════════

def execute_cross_parquet_query(
    *,
    primary_data_dir:   str,
    primary_config:     Dict[str, Any],
    secondary_data_dir: str,
    secondary_config:   Dict[str, Any],
    combine_mode:       str = "union",
    join_config:        Optional[Dict[str, Any]] = None,
    output_dir:         str = "./data/downloads",
    execution_id:       Optional[str] = None,
    progress_callback=None,
) -> CrossSourceResult:
    """
    Execute two independent parquet queries (possibly from different connections)
    and combine the results via UNION or JOIN.

    Args:
        primary_data_dir:   Absolute path to the primary data directory
        primary_config:     QueryConfig dict for primary source
                            Keys: files, joins, filters, columns, limit, offset, order_by
        secondary_data_dir: Absolute path to the secondary data directory
        secondary_config:   QueryConfig dict for secondary source
        combine_mode:       "union" — stack rows (pd.concat, requires compatible columns)
                            "join"  — merge by key columns (pd.merge)
        join_config:        Required when combine_mode="join"
                            { "how": str, "left_on": str|list, "right_on": str|list,
                              "suffixes": [str, str] }
        output_dir:         Where to write the result CSV
        execution_id:       UUID for the execution (generated if not provided)
        progress_callback:  Optional callable(dict) for progress updates

    Returns:
        CrossSourceResult with output CSV path and row counts
    """
    from pathlib import Path as _Path
    from core.optimized_engine import OptimizedParquetEngine, QueryConfig

    execution_id = execution_id or str(uuid.uuid4())
    t_start = datetime.utcnow()

    def _emit(step: str, **kwargs):
        if progress_callback:
            try:
                progress_callback({"step": step, "execution_id": execution_id, **kwargs})
            except Exception:
                pass

    _emit("starting", message="Initializing cross-connection query")

    # ── Helper: execute one parquet engine config → DataFrame ────────────────
    def _run_parquet(data_dir: str, cfg_dict: Dict[str, Any]) -> pd.DataFrame:
        engine = OptimizedParquetEngine(data_dir=data_dir)
        qc = QueryConfig(
            files=cfg_dict.get("files", []),
            joins=cfg_dict.get("joins") or [],
            filters=cfg_dict.get("filters") or [],
            columns=cfg_dict.get("columns") or [],
            limit=cfg_dict.get("limit"),
            offset=cfg_dict.get("offset", 0),
            order_by=cfg_dict.get("order_by") or [],
        )
        chunks = list(engine.execute_query(qc))
        if not chunks:
            return pd.DataFrame()
        return pd.concat(chunks, ignore_index=True)

    # ── Step 1: Primary query ────────────────────────────────────────────────
    _emit("primary_query", message="Executing primary source query")
    try:
        df_a = _run_parquet(primary_data_dir, primary_config)
    except Exception as e:
        raise RuntimeError(f"Primary parquet query failed: {e}") from e
    _emit("primary_done", message=f"Primary: {len(df_a)} rows", primary_rows=len(df_a))
    logger.info(f"[{execution_id}] Primary parquet query: {len(df_a)} rows from {primary_data_dir}")

    # ── Step 2: Secondary query ──────────────────────────────────────────────
    _emit("secondary_query", message="Executing secondary source query")
    try:
        df_b = _run_parquet(secondary_data_dir, secondary_config)
    except Exception as e:
        raise RuntimeError(f"Secondary parquet query failed: {e}") from e
    _emit("secondary_done", message=f"Secondary: {len(df_b)} rows", secondary_rows=len(df_b))
    logger.info(f"[{execution_id}] Secondary parquet query: {len(df_b)} rows from {secondary_data_dir}")

    # ── Step 3: Combine ──────────────────────────────────────────────────────
    _emit("combining", message=f"Combining results via {combine_mode.upper()}")

    if combine_mode == "union":
        # UNION: stack rows — align columns by name, fill missing with NaN
        df_result = pd.concat([df_a, df_b], ignore_index=True, sort=False)
        logger.info(f"[{execution_id}] UNION: {len(df_a)} + {len(df_b)} = {len(df_result)} rows")

    elif combine_mode == "join":
        if not join_config:
            raise ValueError("join_config is required when combine_mode='join'")
        how      = join_config.get("how", "inner")
        left_on  = join_config.get("left_on")
        right_on = join_config.get("right_on")
        suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
        if not left_on or not right_on:
            raise ValueError("join_config must specify 'left_on' and 'right_on'")
        if isinstance(left_on,  str): left_on  = [left_on]
        if isinstance(right_on, str): right_on = [right_on]
        df_result = pd.merge(df_a, df_b, how=how, left_on=left_on, right_on=right_on, suffixes=suffixes)
        logger.info(f"[{execution_id}] {how.upper()} JOIN → {len(df_result)} rows")

    else:
        raise ValueError(f"Unknown combine_mode '{combine_mode}'. Use 'union' or 'join'.")

    # ── Step 4: Save CSV ─────────────────────────────────────────────────────
    _emit("saving", message=f"Saving {len(df_result)} rows")
    out_dir = _Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(out_dir / f"{execution_id}.csv")
    df_result.to_csv(output_path, index=False)

    duration = (datetime.utcnow() - t_start).total_seconds()
    _emit("completed", message=f"Done: {len(df_result)} rows in {duration:.1f}s", total_rows=len(df_result))

    return CrossSourceResult(
        execution_id=execution_id,
        output_path=output_path,
        total_rows=len(df_result),
        columns=df_result.columns.tolist(),
        duration_seconds=round(duration, 3),
        primary_rows=len(df_a),
        secondary_rows=len(df_b),
    )
