"""
Credential encryption for Query Studio connection configs.

Sensitive fields (passwords, tokens, private keys) are encrypted at rest using
Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).

Key resolution order:
  1. QUERY_STUDIO_SECRET_KEY environment variable (base64url-encoded Fernet key)
  2. Auto-generated ephemeral key (for development — not persistent across restarts)

For production / OpenShift deployments, set QUERY_STUDIO_SECRET_KEY as a secret env var.
To generate a valid key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict

logger = logging.getLogger(__name__)

# Prefix that marks an already-encrypted value — allows idempotent encrypt/decrypt
_ENC_PREFIX = "enc::"

# Config field names that contain credentials and must be encrypted at rest
SENSITIVE_FIELDS: frozenset[str] = frozenset([
    "password",
    "token",
    "access_token",
    "aws_secret_access_key",
    "private_key",
    "private_key_passphrase",
])

_fernet = None  # module-level singleton, initialized lazily


def _build_fernet():
    from cryptography.fernet import Fernet

    key = os.environ.get("QUERY_STUDIO_SECRET_KEY", "").strip()
    if key:
        try:
            return Fernet(key.encode() if isinstance(key, str) else key)
        except Exception as e:
            logger.error("QUERY_STUDIO_SECRET_KEY is invalid: %s. Generating ephemeral key.", e)

    # No valid key provided — generate an ephemeral one.
    # Credentials encrypted with this key cannot be decrypted after restart.
    new_key = Fernet.generate_key().decode()
    os.environ["QUERY_STUDIO_SECRET_KEY"] = new_key
    logger.warning(
        "QUERY_STUDIO_SECRET_KEY not set — using an ephemeral encryption key. "
        "Credentials will NOT survive an application restart. "
        "Set QUERY_STUDIO_SECRET_KEY in your environment for persistent encryption."
    )
    return Fernet(new_key.encode())


def _get_fernet():
    global _fernet
    if _fernet is None:
        _fernet = _build_fernet()
    return _fernet


# ── Public API ─────────────────────────────────────────────────────────────────

def encrypt_value(plaintext: str) -> str:
    """Encrypt a single string value.  Returns ``enc::<base64token>``."""
    if not plaintext:
        return plaintext
    if plaintext.startswith(_ENC_PREFIX):
        return plaintext  # already encrypted — idempotent
    token = _get_fernet().encrypt(plaintext.encode()).decode()
    return f"{_ENC_PREFIX}{token}"


def decrypt_value(value: str) -> str:
    """Decrypt a single encrypted value.  Pass-through for unencrypted strings."""
    if not value or not value.startswith(_ENC_PREFIX):
        return value
    token = value[len(_ENC_PREFIX):]
    try:
        return _get_fernet().decrypt(token.encode()).decode()
    except Exception:
        logger.error(
            "Credential decryption failed — key mismatch or corrupted value. "
            "Check QUERY_STUDIO_SECRET_KEY."
        )
        return ""  # return empty rather than crash; callers will fail at connect time


def encrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields encrypted."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        val = result.get(field)
        if val and isinstance(val, str):
            result[field] = encrypt_value(val)
    return result


def decrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields decrypted."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        val = result.get(field)
        if val and isinstance(val, str):
            result[field] = decrypt_value(val)
    return result


def mask_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with sensitive fields replaced by ``"***"``.
    Safe to return to API clients / browser."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        if result.get(field):
            result[field] = "***"
    return result
