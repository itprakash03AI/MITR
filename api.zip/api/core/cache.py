import threading
import time
from typing import Any, Optional

class TTLCache:
    def __init__(self, ttl_seconds: int = 300):
        self._cache = {}
        self._lock = threading.Lock()
        self._ttl = ttl_seconds

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._cache.get(key)
            if entry and time.time() - entry['time'] < self._ttl:
                return entry['value']
            elif entry:
                del self._cache[key]
            return None

    def set(self, key: str, value: Any):
        with self._lock:
            self._cache[key] = {'value': value, 'time': time.time()}

    def invalidate(self, key: str = None):
        with self._lock:
            if key:
                self._cache.pop(key, None)
            else:
                self._cache.clear()

# Global caches
schema_cache = TTLCache(ttl_seconds=300)   # 5 min for schemas
file_list_cache = TTLCache(ttl_seconds=120)  # 2 min for file listings
