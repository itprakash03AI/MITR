"""
Trino / Starburst connector.
Supports both on-premises and cloud Starburst Galaxy deployments.

Required config keys:
  host          – Trino/Starburst host (e.g. "trino.example.com")
  port          – int, default 443 for HTTPS or 8080 for HTTP
  user          – authenticating user
  auth_type     – "basic" | "jwt" | "kerberos" | "oauth2" | "none"
  password      – for basic auth
  token         – for JWT/Bearer token auth
  catalog       – default catalog (optional)
  schema        – default schema (optional)
  http_scheme   – "https" | "http", default "https"
  verify_ssl    – bool, default True
  extra_headers – dict of extra HTTP headers (optional)
  session_props – dict of Trino session properties (optional)
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector

logger = logging.getLogger(__name__)


class TrinoConnector(SqlConnector):
    """Connector for Trino / Starburst Enterprise / Starburst Galaxy."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            return self._conn
        try:
            import trino
            from trino.auth import BasicAuthentication, JWTAuthentication
        except ImportError:
            raise RuntimeError(
                "trino package is not installed. "
                "Add 'trino' to requirements.txt and restart the backend."
            )

        host       = self.config["host"]
        port       = int(self.config.get("port", 443))
        user       = self.config.get("user", "query_studio")
        auth_type  = self.config.get("auth_type", "none").lower()
        http_scheme = self.config.get("http_scheme", "https")
        verify_ssl = self.config.get("verify_ssl", True)
        catalog    = self.config.get("catalog")
        schema     = self.config.get("schema")
        extra_hdr  = self.config.get("extra_headers", {}) or {}
        session_p  = self.config.get("session_props", {}) or {}

        auth = None
        if auth_type == "basic":
            auth = BasicAuthentication(user, self.config.get("password", ""))
        elif auth_type in ("jwt", "bearer"):
            auth = JWTAuthentication(self.config.get("token", ""))

        kwargs = dict(
            host=host,
            port=port,
            user=user,
            auth=auth,
            http_scheme=http_scheme,
            verify=verify_ssl,
            http_headers=extra_hdr,
            session_properties=session_p,
        )
        if catalog:
            kwargs["catalog"] = catalog
        if schema:
            kwargs["schema"] = schema

        self._conn = trino.dbapi.connect(**kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    def _fetchall_as_dicts(self, cursor) -> List[Dict[str, Any]]:
        desc = cursor.description or []
        col_names = [d[0] for d in desc]
        return [dict(zip(col_names, row)) for row in cursor.fetchall()]

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        try:
            cur = self._cursor()
            cur.execute("SELECT 1")
            cur.fetchone()
            cur.execute("SELECT current_version()")
            row = cur.fetchone()
            version = row[0] if row else "unknown"
            return {
                "success": True,
                "message": f"Connected to Trino/Starburst version {version}",
                "details": {"version": version, "host": self.config.get("host")},
            }
        except Exception as e:
            logger.exception("Trino test_connection failed")
            return {"success": False, "message": str(e), "details": {}}

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        cur = self._cursor()
        cur.execute("SHOW CATALOGS")
        return [row[0] for row in cur.fetchall()]

    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._cursor()
        cur.execute(f"SHOW SCHEMAS FROM {catalog}")
        return [row[0] for row in cur.fetchall()]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(f"SHOW TABLES FROM {catalog}.{schema}")
        return [
            {"name": row[0], "type": "TABLE", "catalog": catalog, "schema": schema}
            for row in cur.fetchall()
        ]

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(f"DESCRIBE {catalog}.{schema}.{table}")
        rows = cur.fetchall()
        # Trino DESCRIBE: Column, Type, Extra, Comment
        return [
            {"name": r[0], "type": r[1], "nullable": True, "ordinal": i}
            for i, r in enumerate(rows)
        ]

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        cur = self._cursor()
        cur.execute(sql)
        desc = cur.description or []
        col_info = [{"name": d[0], "type": str(d[1])} for d in desc]
        rows_raw = cur.fetchall()
        col_names = [d[0] for d in desc]
        rows = [dict(zip(col_names, row)) for row in rows_raw]
        return {"columns": col_info, "rows": rows, "total_rows": len(rows)}
