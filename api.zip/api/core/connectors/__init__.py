"""
SQL Connector factory.

Usage:
    from backend.core.connectors import get_connector

    connector = get_connector(connection_type, config)
    result = connector.execute_query("SELECT 1")
    connector.close()

Supported types:
    "trino"      / "starburst"  – Trino / Starburst on-prem or Galaxy
    "snowflake"                  – Snowflake cloud
    "databricks"                 – Databricks SQL Warehouse
"""

from typing import Any, Dict

from .base import SqlConnector

_REGISTRY: Dict[str, str] = {
    "trino":      "trino_connector.TrinoConnector",
    "starburst":  "trino_connector.TrinoConnector",
    "snowflake":  "snowflake_connector.SnowflakeConnector",
    "databricks": "databricks_connector.DatabricksConnector",
}

# Display-friendly names for the UI
CONNECTOR_DISPLAY_NAMES = {
    "trino":      "Trino",
    "starburst":  "Starburst",
    "snowflake":  "Snowflake",
    "databricks": "Databricks SQL",
}

# Config field definitions for each connector type (used by the frontend form)
CONNECTOR_FIELDS: Dict[str, list] = {
    "trino": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
    ],
    "starburst": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
    ],
    "snowflake": [
        {"key": "account",     "label": "Account",       "type": "text",     "required": True,
         "placeholder": "xy12345.us-east-1"},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["password", "key_pair", "oauth"], "default": "password"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "password"}},
        {"key": "private_key", "label": "Private Key (PEM)", "type": "textarea", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "private_key_passphrase", "label": "Key Passphrase", "type": "password", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "token",       "label": "OAuth Token",   "type": "password", "required": False, "showIf": {"auth_type": "oauth"}},
        {"key": "warehouse",   "label": "Warehouse",     "type": "text",     "required": False},
        {"key": "database",    "label": "Database",      "type": "text",     "required": False},
        {"key": "schema",      "label": "Default Schema", "type": "text",    "required": False},
        {"key": "role",        "label": "Role",          "type": "text",     "required": False},
    ],
    "databricks": [
        {"key": "server_hostname", "label": "Server Hostname", "type": "text",     "required": True,
         "placeholder": "adb-1234567890.12.azuredatabricks.net"},
        {"key": "http_path",       "label": "HTTP Path",       "type": "text",     "required": True,
         "placeholder": "/sql/1.0/warehouses/abc123def456"},
        {"key": "access_token",    "label": "Access Token",    "type": "password", "required": True},
        {"key": "catalog",         "label": "Default Catalog", "type": "text",     "required": False},
        {"key": "schema",          "label": "Default Schema",  "type": "text",     "required": False},
    ],
}


def get_connector(connection_type: str, config: Dict[str, Any]) -> SqlConnector:
    """
    Instantiate and return the correct SqlConnector for `connection_type`.

    Args:
        connection_type: one of "trino", "starburst", "snowflake", "databricks"
        config: the connection-specific configuration dict stored in the DB

    Returns:
        SqlConnector instance (not yet connected — call test_connection or execute_query)

    Raises:
        ValueError: if connection_type is unsupported
        RuntimeError: if the required driver package is not installed
    """
    entry = _REGISTRY.get(connection_type.lower())
    if not entry:
        supported = ", ".join(sorted(_REGISTRY.keys()))
        raise ValueError(
            f"Unsupported connection type '{connection_type}'. "
            f"Supported: {supported}"
        )

    module_name, class_name = entry.rsplit(".", 1)
    # Lazy import within this package
    import importlib
    module = importlib.import_module(f".{module_name}", package=__name__)
    cls = getattr(module, class_name)
    return cls(config)


SQL_CONNECTOR_TYPES = list(_REGISTRY.keys())
