"""
Snowflake connector.

Required config keys:
  account       – Snowflake account identifier (e.g. "xy12345.us-east-1")
  user          – Snowflake username
  auth_type     – "password" | "key_pair" | "oauth"
  password      – for password auth
  private_key   – PEM private key string (for key_pair auth)
  private_key_passphrase – optional passphrase for private key
  token         – for oauth
  warehouse     – virtual warehouse name (optional)
  database      – default database (optional)
  schema        – default schema (optional)
  role          – Snowflake role (optional)
  login_timeout – seconds, default 30
  network_timeout – seconds, default 60
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector

logger = logging.getLogger(__name__)


class SnowflakeConnector(SqlConnector):
    """Connector for Snowflake cloud data platform."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            try:
                # Quick ping to verify connection is alive
                self._conn.cursor().execute("SELECT 1")
                return self._conn
            except Exception:
                self._conn = None

        try:
            import snowflake.connector
        except ImportError:
            raise RuntimeError(
                "snowflake-connector-python is not installed. "
                "Add 'snowflake-connector-python' to requirements.txt."
            )

        auth_type = self.config.get("auth_type", "password").lower()
        conn_kwargs: Dict[str, Any] = dict(
            account=self.config["account"],
            user=self.config["user"],
            login_timeout=int(self.config.get("login_timeout", 30)),
            network_timeout=int(self.config.get("network_timeout", 60)),
        )

        # Optional context
        if self.config.get("warehouse"):
            conn_kwargs["warehouse"] = self.config["warehouse"]
        if self.config.get("database"):
            conn_kwargs["database"] = self.config["database"]
        if self.config.get("schema"):
            conn_kwargs["schema"] = self.config["schema"]
        if self.config.get("role"):
            conn_kwargs["role"] = self.config["role"]

        if auth_type == "password":
            conn_kwargs["password"] = self.config.get("password", "")
        elif auth_type == "key_pair":
            from cryptography.hazmat.backends import default_backend
            from cryptography.hazmat.primitives.serialization import (
                Encoding, NoEncryption, PrivateFormat,
                load_pem_private_key,
            )
            pem = self.config["private_key"].encode()
            passphrase = self.config.get("private_key_passphrase")
            if passphrase:
                passphrase = passphrase.encode()
            private_key_obj = load_pem_private_key(pem, password=passphrase, backend=default_backend())
            conn_kwargs["private_key"] = private_key_obj.private_bytes(
                Encoding.DER, PrivateFormat.PKCS8, NoEncryption()
            )
        elif auth_type == "oauth":
            conn_kwargs["token"] = self.config.get("token", "")
            conn_kwargs["authenticator"] = "oauth"

        self._conn = snowflake.connector.connect(**conn_kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor(snowflake.connector.DictCursor
                                             if False else None)

    def _dict_cursor(self):
        try:
            import snowflake.connector
            return self._get_connection().cursor(snowflake.connector.DictCursor)
        except Exception:
            return self._get_connection().cursor()

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        try:
            cur = self._get_connection().cursor()
            cur.execute("SELECT CURRENT_VERSION(), CURRENT_USER(), CURRENT_ROLE()")
            row = cur.fetchone()
            version, user, role = (row or ("?", "?", "?"))[:3]
            return {
                "success": True,
                "message": f"Connected to Snowflake {version} as {user} ({role})",
                "details": {
                    "version": version,
                    "user": user,
                    "role": role,
                    "account": self.config.get("account"),
                },
            }
        except Exception as e:
            logger.exception("Snowflake test_connection failed")
            return {"success": False, "message": str(e), "details": {}}

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        cur = self._get_connection().cursor()
        cur.execute("SHOW DATABASES")
        rows = cur.fetchall()
        # Column 1 is "name" in SHOW DATABASES output
        return [r[1] for r in rows]

    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._get_connection().cursor()
        cur.execute(f"SHOW SCHEMAS IN DATABASE {catalog}")
        rows = cur.fetchall()
        return [r[1] for r in rows]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        cur = self._get_connection().cursor()
        cur.execute(f"SHOW TABLES IN {catalog}.{schema}")
        rows = cur.fetchall()
        # col 1=name, col 3=kind (TABLE/VIEW)
        return [
            {"name": r[1], "type": r[3] if len(r) > 3 else "TABLE",
             "catalog": catalog, "schema": schema}
            for r in rows
        ]

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._get_connection().cursor()
        cur.execute(f"DESCRIBE TABLE {catalog}.{schema}.{table}")
        rows = cur.fetchall()
        # col 0=name, col 1=type, col 3=null?
        return [
            {
                "name": r[0],
                "type": r[1],
                "nullable": (r[3].upper() == "Y") if len(r) > 3 else True,
                "ordinal": i,
            }
            for i, r in enumerate(rows)
        ]

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        conn = self._get_connection()
        cur = conn.cursor()
        cur.execute(sql)
        desc = cur.description or []
        col_info = [{"name": d[0], "type": str(d[1])} for d in desc]
        col_names = [d[0] for d in desc]
        rows_raw = cur.fetchall()
        rows = [dict(zip(col_names, row)) for row in rows_raw]
        return {"columns": col_info, "rows": rows, "total_rows": len(rows)}
