"""
Abstract base class for SQL data source connectors.
All SQL connectors (Trino/Starburst, Snowflake, Databricks) implement this interface.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class SqlConnector(ABC):
    """
    Base class for all SQL source connectors.
    Config dict is passed at construction time — all connection parameters come
    from the stored connection record (no hardcoded values).
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    # ── Connection lifecycle ──────────────────────────────────────────────────

    @abstractmethod
    def test_connection(self) -> Dict[str, Any]:
        """
        Verify connectivity.
        Returns: { "success": bool, "message": str, "details": {...} }
        """

    @abstractmethod
    def close(self):
        """Release any held resources / connection pools."""

    # ── Schema browsing ───────────────────────────────────────────────────────

    @abstractmethod
    def list_catalogs(self) -> List[str]:
        """Return list of catalog names (databases in Snowflake, catalogs in Trino)."""

    @abstractmethod
    def list_schemas(self, catalog: str) -> List[str]:
        """Return list of schema names within the given catalog."""

    @abstractmethod
    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """
        Return list of table info dicts:
        [{ "name": str, "type": "TABLE"|"VIEW", "catalog": str, "schema": str }]
        """

    @abstractmethod
    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """
        Return column metadata:
        [{ "name": str, "type": str, "nullable": bool, "ordinal": int }]
        """

    # ── Query execution ───────────────────────────────────────────────────────

    @abstractmethod
    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a SQL statement and return results as a dict:
        {
            "columns": [{ "name": str, "type": str }],
            "rows":    list[dict],
            "total_rows": int,
        }
        Implementations should apply `limit` if provided (adds LIMIT clause or
        uses cursor row-limit to avoid fetching millions of rows without intent).
        """

    # ── Helper ───────────────────────────────────────────────────────────────

    def _apply_limit(self, sql: str, limit: Optional[int]) -> str:
        """Append LIMIT clause if not already present and limit is specified."""
        if limit is None:
            return sql
        stripped = sql.strip().rstrip(';')
        upper = stripped.upper()
        if ' LIMIT ' not in upper:
            return f"{stripped}\nLIMIT {limit}"
        return stripped
