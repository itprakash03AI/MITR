"""
Databricks SQL connector.
Supports Databricks SQL Warehouses (formerly SQL Endpoints) and clusters.

Required config keys:
  server_hostname  – e.g. "adb-1234567890.12.azuredatabricks.net"
  http_path        – SQL Warehouse HTTP path,
                     e.g. "/sql/1.0/warehouses/abc123def456"
  access_token     – Personal Access Token or Service Principal token
  catalog          – Unity Catalog catalog name (optional, default "hive_metastore")
  schema           – default schema (optional)
  http_headers     – list of [key, value] pairs (optional)
  session_config   – dict of Spark conf keys (optional)
  max_download_threads – int, default 10
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector

logger = logging.getLogger(__name__)


class DatabricksConnector(SqlConnector):
    """Connector for Databricks SQL Warehouses."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            return self._conn
        try:
            from databricks import sql as dbsql
        except ImportError:
            raise RuntimeError(
                "databricks-sql-connector is not installed. "
                "Add 'databricks-sql-connector' to requirements.txt."
            )

        kwargs: Dict[str, Any] = dict(
            server_hostname=self.config["server_hostname"],
            http_path=self.config["http_path"],
            access_token=self.config["access_token"],
        )

        if self.config.get("catalog"):
            kwargs["catalog"] = self.config["catalog"]
        if self.config.get("schema"):
            kwargs["schema"] = self.config["schema"]
        if self.config.get("http_headers"):
            # stored as list of [key, val] pairs
            kwargs["http_headers"] = self.config["http_headers"]
        if self.config.get("session_config"):
            kwargs["session_configuration"] = self.config["session_config"]
        if self.config.get("max_download_threads"):
            kwargs["max_download_threads"] = int(self.config["max_download_threads"])

        self._conn = dbsql.connect(**kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        try:
            with self._cursor() as cur:
                cur.execute("SELECT 1 AS ping")
                cur.fetchone()
            # Get cluster/warehouse version info
            try:
                with self._cursor() as cur:
                    cur.execute("SELECT version()")
                    row = cur.fetchone()
                    version = row[0] if row else "unknown"
            except Exception:
                version = "unknown"
            return {
                "success": True,
                "message": f"Connected to Databricks SQL ({version})",
                "details": {
                    "version": version,
                    "server": self.config.get("server_hostname"),
                    "http_path": self.config.get("http_path"),
                },
            }
        except Exception as e:
            logger.exception("Databricks test_connection failed")
            return {"success": False, "message": str(e), "details": {}}

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        try:
            with self._cursor() as cur:
                cur.execute("SHOW CATALOGS")
                rows = cur.fetchall()
                # Unity Catalog: column 0 is catalog name
                return [r[0] for r in rows]
        except Exception:
            # Fallback for non-Unity Catalog workspaces
            with self._cursor() as cur:
                cur.execute("SHOW DATABASES")
                rows = cur.fetchall()
                return [r[0] for r in rows]

    def list_schemas(self, catalog: str) -> List[str]:
        with self._cursor() as cur:
            cur.execute(f"SHOW SCHEMAS IN {catalog}")
            rows = cur.fetchall()
            return [r[0] for r in rows]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        with self._cursor() as cur:
            cur.execute(f"SHOW TABLES IN {catalog}.{schema}")
            rows = cur.fetchall()
            desc = [d[0] for d in cur.description]
            result = []
            for row in rows:
                r = dict(zip(desc, row))
                result.append({
                    "name": r.get("tableName") or r.get("name") or row[0],
                    "type": "VIEW" if r.get("isTemporary") else "TABLE",
                    "catalog": catalog,
                    "schema": schema,
                })
            return result

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        with self._cursor() as cur:
            cur.execute(f"DESCRIBE TABLE {catalog}.{schema}.{table}")
            rows = cur.fetchall()
            result = []
            for i, row in enumerate(rows):
                if not row[0] or row[0].startswith('#'):
                    continue
                result.append({
                    "name": row[0],
                    "type": row[1] if len(row) > 1 else "string",
                    "nullable": True,
                    "ordinal": i,
                    "comment": row[2] if len(row) > 2 else None,
                })
            return result

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        with self._cursor() as cur:
            cur.execute(sql)
            desc = cur.description or []
            col_info = [{"name": d[0], "type": str(d[1])} for d in desc]
            col_names = [d[0] for d in desc]
            rows_raw = cur.fetchall()
            rows = [dict(zip(col_names, row)) for row in rows_raw]
        return {"columns": col_info, "rows": rows, "total_rows": len(rows)}
