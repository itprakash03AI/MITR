"""
Enterprise Parquet Query Engine with S3 Support
Memory-efficient processing for large-scale parquet files from local and S3 storage
"""

import pyarrow.parquet as pq
import pyarrow.compute as pc
import pyarrow as pa
import pyarrow.csv as pacsv  # type: ignore[import]
import pandas as pd
from typing import List, Dict, Any, Optional, Generator, Union
from pathlib import Path
import logging
import time
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from enum import Enum

from core.s3_storage import S3StorageHandler, S3Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class StorageType(Enum):
    """Storage type enumeration"""
    LOCAL = "local"
    S3 = "s3"


@dataclass
class FileReference:
    """Reference to a parquet file in local or S3 storage"""
    path: str
    storage_type: StorageType
    s3_bucket: Optional[str] = None
    
    def __str__(self):
        if self.storage_type == StorageType.S3:
            return f"s3://{self.s3_bucket}/{self.path}"
        return self.path


@dataclass
class JoinConfig:
    """Configuration for joining parquet files"""
    left_file: Union[str, FileReference]
    right_file: Union[str, FileReference]
    left_on: List[str]
    right_on: List[str]
    how: str = 'inner'  # inner, left, right, outer


@dataclass
class QueryConfig:
    """Configuration for query execution"""
    files: List[Union[str, FileReference]]
    joins: Optional[List[JoinConfig]] = None
    filters: Optional[List[Dict[str, Any]]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[Dict[str, str]]] = None


class ParquetQueryEngine:
    """
    Enterprise-grade Parquet Query Engine with S3 support
    Supports both local and S3 storage with memory-efficient operations
    """
    
    def __init__(self, base_path: str = "./data/parquet", 
                 chunk_size: int = 100000,
                 s3_config: Optional[S3Config] = None):
        """
        Initialize the Parquet Query Engine
        
        Args:
            base_path: Base directory for local parquet files
            chunk_size: Number of rows to process at a time
            s3_config: Optional S3 configuration
        """
        self.base_path = Path(base_path)
        self.chunk_size = chunk_size
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize S3 handler if config provided
        self.s3_handler = None
        if s3_config:
            try:
                self.s3_handler = S3StorageHandler(s3_config)
                logger.info("S3 storage handler initialized")
            except Exception as e:
                logger.error(f"Failed to initialize S3 handler: {e}")
        
        logger.info(f"ParquetQueryEngine initialized with base_path: {self.base_path}")
    
    def set_s3_config(self, s3_config: S3Config):
        """
        Set or update S3 configuration
        
        Args:
            s3_config: S3 configuration
        """
        try:
            self.s3_handler = S3StorageHandler(s3_config)
            logger.info("S3 configuration updated")
        except Exception as e:
            logger.error(f"Failed to set S3 config: {e}")
            raise
    
    def list_s3_folders(self, prefix: str = "") -> List[Dict[str, Any]]:
        """
        List folders in S3 bucket
        
        Args:
            prefix: Prefix to filter folders
            
        Returns:
            List of folder information
        """
        if not self.s3_handler:
            raise ValueError("S3 handler not configured")
        
        return self.s3_handler.list_folders(prefix)
    
    def list_s3_files(self, folder_path: str = "") -> List[Dict[str, Any]]:
        """
        List parquet files in S3 folder
        
        Args:
            folder_path: S3 folder path
            
        Returns:
            List of file information
        """
        if not self.s3_handler:
            raise ValueError("S3 handler not configured")
        
        files = self.s3_handler.list_parquet_files(folder_path)
        
        # Add storage type and schema info
        for file in files:
            file['storage_type'] = 's3'
            try:
                schema = self.s3_handler.get_file_schema(file['key'])
                file['num_rows'] = schema.get('num_rows', 0)
                file['num_columns'] = len(schema.get('columns', []))
                file['columns'] = schema.get('columns', [])
            except Exception as e:
                logger.warning(f"Could not get schema for {file['key']}: {e}")
        
        return files
    
    def list_local_files(self) -> List[Dict[str, Any]]:
        """
        List all available local parquet files with metadata
        
        Returns:
            List of file information dictionaries
        """
        files = []
        for file_path in self.base_path.rglob("*.parquet"):
            try:
                parquet_file = pq.ParquetFile(file_path)
                metadata = parquet_file.metadata
                schema = parquet_file.schema_arrow
                
                files.append({
                    "name": file_path.name,
                    "path": str(file_path.relative_to(self.base_path)),
                    "size_bytes": file_path.stat().st_size,
                    "num_rows": metadata.num_rows,
                    "num_columns": len(schema),
                    "storage_type": "local",
                    "columns": [
                        {
                            "name": field.name,
                            "type": str(field.type)
                        }
                        for field in schema
                    ]
                })
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                continue
        
        return files
    
    def list_files(self, storage_type: Optional[str] = None, 
                   s3_folder: str = "") -> List[Dict[str, Any]]:
        """
        List all available parquet files from local and/or S3 storage
        
        Args:
            storage_type: Filter by storage type ('local', 's3', or None for both)
            s3_folder: S3 folder path if listing S3 files
            
        Returns:
            Combined list of files from all sources
        """
        all_files = []
        
        # List local files
        if storage_type is None or storage_type == 'local':
            all_files.extend(self.list_local_files())
        
        # List S3 files
        if (storage_type is None or storage_type == 's3') and self.s3_handler:
            try:
                all_files.extend(self.list_s3_files(s3_folder))
            except Exception as e:
                logger.error(f"Error listing S3 files: {e}")
        
        return all_files
    
    def get_file_schema(self, file_ref: Union[str, FileReference]) -> Dict[str, Any]:
        """
        Get detailed schema information for a parquet file
        
        Args:
            file_ref: File reference (path string or FileReference object)
            
        Returns:
            Schema information dictionary
        """
        # Convert string to FileReference if needed
        if isinstance(file_ref, str):
            if file_ref.startswith('s3://'):
                # Parse S3 URL
                parts = file_ref[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                file_ref = FileReference(key, StorageType.S3, bucket)
            else:
                file_ref = FileReference(file_ref, StorageType.LOCAL)
        
        # Get schema based on storage type
        if file_ref.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            return self.s3_handler.get_file_schema(file_ref.path)
        else:
            # Local file
            full_path = self.base_path / file_ref.path
            if not full_path.exists():
                raise FileNotFoundError(f"File not found: {file_ref.path}")
            
            parquet_file = pq.ParquetFile(full_path)
            schema = parquet_file.schema_arrow
            
            return {
                "file": file_ref.path,
                "storage_type": "local",
                "columns": [
                    {
                        "name": field.name,
                        "type": str(field.type),
                        "nullable": field.nullable
                    }
                    for field in schema
                ],
                "num_rows": parquet_file.metadata.num_rows
            }
    
    def _apply_filters(self, table: pa.Table, filters: List[Dict[str, Any]]) -> pa.Table:
        """
        Apply filters to a PyArrow table
        
        Args:
            table: PyArrow table
            filters: List of filter conditions
            
        Returns:
            Filtered table
        """
        if not filters:
            return table
        
        mask = None
        
        for filter_condition in filters:
            column = filter_condition["column"]
            operator = filter_condition["operator"]
            value = filter_condition["value"]
            
            # Convert value to appropriate Arrow scalar
            col_type = table.schema.field(column).type
            
            if operator == "eq":
                condition = pc.equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "ne":
                condition = pc.not_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "gt":
                condition = pc.greater(table[column], pa.scalar(value, type=col_type))
            elif operator == "gte":
                condition = pc.greater_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "lt":
                condition = pc.less(table[column], pa.scalar(value, type=col_type))
            elif operator == "lte":
                condition = pc.less_equal(table[column], pa.scalar(value, type=col_type))
            elif operator == "in":
                condition = pc.is_in(table[column], pa.array(value))
            elif operator == "contains":
                condition = pc.match_substring(table[column], value)
            else:
                raise ValueError(f"Unsupported operator: {operator}")
            
            if mask is None:
                mask = condition
            else:
                mask = pc.and_(mask, condition)
        
        return table.filter(mask)
    
    def _read_parquet_chunked(self, file_ref: Union[str, FileReference], 
                              columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file in chunks for memory efficiency
        
        Args:
            file_ref: File reference
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        # Convert string to FileReference if needed
        if isinstance(file_ref, str):
            if file_ref.startswith('s3://'):
                parts = file_ref[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                file_ref = FileReference(key, StorageType.S3, bucket)
            else:
                file_ref = FileReference(file_ref, StorageType.LOCAL)
        
        if file_ref.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            
            for chunk in self.s3_handler.read_parquet_chunked(
                file_ref.path, self.chunk_size, columns
            ):
                yield chunk
        else:
            # Local file
            full_path = self.base_path / file_ref.path
            parquet_file = pq.ParquetFile(full_path)
            
            for batch in parquet_file.iter_batches(batch_size=self.chunk_size, columns=columns):
                yield pa.Table.from_batches([batch])
    
    def execute_query(self, query_config: QueryConfig) -> Generator[pd.DataFrame, None, None]:
        """
        Execute a query with joins, filters, and projections
        Memory-efficient streaming implementation for large datasets
        
        Args:
            query_config: Query configuration object
            
        Yields:
            Pandas DataFrame chunks
        """
        logger.info(f"Executing query with config: {query_config}")
        
        if not query_config.files:
            raise ValueError("At least one file must be specified")
        
        # Read first file
        primary_file = query_config.files[0]
        logger.info(f"Reading primary file: {primary_file}")
        
        # Determine columns to read
        read_columns = query_config.columns if query_config.columns else None
        
        # Process in chunks
        for chunk_idx, table_chunk in enumerate(self._read_parquet_chunked(primary_file, read_columns)):
            logger.info(f"Processing chunk {chunk_idx}, rows: {len(table_chunk)}")
            
            # Apply filters
            if query_config.filters:
                table_chunk = self._apply_filters(table_chunk, query_config.filters)
                if len(table_chunk) == 0:
                    continue
            
            # Perform joins if specified
            if query_config.joins:
                for join_config in query_config.joins:
                    table_chunk = self._perform_join(table_chunk, join_config)
                    if len(table_chunk) == 0:
                        break
            
            # Apply column selection
            if query_config.columns:
                available_cols = [col for col in query_config.columns if col in table_chunk.column_names]
                table_chunk = table_chunk.select(available_cols)
            
            # Apply ordering
            if query_config.order_by:
                table_chunk = self._apply_sorting(table_chunk, query_config.order_by)
            
            # Convert to pandas and yield
            if len(table_chunk) > 0:
                yield table_chunk.to_pandas()
    
    def _perform_join(self, left_table: pa.Table, join_config: JoinConfig) -> pa.Table:
        """
        Perform join operation between tables
        
        Args:
            left_table: Left table
            join_config: Join configuration
            
        Returns:
            Joined table
        """
        # Read the right file
        right_file = join_config.right_file
        
        # For simplicity, read entire right table (consider chunking for very large files)
        if isinstance(right_file, str):
            if right_file.startswith('s3://'):
                parts = right_file[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                right_file = FileReference(key, StorageType.S3, bucket)
            else:
                right_file = FileReference(right_file, StorageType.LOCAL)
        
        if right_file.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            right_table = self.s3_handler.read_parquet(right_file.path)
        else:
            right_path = self.base_path / right_file.path
            right_table = pq.read_table(right_path)
        
        # Convert to pandas for join
        left_df = left_table.to_pandas()
        right_df = right_table.to_pandas()
        
        # Perform join
        merged_df = left_df.merge(
            right_df,
            left_on=join_config.left_on,
            right_on=join_config.right_on,
            how=join_config.how,
            suffixes=('', '_right')
        )
        
        return pa.Table.from_pandas(merged_df)
    
    def _apply_sorting(self, table: pa.Table, order_by: List[Dict[str, str]]) -> pa.Table:
        """
        Apply sorting to table
        
        Args:
            table: PyArrow table
            order_by: List of sort specifications
            
        Returns:
            Sorted table
        """
        df = table.to_pandas()
        
        sort_columns = [item["column"] for item in order_by]
        sort_ascending = [item.get("direction", "asc") == "asc" for item in order_by]
        
        df = df.sort_values(by=sort_columns, ascending=sort_ascending)
        
        return pa.Table.from_pandas(df)
    
    def execute_query_to_csv(self, query_config: QueryConfig, output_path: str,
                            progress_callback: Optional[callable] = None) -> Dict[str, Any]:
        """
        Execute query and save results to CSV with streaming
        
        Args:
            query_config: Query configuration
            output_path: Path to save CSV file
            progress_callback: Optional callback for progress updates
            
        Returns:
            Execution statistics
        """
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        total_rows = 0
        chunk_count = 0
        writer = None

        try:
            for chunk_df in self.execute_query(query_config):
                # Use PyArrow's C++ CSV writer — releases the GIL during I/O so
                # the asyncio event loop stays responsive while chunks are written.
                table = pa.Table.from_pandas(chunk_df, preserve_index=False)
                if writer is None:
                    writer = pacsv.CSVWriter(str(output_file), table.schema)
                writer.write(table)
                time.sleep(0)  # yield GIL between chunks so asyncio event loop stays alive

                total_rows += len(chunk_df)
                chunk_count += 1

                if progress_callback:
                    progress_callback({
                        "chunk": chunk_count,
                        "total_rows": total_rows,
                        "status": "processing"
                    })

                logger.info(f"Written chunk {chunk_count}, total rows: {total_rows}")
            
            if writer is not None:
                writer.close()
            elif not output_file.exists():
                output_file.touch()  # empty result — create file so readers don't 404

            stats = {
                "total_rows": total_rows,
                "chunks_processed": chunk_count,
                "output_file": str(output_file),
                "file_size_bytes": output_file.stat().st_size if output_file.exists() else 0,
                "status": "completed"
            }

            if progress_callback:
                progress_callback(stats)

            logger.info(f"Query execution completed: {stats}")
            return stats

        except Exception as e:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass
            logger.error(f"Error executing query: {e}")
            if progress_callback:
                progress_callback({
                    "status": "failed",
                    "error": str(e)
                })
            raise
    
    def generate_query_id(self, query_config: QueryConfig) -> str:
        """
        Generate unique ID for a query
        
        Args:
            query_config: Query configuration
            
        Returns:
            Unique query ID
        """
        query_str = json.dumps(query_config.__dict__, sort_keys=True, default=str)
        return hashlib.md5(query_str.encode()).hexdigest()
    
    def validate_query(self, query_config: QueryConfig) -> Dict[str, Any]:
        """
        Validate query configuration
        
        Args:
            query_config: Query configuration to validate
            
        Returns:
            Validation result with errors if any
        """
        errors = []
        warnings = []
        
        # Check if files exist
        for file in query_config.files:
            try:
                self.get_file_schema(file)
            except Exception as e:
                errors.append(f"File not found or inaccessible: {file} - {str(e)}")
        
        # Validate join configurations
        if query_config.joins:
            for join in query_config.joins:
                try:
                    self.get_file_schema(join.right_file)
                except Exception as e:
                    errors.append(f"Join file not found: {join.right_file} - {str(e)}")
        
        # Validate columns if specified
        if query_config.columns and query_config.files:
            try:
                schema = self.get_file_schema(query_config.files[0])
                available_cols = {col["name"] for col in schema["columns"]}
                
                for col in query_config.columns:
                    if col not in available_cols:
                        warnings.append(f"Column '{col}' not found in primary file")
            except Exception as e:
                warnings.append(f"Could not validate columns: {str(e)}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
