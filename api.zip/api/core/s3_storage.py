"""
S3 Storage Handler
Manages S3 connections and file operations for Parquet files
"""

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from typing import List, Dict, Any, Optional, Generator
from pathlib import Path
import logging
from dataclasses import dataclass
import pyarrow.parquet as pq
import pyarrow as pa
from io import BytesIO
import tempfile

logger = logging.getLogger(__name__)


@dataclass
class S3Config:
    """S3 Configuration"""
    bucket_name: str
    region_name: str = "us-east-1"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    endpoint_url: Optional[str] = None  # For custom S3-compatible storage


class S3StorageHandler:
    """
    Handles S3 storage operations for Parquet files
    Supports reading from specific folders and file management
    """
    
    def __init__(self, config: S3Config):
        """
        Initialize S3 storage handler
        
        Args:
            config: S3 configuration
        """
        self.config = config
        self.s3_client = None
        self.s3_resource = None
        self._initialize_clients()
    
    def _initialize_clients(self):
        """Initialize S3 client and resource"""
        try:
            session_kwargs = {
                "region_name": self.config.region_name
            }
            
            if self.config.aws_access_key_id and self.config.aws_secret_access_key:
                session_kwargs["aws_access_key_id"] = self.config.aws_access_key_id
                session_kwargs["aws_secret_access_key"] = self.config.aws_secret_access_key
            
            session = boto3.Session(**session_kwargs)
            
            client_kwargs = {}
            resource_kwargs = {}
            
            if self.config.endpoint_url:
                client_kwargs["endpoint_url"] = self.config.endpoint_url
                resource_kwargs["endpoint_url"] = self.config.endpoint_url
            
            self.s3_client = session.client('s3', **client_kwargs)
            self.s3_resource = session.resource('s3', **resource_kwargs)
            
            # Test connection
            self.s3_client.head_bucket(Bucket=self.config.bucket_name)
            logger.info(f"S3 connection established to bucket: {self.config.bucket_name}")
            
        except NoCredentialsError:
            logger.error("AWS credentials not found")
            raise
        except ClientError as e:
            logger.error(f"Failed to connect to S3: {e}")
            raise
    
    def list_folders(self, prefix: str = "") -> List[Dict[str, Any]]:
        """
        List all folders in the S3 bucket
        
        Args:
            prefix: Prefix to filter folders
            
        Returns:
            List of folder information
        """
        try:
            folders = []
            paginator = self.s3_client.get_paginator('list_objects_v2')
            
            # Use delimiter to get folder structure
            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=prefix,
                Delimiter='/'
            )
            
            for page in pages:
                # CommonPrefixes contains the "folders"
                for prefix_obj in page.get('CommonPrefixes', []):
                    folder_path = prefix_obj['Prefix']
                    folders.append({
                        'path': folder_path,
                        'name': folder_path.rstrip('/').split('/')[-1],
                        'type': 'folder'
                    })
            
            logger.info(f"Found {len(folders)} folders with prefix '{prefix}'")
            return folders
            
        except ClientError as e:
            logger.error(f"Error listing folders: {e}")
            raise
    
    def list_parquet_files(self, folder_path: str = "") -> List[Dict[str, Any]]:
        """
        List all parquet files in a specific S3 folder
        
        Args:
            folder_path: S3 folder path (prefix)
            
        Returns:
            List of file information dictionaries
        """
        try:
            files = []
            paginator = self.s3_client.get_paginator('list_objects_v2')
            
            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=folder_path
            )
            
            for page in pages:
                for obj in page.get('Contents', []):
                    key = obj['Key']
                    
                    # Only include .parquet files
                    if key.endswith('.parquet'):
                        # Get file metadata
                        try:
                            head = self.s3_client.head_object(
                                Bucket=self.config.bucket_name,
                                Key=key
                            )
                            
                            files.append({
                                'key': key,
                                'name': key.split('/')[-1],
                                'size_bytes': obj['Size'],
                                'last_modified': obj['LastModified'].isoformat(),
                                'folder': '/'.join(key.split('/')[:-1]) + '/',
                                'storage_class': obj.get('StorageClass', 'STANDARD'),
                                'etag': obj.get('ETag', '').strip('"')
                            })
                        except ClientError as e:
                            logger.warning(f"Could not get metadata for {key}: {e}")
                            continue
            
            logger.info(f"Found {len(files)} parquet files in folder '{folder_path}'")
            return files
            
        except ClientError as e:
            logger.error(f"Error listing files: {e}")
            raise
    
    def get_file_schema(self, s3_key: str) -> Dict[str, Any]:
        """
        Get schema information for a parquet file in S3
        
        Args:
            s3_key: S3 key of the parquet file
            
        Returns:
            Schema information dictionary
        """
        try:
            # Read file into memory (just metadata)
            obj = self.s3_client.get_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            # Read parquet metadata
            buffer = BytesIO(obj['Body'].read())
            parquet_file = pq.ParquetFile(buffer)
            schema = parquet_file.schema_arrow
            metadata = parquet_file.metadata
            
            return {
                'file': s3_key,
                'bucket': self.config.bucket_name,
                'columns': [
                    {
                        'name': field.name,
                        'type': str(field.type),
                        'nullable': field.nullable
                    }
                    for field in schema
                ],
                'num_rows': metadata.num_rows,
                'num_row_groups': metadata.num_row_groups,
                'size_bytes': obj['ContentLength']
            }
            
        except ClientError as e:
            logger.error(f"Error getting schema for {s3_key}: {e}")
            raise
    
    def read_parquet_chunked(self, s3_key: str, chunk_size: int = 100000,
                            columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file from S3 in chunks for memory efficiency
        
        Args:
            s3_key: S3 key of the parquet file
            chunk_size: Number of rows per chunk
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        try:
            # Download to temporary file for efficient chunked reading
            with tempfile.NamedTemporaryFile(delete=True, suffix='.parquet') as tmp_file:
                logger.info(f"Downloading {s3_key} to temporary file...")
                
                self.s3_client.download_fileobj(
                    self.config.bucket_name,
                    s3_key,
                    tmp_file
                )
                
                tmp_file.flush()
                tmp_file.seek(0)
                
                # Read in chunks
                parquet_file = pq.ParquetFile(tmp_file.name)
                
                for batch in parquet_file.iter_batches(batch_size=chunk_size, columns=columns):
                    yield pa.Table.from_batches([batch])
                    
        except ClientError as e:
            logger.error(f"Error reading file {s3_key}: {e}")
            raise
    
    def read_parquet(self, s3_key: str, columns: Optional[List[str]] = None) -> pa.Table:
        """
        Read entire parquet file from S3 into memory
        
        Args:
            s3_key: S3 key of the parquet file
            columns: Optional list of columns to read
            
        Returns:
            PyArrow table
        """
        try:
            obj = self.s3_client.get_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            buffer = BytesIO(obj['Body'].read())
            table = pq.read_table(buffer, columns=columns)
            
            logger.info(f"Read {len(table)} rows from {s3_key}")
            return table
            
        except ClientError as e:
            logger.error(f"Error reading file {s3_key}: {e}")
            raise
    
    def upload_file(self, local_path: str, s3_key: str) -> Dict[str, Any]:
        """
        Upload a file to S3
        
        Args:
            local_path: Local file path
            s3_key: S3 key for the uploaded file
            
        Returns:
            Upload information
        """
        try:
            self.s3_client.upload_file(
                local_path,
                self.config.bucket_name,
                s3_key
            )
            
            # Get file info
            head = self.s3_client.head_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Uploaded file to s3://{self.config.bucket_name}/{s3_key}")
            
            return {
                'bucket': self.config.bucket_name,
                'key': s3_key,
                'size_bytes': head['ContentLength'],
                'etag': head['ETag'].strip('"')
            }
            
        except ClientError as e:
            logger.error(f"Error uploading file: {e}")
            raise
    
    def delete_file(self, s3_key: str) -> bool:
        """
        Delete a file from S3
        
        Args:
            s3_key: S3 key of the file to delete
            
        Returns:
            True if successful
        """
        try:
            self.s3_client.delete_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Deleted file: s3://{self.config.bucket_name}/{s3_key}")
            return True
            
        except ClientError as e:
            logger.error(f"Error deleting file: {e}")
            raise
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test S3 connection and return bucket info
        
        Returns:
            Connection test results
        """
        try:
            # Get bucket location
            location = self.s3_client.get_bucket_location(
                Bucket=self.config.bucket_name
            )
            
            # Count objects
            response = self.s3_client.list_objects_v2(
                Bucket=self.config.bucket_name,
                MaxKeys=1
            )
            
            return {
                'connected': True,
                'bucket': self.config.bucket_name,
                'region': location.get('LocationConstraint', 'us-east-1'),
                'accessible': True
            }
            
        except ClientError as e:
            logger.error(f"Connection test failed: {e}")
            return {
                'connected': False,
                'error': str(e)
            }
    
    def get_folder_tree(self, max_depth: int = 3) -> List[Dict[str, Any]]:
        """
        Get hierarchical folder structure
        
        Args:
            max_depth: Maximum depth to traverse
            
        Returns:
            Hierarchical folder structure
        """
        def get_subfolders(prefix: str, depth: int) -> List[Dict[str, Any]]:
            if depth >= max_depth:
                return []
            
            folders = self.list_folders(prefix)
            result = []
            
            for folder in folders:
                folder_data = {
                    'path': folder['path'],
                    'name': folder['name'],
                    'type': 'folder',
                    'children': get_subfolders(folder['path'], depth + 1)
                }
                result.append(folder_data)
            
            return result
        
        return get_subfolders('', 0)
