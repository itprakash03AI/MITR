# Setup script for Windows with Python 3.13

Write-Host "=== Parquet Query Engine Setup for Python 3.13 ===" -ForegroundColor Green
Write-Host ""

# Check Python version
Write-Host "Checking Python version..." -ForegroundColor Yellow
$pythonVersion = python --version
Write-Host $pythonVersion

if ($pythonVersion -notmatch "3\.13") {
    Write-Host "Warning: Python 3.13 not found or not default" -ForegroundColor Red
    Write-Host "Trying py -3.13..." -ForegroundColor Yellow
    $pythonCmd = "py -3.13"
} else {
    $pythonCmd = "python"
}

# Create virtual environment
Write-Host ""
Write-Host "Creating virtual environment..." -ForegroundColor Yellow
& $pythonCmd -m venv venv

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
venv\Scripts\Activate.ps1

# Upgrade pip
Write-Host ""
Write-Host "Upgrading pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip

# Install dependencies
Write-Host ""
Write-Host "Installing dependencies..." -ForegroundColor Yellow
pip install -r requirements-py313.txt

# Verify installation
Write-Host ""
Write-Host "Verifying installation..." -ForegroundColor Yellow
python -c "import fastapi, pyarrow, boto3, pandas; print('✅ All dependencies installed successfully!')"

Write-Host ""
Write-Host "=== Setup Complete! ===" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Configure .env file (optional for S3)" -ForegroundColor White
Write-Host "2. Generate sample data: python generate_sample_data.py" -ForegroundColor White
Write-Host "3. Run backend: python main_with_s3.py" -ForegroundColor White