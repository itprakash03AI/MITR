"""
Backend Endpoint Diagnostic Tool
Run this to see what endpoints actually work in your backend
"""

import requests
import json

API_BASE = "http://localhost:8000"

def test_endpoint(method, path, data=None, description=""):
    """Test a single endpoint"""
    url = f"{API_BASE}{path}"
    
    try:
        if method == "GET":
            response = requests.get(url, timeout=5)
        elif method == "POST":
            response = requests.post(url, json=data, timeout=5)
        else:
            return {"status": "UNKNOWN", "message": "Unknown method"}
        
        if response.status_code == 200:
            return {
                "status": "✅ WORKS",
                "code": response.status_code,
                "data": response.json() if response.text else None
            }
        else:
            return {
                "status": "❌ FAILS",
                "code": response.status_code,
                "error": response.text[:200]
            }
    except requests.exceptions.ConnectionError:
        return {"status": "🔴 NO CONNECTION", "message": "Backend not running"}
    except Exception as e:
        return {"status": "❌ ERROR", "message": str(e)}

def run_diagnostics():
    """Run all diagnostic tests"""
    print("=" * 80)
    print("🔍 BACKEND ENDPOINT DIAGNOSTICS")
    print("=" * 80)
    
    tests = [
        # Basic
        ("GET", "/", None, "Root endpoint"),
        ("GET", "/health", None, "Health check"),
        
        # Files
        ("GET", "/api/files", None, "List files"),
        ("GET", "/api/files/schema?path=product_data.parquet", None, "Get schema (product_data)"),
        ("GET", "/api/files/schema?path=sales_data.parquet", None, "Get schema (sales_data)"),
        
        # Queries
        ("POST", "/api/execute", {
            "query_config": {
                "files": ["product_data.parquet"],
                "limit": 10
            }
        }, "Execute query"),
        ("GET", "/api/queries", None, "List saved queries"),
        
        # Downloads
        ("GET", "/api/downloads", None, "List downloads"),
        
        # Executions
        ("GET", "/api/executions", None, "List executions"),
        ("GET", "/api/executions/test-id/status", None, "Get execution status"),
        ("GET", "/api/executions/test-id/results", None, "Get execution results"),
    ]
    
    print()
    for method, path, data, description in tests:
        print(f"\n📍 Testing: {description}")
        print(f"   {method} {path}")
        
        result = test_endpoint(method, path, data, description)
        print(f"   Result: {result['status']}")
        
        if result['status'] == "✅ WORKS" and result.get('data'):
            if isinstance(result['data'], list):
                print(f"   Data: Array with {len(result['data'])} items")
                if len(result['data']) > 0:
                    print(f"   Sample: {json.dumps(result['data'][0], indent=2)[:200]}")
            elif isinstance(result['data'], dict):
                print(f"   Data: {list(result['data'].keys())}")
        elif result.get('message'):
            print(f"   Message: {result['message']}")
        elif result.get('error'):
            print(f"   Error: {result['error'][:100]}")
    
    print()
    print("=" * 80)
    print("🎯 DIAGNOSIS COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    run_diagnostics()