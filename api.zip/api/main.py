"""
FastAPI Application for Parquet Query Engine
Enterprise-grade API with WebSocket support for real-time notifications
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import uuid
import logging
import os
import functools
from pathlib import Path
import asyncio
import json
import threading
from concurrent.futures import ThreadPoolExecutor

from core.parquet_engine import ParquetQueryEngine, QueryConfig as LegacyQueryConfig, JoinConfig
from core.optimized_engine import OptimizedParquetEngine, QueryConfig as OptQueryConfig
from core.database import DatabaseManager
from core.websocket_manager import WebSocketManager
from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws
from api.sql_query_api import router as sql_router, set_sql_dependencies
from api.reports_api import router as reports_router, set_report_dependencies
from api.schedules_api import router as schedules_router, set_schedule_dependencies

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Parquet Query Engine API",
    description="Enterprise-grade Parquet Query Engine with real-time notifications",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
engine = ParquetQueryEngine(base_path="./data/parquet", chunk_size=100000)
optimized_engine = OptimizedParquetEngine(data_dir="./data/parquet")
db_manager = DatabaseManager()
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# Thread pool for long-running query execution — sized for 100+ concurrent users.
# Queries are CPU/IO bound; use os.cpu_count() as a floor with overhead headroom.
query_executor = ThreadPoolExecutor(
    max_workers=min(32, (os.cpu_count() or 4) + 4),
    thread_name_prefix="query"
)

# Separate small pool for short blocking DB/IO calls offloaded from the event loop.
db_executor = ThreadPoolExecutor(max_workers=10, thread_name_prefix="db")

# Per-execution cancellation tokens: execution_id → threading.Event
_cancel_events: Dict[str, threading.Event] = {}
_cancel_lock = threading.Lock()

# Register sub-routers
app.include_router(data_grid_router)
app.include_router(sql_router)
app.include_router(reports_router)
app.include_router(schedules_router)
set_grid_db(db_manager)


@app.on_event("startup")
async def _startup():
    """Wire managers + event loop into sub-router modules, then start scheduler."""
    loop = asyncio.get_running_loop()
    set_grid_db(db_manager)          # ensure db is wired in every worker/reload
    set_grid_ws(ws_manager, loop)
    set_sql_dependencies(db_manager, ws_manager, loop)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_schedule_dependencies(db_manager, ws_manager, loop)

    # Start APScheduler in a thread-pool executor so blocking SQLite operations
    # (jobstore init, list_schedules, _bootstrap_schedules) never stall the event loop.
    # Non-fatal: a scheduler failure should not prevent the API from serving requests.
    from core.scheduler import init_scheduler

    def _start_scheduler():
        try:
            init_scheduler(db_manager, ws_manager, loop,
                           db_url="sqlite:///./data/parquet_query_engine.db")
        except Exception as exc:
            logger.error("APScheduler startup failed (non-fatal): %s", exc)

    await loop.run_in_executor(db_executor, _start_scheduler)


@app.on_event("shutdown")
async def _shutdown():
    """Gracefully stop APScheduler on application shutdown."""
    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _db(fn, *args, **kwargs):
    """
    Run a synchronous blocking function (DB or light I/O) in the DB executor
    so it never blocks the asyncio event loop.
    """
    loop = asyncio.get_running_loop()
    if kwargs:
        return await loop.run_in_executor(db_executor, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(db_executor, fn, *args)


# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------

class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|contains)$")
    value: Any


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class CrossParquetJoinConfig(BaseModel):
    how:      str            = Field(default="inner", pattern="^(inner|left|right|outer)$")
    left_on:  Any                    # str or List[str]
    right_on: Any                    # str or List[str]
    suffixes: Optional[List[str]] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None  # Primary data source connection
    # ── Cross-connection UNION / JOIN ──────────────────────────────────────
    secondary_connection_id: Optional[int]            = None
    secondary_query_config:  Optional[QueryConfigModel] = None
    combine_mode:            Optional[str]            = Field(default=None, pattern="^(union|join)$")
    join_config:             Optional[CrossParquetJoinConfig] = None


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str   # s3 | local | trino | starburst | snowflake | databricks
    config: dict


class ConnectionTestRequest(BaseModel):
    connection_type: str   # s3 | local | trino | starburst | snowflake | databricks
    config: dict


class QueryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    query_config: Dict[str, Any]
    created_at: str
    updated_at: str
    execution_count: int


class ExecutionResponse(BaseModel):
    execution_id: str
    status: str
    started_at: str
    message: str


# ---------------------------------------------------------------------------
# Query config converters
# ---------------------------------------------------------------------------

def convert_query_config_to_engine(config: QueryConfigModel) -> LegacyQueryConfig:
    """Convert API model to legacy engine QueryConfig (for validate_query etc.)"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how
            )
            for j in config.joins
        ]

    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]

    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]

    return LegacyQueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by
    )


def convert_to_optimized_config(config: QueryConfigModel) -> OptQueryConfig:
    """Convert API model to OptimizedParquetEngine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            {
                "left_file": j.left_file,
                "right_file": j.right_file,
                "left_on": j.left_on,
                "right_on": j.right_on,
                "how": j.how
            }
            for j in config.joins
        ]

    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]

    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]

    return OptQueryConfig(
        files=config.files,
        columns=config.columns,
        filters=filters,
        joins=joins,
        order_by=order_by,
        limit=config.limit if config.limit else 1000,
        chunk_size=50000
    )


async def execute_query_background(execution_id: str, query_config: QueryConfigModel,
                                  query_id: Optional[int] = None):
    """Background task for query execution (legacy path — not used by /api/execute)"""
    try:
        # Update status to processing
        db_manager.update_execution(execution_id, status="processing")

        # Send notification
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.utcnow().isoformat()
        })

        # Generate output path
        output_dir = Path("./data/downloads")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.csv"

        # Define progress callback
        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.utcnow().isoformat()
            })

            # Update execution in database
            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Execute query
        stats = engine.execute_query_to_csv(
            query_config,
            str(output_file),
            progress_callback=lambda data: asyncio.create_task(progress_callback(data))
        )

        # Create download file record
        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.csv",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.utcnow() + timedelta(days=7)
        )

        # Increment query execution count if applicable
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Send completion notification
        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.utcnow().isoformat()
        })

        logger.info(f"Query execution completed: {execution_id}")

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}")

        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )

        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        })


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Parquet Query Engine API",
        "version": "1.0.0",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }


# ---------------------------------------------------------------------------
# File Management Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/files", response_model=List[Dict[str, Any]])
async def list_files():
    """List all available parquet files"""
    try:
        files = await _db(engine.list_files)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str):
    """Get schema information for a specific file"""
    try:
        schema = await _db(engine.get_file_schema, file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error(f"Error getting file schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...)):
    """Upload a parquet file"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")

        file_path = Path(engine.base_path) / file.filename

        # Save file
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        logger.info(f"File uploaded: {file.filename}")

        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Query Management Endpoints
# ---------------------------------------------------------------------------

@app.post("/api/queries", response_model=QueryResponse)
async def create_query(request: SaveQueryRequest):
    """Save a new query"""
    try:
        # Validate query config (in-memory conversion, fast)
        engine_config = convert_query_config_to_engine(request.query_config)
        validation = await _db(engine.validate_query, engine_config)

        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )

        query = await _db(
            db_manager.create_query,
            request.name,
            request.query_config.dict(),
            request.description,
            request.created_by
        )

        logger.info(f"Query saved: {query['id']}")
        return query

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries", response_model=List[QueryResponse])
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0):
    """List all saved queries"""
    try:
        queries = await _db(db_manager.list_queries, active_only, limit, offset)
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries/{query_id}", response_model=QueryResponse)
async def get_query(query_id: int):
    """Get a specific query"""
    try:
        query = await _db(db_manager.get_query, query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/queries/{query_id}", response_model=QueryResponse)
async def update_query(query_id: int, request: SaveQueryRequest):
    """Update an existing query"""
    try:
        engine_config = convert_query_config_to_engine(request.query_config)
        validation = await _db(engine.validate_query, engine_config)

        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )

        query = await _db(
            db_manager.update_query,
            query_id,
            name=request.name,
            description=request.description,
            query_config=request.query_config.dict()
        )

        if not query:
            raise HTTPException(status_code=404, detail="Query not found")

        logger.info(f"Query updated: {query_id}")
        return query

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, permanent: bool = False):
    """Delete a query"""
    try:
        success = await _db(db_manager.delete_query, query_id, not permanent)
        if not success:
            raise HTTPException(status_code=404, detail="Query not found")

        logger.info(f"Query deleted: {query_id}")
        return {"message": "Query deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Query Execution Endpoints
# ---------------------------------------------------------------------------

@app.post("/api/execute")
async def execute_query_endpoint(request: ExecuteQueryRequest):
    """Execute a query using the optimized engine with cost estimation"""
    execution_id = str(uuid.uuid4())

    # Resolve query config: either inline or from a saved query
    if request.query_config:
        query_config_model = request.query_config
    elif request.query_id:
        saved = await _db(db_manager.get_query, request.query_id)
        if not saved:
            raise HTTPException(status_code=404, detail="Saved query not found")
        query_config_model = QueryConfigModel(**saved['query_config'])
    else:
        raise HTTPException(
            status_code=400,
            detail="Either query_config or query_id must be provided"
        )

    # ── Resolve primary connection data directory ──────────────────────────
    active_engine = optimized_engine
    primary_data_dir = str(optimized_engine.data_dir)

    if request.connection_id:
        conn_record = await _db(db_manager.get_connection, request.connection_id)
        if conn_record and conn_record.get('connection_type') == 'local':
            local_path = str(_normalize_path(conn_record['config'].get('base_path', './data/parquet')))
            active_engine = OptimizedParquetEngine(data_dir=local_path)
            primary_data_dir = local_path

    config = convert_to_optimized_config(query_config_model)

    # ── Cross-connection UNION / JOIN detection ────────────────────────────
    is_cross_connection = bool(request.secondary_connection_id and request.secondary_query_config)

    if not is_cross_connection:
        # ── Standard single-source path: cost estimation ───────────────────
        loop = asyncio.get_running_loop()
        cost = await loop.run_in_executor(db_executor, active_engine.estimate_query_cost, config)
        if cost['estimated_seconds'] > 300:
            raise HTTPException(
                status_code=400,
                detail=f"Query too expensive! Estimated {cost['estimated_seconds']:.0f}s. "
                       f"Warnings: {'; '.join(cost['warnings'])}. "
                       f"Tip: Select specific columns instead of all {cost.get('total_columns', 'N/A')}"
            )
    else:
        cost = {'estimated_seconds': 0, 'optimization_score': 1, 'warnings': []}

    # ── Resolve secondary connection (for cross-connection) ────────────────
    secondary_data_dir = None
    if is_cross_connection:
        sec_conn = await _db(db_manager.get_connection, request.secondary_connection_id)
        if not sec_conn:
            raise HTTPException(status_code=404, detail=f"Secondary connection {request.secondary_connection_id} not found")
        if sec_conn.get('connection_type') == 'local':
            secondary_data_dir = str(_normalize_path(sec_conn['config'].get('base_path', './data/parquet')))
        elif sec_conn.get('connection_type') == 's3':
            # S3 secondary: we can't directly use the optimized engine (it works on local paths)
            # so we treat S3 connections as a limitation and raise a clear error
            raise HTTPException(
                status_code=400,
                detail="Cross-connection UNION/JOIN currently supports Local Folder connections only. "
                       "For S3-to-S3 operations, mount the buckets as local paths or use the SQL Query page."
            )
        else:
            raise HTTPException(status_code=400, detail=f"Secondary connection type '{sec_conn.get('connection_type')}' not supported for cross-connection parquet queries")

    # ── Record execution ───────────────────────────────────────────────────
    exec_cfg = {
        **query_config_model.dict(),
        "cross_connection": is_cross_connection,
        "secondary_connection_id": request.secondary_connection_id,
        "combine_mode": request.combine_mode,
    }
    await _db(
        db_manager.create_execution,
        execution_id,
        exec_cfg,
        request.query_id,
        request.executed_by
    )

    output_dir = Path("./data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / f"{execution_id}.csv")

    cancel_event = threading.Event()
    with _cancel_lock:
        _cancel_events[execution_id] = cancel_event

    main_loop = asyncio.get_running_loop()

    # Snapshot cross-connection params for the worker thread
    _is_cross  = is_cross_connection
    _sec_dir   = secondary_data_dir
    _sec_cfg   = request.secondary_query_config.dict() if request.secondary_query_config else None
    _combine   = request.combine_mode or "union"
    _join_cfg  = request.join_config.dict() if request.join_config else None

    def run_query():
        def _broadcast(payload: dict):
            try:
                asyncio.run_coroutine_threadsafe(ws_manager.broadcast(payload), main_loop)
            except Exception:
                pass

        def progress_callback(data: dict):
            if cancel_event.is_set():
                raise RuntimeError(f"Execution {execution_id} cancelled by user")
            _broadcast({"type": "execution_progress", "execution_id": execution_id,
                        "data": data, "timestamp": datetime.utcnow().isoformat()})

        try:
            db_manager.update_execution(execution_id, status="processing")
            _broadcast({"type": "execution_started", "execution_id": execution_id,
                        "timestamp": datetime.utcnow().isoformat()})

            if cancel_event.is_set():
                raise RuntimeError(f"Execution {execution_id} cancelled before starting")

            if _is_cross:
                # ── Cross-connection UNION / JOIN ──────────────────────────
                from core.cross_source_engine import execute_cross_parquet_query

                def _xprogress(info):
                    if cancel_event.is_set():
                        raise RuntimeError(f"Execution {execution_id} cancelled by user")
                    _broadcast({"type": "execution_progress", "execution_id": execution_id,
                                "data": {"status": info.get("step"), "message": info.get("message", "")},
                                "timestamp": datetime.utcnow().isoformat()})

                result = execute_cross_parquet_query(
                    primary_data_dir=primary_data_dir,
                    primary_config=query_config_model.dict(),
                    secondary_data_dir=_sec_dir,
                    secondary_config=_sec_cfg,
                    combine_mode=_combine,
                    join_config=_join_cfg,
                    output_dir=str(output_dir),
                    execution_id=execution_id,
                    progress_callback=_xprogress,
                )
                total_rows = result.total_rows
                rows_read  = result.primary_rows + result.secondary_rows
                extra_stats = {
                    "primary_rows": result.primary_rows,
                    "secondary_rows": result.secondary_rows,
                    "combine_mode": _combine,
                    "duration_seconds": result.duration_seconds,
                }
            else:
                # ── Standard single-source path ────────────────────────────
                stats = active_engine.execute_query_to_csv(config, output_path,
                                                           progress_callback=progress_callback)
                total_rows = stats.rows_output
                rows_read  = stats.rows_read
                extra_stats = {
                    "rows_read": stats.rows_read,
                    "execution_time": stats.execution_time,
                    "columns_pruned": stats.columns_pruned,
                }

            db_manager.update_execution(execution_id, status="completed",
                                        total_rows=total_rows, output_file=output_path)

            if request.query_id:
                db_manager.increment_execution_count(request.query_id)

            # Register CSV in Download Center
            try:
                csv_p = Path(output_path)
                if csv_p.exists():
                    db_manager.create_download_file(
                        file_id=str(uuid.uuid4()),
                        execution_id=execution_id,
                        filename=f"query_{execution_id[:8]}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
                        file_path=output_path,
                        file_size_bytes=csv_p.stat().st_size,
                        expires_at=datetime.utcnow() + timedelta(days=7),
                    )
            except Exception as _reg_err:
                logger.warning(f"Could not register CSV as download [{execution_id}]: {_reg_err}")

            _broadcast({
                "type": "execution_completed",
                "execution_id": execution_id,
                "stats": {"rows_output": total_rows, "rows_read": rows_read, **extra_stats},
                "timestamp": datetime.utcnow().isoformat()
            })
            logger.info(f"Query execution completed: {execution_id} ({total_rows} rows)")

        except Exception as e:
            is_cancelled = cancel_event.is_set()
            final_status = "cancelled" if is_cancelled else "failed"
            logger.error(f"Query execution {final_status} [{execution_id}]: {e}")
            db_manager.update_execution(execution_id, status=final_status,
                                        error_message=None if is_cancelled else str(e))
            _broadcast({
                "type": "execution_cancelled" if is_cancelled else "execution_failed",
                "execution_id": execution_id,
                "error": None if is_cancelled else str(e),
                "timestamp": datetime.utcnow().isoformat()
            })
        finally:
            with _cancel_lock:
                _cancel_events.pop(execution_id, None)

    query_executor.submit(run_query)

    return {
        'execution_id': execution_id,
        'status': 'started',
        'is_cross_connection': is_cross_connection,
        'combine_mode': _combine if is_cross_connection else None,
        'estimated_seconds': cost['estimated_seconds'],
        'optimization_score': cost['optimization_score'],
        'warnings': cost['warnings'],
    }


@app.get("/api/executions")
async def list_executions(limit: int = 100, offset: int = 0, status: Optional[str] = None):
    """List query executions"""
    try:
        executions = await _db(db_manager.list_executions, limit, offset, status)
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/executions/{execution_id}")
async def get_execution(execution_id: str):
    """Get execution details"""
    try:
        execution = await _db(db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str):
    """Get real-time status of an execution (used by ReportPage polling)"""
    try:
        execution = await _db(db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        # Also check CSV on disk for definitive completion
        csv_file = Path(f"./data/downloads/{execution_id}.csv")
        if csv_file.exists() and execution.get("status") != "failed":
            return {
                "execution_id": execution_id,
                "status": "completed",
                "total_rows": execution.get("total_rows", 0),
                "file_size_bytes": csv_file.stat().st_size,
                "started_at": execution.get("started_at"),
                "completed_at": execution.get("completed_at"),
                "query_id": execution.get("query_id"),
                "error_message": None,
            }
        return {
            "execution_id": execution_id,
            "status": execution.get("status", "pending"),
            "total_rows": execution.get("total_rows", 0),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "query_id": execution.get("query_id"),
            "error_message": execution.get("error_message"),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """Cancel a running execution"""
    try:
        execution = await _db(db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution.get("status") in ("completed", "failed", "cancelled"):
            return {"message": f"Execution already in state: {execution.get('status')}"}

        # Signal the worker thread to stop at the next progress_callback check
        with _cancel_lock:
            event = _cancel_events.get(execution_id)
        if event:
            event.set()
        else:
            # Thread already finished or hasn't started — update DB directly
            await _db(db_manager.update_execution, execution_id, status="cancelled")

        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.utcnow().isoformat(),
        })
        return {"message": "Cancellation requested", "execution_id": execution_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Download Management Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0):
    """List available downloads"""
    try:
        downloads = await _db(db_manager.list_download_files, status, limit, offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads/{file_id}")
async def download_file(file_id: str):
    """Download a file"""
    try:
        download_info = await _db(db_manager.get_download_file, file_id)

        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")

        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")

        file_path = Path(download_info["file_path"])

        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")

        # Increment download count (fire-and-forget, non-critical)
        asyncio.get_running_loop().run_in_executor(
            db_executor, db_manager.increment_download_count, file_id
        )

        logger.info(f"File downloaded: {file_id}")

        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type="text/csv"
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str):
    """Delete a download file"""
    try:
        download_info = await _db(db_manager.get_download_file, file_id)

        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")

        await _db(db_manager.update_download_file, file_id, status="deleted")

        # Delete physical file
        file_path = Path(download_info["file_path"])
        if file_path.exists():
            file_path.unlink()

        logger.info(f"File deleted: {file_id}")

        return {"message": "File deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Exports — enriched download list for the Download Center UI
# ---------------------------------------------------------------------------

@app.get("/api/exports")
async def list_exports(
    status: Optional[str] = "available",
    limit: int = 200,
    offset: int = 0,
):
    """
    Enriched download list for the Download Center page.

    Returns all download records joined with their linked execution so the
    UI can display:
      - duration_seconds  — how long the query took to produce the file
      - total_rows        — number of rows written
      - format            — 'csv' | 'excel' | 'json' (derived from filename)

    Pass status='' (empty string) to return all statuses.
    """
    try:
        # Empty string means "all statuses" — normalise to None for the query
        status_filter = status if status else None
        downloads = await _db(db_manager.list_downloads_enriched, status_filter, limit, offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing exports: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Connection Management Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/connections")
async def list_connections(active_only: bool = True):
    """List all connections"""
    try:
        connections = await _db(db_manager.list_connections, active_only)
        return connections
    except Exception as e:
        logger.error(f"Error listing connections: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections")
async def create_connection(request: ConnectionConfigModel):
    """Create a new connection"""
    try:
        connection = await _db(
            db_manager.create_connection,
            request.name,
            request.connection_type,
            request.config
        )
        return connection
    except Exception as e:
        logger.error(f"Error creating connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest):
    """Test a connection configuration without saving (S3, local, or SQL connector)."""
    try:
        from core.connectors import SQL_CONNECTOR_TYPES, get_connector
        if request.connection_type in SQL_CONNECTOR_TYPES:
            def _sql_test():
                c = get_connector(request.connection_type, request.config or {})
                try:
                    return c.test_connection()
                finally:
                    c.close()
            result = await _db(_sql_test)
        else:
            result = await _db(conn_manager.test_connection, request.connection_type, request.config)
        return result
    except Exception as e:
        logger.error(f"Error testing connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int):
    """Get a specific connection"""
    try:
        conn = await _db(db_manager.get_connection, connection_id)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        return conn
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel):
    """Update an existing connection"""
    try:
        conn = await _db(
            db_manager.update_connection,
            connection_id,
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return conn
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int):
    """Delete a connection"""
    try:
        success = await _db(db_manager.delete_connection, connection_id)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection (S3/local or SQL connector)."""
    try:
        conn = await _db(db_manager.get_connection, connection_id)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")

        conn_type = conn.get("connection_type", "")

        # SQL connector types — use the SQL connector factory
        from core.connectors import SQL_CONNECTOR_TYPES, get_connector
        if conn_type in SQL_CONNECTOR_TYPES:
            def _sql_test():
                c = get_connector(conn_type, conn.get("config") or {})
                try:
                    return c.test_connection()
                finally:
                    c.close()
            result = await _db(_sql_test)
        else:
            # S3 / local — existing path
            result = await _db(conn_manager.test_connection, conn_type, conn["config"])

        # Update test status in DB
        await _db(
            db_manager.update_connection,
            connection_id,
            last_tested_at=datetime.utcnow(),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result['message']
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error testing saved connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = ""):
    """List parquet files from a connection"""
    try:
        conn = await _db(db_manager.get_connection, connection_id)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        # May involve S3 API calls or filesystem traversal — run off event loop
        files = await _db(conn_manager.list_files, connection_id, folder)
        return files
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error listing connection files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str):
    """Get schema for a file within a connection"""
    try:
        conn = await _db(db_manager.get_connection, connection_id)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        # Reads parquet metadata — run off event loop
        schema = await _db(conn_manager.get_schema, connection_id, file_path)
        return schema
    except HTTPException:
        raise
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error getting connection file schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# WebSocket Endpoint
# ---------------------------------------------------------------------------

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time notifications"""
    await ws_manager.connect(websocket)
    try:
        while True:
            # Keep connection alive and respond to pings from client
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.utcnow().isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
