"""
Parametric Reports API

Endpoints:
  GET    /api/reports                        — list reports
  POST   /api/reports                        — create report
  GET    /api/reports/{id}                   — get report
  PUT    /api/reports/{id}                   — update report
  DELETE /api/reports/{id}                   — soft delete
  POST   /api/reports/{id}/execute           — run async (returns execution_id)
  GET    /api/reports/{id}/download          — run sync, return CSV directly (for API/curl)
  GET    /api/reports/{id}/source-info       — describe the underlying source query
  GET    /api/reports/{id}/columns           — available columns for the source query

Parameter substitution:
  SQL sources:     {param_name} in SQL → type-safe string replacement
  Parquet sources: {param_name} in filter.value → replaced with param value
  Date shortcuts:  today, yesterday, month_start, -7d, etc. → ISO date
"""

from __future__ import annotations

import asyncio
import functools
import logging
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import date as _date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query as QParam, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager  = None
_ws_manager  = None
_main_loop   = None
_rpt_executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix="report_exec")


def set_report_dependencies(db_manager, ws_manager, loop):
    global _db_manager, _ws_manager, _main_loop
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    if kwargs:
        return await loop.run_in_executor(_rpt_executor, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_rpt_executor, fn, *args)


def _broadcast(payload: dict):
    if _ws_manager and _main_loop:
        asyncio.run_coroutine_threadsafe(_ws_manager.broadcast(payload), _main_loop)


# ── Parameter substitution ────────────────────────────────────────────────────

_PARAM_RE = re.compile(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}')


def substitute_sql_params(sql: str, param_values: dict, param_schema: list) -> str:
    """
    Replace {param_name} placeholders in SQL with type-safe values.
    - string / date  → wrapped in single quotes, single-quotes in value escaped
    - number         → cast to float, inserted raw (validates it's numeric)
    - boolean        → TRUE / FALSE
    - select         → treated as string
    Unknown params are left as-is (no substitution).
    """
    schema_map = {p["name"]: p for p in (param_schema or [])}

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        val  = param_values.get(name)
        if val is None:
            return m.group(0)    # leave placeholder untouched
        p     = schema_map.get(name, {})
        ptype = p.get("type", "string")

        # ── Multi-select: list/array → 'v1','v2','v3' for IN clauses ──────────
        # Template should use: WHERE col IN ({param_name})
        if isinstance(val, (list, tuple)):
            if not val:
                return "''"   # empty → no match
            safe_parts = [str(v).replace("'", "''") for v in val]
            return "'" + "','".join(safe_parts) + "'"

        if ptype == "number":
            try:
                return str(float(val))
            except (ValueError, TypeError):
                raise ValueError(f"Parameter '{name}' must be a number, got: {val!r}")
        elif ptype == "boolean":
            return "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
        else:
            # string, date, select, multiselect (single value) — wrap in quotes
            safe = str(val).replace("'", "''")
            return f"'{safe}'"

    return _PARAM_RE.sub(_replace, sql)


def substitute_filter_params(filters: list, param_values: dict) -> list:
    """Replace {param_name} in parquet filter values with actual param values."""
    if not filters or not param_values:
        return filters
    result = []
    for f in filters:
        new_f = dict(f)
        val_str = str(f.get("value", ""))
        m = _PARAM_RE.fullmatch(val_str)
        if m:
            param_name = m.group(1)
            if param_name in param_values:
                substituted = param_values[param_name]
                # Empty list/tuple → drop this filter entirely so ALL rows are
                # returned (multiselect with nothing selected = no restriction).
                if isinstance(substituted, (list, tuple)) and len(substituted) == 0:
                    continue
                new_f["value"] = substituted
                # When the substituted value is a non-empty list, upgrade
                # eq → in so the parquet engine can evaluate it correctly.
                if isinstance(substituted, (list, tuple)) and new_f.get("operator") in ("eq", "=", None, ""):
                    new_f["operator"] = "in"
        result.append(new_f)
    return result


def validate_param_values(param_schema: list, param_values: dict) -> List[str]:
    """Return list of validation error messages (empty = valid)."""
    errors = []
    for p in param_schema:
        name = p["name"]
        val  = param_values.get(name)
        if p.get("required") and (val is None or str(val).strip() == ""):
            errors.append(f"Required parameter '{p.get('label', name)}' is missing")
    return errors


# ── Business date resolver ────────────────────────────────────────────────────

_RELATIVE_RE = re.compile(r'^([+-])(\d+)d$', re.IGNORECASE)

# Exposed as a module constant for frontend discovery
BUSINESS_DATE_SHORTCUTS = [
    "today", "yesterday", "tomorrow",
    "week_start", "week_end",
    "last_week_start", "last_week_end",
    "month_start", "month_end",
    "last_month_start", "last_month_end",
    "year_start", "year_end",
    "last_year_start", "last_year_end",
]


def resolve_business_dates(param_values: dict) -> dict:
    """
    Expand business date shortcuts in param_values before substitution.
    Shortcuts are case-insensitive and resolved to YYYY-MM-DD strings.

    Supported shortcuts:
      today, yesterday, tomorrow
      week_start / week_end          — Mon/Sun of current ISO week
      last_week_start / last_week_end
      month_start / month_end
      last_month_start / last_month_end
      year_start / year_end
      last_year_start / last_year_end
      -Nd / +Nd                       — relative days (e.g. -7d = 7 days ago)
    """
    today = _date.today()

    def _first(d): return d.replace(day=1)
    def _last(d):
        m2 = d.month % 12 + 1
        y2 = d.year + (1 if d.month == 12 else 0)
        return _date(y2, m2, 1) - timedelta(days=1)

    last_month_last = _first(today) - timedelta(days=1)
    shortcuts = {
        "today":             today,
        "yesterday":         today - timedelta(days=1),
        "tomorrow":          today + timedelta(days=1),
        "week_start":        today - timedelta(days=today.weekday()),
        "week_end":          today + timedelta(days=6 - today.weekday()),
        "last_week_start":   today - timedelta(days=today.weekday() + 7),
        "last_week_end":     today - timedelta(days=today.weekday() + 1),
        "month_start":       _first(today),
        "month_end":         _last(today),
        "last_month_start":  _first(last_month_last),
        "last_month_end":    last_month_last,
        "year_start":        _date(today.year, 1, 1),
        "year_end":          _date(today.year, 12, 31),
        "last_year_start":   _date(today.year - 1, 1, 1),
        "last_year_end":     _date(today.year - 1, 12, 31),
    }

    result = {}
    for key, val in param_values.items():
        if not isinstance(val, str):
            result[key] = val
            continue
        norm = val.strip().lower()
        if norm in shortcuts:
            result[key] = shortcuts[norm].isoformat()
        else:
            m = _RELATIVE_RE.match(val.strip())
            if m:
                sign = 1 if m.group(1) == "+" else -1
                result[key] = (today + timedelta(days=sign * int(m.group(2)))).isoformat()
            else:
                result[key] = val
    return result


# ── Pydantic models ───────────────────────────────────────────────────────────

class ParameterDef(BaseModel):
    name:          str
    label:         str
    type:          str = "string"   # string | number | date | boolean | select
    required:      bool = False
    default_value: Optional[Any] = None
    description:   Optional[str] = None
    options:       Optional[List[str]] = None   # for select type


class CreateReportRequest(BaseModel):
    name:                str
    description:         Optional[str] = None
    saved_query_id:      Optional[int] = None
    sql_saved_query_id:  Optional[int] = None
    parameters:          List[ParameterDef] = []
    sql_override:        Optional[str] = None
    is_public:           bool = True
    created_by:          Optional[str] = None


class UpdateReportRequest(BaseModel):
    name:                Optional[str] = None
    description:         Optional[str] = None
    saved_query_id:      Optional[int] = None
    sql_saved_query_id:  Optional[int] = None
    parameters:          Optional[List[ParameterDef]] = None
    sql_override:        Optional[str] = None
    is_public:           Optional[bool] = None


class ExecuteReportRequest(BaseModel):
    param_values: Dict[str, Any] = {}
    row_limit:    Optional[int]  = None
    executed_by:  Optional[str]  = None


# ── CRUD endpoints ────────────────────────────────────────────────────────────

def _require_db():
    """Raise 503 with a helpful message when the DB manager hasn't been injected yet."""
    if _db_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Reports service not ready — the server may still be starting up or needs a restart.",
        )
    return _db_manager


@router.get("/api/reports")
async def list_reports(
    active_only: bool = True,
    limit: int = QParam(200, ge=1, le=1000),
    offset: int = QParam(0, ge=0),
):
    db = _require_db()
    return await _run_in_executor(db.list_reports, active_only, limit, offset)


@router.post("/api/reports", status_code=201)
async def create_report(req: CreateReportRequest):
    db = _require_db()
    if not req.saved_query_id and not req.sql_saved_query_id:
        raise HTTPException(400, "Must specify either saved_query_id or sql_saved_query_id")
    if req.saved_query_id and req.sql_saved_query_id:
        raise HTTPException(400, "Specify only one source: saved_query_id or sql_saved_query_id")
    return await _run_in_executor(
        db.create_report,
        name=req.name,
        description=req.description,
        saved_query_id=req.saved_query_id,
        sql_saved_query_id=req.sql_saved_query_id,
        parameters=[p.dict() for p in req.parameters],
        sql_override=req.sql_override,
        is_public=req.is_public,
        created_by=req.created_by,
    )


@router.get("/api/reports/{report_id}")
async def get_report(report_id: int):
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")
    return r


@router.put("/api/reports/{report_id}")
async def update_report(report_id: int, req: UpdateReportRequest):
    db = _require_db()
    updates = req.dict(exclude_none=True)
    if "parameters" in updates:
        updates["parameters"] = [p.dict() if hasattr(p, "dict") else p for p in (req.parameters or [])]
    result = await _run_in_executor(db.update_report, report_id, **updates)
    if not result:
        raise HTTPException(404, f"Report {report_id} not found")
    return result


@router.delete("/api/reports/{report_id}")
async def delete_report(report_id: int, permanent: bool = False):
    db = _require_db()
    success = await _run_in_executor(db.delete_report, report_id, not permanent)
    if not success:
        raise HTTPException(404, f"Report {report_id} not found")
    return {"message": "Deleted", "report_id": report_id}


@router.get("/api/reports/{report_id}/source-info")
async def get_report_source_info(report_id: int):
    """Return info about the report's underlying source query."""
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    info: Dict[str, Any] = {"report_id": report_id, "name": r["name"]}

    if r["saved_query_id"]:
        sq = await _run_in_executor(db.get_query, r["saved_query_id"])
        info["source_type"] = "parquet"
        info["source"] = sq
    elif r["sql_saved_query_id"]:
        sq = await _run_in_executor(db.get_sql_query, r["sql_saved_query_id"])
        info["source_type"] = "sql"
        info["source"] = sq
    return info


@router.get("/api/reports/{report_id}/param-values")
async def get_report_param_values(
    report_id: int,
    param_name: str,
    limit: int = QParam(1000, ge=1, le=10000),
):
    """
    Return sorted distinct non-null values for a column (param_name) from the
    report's parquet source.  Used by the frontend to auto-populate multi-select
    parameter dropdowns.

    For SQL-backed reports, returns an empty list (schema unknown until execution).
    """
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    values: List[str] = []
    truncated = False

    if r.get("saved_query_id"):
        values, truncated = await _run_in_executor(
            _fetch_distinct_parquet_values, r, param_name, limit
        )

    return {
        "report_id":  report_id,
        "param_name": param_name,
        "values":     values,
        "total":      len(values),
        "truncated":  truncated,
    }


@router.get("/api/reports/{report_id}/columns")
async def get_report_columns(report_id: int):
    """
    Return available column names for the report's source query.
    Used by the frontend to assist parameter schema creation.
    For Parquet sources: reads schema of the first 3 files in the query.
    For SQL sources: returns empty list (schema only known at execution time).
    """
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    columns: List[Dict[str, str]] = []

    if r.get("saved_query_id"):
        sq = await _run_in_executor(db.get_query, r["saved_query_id"])
        if sq:
            files = (sq.get("query_config") or {}).get("files") or []
            seen: set = set()
            for f in files[:5]:
                try:
                    from core.optimized_engine import OptimizedParquetEngine
                    engine = OptimizedParquetEngine(data_dir="./data/parquet")
                    schema = await _run_in_executor(engine.get_file_schema, f)
                    for col in (schema or []):
                        name = col.get("name") or col if isinstance(col, str) else col.get("name", "")
                        if name and name not in seen:
                            seen.add(name)
                            columns.append({
                                "name": name,
                                "type": col.get("type", "unknown") if isinstance(col, dict) else "unknown",
                            })
                except Exception:
                    pass

    return {
        "report_id": report_id,
        "source_type": "parquet" if r.get("saved_query_id") else "sql",
        "columns": columns,
        "date_shortcuts": BUSINESS_DATE_SHORTCUTS,
    }


@router.get("/api/reports/{report_id}/download")
async def download_report_csv(report_id: int, request: Request):
    """
    Synchronous CSV download for API/automation/curl access.
    Pass parameter values as query string:
      GET /api/reports/5/download?start_date=month_start&region=EMEA

    Date shortcuts (today, yesterday, month_start, -7d, etc.) are resolved automatically.
    Returns the CSV as a file attachment.
    """
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    param_values = resolve_business_dates(dict(request.query_params))
    errors = validate_param_values(report["parameters"], param_values)
    if errors:
        raise HTTPException(400, detail={"errors": errors})

    execution_id = str(uuid.uuid4())
    output_dir = Path("./data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / f"{execution_id}.csv")

    noop = lambda _: None

    try:
        if report["saved_query_id"]:
            await _run_in_executor(_run_parquet_report, report, param_values, None, output_path, noop)
        elif report["sql_saved_query_id"]:
            await _run_in_executor(_run_sql_report, report, param_values, None, execution_id, noop)
        else:
            raise HTTPException(400, "Report has no source configured")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))

    csv_path = Path(output_path)
    if not csv_path.exists():
        raise HTTPException(500, "Report execution produced no output")

    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", report["name"])
    filename = f"report_{safe_name}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return FileResponse(path=str(csv_path), filename=filename, media_type="text/csv")


# ── Execute endpoint ──────────────────────────────────────────────────────────

@router.post("/api/reports/{report_id}/execute")
async def execute_report(report_id: int, req: ExecuteReportRequest):
    """
    Execute a report with parameter values.
    Runs asynchronously — returns execution_id immediately.
    Progress / completion broadcast via WebSocket.
    """
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    # Resolve date shortcuts then validate required parameters
    param_values = resolve_business_dates(req.param_values)
    errors = validate_param_values(report["parameters"], param_values)
    if errors:
        raise HTTPException(400, detail={"errors": errors})

    execution_id = str(uuid.uuid4())

    try:
        current_loop = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    def _run():
        def _emit(payload):
            loop = current_loop or _main_loop
            if _ws_manager and loop:
                asyncio.run_coroutine_threadsafe(
                    _ws_manager.broadcast({**payload, "execution_id": execution_id}),
                    loop,
                )

        try:
            _emit({"type": "execution_progress", "data": {"status": "starting"}})

            output_dir = Path("./data/downloads")
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = str(output_dir / f"{execution_id}.csv")

            if report["saved_query_id"]:
                total_rows = _run_parquet_report(
                    report, param_values, req.row_limit, output_path, _emit
                )
            elif report["sql_saved_query_id"]:
                total_rows = _run_sql_report(
                    report, param_values, req.row_limit, execution_id, _emit
                )
                # sql report saves to its own path inside cross_source_engine
                output_path = str(output_dir / f"{execution_id}.csv")
            else:
                raise ValueError("Report has no source configured")

            # Register in downloads (capture db reference from outer scope)
            db.create_execution(
                execution_id=execution_id,
                query_config={"report_id": report_id, "param_values": req.param_values, "query_type": "report"},
            )
            db.update_execution(execution_id, status="completed", total_rows=total_rows, output_file=output_path)

            csv_p = Path(output_path)
            if csv_p.exists():
                db.create_download_file(
                    file_id=str(uuid.uuid4()),
                    execution_id=execution_id,
                    filename=f"report_{report['name'].replace(' ', '_')}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
                    file_path=str(csv_p),
                    file_size_bytes=csv_p.stat().st_size,
                    expires_at=datetime.utcnow() + timedelta(days=7),
                    created_by=req.executed_by,
                )

            db.increment_report_execution(report_id)

            _emit({
                "type": "execution_completed",
                "stats": {"total_rows": total_rows},
            })
        except Exception as exc:
            logger.exception(f"[{execution_id}] Report execution failed")
            try:
                db.update_execution(execution_id, status="failed", error_message=str(exc))
            except Exception:
                pass
            _emit({"type": "execution_failed", "error": str(exc)})

    # Submit to thread pool
    from concurrent.futures import ThreadPoolExecutor
    _rpt_executor.submit(_run)

    return {
        "execution_id": execution_id,
        "status": "running",
        "message": f"Report '{report['name']}' execution started",
    }


# ── Distinct-values helper ────────────────────────────────────────────────────

def _fetch_distinct_parquet_values(report: dict, param_name: str, limit: int):
    """
    Return (sorted_values, truncated) for `param_name` column from the report's
    parquet saved-query source.  Uses DuckDB so large files are read cheaply.
    """
    try:
        import duckdb as _duckdb
    except ImportError:
        return [], False

    saved_q = _db_manager.get_query(report["saved_query_id"])
    files = (saved_q.get("query_config") or {}).get("files") or []
    if not files:
        return [], False

    # Sanitise column name — strip quotes to prevent injection, then re-quote
    col = param_name.replace('"', '').replace("'", "")

    values: set = set()
    data_dir = Path("./data/parquet")

    for fname in files[:20]:          # cap at 20 files to keep response fast
        # Resolve path: try relative-to-data-dir first, then absolute
        candidates = [
            data_dir / fname,
            Path(fname),
        ]
        path = next((p for p in candidates if p.exists()), None)
        if path is None:
            continue

        p_posix = path.resolve().as_posix().replace("'", "''")
        try:
            con = _duckdb.connect(":memory:")
            rows = con.execute(
                f'SELECT DISTINCT "{col}" '
                f'FROM read_parquet(\'{p_posix}\') '
                f'WHERE "{col}" IS NOT NULL '
                f'LIMIT {limit + 1}'
            ).fetchall()
            values.update(str(r[0]) for r in rows)
            if len(values) > limit:
                return sorted(values)[:limit], True
        except Exception:
            continue

    sorted_vals = sorted(values)
    return sorted_vals[:limit], len(sorted_vals) > limit


# ── Internal execution helpers ────────────────────────────────────────────────

def _cast_scalar(v):
    """Try int → float → str so PyArrow type-matching works on numeric columns."""
    s = str(v).strip()
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    return s


def _run_parquet_report(report: dict, param_values: dict, row_limit: Optional[int],
                        output_path: str, emit) -> int:
    """Execute the parquet saved query backing this report."""
    from core.optimized_engine import OptimizedParquetEngine, QueryConfig as OptQC

    saved_q  = _db_manager.get_query(report["saved_query_id"])
    qc_dict  = dict(saved_q["query_config"])

    # ── Step 1: find which params are handled by existing {placeholder} filters ──
    original_filters = list(qc_dict.get("filters") or [])
    handled_by_placeholder: set = set()
    for f in original_filters:
        m = _PARAM_RE.fullmatch(str(f.get("value", "")))
        if m:
            handled_by_placeholder.add(m.group(1))

    # ── Step 2: substitute {param_name} placeholders in existing filters ────────
    if qc_dict.get("filters"):
        qc_dict["filters"] = substitute_filter_params(qc_dict["filters"], param_values)
    else:
        qc_dict["filters"] = []

    # ── Step 3: auto-apply any report param not already handled via placeholder ─
    # This lets users add parameters by column name without needing to pre-wire
    # {param_name} placeholders in the saved query's filter definitions.
    for p in (report.get("parameters") or []):
        name = p["name"]
        if name in handled_by_placeholder:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue  # nothing provided

        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue  # empty list = no restriction (all rows)
            # Cast each element for PyArrow type compatibility
            cast_vals = [_cast_scalar(v) for v in val]
            if len(cast_vals) == 1:
                qc_dict["filters"].append({"column": name, "operator": "eq", "value": cast_vals[0]})
            else:
                qc_dict["filters"].append({"column": name, "operator": "in", "value": cast_vals})
        else:
            qc_dict["filters"].append({"column": name, "operator": "eq", "value": _cast_scalar(val)})

    # Apply row_limit override
    if row_limit:
        qc_dict["limit"] = row_limit

    def _dict_to_optimized(d: dict) -> OptQC:
        return OptQC(
            files=d.get("files", []),
            columns=d.get("columns"),
            filters=d.get("filters"),
            joins=d.get("joins"),
            order_by=d.get("order_by"),
            limit=d.get("limit"),
        )

    engine = OptimizedParquetEngine(data_dir="./data/parquet")
    config = _dict_to_optimized(qc_dict)

    emit({"type": "execution_progress", "data": {"status": "processing"}})
    stats = engine.execute_query_to_csv(config, output_path)
    return stats.rows_output


def _run_sql_report(report: dict, param_values: dict, row_limit: Optional[int],
                    execution_id: str, emit) -> int:
    """Execute the SQL saved query backing this report."""
    from core.cross_source_engine import execute_single_source_query, execute_cross_source_query

    sql_q = _db_manager.get_sql_query(report["sql_saved_query_id"])

    primary_conn = _db_manager.get_connection_raw(sql_q["primary_connection_id"])
    if not primary_conn:
        raise ValueError(f"Connection {sql_q['primary_connection_id']} not found")

    # Use sql_override if set, otherwise use the saved query's SQL
    primary_sql = report.get("sql_override") or sql_q["primary_sql"]
    primary_sql = substitute_sql_params(primary_sql, param_values, report["parameters"])

    emit({"type": "execution_progress", "data": {"status": "querying"}})

    is_cross = bool(sql_q.get("secondary_connection_id") and sql_q.get("secondary_sql"))
    if is_cross:
        secondary_conn = _db_manager.get_connection_raw(sql_q["secondary_connection_id"])
        secondary_sql  = substitute_sql_params(
            sql_q["secondary_sql"], param_values, report["parameters"]
        )
        result = execute_cross_source_query(
            primary_conn_type=primary_conn["connection_type"],
            primary_conn_config=primary_conn["config"],
            primary_sql=primary_sql,
            secondary_conn_type=secondary_conn["connection_type"],
            secondary_conn_config=secondary_conn["config"],
            secondary_sql=secondary_sql,
            join_config=sql_q.get("join_config") or {},
            execution_id=execution_id,
            row_limit=row_limit,
        )
    else:
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            execution_id=execution_id,
            row_limit=row_limit,
        )

    return result.total_rows
