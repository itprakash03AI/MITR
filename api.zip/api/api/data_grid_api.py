"""
Data Grid API — DuckDB-Powered
Key changes:
  1. DuckDB replaces pandas for all data reads — handles 5-10 GB files without loading into RAM
  2. Advanced AND/OR filter via adv_filters parameter (JSON: {conjunction, conditions})
  3. Legacy per-column filters still supported for backwards compat
  4. All chart-data endpoints use DuckDB aggregation
  5. /export and /stats retain pandas (they process full dataset intentionally)
"""

from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from fastapi.responses import FileResponse, StreamingResponse
import pandas as pd
from pathlib import Path
import json
from typing import Optional
import io
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor as _TPE
from datetime import datetime, timedelta

try:
    import duckdb as _duckdb
    _DUCKDB_AVAILABLE = True
except ImportError:
    _DUCKDB_AVAILABLE = False

router = APIRouter()

# Dedicated thread pool for blocking DuckDB / pandas calls so they never
# stall the asyncio event loop.  DuckDB in-memory connections are per-call
# (_duckdb_con() creates a new one each time), so this is thread-safe.
_duckdb_executor = _TPE(max_workers=8, thread_name_prefix="duckdb")


async def _aduckdb(fn):
    """Run a blocking DuckDB or pandas function off the event loop."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_duckdb_executor, fn)


# Injected from main.py at startup
_db_manager = None
_ws_manager  = None
_main_loop   = None

# ── Eager own-instance init ─────────────────────────────────────────
# Creates a DatabaseManager at module-load time using an absolute path
# derived from __file__ so this works regardless of working directory.
# set_db_manager() below lets main.py override with its own instance
# (preferred, avoids two SQLite connections).
import logging as _init_log
try:
    from core.database import DatabaseManager as _OwnDBManager
    _own_data_dir = (Path(__file__).resolve().parent.parent / "data")
    _own_data_dir.mkdir(parents=True, exist_ok=True)
    _own_db_url   = "sqlite:///" + (_own_data_dir / "parquet_query_engine.db").as_posix()
    _db_manager   = _OwnDBManager(db_url=_own_db_url)
    _init_log.getLogger(__name__).info(
        "data_grid_api: eager DatabaseManager init OK — %s", _own_db_url)
except Exception as _init_exc:
    _init_log.getLogger(__name__).warning(
        "data_grid_api: eager DatabaseManager init failed (%s) — "
        "will rely on set_db_manager() injection", _init_exc)
    _db_manager = None


def set_db_manager(db):
    global _db_manager
    _db_manager = db

def set_ws_manager(ws_mgr, loop):
    global _ws_manager, _main_loop
    _ws_manager = ws_mgr
    _main_loop  = loop


def _get_db():
    """Return the DatabaseManager.

    Tier 1: module-level global (set eagerly at import time OR via set_db_manager).
    Tier 2: sys.modules lookup — final safety net for unusual import scenarios.
    """
    global _db_manager
    if _db_manager is not None:
        return _db_manager

    # Tier 2: look inside sys.modules for main.db_manager
    import sys
    for mod_name in ("main", "__main__"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            dm = getattr(mod, "db_manager", None)
            if dm is not None:
                _db_manager = dm
                return _db_manager

    import logging as _log
    _log.getLogger(__name__).error(
        "_get_db: all tiers failed — DatabaseManager unavailable")
    return None


def find_csv_file(execution_id: str) -> Optional[Path]:
    """Backend saves results as ./data/downloads/{execution_id}.csv"""
    # Absolute path derived from __file__ is CWD-independent
    _abs_downloads = Path(__file__).resolve().parent.parent / "data" / "downloads"
    for candidate in [
        _abs_downloads / f"{execution_id}.csv",
        Path(f"./data/downloads/{execution_id}.csv"),
        Path(f"data/downloads/{execution_id}.csv"),
    ]:
        if candidate.exists():
            return candidate
    return None


# ═══════════════════════════════════════════════════════════════════
# DuckDB helpers
# ═══════════════════════════════════════════════════════════════════

def _duckdb_con():
    """New in-memory DuckDB connection (each request gets its own)."""
    return _duckdb.connect(database=":memory:")


def _duckdb_source(path: Path) -> str:
    """Return the DuckDB table-function expression for a file.
    Uses .as_posix() so Windows backslashes are not misinterpreted
    as SQL/octal escape sequences inside DuckDB string literals.
    """
    p = path.resolve().as_posix().replace("'", "''")
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return f"read_parquet('{p}')"
    if suffix == ".json":
        return f"read_json_auto('{p}')"
    # CSV / TXT (and anything else): auto-detect.
    # sample_size=1000 caps schema-inference to the first 1000 rows so DuckDB
    # doesn't scan the entire file just to figure out column types — critical
    # for 1000-column files where a full scan takes 30-60 s.
    return f"read_csv_auto('{p}', ignore_errors=true, all_varchar=false, sample_size=1000)"


def _duckdb_valid_cols(con, source: str) -> list:
    """Return ordered list of column names from the source."""
    try:
        df = con.execute(f"SELECT * FROM {source} LIMIT 0").fetchdf()
        return df.columns.tolist()
    except Exception:
        return []


def _build_where(adv_filters_json: Optional[str], valid_cols: list) -> tuple:
    """
    Parse adv_filters JSON into a (WHERE-clause-string, params-list) pair.

    adv_filters format:
      { "conjunction": "AND" | "OR",
        "conditions": [
          { "col": "region", "op": "equals",   "val": "US" },
          { "col": "revenue","op": "gt",        "val": "1000" },
          ...
        ]
      }
    Supported ops: contains, not_contains, equals, not_equals,
                   starts_with, ends_with, gt, gte, lt, lte,
                   is_null, is_not_null
    """
    if not adv_filters_json:
        return "", []
    try:
        af = json.loads(adv_filters_json)
    except Exception:
        return "", []

    conjunction = af.get("conjunction", "AND").upper()
    if conjunction not in ("AND", "OR"):
        conjunction = "AND"

    valid_set = set(valid_cols)
    parts, params = [], []

    for cond in af.get("conditions", []):
        col = cond.get("col", "")
        op  = cond.get("op", "contains")
        val = cond.get("val", "")
        if col not in valid_set:
            continue

        qcol     = f'"{col}"'
        cast_col = f'CAST({qcol} AS VARCHAR)'

        if op == "contains":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"%{val}%")
        elif op == "not_contains":
            parts.append(f"({cast_col} NOT ILIKE ? OR {qcol} IS NULL)");  params.append(f"%{val}%")
        elif op == "equals":
            parts.append(f"{cast_col} = ?");      params.append(str(val))
        elif op == "not_equals":
            parts.append(f"({cast_col} != ? OR {qcol} IS NULL)");  params.append(str(val))
        elif op == "starts_with":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"{val}%")
        elif op == "ends_with":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"%{val}")
        elif op in ("gt", "gte", "lt", "lte"):
            try:
                nval = float(val)
                sym  = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[op]
                parts.append(f"TRY_CAST({qcol} AS DOUBLE) {sym} ?");  params.append(nval)
            except (ValueError, TypeError):
                pass
        elif op == "is_null":
            parts.append(f"{qcol} IS NULL")
        elif op == "is_not_null":
            parts.append(f"{qcol} IS NOT NULL")

    if not parts:
        return "", []
    return f" WHERE {(' ' + conjunction + ' ').join(parts)}", params


def _duckdb_paginate(
    path: Path,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
) -> dict:
    """
    DuckDB-powered pagination — works for CSV, Parquet, JSON of any size.
    Uses pushdown predicates; never loads the full file into Python RAM.
    Falls back to pandas for Excel (.xlsx/.xls).
    """
    suffix = path.suffix.lower()

    # Excel: DuckDB can't read natively
    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)

    if not _DUCKDB_AVAILABLE:
        # Fallback to pandas (limited to files that fit in RAM)
        if suffix == ".parquet":
            df = pd.read_parquet(path)
        else:
            df = pd.read_csv(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)

    # Empty file → execution produced 0 rows.  Return an empty-but-valid response
    # instead of letting DuckDB fail on a schema-less file.
    if path.stat().st_size == 0:
        return {
            "columns":       [],
            "rows":          [],
            "total_rows":    0,
            "filtered_rows": 0,
            "page":          page,
            "page_size":     page_size,
            "total_pages":   1,
            "filename":      filename_hint or path.name,
        }

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        valid_cols = _duckdb_valid_cols(con, source)
        if not valid_cols:
            raise HTTPException(status_code=500, detail="Cannot read file schema")

        where_clause, params = _build_where(adv_filters_json, valid_cols)

        order_clause = ""
        if sort_col and sort_col in valid_cols:
            direction = "ASC" if sort_dir == "asc" else "DESC"
            order_clause = f' ORDER BY "{sort_col}" {direction}'

        offset = (page - 1) * page_size

        # Row counts
        total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
        if where_clause:
            filtered_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}{where_clause}", params).fetchone()[0])
        else:
            filtered_rows = total_rows

        # Data page
        data_sql   = f"SELECT * FROM {source}{where_clause}{order_clause} LIMIT {page_size} OFFSET {offset}"
        result_df  = con.execute(data_sql, params).fetchdf()
        result_df  = result_df.where(pd.notnull(result_df), None)

        return {
            "columns":       valid_cols,
            "rows":          result_df.to_dict("records"),
            "total_rows":    total_rows,
            "filtered_rows": filtered_rows,
            "page":          page,
            "page_size":     page_size,
            "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
            "filename":      filename_hint or path.name,
        }
    finally:
        con.close()


def _pandas_paginate(
    df: pd.DataFrame,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
) -> dict:
    """Pandas pagination (Excel files or DuckDB-unavailable fallback)."""
    total_rows = len(df)

    if adv_filters_json:
        try:
            af = json.loads(adv_filters_json)
            conjunction = af.get("conjunction", "AND").upper()
            masks = []
            for cond in af.get("conditions", []):
                col = cond.get("col", "")
                op  = cond.get("op", "contains")
                val = str(cond.get("val", ""))
                if col not in df.columns:
                    continue
                s = df[col].astype(str)
                if   op == "contains":      masks.append(s.str.contains(val, case=False, na=False))
                elif op == "not_contains":  masks.append(~s.str.contains(val, case=False, na=False))
                elif op == "equals":        masks.append(s.str.lower() == val.lower())
                elif op == "not_equals":    masks.append(s.str.lower() != val.lower())
                elif op == "starts_with":   masks.append(s.str.startswith(val, na=False))
                elif op == "ends_with":     masks.append(s.str.endswith(val, na=False))
                elif op in ("gt", "gte", "lt", "lte"):
                    try:
                        nval   = float(val)
                        numcol = pd.to_numeric(df[col], errors="coerce")
                        sym_fn = {"gt": numcol.__gt__, "gte": numcol.__ge__,
                                  "lt": numcol.__lt__, "lte": numcol.__le__}[op]
                        masks.append(sym_fn(nval).fillna(False))
                    except (ValueError, TypeError):
                        pass
                elif op == "is_null":     masks.append(df[col].isna())
                elif op == "is_not_null": masks.append(df[col].notna())
            if masks:
                combined = masks[0]
                for m in masks[1:]:
                    combined = (combined | m) if conjunction == "OR" else (combined & m)
                df = df[combined]
        except Exception:
            pass

    filtered_rows = len(df)
    if sort_col and sort_col in df.columns:
        df = df.sort_values(by=sort_col, ascending=(sort_dir == "asc"))

    start   = (page - 1) * page_size
    page_df = df.iloc[start: start + page_size]
    page_df = page_df.where(pd.notnull(page_df), None)

    return {
        "columns":       df.columns.tolist(),
        "rows":          page_df.to_dict("records"),
        "total_rows":    total_rows,
        "filtered_rows": filtered_rows,
        "page":          page,
        "page_size":     page_size,
        "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
        "filename":      filename_hint,
    }


def _duckdb_chart(path: Path, x_col: str, y_col: str, agg: str, top_n: int) -> dict:
    """DuckDB-powered chart aggregation — full scan, server-side groupby."""
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name)

    if not _DUCKDB_AVAILABLE:
        df = pd.read_parquet(path) if suffix == ".parquet" else pd.read_csv(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name)

    if path.stat().st_size == 0:
        return {"x_col": x_col, "y_col": y_col, "agg": agg,
                "total_rows": 0, "groups": 0, "grand_total": 0.0, "data": []}

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        valid_cols = set(_duckdb_valid_cols(con, source))
        if x_col not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Column '{x_col}' not found")
        if y_col not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Column '{y_col}' not found")

        agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(agg, "SUM")
        total_rows  = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
        groups_cnt  = int(con.execute(f'SELECT COUNT(DISTINCT CAST("{x_col}" AS VARCHAR)) FROM {source}').fetchone()[0])

        agg_sql = f"""
            SELECT
                CAST("{x_col}" AS VARCHAR) AS label,
                {agg_fn}(TRY_CAST("{y_col}" AS DOUBLE)) AS value,
                COUNT(*) AS cnt
            FROM {source}
            GROUP BY "{x_col}"
            ORDER BY value DESC NULLS LAST
            LIMIT {top_n}
        """
        result_df   = con.execute(agg_sql).fetchdf()
        grand_total = float(result_df["value"].sum()) if len(result_df) > 0 else 0.0

        data = []
        for _, row in result_df.iterrows():
            v = None if pd.isna(row["value"]) else float(row["value"])
            data.append({
                "label": str(row["label"]),
                "value": v,
                "count": int(row["cnt"]),
                "pct":   round(v / grand_total * 100, 2) if grand_total and v is not None else 0,
            })

        return {"x_col": x_col, "y_col": y_col, "agg": agg,
                "total_rows": total_rows, "groups": groups_cnt, "grand_total": grand_total, "data": data}
    finally:
        con.close()


def _pandas_chart(df: pd.DataFrame, x_col: str, y_col: str, agg: str, top_n: int, name: str) -> dict:
    if x_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Column '{x_col}' not found")
    if y_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Column '{y_col}' not found")
    df[y_col] = pd.to_numeric(df[y_col], errors="coerce")
    grouped   = df.groupby(x_col, dropna=False)
    agg_map   = {"sum": "sum", "avg": "mean", "max": "max", "min": "min", "count": "count"}
    agg_s     = getattr(grouped[y_col], agg_map.get(agg, "sum"))()
    cnt_s     = grouped[y_col].count()
    res       = pd.DataFrame({"label": agg_s.index.astype(str), "value": agg_s.values, "count": cnt_s.values})\
                  .sort_values("value", ascending=False).head(top_n)
    total     = float(res["value"].sum())
    return {
        "x_col": x_col, "y_col": y_col, "agg": agg,
        "total_rows": len(df), "groups": len(agg_s), "grand_total": total,
        "data": [
            {"label": r["label"],
             "value": None if pd.isna(r["value"]) else float(r["value"]),
             "count": int(r["count"]),
             "pct":   round(float(r["value"]) / total * 100, 2) if total and not pd.isna(r["value"]) else 0}
            for _, r in res.iterrows()
        ],
    }


# ═══════════════════════════════════════════════════════════════════
# Paginated results — execution (1M+ rows supported via DuckDB)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/results")
async def get_paginated_results(
    execution_id:   str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=1000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy per-column
):
    """Paginated results with DuckDB — handles any file size."""
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")

    # Coerce legacy per-column filters into adv_filters format
    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conditions = [
                {"col": col, "op": "contains", "val": val}
                for col, val in json.loads(filters).items()
                if val
            ]
            if conditions:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conditions})
        except Exception:
            pass

    try:
        return await _aduckdb(lambda: _duckdb_paginate(
            csv_file, page, page_size, sort_column, sort_direction or "asc", effective_adv))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading results: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Chart data — full dataset aggregation (DuckDB)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/chart-data")
async def get_chart_data(
    execution_id: str,
    x_col: str,
    y_col: str,
    agg:   str = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n: int = Query(50, ge=1, le=500),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    try:
        return await _aduckdb(lambda: _duckdb_chart(csv_file, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Export — background task (pandas OK here — converts once to target format)
# ═══════════════════════════════════════════════════════════════════
def _do_export(execution_id, export_format, output_path, file_id, filename, loop=None):
    import asyncio
    import shutil
    import logging as _logging
    _log = _logging.getLogger(__name__)
    try:
        csv_file = find_csv_file(execution_id)
        if not csv_file:
            _log.error(f"Export [{execution_id}]: source CSV not found")
            return

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        if export_format == "csv":
            # Fast path: just copy the file — no need to load into pandas
            shutil.copy2(str(csv_file), str(out))
        else:
            # Excel / JSON need the DataFrame
            df = pd.read_csv(csv_file)
            if export_format == "excel":
                with pd.ExcelWriter(str(out), engine="openpyxl") as writer:
                    df.to_excel(writer, index=False, sheet_name="Query Results")
            elif export_format == "json":
                out.write_text(df.to_json(orient="records", indent=2), encoding="utf-8")

        file_size = out.stat().st_size
        _db = _get_db()
        if _db:
            _db.create_download_file(
                file_id=file_id, execution_id=execution_id, filename=filename,
                file_path=str(out), file_size_bytes=file_size,
                expires_at=datetime.utcnow() + timedelta(days=7),
            )
        _emit_loop = loop or _main_loop
        if _ws_manager and _emit_loop:
            asyncio.run_coroutine_threadsafe(
                _ws_manager.broadcast({
                    "type": "export_completed", "file_id": file_id, "filename": filename,
                    "format": export_format, "execution_id": execution_id,
                    "file_size_bytes": file_size, "timestamp": datetime.utcnow().isoformat(),
                }),
                _emit_loop,
            )
        _log.info(f"Export completed [{execution_id}] → {filename}")
    except Exception as e:
        _logging.getLogger(__name__).error(f"Export failed [{execution_id}]: {e}")


@router.post("/api/executions/{execution_id}/export")
async def export_results_background(
    execution_id: str,
    background_tasks: BackgroundTasks,
    format: str = Query("csv", pattern="^(csv|excel|json)$"),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    ext     = {"csv": ".csv", "excel": ".xlsx", "json": ".json"}[format]
    file_id = str(uuid.uuid4())
    fname   = f"export_{execution_id[:8]}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}{ext}"
    out_path= f"./data/downloads/{file_id}{ext}"
    import asyncio as _a
    try:    loop = _a.get_running_loop()
    except RuntimeError: loop = None
    background_tasks.add_task(_do_export, execution_id, format, out_path, file_id, fname, loop)
    return {"file_id": file_id, "filename": fname, "format": format,
            "message": f"Export started. '{fname}' will appear on the Downloads page shortly."}


@router.get("/api/executions/{execution_id}/export")
async def export_results_direct(
    execution_id: str,
    format: str = Query("csv", pattern="^(csv|excel|json)$"),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    if format == "csv":
        return FileResponse(path=csv_file, filename=f"query_results_{execution_id}.csv", media_type="text/csv")
    try:
        df = pd.read_csv(csv_file)
        if format == "excel":
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w:
                df.to_excel(w, index=False, sheet_name="Query Results")
            buf.seek(0)
            return StreamingResponse(buf,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.xlsx"})
        if format == "json":
            return StreamingResponse(io.StringIO(df.to_json(orient="records", indent=2)),
                media_type="application/json",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.json"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Column stats — full dataset
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/stats")
async def get_result_stats(execution_id: str):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")

    def _compute():
        df = pd.read_csv(csv_file)
        stats = {"total_rows": len(df), "total_columns": len(df.columns),
                 "file_size_bytes": csv_file.stat().st_size, "columns": []}
        for col in df.columns:
            cs = {"name": col, "type": str(df[col].dtype),
                  "null_count": int(df[col].isnull().sum()),
                  "unique_count": int(df[col].nunique())}
            if pd.api.types.is_numeric_dtype(df[col]):
                cs["min"]  = float(df[col].min())  if not pd.isna(df[col].min())  else None
                cs["max"]  = float(df[col].max())  if not pd.isna(df[col].max())  else None
                cs["mean"] = float(df[col].mean()) if not pd.isna(df[col].mean()) else None
            stats["columns"].append(cs)
        return stats

    try:
        return await _aduckdb(_compute)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing stats: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Download file helpers
# ═══════════════════════════════════════════════════════════════════
def _resolve_download_path(record: dict, file_id: str) -> Optional[Path]:
    """Try multiple locations to find a DownloadFile on disk."""
    stored       = record.get("file_path", "")
    filename     = record.get("filename", "")
    execution_id = record.get("execution_id", "")

    candidates: list = []
    if stored:
        candidates.append(Path(stored))
    if stored and stored.startswith("./"):
        candidates.append(Path(stored[2:]))
    for base in ("data/downloads", "./data/downloads"):
        candidates.append(Path(base) / f"{file_id}.csv")
        if filename:
            candidates.append(Path(base) / filename)
        if execution_id:
            candidates.append(Path(base) / f"{execution_id}.csv")

    for c in candidates:
        try:
            if c.exists() and c.is_file():
                return c
        except Exception:
            pass
    return None


# ═══════════════════════════════════════════════════════════════════
# Preview by file_id — DuckDB, any size
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/downloads/{file_id}/preview")
async def preview_download_file(
    file_id:        str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=500),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy
):
    path     = None
    filename = ""

    # Preferred: DB lookup for the DownloadFile record
    _db = _get_db()
    if _db:
        loop   = asyncio.get_running_loop()
        record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
        if record:
            path     = _resolve_download_path(record, file_id)
            filename = record.get("filename", "")

    # Fallback: treat file_id as an execution_id and look for the raw CSV
    if path is None:
        path = find_csv_file(file_id)

    if path is None:
        raise HTTPException(
            status_code=404,
            detail=f"No download record or results file found for id={file_id}")

    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conds = [{"col": c, "op": "contains", "val": v} for c, v in json.loads(filters).items() if v]
            if conds:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conds})
        except Exception:
            pass

    try:
        return await _aduckdb(lambda: _duckdb_paginate(
            path, page, page_size, sort_column,
            sort_direction or "asc", effective_adv, filename))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Chart data for download file (by file_id)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/downloads/{file_id}/chart-data")
async def chart_data_download_file(
    file_id: str,
    x_col:   str,
    y_col:   str,
    agg:     str  = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:   int  = Query(50, ge=1, le=500),
):
    path = None
    _db  = _get_db()
    if _db:
        loop   = asyncio.get_running_loop()
        record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
        if record:
            path = _resolve_download_path(record, file_id)
    if path is None:
        path = find_csv_file(file_id)
    if path is None:
        raise HTTPException(status_code=404,
            detail=f"No download record or results file found for id={file_id}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Direct download of a DownloadFile by file_id
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/downloads/{file_id}/download")
async def download_file_direct(file_id: str):
    _db = _get_db()
    if not _db:
        raise HTTPException(status_code=503, detail="Service unavailable")
    loop = asyncio.get_running_loop()
    record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
    if not record:
        raise HTTPException(status_code=404, detail=f"No download record for file_id={file_id}")
    path = _resolve_download_path(record, file_id)
    if path is None:
        raise HTTPException(status_code=404, detail="File not found on disk")
    filename   = record.get("filename", path.name)
    media_map  = {".csv": "text/csv", ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  ".json": "application/json"}
    media_type = media_map.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(path=str(path), filename=filename, media_type=media_type)


# ═══════════════════════════════════════════════════════════════════
# Raw file path resolution helper
# ═══════════════════════════════════════════════════════════════════
def _resolve_raw_path(file_path: str, connection_id: Optional[int]) -> Path:
    """Resolve a relative/absolute path, trying connection base_path as fallback."""
    path = Path(file_path)
    if path.is_absolute() and path.exists():
        return path
    _db = _get_db()
    if connection_id and _db:
        try:
            conn = _db.get_connection_raw(connection_id)
            if conn:
                cfg  = conn.get("config", {})
                base = cfg.get("base_path") or cfg.get("folder_path")
                if base:
                    candidate = Path(base) / file_path
                    if candidate.exists():
                        return candidate
        except Exception:
            pass
    default = Path("./data/parquet") / file_path
    if default.exists():
        return default
    return path


# ═══════════════════════════════════════════════════════════════════
# Raw file preview — CSV or Parquet by path (DuckDB, any size)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/data")
async def get_raw_file_data(
    file_path:      str,
    connection_id:  Optional[int] = None,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=1000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,  # legacy
):
    """Paginated preview of any file (CSV/Parquet/Excel/JSON).
    Supply connection_id when file_path is relative to a connection's base_path."""
    path = _resolve_raw_path(file_path, connection_id)
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conds = [{"col": c, "op": "contains", "val": v} for c, v in json.loads(filters).items() if v]
            if conds:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conds})
        except Exception:
            pass

    try:
        return await _aduckdb(lambda: _duckdb_paginate(
            path, page, page_size, sort_column, sort_direction or "asc", effective_adv))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Raw file chart data (CSV or Parquet, by path)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/chart-data")
async def get_raw_file_chart_data(
    file_path:     str,
    x_col:         str,
    y_col:         str,
    connection_id: Optional[int] = None,
    agg:           str  = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:         int  = Query(50, ge=1, le=500),
):
    path = _resolve_raw_path(file_path, connection_id)
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")
