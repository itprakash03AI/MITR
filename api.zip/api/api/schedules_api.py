"""
Schedules API — CRUD + control for scheduled query/report downloads.

Endpoints:
  GET    /api/schedules                  — list schedules
  POST   /api/schedules                  — create + register with APScheduler
  GET    /api/schedules/{id}             — get schedule detail
  PUT    /api/schedules/{id}             — update (re-registers trigger)
  DELETE /api/schedules/{id}             — remove from scheduler + DB
  POST   /api/schedules/{id}/pause       — pause (keeps trigger, stops firing)
  POST   /api/schedules/{id}/resume      — resume a paused schedule
  POST   /api/schedules/{id}/run-now     — trigger an immediate run
  GET    /api/schedules/scheduler-status — APScheduler health info
"""

from __future__ import annotations

import asyncio
import functools
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query as QParam
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager  = None
_ws_manager  = None
_main_loop   = None
_sched_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_api")


def set_schedule_dependencies(db_manager, ws_manager, loop):
    global _db_manager, _ws_manager, _main_loop
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop


async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    if kwargs:
        return await loop.run_in_executor(_sched_executor, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_sched_executor, fn, *args)


# ── Pydantic models ───────────────────────────────────────────────────────────

class TriggerConfig(BaseModel):
    type: str                        # "cron" | "interval"
    cron_expr: Optional[str] = None  # for type="cron": "0 8 * * 1-5"
    minutes: Optional[int]   = None  # for type="interval"
    hours:   Optional[int]   = None
    seconds: Optional[int]   = None


class CreateScheduleRequest(BaseModel):
    name:                    str
    description:             Optional[str] = None
    source_type:             str             # saved_query | sql_query | report
    source_id:               int
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          TriggerConfig
    output_filename_template: Optional[str] = None
    created_by:              Optional[str] = None


class UpdateScheduleRequest(BaseModel):
    name:                    Optional[str] = None
    description:             Optional[str] = None
    source_type:             Optional[str] = None
    source_id:               Optional[int] = None
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          Optional[TriggerConfig] = None
    output_filename_template: Optional[str] = None
    is_active:               Optional[bool] = None


# ── Helper: validate trigger config ──────────────────────────────────────────

def _validate_trigger(tc: TriggerConfig):
    if tc.type == "cron":
        if not tc.cron_expr:
            raise HTTPException(400, "cron_expr is required for type='cron'")
        # Validate the cron expression is parsable
        try:
            from apscheduler.triggers.cron import CronTrigger
            CronTrigger.from_crontab(tc.cron_expr, timezone="UTC")
        except Exception as e:
            raise HTTPException(400, f"Invalid cron expression '{tc.cron_expr}': {e}")
    elif tc.type == "interval":
        if not any([tc.minutes, tc.hours, tc.seconds]):
            raise HTTPException(400, "Specify at least one of: minutes, hours, seconds for type='interval'")
    else:
        raise HTTPException(400, f"Unknown trigger type '{tc.type}'. Use 'cron' or 'interval'.")


def _validate_source(source_type: str, source_id: int):
    if source_type == "saved_query":
        if not _db_manager.get_query(source_id):
            raise HTTPException(404, f"Saved query {source_id} not found")
    elif source_type == "sql_query":
        if not _db_manager.get_sql_query(source_id):
            raise HTTPException(404, f"SQL query {source_id} not found")
    elif source_type == "report":
        if not _db_manager.get_report(source_id):
            raise HTTPException(404, f"Report {source_id} not found")
    else:
        raise HTTPException(400, f"Unknown source_type '{source_type}'. Use: saved_query, sql_query, report")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/schedules/scheduler-status")
async def get_scheduler_status():
    """APScheduler health: running state, active jobs, next fire times."""
    from core.scheduler import get_scheduler_status
    return await _run_in_executor(get_scheduler_status)


@router.get("/api/schedules")
async def list_schedules(
    active_only: bool = False,
    limit: int = QParam(200, ge=1, le=1000),
    offset: int = QParam(0, ge=0),
):
    if active_only:
        return await _run_in_executor(_db_manager.list_schedules, True, limit, offset)
    return await _run_in_executor(_db_manager.list_all_schedules, limit, offset)


@router.post("/api/schedules", status_code=201)
async def create_schedule(req: CreateScheduleRequest):
    _validate_trigger(req.trigger_config)
    await _run_in_executor(_validate_source, req.source_type, req.source_id)

    # Create DB record
    record = await _run_in_executor(
        _db_manager.create_schedule,
        name=req.name,
        description=req.description,
        source_type=req.source_type,
        source_id=req.source_id,
        param_values=req.param_values,
        trigger_config=req.trigger_config.dict(exclude_none=True),
        output_filename_template=req.output_filename_template,
        created_by=req.created_by,
    )

    # Register with APScheduler
    try:
        from core.scheduler import add_schedule
        job_id = await _run_in_executor(add_schedule, record)
        record = await _run_in_executor(
            _db_manager.update_schedule, record["id"], apscheduler_job_id=job_id
        )
    except Exception as e:
        logger.error("Failed to register schedule %s with APScheduler: %s", record["id"], e)
        raise HTTPException(500, f"Schedule saved but APScheduler registration failed: {e}")

    return record


@router.get("/api/schedules/{schedule_id}")
async def get_schedule(schedule_id: int):
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    return s


@router.put("/api/schedules/{schedule_id}")
async def update_schedule(schedule_id: int, req: UpdateScheduleRequest):
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")

    updates: Dict[str, Any] = {}
    if req.name           is not None: updates["name"]           = req.name
    if req.description    is not None: updates["description"]    = req.description
    if req.source_type    is not None: updates["source_type"]    = req.source_type
    if req.source_id      is not None: updates["source_id"]      = req.source_id
    if req.param_values   is not None: updates["param_values"]   = req.param_values
    if req.is_active      is not None: updates["is_active"]      = req.is_active
    if req.output_filename_template is not None:
        updates["output_filename_template"] = req.output_filename_template
    if req.trigger_config is not None:
        _validate_trigger(req.trigger_config)
        updates["trigger_config"] = req.trigger_config.dict(exclude_none=True)

    if req.source_type and req.source_id:
        await _run_in_executor(_validate_source, req.source_type, req.source_id)

    record = await _run_in_executor(_db_manager.update_schedule, schedule_id, **updates)

    # Re-register with APScheduler if trigger or active state changed
    if "trigger_config" in updates or "is_active" in updates:
        try:
            from core.scheduler import add_schedule, remove_schedule
            if existing.get("apscheduler_job_id"):
                await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
            if record.get("is_active"):
                job_id = await _run_in_executor(add_schedule, record)
                record = await _run_in_executor(
                    _db_manager.update_schedule, schedule_id, apscheduler_job_id=job_id
                )
            else:
                await _run_in_executor(
                    _db_manager.update_schedule, schedule_id, apscheduler_job_id=None
                )
        except Exception as e:
            logger.error("APScheduler update failed for schedule %s: %s", schedule_id, e)

    return record


@router.delete("/api/schedules/{schedule_id}")
async def delete_schedule(schedule_id: int):
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")

    # Remove from APScheduler first
    if existing.get("apscheduler_job_id"):
        try:
            from core.scheduler import remove_schedule
            await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
        except Exception as e:
            logger.warning("APScheduler remove failed for schedule %s: %s", schedule_id, e)

    success = await _run_in_executor(_db_manager.delete_schedule, schedule_id)
    if not success:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    return {"message": "Deleted", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/pause")
async def pause_schedule(schedule_id: int):
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        from core.scheduler import pause_schedule as _pause
        await _run_in_executor(_pause, s["apscheduler_job_id"])
        await _run_in_executor(_db_manager.update_schedule, schedule_id, is_active=False)
    except Exception as e:
        raise HTTPException(500, f"Pause failed: {e}")
    return {"message": "Paused", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/resume")
async def resume_schedule(schedule_id: int):
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        from core.scheduler import resume_schedule as _resume
        next_run = await _run_in_executor(_resume, s["apscheduler_job_id"])
        await _run_in_executor(
            _db_manager.update_schedule, schedule_id, is_active=True, next_run_at=next_run
        )
    except Exception as e:
        raise HTTPException(500, f"Resume failed: {e}")
    return {"message": "Resumed", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/run-now")
async def run_schedule_now(schedule_id: int):
    """Trigger an immediate out-of-schedule run. Does not affect the regular trigger."""
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    try:
        from core.scheduler import run_now
        await _run_in_executor(run_now, schedule_id)
    except Exception as e:
        raise HTTPException(500, f"Immediate run failed: {e}")
    return {"message": "Triggered", "schedule_id": schedule_id}
