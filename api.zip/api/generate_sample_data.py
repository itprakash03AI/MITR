"""
Sample Parquet File Generator
Creates test parquet files with various schemas for testing the query engine
"""

import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path
import random

def generate_sales_data(num_rows=1000000):
    """Generate sample sales transaction data"""
    print(f"Generating sales data with {num_rows:,} rows...")
    
    np.random.seed(42)
    
    # Generate dates
    start_date = datetime(2023, 1, 1)
    dates = [start_date + timedelta(days=random.randint(0, 365)) 
             for _ in range(num_rows)]
    
    # Generate data
    data = {
        'transaction_id': range(1, num_rows + 1),
        'date': dates,
        'customer_id': np.random.randint(1, 10000, num_rows),
        'product_id': np.random.randint(1, 1000, num_rows),
        'quantity': np.random.randint(1, 20, num_rows),
        'unit_price': np.round(np.random.uniform(10, 1000, num_rows), 2),
        'discount': np.random.choice([0, 0.05, 0.10, 0.15, 0.20], num_rows),
        'status': np.random.choice(['completed', 'pending', 'cancelled'], num_rows),
        'region': np.random.choice(['North', 'South', 'East', 'West'], num_rows),
        'payment_method': np.random.choice(['credit_card', 'debit_card', 'cash', 'digital'], num_rows)
    }
    
    df = pd.DataFrame(data)
    
    # Calculate total
    df['total_amount'] = df['quantity'] * df['unit_price'] * (1 - df['discount'])
    
    return df

def generate_customer_data(num_rows=10000):
    """Generate sample customer data"""
    print(f"Generating customer data with {num_rows:,} rows...")
    
    np.random.seed(43)
    
    data = {
        'customer_id': range(1, num_rows + 1),
        'name': [f"Customer_{i}" for i in range(1, num_rows + 1)],
        'email': [f"customer{i}@example.com" for i in range(1, num_rows + 1)],
        'age': np.random.randint(18, 80, num_rows),
        'gender': np.random.choice(['M', 'F', 'Other'], num_rows),
        'country': np.random.choice(['USA', 'UK', 'Canada', 'Germany', 'France'], num_rows),
        'registration_date': [datetime(2020, 1, 1) + timedelta(days=random.randint(0, 1095)) 
                             for _ in range(num_rows)],
        'loyalty_points': np.random.randint(0, 10000, num_rows),
        'is_premium': np.random.choice([True, False], num_rows, p=[0.3, 0.7])
    }
    
    df = pd.DataFrame(data)
    return df

def generate_product_data(num_rows=1000):
    """Generate sample product data"""
    print(f"Generating product data with {num_rows:,} rows...")
    
    np.random.seed(44)
    
    categories = ['Electronics', 'Clothing', 'Home & Garden', 'Sports', 'Books', 'Toys']
    
    data = {
        'product_id': range(1, num_rows + 1),
        'product_name': [f"Product_{i}" for i in range(1, num_rows + 1)],
        'category': np.random.choice(categories, num_rows),
        'price': np.round(np.random.uniform(5, 2000, num_rows), 2),
        'cost': np.round(np.random.uniform(2, 1000, num_rows), 2),
        'stock_quantity': np.random.randint(0, 1000, num_rows),
        'supplier_id': np.random.randint(1, 100, num_rows),
        'rating': np.round(np.random.uniform(1, 5, num_rows), 1),
        'reviews_count': np.random.randint(0, 1000, num_rows)
    }
    
    df = pd.DataFrame(data)
    
    # Calculate margin
    df['margin_percentage'] = ((df['price'] - df['cost']) / df['price'] * 100).round(2)
    
    return df

def generate_large_dataset(num_rows=5000000):
    """Generate a large dataset for performance testing"""
    print(f"Generating large dataset with {num_rows:,} rows...")
    
    np.random.seed(45)
    
    data = {
        'id': range(1, num_rows + 1),
        'timestamp': [datetime(2024, 1, 1) + timedelta(seconds=random.randint(0, 31536000)) 
                     for _ in range(num_rows)],
        'user_id': np.random.randint(1, 100000, num_rows),
        'event_type': np.random.choice(['click', 'view', 'purchase', 'search'], num_rows),
        'value': np.random.uniform(0, 1000, num_rows),
        'session_id': np.random.randint(1, 1000000, num_rows),
        'device': np.random.choice(['mobile', 'desktop', 'tablet'], num_rows),
        'browser': np.random.choice(['chrome', 'firefox', 'safari', 'edge'], num_rows),
        'country_code': np.random.choice(['US', 'UK', 'CA', 'DE', 'FR', 'JP', 'AU'], num_rows)
    }
    
    df = pd.DataFrame(data)
    return df

def save_to_parquet(df, filename, output_dir='./backend/data/parquet'):
    """Save dataframe to parquet file"""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    file_path = output_path / filename
    
    # Convert to PyArrow Table for better control
    table = pa.Table.from_pandas(df)
    
    # Write with compression
    pq.write_table(
        table,
        file_path,
        compression='snappy',
        use_dictionary=True,
        write_statistics=True
    )
    
    file_size = file_path.stat().st_size / (1024 * 1024)  # Convert to MB
    print(f"✓ Saved {filename} ({file_size:.2f} MB, {len(df):,} rows)")

def main():
    """Generate all sample datasets"""
    print("=" * 60)
    print("Parquet Query Engine - Sample Data Generator")
    print("=" * 60)
    print()
    
    # Generate datasets
    datasets = [
        ('sales_data.parquet', generate_sales_data(1000000)),
        ('customer_data.parquet', generate_customer_data(10000)),
        ('product_data.parquet', generate_product_data(1000)),
        ('large_events.parquet', generate_large_dataset(5000000))
    ]
    
    print()
    print("Saving parquet files...")
    print()
    
    for filename, df in datasets:
        save_to_parquet(df, filename)
    
    print()
    print("=" * 60)
    print("Sample Data Generation Complete!")
    print("=" * 60)
    print()
    print("Generated files in ./backend/data/parquet/:")
    print("  - sales_data.parquet (1M rows) - Sales transactions")
    print("  - customer_data.parquet (10K rows) - Customer information")
    print("  - product_data.parquet (1K rows) - Product catalog")
    print("  - large_events.parquet (5M rows) - Large event log")
    print()
    print("You can now:")
    print("  1. Start the backend server")
    print("  2. Navigate to the Query Builder")
    print("  3. Select and query these files")
    print()
    print("Example queries to try:")
    print("  - Join sales_data with customer_data on customer_id")
    print("  - Filter sales by date range and status")
    print("  - Group by region and calculate total sales")
    print()

if __name__ == "__main__":
    main()
