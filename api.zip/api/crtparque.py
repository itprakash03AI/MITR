import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

# -----------------------------------
# CONFIG
# -----------------------------------
NUM_CUSTOMERS = 50_000
NUM_ACCOUNTS = 100_000
NUM_TRANSACTIONS = 1_000_000
NUM_COLS = 1000

# -----------------------------------
# Helper: Create synthetic numeric columns
# -----------------------------------
def generate_numeric_cols(n_rows, start_idx, end_idx):
    return {
        f"col_{i:04d}": np.random.rand(n_rows).astype("float32")
        for i in range(start_idx, end_idx)
    }

# -----------------------------------
# 1. CUSTOMERS (PARENT)
# -----------------------------------
print("Creating customers...")

customer_ids = np.arange(1, NUM_CUSTOMERS + 1)

df_customers = pd.DataFrame({
    "customer_id": customer_ids,
    "first_name": np.random.choice(["John", "Mary", "Raj", "Anita", "Wei", "Sara"], size=NUM_CUSTOMERS),
    "last_name": np.random.choice(["Smith", "Patel", "Chen", "Garcia", "Brown", "Singh"], size=NUM_CUSTOMERS),
    "dob": pd.to_datetime("1950-01-01") + pd.to_timedelta(
        np.random.randint(0, 25000, size=NUM_CUSTOMERS), unit="D"
    ),
    "segment": np.random.choice(["RETAIL", "WEALTH", "CORPORATE"], size=NUM_CUSTOMERS),
})

extra_cols = generate_numeric_cols(NUM_CUSTOMERS, 5, NUM_COLS)
df_customers = pd.concat([df_customers, pd.DataFrame(extra_cols)], axis=1)

pq.write_table(pa.Table.from_pandas(df_customers, preserve_index=False), "customers.parquet")
print("customers.parquet created.")

# -----------------------------------
# 2. ACCOUNTS (CHILD OF CUSTOMERS)
# -----------------------------------
print("Creating accounts...")

account_ids = np.arange(1, NUM_ACCOUNTS + 1)

df_accounts = pd.DataFrame({
    "account_id": account_ids,
    "customer_id": np.random.choice(customer_ids, size=NUM_ACCOUNTS),  # FK
    "account_type": np.random.choice(["SAVINGS", "CHECKING", "CREDIT"], size=NUM_ACCOUNTS),
    "open_date": pd.to_datetime("2010-01-01") + pd.to_timedelta(
        np.random.randint(0, 5000, size=NUM_ACCOUNTS), unit="D"
    ),
    "status": np.random.choice(["ACTIVE", "CLOSED", "FROZEN"], size=NUM_ACCOUNTS),
})

extra_cols = generate_numeric_cols(NUM_ACCOUNTS, 5, NUM_COLS)
df_accounts = pd.concat([df_accounts, pd.DataFrame(extra_cols)], axis=1)

pq.write_table(pa.Table.from_pandas(df_accounts, preserve_index=False), "accounts.parquet")
print("accounts.parquet created.")

# -----------------------------------
# 3. TRANSACTIONS (CHILD OF ACCOUNTS)
# -----------------------------------
print("Creating transactions...")

txn_ids = np.arange(1, NUM_TRANSACTIONS + 1)

df_txn = pd.DataFrame({
    "txn_id": txn_ids,
    "account_id": np.random.choice(account_ids, size=NUM_TRANSACTIONS),  # FK
    "txn_date": pd.to_datetime("2020-01-01") + pd.to_timedelta(
        np.random.randint(0, 1500, size=NUM_TRANSACTIONS), unit="D"
    ),
    "amount": np.random.normal(100, 50, size=NUM_TRANSACTIONS).astype("float32"),
    "txn_type": np.random.choice(["DEBIT", "CREDIT", "TRANSFER"], size=NUM_TRANSACTIONS),
})

extra_cols = generate_numeric_cols(NUM_TRANSACTIONS, 5, NUM_COLS)
df_txn = pd.concat([df_txn, pd.DataFrame(extra_cols)], axis=1)

pq.write_table(pa.Table.from_pandas(df_txn, preserve_index=False), "transactions.parquet")
print("transactions.parquet created.")


# from pathlib import Path
# import numpy as np
# import pandas as pd
# import pyarrow as pa
# import pyarrow.parquet as pq

# # Parameters
# num_rows = 1_000_000
# num_cols = 1000
# filename = "data_1Mrows_1000cols.parquet"

# # Create column names
# cols = [f"col_{i:04d}" for i in range(num_cols)]

# # Generate random data as float32 to save memory
# # This will still be a large DataFrame, so ensure you have enough RAM
# data = np.random.rand(num_rows, num_cols).astype("float32")

# df = pd.DataFrame(data, columns=cols)

# output_path = Path('./data/parquet')
# output_path.mkdir(parents=True, exist_ok=True)
    
# file_path = output_path / filename

# # Convert to Arrow table and write to Parquet
# table = pa.Table.from_pandas(df, preserve_index=False)
# pq.write_table(table, file_path)

# print(f"Written: {file_path}")