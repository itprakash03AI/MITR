"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta, timezone
import uuid
import logging
from pathlib import Path
import asyncio
import os
import sys
import signal
from dotenv import load_dotenv

# ── Make Ctrl+C / SIGTERM reliably stop the server on Windows + Linux ─────────
# Register a SIGINT/SIGTERM handler that calls os._exit(0) so non-daemon
# ThreadPoolExecutor workers cannot block process shutdown.
def _force_exit(signum, frame):
    os._exit(0)

signal.signal(signal.SIGINT,  _force_exit)
signal.signal(signal.SIGTERM, _force_exit)

from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws
from api.sql_query_api import router as sql_router, set_sql_dependencies
from api.reports_api import router as reports_router, set_report_dependencies
from api.schedules_api import router as schedules_router, set_schedule_dependencies
# Load environment variables
load_dotenv()

from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType
from core.s3_storage import S3Config
from core.database import DatabaseManager
from core.websocket_manager import WebSocketManager
from core.connection_manager import ConnectionManager as ConnManager, _normalize_path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Parquet Query Engine API with S3",
    description="Enterprise-grade Parquet Query Engine with S3 and local storage support",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(data_grid_router)
app.include_router(sql_router)
app.include_router(reports_router)
app.include_router(schedules_router)

# Initialize S3 config from environment
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', 'us-east-1'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL')
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path="./data/parquet",
    chunk_size=int(os.getenv('PARQUET_CHUNK_SIZE', 100000)),
    s3_config=s3_config
)
db_manager = DatabaseManager()
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)


# Pydantic Models
class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    endpoint_url: Optional[str] = None


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|contains)$")
    value: Any


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern="^(s3|local)$")
    config: dict


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern="^(s3|local)$")
    config: dict


# Helper functions
def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how
            )
            for j in config.joins
        ]
    
    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]
    
    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]
    
    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by
    )


async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None):
    """Background task for query execution"""
    run_engine = active_engine or engine
    try:
        db_manager.update_execution(execution_id, status="processing")
        
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        output_dir = Path("./data/downloads")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.csv"
        
        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )
        
        stats = run_engine.execute_query_to_csv(
            query_config,
            str(output_file),
            progress_callback=lambda data: asyncio.create_task(progress_callback(data))
        )
        
        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.csv",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.utcnow() + timedelta(days=7)
        )
        
        if query_id:
            db_manager.increment_execution_count(query_id)
        
        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        logger.info(f"Query execution completed: {execution_id}")
        
    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}")
        
        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )
        
        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        })


# API Endpoints

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Parquet Query Engine API with S3",
        "version": "2.0.0",
        "status": "operational",
        "features": ["local_storage", "s3_storage", "websocket", "query_builder"]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    s3_status = "not_configured"
    if engine.s3_handler:
        try:
            test_result = engine.s3_handler.test_connection()
            s3_status = "connected" if test_result.get("connected") else "error"
        except:
            s3_status = "error"
    
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "s3_enabled": s3_status
    }


# S3 Configuration Endpoints

@app.post("/api/s3/configure")
async def configure_s3(config: S3ConfigModel):
    """Configure or update S3 connection"""
    try:
        s3_config = S3Config(
            bucket_name=config.bucket_name,
            region_name=config.region_name,
            aws_access_key_id=config.aws_access_key_id,
            aws_secret_access_key=config.aws_secret_access_key,
            endpoint_url=config.endpoint_url
        )
        
        engine.set_s3_config(s3_config)
        
        # Test connection
        test_result = engine.s3_handler.test_connection()
        
        return {
            "message": "S3 configured successfully",
            "connection_test": test_result
        }
    except Exception as e:
        logger.error(f"Error configuring S3: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/test")
async def test_s3_connection():
    """Test S3 connection"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        result = engine.s3_handler.test_connection()
        return result
    except Exception as e:
        logger.error(f"Error testing S3 connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/folders")
async def list_s3_folders(prefix: str = ""):
    """List folders in S3 bucket"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        folders = engine.list_s3_folders(prefix)
        return folders
    except Exception as e:
        logger.error(f"Error listing S3 folders: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/files")
async def list_s3_files(folder: str = ""):
    """List parquet files in S3 folder"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        files = engine.list_s3_files(folder)
        return files
    except Exception as e:
        logger.error(f"Error listing S3 files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# File Management Endpoints

@app.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = ""):
    """List all available parquet files from local and/or S3"""
    try:
        files = engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str):
    """Get schema information for a specific file"""
    try:
        schema = engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error(f"Error getting file schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")
        
        file_path = Path(engine.base_path) / file.filename
        
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"File uploaded: {file.filename}")
        
        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Query Management Endpoints (same as before)
@app.post("/api/queries")
async def create_query(request: SaveQueryRequest):
    """Save a new query"""
    try:
        engine_config = convert_query_config_to_engine(request.query_config)
        validation = engine.validate_query(engine_config)
        
        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )
        
        query = db_manager.create_query(
            name=request.name,
            description=request.description,
            query_config=request.query_config.dict(),
            created_by=request.created_by
        )
        
        logger.info(f"Query saved: {query['id']}")
        return query
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0):
    """List all saved queries"""
    try:
        queries = db_manager.list_queries(active_only=active_only, limit=limit, offset=offset)
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks):
    """Execute a query (saved or ad-hoc)"""
    try:
        if request.query_id:
            saved_query = db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.query_config:
            query_config_model = request.query_config
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id or query_config must be provided"
            )
        
        # Resolve engine: use connection's local path if connection_id provided
        active_engine = engine
        if request.connection_id:
            conn_record = db_manager.get_connection(request.connection_id)
            if conn_record and conn_record.get('connection_type') == 'local':
                local_path = str(_normalize_path(conn_record['config'].get('base_path', './data/parquet')))
                active_engine = ParquetQueryEngine(
                    base_path=local_path,
                    chunk_size=int(os.getenv('PARQUET_CHUNK_SIZE', 100000)),
                )

        engine_config = convert_query_config_to_engine(query_config_model)

        validation = active_engine.validate_query(engine_config)
        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )

        execution_id = str(uuid.uuid4())
        execution = db_manager.create_execution(
            execution_id=execution_id,
            query_id=request.query_id,
            query_config=query_config_model.dict(),
            executed_by=request.executed_by
        )

        background_tasks.add_task(
            execute_query_background,
            execution_id,
            engine_config,
            request.query_id,
            active_engine
        )
        
        logger.info(f"Query execution started: {execution_id}")
        
        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0):
    """List available downloads"""
    try:
        downloads = db_manager.list_download_files(status=status, limit=limit, offset=offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads/{file_id}")
async def download_file(file_id: str):
    """Download a file"""
    try:
        download_info = db_manager.get_download_file(file_id)
        
        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")
        
        file_path = Path(download_info["file_path"])
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        db_manager.increment_download_count(file_id)
        
        logger.info(f"File downloaded: {file_id}")
        
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type="text/csv"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 1. GET /api/queries/{query_id}
#    ReportPage calls api.getSavedQuery(id) to load a report by ID
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}")
async def get_query(query_id: int):
    """Get a single saved query by ID"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 2. DELETE /api/queries/{query_id}
#    SavedQueries page delete button
#    Uses db_manager.delete_query() — soft delete, sets is_active=False
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/queries/{query_id}")
async def delete_query(query_id: int):
    """Soft-delete a saved query (sets is_active=False)"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        db_manager.delete_query(query_id, soft_delete=True)
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 3. DELETE /api/downloads/{file_id}
#    Downloads page delete button
#    Uses update_download_file() to set status='deleted', removes file from disk
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str):
    """Mark a download as deleted and remove from disk"""
    try:
        download = db_manager.get_download_file(file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")

        # Remove file from disk if it exists
        file_path = Path(download["file_path"])
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        db_manager.update_download_file(file_id, status="deleted")

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 4. GET /api/executions
#    ExecutionHistory component — list recent executions
#    Uses list_executions(limit, offset, status) — all params optional
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions")
async def list_executions(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = None
):
    """List recent query executions"""
    try:
        executions = db_manager.list_executions(
            limit=limit,
            offset=offset,
            status=status if status else None
        )
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 5. GET /api/executions/{execution_id}
#    Single execution detail — used by ExecutionHistory detail view
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str):
    """Get a single execution record by ID"""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 6. GET /api/executions/{execution_id}/status
#    ReportPage polls this every 2 seconds to know when query finishes
#    Uses get_execution() — already tracked by execute_query_background()
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str):
    """
    Get status of an execution — polled by ReportPage.
    Returns: { execution_id, status, total_rows, started_at, completed_at, error_message }
    status values: pending | processing | completed | failed
    """
    try:
        execution = db_manager.get_execution(execution_id)

        if not execution:
            # Not in DB yet (just started) — check downloads as fallback
            downloads = db_manager.list_download_files(status="available", limit=500, offset=0)
            match = next(
                (d for d in downloads if d.get("execution_id") == execution_id),
                None
            )
            if match:
                return {
                    "execution_id": execution_id,
                    "status": "completed",
                    "file_id": match["file_id"],
                    "filename": match["filename"],
                    "total_rows": None,
                }
            return {"execution_id": execution_id, "status": "pending"}

        return {
            "execution_id": execution_id,
            "status": execution.get("status", "unknown"),
            "total_rows": execution.get("total_rows"),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "error_message": execution.get("error_message"),
        }

    except Exception as e:
        logger.error(f"Error getting execution status {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: The data_grid_api router already adds these routes via include_router:
#   GET /api/executions/{execution_id}/results  (pagination)
#   GET /api/executions/{execution_id}/export   (csv/excel/json)
#   GET /api/executions/{execution_id}/stats    (column stats)
# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# 7. POST /api/executions/{execution_id}/cancel  — Kill a running execution
#
# PREREQUISITE: main_with_s3.py must use asyncio.create_task() (not BackgroundTasks)
# and maintain a _running_tasks registry.
#
# ── Add to main_with_s3.py ONCE at module level (near db_manager init) ──────
#   _running_tasks: Dict[str, asyncio.Task] = {}
#
# ── Replace execute endpoint's background_tasks.add_task(...) with ──────────
#   task = asyncio.create_task(
#       execute_query_background(execution_id, query_config, request.query_id)
#   )
#   _running_tasks[execution_id] = task
#   task.add_done_callback(lambda t: _running_tasks.pop(execution_id, None))
#
# ── Then add this route ──────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """
    Cancel a running execution.
    Works by: (1) cancelling asyncio.Task if still running, (2) marking DB as cancelled.
    """
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # Cancel the asyncio task if it's still running
        task = _running_tasks.get(execution_id)
        if task and not task.done():
            task.cancel()
            logger.info(f"Cancelled asyncio task for execution {execution_id}")
            _running_tasks.pop(execution_id, None)

        # Mark as cancelled in DB
        db_manager.update_execution(
            execution_id,
            status="cancelled",
            error_message="Cancelled by user"
        )

        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 8. FIX: Downloads page shows EVERY query execution
#
# ROOT CAUSE: execute_query_background() calls db_manager.create_download_file()
# after every execution, so ALL results appear in the Downloads page.
#
# Downloads should only show EXPLICIT exports (xlsx/json/csv the user requested).
#
# SOLUTION: In execute_query_background(), change create_download_file to use
# status="internal" instead of status="available":
#
#   db_manager.create_download_file(
#       file_id=file_id,
#       execution_id=execution_id,
#       filename=f"query_result_{execution_id}.csv",
#       file_path=str(output_file),
#       file_size_bytes=stats["file_size_bytes"],
#       expires_at=datetime.utcnow() + timedelta(days=7),
#       # ADD THIS:
#       created_by="internal"       # ← use created_by field to tag internal files
#   )
#
# Then in list_download_files, the Downloads page already filters by status="available"
# by default — internal results use status="available" but we mark created_by="internal".
#
# SIMPLEST FIX (no DB schema change needed):
# Change the Downloads page list_downloads route filter to exclude internal records:
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/exports")
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').
    """
    try:
        all_files = db_manager.list_download_files(status=status, limit=limit*3, offset=0)
        # Exclude internal auto-generated results
        exports = [f for f in all_files if f.get("created_by") != "internal"]
        return exports[:limit]
    except Exception as e:
        logger.error(f"Error listing exports: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    
# ─────────────────────────────────────────────────────────────────────────────
# Connection Manager Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/connections")
async def list_connections(active_only: bool = True):
    """List all connections"""
    try:
        return db_manager.list_connections(active_only=active_only)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections")
async def create_connection(request: ConnectionConfigModel):
    """Create a new connection"""
    try:
        return db_manager.create_connection(
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@app.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest):
    """Test a connection configuration without saving"""
    try:
        return conn_manager.test_connection(request.connection_type, request.config)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int):
    """Get a specific connection"""
    conn = db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@app.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel):
    """Update an existing connection"""
    try:
        conn = db_manager.update_connection(
            connection_id,
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int):
    """Delete a connection"""
    try:
        success = db_manager.delete_connection(connection_id)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection and persist the result"""
    try:
        conn = db_manager.get_connection(connection_id)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        result = conn_manager.test_connection(conn['connection_type'], conn['config'])
        db_manager.update_connection(
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result['message']
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = ""):
    """List parquet files from a connection"""
    try:
        return conn_manager.list_files(connection_id, folder)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str):
    """Get schema for a file within a connection"""
    try:
        return conn_manager.get_schema(connection_id, file_path)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_sql_dependencies(db_manager, ws_manager, loop)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_schedule_dependencies(db_manager, ws_manager, loop)

    # Start APScheduler (non-fatal — server starts regardless)
    from core.scheduler import init_scheduler
    import threading as _threading

    def _start_scheduler():
        try:
            init_scheduler(db_manager, ws_manager, loop,
                           db_url="sqlite:///./data/parquet_query_engine.db")
        except Exception as exc:
            logger.error("APScheduler startup failed (non-fatal): %s", exc)

    _threading.Thread(target=_start_scheduler, daemon=True).start()


@app.on_event("shutdown")
async def _shutdown():
    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()


# WebSocket Endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time notifications"""
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.utcnow().isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
