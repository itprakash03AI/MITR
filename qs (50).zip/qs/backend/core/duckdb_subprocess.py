"""
DuckDB Subprocess Worker — crash-isolated DuckDB execution.

DuckDB's C++ code can crash (access violation / segfault) during httpfs
extension loading or S3 operations, especially on Windows in thread-pool
threads.  A C-level crash kills the entire Python process — no try/except
can catch it.

This module runs DuckDB operations in a **child process**.  If DuckDB
crashes, only the child dies; the main backend survives and returns an
error to the client.

Usage from main.py / worker_pool:

    from core.duckdb_subprocess import run_duckdb_copy_to
    result = run_duckdb_copy_to(conn_config, tables, bucket, sql,
                                 output_path, connection_id, timeout=600)
"""

import json
import logging
import os
import subprocess
import sys
import tempfile

logger = logging.getLogger(__name__)

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_duckdb_copy_to(
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str,
    copy_sql: str,
    output_path: str,
    connection_id: int = None,
    timeout: int = 600,
) -> dict:
    """Run a DuckDB COPY TO query in a child process.

    Returns dict with keys: total_rows, file_size_bytes
    Raises RuntimeError on crash or timeout.
    """
    args_payload = {
        "conn_config": conn_config,
        "registered_tables": registered_tables,
        "bucket": bucket,
        "setup_sql": setup_sql,
        "copy_sql": copy_sql,
        "output_path": output_path,
        "connection_id": connection_id,
    }

    # Write args to temp file (avoids command-line length limits)
    args_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", dir=_BACKEND_DIR, delete=False)
    try:
        json.dump(args_payload, args_file)
        args_file.close()

        result_path = args_file.name + ".result.json"

        proc = subprocess.Popen(
            [sys.executable, "-m", "core.duckdb_subprocess", args_file.name, result_path],
            cwd=_BACKEND_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stdout, stderr = proc.communicate(timeout=timeout)

        if proc.returncode != 0:
            stderr_text = stderr.decode("utf-8", errors="replace")[-2000:]
            stdout_text = stdout.decode("utf-8", errors="replace")[-2000:]
            logger.error(
                "DuckDB subprocess crashed (exit %d):\nSTDOUT: %s\nSTDERR: %s",
                proc.returncode, stdout_text, stderr_text,
            )
            raise RuntimeError(
                f"DuckDB query execution crashed (exit code {proc.returncode}). "
                f"This is a C-level crash in DuckDB — check backend logs for details."
            )

        if not os.path.exists(result_path):
            raise RuntimeError(
                "DuckDB subprocess completed but no result file — possible silent crash"
            )

        with open(result_path, "r") as f:
            result = json.load(f)

        if result.get("error"):
            raise RuntimeError(f"DuckDB query error: {result['error']}")

        return result

    except subprocess.TimeoutExpired:
        proc.kill()
        raise RuntimeError(f"DuckDB query timed out after {timeout}s")
    finally:
        # Cleanup temp files
        for p in (args_file.name, args_file.name + ".result.json"):
            try:
                os.unlink(p)
            except OSError:
                pass


# ═══════════════════════════════════════════════════════════════════════════════
# CLI entry point — runs in the CHILD process
# ═══════════════════════════════════════════════════════════════════════════════

def _child_main():
    """Entry point when invoked as: python -m core.duckdb_subprocess <args.json> <result.json>"""
    import duckdb

    args_path = sys.argv[1]
    result_path = sys.argv[2]

    def _write_result(data):
        with open(result_path, "w") as f:
            json.dump(data, f)

    try:
        with open(args_path, "r") as f:
            args = json.load(f)

        conn_config = args["conn_config"]
        setup_sql = args["setup_sql"]
        copy_sql = args["copy_sql"]
        output_path = args["output_path"]

        # Create DuckDB connection
        print("[SUBPROCESS] Creating DuckDB connection...", flush=True)
        con = duckdb.connect(database=":memory:")

        # Load httpfs
        print("[SUBPROCESS] Loading httpfs extension...", flush=True)
        try:
            con.execute("INSTALL 'httpfs';")
        except Exception:
            pass  # may already be installed
        con.execute("LOAD 'httpfs';")

        # Set S3 credentials
        region = conn_config.get("region_name") or conn_config.get("region") or "us-east-1"
        ep = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")
        auth_mode = (conn_config.get("auth_mode") or "keys").lower()

        key = ""
        secret = ""
        token = ""

        if auth_mode == "keys":
            key = conn_config.get("aws_access_key_id", "")
            secret = conn_config.get("aws_secret_access_key", "")
            token = conn_config.get("aws_session_token", "")
        elif auth_mode in ("profile", "assume_role", "iam_role"):
            try:
                import boto3
                if auth_mode == "assume_role":
                    role_arn = conn_config.get("role_arn")
                    if not role_arn:
                        raise ValueError("role_arn required for assume_role")
                    base_session = boto3.Session(
                        profile_name=conn_config.get("aws_profile") or None,
                        region_name=region,
                    )
                    ssl_val = conn_config.get("ssl_verify", True)
                    sts_verify = not (ssl_val is False or str(ssl_val).lower() == "false")
                    sts = base_session.client("sts", verify=sts_verify)
                    assume_kw = {
                        "RoleArn": role_arn,
                        "RoleSessionName": conn_config.get("role_session_name") or "parquet-engine",
                    }
                    if conn_config.get("external_id"):
                        assume_kw["ExternalId"] = conn_config["external_id"]
                    creds = sts.assume_role(**assume_kw)["Credentials"]
                    key = creds["AccessKeyId"]
                    secret = creds["SecretAccessKey"]
                    token = creds["SessionToken"]
                else:
                    session = boto3.Session(
                        profile_name=conn_config.get("aws_profile") or None,
                        region_name=region,
                    )
                    resolved = session.get_credentials()
                    if resolved:
                        frozen = resolved.get_frozen_credentials()
                        key = frozen.access_key or ""
                        secret = frozen.secret_key or ""
                        token = frozen.token or ""
            except Exception as exc:
                print(f"[SUBPROCESS] WARNING: credential resolution failed: {exc}", flush=True)

        def _esc(v: str) -> str:
            return v.replace("'", "''")

        print(f"[SUBPROCESS] Setting S3 creds (region={region}, auth={auth_mode})...", flush=True)
        con.execute(f"SET s3_region='{_esc(region)}';")
        if key:
            con.execute(f"SET s3_access_key_id='{_esc(key)}';")
        if secret:
            con.execute(f"SET s3_secret_access_key='{_esc(secret)}';")
        if token:
            con.execute(f"SET s3_session_token='{_esc(token)}';")
        if ep:
            use_ssl = ep.startswith("https://")
            ep_clean = ep.replace("https://", "").replace("http://", "").rstrip("/")
            con.execute(f"SET s3_endpoint='{_esc(ep_clean)}';")
            if not use_ssl:
                con.execute("SET s3_use_ssl=false;")
                con.execute("SET s3_url_style='path';")

        # S3 tuning
        try:
            con.execute("SET http_keep_alive=true;")
            con.execute("SET http_retries=3;")
            con.execute("SET http_timeout=30000;")
            con.execute("SET enable_http_metadata_cache=true;")
            con.execute("SET enable_object_cache=true;")
        except Exception:
            pass

        # Execute setup SQL (CREATE VIEW statements)
        if setup_sql:
            print(f"[SUBPROCESS] Executing setup SQL ({len(setup_sql)} chars)...", flush=True)
            for stmt in setup_sql.split(";\n"):
                stmt = stmt.strip()
                if stmt:
                    con.execute(stmt)

        # Execute COPY TO
        print(f"[SUBPROCESS] Executing COPY TO...", flush=True)
        con.execute(copy_sql)

        # Read result metadata
        import pyarrow.parquet as pq
        meta = pq.read_metadata(output_path)
        total_rows = meta.num_rows
        file_size = os.path.getsize(output_path)

        print(f"[SUBPROCESS] Done: {total_rows:,} rows, {file_size/1024/1024:.1f} MB", flush=True)
        _write_result({
            "total_rows": total_rows,
            "file_size_bytes": file_size,
        })
        con.close()

    except Exception as exc:
        print(f"[SUBPROCESS] ERROR: {type(exc).__name__}: {exc}", flush=True)
        import traceback
        traceback.print_exc()
        _write_result({"error": f"{type(exc).__name__}: {exc}"})
        sys.exit(1)


if __name__ == "__main__":
    _child_main()
