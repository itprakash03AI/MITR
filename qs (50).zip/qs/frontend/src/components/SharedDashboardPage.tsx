// @ts-nocheck
/**
 * SharedDashboardPage — public standalone dashboard view (no auth required).
 * Accessed via /shared-dashboard/:token
 * Mirrors the layout of DashboardPage but read-only; each widget auto-executes its query.
 */
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box, Typography, Paper, CircularProgress, Alert, Chip, Skeleton,
  IconButton, Tooltip, ToggleButtonGroup, ToggleButton,
} from '@mui/material';
import {
  BoltOutlined as BoltIcon, LinkOff as LinkOffIcon,
  Refresh as RefreshIcon,
  TableChart as TableIcon, BarChart as BarChartIcon,
  ShowChart as LineIcon, AreaChart as AreaIcon,
  PieChart as PieIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  Legend, ResponsiveContainer,
} from 'recharts';
import GridLayout from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import api from '../services/api';

// ── Palette ────────────────────────────────────────────────────────────────────
const COLORS = ['#1565c0','#2e7d32','#c62828','#e65100','#6a1b9a',
                '#00838f','#ff6f00','#558b2f','#ad1457','#4527a0'];

const fmtNum = (n) => {
  if (typeof n !== 'number' && isNaN(Number(n))) return String(n ?? '');
  const num = Number(n);
  const abs = Math.abs(num);
  const s = abs >= 1_000_000 ? `${(abs/1_000_000).toFixed(1)}M`
           : abs >= 1_000   ? `${(abs/1_000).toFixed(1)}K`
           : abs.toLocaleString();
  return num < 0 ? `(${s})` : s;
};

function isNumCol(rows, col) {
  const sample = rows.slice(0, 20).map(r => r[col]).filter(v => v != null);
  return sample.length > 0 && sample.every(v => !isNaN(Number(v)));
}

function aggregateRows(rows, xKey, yKey, aggFn = 'sum') {
  const map = new Map();
  rows.forEach(r => {
    const k = String(r[xKey] ?? '(blank)');
    const v = Number(r[yKey]);
    if (!map.has(k)) map.set(k, []);
    if (!isNaN(v)) map.get(k).push(v);
  });
  return Array.from(map.entries())
    .map(([name, vals]) => {
      let value = 0;
      if (aggFn === 'sum')   value = vals.reduce((a, b) => a + b, 0);
      if (aggFn === 'avg')   value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      if (aggFn === 'count') value = vals.length;
      if (aggFn === 'max')   value = vals.length ? Math.max(...vals) : 0;
      if (aggFn === 'min')   value = vals.length ? Math.min(...vals) : 0;
      return { name, value: Math.round(value * 100) / 100 };
    })
    .sort((a, b) => b.value - a.value)
    .slice(0, 40);
}

// ── FmtCell — red negatives ───────────────────────────────────────────────────
const FmtCell = ({ v, isNum }) => {
  if (!isNum) return v == null
    ? <span style={{ color:'#94a3b8', fontStyle:'italic' }}>null</span>
    : <>{String(v)}</>;
  const n = Number(v);
  if (isNaN(n)) return <>{String(v ?? '')}</>;
  const formatted = fmtNum(n);
  if (n < 0) return <span style={{ color:'#c62828', fontWeight:600 }}>{formatted}</span>;
  return <>{formatted}</>;
};

// ── ChartRenderer (shared with DashboardPage logic) ───────────────────────────
function ChartRenderer({ chartType, rows, config }) {
  if (!rows || rows.length === 0) {
    return (
      <Box sx={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%' }}>
        <Typography variant="caption" color="text.disabled">No data</Typography>
      </Box>
    );
  }

  const cols    = Object.keys(rows[0] || {});
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));
  const xKey    = config?.x_field || strCols[0] || cols[0];
  const yKey    = config?.y_field || numCols[0] || cols[1] || cols[0];
  const aggFn   = config?.agg_fn  || 'sum';

  // Table
  if (chartType === 'grid') return (
    <Box sx={{ overflowX:'auto', overflowY:'auto', height:'100%' }}>
      <table style={{ borderCollapse:'collapse', fontSize:12, width:'100%' }}>
        <thead>
          <tr>
            {cols.map(c => (
              <th key={c} style={{ background:'#f8fafc', padding:'5px 10px',
                borderBottom:'2px solid #e2e8f0', textAlign:'left',
                whiteSpace:'nowrap', fontWeight:700, fontSize:11, color:'#64748b' }}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, 100).map((row, i) => (
            <tr key={i} style={{ background: i % 2 ? '#f8fafc' : '#fff' }}>
              {cols.map(c => (
                <td key={c} style={{ padding:'4px 10px', borderBottom:'1px solid #f1f5f9',
                  maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
                  textAlign: isNumCol(rows, c) ? 'right' : 'left' }}>
                  <FmtCell v={row[c]} isNum={isNumCol(rows, c)} />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length > 100 && (
        <Box sx={{ p:1, textAlign:'center' }}>
          <Typography variant="caption" color="text.disabled">
            Showing first 100 of {rows.length.toLocaleString()} rows
          </Typography>
        </Box>
      )}
    </Box>
  );

  // KPI
  if (chartType === 'metric') {
    const val = rows[0]?.[yKey] ?? '—';
    const total = numCols.includes(yKey)
      ? rows.reduce((s, r) => s + Number(r[yKey] || 0), 0) : null;
    return (
      <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                 justifyContent:'center', height:'100%', gap:1, p:2 }}>
        <Typography variant="h2" fontWeight={800} color="primary.main" sx={{ lineHeight:1 }}>
          {fmtNum(typeof val === 'number' ? val : Number(val) || val)}
        </Typography>
        <Typography variant="body2" color="text.secondary" fontWeight={600}>{yKey}</Typography>
        {total !== null && rows.length > 1 && (
          <Chip label={`Total: ${fmtNum(total)}`} size="small" variant="outlined" sx={{ fontSize:11 }} />
        )}
      </Box>
    );
  }

  if (!numCols.includes(yKey) && numCols.length === 0) return (
    <Box sx={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%' }}>
      <Typography variant="caption" color="text.secondary">No numeric columns for chart</Typography>
    </Box>
  );

  const agg     = aggregateRows(rows, xKey, yKey, aggFn);
  const xProps  = { dataKey:'name', tick:{ fontSize:11 }, angle:-30, textAnchor:'end', interval:0 };
  const yProps  = { tick:{ fontSize:11 }, tickFormatter: fmtNum, width:58 };
  const tip     = <ReTooltip formatter={(v) => [fmtNum(Number(v)), `${aggFn.toUpperCase()}(${yKey})`]}
                              labelFormatter={(l) => `${xKey}: ${l}`} />;
  const common  = { data:agg, margin:{ top:8, right:12, left:0, bottom:56 } };

  if (chartType === 'bar') return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart {...common}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} /><YAxis {...yProps} />{tip}
        <Bar dataKey="value" radius={[4,4,0,0]} maxBarSize={48}>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  if (chartType === 'line') return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart {...common}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} /><YAxis {...yProps} />{tip}
        <Line type="monotone" dataKey="value" stroke={COLORS[0]} strokeWidth={2} dot={{ r:3 }} />
      </LineChart>
    </ResponsiveContainer>
  );

  if (chartType === 'area') return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart {...common}>
        <defs>
          <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={COLORS[0]} stopOpacity={0.3} />
            <stop offset="95%" stopColor={COLORS[0]} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} /><YAxis {...yProps} />{tip}
        <Area type="monotone" dataKey="value" stroke={COLORS[0]} fill="url(#ag)" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );

  if (chartType === 'pie') return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart margin={{ top:8, right:8, bottom:8, left:8 }}>
        <Pie data={agg} dataKey="value" nameKey="name" cx="50%" cy="45%" outerRadius="65%"
             label={({ name, percent }) => `${name}: ${(percent*100).toFixed(1)}%`} labelLine>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Pie>
        <ReTooltip formatter={(v) => [fmtNum(v), yKey]} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );

  return null;
}

// ── WidgetCard (read-only) ────────────────────────────────────────────────────
function WidgetCard({ widget }) {
  const [rows,      setRows]      = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState('');
  const [chartType, setChartType] = useState(widget.chart_type || 'grid');
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true); setError('');
    try {
      let execResp;
      if (widget.widget_type === 'saved_query')
        execResp = await api.executeQuery({ query_id: widget.source_id });
      else if (widget.widget_type === 'sql_query')
        execResp = await api.executeSqlQuery({ query_id: widget.source_id });
      else if (widget.widget_type === 'report')
        execResp = await api.executeReport(widget.source_id, widget.param_values || {});
      if (!execResp) { setLoading(false); return; }

      const fetchResults = async (execId) => {
        const res = await api.getExecutionResults(execId, 1, 500);
        setRows(res?.rows || res?.data || []);
        setLastUpdated(new Date());
      };

      if (execResp.status === 'completed' || execResp.cache_hit) {
        await fetchResults(execResp.execution_id);
        setLoading(false); return;
      }

      const execId = execResp.execution_id;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 1000));
        const status = await api.getExecutionStatus(execId);
        if (status?.status === 'completed') { await fetchResults(execId); break; }
        if (status?.status === 'failed') { setError(status.error_message || 'Query failed'); break; }
      }
    } catch (e) {
      setError(e.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  const cols    = rows.length ? Object.keys(rows[0]) : [];
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));

  const headerStat = useMemo(() => {
    if (!rows.length) return null;
    const cfg  = widget.chart_config || {};
    const xKey = cfg.x_field || strCols[0] || cols[0];
    const yKey = cfg.y_field || numCols[0] || cols[1] || cols[0];
    const aggFn = cfg.agg_fn || 'sum';
    if (chartType !== 'grid' && chartType !== 'metric' && xKey && yKey && numCols.includes(yKey)) {
      const agg = aggregateRows(rows, xKey, yKey, aggFn);
      const total = agg.reduce((s, r) => s + r.value, 0);
      return `${aggFn.toUpperCase()}(${yKey}) by ${xKey} · ${agg.length} groups · ${fmtNum(Math.round(total*100)/100)} total`;
    }
    return `${rows.length.toLocaleString()} rows · ${cols.length} columns`;
  }, [rows, widget.chart_config, chartType]);

  return (
    <Paper elevation={2} sx={{ height:'100%', display:'flex', flexDirection:'column',
                                overflow:'hidden', borderRadius:2 }}>
      {/* Header */}
      <Box sx={{ px:1.5, py:0.75, borderBottom:1, borderColor:'divider',
                 display:'flex', alignItems:'center', gap:0.5, minHeight:42,
                 background:'linear-gradient(135deg,#f8fafc 0%,#f1f5f9 100%)' }}>
        <Box sx={{ flex:1, overflow:'hidden', mr:0.5 }}>
          <Typography variant="subtitle2" fontWeight={700} fontSize={13} noWrap>
            {widget.title || 'Widget'}
          </Typography>
          {!loading && headerStat && (
            <Typography variant="caption" color="text.secondary" sx={{ display:'block', lineHeight:1.2 }}>
              {headerStat}{lastUpdated && ` · ${lastUpdated.toLocaleTimeString()}`}
            </Typography>
          )}
        </Box>

        <ToggleButtonGroup size="small" value={chartType} exclusive
                           onChange={(_, v) => v && setChartType(v)}
                           sx={{ '& .MuiToggleButton-root':{ py:0, px:0.4, minWidth:26 } }}>
          <ToggleButton value="grid"><Tooltip title="Table"><TableIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="bar"><Tooltip title="Bar"><BarChartIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="line"><Tooltip title="Line"><LineIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="area"><Tooltip title="Area"><AreaIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="pie"><Tooltip title="Pie"><PieIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
        </ToggleButtonGroup>

        <Tooltip title="Refresh">
          <IconButton size="small" onClick={loadData}><RefreshIcon sx={{ fontSize:14 }} /></IconButton>
        </Tooltip>
      </Box>

      {/* Content */}
      <Box sx={{ flex:1, overflow:'hidden', p: chartType === 'grid' ? 0 : 1, minHeight:0 }}>
        {loading ? (
          <Box sx={{ p:1.5 }}>
            <Skeleton variant="rectangular" height={30} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={80} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={50} sx={{ borderRadius:1 }} />
          </Box>
        ) : error ? (
          <Box sx={{ p:1 }}><Alert severity="error" sx={{ fontSize:12 }}>{error}</Alert></Box>
        ) : (
          <ChartRenderer chartType={chartType} rows={rows} config={widget.chart_config || {}} />
        )}
      </Box>
    </Paper>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function SharedDashboardPage() {
  const { token } = useParams();
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(null);
  const [data,     setData]     = useState(null);       // {dashboard, widgets, share}
  const [width,    setWidth]    = useState(1200);
  const containerRef = useRef(null);

  useEffect(() => {
    api.getSharedDashboard(token)
      .then(d => { setData(d); setLoading(false); })
      .catch(err => { setError(String(err)); setLoading(false); });
  }, [token]);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(entries => {
      setWidth(entries[0]?.contentRect.width || 1200);
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  // ── Loading ────────────────────────────────────────────────────────────────
  if (loading) return (
    <Box sx={{ display:'flex', justifyContent:'center', alignItems:'center', minHeight:'100vh' }}>
      <CircularProgress />
    </Box>
  );

  // ── Error / invalid token ──────────────────────────────────────────────────
  if (error) return (
    <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
               justifyContent:'center', minHeight:'100vh', gap:2, p:4,
               background:'linear-gradient(135deg,#f8fafc 0%,#e8f4fd 100%)' }}>
      <Box sx={{ width:72, height:72, borderRadius:'50%', bgcolor:'#fee2e2',
                 display:'flex', alignItems:'center', justifyContent:'center' }}>
        <LinkOffIcon sx={{ fontSize:36, color:'#dc2626' }} />
      </Box>
      <Typography variant="h5" fontWeight={700}>Dashboard Not Available</Typography>
      <Typography color="text.secondary" textAlign="center" maxWidth={420}>
        This shared dashboard link is invalid, expired, or has been revoked.
        Please ask the owner to generate a new link.
      </Typography>
    </Box>
  );

  const { dashboard, widgets, share } = data;

  const layouts = widgets.map(w => ({
    i: String(w.id),
    x: w.layout?.x ?? 0, y: w.layout?.y ?? 0,
    w: w.layout?.w ?? 6,  h: w.layout?.h ?? 5,
    static: true,   // read-only — no drag/resize
  }));

  return (
    <Box sx={{ minHeight:'100vh', background:'linear-gradient(135deg,#f8fafc 0%,#e8f4fd 100%)', pb:6 }}>

      {/* Top bar */}
      <Box sx={{ background:'linear-gradient(90deg,#0d47a1 0%,#1976d2 100%)',
                 px:{ xs:2, sm:4 }, py:1.5, display:'flex', alignItems:'center', gap:2 }}>
        <BoltIcon sx={{ color:'#fff', fontSize:26 }} />
        <Typography variant="h6" fontWeight={800} sx={{ color:'#fff', flex:1 }}>
          QueryStudio
        </Typography>
        <Chip label="Shared Dashboard" size="small"
              sx={{ bgcolor:'rgba(255,255,255,0.18)', color:'#fff', fontWeight:600, fontSize:11 }} />
      </Box>

      {/* Dashboard header */}
      <Box sx={{ px:{ xs:2, sm:4 }, pt:3, pb:1 }}>
        <Typography variant="h5" fontWeight={700}>{dashboard.name}</Typography>
        {dashboard.description && (
          <Typography variant="body2" color="text.secondary" sx={{ mt:0.5 }}>
            {dashboard.description}
          </Typography>
        )}
        <Box sx={{ display:'flex', gap:1, mt:1, flexWrap:'wrap' }}>
          {share.created_by && (
            <Chip label={`Shared by ${share.created_by}`} size="small" variant="outlined" />
          )}
          <Chip label={`${widgets.length} widget${widgets.length !== 1 ? 's' : ''}`}
                size="small" variant="outlined" />
          {share.expires_at && (
            <Chip label={`Expires ${new Date(share.expires_at).toLocaleDateString()}`}
                  size="small" variant="outlined" color="warning" />
          )}
        </Box>
      </Box>

      {/* Widget grid */}
      <Box ref={containerRef} sx={{ px:{ xs:1, sm:3 }, pt:1 }}>
        {widgets.length === 0 ? (
          <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                     justifyContent:'center', height:250, gap:2 }}>
            <Typography color="text.secondary">This dashboard has no widgets.</Typography>
          </Box>
        ) : (
          <GridLayout
            className="layout"
            layout={layouts}
            cols={12}
            rowHeight={55}
            width={width - 48}
            margin={[10, 10]}
            isDraggable={false}
            isResizable={false}
          >
            {widgets.map(w => (
              <div key={String(w.id)}>
                <WidgetCard widget={w} />
              </div>
            ))}
          </GridLayout>
        )}
      </Box>

    </Box>
  );
}
