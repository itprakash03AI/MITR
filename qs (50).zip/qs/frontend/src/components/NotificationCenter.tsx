import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../context/NotificationContext';
import { Snackbar, Alert, Box, Button, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const NotificationCenter = () => {
  const { notifications, removeNotification } = useNotifications();
  const navigate = useNavigate();

  // Show up to 3 most recent notifications stacked at bottom-right
  return (
    <>
      {notifications.slice(-3).map((n, i) => (
        <Snackbar
          key={n.id}
          open
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          sx={{ bottom: { xs: 24 + i * 84 } }}
          autoHideDuration={n.type === 'error' || n.action ? null : 5000}
          onClose={() => removeNotification(n.id)}
        >
          <Alert
            severity={n.type === 'info' ? 'info' : n.type}
            variant="filled"
            sx={{ width: '100%', minWidth: 300, maxWidth: 440 }}
            action={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                {n.action && (
                  <Button
                    size="small"
                    color="inherit"
                    sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}
                    onClick={() => { removeNotification(n.id); navigate(n.action!.href); }}
                  >
                    {n.action.label}
                  </Button>
                )}
                <IconButton size="small" color="inherit" onClick={() => removeNotification(n.id)}
                  sx={{ opacity: 0.8, '&:hover': { opacity: 1 } }}>
                  <CloseIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </Box>
            }
          >
            <strong>{n.title}</strong>
            {n.message && (
              <Box sx={{ mt: 0.25, fontSize: '0.8125rem', opacity: 0.92 }}>{n.message}</Box>
            )}
          </Alert>
        </Snackbar>
      ))}
    </>
  );
};

export default NotificationCenter;
