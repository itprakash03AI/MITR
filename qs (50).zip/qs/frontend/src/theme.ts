import { createTheme, Theme } from '@mui/material/styles';

const sharedTypography = {
  fontFamily: [
    '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto',
    '"Helvetica Neue"', 'Arial', 'sans-serif',
  ].join(','),
  h5: { fontWeight: 700 },
  h6: { fontWeight: 600 },
  subtitle2: { fontWeight: 500 },
};

const sharedComponents = {
  MuiButton: {
    defaultProps: { disableElevation: true as const },
    styleOverrides: {
      root: { textTransform: 'none' as const, fontWeight: 500 },
    },
  },
  MuiListItemButton: {
    styleOverrides: {
      root: {
        borderRadius: 8,
        margin: '2px 8px',
        '&.Mui-selected': {
          backgroundColor: 'rgba(21, 101, 192, 0.08)',
          '&:hover': { backgroundColor: 'rgba(21, 101, 192, 0.12)' },
        },
      },
    },
  },
  MuiCard: {
    styleOverrides: {
      root: { boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)' },
    },
  },
  MuiChip: {
    styleOverrides: {
      root: { fontWeight: 500 },
    },
  },
};

export const createAppTheme = (mode: 'light' | 'dark'): Theme => {
  const isLight = mode === 'light';

  return createTheme({
    palette: {
      mode,
      primary:    { main: '#1565c0', dark: '#003c8f', light: '#5e92f3' },
      secondary:  { main: '#64748b', dark: '#475569', light: '#94a3b8' },
      success:    { main: '#10b981', dark: '#059669', light: '#34d399' },
      warning:    { main: '#f59e0b', dark: '#d97706', light: '#fbbf24' },
      error:      { main: '#ef4444', dark: '#dc2626', light: '#f87171' },
      background: isLight
        ? { default: '#f8fafc', paper: '#ffffff' }
        : { default: '#0f172a', paper: '#1e293b' },
      text: isLight
        ? { primary: '#0f172a', secondary: '#64748b' }
        : { primary: '#f1f5f9', secondary: '#94a3b8' },
      divider: isLight ? '#e2e8f0' : '#334155',
    },
    shape: { borderRadius: 8 },
    typography: {
      ...sharedTypography,
      subtitle2: { ...sharedTypography.subtitle2, color: isLight ? '#64748b' : '#94a3b8' },
    },
    components: {
      ...sharedComponents,
      MuiDrawer: {
        styleOverrides: {
          paper: {
            borderRight: `1px solid ${isLight ? '#e2e8f0' : '#334155'}`,
            backgroundColor: isLight ? '#ffffff' : '#1e293b',
          },
        },
      },
    },
  });
};

// Default export for backwards compatibility
const theme = createAppTheme('light');
export default theme;
