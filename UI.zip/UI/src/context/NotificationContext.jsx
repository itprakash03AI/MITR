import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useWebSocket } from './WebSocketContext';

const NotificationContext = createContext(null);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }) => {
  const [notifications, setNotifications] = useState([]);
  const { addListener } = useWebSocket();

  useEffect(() => {
    // Execution events are handled directly by the component that triggered them
    // (CompleteQueryBuilder, SavedQueries, etc.) to avoid duplicate notifications.
    const COMPONENT_HANDLED = new Set([
      'pong', 'connection_established',
      'execution_started', 'execution_progress',
      'execution_completed', 'execution_failed',
    ]);

    const removeListener = addListener((message) => {
      if (message.type && !COMPONENT_HANDLED.has(message.type)) {
        addNotification({
          type: getNotificationType(message.type),
          title: getNotificationTitle(message.type),
          message: getNotificationMessage(message),
          data: message,
          timestamp: message.timestamp || new Date().toISOString()
        });
      }
    });

    return () => removeListener();
  }, [addListener]);

  const getNotificationType = (messageType) => {
    if (messageType.includes('completed')) return 'success';
    if (messageType.includes('failed') || messageType.includes('error')) return 'error';
    if (messageType.includes('progress')) return 'info';
    if (messageType.includes('started')) return 'info';
    return 'info';
  };

  const getNotificationTitle = (messageType) => {
    const titles = {
      'execution_started': 'Query Execution Started',
      'execution_progress': 'Query Processing',
      'execution_completed': 'Query Completed',
      'execution_failed': 'Query Failed',
      'download_ready': 'Download Ready',
    };
    return titles[messageType] || 'Notification';
  };

  const getNotificationMessage = (message) => {
    switch (message.type) {
      case 'execution_started':
        return `Execution ${message.execution_id.substring(0, 8)}... started`;
      case 'execution_progress':
        return `Processed ${message.data?.total_rows || 0} rows`;
      case 'execution_completed':
        return `Query completed successfully. ${message.stats?.total_rows || 0} rows processed`;
      case 'execution_failed':
        return `Execution failed: ${message.error}`;
      case 'download_ready':
        return 'Your file is ready to download';
      default:
        return message.message || 'New notification';
    }
  };

  const addNotification = useCallback((notification) => {
    const id = Date.now() + Math.random();
    const newNotification = {
      id,
      ...notification,
      timestamp: notification.timestamp || new Date().toISOString()
    };

    setNotifications(prev => [newNotification, ...prev].slice(0, 50)); // Keep last 50

    // Auto-remove after 5 seconds for non-error notifications
    if (notification.type !== 'error') {
      setTimeout(() => {
        removeNotification(id);
      }, 5000);
    }
  }, []);

  const removeNotification = useCallback((id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  const value = {
    notifications,
    addNotification,
    removeNotification,
    clearAll
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};
