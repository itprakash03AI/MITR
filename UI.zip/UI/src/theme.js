import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary:    { main: '#1565c0', dark: '#003c8f', light: '#5e92f3' },
    secondary:  { main: '#64748b', dark: '#475569', light: '#94a3b8' },
    success:    { main: '#10b981', dark: '#059669', light: '#34d399' },
    warning:    { main: '#f59e0b', dark: '#d97706', light: '#fbbf24' },
    error:      { main: '#ef4444', dark: '#dc2626', light: '#f87171' },
    background: { default: '#f8fafc', paper: '#ffffff' },
    text:       { primary: '#0f172a', secondary: '#64748b' },
    divider:    '#e2e8f0',
  },
  shape: { borderRadius: 8 },
  typography: {
    fontFamily: [
      '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto',
      '"Helvetica Neue"', 'Arial', 'sans-serif',
    ].join(','),
    h5: { fontWeight: 700 },
    h6: { fontWeight: 600 },
    subtitle2: { fontWeight: 500, color: '#64748b' },
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: { textTransform: 'none', fontWeight: 500 },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          borderRight: '1px solid #e2e8f0',
          backgroundColor: '#ffffff',
        },
      },
    },
    MuiListItemButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          margin: '2px 8px',
          '&.Mui-selected': {
            backgroundColor: 'rgba(21, 101, 192, 0.08)',
            '&:hover': { backgroundColor: 'rgba(21, 101, 192, 0.12)' },
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)' },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 500 },
      },
    },
  },
});

export default theme;
