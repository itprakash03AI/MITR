import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from './theme';
import Layout from './components/Layout';
import CompleteQueryBuilder from './components/CompleteQueryBuilder';
import SavedQueries from './components/SavedQueries';
import Downloads from './components/Downloads';
import ExecutionHistory from './components/ExecutionHistory';
import ReportPage from './components/ReportPage';
import ConnectionManager from './components/ConnectionManager';
import SqlQueryPage from './components/SqlQueryPage';
import ReportsManagerPage from './components/ReportsManagerPage';
import SchedulesPage from './components/SchedulesPage';
import FilePreviewPage from './components/FilePreviewPage';
import { WebSocketProvider } from './context/WebSocketContext';
import { NotificationProvider } from './context/NotificationContext';
import NotificationCenter from './components/NotificationCenter';
import './App.css';

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <WebSocketProvider>
          <NotificationProvider>
            <Layout>
              <NotificationCenter />
              <Routes>
                <Route path="/connections"       element={<ConnectionManager />} />
                <Route path="/"                  element={<CompleteQueryBuilder />} />
                <Route path="/reports"           element={<ReportPage />} />
                <Route path="/reports/:reportId" element={<ReportPage />} />
                <Route path="/saved-queries"     element={<SavedQueries />} />
                <Route path="/executions"        element={<ExecutionHistory />} />
                <Route path="/downloads"         element={<Downloads />} />
                <Route path="/sql"              element={<SqlQueryPage />} />
                <Route path="/report-manager"  element={<ReportsManagerPage />} />
                <Route path="/schedules"        element={<SchedulesPage />} />
                <Route path="/file-preview"     element={<FilePreviewPage />} />
              </Routes>
            </Layout>
          </NotificationProvider>
        </WebSocketProvider>
      </Router>
    </ThemeProvider>
  );
}

export default App;
