/**
 * API Service - Complete & Correct
 * Every method maps to an actual backend route.
 * Where routes are missing, safe fallbacks are returned.
 *
 * ACTUAL BACKEND ROUTES (main_with_s3.py + data_grid_api.py):
 *   GET    /health
 *   GET    /api/files
 *   GET    /api/files/{file_path:path}/schema    ← PATH param, NOT query string
 *   POST   /api/files/upload
 *   POST   /api/s3/configure
 *   GET    /api/s3/test
 *   GET    /api/s3/folders?prefix=
 *   GET    /api/s3/files?folder=
 *   POST   /api/queries
 *   GET    /api/queries?active_only=true
 *   GET    /api/queries/{id}                     ← needs adding to backend
 *   DELETE /api/queries/{id}                     ← needs adding to backend
 *   POST   /api/execute
 *   GET    /api/downloads?status=
 *   GET    /api/downloads/{file_id}
 *   DELETE /api/downloads/{file_id}              ← needs adding to backend
 *   GET    /api/executions                       ← needs adding to backend
 *   GET    /api/executions/{id}/results          (data_grid_api)
 *   GET    /api/executions/{id}/export           (data_grid_api)
 *   GET    /api/executions/{id}/stats            (data_grid_api)
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const safeFetch = async (url, options = {}) => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  console.log(`🌐 ${options.method || 'GET'} ${fullUrl}`);
  const response = await fetch(fullUrl, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
  });
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try { const e = await response.json(); detail = e.detail || e.message || detail; } catch {}
    throw new Error(detail);
  }
  return response.json();
};

const openDownload = (path) =>
  window.open(path.startsWith('http') ? path : `${API_BASE_URL}${path}`, '_blank');

// ─────────────────────────────────────────────────────────────
// Transform frontend component query state → backend QueryConfigModel
// CompleteQueryBuilder state: { selectedTables, joins, selectedColumns, filters, orderBy, limit }
// Backend expects:            { files, joins, filters, columns, order_by, limit }
// ─────────────────────────────────────────────────────────────
const toBackendQueryConfig = (qc) => {
  // Already in backend format (has 'files' key)
  if (qc.files) return qc;

  // Transform from component state format
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn],
          how:        j.how || j.joinType || 'inner'
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? f.value.split(',').map(v => v.trim())
            : f.value
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns.map(c => c.columnName || c)
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  || null,
    offset: qc.offset || 0,
  };
};

const api = {

  // ── Utility ───────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: err.message })),

  // ── Files ─────────────────────────────────────────────────
  listFiles: (storageType = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },

  /**
   * GET /api/files/{file_path:path}/schema
   * Returns { file, storage_type, columns: [{name, type, nullable}], num_rows }
   */
  getFileSchema: (filePath) =>
    safeFetch(`/api/files/${filePath}/schema`)
      .catch(err => {
        console.warn(`Schema failed for ${filePath}:`, err.message);
        return { file: filePath, columns: [], num_rows: 0 };
      }),

  uploadFile: (file) => {
    const form = new FormData();
    form.append('file', file);
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 (legacy — use Connections API instead) ───────────
  configureS3: (config) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Connections ─────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),

  getConnection: (id) =>
    safeFetch(`/api/connections/${id}`),

  createConnection: (data) =>
    safeFetch('/api/connections', { method: 'POST', body: JSON.stringify(data) }),

  updateConnection: (id, data) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  deleteConnection: (id) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),

  testConnection: (data) =>
    safeFetch('/api/connections/test', { method: 'POST', body: JSON.stringify(data) }),

  testSavedConnection: (id) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),

  listConnectionFiles: (connId, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),

  getConnectionFileSchema: (connId, filePath) =>
    safeFetch(`/api/connections/${connId}/files/${filePath}/schema`),

  // ── Saved Queries ─────────────────────────────────────────

  /**
   * GET /api/queries?active_only=true
   * Accepts both boolean and object { active_only: true } — handles both call styles
   */
  listQueries: (activeOnly = true) => {
    const active = typeof activeOnly === 'object'
      ? (activeOnly.active_only ?? true)
      : activeOnly;
    return safeFetch(`/api/queries?active_only=${active}`).catch(() => []);
  },

  getSavedQueries: (activeOnly = true) => api.listQueries(activeOnly),

  /** GET /api/queries/{id}  — added to backend via backend_additions.py */
  getSavedQuery: (id) =>
    safeFetch(`/api/queries/${id}`).catch(err => {
      console.warn(`GET /api/queries/${id}:`, err.message);
      return null;
    }),

  /**
   * POST /api/queries
   * Backend expects SaveQueryRequest: { name, description, query_config: QueryConfigModel }
   * Automatically transforms component state format → backend format
   */
  saveQuery: (data) => {
    const payload = {
      name:        data.name,
      description: data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
      created_by:  data.created_by || null,
    };
    console.log('💾 Saving query with payload:', JSON.stringify(payload, null, 2));
    return safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(payload) });
  },

  /** PUT /api/queries/{id} — update existing saved query */
  updateQuery: (id, data) => {
    const payload = {
      name:        data.name,
      description: data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
    };
    return safeFetch(`/api/queries/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
  },

  /** DELETE /api/queries/{id} — added to backend via backend_additions.py */
  deleteQuery: (id) =>
    safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),

  // ── Query Execution ───────────────────────────────────────
  /** POST /api/execute — accepts { query_config } or { query_id } */
  executeQuery: (payload) => {
    // If passing query_config, ensure it's in backend format
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute', { method: 'POST', body: JSON.stringify(body) });
  },

  // ── Executions ────────────────────────────────────────────
  /**
   * GET /api/executions?limit=&offset=&status=
   * ExecutionHistory calls: api.listExecutions({ status: 'completed' })
   * Also handles: api.listExecutions() or api.listExecutions(50)
   */
  listExecutions: (params = {}) => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  p.limit  !== undefined ? p.limit  : 50);
    qs.append('offset', p.offset !== undefined ? p.offset : 0);
    if (p.status) qs.append('status', p.status);
    return safeFetch(`/api/executions?${qs}`).catch(() => []);
  },

  /** GET /api/executions/{id} */
  getExecution: (executionId) =>
    safeFetch(`/api/executions/${executionId}`).catch(() => null),

  /**
   * POST /api/executions/{id}/cancel — kill a running execution
   * Added to backend via backend_additions.py
   */
  cancelExecution: (executionId) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),

  /**
   * Execution status — uses dedicated endpoint from backend_additions.py
   * Falls back to scanning downloads list if endpoint missing
   */
  getExecutionStatus: async (executionId) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      // Fallback: scan downloads list
      try {
        const downloads = await api.listDownloads('');
        const match = downloads.find(d => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ─────────────────────────────────────────────
  /**
   * GET /api/downloads?status=available
   * Returns [{ file_id, execution_id, filename, file_size_bytes, status, ... }]
   */
  listDownloads: (status = 'available') => {
    const qs = status ? `?status=${status}` : '';
    return safeFetch(`/api/downloads${qs}`).catch(() => []);
  },

  getDownloads: (status = 'available') => api.listDownloads(status),

  /** GET /api/downloads/{file_id} — triggers browser file download */
  downloadFile: (fileId) => openDownload(`/api/downloads/${fileId}`),

  /** DELETE /api/downloads/{file_id} — added to backend via backend_additions.py */
  deleteDownload: (fileId) =>
    safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Results (data_grid_api router) ────────────────────────
  getExecutionResults: (executionId, page = 1, pageSize = 100, sortColumn = null, sortDirection = 'asc', filters = null) => {
    const params = new URLSearchParams({ page, page_size: pageSize });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },

  exportResults: (executionId, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),

  getExecutionStats: (executionId) =>
    safeFetch(`/api/executions/${executionId}/stats`),

  // ── SQL Queries (Trino / Snowflake / Databricks) ──────────────────────────

  /** GET /api/sql/connector-types — field definitions for each connector type */
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),

  /** GET /api/sql/queries */
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),

  /** POST /api/sql/queries */
  createSqlQuery: (data) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: JSON.stringify(data) }),

  /** GET /api/sql/queries/{id} */
  getSqlQuery: (id) =>
    safeFetch(`/api/sql/queries/${id}`),

  /** PUT /api/sql/queries/{id} */
  updateSqlQuery: (id, data) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  /** DELETE /api/sql/queries/{id} */
  deleteSqlQuery: (id) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),

  /** POST /api/sql/execute */
  executeSqlQuery: (payload) =>
    safeFetch('/api/sql/execute', { method: 'POST', body: JSON.stringify(payload) }),

  // ── SQL Schema browsing ───────────────────────────────────────────────────

  /** GET /api/sql/connections/{id}/catalogs */
  listSqlCatalogs: (connectionId) =>
    safeFetch(`/api/sql/connections/${connectionId}/catalogs`),

  /** GET /api/sql/connections/{id}/schemas?catalog= */
  listSqlSchemas: (connectionId, catalog) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),

  /** GET /api/sql/connections/{id}/tables?catalog=&schema= */
  listSqlTables: (connectionId, catalog, schema) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),

  /** GET /api/sql/connections/{id}/columns?catalog=&schema=&table= */
  listSqlColumns: (connectionId, catalog, schema, table) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),

  /** POST /api/sql/connections/{id}/test */
  testSqlConnection: (connectionId) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Parametric Reports ────────────────────────────────────────────────────

  /** GET /api/reports?active_only=true */
  listReports: (activeOnly = true) =>
    safeFetch(`/api/reports?active_only=${activeOnly}`).catch(() => []),

  /** POST /api/reports */
  createReport: (data) =>
    safeFetch('/api/reports', { method: 'POST', body: JSON.stringify(data) }),

  /** GET /api/reports/{id} */
  getReport: (id) =>
    safeFetch(`/api/reports/${id}`),

  /** PUT /api/reports/{id} */
  updateReport: (id, data) =>
    safeFetch(`/api/reports/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  /** DELETE /api/reports/{id} */
  deleteReport: (id) =>
    safeFetch(`/api/reports/${id}`, { method: 'DELETE' }),

  /** POST /api/reports/{id}/execute */
  executeReport: (id, paramValues = {}, rowLimit = null, executedBy = null) =>
    safeFetch(`/api/reports/${id}/execute`, {
      method: 'POST',
      body: JSON.stringify({ param_values: paramValues, row_limit: rowLimit, executed_by: executedBy }),
    }),

  /** GET /api/reports/{id}/source-info */
  getReportSourceInfo: (id) =>
    safeFetch(`/api/reports/${id}/source-info`),

  /** GET /api/reports/{id}/columns — available columns + date shortcuts */
  getReportColumns: (id) =>
    safeFetch(`/api/reports/${id}/columns`).catch(() => ({ columns: [], date_shortcuts: [] })),

  /**
   * GET /api/reports/{id}/param-values?param_name={name}
   * Returns sorted distinct non-null values for a column from the report's
   * parquet source — used to auto-populate multi-select dropdowns.
   * Returns { values: [], total: 0, truncated: false } on failure.
   */
  getReportParamValues: (id, paramName, limit = 1000) =>
    safeFetch(`/api/reports/${id}/param-values?param_name=${encodeURIComponent(paramName)}&limit=${limit}`)
      .catch(() => ({ values: [], total: 0, truncated: false })),

  /** GET /api/reports/{id}/download?param=value — synchronous CSV, opens in new tab */
  downloadReportDirect: (id, paramValues = {}) => {
    const qs = new URLSearchParams(paramValues).toString();
    openDownload(`/api/reports/${id}/download${qs ? '?' + qs : ''}`);
  },

  /** GET /api/downloads/{file_id}/preview — preview any file by file_id (no execution_id needed) */
  previewDownloadFile: (fileId, page = 1, pageSize = 100) =>
    safeFetch(`/api/downloads/${fileId}/preview?page=${page}&page_size=${pageSize}`),

  // ── Scheduled Downloads ───────────────────────────────────────────────────

  /** GET /api/schedules?active_only=false */
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),

  /** POST /api/schedules */
  createSchedule: (data) =>
    safeFetch('/api/schedules', { method: 'POST', body: JSON.stringify(data) }),

  /** GET /api/schedules/{id} */
  getSchedule: (id) =>
    safeFetch(`/api/schedules/${id}`),

  /** PUT /api/schedules/{id} */
  updateSchedule: (id, data) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  /** DELETE /api/schedules/{id} */
  deleteSchedule: (id) =>
    safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),

  /** POST /api/schedules/{id}/pause */
  pauseSchedule: (id) =>
    safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),

  /** POST /api/schedules/{id}/resume */
  resumeSchedule: (id) =>
    safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),

  /** POST /api/schedules/{id}/run-now */
  runScheduleNow: (id) =>
    safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),

  /** GET /api/schedules/scheduler-status */
  getSchedulerStatus: () =>
    safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),
};

export default api;