/**
 * API Service - Complete & Correct
 *
 * Every method maps to an ACTUAL route in main_with_s3.py or data_grid_api.py.
 * Where backend routes are missing (GET /api/queries/{id}, DELETE, executions list)
 * safe fallbacks are returned so the UI doesn't crash.
 *
 * BACKEND ROUTES (main_with_s3.py):
 *   GET    /                                    root
 *   GET    /health                              health
 *   POST   /api/s3/configure                   configure S3
 *   GET    /api/s3/test                        test S3
 *   GET    /api/s3/folders?prefix=             list S3 folders
 *   GET    /api/s3/files?folder=               list S3 files
 *   GET    /api/files                          list local+S3 files
 *   GET    /api/files/{file_path:path}/schema  ← PATH PARAM, not query string
 *   POST   /api/files/upload                   upload file
 *   POST   /api/queries                        save query
 *   GET    /api/queries                        list queries
 *   POST   /api/execute                        execute query
 *   GET    /api/downloads?status=              list downloads
 *   GET    /api/downloads/{file_id}            download file
 *   WS     /ws                                websocket
 *
 * DATA GRID ROUTES (data_grid_api.py router):
 *   GET    /api/executions/{id}/results        paginated results
 *   GET    /api/executions/{id}/export         export csv/excel/json
 *   GET    /api/executions/{id}/stats          column stats
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// ─────────────────────────────────────────────────────────────
// Core fetch helper
// ─────────────────────────────────────────────────────────────
const safeFetch = async (url, options = {}) => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  console.log(`🌐 ${options.method || 'GET'} ${fullUrl}`);

  const response = await fetch(fullUrl, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
  });

  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try { const err = await response.json(); detail = err.detail || err.message || detail; } catch {}
    throw new Error(detail);
  }
  return response.json();
};

// ─────────────────────────────────────────────────────────────
// Open a URL for file download (no JSON expected)
// ─────────────────────────────────────────────────────────────
const openDownload = (path) => {
  const url = path.startsWith('http') ? path : `${API_BASE_URL}${path}`;
  window.open(url, '_blank');
};

// ─────────────────────────────────────────────────────────────
const api = {

  // ── Utility ──────────────────────────────────────────────

  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: err.message })),

  // ── Files ─────────────────────────────────────────────────

  /** GET /api/files  (returns array with columns[] already embedded) */
  listFiles: (storageType = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },

  /**
   * GET /api/files/{file_path:path}/schema
   * file_path is a PATH PARAMETER embedded in the URL.
   * e.g. getFileSchema('customer_data.parquet')
   *   → /api/files/customer_data.parquet/schema
   *
   * Response shape from engine.get_file_schema():
   *   { file, storage_type, columns: [{name, type, nullable}], num_rows }
   *
   * The frontend (CompleteQueryBuilder loadSchemas) does:
   *   schema.columns  ← array of {name, type, nullable} objects  ✅ matches
   */
  getFileSchema: (filePath) =>
    safeFetch(`/api/files/${filePath}/schema`)
      .catch(err => {
        console.warn(`Schema failed for ${filePath}:`, err.message);
        return { file: filePath, columns: [], num_rows: 0 };
      }),

  uploadFile: (file) => {
    const form = new FormData();
    form.append('file', file);
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 ────────────────────────────────────────────────────

  configureS3: (config) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),

  testS3Connection: () =>
    safeFetch('/api/s3/test'),

  /** GET /api/s3/folders?prefix= */
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),

  /** GET /api/s3/files?folder= */
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Saved Queries ─────────────────────────────────────────

  /** GET /api/queries */
  listQueries: (activeOnly = true) =>
    safeFetch(`/api/queries?active_only=${activeOnly}`).catch(() => []),

  /** Alias – some components call getSavedQueries, others call listQueries */
  getSavedQueries: (activeOnly = true) =>
    safeFetch(`/api/queries?active_only=${activeOnly}`).catch(() => []),

  /**
   * GET /api/queries/{id}
   * ⚠️  This route does NOT exist in main_with_s3.py yet.
   * Returns null gracefully until the backend adds it.
   */
  getSavedQuery: (id) =>
    safeFetch(`/api/queries/${id}`).catch(err => {
      console.warn(`GET /api/queries/${id} failed (endpoint may be missing):`, err.message);
      return null;
    }),

  /** POST /api/queries */
  saveQuery: (data) =>
    safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(data) }),

  /**
   * DELETE /api/queries/{id}
   * ⚠️  This route does NOT exist in main_with_s3.py yet.
   */
  deleteQuery: (id) =>
    safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),

  // ── Query Execution ───────────────────────────────────────

  /** POST /api/execute  → { execution_id, status, started_at, message } */
  executeQuery: (payload) =>
    safeFetch('/api/execute', { method: 'POST', body: JSON.stringify(payload) }),

  // ── Downloads ─────────────────────────────────────────────

  /**
   * GET /api/downloads?status=available
   * Returns array of { file_id, execution_id, filename, file_size_bytes,
   *                    status, created_at, expires_at, download_count, ... }
   */
  listDownloads: (status = 'available') => {
    const qs = status ? `?status=${status}` : '';
    return safeFetch(`/api/downloads${qs}`).catch(() => []);
  },

  /** Alias */
  getDownloads: (status = 'available') => api.listDownloads(status),

  /**
   * GET /api/downloads/{file_id}  → triggers file download (not JSON)
   * Note: uses file_id from the downloads list, NOT execution_id
   */
  downloadFile: (fileId) =>
    openDownload(`/api/downloads/${fileId}`),

  /**
   * DELETE /api/downloads/{file_id}
   * ⚠️  This route does NOT exist in main_with_s3.py yet.
   */
  deleteDownload: (fileId) =>
    safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Execution Results (data_grid_api router) ──────────────

  /**
   * GET /api/executions/{execution_id}/results
   * Returns { columns, rows, total_rows, filtered_rows, page, page_size, total_pages }
   */
  getExecutionResults: (executionId, page = 1, pageSize = 100, sortColumn = null, sortDirection = 'asc', filters = null) => {
    const params = new URLSearchParams({ page, page_size: pageSize });
    if (sortColumn)                              { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length)   params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },

  /**
   * GET /api/executions/{execution_id}/export?format=csv|excel|json
   * Opens download in new tab
   */
  exportResults: (executionId, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),

  /** GET /api/executions/{execution_id}/stats */
  getExecutionStats: (executionId) =>
    safeFetch(`/api/executions/${executionId}/stats`),

  /**
   * Execution status – backend has no dedicated status endpoint.
   * We derive status from the downloads list by matching execution_id.
   * ReportPage polls this to know when a query finishes.
   */
  getExecutionStatus: async (executionId) => {
    try {
      const downloads = await api.listDownloads('');   // fetch all statuses
      const match = downloads.find(d => d.execution_id === executionId);
      if (match) {
        return {
          execution_id: executionId,
          status: 'completed',
          total_rows: null,   // not stored in downloads list
          file_id: match.file_id,
          filename: match.filename,
        };
      }
      // File not in downloads yet → still running
      return { execution_id: executionId, status: 'pending' };
    } catch {
      return { execution_id: executionId, status: 'unknown' };
    }
  },

  /**
   * List executions – backend has no /api/executions list endpoint.
   * ExecutionHistory component calls this; return empty so it doesn't crash.
   */
  listExecutions: () => Promise.resolve([]),

  /** Single execution – no backend endpoint, return null gracefully */
  getExecution: (executionId) => Promise.resolve(null),

};

export default api;