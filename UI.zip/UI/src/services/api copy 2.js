/**
 * API Service - Minimal & Robust
 * 
 * This version:
 * - Only uses endpoints that MUST exist
 * - Has defensive error handling
 * - Logs everything for debugging
 * - Works with partial backend implementations
 * - Returns safe defaults instead of crashing
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// Helper: Safe fetch with detailed logging
const safeFetch = async (url, options = {}) => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  
  console.log(`🌐 API Call: ${options.method || 'GET'} ${fullUrl}`);
  
  try {
    const response = await fetch(fullUrl, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });
    
    console.log(`📡 Response: ${response.status} ${response.statusText}`);
    
    if (!response.ok) {
      let errorMsg;
      try {
        const errorData = await response.json();
        errorMsg = errorData.detail || errorData.message || `HTTP ${response.status}`;
      } catch {
        errorMsg = `HTTP ${response.status}: ${response.statusText}`;
      }
      throw new Error(errorMsg);
    }
    
    const data = await response.json();
    console.log(`✅ Success:`, data);
    return data;
    
  } catch (error) {
    console.error(`❌ API Error:`, error.message);
    throw error;
  }
};

const api = {
  // ============================================================================
  // FILE OPERATIONS - These MUST exist
  // ============================================================================

  /**
   * List all available data files
   */
  listFiles: async () => {
    try {
      return await safeFetch('/api/files');
    } catch (error) {
      console.error('Failed to list files:', error);
      throw new Error('Cannot connect to backend. Is the server running?');
    }
  },

  /**
   * Get schema for a specific file
   * @param {string} filePath - File path or name
   */
  getFileSchema: async (filePath) => {
    try {
      // Handle both full paths and just filenames
      const encodedPath = encodeURIComponent(filePath);
      return await safeFetch(`/api/files/schema?path=${encodedPath}`);
    } catch (error) {
      console.error(`Failed to get schema for ${filePath}:`, error);
      // Return minimal schema instead of crashing
      return {
        columns: [],
        types: {},
        error: error.message
      };
    }
  },

  // ============================================================================
  // QUERY EXECUTION - Core functionality
  // ============================================================================

  /**
   * Execute a query
   * @param {Object} payload - Must have query_config property
   */
  executeQuery: async (payload) => {
    try {
      return await safeFetch('/api/execute', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    } catch (error) {
      console.error('Query execution failed:', error);
      throw error;
    }
  },

  // ============================================================================
  // DOWNLOADS - Simple file download
  // ============================================================================

  /**
   * Download a file by execution ID
   * @param {string} executionId - Execution/file ID
   */
  downloadFile: (executionId) => {
    const url = `${API_BASE_URL}/api/downloads/${executionId}`;
    console.log(`📥 Opening download: ${url}`);
    window.open(url, '_blank');
  },

  // ============================================================================
  // OPTIONAL ENDPOINTS - These may not exist yet
  // ============================================================================

  /**
   * Get saved queries (if endpoint exists)
   */
  getSavedQueries: async () => {
    try {
      return await safeFetch('/api/queries');
    } catch (error) {
      console.warn('Saved queries endpoint not available:', error.message);
      return []; // Return empty array instead of crashing
    }
  },

  /**
   * Get a single saved query (if endpoint exists)
   */
  getSavedQuery: async (queryId) => {
    try {
      return await safeFetch(`/api/queries/${queryId}`);
    } catch (error) {
      console.warn(`Query ${queryId} not found:`, error.message);
      return null;
    }
  },

  /**
   * Save a query (if endpoint exists)
   */
  saveQuery: async (queryData) => {
    try {
      return await safeFetch('/api/queries', {
        method: 'POST',
        body: JSON.stringify(queryData),
      });
    } catch (error) {
      console.error('Failed to save query:', error);
      throw error;
    }
  },

  /**
   * Delete a query (if endpoint exists)
   */
  deleteQuery: async (queryId) => {
    try {
      return await safeFetch(`/api/queries/${queryId}`, {
        method: 'DELETE',
      });
    } catch (error) {
      console.error('Failed to delete query:', error);
      throw error;
    }
  },

  /**
   * Get execution status (if endpoint exists)
   * Falls back to checking if file exists
   */
  getExecutionStatus: async (executionId) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch (error) {
      console.warn('Status endpoint failed, trying file check:', error.message);
      
      // Fallback: Try to access the download file
      try {
        const response = await fetch(`${API_BASE_URL}/api/downloads/${executionId}`, {
          method: 'HEAD', // Just check if file exists
        });
        
        if (response.ok) {
          return {
            execution_id: executionId,
            status: 'completed',
            message: 'File exists (status endpoint not available)'
          };
        }
      } catch {}
      
      // Last resort
      return {
        execution_id: executionId,
        status: 'unknown',
        message: 'Status unavailable'
      };
    }
  },

  /**
   * Get paginated results (if endpoint exists)
   */
  getExecutionResults: async (executionId, page = 1, pageSize = 100, sortColumn = null, sortDirection = 'asc', filters = null) => {
    try {
      const params = new URLSearchParams({
        page: String(page),
        page_size: String(pageSize),
      });

      if (sortColumn) {
        params.append('sort_column', sortColumn);
        params.append('sort_direction', sortDirection);
      }

      if (filters && Object.keys(filters).length > 0) {
        params.append('filters', JSON.stringify(filters));
      }

      return await safeFetch(`/api/executions/${executionId}/results?${params}`);
    } catch (error) {
      console.error('Pagination endpoint not available:', error.message);
      throw new Error('Result pagination not available. Download the CSV file instead.');
    }
  },

  /**
   * Export results (if endpoint exists)
   */
  exportResults: async (executionId, format = 'csv') => {
    try {
      const url = `${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`;
      console.log(`📥 Exporting as ${format}: ${url}`);
      window.open(url, '_blank');
    } catch (error) {
      // Fallback to regular download
      console.warn('Export endpoint failed, falling back to download:', error.message);
      api.downloadFile(executionId);
    }
  },

  /**
   * Get downloads list (if endpoint exists)
   */
  getDownloads: async () => {
    try {
      return await safeFetch('/api/downloads');
    } catch (error) {
      console.warn('Downloads list endpoint not available:', error.message);
      return [];
    }
  },

  /**
   * Delete a download (if endpoint exists)
   */
  deleteDownload: async (executionId) => {
    try {
      return await safeFetch(`/api/downloads/${executionId}`, {
        method: 'DELETE',
      });
    } catch (error) {
      console.error('Failed to delete download:', error);
      throw error;
    }
  },

  // ============================================================================
  // UTILITY
  // ============================================================================

  /**
   * Test backend connection
   */
  healthCheck: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      if (response.ok) {
        return await response.json();
      }
      return { status: 'unhealthy', message: `HTTP ${response.status}` };
    } catch (error) {
      return { status: 'error', message: 'Cannot connect to backend' };
    }
  },
};

export default api;

// Also export individual methods for tree-shaking
export const {
  listFiles,
  getFileSchema,
  executeQuery,
  downloadFile,
  getSavedQueries,
  getSavedQuery,
  saveQuery,
  deleteQuery,
  getExecutionStatus,
  getExecutionResults,
  exportResults,
  getDownloads,
  deleteDownload,
  healthCheck,
} = api;