const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

class ApiService {
  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: response.statusText }));
        throw new Error(error.detail || `HTTP ${response.status}: ${response.statusText}`);
      }

      if (options.download) {
        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = options.filename || 'download';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(downloadUrl);
        return { success: true };
      }

      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }

      return response;
    } catch (error) {
      console.error('API Request Error:', error);
      throw error;
    }
  }

  // S3 Configuration
  async configureS3(config) {
    return this.request('/api/s3/configure', {
      method: 'POST',
      body: JSON.stringify(config),
    });
  }

  async testS3Connection() {
    return this.request('/api/s3/test');
  }

  async listS3Folders(prefix = '') {
    const params = new URLSearchParams({ prefix }).toString();
    return this.request(`/api/s3/folders${params ? '?' + params : ''}`);
  }

  async listS3Files(folder = '') {
    const params = new URLSearchParams({ folder }).toString();
    return this.request(`/api/s3/files${params ? '?' + params : ''}`);
  }

  // File Management
  async listFiles(storageType = null, s3Folder = '') {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder) params.append('s3_folder', s3Folder);
    const queryString = params.toString();
    return this.request(`/api/files${queryString ? '?' + queryString : ''}`);
  }

  async getFileSchema(filePath) {
    return this.request(`/api/files/${filePath}/schema`);
  }

  async uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);

    return this.request('/api/files/upload', {
      method: 'POST',
      headers: {},
      body: formData,
    });
  }

  // Query Management
  async saveQuery(data) {
    return this.request('/api/queries', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async listQueries(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/api/queries${queryString ? '?' + queryString : ''}`);
  }

  async getQuery(queryId) {
    return this.request(`/api/queries/${queryId}`);
  }

  async updateQuery(queryId, data) {
    return this.request(`/api/queries/${queryId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteQuery(queryId, permanent = false) {
    const queryString = permanent ? '?permanent=true' : '';
    return this.request(`/api/queries/${queryId}${queryString}`, {
      method: 'DELETE',
    });
  }

  // Query Execution
  async executeQuery(data) {
    return this.request('/api/execute', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async listExecutions(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/api/executions${queryString ? '?' + queryString : ''}`);
  }

  async getExecution(executionId) {
    return this.request(`/api/executions/${executionId}`);
  }

  // Download Management
  async listDownloads(status = 'available', limit = 100, offset = 0) {
    const params = new URLSearchParams({ status, limit, offset }).toString();
    return this.request(`/api/downloads?${params}`);
  }

  async downloadFile(fileId, filename) {
    return this.request(`/api/downloads/${fileId}`, {
      download: true,
      filename: filename,
    });
  }

  async deleteDownload(fileId) {
    return this.request(`/api/downloads/${fileId}`, {
      method: 'DELETE',
    });
  }

  // Health Check
  async healthCheck() {
    return this.request('/health');
  }
}

const api = new ApiService();
export default api;
