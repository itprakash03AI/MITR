/**
 * API Service - Complete Implementation
 * 
 * Handles all API calls to the backend server
 * Includes: Files, Queries, Executions, Results, Exports
 * 
 * USAGE:
 * import api from './services/api';
 * 
 * const files = await api.listFiles();
 * const result = await api.executeQuery(queryConfig);
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const api = {
  // ============================================================================
  // FILE OPERATIONS
  // ============================================================================

  /**
   * List all available parquet files
   * @returns {Promise<Array>} Array of file objects with metadata
   */
  listFiles: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/files`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to load files`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error listing files:', error);
      throw new Error(error.message || 'Failed to load files');
    }
  },

  /**
   * Get schema (columns and types) for a specific file
   * @param {string} filePath - Path to the parquet file
   * @returns {Promise<Object>} Schema object with columns and types
   */
  getFileSchema: async (filePath) => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/files/schema?path=${encodeURIComponent(filePath)}`
      );
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to load schema`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting file schema:', error);
      throw new Error(error.message || 'Failed to load file schema');
    }
  },

  /**
   * Get file statistics (row count, size, etc.)
   * @param {string} filePath - Path to the parquet file
   * @returns {Promise<Object>} File statistics
   */
  getFileStats: async (filePath) => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/files/stats?path=${encodeURIComponent(filePath)}`
      );
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to load stats`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting file stats:', error);
      throw new Error(error.message || 'Failed to load file statistics');
    }
  },

  // ============================================================================
  // QUERY EXECUTION
  // ============================================================================

  /**
   * Execute a query configuration
   * @param {Object} queryConfig - Query configuration object
   * @param {Array} queryConfig.files - Array of file paths
   * @param {Array} queryConfig.columns - Selected columns (optional, defaults to all)
   * @param {Array} queryConfig.filters - Array of filter objects (optional)
   * @param {Array} queryConfig.joins - Array of join configurations (optional)
   * @param {Array} queryConfig.order_by - Array of order by configurations (optional)
   * @param {number} queryConfig.limit - Limit number of rows (default 1000)
   * @returns {Promise<Object>} Execution response with execution_id
   */
  executeQuery: async (queryConfig) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(queryConfig),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP ${response.status}: Query execution failed`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error executing query:', error);
      throw new Error(error.message || 'Failed to execute query');
    }
  },

  /**
   * Cancel a running query execution
   * @param {string} executionId - Execution ID to cancel
   * @returns {Promise<Object>} Cancellation response
   */
  cancelExecution: async (executionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/executions/${executionId}/cancel`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to cancel execution`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error cancelling execution:', error);
      throw new Error(error.message || 'Failed to cancel execution');
    }
  },

  // ============================================================================
  // SAVED QUERIES
  // ============================================================================

  /**
   * Get all saved queries
   * @returns {Promise<Array>} Array of saved query objects
   */
  getSavedQueries: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/queries`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to load saved queries`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting saved queries:', error);
      throw new Error(error.message || 'Failed to load saved queries');
    }
  },

  /**
   * Get a specific saved query by ID
   * @param {string} queryId - Query ID
   * @returns {Promise<Object>} Query object with configuration
   */
  getSavedQuery: async (queryId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/queries/${queryId}`);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Query not found');
        }
        throw new Error(`HTTP ${response.status}: Failed to load query`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting saved query:', error);
      throw new Error(error.message || 'Failed to load query');
    }
  },

  /**
   * Save a new query or update existing one
   * @param {Object} queryData - Query data to save
   * @param {string} queryData.name - Query name
   * @param {string} queryData.description - Query description (optional)
   * @param {Object} queryData.query_config - Query configuration object
   * @param {string} queryData.category - Category for organization (optional)
   * @returns {Promise<Object>} Saved query object with ID
   */
  saveQuery: async (queryData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/queries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(queryData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP ${response.status}: Failed to save query`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error saving query:', error);
      throw new Error(error.message || 'Failed to save query');
    }
  },

  /**
   * Update an existing saved query
   * @param {string} queryId - Query ID to update
   * @param {Object} queryData - Updated query data
   * @returns {Promise<Object>} Updated query object
   */
  updateQuery: async (queryId, queryData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/queries/${queryId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(queryData),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to update query`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating query:', error);
      throw new Error(error.message || 'Failed to update query');
    }
  },

  /**
   * Delete a saved query
   * @param {string} queryId - Query ID to delete
   * @returns {Promise<Object>} Deletion confirmation
   */
  deleteQuery: async (queryId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/queries/${queryId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to delete query`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error deleting query:', error);
      throw new Error(error.message || 'Failed to delete query');
    }
  },

  // ============================================================================
  // EXECUTION STATUS & RESULTS
  // ============================================================================

  /**
   * Get execution status (for polling)
   * @param {string} executionId - Execution ID
   * @returns {Promise<Object>} Status object with current state
   */
  getExecutionStatus: async (executionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/executions/${executionId}/status`);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Execution not found');
        }
        throw new Error(`HTTP ${response.status}: Failed to get execution status`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting execution status:', error);
      throw new Error(error.message || 'Failed to get execution status');
    }
  },

  /**
   * Get paginated execution results
   * @param {string} executionId - Execution ID
   * @param {number} page - Page number (1-indexed)
   * @param {number} pageSize - Number of rows per page
   * @param {string} sortColumn - Column to sort by (optional)
   * @param {string} sortDirection - Sort direction: 'asc' or 'desc' (optional)
   * @param {Object} filters - Column filters (optional)
   * @returns {Promise<Object>} Paginated results with metadata
   */
  getExecutionResults: async (executionId, page = 1, pageSize = 100, sortColumn = null, sortDirection = 'asc', filters = null) => {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        page_size: pageSize.toString(),
      });

      if (sortColumn) {
        params.append('sort_column', sortColumn);
        params.append('sort_direction', sortDirection);
      }

      if (filters && Object.keys(filters).length > 0) {
        params.append('filters', JSON.stringify(filters));
      }

      const response = await fetch(
        `${API_BASE_URL}/api/executions/${executionId}/results?${params}`
      );

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Results not found');
        }
        throw new Error(`HTTP ${response.status}: Failed to get results`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting execution results:', error);
      throw new Error(error.message || 'Failed to get results');
    }
  },

  /**
   * Get execution statistics
   * @param {string} executionId - Execution ID
   * @returns {Promise<Object>} Statistics including column stats, row count, etc.
   */
  getExecutionStats: async (executionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/executions/${executionId}/stats`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to get statistics`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting execution stats:', error);
      throw new Error(error.message || 'Failed to get statistics');
    }
  },

  /**
   * Get execution history
   * @param {number} limit - Number of recent executions to return
   * @returns {Promise<Array>} Array of execution objects
   */
  getExecutionHistory: async (limit = 50) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/executions?limit=${limit}`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to get execution history`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting execution history:', error);
      throw new Error(error.message || 'Failed to get execution history');
    }
  },

  // ============================================================================
  // EXPORT
  // ============================================================================

  /**
   * Export execution results in specified format
   * Opens download in new window
   * @param {string} executionId - Execution ID
   * @param {string} format - Export format: 'csv', 'excel', 'json', or 'pdf'
   */
  exportResults: async (executionId, format = 'csv') => {
    try {
      const validFormats = ['csv', 'excel', 'json', 'pdf'];
      if (!validFormats.includes(format)) {
        throw new Error(`Invalid format: ${format}. Must be one of: ${validFormats.join(', ')}`);
      }

      const url = `${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`;
      
      // Open in new window to trigger download
      window.open(url, '_blank');
      
      return { success: true, message: `Exporting as ${format.toUpperCase()}...` };
    } catch (error) {
      console.error('Error exporting results:', error);
      throw new Error(error.message || 'Failed to export results');
    }
  },

  /**
   * Download execution results as file
   * Alternative to exportResults that uses direct download
   * @param {string} executionId - Execution ID
   * @param {string} format - Export format
   * @returns {Promise<Blob>} File blob for download
   */
  downloadResults: async (executionId, format = 'csv') => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to download results`);
      }

      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `query_results_${executionId}.${format === 'excel' ? 'xlsx' : format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      return blob;
    } catch (error) {
      console.error('Error downloading results:', error);
      throw new Error(error.message || 'Failed to download results');
    }
  },

  // ============================================================================
  // DOWNLOADS MANAGEMENT
  // ============================================================================

  /**
   * Get list of all available downloads
   * @returns {Promise<Array>} Array of download file objects
   */
  getDownloads: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/downloads`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to get downloads`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting downloads:', error);
      throw new Error(error.message || 'Failed to get downloads');
    }
  },

  /**
   * Download a specific file
   * @param {string} executionId - Execution ID / file ID
   */
  downloadFile: async (executionId) => {
    try {
      const url = `${API_BASE_URL}/api/downloads/${executionId}`;
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error downloading file:', error);
      throw new Error(error.message || 'Failed to download file');
    }
  },

  /**
   * Delete a download file
   * @param {string} executionId - Execution ID / file ID
   * @returns {Promise<Object>} Deletion confirmation
   */
  deleteDownload: async (executionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/downloads/${executionId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to delete download`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error deleting download:', error);
      throw new Error(error.message || 'Failed to delete download');
    }
  },

  // ============================================================================
  // UTILITY METHODS
  // ============================================================================

  /**
   * Test API connectivity
   * @returns {Promise<Object>} Health check response
   */
  healthCheck: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      
      if (!response.ok) {
        throw new Error('API is not responding');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Health check failed:', error);
      throw new Error(error.message || 'API health check failed');
    }
  },

  /**
   * Get API version and info
   * @returns {Promise<Object>} API information
   */
  getApiInfo: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/`);
      
      if (!response.ok) {
        throw new Error('Failed to get API info');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting API info:', error);
      throw new Error(error.message || 'Failed to get API information');
    }
  },
};

// Export as default
export default api;

// Also export individual methods for tree-shaking
export const {
  listFiles,
  getFileSchema,
  getFileStats,
  executeQuery,
  cancelExecution,
  getSavedQueries,
  getSavedQuery,
  saveQuery,
  updateQuery,
  deleteQuery,
  getExecutionStatus,
  getExecutionResults,
  getExecutionStats,
  getExecutionHistory,
  exportResults,
  downloadResults,
  getDownloads,
  downloadFile,
  deleteDownload,
  healthCheck,
  getApiInfo,
} = api;

// const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// class ApiService {
//   async request(endpoint, options = {}) {
//     const url = `${API_BASE_URL}${endpoint}`;
//     const config = {
//       headers: {
//         'Content-Type': 'application/json',
//         ...options.headers,
//       },
//       ...options,
//     };

//     try {
//       const response = await fetch(url, config);
      
//       if (!response.ok) {
//         const error = await response.json().catch(() => ({ detail: response.statusText }));
//         throw new Error(error.detail || `HTTP ${response.status}: ${response.statusText}`);
//       }

//       // Handle file downloads
//       if (options.download) {
//         const blob = await response.blob();
//         const downloadUrl = window.URL.createObjectURL(blob);
//         const a = document.createElement('a');
//         a.href = downloadUrl;
//         a.download = options.filename || 'download';
//         document.body.appendChild(a);
//         a.click();
//         document.body.removeChild(a);
//         window.URL.revokeObjectURL(downloadUrl);
//         return { success: true };
//       }

//       // Handle JSON responses
//       const contentType = response.headers.get('content-type');
//       if (contentType && contentType.includes('application/json')) {
//         return await response.json();
//       }

//       return response;
//     } catch (error) {
//       console.error('API Request Error:', error);
//       throw error;
//     }
//   }

//   // File Management
//   async listFiles() {
//     return this.request('/api/files');
//   }

//   async getFileSchema(filePath) {
//     return this.request(`/api/files/${filePath}/schema`);
//   }

//   async uploadFile(file) {
//     const formData = new FormData();
//     formData.append('file', file);

//     return this.request('/api/files/upload', {
//       method: 'POST',
//       headers: {},  // Let browser set Content-Type for FormData
//       body: formData,
//     });
//   }

//   // Query Management
//   async saveQuery(data) {
//     return this.request('/api/queries', {
//       method: 'POST',
//       body: JSON.stringify(data),
//     });
//   }

//   async listQueries(params = {}) {
//     const queryString = new URLSearchParams(params).toString();
//     return this.request(`/api/queries${queryString ? '?' + queryString : ''}`);
//   }

//   async getQuery(queryId) {
//     return this.request(`/api/queries/${queryId}`);
//   }

//   async updateQuery(queryId, data) {
//     return this.request(`/api/queries/${queryId}`, {
//       method: 'PUT',
//       body: JSON.stringify(data),
//     });
//   }

//   async deleteQuery(queryId, permanent = false) {
//     const queryString = permanent ? '?permanent=true' : '';
//     return this.request(`/api/queries/${queryId}${queryString}`, {
//       method: 'DELETE',
//     });
//   }

//   // Query Execution
//   async executeQuery(data) {
//     return this.request('/api/execute', {
//       method: 'POST',
//       body: JSON.stringify(data),
//     });
//   }

//   async listExecutions(params = {}) {
//     const queryString = new URLSearchParams(params).toString();
//     return this.request(`/api/executions${queryString ? '?' + queryString : ''}`);
//   }

//   async getExecution(executionId) {
//     return this.request(`/api/executions/${executionId}`);
//   }

//   // Download Management
//   async listDownloads(status = 'available', limit = 100, offset = 0) {
//     const params = new URLSearchParams({ status, limit, offset }).toString();
//     return this.request(`/api/downloads?${params}`);
//   }

//   async downloadFile(fileId, filename) {
//     return this.request(`/api/downloads/${fileId}`, {
//       download: true,
//       filename: filename,
//     });
//   }

//   async deleteDownload(fileId) {
//     return this.request(`/api/downloads/${fileId}`, {
//       method: 'DELETE',
//     });
//   }

//   // Health Check
//   async healthCheck() {
//     return this.request('/health');
//   }
// }

// const api = new ApiService();
// export default api;
