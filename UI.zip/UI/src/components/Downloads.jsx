/**
 * Download Center — Query Studio
 * Shows all exports (CSV auto-generated + explicit Excel/JSON exports).
 * Features: format badge, duration, row count, preview dialog, stats bar.
 */
import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Chip, Stack, Divider,
  ToggleButtonGroup, ToggleButton, CircularProgress, IconButton, Tooltip,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, InputAdornment, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TableSortLabel, TablePagination, Alert,
} from '@mui/material';
import {
  Download as DownloadIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  InsertDriveFile as FileIcon,
  TableChart as ExcelIcon,
  DataObject as JsonIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Visibility as PreviewIcon,
  Storage as StorageIcon,
  CheckCircleOutline as AvailableIcon,
  TimerOutlined as TimerIcon,
  Close as CloseIcon,
  Minimize as MinimizeIcon,
  CropSquare as MaximizeIcon,
  OpenInFull as RestoreIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import api from '../services/api';
import DataGridViewer from './DataGridViewer';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// ─────────────────────────────────────────────────────────────
// Formatters
// ─────────────────────────────────────────────────────────────
const fmtSize = (bytes) => {
  if (!bytes) return '—';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
};

const fmtDate = (s) => {
  if (!s) return '—';
  return new Date(s).toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

const fmtDuration = (secs) => {
  if (secs == null || secs === '') return '—';
  const n = Number(secs);
  if (isNaN(n)) return '—';
  if (n < 60) return `${n.toFixed(1)}s`;
  const m = Math.floor(n / 60), s = Math.floor(n % 60);
  return `${m}m ${s}s`;
};

const fmtRows = (n) =>
  n != null && n !== '' ? Number(n).toLocaleString() : '—';

const statusColor = {
  available: 'success',
  downloaded: 'info',
  expired: 'warning',
  deleted: 'error',
};

const FORMAT_META = {
  excel: { label: 'EXCEL', color: 'success' },
  json:  { label: 'JSON',  color: 'info'    },
  csv:   { label: 'CSV',   color: 'default' },
};

const FileTypeIcon = ({ filename, format }) => {
  const fmt = format || (
    (filename || '').endsWith('.xlsx') ? 'excel' :
    (filename || '').endsWith('.json') ? 'json' : 'csv'
  );
  if (fmt === 'excel') return <ExcelIcon sx={{ color: '#217346', fontSize: 22 }} />;
  if (fmt === 'json')  return <JsonIcon  sx={{ color: '#00AEEF', fontSize: 22 }} />;
  return <FileIcon sx={{ color: 'text.secondary', fontSize: 22 }} />;
};

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

// ─────────────────────────────────────────────────────────────
// Apple macOS-style floating window
// • Draggable title bar
// • Minimize (collapses to title bar only)
// • Maximize / Restore
// • Resizable from bottom-right corner
// • Does NOT block background interaction (no modal overlay)
// ─────────────────────────────────────────────────────────────
const FloatingPreviewWindow = ({ open, onClose, download }) => {
  const canPreview = !!(download?.execution_id || download?.file_id);

  // Window state
  const DEFAULT_W = Math.min(window.innerWidth  * 0.78, 1400);
  const DEFAULT_H = Math.min(window.innerHeight * 0.80, 900);
  const DEFAULT_X = Math.round((window.innerWidth  - DEFAULT_W) / 2);
  const DEFAULT_Y = Math.round((window.innerHeight - DEFAULT_H) / 4);

  const [pos,       setPos]       = useState({ x: DEFAULT_X, y: DEFAULT_Y });
  const [size,      setSize]      = useState({ w: DEFAULT_W, h: DEFAULT_H });
  const [minimized, setMinimized] = useState(false);
  const [maximized, setMaximized] = useState(false);
  const [prevGeom,  setPrevGeom]  = useState(null); // for restore

  const dragging  = useRef(false);
  const dragStart = useRef(null);
  const resizing  = useRef(false);
  const resStart  = useRef(null);

  // Reset position when opened
  useEffect(() => {
    if (open) {
      setPos({ x: DEFAULT_X, y: DEFAULT_Y });
      setSize({ w: DEFAULT_W, h: DEFAULT_H });
      setMinimized(false);
      setMaximized(false);
    }
  }, [open]); // eslint-disable-line

  // ── Drag ──────────────────────────────────────────────
  const startDrag = useCallback((e) => {
    if (maximized) return;
    e.preventDefault();
    dragging.current  = true;
    dragStart.current = { mx: e.clientX, my: e.clientY, px: pos.x, py: pos.y };

    const onMove = (ev) => {
      if (!dragging.current) return;
      const dx = ev.clientX - dragStart.current.mx;
      const dy = ev.clientY - dragStart.current.my;
      setPos({
        x: Math.max(0, Math.min(window.innerWidth  - 120, dragStart.current.px + dx)),
        y: Math.max(0, Math.min(window.innerHeight - 40,  dragStart.current.py + dy)),
      });
    };
    const onUp = () => { dragging.current = false; window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }, [pos, maximized]);

  // ── Resize ────────────────────────────────────────────
  const startResize = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    resizing.current  = true;
    resStart.current  = { mx: e.clientX, my: e.clientY, w: size.w, h: size.h };

    const onMove = (ev) => {
      if (!resizing.current) return;
      const dw = ev.clientX - resStart.current.mx;
      const dh = ev.clientY - resStart.current.my;
      setSize({
        w: Math.max(520, resStart.current.w + dw),
        h: Math.max(300, resStart.current.h + dh),
      });
    };
    const onUp = () => { resizing.current = false; window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }, [size]);

  // ── Maximize / Restore ────────────────────────────────
  const toggleMaximize = () => {
    if (maximized) {
      setPos(prevGeom.pos); setSize(prevGeom.size); setPrevGeom(null);
      setMaximized(false);
    } else {
      setPrevGeom({ pos, size });
      setPos({ x: 0, y: 0 });
      setSize({ w: window.innerWidth, h: window.innerHeight });
      setMaximized(true); setMinimized(false);
    }
  };

  const toggleMinimize = () => setMinimized(v => !v);

  if (!open) return null;

  const winStyle = maximized
    ? { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 1400,
        borderRadius: 0, boxShadow: 'none' }
    : minimized
    ? { position: 'fixed', top: pos.y, left: pos.x, width: size.w, height: 36, zIndex: 1400,
        borderRadius: '10px', boxShadow: '0 8px 32px rgba(0,0,0,0.35)' }
    : { position: 'fixed', top: pos.y, left: pos.x, width: size.w, height: size.h, zIndex: 1400,
        borderRadius: '10px', boxShadow: '0 20px 60px rgba(0,0,0,0.4)', display: 'flex', flexDirection: 'column' };

  return (
    <Box sx={{ ...winStyle, overflow: 'hidden', bgcolor: 'background.paper', border: '1px solid rgba(0,0,0,0.18)' }}>

      {/* ── macOS-style title bar ────────────────────────── */}
      <Box
        onMouseDown={startDrag}
        sx={{
          height: 36, flexShrink: 0,
          background: 'linear-gradient(180deg, #3a3a3a 0%, #2b2b2b 100%)',
          display: 'flex', alignItems: 'center', px: 1.5, gap: 0.75,
          cursor: maximized ? 'default' : 'move', userSelect: 'none',
          borderBottom: minimized ? 0 : '1px solid rgba(0,0,0,0.3)',
          borderRadius: maximized ? 0 : `10px 10px ${minimized ? '10px 10px' : '0 0'}`,
        }}
      >
        {/* Traffic lights */}
        <Box sx={{ display: 'flex', gap: 0.75, mr: 1.5 }}>
          {/* Red — close */}
          <Tooltip title="Close">
            <Box onClick={onClose} sx={{
              width: 13, height: 13, borderRadius: '50%',
              bgcolor: '#ff5f57', border: '1px solid #e0443e',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              '&:hover::after': { content: '"×"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)' },
            }} />
          </Tooltip>
          {/* Yellow — minimize */}
          <Tooltip title={minimized ? 'Restore' : 'Minimize'}>
            <Box onClick={toggleMinimize} sx={{
              width: 13, height: 13, borderRadius: '50%',
              bgcolor: '#febc2e', border: '1px solid #d9a018',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              '&:hover::after': { content: '"–"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)', lineHeight: 1 },
            }} />
          </Tooltip>
          {/* Green — maximize */}
          <Tooltip title={maximized ? 'Restore' : 'Maximize'}>
            <Box onClick={toggleMaximize} sx={{
              width: 13, height: 13, borderRadius: '50%',
              bgcolor: '#28c840', border: '1px solid #1aab2c',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              '&:hover::after': { content: '"+"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)' },
            }} />
          </Tooltip>
        </Box>

        {/* Centered title */}
        <Box sx={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, overflow: 'hidden' }}>
          <FileTypeIcon filename={download?.filename} format={download?.format} />
          <Typography variant="caption" noWrap sx={{ color: 'rgba(255,255,255,0.85)', fontWeight: 600, letterSpacing: 0.3, maxWidth: 400 }}
            title={download?.filename}>
            {download?.filename || 'File Preview'}
          </Typography>
          {!download?.execution_id && download?.file_id && (
            <Chip label="file" size="small" variant="outlined"
              sx={{ height: 16, fontSize: 9, color: 'rgba(255,255,255,0.55)', borderColor: 'rgba(255,255,255,0.25)' }} />
          )}
        </Box>
      </Box>

      {/* ── Content ─────────────────────────────────────── */}
      {!minimized && (
        <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
          {!canPreview && (
            <Alert severity="info" sx={{ m: 2 }}>No file linked — preview unavailable.</Alert>
          )}
          {/* Prefer file_id mode — works for CSV, Excel, and JSON exports.
              Fall back to executionId only when there is no file_id (legacy). */}
          {canPreview && download?.file_id && (
            <DataGridViewer key={download.file_id} fileId={download.file_id} embedded />
          )}
          {canPreview && !download?.file_id && download?.execution_id && (
            <DataGridViewer key={download.execution_id} executionId={download.execution_id} embedded />
          )}

          {/* ── Resize handle (bottom-right) ─────────────── */}
          {!maximized && (
            <Box
              onMouseDown={startResize}
              sx={{
                position: 'absolute', bottom: 0, right: 0,
                width: 18, height: 18, cursor: 'nwse-resize',
                '&::before': {
                  content: '""', position: 'absolute', bottom: 4, right: 4,
                  width: 0, height: 0,
                  borderStyle: 'solid',
                  borderWidth: '0 0 10px 10px',
                  borderColor: 'transparent transparent rgba(0,0,0,0.2) transparent',
                },
              }}
            />
          )}
        </Box>
      )}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// Main Component
// ─────────────────────────────────────────────────────────────
const Downloads = () => {
  const [downloads,    setDownloads]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [filter,       setFilter]       = useState('available');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [previewTarget,setPreviewTarget]= useState(null);
  const [search,       setSearch]       = useState('');
  const [sortField,    setSortField]    = useState('created_at');
  const [sortDir,      setSortDir]      = useState('desc');
  const [page,         setPage]         = useState(0);
  const [rowsPerPage,  setRowsPerPage]  = useState(25);

  const { addNotification } = useNotifications();
  const { addListener }     = useWebSocket();

  // ── Data loading ─────────────────────────────────────────
  const loadDownloads = async () => {
    setLoading(true);
    try {
      const qs  = filter ? `?status=${filter}` : '';
      const res = await fetch(`${API_BASE_URL}/api/exports${qs}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setDownloads((await res.json()) || []);
    } catch (err) {
      addNotification({ type: 'error', title: 'Error Loading Downloads', message: err.message });
      setDownloads([]);
    } finally {
      setLoading(false);
    }
  };

  // Mount: load + subscribe to WS
  useEffect(() => {
    loadDownloads();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // WS listener — re-register when filter changes so reload uses current filter
  useEffect(() => {
    const remove = addListener(msg => {
      if (['export_completed', 'execution_completed'].includes(msg.type)) {
        setTimeout(loadDownloads, 1500);
      }
    });
    return () => remove();
  }, [filter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reload when filter changes
  useEffect(() => {
    loadDownloads();
    setPage(0);
  }, [filter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reset pagination on search change
  useEffect(() => { setPage(0); }, [search]);

  // ── Handlers ─────────────────────────────────────────────
  const handleDownload = (fileId, filename) => {
    window.open(`${API_BASE_URL}/api/downloads/${fileId}`, '_blank');
    addNotification({ type: 'success', title: 'Download Started', message: filename || 'File download initiated' });
    setTimeout(loadDownloads, 2000);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteDownload(deleteTarget.file_id);
      addNotification({ type: 'success', title: 'Deleted', message: `"${deleteTarget.filename}" deleted` });
      loadDownloads();
    } catch (err) {
      addNotification({ type: 'error', title: 'Delete Failed', message: err.message });
    }
    setDeleteTarget(null);
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
    setPage(0);
  };

  // ── Derived data ─────────────────────────────────────────
  const stats = useMemo(() => {
    const available  = downloads.filter(d => d.status === 'available').length;
    const totalSize  = downloads.reduce((s, d) => s + (d.file_size_bytes || 0), 0);
    const excelCount = downloads.filter(d => d.format === 'excel').length;
    return { total: downloads.length, available, totalSize, excelCount };
  }, [downloads]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = q
      ? downloads.filter(d =>
          (d.filename     || '').toLowerCase().includes(q) ||
          (d.execution_id || '').toLowerCase().includes(q) ||
          (d.format       || '').toLowerCase().includes(q)
        )
      : downloads;

    return [...rows].sort((a, b) => {
      let av = a[sortField] ?? '';
      let bv = b[sortField] ?? '';
      const numericFields = ['file_size_bytes', 'download_count', 'total_rows', 'duration_seconds'];
      if (numericFields.includes(sortField)) {
        av = Number(av) || 0;
        bv = Number(bv) || 0;
      }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ?  1 : -1;
      return 0;
    });
  }, [downloads, search, sortField, sortDir]);

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  // ── Sort header helper ────────────────────────────────────
  const SortHeader = ({ field, label, align, width }) => (
    <TableCell
      align={align}
      sx={{ fontWeight: 700, whiteSpace: 'nowrap', bgcolor: 'grey.50', width }}
    >
      <TableSortLabel
        active={sortField === field}
        direction={sortField === field ? sortDir : 'asc'}
        onClick={() => handleSort(field)}
      >
        {label}
      </TableSortLabel>
    </TableCell>
  );

  // ── Render ────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>

      {/* ── Page header ── */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Download Center</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            All exported files — CSV results, Excel, and JSON exports
          </Typography>
        </Box>
        <Button
          variant="outlined"
          size="small"
          startIcon={<RefreshIcon />}
          onClick={loadDownloads}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {/* ── Stats bar ── */}
      {!loading && downloads.length > 0 && (
        <Paper
          variant="outlined"
          sx={{ display: 'flex', mb: 3, overflow: 'hidden', borderRadius: 2 }}
        >
          {[
            {
              icon: <StorageIcon sx={{ color: 'text.secondary' }} />,
              value: stats.total,
              label: 'Total Files',
            },
            {
              icon: <AvailableIcon color="success" />,
              value: stats.available,
              label: 'Available',
              color: 'success.main',
            },
            {
              icon: <DownloadIcon color="primary" />,
              value: fmtSize(stats.totalSize),
              label: 'Total Size',
              color: 'primary.main',
            },
            {
              icon: <ExcelIcon sx={{ color: '#217346' }} />,
              value: stats.excelCount,
              label: 'Excel Exports',
            },
          ].map((s, i, arr) => (
            <Box
              key={i}
              sx={{
                flex: 1, px: 3, py: 2,
                display: 'flex', alignItems: 'center', gap: 1.5,
                borderRight: i < arr.length - 1 ? '1px solid' : 'none',
                borderColor: 'divider',
              }}
            >
              {s.icon}
              <Box>
                <Typography variant="h6" fontWeight={700} color={s.color || 'text.primary'} lineHeight={1.2}>
                  {s.value}
                </Typography>
                <Typography variant="caption" color="text.secondary">{s.label}</Typography>
              </Box>
            </Box>
          ))}
        </Paper>
      )}

      {/* ── Toolbar ── */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2.5, flexWrap: 'wrap' }}>
        <ToggleButtonGroup
          value={filter}
          exclusive
          onChange={(_, val) => val !== null && setFilter(val)}
          size="small"
        >
          <ToggleButton value="available">Available</ToggleButton>
          <ToggleButton value="downloaded">Downloaded</ToggleButton>
          <ToggleButton value="expired">Expired</ToggleButton>
          <ToggleButton value="">All</ToggleButton>
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search filename, execution ID, or format…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          sx={{ flex: 1, minWidth: 260, maxWidth: 460 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ fontSize: 18 }} />
              </InputAdornment>
            ),
            endAdornment: search ? (
              <InputAdornment position="end">
                <IconButton size="small" onClick={() => setSearch('')}>
                  <ClearIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />

        <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto' }}>
          {loading
            ? 'Loading…'
            : `${filtered.length} of ${downloads.length} file${downloads.length !== 1 ? 's' : ''}`}
        </Typography>
      </Box>

      {/* ── Content ── */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 10 }}>
          <CircularProgress />
        </Box>

      ) : downloads.length === 0 ? (
        <Paper sx={{ p: 8, textAlign: 'center', border: '2px dashed', borderColor: 'divider', borderRadius: 2 }}>
          <DownloadIcon sx={{ fontSize: 64, color: 'text.disabled', mb: 2 }} />
          <Typography variant="h6" gutterBottom>No downloads yet</Typography>
          <Typography color="text.secondary" sx={{ maxWidth: 420, mx: 'auto' }}>
            Run a query — the result CSV appears here automatically. Use the{' '}
            <strong>Export</strong> button in the Results viewer to also create
            Excel (.xlsx) or JSON exports.
          </Typography>
        </Paper>

      ) : filtered.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 2 }}>
          <Typography variant="h6" gutterBottom>No results for "{search}"</Typography>
          <Button onClick={() => setSearch('')}>Clear search</Button>
        </Paper>

      ) : (
        <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {/* Icon column */}
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', width: 44, pl: 2 }} />
                <SortHeader field="filename"    label="File"     />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Format</TableCell>
                <SortHeader field="total_rows"       label="Rows"     align="right" />
                <SortHeader field="file_size_bytes"  label="Size"     align="right" />
                <SortHeader field="duration_seconds" label="Duration" align="right" />
                <SortHeader field="created_at"       label="Created"  />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Status</TableCell>
                <SortHeader field="download_count"   label="DLs"      align="center" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Expires</TableCell>
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', pr: 2 }}>Actions</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {paginated.map(d => {
                const fmt     = d.format || 'csv';
                const fmtMeta = FORMAT_META[fmt] || FORMAT_META.csv;
                const expired = d.expires_at && new Date(d.expires_at) < new Date();

                return (
                  <TableRow key={d.file_id} hover sx={{ '&:last-child td': { border: 0 } }}>

                    {/* Icon */}
                    <TableCell sx={{ pl: 2, py: 1 }}>
                      <FileTypeIcon filename={d.filename} format={fmt} />
                    </TableCell>

                    {/* File name + execution ID */}
                    <TableCell sx={{ maxWidth: 280 }}>
                      <Typography variant="body2" fontWeight={500} noWrap title={d.filename}>
                        {d.filename || '—'}
                      </Typography>
                      {d.execution_id && (
                        <Typography
                          variant="caption"
                          color="text.disabled"
                          sx={{ display: 'block', fontFamily: 'monospace' }}
                        >
                          {d.execution_id.substring(0, 13)}…
                        </Typography>
                      )}
                    </TableCell>

                    {/* Format badge */}
                    <TableCell>
                      <Chip
                        label={fmtMeta.label}
                        size="small"
                        color={fmtMeta.color}
                        variant="outlined"
                        sx={{ fontWeight: 700, fontSize: 10, height: 20, letterSpacing: 0.5 }}
                      />
                    </TableCell>

                    {/* Row count */}
                    <TableCell align="right">
                      <Typography variant="body2">{fmtRows(d.total_rows)}</Typography>
                    </TableCell>

                    {/* File size */}
                    <TableCell align="right">
                      <Typography variant="body2">{fmtSize(d.file_size_bytes)}</Typography>
                    </TableCell>

                    {/* Query duration */}
                    <TableCell align="right">
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 0.5 }}>
                        {d.duration_seconds != null && (
                          <TimerIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
                        )}
                        <Typography variant="body2" color="text.secondary">
                          {fmtDuration(d.duration_seconds)}
                        </Typography>
                      </Box>
                    </TableCell>

                    {/* Created at */}
                    <TableCell sx={{ whiteSpace: 'nowrap' }}>
                      <Typography variant="body2">{fmtDate(d.created_at)}</Typography>
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      <Chip
                        label={d.status}
                        size="small"
                        color={statusColor[d.status] || 'default'}
                        variant="outlined"
                      />
                    </TableCell>

                    {/* Download count */}
                    <TableCell align="center">
                      <Typography variant="body2">{d.download_count ?? 0}</Typography>
                    </TableCell>

                    {/* Expires */}
                    <TableCell sx={{ whiteSpace: 'nowrap' }}>
                      <Typography
                        variant="caption"
                        color={expired ? 'error.main' : 'text.secondary'}
                      >
                        {d.expires_at ? new Date(d.expires_at).toLocaleDateString() : '—'}
                      </Typography>
                    </TableCell>

                    {/* Actions */}
                    <TableCell sx={{ whiteSpace: 'nowrap', pr: 2 }}>
                      {/* Preview — works with execution_id OR file_id directly */}
                      {(d.execution_id || d.file_id) && d.status === 'available' && (
                        <Tooltip title="Preview data">
                          <IconButton size="small" onClick={() => setPreviewTarget(d)}>
                            <PreviewIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* Download — only if file is available */}
                      {d.status === 'available' && (
                        <Tooltip title="Download file">
                          <IconButton
                            size="small"
                            color="primary"
                            onClick={() => handleDownload(d.file_id, d.filename)}
                          >
                            <DownloadIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* Delete */}
                      <Tooltip title="Delete">
                        <IconButton size="small" color="error" onClick={() => setDeleteTarget(d)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </TableContainer>
      )}

      {/* ── Floating preview window (non-modal, draggable/resizable) ── */}
      <FloatingPreviewWindow
        open={!!previewTarget}
        onClose={() => setPreviewTarget(null)}
        download={previewTarget}
      />

      {/* ── Delete confirmation ── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Delete Download</DialogTitle>
        <DialogContent>
          <Typography>
            Delete <strong>{deleteTarget?.filename}</strong>? This cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default Downloads;
