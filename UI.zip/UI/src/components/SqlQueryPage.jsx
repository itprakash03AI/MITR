/**
 * SQL Query Page — Enterprise SQL editor for Trino/Starburst, Snowflake, Databricks
 *
 * Layout: Superset-style
 *   Left  (300px) — Connection + Schema Browser (catalogs → schemas → tables → columns)
 *   Center         — Primary SQL editor + optional secondary SQL editor for cross-source joins
 *   Results        — DataGridViewer (same as Query Builder)
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Box, Typography, Button, Paper, Chip, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, MenuItem, IconButton, Tooltip, Stack, Divider,
  List, ListItem, ListItemButton, ListItemText, ListItemIcon,
  Collapse, InputAdornment, Alert, LinearProgress,
  ToggleButton, ToggleButtonGroup, Tabs, Tab,
} from '@mui/material';
import {
  PlayArrow as RunIcon, Save as SaveIcon, Add as AddIcon,
  Delete as DeleteIcon, Edit as EditIcon, Refresh as RefreshIcon,
  Storage as CatalogIcon, Schema as SchemaIcon, TableChart as TableIcon,
  ViewColumn as ColumnIcon, ExpandMore as ExpandMoreIcon,
  ChevronRight as ChevronRightIcon, ContentCopy as CopyIcon,
  Link as JoinIcon, Close as CloseIcon, Search as SearchIcon,
  Bookmark as BookmarkIcon, Code as CodeIcon, CheckCircle as CheckIcon,
  Cancel as CancelIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import DataGridViewer from './DataGridViewer';
import api from '../services/api';

const SCHEMA_PANEL_W = 300;

// ── Type badge ────────────────────────────────────────────────────────────────
const ConnTypeBadge = ({ type }) => {
  const colors = {
    trino: '#3b82f6', starburst: '#f59e0b', snowflake: '#22d3ee', databricks: '#f97316',
  };
  return (
    <Chip
      label={(type || '').toUpperCase()}
      size="small"
      sx={{
        fontSize: 10, height: 18, fontWeight: 700,
        bgcolor: colors[type] || 'grey.400', color: 'white',
        '& .MuiChip-label': { px: 0.75 },
      }}
    />
  );
};

// ── Simple textarea-based SQL editor ─────────────────────────────────────────
const SqlEditor = ({ value, onChange, label, placeholder, rows = 12 }) => (
  <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
    {label && (
      <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', px: 1.5, py: 0.5, borderBottom: 1, borderColor: 'divider', display: 'block', textTransform: 'uppercase', letterSpacing: 0.5, bgcolor: 'grey.50' }}>
        {label}
      </Typography>
    )}
    <Box
      component="textarea"
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder || 'Enter SQL query...'}
      spellCheck={false}
      sx={{
        flex: 1, width: '100%', minHeight: rows * 20,
        fontFamily: '"Fira Code", "Consolas", monospace',
        fontSize: 13, lineHeight: 1.6,
        p: 1.5, border: 'none', outline: 'none', resize: 'none',
        bgcolor: '#1e1e2e', color: '#cdd6f4',
        '&::placeholder': { color: '#6c7086' },
      }}
    />
  </Box>
);

// ── Schema tree node ──────────────────────────────────────────────────────────
const SchemaTreeNode = ({ label, icon, children, onInsert, depth = 0, loading = false, count, type }) => {
  const [open, setOpen] = useState(false);
  const hasChildren = !!children;
  const iconColor = { catalog: 'primary.main', schema: 'warning.main', table: 'success.main', column: 'text.secondary' }[type] || 'text.secondary';

  return (
    <>
      <ListItem disablePadding>
        <ListItemButton
          onClick={() => { if (hasChildren) setOpen(o => !o); if (onInsert) onInsert(); }}
          sx={{
            pl: 1 + depth * 1.5,
            py: 0.4,
            '&:hover .insert-hint': { opacity: 1 },
          }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 24, color: iconColor }}>
            {loading ? <CircularProgress size={14} /> : icon}
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="body2" sx={{ fontSize: 13, lineHeight: 1.4, flexGrow: 1 }} noWrap>
                  {label}
                </Typography>
                {count !== undefined && (
                  <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0 }}>{count}</Typography>
                )}
              </Box>
            }
          />
          {hasChildren && (
            open ? <ExpandMoreIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
                 : <ChevronRightIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
          )}
        </ListItemButton>
      </ListItem>
      {hasChildren && (
        <Collapse in={open} unmountOnExit>
          {children}
        </Collapse>
      )}
    </>
  );
};

// ── Column list (leaf) ────────────────────────────────────────────────────────
const ColumnList = ({ columns, onInsert }) => (
  <List disablePadding>
    {columns.map(col => (
      <ListItem key={col.name} disablePadding>
        <ListItemButton
          onClick={() => onInsert(col.name)}
          sx={{ pl: 7, py: 0.25 }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 20 }}>
            <ColumnIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: 12, flexGrow: 1 }} noWrap>{col.name}</Typography>
                <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0, fontFamily: 'monospace' }}>{col.type}</Typography>
              </Box>
            }
          />
        </ListItemButton>
      </ListItem>
    ))}
  </List>
);

// ── Table tree with lazy-load ─────────────────────────────────────────────────
const TableTree = ({ connectionId, catalog, schema, onInsertTable, onInsertColumn }) => {
  const [tables, setTables] = useState(null);
  const [columns, setColumns] = useState({});
  const [loadingTables, setLoadingTables] = useState(false);
  const [loadingCols, setLoadingCols] = useState({});

  useEffect(() => {
    setLoadingTables(true);
    api.listSqlTables(connectionId, catalog, schema)
      .then(setTables)
      .catch(() => setTables([]))
      .finally(() => setLoadingTables(false));
  }, [connectionId, catalog, schema]);

  const loadColumns = (tableName) => {
    if (columns[tableName] !== undefined) return;
    setLoadingCols(p => ({ ...p, [tableName]: true }));
    api.listSqlColumns(connectionId, catalog, schema, tableName)
      .then(cols => setColumns(p => ({ ...p, [tableName]: cols })))
      .catch(() => setColumns(p => ({ ...p, [tableName]: [] })))
      .finally(() => setLoadingCols(p => ({ ...p, [tableName]: false })));
  };

  if (loadingTables) return <Box sx={{ pl: 6, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!tables) return null;

  return (
    <List disablePadding>
      {tables.map(t => (
        <SchemaTreeNode
          key={t.name}
          label={t.name}
          icon={<TableIcon sx={{ fontSize: 14 }} />}
          depth={3}
          type="table"
          onInsert={() => { onInsertTable(`${catalog}.${schema}.${t.name}`); loadColumns(t.name); }}
          loading={loadingCols[t.name]}
          count={columns[t.name]?.length}
        >
          {(columns[t.name] !== undefined) && (
            <ColumnList
              columns={columns[t.name]}
              onInsert={col => onInsertColumn(`${catalog}.${schema}.${t.name}.${col}`)}
            />
          )}
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Schema tree ───────────────────────────────────────────────────────────────
const SchemaTree = ({ connectionId, catalog, onInsert }) => {
  const [schemas, setSchemas] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.listSqlSchemas(connectionId, catalog)
      .then(setSchemas)
      .catch(() => setSchemas([]))
      .finally(() => setLoading(false));
  }, [connectionId, catalog]);

  if (loading) return <Box sx={{ pl: 5, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!schemas) return null;

  return (
    <List disablePadding>
      {schemas.map(s => (
        <SchemaTreeNode
          key={s}
          label={s}
          icon={<SchemaIcon sx={{ fontSize: 14 }} />}
          depth={2}
          type="schema"
          onInsert={() => onInsert(`${catalog}.${s}`)}
        >
          <TableTree
            connectionId={connectionId}
            catalog={catalog}
            schema={s}
            onInsertTable={onInsert}
            onInsertColumn={onInsert}
          />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Catalog tree ──────────────────────────────────────────────────────────────
const CatalogTree = ({ connectionId, onInsert }) => {
  const [catalogs, setCatalogs] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = () => {
    setLoading(true);
    setError(null);
    api.listSqlCatalogs(connectionId)
      .then(setCatalogs)
      .catch(e => setError(e.message || 'Failed to load catalogs'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { if (connectionId) load(); }, [connectionId]);

  if (!connectionId) return (
    <Box sx={{ p: 2 }}>
      <Typography variant="caption" color="text.disabled">Select a connection to browse schema</Typography>
    </Box>
  );

  if (loading && !catalogs) return <Box sx={{ p: 2 }}><CircularProgress size={20} /></Box>;
  if (error) return (
    <Box sx={{ p: 1 }}>
      <Alert severity="error" sx={{ fontSize: 12 }} action={<Button size="small" onClick={load}>Retry</Button>}>{error}</Alert>
    </Box>
  );

  return (
    <List disablePadding>
      {(catalogs || []).map(cat => (
        <SchemaTreeNode
          key={cat}
          label={cat}
          icon={<CatalogIcon sx={{ fontSize: 14 }} />}
          depth={1}
          type="catalog"
          onInsert={() => onInsert(cat)}
        >
          <SchemaTree connectionId={connectionId} catalog={cat} onInsert={onInsert} />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Save Query Dialog ─────────────────────────────────────────────────────────
const SaveSqlQueryDialog = ({ open, onClose, onSaved, primaryConnectionId, primarySql, secondaryConnectionId, secondarySql, joinConfig, editingQuery }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    if (open) {
      setName(editingQuery?.name || '');
      setDescription(editingQuery?.description || '');
    }
  }, [open, editingQuery]);

  const handleSave = async () => {
    if (!name.trim()) { alert('Enter a query name'); return; }
    try {
      const payload = {
        name:                   name.trim(),
        description:            description || null,
        primary_connection_id:  primaryConnectionId,
        primary_sql:            primarySql,
        secondary_connection_id: secondaryConnectionId || null,
        secondary_sql:          secondaryConnectionId ? secondarySql : null,
        join_config:            secondaryConnectionId ? joinConfig : null,
      };
      let result;
      if (editingQuery?.id) {
        result = await api.updateSqlQuery(editingQuery.id, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated` });
      } else {
        result = await api.createSqlQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved` });
      }
      onSaved(result);
      onClose();
    } catch (e) {
      addNotification({ type: 'error', title: 'Save Error', message: e.message });
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <SaveIcon fontSize="small" />
        {editingQuery?.id ? 'Update SQL Query' : 'Save SQL Query'}
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField label="Name" required fullWidth value={name} onChange={e => setName(e.target.value)} />
          <TextField label="Description" fullWidth multiline rows={2} value={description} onChange={e => setDescription(e.target.value)} />
          {secondaryConnectionId && (
            <Alert severity="info" sx={{ fontSize: 12 }}>
              Cross-source join configuration will be saved with this query.
            </Alert>
          )}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {editingQuery?.id ? 'Update' : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ── Join Config Dialog ────────────────────────────────────────────────────────
const JoinConfigDialog = ({ open, onClose, config, onChange }) => {
  const [local, setLocal] = useState({ how: 'inner', left_on: '', right_on: '', ...config });

  useEffect(() => { if (open) setLocal({ how: 'inner', left_on: '', right_on: '', ...config }); }, [open]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Cross-Source Join Configuration</DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField select label="Join Type" fullWidth size="small" value={local.how} onChange={e => setLocal(p => ({ ...p, how: e.target.value }))}>
            {['inner', 'left', 'right', 'outer'].map(h => (
              <MenuItem key={h} value={h}>{h.toUpperCase()} JOIN</MenuItem>
            ))}
          </TextField>
          <TextField label="Primary Key Column" placeholder="e.g. customer_id" fullWidth size="small" value={local.left_on} onChange={e => setLocal(p => ({ ...p, left_on: e.target.value }))} helperText="Column from primary source query" />
          <TextField label="Secondary Key Column" placeholder="e.g. id" fullWidth size="small" value={local.right_on} onChange={e => setLocal(p => ({ ...p, right_on: e.target.value }))} helperText="Column from secondary source query" />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onChange(local); onClose(); }}>Apply</Button>
      </DialogActions>
    </Dialog>
  );
};

// ── Saved Queries Panel ───────────────────────────────────────────────────────
const SavedQueriesPanel = ({ onLoad, onClose }) => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    api.listSqlQueries(true).then(setQueries).catch(() => setQueries([])).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return q ? queries.filter(r => r.name.toLowerCase().includes(q)) : queries;
  }, [queries, search]);

  const handleDelete = async (query) => {
    if (!window.confirm(`Delete "${query.name}"?`)) return;
    try {
      await api.deleteSqlQuery(query.id);
      setQueries(prev => prev.filter(q => q.id !== query.id));
      addNotification({ type: 'success', title: 'Deleted', message: `"${query.name}" deleted` });
    } catch (e) {
      addNotification({ type: 'error', title: 'Delete Error', message: e.message });
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ p: 1.5, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, flexGrow: 1 }}>Saved SQL Queries</Typography>
        <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
      </Box>
      <Box sx={{ p: 1 }}>
        <TextField
          size="small" fullWidth placeholder="Search…" value={search}
          onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
        />
      </Box>
      <Box sx={{ flex: 1, overflowY: 'auto' }}>
        {loading ? <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress size={24} /></Box> : (
          filtered.map(q => (
            <Box key={q.id} sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', '&:hover': { bgcolor: 'action.hover' } }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" fontWeight={600} noWrap>{q.name}</Typography>
                  {q.secondary_connection_id && (
                    <Chip label="Cross-source" size="small" color="warning" sx={{ fontSize: 10, height: 16, mt: 0.25 }} />
                  )}
                  <Typography variant="caption" color="text.disabled" display="block">
                    {q.execution_count} runs · {q.created_at ? new Date(q.created_at).toLocaleDateString() : ''}
                  </Typography>
                </Box>
                <Tooltip title="Load into editor"><IconButton size="small" color="primary" onClick={() => onLoad(q)}><EditIcon fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => handleDelete(q)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
              </Box>
            </Box>
          ))
        )}
        {!loading && filtered.length === 0 && (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="caption" color="text.disabled">No saved SQL queries found</Typography>
          </Box>
        )}
      </Box>
    </Box>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ══════════════════════════════════════════════════════════════════════════════
const SqlQueryPage = () => {
  const { addNotification } = useNotifications();
  const { lastMessage } = useWebSocket();

  // SQL connector connections (trino, starburst, snowflake, databricks)
  const [sqlConnections, setSqlConnections] = useState([]);
  const [connectionsLoading, setConnectionsLoading] = useState(true);

  // Schema browser
  const [primaryConnId, setPrimaryConnId] = useState(null);
  const [schemaTarget, setSchemaTarget] = useState('primary'); // 'primary' | 'secondary'

  // SQL editors
  const [primarySql, setPrimarySql] = useState('-- Primary SQL Query\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000');
  const [secondaryConnId, setSecondaryConnId] = useState(null);
  const [secondarySql, setSecondarySql] = useState('-- Secondary SQL Query (optional cross-source join)\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000');
  const [joinConfig, setJoinConfig] = useState({ how: 'inner', left_on: '', right_on: '' });
  const [showSecondary, setShowSecondary] = useState(false);

  // Dialogs
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showJoinConfig, setShowJoinConfig] = useState(false);
  const [showSavedPanel, setShowSavedPanel] = useState(false);
  const [editingQuery, setEditingQuery] = useState(null);

  // Execution
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const [resultsExecutionId, setResultsExecutionId] = useState(null);

  // Row limit
  const [rowLimit, setRowLimit] = useState(10000);

  // Active editor tab
  const [activeTab, setActiveTab] = useState(0);

  // Load SQL connector connections on mount
  useEffect(() => {
    api.listConnections(true)
      .then(conns => {
        const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks'];
        setSqlConnections((conns || []).filter(c => SQL_TYPES.includes(c.connection_type)));
      })
      .catch(() => setSqlConnections([]))
      .finally(() => setConnectionsLoading(false));
  }, []);

  // WebSocket progress handler
  useEffect(() => {
    if (!lastMessage || lastMessage.execution_id !== executionId) return;
    const msg = lastMessage;
    if (msg.type === 'execution_progress') {
      setProgress({ status: msg.data?.status || 'processing', ...msg.data });
    } else if (msg.type === 'execution_completed') {
      setExecuting(false);
      setProgress({ status: 'completed', total_rows: msg.stats?.total_rows });
      setResultsExecutionId(executionId);
      setShowResults(true);
      addNotification({ type: 'success', title: 'SQL Query Completed', message: `${msg.stats?.total_rows?.toLocaleString()} rows returned` });
    } else if (msg.type === 'execution_failed') {
      setExecuting(false);
      setProgress({ status: 'failed', error: msg.error });
      addNotification({ type: 'error', title: 'SQL Query Failed', message: msg.error });
    }
  }, [lastMessage]);

  const handleInsertText = useCallback((text) => {
    const target = schemaTarget === 'secondary' ? secondarySql : primarySql;
    const setter = schemaTarget === 'secondary' ? setSecondarySql : setPrimarySql;
    setter(target + (target.endsWith('\n') ? '' : '\n') + text);
  }, [schemaTarget, primarySql, secondarySql]);

  const handleExecute = async () => {
    if (!primaryConnId) {
      addNotification({ type: 'warning', title: 'No Connection', message: 'Select a primary data source connection' });
      return;
    }
    if (!primarySql.trim()) {
      addNotification({ type: 'warning', title: 'Empty Query', message: 'Enter a SQL query to execute' });
      return;
    }
    if (showSecondary && secondaryConnId && (!joinConfig.left_on || !joinConfig.right_on)) {
      addNotification({ type: 'warning', title: 'Join Config Incomplete', message: 'Configure join columns before executing cross-source query' });
      setShowJoinConfig(true);
      return;
    }

    try {
      setExecuting(true);
      setShowResults(false);
      setProgress({ status: 'starting' });

      const payload = {
        primary_connection_id: primaryConnId,
        primary_sql: primarySql,
        row_limit: rowLimit || null,
        ...(showSecondary && secondaryConnId
          ? {
              secondary_connection_id: secondaryConnId,
              secondary_sql: secondarySql,
              join_config: joinConfig,
            }
          : {}),
      };

      const response = await api.executeSqlQuery(payload);
      setExecutionId(response.execution_id);
      addNotification({ type: 'info', title: 'SQL Query Started', message: `ID: ${response.execution_id?.substring(0, 8)}` });
    } catch (e) {
      setExecuting(false);
      setProgress(null);
      addNotification({ type: 'error', title: 'Execution Failed', message: e.message });
    }
  };

  const loadSavedQuery = (q) => {
    setPrimaryConnId(q.primary_connection_id);
    setPrimarySql(q.primary_sql || '');
    if (q.secondary_connection_id) {
      setSecondaryConnId(q.secondary_connection_id);
      setSecondarySql(q.secondary_sql || '');
      setJoinConfig(q.join_config || { how: 'inner', left_on: '', right_on: '' });
      setShowSecondary(true);
    } else {
      setSecondaryConnId(null);
      setShowSecondary(false);
    }
    setEditingQuery(q);
    setShowSavedPanel(false);
    addNotification({ type: 'info', title: 'Query Loaded', message: `Editing "${q.name}"` });
  };

  const primaryConn  = sqlConnections.find(c => c.id === primaryConnId);
  const secondaryConn = sqlConnections.find(c => c.id === secondaryConnId);
  const browsedConnId = schemaTarget === 'secondary' ? secondaryConnId : primaryConnId;

  const statusColor = { starting: 'info', processing: 'warning', completed: 'success', failed: 'error' };

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', overflow: 'hidden' }}>

      {/* ─── Left: Schema Browser ──────────────────────────────────────────── */}
      <Box sx={{ width: SCHEMA_PANEL_W, minWidth: SCHEMA_PANEL_W, display: 'flex', flexDirection: 'column', borderRight: 1, borderColor: 'divider', bgcolor: 'background.paper', overflow: 'hidden' }}>

        {/* Header */}
        <Box sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <Typography variant="caption" sx={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Schema Browser
          </Typography>
        </Box>

        {/* Connection pickers */}
        <Box sx={{ p: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
            Browse schema for:
          </Typography>
          <ToggleButtonGroup size="small" value={schemaTarget} exclusive onChange={(_, v) => v && setSchemaTarget(v)} sx={{ mb: 1 }}>
            <ToggleButton value="primary" sx={{ fontSize: 11 }}>Primary</ToggleButton>
            {showSecondary && <ToggleButton value="secondary" sx={{ fontSize: 11 }}>Secondary</ToggleButton>}
          </ToggleButtonGroup>

          {/* Primary connection */}
          <TextField
            select fullWidth size="small" label="Primary Source"
            value={primaryConnId || ''}
            onChange={e => { setPrimaryConnId(e.target.value || null); setSchemaTarget('primary'); }}
            sx={{ mb: 1 }}
          >
            <MenuItem value=""><em>Select connection…</em></MenuItem>
            {sqlConnections.map(c => (
              <MenuItem key={c.id} value={c.id}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <ConnTypeBadge type={c.connection_type} />
                  <Typography variant="body2" noWrap>{c.name}</Typography>
                </Box>
              </MenuItem>
            ))}
          </TextField>

          {/* Secondary connection (cross-source) */}
          {showSecondary && (
            <TextField
              select fullWidth size="small" label="Secondary Source"
              value={secondaryConnId || ''}
              onChange={e => { setSecondaryConnId(e.target.value || null); setSchemaTarget('secondary'); }}
            >
              <MenuItem value=""><em>Select connection…</em></MenuItem>
              {sqlConnections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ConnTypeBadge type={c.connection_type} />
                    <Typography variant="body2" noWrap>{c.name}</Typography>
                  </Box>
                </MenuItem>
              ))}
            </TextField>
          )}
        </Box>

        {/* Catalog/schema tree */}
        <Box sx={{ flex: 1, overflowY: 'auto' }}>
          <CatalogTree
            connectionId={browsedConnId}
            onInsert={handleInsertText}
          />
        </Box>

        {connectionsLoading && (
          <Box sx={{ p: 1 }}><LinearProgress /></Box>
        )}
        {!connectionsLoading && sqlConnections.length === 0 && (
          <Box sx={{ p: 2 }}>
            <Alert severity="info" sx={{ fontSize: 12 }}>
              No SQL connections found. Add a Trino, Snowflake, or Databricks connection first.
            </Alert>
          </Box>
        )}
      </Box>

      {/* ─── Right: Editor + Results ────────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Toolbar */}
        <Box sx={{ px: 1.5, py: 0.75, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0, bgcolor: 'background.paper' }}>

          {/* Saved queries toggle */}
          <Tooltip title="Saved SQL Queries">
            <IconButton size="small" color={showSavedPanel ? 'primary' : 'default'} onClick={() => setShowSavedPanel(p => !p)}>
              <BookmarkIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          {/* Cross-source toggle */}
          <Tooltip title={showSecondary ? 'Remove secondary source' : 'Add secondary source for cross-source join'}>
            <Button
              size="small"
              startIcon={<JoinIcon />}
              variant={showSecondary ? 'contained' : 'outlined'}
              color={showSecondary ? 'warning' : 'inherit'}
              onClick={() => setShowSecondary(p => !p)}
              sx={{ fontSize: 12 }}
            >
              Cross-Source
            </Button>
          </Tooltip>

          {showSecondary && secondaryConnId && (
            <Tooltip title="Configure join keys">
              <Button
                size="small"
                startIcon={<CodeIcon />}
                variant="outlined"
                color={joinConfig.left_on && joinConfig.right_on ? 'success' : 'warning'}
                onClick={() => setShowJoinConfig(true)}
                sx={{ fontSize: 12 }}
              >
                Join: {joinConfig.how.toUpperCase()}
                {joinConfig.left_on && joinConfig.right_on && (
                  <> · {joinConfig.left_on} = {joinConfig.right_on}</>
                )}
              </Button>
            </Tooltip>
          )}

          <Box sx={{ flexGrow: 1 }} />

          {/* Row limit */}
          <TextField
            select size="small" label="Row Limit" value={rowLimit}
            onChange={e => setRowLimit(Number(e.target.value))}
            sx={{ minWidth: 120 }}
          >
            {[1000, 5000, 10000, 50000, 100000].map(n => (
              <MenuItem key={n} value={n}>{n.toLocaleString()}</MenuItem>
            ))}
          </TextField>

          {/* Save */}
          <Tooltip title="Save query">
            <IconButton size="small" onClick={() => setShowSaveDialog(true)} disabled={!primaryConnId}>
              <SaveIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          {/* Execute */}
          <Button
            variant="contained"
            startIcon={executing ? <CircularProgress size={16} color="inherit" /> : <RunIcon />}
            onClick={handleExecute}
            disabled={executing || !primaryConnId}
            size="small"
            sx={{ minWidth: 100 }}
          >
            {executing ? 'Running…' : 'Run SQL'}
          </Button>
        </Box>

        {/* Saved queries panel */}
        {showSavedPanel && (
          <Box sx={{ height: 340, borderBottom: 1, borderColor: 'divider', overflow: 'hidden', flexShrink: 0 }}>
            <SavedQueriesPanel
              onLoad={loadSavedQuery}
              onClose={() => setShowSavedPanel(false)}
            />
          </Box>
        )}

        {/* Connection badges */}
        {(primaryConn || secondaryConn) && (
          <Box sx={{ px: 1.5, py: 0.5, display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'grey.50', borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
            {primaryConn && (
              <Chip
                icon={<ConnTypeBadge type={primaryConn.connection_type} />}
                label={`Primary: ${primaryConn.name}`}
                size="small"
                variant="outlined"
                sx={{ fontSize: 12 }}
              />
            )}
            {secondaryConn && (
              <>
                <Typography variant="caption" color="text.disabled">→ {joinConfig.how?.toUpperCase()} JOIN →</Typography>
                <Chip
                  icon={<ConnTypeBadge type={secondaryConn.connection_type} />}
                  label={`Secondary: ${secondaryConn.name}`}
                  size="small"
                  color="warning"
                  variant="outlined"
                  sx={{ fontSize: 12 }}
                />
              </>
            )}
            {editingQuery && (
              <Chip label={`Editing: ${editingQuery.name}`} size="small" color="info" onDelete={() => setEditingQuery(null)} />
            )}
          </Box>
        )}

        {/* Progress bar */}
        {executing && (
          <Box sx={{ flexShrink: 0 }}>
            <LinearProgress color={statusColor[progress?.status] || 'primary'} />
            <Box sx={{ px: 2, py: 0.5, bgcolor: 'grey.50' }}>
              <Typography variant="caption" color="text.secondary">
                {progress?.message || progress?.status || 'Executing…'}
              </Typography>
            </Box>
          </Box>
        )}

        {/* Error */}
        {progress?.status === 'failed' && (
          <Alert severity="error" sx={{ m: 1, flexShrink: 0 }} onClose={() => setProgress(null)}>
            {progress.error}
          </Alert>
        )}

        {/* SQL Editors */}
        <Box sx={{ display: 'flex', flex: showResults ? '0 0 280px' : 1, minHeight: 180, borderBottom: showResults ? 1 : 0, borderColor: 'divider', overflow: 'hidden', flexShrink: showResults ? 0 : 1 }}>
          {showSecondary ? (
            <Box sx={{ display: 'flex', width: '100%' }}>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: 1, borderColor: 'divider' }}>
                <SqlEditor
                  value={primarySql}
                  onChange={setPrimarySql}
                  label={`Primary: ${primaryConn?.name || 'select a connection'}`}
                />
              </Box>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                <SqlEditor
                  value={secondarySql}
                  onChange={setSecondarySql}
                  label={`Secondary: ${secondaryConn?.name || 'select a connection'}`}
                />
              </Box>
            </Box>
          ) : (
            <SqlEditor
              value={primarySql}
              onChange={setPrimarySql}
              label={primaryConn ? `${primaryConn.name} (${primaryConn.connection_type})` : 'Select a connection'}
            />
          )}
        </Box>

        {/* Results */}
        {showResults && resultsExecutionId && (
          <Box sx={{ flex: 1, overflow: 'hidden' }}>
            <DataGridViewer executionId={resultsExecutionId} />
          </Box>
        )}
      </Box>

      {/* ─── Dialogs ─────────────────────────────────────────────────────────── */}
      <SaveSqlQueryDialog
        open={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        onSaved={(q) => setEditingQuery(q)}
        primaryConnectionId={primaryConnId}
        primarySql={primarySql}
        secondaryConnectionId={showSecondary ? secondaryConnId : null}
        secondarySql={secondarySql}
        joinConfig={joinConfig}
        editingQuery={editingQuery}
      />

      <JoinConfigDialog
        open={showJoinConfig}
        onClose={() => setShowJoinConfig(false)}
        config={joinConfig}
        onChange={setJoinConfig}
      />
    </Box>
  );
};

export default SqlQueryPage;
