/**
 * ReportPage — Smart Query Studio
 *
 * Layout: Superset-style split view
 *   Left panel (320px):  query selector, info card, parameters, run button
 *   Right main area:     DataGridViewer results (table / chart / pivot)
 *
 * Features:
 *   - Searchable Autocomplete for saved queries
 *   - Auto-detected {param} placeholder substitution
 *   - Ad-hoc runtime filters (never modify saved query)
 *   - Limit override
 *   - Real-time execution status via polling
 *   - "Modify in Builder" deep link
 */
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import DataGridViewer from './DataGridViewer';
import { useNotifications } from '../context/NotificationContext';
import api from '../services/api';
import {
  Box, Typography, Button, Paper, Card, CardContent, Chip, TextField,
  MenuItem, Autocomplete, CircularProgress, LinearProgress, IconButton,
  Collapse, Divider, Alert, Tooltip,
} from '@mui/material';
import {
  PlayArrow as PlayIcon, Settings as SettingsIcon, Edit as EditIcon,
  Close as CloseIcon, Add as AddIcon, Delete as DeleteIcon,
  BarChart as ChartIcon, Search as SearchIcon, ChevronLeft, ChevronRight,
  Schedule as ScheduleIcon, Storage as StorageIcon, FilterAlt as FilterIcon,
} from '@mui/icons-material';

// ─── helpers ─────────────────────────────────────────────────────────────────
const fmtDate  = (s) => s ? new Date(s).toLocaleString() : '—';
const fmtFiles = (qc) => (qc?.files || []).map(f => f.split('/').pop()).join(', ') || '—';

const extractParams = (queryConfig) => {
  const params = [];
  (queryConfig?.filters || []).forEach(f => {
    const m = String(f.value || '').match(/^\{(\w+)\}$/);
    if (m) params.push({
      name: m[1],
      label: m[1].replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      column: f.column,
      operator: f.operator,
      required: true,
    });
  });
  return params;
};

const LEFT_PANEL_WIDTH = 320;

// ─── main component ───────────────────────────────────────────────────────────
const ReportPage = () => {
  const navigate = useNavigate();
  const { reportId } = useParams();
  const { addNotification } = useNotifications();

  // Queries list
  const [queries, setQueries]         = useState([]);
  const [queriesLoading, setQL]       = useState(true);
  const [search, setSearch]           = useState('');
  const [selectedQuery, setSelectedQ] = useState(null);

  // Left panel collapse
  const [panelOpen, setPanelOpen]     = useState(true);

  // Parameters
  const [detectedParams, setDetectedParams] = useState([]);
  const [paramValues, setParamValues]       = useState({});
  const [limitOverride, setLimitOverride]   = useState('');
  const [showParamSection, setShowParamSection] = useState(false);
  const [adHocFilters, setAdHocFilters]     = useState([]);

  // Execution
  const [executing, setExecuting]     = useState(false);
  const [executionId, setExecId]      = useState(null);
  const [execStatus, setExecStatus]   = useState(null);
  const [showResults, setShowResults] = useState(false);
  const pollRef = useRef(null);

  useEffect(() => { loadQueries(); }, []);

  useEffect(() => {
    if (reportId && queries.length > 0) {
      const q = queries.find(q => String(q.id) === String(reportId));
      if (q) selectQuery(q);
    }
  }, [reportId, queries]);

  const loadQueries = async () => {
    setQL(true);
    try {
      const data = await api.listQueries(true);
      setQueries(data || []);
    } catch (e) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    } finally {
      setQL(false);
    }
  };

  const selectQuery = (q) => {
    setSelectedQ(q);
    setSearch(q.name);
    setShowResults(false);
    setExecId(null);
    setExecStatus(null);
    const params = extractParams(q.query_config);
    setDetectedParams(params);
    setParamValues({});
    setLimitOverride('');
    setAdHocFilters([]);
    setShowParamSection(params.length > 0);
  };

  const filteredQueries = queries.filter(q =>
    !search || q.name.toLowerCase().includes(search.toLowerCase()) ||
    (q.description || '').toLowerCase().includes(search.toLowerCase())
  );

  // ── Execute ───────────────────────────────────────────────────────────────
  const handleRun = () => {
    if (!selectedQuery) return;
    for (const p of detectedParams) {
      if (p.required && !paramValues[p.name]) {
        addNotification({ type: 'warning', title: 'Missing Parameter', message: `"${p.label}" is required` });
        setShowParamSection(true);
        return;
      }
    }
    executeQuery();
  };

  const executeQuery = async () => {
    setExecuting(true);
    setShowResults(false);
    setExecStatus('pending');
    setPanelOpen(false); // collapse left panel → maximize results area

    const qc = JSON.parse(JSON.stringify(selectedQuery.query_config));
    if (qc.filters) {
      qc.filters = qc.filters
        .map(f => {
          const m = String(f.value || '').match(/^\{(\w+)\}$/);
          return (m && paramValues[m[1]]) ? { ...f, value: paramValues[m[1]] } : f;
        })
        .filter(f => !String(f.value || '').match(/^\{(\w+)\}$/));
    }
    // Merge ad-hoc filters
    const validAdHoc = adHocFilters.filter(f => f.column && f.value);
    if (validAdHoc.length > 0) {
      qc.filters = [...(qc.filters || []), ...validAdHoc];
    }
    if (limitOverride && !isNaN(+limitOverride)) qc.limit = +limitOverride;

    try {
      const res = await api.executeQuery({ query_config: qc, query_id: selectedQuery.id });
      setExecId(res.execution_id);
      startPolling(res.execution_id);
    } catch (e) {
      setExecuting(false);
      setExecStatus('failed');
      addNotification({ type: 'error', title: 'Execution Failed', message: e.message });
    }
  };

  const startPolling = (execId) => {
    let attempts = 0;
    pollRef.current = setInterval(async () => {
      attempts++;
      try {
        const status = await api.getExecutionStatus(execId);
        setExecStatus(status.status);
        if (status.status === 'completed') {
          clearInterval(pollRef.current);
          setExecuting(false);
          setShowResults(true);
          addNotification({ type: 'success', title: 'Report Ready', message: `${(status.total_rows || 0).toLocaleString()} rows` });
        } else if (status.status === 'failed') {
          clearInterval(pollRef.current);
          setExecuting(false);
          addNotification({ type: 'error', title: 'Failed', message: status.error_message || 'Unknown error' });
        } else if (attempts > 120) {
          clearInterval(pollRef.current);
          setExecuting(false);
          addNotification({ type: 'warning', title: 'Still Running', message: 'Check Exports page when done.' });
        }
      } catch {}
    }, 2000);
  };

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  const handleModify = () => {
    if (!selectedQuery) return;
    navigate('/', { state: { loadQuery: selectedQuery } });
  };

  const handleCancel = () => {
    clearInterval(pollRef.current);
    if (executionId) api.cancelExecution(executionId).catch(() => {});
    setExecuting(false);
    setExecStatus('cancelled');
    addNotification({ type: 'info', title: 'Cancelled', message: 'Execution cancelled' });
  };

  // ─── RENDER ───────────────────────────────────────────────────────────────
  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 52px)', overflow: 'hidden', bgcolor: 'background.default' }}>

      {/* ══ LEFT CONTROL PANEL ══════════════════════════════════════════════ */}
      <Box
        sx={{
          width: panelOpen ? LEFT_PANEL_WIDTH : 0,
          minWidth: panelOpen ? LEFT_PANEL_WIDTH : 0,
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
          borderRight: 1,
          borderColor: 'divider',
          bgcolor: 'background.paper',
          overflow: 'hidden',
          transition: 'width 0.2s ease, min-width 0.2s ease',
        }}
      >
        {/* Panel header */}
        <Box sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          px: 2,
          py: 1.5,
          borderBottom: 1,
          borderColor: 'divider',
          bgcolor: 'primary.main',
        }}>
          <ChartIcon sx={{ color: 'white', fontSize: 20 }} />
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: 'white', flex: 1, whiteSpace: 'nowrap' }}>
            Reports
          </Typography>
        </Box>

        <Box sx={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>

          {/* ── Query Selector ── */}
          <Box sx={{ px: 2, pt: 2, pb: 1 }}>
            <Typography variant="overline" sx={{ color: 'text.secondary', fontSize: '0.65rem', letterSpacing: 1 }}>
              SELECT QUERY / VIEW
            </Typography>
            <Autocomplete
              sx={{ mt: 1 }}
              options={filteredQueries}
              loading={queriesLoading}
              getOptionLabel={(o) => o.name || ''}
              value={selectedQuery}
              inputValue={search}
              onInputChange={(_, v, reason) => { if (reason !== 'reset') setSearch(v); }}
              onChange={(_, v) => { if (v) selectQuery(v); }}
              isOptionEqualToValue={(o, v) => o.id === v?.id}
              noOptionsText={queriesLoading ? 'Loading...' : 'No saved queries found.'}
              renderInput={(params) => (
                <TextField
                  {...params}
                  size="small"
                  placeholder="Search queries..."
                  InputProps={{
                    ...params.InputProps,
                    startAdornment: (
                      <>
                        <SearchIcon sx={{ color: 'text.secondary', fontSize: 18, mr: 0.5 }} />
                        {params.InputProps.startAdornment}
                      </>
                    ),
                    endAdornment: (
                      <>
                        {queriesLoading ? <CircularProgress size={16} /> : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              renderOption={(props, option) => (
                <Box component="li" {...props} key={option.id} sx={{ display: 'block !important', py: 1, px: 1.5 }}>
                  <Typography variant="body2" sx={{ fontWeight: 600, lineHeight: 1.3 }}>{option.name}</Typography>
                  <Box sx={{ display: 'flex', gap: 0.75, mt: 0.25, flexWrap: 'wrap' }}>
                    <Typography variant="caption" color="text.secondary">
                      {(option.query_config?.files || []).length} file(s)
                    </Typography>
                    <Typography variant="caption" color="text.secondary">·</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {option.execution_count || 0} runs
                    </Typography>
                  </Box>
                  {option.description && (
                    <Typography variant="caption" sx={{ color: 'text.disabled', fontStyle: 'italic', display: 'block', mt: 0.25, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {option.description}
                    </Typography>
                  )}
                </Box>
              )}
            />
          </Box>

          {/* ── Query Info Card ── */}
          {selectedQuery && (
            <Box sx={{ px: 2, pb: 1.5 }}>
              <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'grey.50' }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 0.75 }}>
                  {selectedQuery.name}
                </Typography>

                {selectedQuery.description && (
                  <Typography variant="caption" sx={{ color: 'text.secondary', display: 'block', mb: 0.75, lineHeight: 1.5 }}>
                    {selectedQuery.description}
                  </Typography>
                )}

                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 0.75 }}>
                  {selectedQuery.execution_count > 0 && (
                    <Chip size="small" icon={<PlayIcon sx={{ fontSize: '0.75rem !important' }} />}
                      label={`${selectedQuery.execution_count} runs`} />
                  )}
                  <Chip size="small" icon={<StorageIcon sx={{ fontSize: '0.75rem !important' }} />}
                    label={`${(selectedQuery.query_config?.files || []).length} file(s)`} />
                  {selectedQuery.query_config?.filters?.length > 0 && (
                    <Chip size="small" icon={<FilterIcon sx={{ fontSize: '0.75rem !important' }} />}
                      label={`${selectedQuery.query_config.filters.length} filter(s)`} />
                  )}
                  {selectedQuery.query_config?.limit && (
                    <Chip size="small" label={`limit ${selectedQuery.query_config.limit.toLocaleString()}`} />
                  )}
                </Box>

                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.25 }}>
                  <Typography variant="caption" color="text.secondary">
                    <strong>Files:</strong> {fmtFiles(selectedQuery.query_config)}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    <strong>Last run:</strong> {fmtDate(selectedQuery.last_executed_at)}
                  </Typography>
                </Box>
              </Paper>
            </Box>
          )}

          {/* ── Parameters section ── */}
          {selectedQuery && (
            <>
              <Divider />
              <Box sx={{ px: 2, pt: 1.5, pb: 0.5 }}>
                <Box
                  sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', mb: 1 }}
                  onClick={() => setShowParamSection(v => !v)}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                    <SettingsIcon fontSize="small" color="action" />
                    <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                      Parameters
                      {detectedParams.length > 0 && (
                        <Chip size="small" label={detectedParams.length} sx={{ ml: 0.75, height: 18, fontSize: 11 }} color="primary" />
                      )}
                    </Typography>
                  </Box>
                  <Typography variant="caption" color="text.secondary">
                    {showParamSection ? 'Hide' : 'Show'}
                  </Typography>
                </Box>

                <Collapse in={showParamSection}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, pb: 1.5 }}>

                    {/* Auto-detected params */}
                    {detectedParams.length > 0 && (
                      <Box>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontStyle: 'italic' }}>
                          Query filter parameters
                        </Typography>
                        {detectedParams.map(p => (
                          <TextField
                            key={p.name}
                            label={p.label}
                            helperText={`${p.column} ${p.operator}`}
                            placeholder={`Enter ${p.label}...`}
                            value={paramValues[p.name] || ''}
                            onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                            size="small"
                            fullWidth
                            required={p.required}
                            sx={{ mb: 1 }}
                          />
                        ))}
                      </Box>
                    )}

                    {/* Limit override */}
                    <TextField
                      label="Row Limit Override"
                      helperText={`Saved: ${selectedQuery.query_config?.limit?.toLocaleString() || 'none'}`}
                      placeholder="e.g. 5000"
                      type="number"
                      value={limitOverride}
                      onChange={e => setLimitOverride(e.target.value)}
                      size="small"
                      fullWidth
                      inputProps={{ min: 1 }}
                    />

                    {/* Ad-hoc filters */}
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.75 }}>
                        <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                          Ad-hoc filters (runtime only)
                        </Typography>
                        <Button
                          size="small"
                          startIcon={<AddIcon />}
                          onClick={() => setAdHocFilters(prev => [...prev, { column: '', operator: 'eq', value: '' }])}
                          sx={{ textTransform: 'none', fontSize: 11 }}
                          variant="outlined"
                        >
                          Add
                        </Button>
                      </Box>
                      {adHocFilters.map((f, i) => (
                        <Box key={i} sx={{ display: 'flex', gap: 0.5, mb: 0.75, alignItems: 'center' }}>
                          <TextField
                            size="small"
                            placeholder="Column"
                            value={f.column}
                            onChange={e => setAdHocFilters(prev => prev.map((x, idx) => idx === i ? { ...x, column: e.target.value } : x))}
                            sx={{ flex: 1 }}
                          />
                          <TextField
                            select size="small"
                            value={f.operator}
                            onChange={e => setAdHocFilters(prev => prev.map((x, idx) => idx === i ? { ...x, operator: e.target.value } : x))}
                            sx={{ width: 72 }}
                          >
                            {['eq','ne','gt','gte','lt','lte','contains','in'].map(op => (
                              <MenuItem key={op} value={op}>{op}</MenuItem>
                            ))}
                          </TextField>
                          <TextField
                            size="small"
                            placeholder="Value"
                            value={f.value}
                            onChange={e => setAdHocFilters(prev => prev.map((x, idx) => idx === i ? { ...x, value: e.target.value } : x))}
                            sx={{ flex: 1.2 }}
                          />
                          <IconButton size="small" color="error"
                            onClick={() => setAdHocFilters(prev => prev.filter((_, idx) => idx !== i))}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      ))}
                    </Box>
                  </Box>
                </Collapse>
              </Box>
            </>
          )}

          {/* ── Empty state ── */}
          {!selectedQuery && !queriesLoading && (
            <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', px: 2, py: 4, textAlign: 'center' }}>
              <ChartIcon sx={{ fontSize: '3rem', mb: 1.5, opacity: 0.25, color: 'text.secondary' }} />
              <Typography variant="body2" color="text.secondary">
                Search and select a saved query above.
              </Typography>
              {queries.length === 0 && (
                <Typography variant="caption" sx={{ color: 'text.disabled', mt: 1, fontStyle: 'italic' }}>
                  No saved queries yet. Build one in Query Builder.
                </Typography>
              )}
            </Box>
          )}
        </Box>

        {/* ── Run / Action buttons ── */}
        {selectedQuery && (
          <Box sx={{ px: 2, py: 2, borderTop: 1, borderColor: 'divider', display: 'flex', flexDirection: 'column', gap: 1 }}>
            {/* Execution status bar */}
            {executing && (
              <Paper variant="outlined" sx={{ p: 0, overflow: 'hidden', borderColor: 'primary.light' }}>
                <LinearProgress color="primary" />
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 1.5, py: 1 }}>
                  <CircularProgress size={16} />
                  <Typography variant="caption" sx={{ flex: 1, color: 'primary.dark', fontWeight: 500 }}>
                    {execStatus === 'pending' ? 'Starting...' : execStatus === 'processing' ? 'Processing data...' : 'Running...'}
                  </Typography>
                  <Button size="small" variant="text" color="error" startIcon={<CloseIcon fontSize="small" />}
                    onClick={handleCancel} sx={{ textTransform: 'none', fontSize: 12 }}>
                    Cancel
                  </Button>
                </Box>
              </Paper>
            )}

            <Button
              variant="contained"
              fullWidth
              size="large"
              startIcon={executing ? <CircularProgress size={18} color="inherit" /> : <PlayIcon />}
              onClick={handleRun}
              disabled={executing}
              sx={{ fontWeight: 700 }}
            >
              {executing ? 'Running...' : 'Run Report'}
            </Button>
            <Button
              variant="outlined"
              fullWidth
              startIcon={<EditIcon />}
              onClick={handleModify}
              sx={{ fontWeight: 500 }}
            >
              Modify in Builder
            </Button>
          </Box>
        )}
      </Box>

      {/* ── Panel collapse toggle ── */}
      <Box
        sx={{
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Tooltip title={panelOpen ? 'Collapse panel' : 'Expand panel'} placement="right">
          <IconButton
            size="small"
            onClick={() => setPanelOpen(v => !v)}
            sx={{
              position: 'absolute',
              left: -12,
              zIndex: 10,
              bgcolor: 'background.paper',
              border: 1,
              borderColor: 'divider',
              boxShadow: 1,
              '&:hover': { bgcolor: 'grey.100' },
              width: 24,
              height: 24,
            }}
          >
            {panelOpen ? <ChevronLeft sx={{ fontSize: 16 }} /> : <ChevronRight sx={{ fontSize: 16 }} />}
          </IconButton>
        </Tooltip>
      </Box>

      {/* ══ RIGHT RESULTS AREA ══════════════════════════════════════════════ */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Results toolbar / breadcrumb */}
        <Box sx={{
          display: 'flex',
          alignItems: 'center',
          px: 3,
          py: 1.5,
          borderBottom: 1,
          borderColor: 'divider',
          bgcolor: 'background.paper',
          gap: 2,
          minHeight: 56,
        }}>
          {selectedQuery ? (
            <>
              <Box sx={{ flex: 1 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 700, lineHeight: 1.2 }}>
                  {selectedQuery.name}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {fmtFiles(selectedQuery.query_config)}
                  {selectedQuery.query_config?.filters?.length > 0 && ` · ${selectedQuery.query_config.filters.length} filter(s)`}
                  {selectedQuery.query_config?.limit && ` · limit ${selectedQuery.query_config.limit.toLocaleString()}`}
                </Typography>
              </Box>
              {showResults && (
                <Chip
                  size="small"
                  label="Results loaded"
                  color="success"
                  variant="outlined"
                />
              )}
            </>
          ) : (
            <Typography variant="body2" color="text.secondary">
              Select a query from the left panel to get started
            </Typography>
          )}
        </Box>

        {/* Results / empty / error area */}
        <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {showResults && executionId ? (
            <DataGridViewer executionId={executionId} onClose={() => setShowResults(false)} />
          ) : (
            <Box sx={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 2,
              color: 'text.secondary',
              userSelect: 'none',
            }}>
              {executing ? (
                <>
                  <CircularProgress size={56} thickness={3} />
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>
                    {execStatus === 'pending' ? 'Starting execution...' : 'Processing data...'}
                  </Typography>
                  <Typography variant="body2" color="text.disabled">
                    Results will appear here when complete
                  </Typography>
                </>
              ) : execStatus === 'cancelled' ? (
                <>
                  <CloseIcon sx={{ fontSize: '3.5rem', opacity: 0.3 }} />
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>Execution cancelled</Typography>
                  <Button variant="outlined" startIcon={<PlayIcon />} onClick={handleRun} disabled={!selectedQuery}>
                    Run again
                  </Button>
                </>
              ) : (
                <>
                  <ChartIcon sx={{ fontSize: '5rem', opacity: 0.12 }} />
                  <Typography variant="h5" sx={{ fontWeight: 600, opacity: 0.5 }}>
                    {selectedQuery ? 'Run the report to see results' : 'No query selected'}
                  </Typography>
                  {selectedQuery && (
                    <Button
                      variant="contained"
                      size="large"
                      startIcon={<PlayIcon />}
                      onClick={handleRun}
                      sx={{ mt: 1, fontWeight: 700 }}
                    >
                      Run Report
                    </Button>
                  )}
                </>
              )}
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default ReportPage;
