import React, { useState, useEffect, useRef, useMemo, useCallback, memo } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Box, Typography, Button, Paper, IconButton, Tooltip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TableSortLabel,
  TextField, MenuItem, Select, Menu, ToggleButtonGroup, ToggleButton,
  CircularProgress, LinearProgress, Alert, Chip, Divider,
  FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions,
  Checkbox, InputAdornment,
} from '@mui/material';
import {
  Download as DownloadIcon, Close as CloseIcon, Refresh as RefreshIcon,
  FilterList as FilterIcon, TableChart as TableIcon, BarChart as ChartIcon,
  PivotTableChart as PivotIcon, FirstPage, LastPage, NavigateBefore, NavigateNext,
  InsertDriveFile as CsvIcon, TableView as ExcelIcon, DataObject as JsonIcon,
  Add as AddIcon, Delete as DeleteIcon,
  ViewColumn as ColumnsIcon, PushPin as PinIcon, Search as SearchIcon,
} from '@mui/icons-material';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';
const FROZEN_COL_WIDTH = 160;
const MAX_VIS_COLS = 50;   // keep DOM count manageable

// ─────────────────────────────────────────────────────────────
// Number formatting
// ─────────────────────────────────────────────────────────────
const SCIENTIFIC_RE = /^-?[\d.]+[eE][+-]?\d+$/;

const fmtNum = (v) => {
  if (v == null || (typeof v === 'number' && isNaN(v))) return '—';
  const num = typeof v === 'string' ? parseFloat(v) : v;
  if (isNaN(num)) return String(v);
  const isNeg = num < 0;
  const abs   = Math.abs(num);
  const fmt   = Number.isInteger(abs) && abs < 1e15
    ? abs.toLocaleString()
    : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return isNeg ? `(${fmt})` : fmt;
};

// Pre-defined style objects (defined ONCE outside the component) so that
// formatValue never allocates new objects on the hot render path.
const _S = {
  null: { color: '#9e9e9e', fontStyle: 'italic', fontSize: 11, letterSpacing: '0.02em' },
  boolT: { color: '#2e7d32', fontWeight: 700, fontSize: 11 },
  boolF: { color: '#757575', fontWeight: 600, fontSize: 11 },
  neg:   { color: '#d32f2f', fontVariantNumeric: 'tabular-nums' },
  pos:   { fontVariantNumeric: 'tabular-nums' },
};

// Pure function — no React hooks, no MUI components — safe to call inside a
// tight map() on every cell without React overhead per invocation.
const formatValue = (value) => {
  if (value === null || value === undefined)
    return <span style={_S.null}>NULL</span>;
  if (typeof value === 'boolean')
    return <span style={value ? _S.boolT : _S.boolF}>{value ? 'TRUE' : 'FALSE'}</span>;

  let numVal = typeof value === 'number' ? value : null;
  if (numVal === null && typeof value === 'string' && SCIENTIFIC_RE.test(value.trim())) {
    const p = parseFloat(value.trim());
    if (!isNaN(p)) numVal = p;
  }
  if (numVal !== null) {
    const isNeg = numVal < 0;
    const abs   = Math.abs(numVal);
    const fmt   = Number.isInteger(abs) && abs < 1e15
      ? abs.toLocaleString()
      : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
    if (isNeg)
      return <span style={_S.neg}>({fmt})</span>;
    return <span style={_S.pos}>{fmt}</span>;
  }
  return value.toString();
};

// ─────────────────────────────────────────────────────────────
// Advanced AND/OR Filter Builder
// ─────────────────────────────────────────────────────────────
const OPERATORS = [
  { value: 'contains',     label: 'Contains' },
  { value: 'not_contains', label: 'Does not contain' },
  { value: 'equals',       label: 'Equals' },
  { value: 'not_equals',   label: 'Not equals' },
  { value: 'starts_with',  label: 'Starts with' },
  { value: 'ends_with',    label: 'Ends with' },
  { value: 'gt',           label: '>' },
  { value: 'gte',          label: '>=' },
  { value: 'lt',           label: '<' },
  { value: 'lte',          label: '<=' },
  { value: 'is_null',      label: 'Is null' },
  { value: 'is_not_null',  label: 'Is not null' },
];

const NO_VALUE_OPS = new Set(['is_null', 'is_not_null']);

const FilterBuilder = ({ columns, value, onChange }) => {
  const { conjunction = 'AND', conditions = [] } = value || {};

  const setConjunction = (c) => onChange({ conjunction: c, conditions });

  const setCondition = (idx, patch) => {
    const next = conditions.map((c, i) => i === idx ? { ...c, ...patch } : c);
    onChange({ conjunction, conditions: next });
  };

  const addCondition = () => onChange({
    conjunction,
    conditions: [...conditions, { col: columns[0] || '', op: 'contains', val: '' }],
  });

  const removeCondition = (idx) => {
    const next = conditions.filter((_, i) => i !== idx);
    onChange({ conjunction, conditions: next });
  };

  return (
    <Box sx={{ px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
        <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mr: 0.5 }}>
          FILTER
        </Typography>
        <ToggleButtonGroup
          value={conjunction} exclusive
          onChange={(_, v) => v && setConjunction(v)}
          size="small"
          sx={{ '& .MuiToggleButton-root': { px: 1.5, py: 0.25, fontSize: 12, fontWeight: 700, minWidth: 44 } }}
        >
          <ToggleButton value="AND">AND</ToggleButton>
          <ToggleButton value="OR">OR</ToggleButton>
        </ToggleButtonGroup>
        <Button size="small" startIcon={<AddIcon sx={{ fontSize: 14 }} />} onClick={addCondition}
          sx={{ fontSize: 12, textTransform: 'none' }}>
          Add condition
        </Button>
        {conditions.length > 0 && (
          <Button size="small" color="error" sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}
            onClick={() => onChange({ conjunction, conditions: [] })}>
            Clear all
          </Button>
        )}
      </Box>

      {conditions.length === 0 && (
        <Typography variant="caption" color="text.disabled" sx={{ pl: 0.5 }}>
          No filters — showing all rows
        </Typography>
      )}

      {conditions.map((cond, idx) => (
        <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.75, flexWrap: 'wrap' }}>
          {idx > 0 && (
            <Chip label={conjunction} size="small" variant="outlined" color="primary"
              sx={{ height: 22, fontSize: 11, fontWeight: 700, minWidth: 36 }} />
          )}
          {idx === 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ minWidth: 36, textAlign: 'center' }}>
              WHERE
            </Typography>
          )}

          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select value={cond.col} onChange={e => setCondition(idx, { col: e.target.value })}
              sx={{ fontSize: 13 }}>
              {columns.map(c => <MenuItem key={c} value={c} sx={{ fontSize: 13 }}>{c}</MenuItem>)}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 160 }}>
            <Select value={cond.op} onChange={e => setCondition(idx, { op: e.target.value })}
              sx={{ fontSize: 13 }}>
              {OPERATORS.map(o => <MenuItem key={o.value} value={o.value} sx={{ fontSize: 13 }}>{o.label}</MenuItem>)}
            </Select>
          </FormControl>

          {!NO_VALUE_OPS.has(cond.op) && (
            <TextField
              size="small" placeholder="value…" value={cond.val}
              onChange={e => setCondition(idx, { val: e.target.value })}
              onKeyDown={e => e.key === 'Enter' && e.currentTarget.blur()}
              sx={{ minWidth: 160, '& input': { fontSize: 13 } }}
            />
          )}

          <Tooltip title="Remove condition">
            <IconButton size="small" onClick={() => removeCondition(idx)} sx={{ color: 'text.disabled' }}>
              <DeleteIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>
      ))}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// ChartConfig sidebar
// ─────────────────────────────────────────────────────────────
const ChartConfig = ({
  cols, chartType, setChartType, xCol, setXCol, yCol, setYCol,
  agg, setAgg, topN, setTopN, onRefresh, xLabel, yLabel, renderLabel, hideChartType,
}) => (
  <Box sx={{ width: 220, flexShrink: 0, p: 2, borderRight: 1, borderColor: 'divider', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
    {!hideChartType && (
      <TextField select label="Chart type" size="small" value={chartType} onChange={e => setChartType(e.target.value)}>
        {['bar', 'line', 'pie', 'area', 'scatter'].map(t => <MenuItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</MenuItem>)}
      </TextField>
    )}
    <TextField select label={xLabel || 'X-axis / Group By'} size="small" value={xCol} onChange={e => setXCol(e.target.value)}>
      {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
    </TextField>
    <TextField select label={yLabel || 'Y-axis / Value'} size="small" value={yCol} onChange={e => setYCol(e.target.value)}>
      {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
    </TextField>
    <TextField select label="Aggregation" size="small" value={agg} onChange={e => setAgg(e.target.value)}>
      {['sum','avg','count','max','min'].map(a => <MenuItem key={a} value={a}>{a.toUpperCase()}</MenuItem>)}
    </TextField>
    <TextField select label="Top N" size="small" value={topN} onChange={e => setTopN(+e.target.value)}>
      {[10,20,50,100,200].map(n => <MenuItem key={n} value={n}>Top {n}</MenuItem>)}
    </TextField>
    <Button variant="contained" size="small" onClick={onRefresh}>{renderLabel || 'Render'}</Button>
  </Box>
);

// ─────────────────────────────────────────────────────────────
// ChartRenderer
// ─────────────────────────────────────────────────────────────
const ChartRenderer = ({ data, type }) => {
  if (!data?.data?.length)
    return <Typography color="text.secondary">No data to display</Typography>;

  const items  = data.data.slice(0, 30);
  const maxVal = Math.max(...items.map(d => d.value || 0));
  const colors = ['#00AEEF','#0089BD','#36C5F0','#2EB67D','#ECB22E','#E01E5A','#611f69','#9b59b6'];

  if (type === 'pie') {
    const total = items.reduce((s, d) => s + (d.value || 0), 0);
    let cumAngle = -90;
    const cx = 140, cy = 120, r = 100;
    const slices = items.map((d, i) => {
      const angle = total > 0 ? (d.value / total) * 360 : 0;
      const start = cumAngle; cumAngle += angle;
      const r1 = (start * Math.PI) / 180, r2 = ((start + angle) * Math.PI) / 180;
      const x1 = cx + r * Math.cos(r1), y1 = cy + r * Math.sin(r1);
      const x2 = cx + r * Math.cos(r2), y2 = cy + r * Math.sin(r2);
      const large = angle > 180 ? 1 : 0;
      return { d: `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`, color: colors[i % colors.length], label: d.label, pct: d.pct };
    });
    return (
      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 3, p: 2, flexWrap: 'wrap' }}>
        <svg width={280} height={240}>
          {slices.map((s, i) => <path key={i} d={s.d} fill={s.color} stroke="#fff" strokeWidth={1.5} />)}
        </svg>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxHeight: 240, overflow: 'auto' }}>
          {slices.map((s, i) => (
            <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: s.color, flexShrink: 0 }} />
              <Typography variant="caption" noWrap sx={{ maxWidth: 200 }}>{s.label}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', pl: 1 }}>{s.pct}%</Typography>
            </Box>
          ))}
        </Box>
      </Box>
    );
  }

  return (
    <Box sx={{ width: '100%', overflow: 'auto', p: 2 }}>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, minWidth: 300 }}>
        {items.map((d, i) => (
          <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="caption" noWrap sx={{ width: 140, flexShrink: 0, textAlign: 'right', pr: 1 }} title={d.label}>{d.label}</Typography>
            <Box sx={{ flex: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Box sx={{ height: 20, borderRadius: 1, bgcolor: colors[i % colors.length], width: maxVal > 0 ? `${Math.max(2, (d.value / maxVal) * 100)}%` : '2%', transition: 'width 0.3s' }} />
              <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap', fontSize: 11 }}>
                {fmtNum(d.value)} ({d.pct}%)
              </Typography>
            </Box>
          </Box>
        ))}
      </Box>
      <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
        {data.groups} groups · {Number(data.total_rows).toLocaleString()} rows · Grand total: {fmtNum(data.grand_total)}
      </Typography>
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// VirtualRow — memoized so unchanged rows skip re-render on scroll
// ─────────────────────────────────────────────────────────────
const VirtualRow = memo(function VirtualRow({
  virtualRow, row, rowBg, startRow, tableCols, pinnedIdxMap, pinnedVisible, refreshing, measureRef,
}) {
  const idx = virtualRow.index;
  return (
    <TableRow
      key={virtualRow.key}
      data-index={idx}
      ref={measureRef}
      hover
      sx={{ opacity: refreshing ? 0.6 : 1, transition: 'opacity 0.15s' }}
    >
      {/* Row number cell */}
      <TableCell sx={{
        color: 'text.secondary', textAlign: 'center', fontVariantNumeric: 'tabular-nums',
        ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 2, bgcolor: rowBg, boxShadow: 'inset -1px 0 0 #e2e8f0' } : {}),
      }}>
        {startRow + idx}
      </TableCell>

      {tableCols.map((col) => {
        const pi = pinnedIdxMap.get(col);
        const isPinned = pi !== undefined;
        const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
        return (
          <TableCell key={col} sx={{
            whiteSpace: 'nowrap',
            maxWidth: isPinned ? FROZEN_COL_WIDTH : 300,
            overflow: 'hidden', textOverflow: 'ellipsis',
            ...(isPinned ? {
              position: 'sticky',
              left: 56 + pi * FROZEN_COL_WIDTH,
              zIndex: 2,
              bgcolor: rowBg,
              minWidth: FROZEN_COL_WIDTH,
              ...(isLastPinned
                ? { boxShadow: '3px 0 6px rgba(0,0,0,0.12)' }
                : { boxShadow: 'inset -1px 0 0 #e2e8f0' }),
            } : {}),
          }}>
            {formatValue(row[col])}
          </TableCell>
        );
      })}
    </TableRow>
  );
});

// ─────────────────────────────────────────────────────────────
// DataGridViewer
// ─────────────────────────────────────────────────────────────
const DataGridViewer = ({
  executionId,
  fileId,
  filePath,
  connectionId,
  embedded = false,
  title,
  onClose,
}) => {
  const sourceType = executionId ? 'execution' : fileId ? 'fileId' : filePath ? 'filePath' : null;

  const buildDataUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/results?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/preview?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/data?${params}`;
    }
    return null;
  };

  const buildChartUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/chart-data?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/chart-data?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/chart-data?${params}`;
    }
    return null;
  };

  // ── Table state ──────────────────────────────────────────
  const [data,       setData]       = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error,      setError]      = useState(null);
  const [page,       setPage]       = useState(1);
  const [pageSize,   setPageSize]   = useState(100);
  const [totalRows,  setTotalRows]  = useState(0);
  const [sortColumn,    setSortColumn]    = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');

  // ── Column visibility & pinning ──────────────────────────
  // pinnedCols: array of col names (in pin order, left-to-right)
  // visibleCols: null = all visible, Set<string> = explicit visible subset
  const [pinnedCols,   setPinnedCols]   = useState([]);
  const [visibleCols,  setVisibleCols]  = useState(null);
  const [showColPanel, setShowColPanel] = useState(false);
  const [colSearch,    setColSearch]    = useState('');

  // ── Filters ──────────────────────────────────────────────
  const [showFilters,   setShowFilters]   = useState(false);
  const [advFilter,     setAdvFilter]     = useState({ conjunction: 'AND', conditions: [] });
  const [appliedFilter, setAppliedFilter] = useState(null);

  // ── View ─────────────────────────────────────────────────
  const [viewMode,       setViewMode]       = useState('table');
  const [exportMsg,      setExportMsg]      = useState(null);
  const [exportAnchorEl, setExportAnchorEl] = useState(null);

  // ── Chart / Pivot ─────────────────────────────────────────
  const [chartType,    setChartType]    = useState('bar');
  const [chartXCol,    setChartXCol]    = useState('');
  const [chartYCol,    setChartYCol]    = useState('');
  const [chartAgg,     setChartAgg]     = useState('sum');
  const [chartTopN,    setChartTopN]    = useState(20);
  const [chartData,    setChartData]    = useState(null);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartError,   setChartError]   = useState(null);

  const abortRef         = useRef(null);
  const hasDataRef       = useRef(false);  // true after first successful load for current source
  const colsInitRef      = useRef(false);  // true after auto-col-init for current source
  const tableContainerRef = useRef(null);  // scrolling container for row virtualizer

  // ── Reset on source change ───────────────────────────────
  useEffect(() => {
    hasDataRef.current  = false;
    colsInitRef.current = false;
    setData(null); setError(null); setPage(1);
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setSortColumn(null); setChartData(null);
    setViewMode('table'); setLoading(true); setRefreshing(false);
    setPinnedCols([]); setVisibleCols(null); setColSearch('');
    setChartXCol(''); setChartYCol('');
  }, [executionId, fileId, filePath, connectionId]); // eslint-disable-line

  // ── Auto-init columns on first data load ─────────────────
  useEffect(() => {
    if (!data?.columns || colsInitRef.current) return;
    colsInitRef.current = true;
    const c = data.columns;

    // Limit visible cols for wide datasets
    if (c.length > MAX_VIS_COLS) {
      setVisibleCols(new Set(c.slice(0, MAX_VIS_COLS)));
    }

    // Auto-pick chart columns
    if (!chartXCol) {
      const firstRow = data.rows?.[0] || {};
      const textCols = c.filter(col => typeof firstRow[col] === 'string');
      const numCols  = c.filter(col => typeof firstRow[col] === 'number');
      setChartXCol(textCols[0] || c[0]);
      setChartYCol(numCols[0]  || c[1] || c[0]);
    }
  }, [data]); // eslint-disable-line

  // ── Load page ─────────────────────────────────────────────
  // Inlined (no useCallback) so the closure captures fresh prop values.
  useEffect(() => {
    if (!sourceType) return;

    if (abortRef.current) abortRef.current.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    if (hasDataRef.current) setRefreshing(true);
    else setLoading(true);

    const run = async () => {
      let aborted = false;
      try {
        const params = new URLSearchParams({ page, page_size: pageSize });
        if (sortColumn) {
          params.append('sort_column', sortColumn);
          params.append('sort_direction', sortDirection);
        }
        if (appliedFilter?.conditions?.length)
          params.append('adv_filters', JSON.stringify(appliedFilter));

        const url = buildDataUrl(params);
        if (!url) throw new Error('No data source configured');

        const res = await fetch(url, { signal: ac.signal });
        if (!res.ok) {
          const detail = await res.json().catch(() => ({}));
          throw new Error(detail?.detail || `HTTP ${res.status}`);
        }
        const result = await res.json();
        setData(result);
        setTotalRows(result.total_rows);
        hasDataRef.current = true;
        setError(null);
      } catch (err) {
        if (err.name === 'AbortError') { aborted = true; return; }
        setError(err.message);
      } finally {
        // Only update loading state if the request was NOT aborted.
        // If aborted, the replacement request manages its own loading state.
        if (!aborted) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    };

    run();
    return () => { ac.abort(); };
  }, [executionId, fileId, filePath, connectionId, page, pageSize, sortColumn, sortDirection, appliedFilter]); // eslint-disable-line

  // ── Derive cols/rows early — useCallback below depends on `cols` ─────────
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const cols = useMemo(() => data?.columns || [], [data]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const rows = useMemo(() => data?.rows    || [], [data]);

  // ── Filter helpers ────────────────────────────────────────
  const handleApplyFilters = useCallback(() => {
    setAppliedFilter({ ...advFilter });
    setPage(1);
  }, [advFilter]);

  const handleClearFilters = useCallback(() => {
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setPage(1);
  }, []);

  // ── View helpers ──────────────────────────────────────────
  const handleViewModeChange = useCallback((_, val) => {
    if (!val) return;
    setViewMode(val);
    if (val === 'chart' || val === 'pivot') setChartData(null);
  }, []);

  const handleSort = useCallback((col) => {
    if (sortColumn === col) setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortColumn(col); setSortDirection('asc'); }
    setPage(1);
  }, [sortColumn]);

  // ── Column visibility helpers ─────────────────────────────
  const toggleColVisibility = useCallback((col, checked) => {
    setVisibleCols(prev => {
      const next = prev === null ? new Set(cols) : new Set(prev);
      if (checked) next.add(col);
      else next.delete(col);
      return next.size === cols.length ? null : next;
    });
  }, [cols]);

  const togglePinCol = useCallback((col) => {
    setPinnedCols(prev =>
      prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]
    );
  }, []);

  // ── Chart loader ──────────────────────────────────────────
  const loadChartData = async () => {
    if (!chartXCol || !chartYCol) return;
    setChartLoading(true); setChartError(null);
    try {
      const params = new URLSearchParams({ x_col: chartXCol, y_col: chartYCol, agg: chartAgg, top_n: chartTopN });
      const url = buildChartUrl(params);
      if (!url) throw new Error('Chart data not available for this source');
      const res = await fetch(url);
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || `HTTP ${res.status}`); }
      setChartData(await res.json());
    } catch (err) {
      setChartError(err.message);
    } finally {
      setChartLoading(false);
    }
  };

  // ── Export helpers ────────────────────────────────────────
  const exportBackground = async (format) => {
    setExportAnchorEl(null);
    setExportMsg(`Starting ${format.toUpperCase()} export…`);
    try {
      const res = await fetch(`${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const result = await res.json();
      setExportMsg(result.message);
      setTimeout(() => setExportMsg(null), 6000);
    } catch (err) {
      setExportMsg(`Export failed: ${err.message}`);
      setTimeout(() => setExportMsg(null), 5000);
    }
  };
  const downloadFile = () => window.open(`${API_BASE_URL}/api/downloads/${fileId}/download`, '_blank');

  // ── Derived values ────────────────────────────────────────
  const totalPages = Math.max(1, Math.ceil((data?.filtered_rows ?? totalRows) / pageSize));
  const startRow   = (page - 1) * pageSize + 1;
  const endRow     = Math.min(page * pageSize, data?.filtered_rows ?? totalRows);
  const activeFilters = appliedFilter?.conditions?.length || 0;

  // Memoize every derived column array so they are stable between renders
  // that don't change col/visibility/pin state (e.g. scroll, pagination).
  const displayCols = useMemo(
    () => visibleCols === null ? cols : cols.filter(c => visibleCols.has(c)),
    [cols, visibleCols],
  );
  const pinnedVisible = useMemo(
    () => pinnedCols.filter(c => displayCols.includes(c)),
    [pinnedCols, displayCols],
  );
  const pinnedSet = useMemo(() => new Set(pinnedVisible), [pinnedVisible]);
  const nonPinnedVis = useMemo(
    () => displayCols.filter(c => !pinnedSet.has(c)),
    [displayCols, pinnedSet],
  );
  const tableCols = useMemo(
    () => [...pinnedVisible, ...nonPinnedVis],
    [pinnedVisible, nonPinnedVis],
  );
  // Map from col name → pin index for O(1) lookup during render
  const pinnedIdxMap = useMemo(
    () => new Map(pinnedVisible.map((c, i) => [c, i])),
    [pinnedVisible],
  );

  // Column picker search
  const colSearchLower = colSearch.toLowerCase();
  const filteredColList = useMemo(
    () => colSearchLower ? cols.filter(c => c.toLowerCase().includes(colSearchLower)) : cols,
    [cols, colSearchLower],
  );

  const headerTitle = title || (
    sourceType === 'execution' ? 'Query Results' :
    sourceType === 'fileId'   ? (data?.filename || 'File Preview') :
    sourceType === 'filePath' ? (data?.filename || filePath?.split('/').pop() || 'File Preview') :
    'Preview'
  );

  // ── Row virtualizer (renders only visible rows for large pages) ─
  // Hook must be called before any early returns (React rules of hooks).
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 33,  // MUI Table size="small" row ~33px
    overscan: 15,
  });
  const virtualRows       = rowVirtualizer.getVirtualItems();
  const totalVirtualHeight = rowVirtualizer.getTotalSize();
  const vPaddingTop    = virtualRows.length > 0 ? (virtualRows[0]?.start ?? 0) : 0;
  const vPaddingBottom = virtualRows.length > 0
    ? totalVirtualHeight - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0;

  // ── Initial load spinner ──────────────────────────────────
  if (loading && !data) {
    const Wrap = embedded ? Box : Paper;
    return (
      <Wrap sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 200, ...(embedded ? {} : { p: 4 }) }}>
        <CircularProgress size={48} sx={{ mb: 2 }} />
        <Typography color="text.secondary">Loading…</Typography>
      </Wrap>
    );
  }

  if (error && !data) {
    const Wrap = embedded ? Box : Paper;
    return (
      <Wrap sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 200, ...(embedded ? {} : { p: 4 }) }}>
        <Alert severity="error" sx={{ mb: 2, width: '100%', maxWidth: 520 }}>
          <Typography variant="subtitle2" fontWeight="bold">Preview Error</Typography>
          <Typography variant="body2">{error}</Typography>
        </Alert>
        {!embedded && <Button variant="outlined" onClick={onClose}>Close</Button>}
      </Wrap>
    );
  }

  const Wrapper = embedded ? Box : Paper;

  return (
    <Wrapper sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* ── Header (non-embedded only) ───────────────────── */}
      {!embedded && (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider' }}>
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1.5 }}>
            <Typography variant="h6">{headerTitle}</Typography>
            <Typography variant="body2" color="text.secondary">
              {refreshing ? 'Refreshing…' : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${totalRows.toLocaleString()} rows`}
            </Typography>
          </Box>
          {onClose && (
            <Tooltip title="Close"><IconButton onClick={onClose} size="small"><CloseIcon /></IconButton></Tooltip>
          )}
        </Box>
      )}

      {exportMsg && (
        <Alert severity={exportMsg.includes('failed') ? 'error' : exportMsg.includes('Starting') ? 'info' : 'success'}
          sx={{ borderRadius: 0 }} onClose={() => setExportMsg(null)}>
          {exportMsg}
        </Alert>
      )}

      {/* ── Toolbar ──────────────────────────────────────── */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderBottom: 1, borderColor: 'divider', flexWrap: 'wrap', gap: 1, flexShrink: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {embedded && (
            <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
              {refreshing ? (
                <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.75 }}>
                  <CircularProgress size={12} /> Updating…
                </Box>
              ) : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${(data?.filtered_rows ?? totalRows).toLocaleString()} rows`}
              {activeFilters > 0 && (
                <Chip label={`${activeFilters} filter${activeFilters > 1 ? 's' : ''}`} size="small" color="primary"
                  variant="outlined" sx={{ ml: 1, height: 18, fontSize: 11 }} onDelete={handleClearFilters} />
              )}
            </Typography>
          )}

          <ToggleButtonGroup value={viewMode} exclusive onChange={handleViewModeChange} size="small">
            <ToggleButton value="table"><Tooltip title="Table"><TableIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Table</ToggleButton>
            <ToggleButton value="chart"><Tooltip title="Chart"><ChartIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Chart</ToggleButton>
            <ToggleButton value="pivot"><Tooltip title="Pivot"><PivotIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Pivot</ToggleButton>
          </ToggleButtonGroup>

          {viewMode === 'table' && (
            <Button
              variant={showFilters ? 'contained' : 'outlined'}
              size="small" startIcon={<FilterIcon />}
              onClick={() => setShowFilters(v => !v)}
              color={activeFilters > 0 ? 'primary' : 'inherit'}
            >
              Filters{activeFilters > 0 ? ` (${activeFilters})` : ''}
            </Button>
          )}

          {viewMode === 'table' && cols.length > 0 && (
            <Button
              variant="outlined"
              size="small"
              startIcon={<ColumnsIcon />}
              onClick={() => setShowColPanel(true)}
              color={pinnedCols.length > 0 || visibleCols !== null ? 'primary' : 'inherit'}
            >
              Columns ({displayCols.length}{displayCols.length !== cols.length ? `/${cols.length}` : ''})
              {pinnedCols.length > 0 && ` · ${pinnedCols.length} pinned`}
            </Button>
          )}
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TextField select size="small" value={pageSize} onChange={e => { setPageSize(+e.target.value); setPage(1); }} sx={{ minWidth: 110 }}>
            {[50, 100, 250, 500, 1000].map(n => <MenuItem key={n} value={n}>{n} rows</MenuItem>)}
          </TextField>

          {sourceType === 'execution' && (
            <>
              <Button variant="outlined" size="small" startIcon={<DownloadIcon />}
                onClick={e => setExportAnchorEl(e.currentTarget)}>Export</Button>
              <Menu anchorEl={exportAnchorEl} open={Boolean(exportAnchorEl)} onClose={() => setExportAnchorEl(null)}>
                <MenuItem onClick={() => exportBackground('csv')}><CsvIcon sx={{ mr: 1, fontSize: 20 }} />CSV</MenuItem>
                <MenuItem onClick={() => exportBackground('excel')}><ExcelIcon sx={{ mr: 1, fontSize: 20 }} />Excel</MenuItem>
                <MenuItem onClick={() => exportBackground('json')}><JsonIcon sx={{ mr: 1, fontSize: 20 }} />JSON</MenuItem>
              </Menu>
            </>
          )}
          {sourceType === 'fileId' && (
            <Button variant="outlined" size="small" startIcon={<DownloadIcon />} onClick={downloadFile}>Download</Button>
          )}
        </Box>
      </Box>

      {/* ── TABLE VIEW ───────────────────────────────────── */}
      {viewMode === 'table' && (
        <>
          {showFilters && (
            <>
              <FilterBuilder columns={displayCols} value={advFilter} onChange={setAdvFilter} />
              <Box sx={{ display: 'flex', gap: 1, px: 2, py: 1, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50', flexShrink: 0 }}>
                <Button
                  size="small" variant="contained" onClick={handleApplyFilters}
                  disabled={advFilter.conditions.length === 0}
                  sx={{ fontSize: 12, textTransform: 'none' }}
                >
                  Apply Filters
                </Button>
                {activeFilters > 0 && (
                  <Button size="small" variant="outlined" onClick={handleClearFilters}
                    sx={{ fontSize: 12, textTransform: 'none' }}>
                    Clear Applied
                  </Button>
                )}
              </Box>
            </>
          )}

          {refreshing && <LinearProgress sx={{ height: 2 }} />}

          <TableContainer ref={tableContainerRef} sx={{ flex: 1, overflow: 'auto', position: 'relative' }}>
            {refreshing && (
              <Box sx={{
                position: 'absolute', inset: 0, zIndex: 10,
                bgcolor: 'rgba(255,255,255,0.55)', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-end', p: 1,
                pointerEvents: 'none',
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, bgcolor: 'background.paper',
                  border: 1, borderColor: 'divider', borderRadius: 1, px: 1.5, py: 0.5, boxShadow: 1 }}>
                  <CircularProgress size={14} />
                  <Typography variant="caption" color="text.secondary">Loading page {page}…</Typography>
                </Box>
              </Box>
            )}

            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {/* Row number header */}
                  <TableCell sx={{
                    fontWeight: 'bold', bgcolor: 'grey.100', width: 56, textAlign: 'center',
                    ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 5, boxShadow: 'inset -1px 0 0 #e2e8f0' } : {}),
                  }}>
                    #
                  </TableCell>

                  {tableCols.map((col) => {
                    const pi = pinnedIdxMap.get(col);
                    const isPinned = pi !== undefined;
                    const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
                    return (
                      <TableCell key={col}
                        sortDirection={sortColumn === col ? sortDirection : false}
                        sx={{
                          fontWeight: 'bold', bgcolor: 'grey.100', whiteSpace: 'nowrap',
                          // Show the pin button on hover of this header cell
                          '&:hover .col-pin-btn': { opacity: 1 },
                          ...(isPinned ? {
                            position: 'sticky',
                            left: 56 + pi * FROZEN_COL_WIDTH,
                            zIndex: 4,
                            minWidth: FROZEN_COL_WIDTH,
                            ...(isLastPinned
                              ? { boxShadow: '3px 0 6px rgba(0,0,0,0.12)' }
                              : { boxShadow: 'inset -1px 0 0 #e2e8f0' }),
                          } : {}),
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
                          <TableSortLabel
                            active={sortColumn === col}
                            direction={sortColumn === col ? sortDirection : 'asc'}
                            onClick={() => handleSort(col)}
                          >
                            {col}
                          </TableSortLabel>
                          {/* Pin / freeze icon — always visible when pinned, hover-only otherwise */}
                          <Tooltip title={isPinned ? 'Unfreeze column' : 'Freeze column (pin left)'} placement="top">
                            <IconButton
                              className="col-pin-btn"
                              size="small"
                              onClick={(e) => { e.stopPropagation(); togglePinCol(col); }}
                              sx={{
                                p: 0.25,
                                opacity: isPinned ? 1 : 0,
                                transition: 'opacity 0.15s',
                                color: isPinned ? 'primary.main' : 'text.secondary',
                                '&:hover': { bgcolor: 'action.hover' },
                              }}
                            >
                              <PinIcon sx={{ fontSize: 12, transform: isPinned ? 'none' : 'rotate(45deg)' }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              </TableHead>

              <TableBody>
                {/* Top spacer — keeps scroll thumb positioned correctly */}
                {vPaddingTop > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingTop, p: 0, border: 0 }} /></TableRow>
                )}

                {virtualRows.map((virtualRow) => {
                  const idx  = virtualRow.index;
                  const row  = rows[idx];
                  const rowBg = idx % 2 === 0 ? 'grey.50' : 'background.paper';
                  return (
                    <VirtualRow
                      key={virtualRow.key}
                      virtualRow={virtualRow}
                      row={row}
                      rowBg={rowBg}
                      startRow={startRow}
                      tableCols={tableCols}
                      pinnedIdxMap={pinnedIdxMap}
                      pinnedVisible={pinnedVisible}
                      refreshing={refreshing}
                      measureRef={rowVirtualizer.measureElement}
                    />
                  );
                })}

                {/* Bottom spacer */}
                {vPaddingBottom > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingBottom, p: 0, border: 0 }} /></TableRow>
                )}

                {/* Empty state — only show when NOT loading or refreshing */}
                {rows.length === 0 && !loading && !refreshing && (
                  <TableRow>
                    <TableCell colSpan={tableCols.length + 1} sx={{ textAlign: 'center', py: 6, color: 'text.disabled' }}>
                      No rows match the current filters
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination */}
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderTop: 1, borderColor: 'divider', flexShrink: 0 }}>
            <Typography variant="body2" color="text.secondary">
              {(data?.filtered_rows ?? totalRows).toLocaleString()} row{(data?.filtered_rows ?? totalRows) !== 1 ? 's' : ''}
              {activeFilters > 0 && totalRows !== (data?.filtered_rows ?? totalRows)
                ? ` (filtered from ${totalRows.toLocaleString()})`
                : ''}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Tooltip title="First page">
                <span><IconButton size="small" onClick={() => setPage(1)} disabled={page === 1 || refreshing}><FirstPage /></IconButton></span>
              </Tooltip>
              <Tooltip title="Previous page">
                <span><IconButton size="small" onClick={() => setPage(p => p - 1)} disabled={page === 1 || refreshing}><NavigateBefore /></IconButton></span>
              </Tooltip>
              <Typography variant="body2" sx={{ mx: 1, minWidth: 80, textAlign: 'center', display: 'flex', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                {refreshing && <CircularProgress size={12} />}
                Page {page} / {totalPages}
              </Typography>
              <Tooltip title="Next page">
                <span><IconButton size="small" onClick={() => setPage(p => p + 1)} disabled={page >= totalPages || refreshing}><NavigateNext /></IconButton></span>
              </Tooltip>
              <Tooltip title="Last page">
                <span><IconButton size="small" onClick={() => setPage(totalPages)} disabled={page >= totalPages || refreshing}><LastPage /></IconButton></span>
              </Tooltip>
            </Box>
          </Box>
        </>
      )}

      {/* ── CHART VIEW ───────────────────────────────────── */}
      {viewMode === 'chart' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <ChartConfig cols={displayCols} chartType={chartType} setChartType={setChartType}
            xCol={chartXCol} setXCol={setChartXCol} yCol={chartYCol} setYCol={setChartYCol}
            agg={chartAgg} setAgg={setChartAgg} topN={chartTopN} setTopN={setChartTopN}
            onRefresh={loadChartData} renderLabel="Render Chart" />
          <Box sx={{ flex: 1, overflow: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 2 }}>
            {chartLoading && <Box sx={{ textAlign: 'center' }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Aggregating {totalRows.toLocaleString()} rows…</Typography></Box>}
            {chartError && <Alert severity="error" sx={{ width: '100%' }}>{chartError}</Alert>}
            {!chartLoading && !chartError && chartData && <ChartRenderer data={chartData} type={chartType} />}
            {!chartLoading && !chartError && !chartData && (
              <Box sx={{ textAlign: 'center' }}>
                <ChartIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                <Typography variant="body1" color="text.secondary">Configure settings on the left, then click <strong>Render Chart</strong></Typography>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── PIVOT VIEW ───────────────────────────────────── */}
      {viewMode === 'pivot' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <ChartConfig cols={displayCols} hideChartType
            xCol={chartXCol} setXCol={setChartXCol} yCol={chartYCol} setYCol={setChartYCol}
            agg={chartAgg} setAgg={setChartAgg} topN={chartTopN} setTopN={setChartTopN}
            onRefresh={loadChartData} xLabel="Group By (Row)" yLabel="Value Column" renderLabel="Render Pivot" />
          <Box sx={{ flex: 1, overflow: 'auto', p: 2 }}>
            {chartLoading && <Box sx={{ textAlign: 'center', mt: 4 }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Aggregating…</Typography></Box>}
            {chartError && <Alert severity="error">{chartError}</Alert>}
            {!chartLoading && !chartError && chartData && (
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  {chartData.agg.toUpperCase()} of <strong>{chartData.y_col}</strong> by <strong>{chartData.x_col}</strong> — {chartData.groups} groups
                </Typography>
                <Table size="small" sx={{ width: 'auto' }}>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100' }}>{chartData.x_col}</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>{chartData.agg.toUpperCase()}({chartData.y_col})</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>Count</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>%</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {chartData.data.map((row, i) => (
                      <TableRow key={i} hover>
                        <TableCell>{row.label}</TableCell>
                        <TableCell sx={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                          {row.value != null ? (row.value < 0 ? <span style={{ color: '#d32f2f' }}>({fmtNum(-row.value)})</span> : fmtNum(row.value)) : '—'}
                        </TableCell>
                        <TableCell sx={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{row.count.toLocaleString()}</TableCell>
                        <TableCell sx={{ textAlign: 'right' }}>{row.pct}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Box>
            )}
            {!chartLoading && !chartError && !chartData && (
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                <Box sx={{ textAlign: 'center' }}>
                  <PivotIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                  <Typography variant="body1" color="text.secondary">Configure settings on the left, then click <strong>Render Pivot</strong></Typography>
                </Box>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── Column Picker Dialog ──────────────────────────── */}
      <Dialog
        open={showColPanel}
        onClose={() => { setShowColPanel(false); setColSearch(''); }}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { maxHeight: '80vh' } }}
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6">Columns</Typography>
            <Typography variant="caption" color="text.secondary">
              {displayCols.length} visible · {pinnedCols.length} pinned · {cols.length} total
            </Typography>
          </Box>
        </DialogTitle>

        <DialogContent sx={{ pt: 0 }}>
          <TextField
            size="small" fullWidth placeholder="Search columns…" value={colSearch}
            onChange={e => setColSearch(e.target.value)} autoFocus
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment> }}
            sx={{ mb: 1.5 }}
          />

          <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
            <Button size="small" variant="outlined"
              onClick={() => setVisibleCols(null)}
              sx={{ fontSize: 12, textTransform: 'none' }}>
              Show all
            </Button>
            {cols.length > MAX_VIS_COLS && (
              <Button size="small" variant="outlined"
                onClick={() => setVisibleCols(new Set(cols.slice(0, MAX_VIS_COLS)))}
                sx={{ fontSize: 12, textTransform: 'none' }}>
                First {MAX_VIS_COLS}
              </Button>
            )}
            <Button size="small" variant="outlined" color="error"
              onClick={() => setPinnedCols([])}
              disabled={pinnedCols.length === 0}
              sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}>
              Unpin all
            </Button>
          </Box>

          <Box sx={{ overflow: 'auto', maxHeight: 380 }}>
            {filteredColList.map(col => {
              const isVisible = visibleCols === null || visibleCols.has(col);
              const isPinned  = pinnedCols.includes(col);
              return (
                <Box key={col} sx={{
                  display: 'flex', alignItems: 'center', gap: 0.5,
                  py: 0.25, px: 0.5, borderRadius: 1,
                  '&:hover': { bgcolor: 'action.hover' },
                }}>
                  <Checkbox
                    checked={isVisible} size="small"
                    onChange={e => toggleColVisibility(col, e.target.checked)}
                    sx={{ p: 0.5 }}
                  />
                  <Typography variant="body2" title={col}
                    sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {col}
                  </Typography>
                  {isPinned && (
                    <Chip label="pinned" size="small" color="primary" variant="filled"
                      sx={{ height: 16, fontSize: 10, mr: 0.5, '& .MuiChip-label': { px: 0.75 } }} />
                  )}
                  <Tooltip title={isPinned ? 'Unpin' : 'Pin to left'}>
                    <IconButton size="small" onClick={() => togglePinCol(col)}
                      sx={{ color: isPinned ? 'primary.main' : 'text.disabled', p: 0.5 }}>
                      <PinIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </Tooltip>
                </Box>
              );
            })}
            {filteredColList.length === 0 && (
              <Typography variant="body2" color="text.disabled" sx={{ textAlign: 'center', py: 3 }}>
                No columns match "{colSearch}"
              </Typography>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => { setShowColPanel(false); setColSearch(''); }} variant="contained" size="small">
            Done
          </Button>
        </DialogActions>
      </Dialog>

    </Wrapper>
  );
};

export default DataGridViewer;
