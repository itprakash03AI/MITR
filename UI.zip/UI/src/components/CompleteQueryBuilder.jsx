import React, { useState, useEffect, useMemo } from 'react';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import api from '../services/api';
import DataGridViewer from './DataGridViewer';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Button, ButtonGroup, Paper, Card, CardContent,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem,
  Checkbox, FormControlLabel, Chip, IconButton, Tooltip,
  CircularProgress, LinearProgress, Alert, Stack, List, ListItem,
  ListItemButton, ListItemText, ListItemIcon, Divider, InputAdornment, Collapse,
} from '@mui/material';
import {
  TableChart as TableIcon, Link as JoinIcon, ViewColumn as ColumnIcon,
  FilterAlt as FilterIcon, PlayArrow as PlayIcon, Save as SaveIcon,
  Code as CodeIcon, Close as CloseIcon, Add as AddIcon, Delete as DeleteIcon,
  Edit as EditIcon, Warning as WarningIcon, OpenInNew as OpenInNewIcon,
  Search as SearchIcon, ChevronLeft as CollapseIcon, ChevronRight as ExpandIcon,
  FolderOpen as FolderIcon, TableRows as TableRowsIcon, Refresh as RefreshIcon,
} from '@mui/icons-material';

const SIDEBAR_W = 248;

const CompleteQueryBuilder = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Connection state
  const [connections, setConnections] = useState([]);
  const [selectedConnectionId, setSelectedConnectionId] = useState(null);

  // Core state
  const [allFiles, setAllFiles] = useState([]);
  const [selectedTables, setSelectedTables] = useState([]);
  const [tableSchemas, setTableSchemas] = useState({});

  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarSearch, setSidebarSearch] = useState('');
  const [expandedFolders, setExpandedFolders] = useState({});
  const [filesLoading, setFilesLoading] = useState(false);

  // Query building
  const [joins, setJoins] = useState([]);
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [filters, setFilters] = useState([]);
  const [orderBy, setOrderBy] = useState([]);
  const [limit, setLimit] = useState(1000);

  // Modals
  const [showTableSelector, setShowTableSelector] = useState(false);
  const [showJoinBuilder, setShowJoinBuilder] = useState(false);
  const [showColumnSelector, setShowColumnSelector] = useState(false);
  const [showFilterBuilder, setShowFilterBuilder] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);

  // Execution
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [sqlPreview, setSqlPreview] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  // Results viewer
  const [showResults, setShowResults] = useState(false);
  const [resultsExecutionId, setResultsExecutionId] = useState(null);

  // Edit mode — set when navigated from SavedQueries with loadQuery state
  const [editingQueryId, setEditingQueryId] = useState(null);
  const [editingQueryName, setEditingQueryName] = useState('');

  // Cross-connection Union / Join (parquet files from a second connection)
  const [showCrossConn, setShowCrossConn] = useState(false);
  const [crossConnId, setCrossConnId] = useState(null);
  const [crossConnFiles, setCrossConnFiles] = useState([]);
  const [crossConnFile, setCrossConnFile] = useState(null);
  const [crossConnMode, setCrossConnMode] = useState('union'); // 'union' | 'join'
  const [crossJoinLeftOn, setCrossJoinLeftOn] = useState('');
  const [crossJoinRightOn, setCrossJoinRightOn] = useState('');
  const [crossJoinHow, setCrossJoinHow] = useState('inner');
  const [crossConnLoading, setCrossConnLoading] = useState(false);

  const { addNotification } = useNotifications();
  const { lastMessage } = useWebSocket();

  useEffect(() => {
    loadConnections();
    loadFiles();
  }, []);

  // Load saved query into builder when navigated from SavedQueries
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    const qc = loadQuery.query_config || {};

    setEditingQueryId(loadQuery.id);
    setEditingQueryName(loadQuery.name || '');

    // Reconstruct selectedTables from files array in query_config
    if (qc.files && qc.files.length > 0) {
      const tables = qc.files.map(path => ({
        path,
        name: path.split('/').pop().replace(/\.[^.]+$/, ''),
        folder: path.includes('/') ? path.substring(0, path.lastIndexOf('/')) : '',
      }));
      setSelectedTables(tables);
    }

    // Reconstruct joins
    if (qc.joins && qc.joins.length > 0) {
      setJoins(qc.joins.map((j, i) => ({
        id: Date.now() + i,
        leftTable:   j.left_file,
        rightTable:  j.right_file,
        leftColumn:  Array.isArray(j.left_on)  ? j.left_on[0]  : j.left_on,
        rightColumn: Array.isArray(j.right_on) ? j.right_on[0] : j.right_on,
        joinType:    j.how || 'inner',
      })));
    }

    // Reconstruct columns
    if (qc.columns && qc.columns.length > 0) {
      setSelectedColumns(qc.columns.map(col => {
        const parts = col.split('.');
        return parts.length === 2
          ? { tableName: parts[0], columnName: parts[1] }
          : { tableName: '', columnName: col };
      }));
    }

    // Reconstruct filters
    if (qc.filters && qc.filters.length > 0) {
      setFilters(qc.filters.map((f, i) => ({
        id: Date.now() + i,
        column:   f.column,
        operator: f.operator,
        value:    Array.isArray(f.value) ? f.value.join(', ') : f.value,
      })));
    }

    // Reconstruct order by
    if (qc.order_by && qc.order_by.length > 0) {
      setOrderBy(qc.order_by.map(o => ({ column: o.column, direction: o.direction || 'asc' })));
    }

    if (qc.limit) setLimit(qc.limit);

    addNotification({ type: 'info', title: 'Query Loaded', message: `Editing "${loadQuery.name}"` });

    // Clear the router state so a refresh doesn't re-apply
    navigate('/', { replace: true, state: {} });
  }, [location.state?.loadQuery]);

  // Reload file list when connection changes
  useEffect(() => {
    setSelectedTables([]);
    setTableSchemas({});
    setSidebarSearch('');
    loadFiles();
  }, [selectedConnectionId]);

  useEffect(() => {
    if (selectedTables.length > 0) loadSchemas();
  }, [selectedTables]);

  useEffect(() => {
    generateSQLPreview();
  }, [selectedTables, joins, selectedColumns, filters, orderBy, limit]);

  useEffect(() => {
    if (lastMessage && lastMessage.execution_id === executionId) {
      handleProgress(lastMessage);
    }
  }, [lastMessage]);

  const loadConnections = async () => {
    try {
      const conns = await api.listConnections(true);
      setConnections(conns || []);
    } catch {}
  };

  const loadFiles = async () => {
    setFilesLoading(true);
    try {
      const files = selectedConnectionId
        ? await api.listConnectionFiles(selectedConnectionId)
        : await api.listFiles();
      const loaded = files || [];
      setAllFiles(loaded);
      // Auto-expand all folders on first load
      const folders = {};
      loaded.forEach(f => { if (f.folder) folders[f.folder] = true; });
      setExpandedFolders(folders);
      if (loaded.length > 0) setSidebarOpen(true);
    } catch (error) {
      addNotification({ type: 'error', title: 'Error loading files', message: error.message });
    } finally {
      setFilesLoading(false);
    }
  };

  const loadSchemas = async () => {
    const schemas = {};
    for (const table of selectedTables) {
      if (tableSchemas[table.path]) {
        schemas[table.path] = tableSchemas[table.path];
        continue;
      }
      try {
        const schema = selectedConnectionId
          ? await api.getConnectionFileSchema(selectedConnectionId, table.path)
          : await api.getFileSchema(table.path);
        schemas[table.path] = schema.columns || [];
      } catch (error) {
        console.error(`Error loading schema for ${table.path}:`, error);
      }
    }
    setTableSchemas(prev => ({ ...prev, ...schemas }));
  };

  // Load file list for the secondary cross-connection
  const loadCrossConnFiles = async (connId) => {
    if (!connId) { setCrossConnFiles([]); setCrossConnFile(null); return; }
    setCrossConnLoading(true);
    try {
      const files = await api.listConnectionFiles(connId);
      setCrossConnFiles(files || []);
      setCrossConnFile(null);
    } catch {
      setCrossConnFiles([]);
    } finally {
      setCrossConnLoading(false);
    }
  };

  const handleProgress = (message) => {
    if (message.type === 'execution_progress') {
      setProgress({
        rows: message.data?.total_rows || 0,
        chunks: message.data?.chunks_processed || 0,
        status: message.data?.status || 'processing',
      });
      if (message.data?.status === 'completed') {
        setExecuting(false);
        setProgress({ rows: message.data.total_rows || 0, status: 'completed' });
        setResultsExecutionId(executionId);
        setShowResults(true);
        addNotification({
          type: 'success',
          title: 'Query Completed',
          message: `Processed ${message.data.total_rows?.toLocaleString()} rows`,
        });
      }
    } else if (message.type === 'execution_completed') {
      setExecuting(false);
      setProgress({ rows: message.stats?.total_rows || 0, status: 'completed' });
      setResultsExecutionId(executionId);
      setShowResults(true);
      addNotification({
        type: 'success',
        title: 'Query Completed',
        message: `Processed ${message.stats?.total_rows?.toLocaleString()} rows`,
      });
    } else if (message.type === 'execution_failed') {
      setExecuting(false);
      setProgress({ status: 'failed', error: message.error });
      addNotification({ type: 'error', title: 'Query Failed', message: message.error });
    }
  };

  const generateSQLPreview = () => {
    if (selectedTables.length === 0) {
      setSqlPreview('-- Select tables to build query');
      return;
    }
    let sql = 'SELECT\n';
    sql += selectedColumns.length > 0
      ? selectedColumns.map(c => `  ${c.tableName}.${c.columnName}`).join(',\n')
      : '  *';
    sql += `\n\nFROM ${selectedTables[0].name}`;
    joins.forEach(j => {
      const rt = selectedTables.find(t => t.path === j.rightTable);
      sql += `\n${j.joinType.toUpperCase()} JOIN ${rt?.name}\n  ON ${j.leftColumn} = ${j.rightColumn}`;
    });
    if (filters.length > 0) {
      sql += '\n\nWHERE\n';
      sql += filters.map((f, i) => {
        const op = { eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=', in: 'IN', contains: 'LIKE' }[f.operator] || '=';
        return `  ${i > 0 ? 'AND ' : ''}${f.column} ${op} ${f.value}`;
      }).join('\n');
    }
    if (orderBy.length > 0) {
      sql += '\n\nORDER BY\n';
      sql += orderBy.map(o => `  ${o.column} ${o.direction.toUpperCase()}`).join(',\n');
    }
    sql += `\n\nLIMIT ${limit};`;
    setSqlPreview(sql);
  };

  const toggleTable = (file) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      setSelectedTables(selectedTables.filter(t => t.path !== file.path));
    } else {
      setSelectedTables([...selectedTables, file]);
    }
  };

  const executeQuery = async () => {
    if (selectedTables.length === 0) {
      addNotification({ type: 'warning', title: 'No Tables', message: 'Select at least one table' });
      return;
    }
    const hasLargeTable = selectedTables.some(t => t.num_rows > 1000000);
    if (hasLargeTable && joins.length > 0 && limit > 10000) {
      const totalRows = selectedTables.reduce((acc, t) => acc * (t.num_rows || 1), 1);
      const confirmed = window.confirm(
        `⚠️ WARNING: Large Join Detected!\n\nTables: ${selectedTables.map(t => `${t.name} (${t.num_rows?.toLocaleString()} rows)`).join(' × ')}\nPotential result: ${totalRows.toLocaleString()} rows\n\nThis could take a long time!\n\nRecommendation: set LIMIT ≤ 1000 and add WHERE filters.\n\nContinue anyway?`
      );
      if (!confirmed) return;
    }
    const queryConfig = {
      files: [selectedTables[0].path],
      joins: joins.map(j => ({
        left_file: j.leftTable, right_file: j.rightTable,
        left_on: [j.leftColumn], right_on: [j.rightColumn], how: j.joinType,
      })),
      columns: selectedColumns.map(c => c.columnName),
      filters: filters.map(f => ({
        column: f.column, operator: f.operator,
        value: f.operator === 'in' ? f.value.split(',').map(v => v.trim()) : f.value,
      })),
      order_by: orderBy.map(o => ({ column: o.column, direction: o.direction })),
      limit,
    };
    // Validate cross-connection config if enabled
    if (showCrossConn && crossConnId) {
      if (!crossConnFile) {
        addNotification({ type: 'warning', title: 'No Secondary File', message: 'Select a file from the secondary connection' });
        return;
      }
      if (crossConnMode === 'join' && (!crossJoinLeftOn || !crossJoinRightOn)) {
        addNotification({ type: 'warning', title: 'Join Config Incomplete', message: 'Specify both join key columns for cross-connection JOIN' });
        return;
      }
    }

    try {
      setExecuting(true);
      setShowResults(false);
      setProgress({ rows: 0, status: 'starting' });

      const payload = {
        query_config: queryConfig,
        ...(selectedConnectionId ? { connection_id: selectedConnectionId } : {}),
      };

      // Attach cross-connection params
      if (showCrossConn && crossConnId && crossConnFile) {
        payload.secondary_connection_id = crossConnId;
        payload.secondary_query_config  = { files: [crossConnFile], limit };
        payload.combine_mode            = crossConnMode;
        if (crossConnMode === 'join') {
          payload.join_config = {
            how:      crossJoinHow,
            left_on:  crossJoinLeftOn,
            right_on: crossJoinRightOn,
            suffixes: ['_primary', '_secondary'],
          };
        }
      }

      const response = await api.executeQuery(payload);
      setExecutionId(response.execution_id);
      const modeLabel = response.is_cross_connection
        ? ` (${(response.combine_mode || 'union').toUpperCase()})`
        : '';
      addNotification({ type: 'info', title: `Query Started${modeLabel}`, message: `ID: ${response.execution_id?.substring(0, 8)}` });
    } catch (error) {
      setExecuting(false);
      setProgress(null);
      addNotification({ type: 'error', title: 'Failed', message: error.message });
    }
  };

  const cancelQuery = async () => {
    if (executionId) {
      try { await api.cancelExecution(executionId); } catch {}
    }
    setExecuting(false);
    setProgress(null);
    addNotification({ type: 'info', title: 'Cancelled', message: 'Execution cancelled' });
  };

  const selectedConn = connections.find(c => c.id === selectedConnectionId);

  // ── Sidebar file tree (grouped by folder) ─────────────────────────────────
  const filteredFiles = useMemo(() => {
    const q = sidebarSearch.toLowerCase();
    return q ? allFiles.filter(f => f.name.toLowerCase().includes(q) || f.path.toLowerCase().includes(q)) : allFiles;
  }, [allFiles, sidebarSearch]);

  const fileTree = useMemo(() => {
    const root = [];
    const folders = {};
    filteredFiles.forEach(f => {
      const folder = f.folder || '';
      if (!folder) { root.push(f); return; }
      if (!folders[folder]) folders[folder] = [];
      folders[folder].push(f);
    });
    return { root, folders };
  }, [filteredFiles]);

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', flexDirection: 'row', bgcolor: 'background.default', overflow: 'hidden' }}>

      {/* ─── File Sidebar (Toad-style) ──────────────────────────────────────── */}
      <Box sx={{
        width: sidebarOpen ? SIDEBAR_W : 0,
        minWidth: sidebarOpen ? SIDEBAR_W : 0,
        transition: 'width 0.2s ease, min-width 0.2s ease',
        overflow: 'hidden',
        borderRight: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Sidebar header */}
        <Box sx={{ px: 1.5, py: 1, display: 'flex', alignItems: 'center', gap: 0.5, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <TableRowsIcon sx={{ fontSize: 16, color: 'primary.main', flexShrink: 0 }} />
          <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.primary', flexGrow: 1, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Tables
          </Typography>
          {filesLoading
            ? <CircularProgress size={14} />
            : <Tooltip title="Refresh">
                <IconButton size="small" onClick={loadFiles} sx={{ p: 0.25 }}>
                  <RefreshIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Tooltip>
          }
          <Tooltip title="Collapse sidebar">
            <IconButton size="small" onClick={() => setSidebarOpen(false)} sx={{ p: 0.25 }}>
              <CollapseIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>

        {/* Search */}
        <Box sx={{ px: 1, pt: 1, pb: 0.5, flexShrink: 0 }}>
          <TextField
            size="small"
            placeholder="Search tables..."
            value={sidebarSearch}
            onChange={e => setSidebarSearch(e.target.value)}
            fullWidth
            InputProps={{
              startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment>,
              endAdornment: sidebarSearch
                ? <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSidebarSearch('')} sx={{ p: 0.25 }}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </InputAdornment>
                : null,
            }}
            sx={{ '& .MuiInputBase-root': { fontSize: 13 } }}
          />
        </Box>

        {/* File tree */}
        <Box sx={{ flex: 1, overflowY: 'auto', pb: 1 }}>
          {allFiles.length === 0 && !filesLoading && (
            <Box sx={{ px: 2, pt: 2, textAlign: 'center' }}>
              <Typography variant="caption" color="text.disabled">
                {selectedConnectionId ? 'No parquet files found' : 'Select a connection or use default data'}
              </Typography>
            </Box>
          )}

          {/* Root-level files (no folder) */}
          {fileTree.root.map(file => (
            <SidebarFileItem
              key={file.path}
              file={file}
              selected={!!selectedTables.find(t => t.path === file.path)}
              onToggle={() => toggleTable(file)}
            />
          ))}

          {/* Folder groups */}
          {Object.entries(fileTree.folders).map(([folder, files]) => (
            <Box key={folder}>
              <ListItemButton
                dense
                onClick={() => setExpandedFolders(prev => ({ ...prev, [folder]: !prev[folder] }))}
                sx={{ px: 1.5, py: 0.5 }}
              >
                {expandedFolders[folder] ? <CollapseIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} /> : <ExpandIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} />}
                <FolderIcon sx={{ fontSize: 14, mr: 0.75, color: 'warning.main' }} />
                <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', flexGrow: 1 }} noWrap>
                  {folder}
                </Typography>
                <Typography variant="caption" color="text.disabled">({files.length})</Typography>
              </ListItemButton>
              <Collapse in={!!expandedFolders[folder]}>
                {files.map(file => (
                  <SidebarFileItem
                    key={file.path}
                    file={file}
                    selected={!!selectedTables.find(t => t.path === file.path)}
                    onToggle={() => toggleTable(file)}
                    indent
                  />
                ))}
              </Collapse>
            </Box>
          ))}
        </Box>

        {/* Selected count footer */}
        {selectedTables.length > 0 && (
          <Box sx={{ px: 1.5, py: 0.75, borderTop: 1, borderColor: 'divider', bgcolor: 'primary.50', flexShrink: 0 }}>
            <Typography variant="caption" sx={{ color: 'primary.main', fontWeight: 600 }}>
              {selectedTables.length} table{selectedTables.length > 1 ? 's' : ''} selected
            </Typography>
          </Box>
        )}
      </Box>

      {/* ─── Main content (controls + results) ─────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* ─── Controls strip ────────────────────────────────────────────── */}
        <Box sx={{ flexShrink: 0, px: 2, pt: 2, pb: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: 'background.paper' }}>

          {/* SQL Preview panel (collapsible) */}
          {showPreview && (
            <Paper sx={{ p: 2, bgcolor: 'grey.900' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="subtitle2" sx={{ color: 'grey.300' }}>
                  <CodeIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />
                  SQL Preview
                </Typography>
                <IconButton size="small" onClick={() => setShowPreview(false)} sx={{ color: 'grey.400' }}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Box>
              <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 13, color: '#4fc3f7', whiteSpace: 'pre-wrap', wordBreak: 'break-word', m: 0, maxHeight: 160, overflowY: 'auto' }}>
                {sqlPreview}
              </Box>
            </Paper>
          )}

          {/* Row 1: Data source + sidebar toggle + SQL toggle */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
            {/* Sidebar toggle */}
            {!sidebarOpen && (
              <Tooltip title="Show table browser">
                <IconButton size="small" onClick={() => setSidebarOpen(true)} sx={{ border: 1, borderColor: 'divider' }}>
                  <ExpandIcon />
                </IconButton>
              </Tooltip>
            )}

            <Typography variant="body2" sx={{ fontWeight: 600, color: 'text.secondary', whiteSpace: 'nowrap' }}>
              Data Source:
            </Typography>
            <TextField
              select
              size="small"
              value={selectedConnectionId ?? ''}
              onChange={e => setSelectedConnectionId(e.target.value === '' ? null : Number(e.target.value))}
              sx={{ minWidth: 220 }}
            >
              <MenuItem value="">Local (default)</MenuItem>
              {connections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  {c.name}
                  <Typography component="span" variant="caption" sx={{ ml: 1, color: 'text.disabled' }}>
                    ({c.connection_type})
                  </Typography>
                </MenuItem>
              ))}
            </TextField>
            {connections.length === 0 && (
              <Button
                size="small"
                variant="text"
                startIcon={<OpenInNewIcon fontSize="small" />}
                onClick={() => navigate('/connections')}
                sx={{ textTransform: 'none', fontSize: 12, color: 'text.secondary' }}
              >
                Manage Connections
              </Button>
            )}
            {selectedConn && (
              <Chip
                size="small"
                label={selectedConn.last_test_status === 'success' ? 'Connected' : 'Untested'}
                color={selectedConn.last_test_status === 'success' ? 'success' : 'default'}
                variant="outlined"
              />
            )}
            <Box sx={{ flexGrow: 1 }} />
            <Button variant="outlined" size="small" startIcon={<CodeIcon />} onClick={() => setShowPreview(v => !v)}>
              {showPreview ? 'Hide SQL' : 'SQL Preview'}
            </Button>
          </Box>

          {/* Row 2: Query builder toolbar + execute */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <ButtonGroup variant="contained" size="small">
              <Tooltip title="Browse tables in sidebar or open picker">
                <Button onClick={() => setShowTableSelector(true)} startIcon={<TableIcon />}>
                  Tables
                  <Chip label={selectedTables.length} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                </Button>
              </Tooltip>
              <Tooltip title="Configure joins (need ≥2 tables)">
                <span>
                  <Button onClick={() => setShowJoinBuilder(true)} disabled={selectedTables.length < 2} startIcon={<JoinIcon />}>
                    Joins
                    <Chip label={joins.length} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Pick columns (SELECT)">
                <span>
                  <Button onClick={() => setShowColumnSelector(true)} disabled={selectedTables.length === 0} startIcon={<ColumnIcon />}>
                    Columns
                    <Chip label={selectedColumns.length || '*'} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Add WHERE filters">
                <Button onClick={() => setShowFilterBuilder(true)} startIcon={<FilterIcon />}>
                  Filters
                  <Chip
                    label={filters.length}
                    size="small"
                    sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }}
                    color={filters.length > 0 ? 'warning' : 'default'}
                  />
                </Button>
              </Tooltip>
            </ButtonGroup>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 600 }}>Limit:</Typography>
              <TextField
                type="number"
                size="small"
                value={limit}
                onChange={e => setLimit(parseInt(e.target.value) || 0)}
                sx={{ width: 100 }}
              />
            </Box>

            {/* Cross-connection toggle */}
            <Tooltip title={showCrossConn ? 'Remove secondary source' : 'Union or Join with a file from another connection'}>
              <Button
                size="small"
                variant={showCrossConn ? 'contained' : 'outlined'}
                color={showCrossConn ? 'warning' : 'inherit'}
                startIcon={<JoinIcon />}
                onClick={() => setShowCrossConn(v => !v)}
                sx={{ fontSize: 12 }}
              >
                {showCrossConn ? 'Cross-Conn ✓' : 'Union / Join'}
              </Button>
            </Tooltip>

            <Box sx={{ flexGrow: 1 }} />

            <Button
              variant="outlined"
              size="small"
              startIcon={<SaveIcon />}
              onClick={() => setShowSaveDialog(true)}
              disabled={selectedTables.length === 0}
            >
              Save
            </Button>
            <Button
              variant="contained"
              color="success"
              size="small"
              startIcon={executing ? <CircularProgress size={16} color="inherit" /> : <PlayIcon />}
              onClick={executeQuery}
              disabled={selectedTables.length === 0 || executing}
              sx={{ fontWeight: 700, minWidth: 120 }}
            >
              {executing ? 'Running...' : 'Execute'}
            </Button>
          </Box>

          {/* Row 2b: Cross-Connection UNION / JOIN panel */}
          {showCrossConn && (
            <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'warning.50', borderColor: 'warning.300' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                <JoinIcon sx={{ fontSize: 16, color: 'warning.main', flexShrink: 0 }} />
                <Typography variant="caption" sx={{ fontWeight: 700, color: 'warning.dark', whiteSpace: 'nowrap' }}>
                  CROSS-CONNECTION
                </Typography>

                {/* Mode: UNION or JOIN */}
                <TextField
                  select size="small" label="Mode"
                  value={crossConnMode}
                  onChange={e => setCrossConnMode(e.target.value)}
                  sx={{ minWidth: 100 }}
                >
                  <MenuItem value="union">UNION (stack rows)</MenuItem>
                  <MenuItem value="join">JOIN (merge by key)</MenuItem>
                </TextField>

                {/* Secondary connection */}
                <TextField
                  select size="small" label="Secondary Connection"
                  value={crossConnId || ''}
                  onChange={e => { const v = e.target.value ? Number(e.target.value) : null; setCrossConnId(v); loadCrossConnFiles(v); }}
                  sx={{ minWidth: 200 }}
                >
                  <MenuItem value="">— Select —</MenuItem>
                  {connections.map(c => (
                    <MenuItem key={c.id} value={c.id} disabled={c.id === selectedConnectionId}>
                      {c.name} ({c.connection_type})
                    </MenuItem>
                  ))}
                </TextField>

                {/* Secondary file */}
                {crossConnId && (
                  <TextField
                    select size="small" label="Secondary File"
                    value={crossConnFile || ''}
                    onChange={e => setCrossConnFile(e.target.value || null)}
                    sx={{ minWidth: 240 }}
                    disabled={crossConnLoading}
                    InputProps={{ endAdornment: crossConnLoading ? <CircularProgress size={14} /> : null }}
                  >
                    <MenuItem value="">— Select file —</MenuItem>
                    {crossConnFiles.map(f => (
                      <MenuItem key={f.path} value={f.path}>{f.name}</MenuItem>
                    ))}
                  </TextField>
                )}

                {/* JOIN keys */}
                {crossConnMode === 'join' && crossConnId && (
                  <>
                    <TextField
                      select size="small" label="Join Type"
                      value={crossJoinHow}
                      onChange={e => setCrossJoinHow(e.target.value)}
                      sx={{ minWidth: 110 }}
                    >
                      {['inner', 'left', 'right', 'outer'].map(h => (
                        <MenuItem key={h} value={h}>{h.toUpperCase()}</MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      size="small" label="Primary key col"
                      value={crossJoinLeftOn}
                      onChange={e => setCrossJoinLeftOn(e.target.value)}
                      placeholder="e.g. id"
                      sx={{ minWidth: 140 }}
                    />
                    <Typography variant="caption" color="text.secondary">=</Typography>
                    <TextField
                      size="small" label="Secondary key col"
                      value={crossJoinRightOn}
                      onChange={e => setCrossJoinRightOn(e.target.value)}
                      placeholder="e.g. customer_id"
                      sx={{ minWidth: 140 }}
                    />
                  </>
                )}

                {crossConnFile && (
                  <Chip
                    size="small"
                    color="warning"
                    label={`${crossConnMode.toUpperCase()} ready`}
                    sx={{ fontSize: 11 }}
                  />
                )}
              </Box>
            </Paper>
          )}

          {/* Row 3: Query summary + execution progress */}
          {(selectedTables.length > 0 || executing) && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap', minHeight: 28 }}>
              {selectedTables.length > 0 && (
                <Typography variant="body2" color="text.secondary">
                  <strong>FROM</strong> {selectedTables[0].name}
                  {joins.length > 0 && ` + ${joins.length} join(s)`}
                  {selectedColumns.length > 0 && ` · ${selectedColumns.length} column(s) selected`}
                  {filters.length > 0 && ` · ${filters.length} filter(s)`}
                </Typography>
              )}
              {executing && (
                <>
                  <LinearProgress sx={{ flex: 1, minWidth: 80, maxWidth: 240 }} />
                  <Typography variant="caption" color="primary.main" sx={{ fontWeight: 500 }}>
                    {progress?.status === 'starting' ? 'Starting...' : `${(progress?.rows || 0).toLocaleString()} rows`}
                  </Typography>
                  <Button
                    size="small"
                    variant="text"
                    color="error"
                    onClick={cancelQuery}
                    sx={{ textTransform: 'none', py: 0 }}
                  >
                    Cancel
                  </Button>
                </>
              )}
            </Box>
          )}

          {/* Error alert */}
          {progress?.status === 'failed' && (
            <Alert severity="error" onClose={() => setProgress(null)} sx={{ py: 0.5 }}>
              <strong>Query failed:</strong> {progress.error}
            </Alert>
          )}
        </Box>

        {/* ─── Results area ──────────────────────────────────────────────── */}
        <Box sx={{ flex: 1, overflow: 'hidden', p: 1 }}>
          {showResults && resultsExecutionId ? (
            <DataGridViewer
              executionId={resultsExecutionId}
              onClose={() => { setShowResults(false); setResultsExecutionId(null); }}
            />
          ) : (
            <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, color: 'text.secondary', userSelect: 'none' }}>
              <TableIcon sx={{ fontSize: '5rem', opacity: 0.08 }} />
              <Typography variant="h5" sx={{ fontWeight: 600, opacity: 0.4 }}>
                {selectedTables.length === 0 ? 'Click a table in the sidebar to get started' : 'Run the query to see results'}
              </Typography>
              {selectedTables.length > 0 && !executing && (
                <Button variant="contained" size="large" startIcon={<PlayIcon />} onClick={executeQuery} sx={{ mt: 1 }}>
                  Execute Query
                </Button>
              )}
            </Box>
          )}
        </Box>
      </Box>

      {/* ─── Modals ──────────────────────────────────────────────────────────── */}
      <TableSelectorModal
        open={showTableSelector}
        files={allFiles}
        selectedTables={selectedTables}
        onUpdate={setSelectedTables}
        onClose={() => setShowTableSelector(false)}
      />
      <JoinBuilderModal
        open={showJoinBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        joins={joins}
        onUpdate={setJoins}
        onClose={() => setShowJoinBuilder(false)}
      />
      <ColumnSelectorModal
        open={showColumnSelector}
        tables={selectedTables}
        schemas={tableSchemas}
        selectedColumns={selectedColumns}
        onUpdate={setSelectedColumns}
        onClose={() => setShowColumnSelector(false)}
      />
      <FilterBuilderModal
        open={showFilterBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        filters={filters}
        onUpdate={setFilters}
        onClose={() => setShowFilterBuilder(false)}
      />
      <SaveQueryModal
        open={showSaveDialog}
        queryConfig={{ selectedTables, joins, selectedColumns, filters, orderBy, limit }}
        sqlPreview={sqlPreview}
        editingQueryId={editingQueryId}
        editingQueryName={editingQueryName}
        onClose={() => setShowSaveDialog(false)}
        onSaved={(id, name) => { setEditingQueryId(id); setEditingQueryName(name); }}
      />
    </Box>
  );
};

// ============================================================================
// SIDEBAR FILE ITEM
// ============================================================================
const SidebarFileItem = ({ file, selected, onToggle, indent = false }) => (
  <ListItemButton
    dense
    onClick={onToggle}
    selected={selected}
    sx={{
      pl: indent ? 3.5 : 1.5,
      pr: 1,
      py: 0.5,
      '&.Mui-selected': { bgcolor: 'rgba(21,101,192,0.08)' },
      '&.Mui-selected:hover': { bgcolor: 'rgba(21,101,192,0.12)' },
    }}
  >
    <ListItemIcon sx={{ minWidth: 24 }}>
      <Checkbox
        checked={selected}
        size="small"
        sx={{ p: 0, '& .MuiSvgIcon-root': { fontSize: 16 } }}
        disableRipple
      />
    </ListItemIcon>
    <ListItemText
      primary={file.name.replace(/\.parquet$/i, '')}
      secondary={file.num_rows != null ? `${file.num_rows.toLocaleString()} rows` : null}
      primaryTypographyProps={{ variant: 'caption', fontWeight: selected ? 700 : 400, noWrap: true }}
      secondaryTypographyProps={{ variant: 'caption', sx: { fontSize: 10 } }}
    />
    {file.num_rows > 1000000 && (
      <Tooltip title="Large file">
        <WarningIcon sx={{ fontSize: 13, color: 'warning.main', ml: 0.5 }} />
      </Tooltip>
    )}
  </ListItemButton>
);

// ============================================================================
// TABLE SELECTOR MODAL
// ============================================================================
const TableSelectorModal = ({ open, files, selectedTables, onUpdate, onClose }) => {
  const toggleTable = (file) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      onUpdate(selectedTables.filter(t => t.path !== file.path));
    } else {
      onUpdate([...selectedTables, file]);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TableIcon />
          <span>Select Tables</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={1}>
          {files.length === 0 && (
            <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
              No parquet files found in this data source.
            </Typography>
          )}
          {files.map(file => {
            const isSelected = selectedTables.find(t => t.path === file.path);
            return (
              <Card
                key={file.path}
                variant="outlined"
                sx={{
                  cursor: 'pointer',
                  bgcolor: isSelected ? 'action.selected' : 'background.paper',
                  borderColor: isSelected ? 'primary.main' : 'divider',
                  '&:hover': { bgcolor: 'action.hover' },
                }}
                onClick={() => toggleTable(file)}
              >
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 1.5, py: 1.5, '&:last-child': { pb: 1.5 } }}>
                  <Checkbox checked={!!isSelected} readOnly />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium' }}>
                      {file.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        {file.num_rows?.toLocaleString()} rows &middot; {file.num_columns} cols
                      </Typography>
                      {file.num_rows > 1000000 && (
                        <Chip
                          icon={<WarningIcon />}
                          label="Large"
                          size="small"
                          color="warning"
                          variant="outlined"
                        />
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            );
          })}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedTables.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// JOIN BUILDER MODAL - COMPLETE WITH EDIT/DELETE
// ============================================================================
const JoinBuilderModal = ({ open, tables, schemas, joins, onUpdate, onClose }) => {
  const [editingJoin, setEditingJoin] = useState(null);
  const [newJoin, setNewJoin] = useState({
    leftTable: tables[0]?.path || '',
    rightTable: tables[1]?.path || '',
    leftColumn: '',
    rightColumn: '',
    joinType: 'inner'
  });

  useEffect(() => {
    if (open) {
      setNewJoin({
        leftTable: tables[0]?.path || '',
        rightTable: tables[1]?.path || '',
        leftColumn: '',
        rightColumn: '',
        joinType: 'inner'
      });
      setEditingJoin(null);
    }
  }, [open, tables]);

  const getAllColumns = (tablePath) => schemas[tablePath] || [];

  const addJoin = () => {
    if (!newJoin.leftColumn || !newJoin.rightColumn) {
      alert('Please select join columns for both tables');
      return;
    }
    if (editingJoin !== null) {
      const updated = [...joins];
      updated[editingJoin] = { ...newJoin, id: joins[editingJoin].id };
      onUpdate(updated);
      setEditingJoin(null);
    } else {
      onUpdate([...joins, { ...newJoin, id: Date.now() }]);
    }
    setNewJoin({
      leftTable: tables[0]?.path || '',
      rightTable: tables[1]?.path || '',
      leftColumn: '',
      rightColumn: '',
      joinType: 'inner'
    });
  };

  const editJoin = (index) => { setEditingJoin(index); setNewJoin(joins[index]); };
  const deleteJoin = (index) => {
    if (window.confirm('Delete this join?')) onUpdate(joins.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <JoinIcon />
          <span>Configure Joins</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 'bold' }}>
            {editingJoin !== null
              ? <><EditIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Edit Join</>
              : <><AddIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Add New Join</>}
          </Typography>

          <Box sx={{ mb: 2 }}>
            <TextField
              select label="Join Type" fullWidth size="small"
              value={newJoin.joinType}
              onChange={e => setNewJoin({ ...newJoin, joinType: e.target.value })}
            >
              <MenuItem value="inner">INNER JOIN</MenuItem>
              <MenuItem value="left">LEFT JOIN</MenuItem>
              <MenuItem value="right">RIGHT JOIN</MenuItem>
              <MenuItem value="outer">FULL OUTER JOIN</MenuItem>
            </TextField>
          </Box>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} sx={{ mb: 1 }}>
            <Box sx={{ flex: 1 }}>
              <TextField
                select label="Left Table" fullWidth size="small"
                value={newJoin.leftTable}
                onChange={e => setNewJoin({ ...newJoin, leftTable: e.target.value, leftColumn: '' })}
                sx={{ mb: 1.5 }}
              >
                {tables.map(t => <MenuItem key={t.path} value={t.path}>{t.name}</MenuItem>)}
              </TextField>
              <TextField
                select label="Left Column" fullWidth size="small"
                value={newJoin.leftColumn}
                onChange={e => setNewJoin({ ...newJoin, leftColumn: e.target.value })}
              >
                <MenuItem value="">-- Select Column --</MenuItem>
                {getAllColumns(newJoin.leftTable).map(col => (
                  <MenuItem key={col.name} value={col.name}>{col.name} ({col.type})</MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Typography variant="h5" color="text.secondary">=</Typography>
            </Box>

            <Box sx={{ flex: 1 }}>
              <TextField
                select label="Right Table" fullWidth size="small"
                value={newJoin.rightTable}
                onChange={e => setNewJoin({ ...newJoin, rightTable: e.target.value, rightColumn: '' })}
                sx={{ mb: 1.5 }}
              >
                {tables.map(t => <MenuItem key={t.path} value={t.path}>{t.name}</MenuItem>)}
              </TextField>
              <TextField
                select label="Right Column" fullWidth size="small"
                value={newJoin.rightColumn}
                onChange={e => setNewJoin({ ...newJoin, rightColumn: e.target.value })}
              >
                <MenuItem value="">-- Select Column --</MenuItem>
                {getAllColumns(newJoin.rightTable).map(col => (
                  <MenuItem key={col.name} value={col.name}>{col.name} ({col.type})</MenuItem>
                ))}
              </TextField>
            </Box>
          </Stack>

          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 2 }}>
            {editingJoin !== null && (
              <Button
                variant="outlined"
                onClick={() => {
                  setEditingJoin(null);
                  setNewJoin({ leftTable: tables[0]?.path, rightTable: tables[1]?.path, leftColumn: '', rightColumn: '', joinType: 'inner' });
                }}
              >
                Cancel Edit
              </Button>
            )}
            <Button variant="contained" onClick={addJoin} startIcon={editingJoin !== null ? <SaveIcon /> : <AddIcon />}>
              {editingJoin !== null ? 'Update Join' : 'Add Join'}
            </Button>
          </Stack>
        </Paper>

        {joins.length > 0 && (
          <Box>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 'bold' }}>
              Configured Joins ({joins.length})
            </Typography>
            <Stack spacing={1}>
              {joins.map((join, index) => {
                const leftTable = tables.find(t => t.path === join.leftTable);
                const rightTable = tables.find(t => t.path === join.rightTable);
                return (
                  <Paper key={join.id} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Chip label={join.joinType.toUpperCase()} size="small" color="primary" />
                      <Typography variant="body2">
                        <strong>{leftTable?.name}</strong>.{join.leftColumn}
                        <Typography component="span" sx={{ mx: 1, color: 'text.secondary' }}>=</Typography>
                        <strong>{rightTable?.name}</strong>.{join.rightColumn}
                      </Typography>
                    </Box>
                    <Box>
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => editJoin(index)} color="primary">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton size="small" onClick={() => deleteJoin(index)} color="error">
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Paper>
                );
              })}
            </Stack>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// COLUMN SELECTOR MODAL - COMPLETE
// ============================================================================
const ColumnSelectorModal = ({ open, tables, schemas, selectedColumns, onUpdate, onClose }) => {
  const toggleColumn = (table, column) => {
    const exists = selectedColumns.find(c => c.tableName === table.name && c.columnName === column.name);
    if (exists) {
      onUpdate(selectedColumns.filter(c => !(c.tableName === table.name && c.columnName === column.name)));
    } else {
      onUpdate([...selectedColumns, { tableName: table.name, columnName: column.name, type: column.type }]);
    }
  };

  const selectAll = (table) => {
    const cols = schemas[table.path] || [];
    const newCols = cols.map(c => ({ tableName: table.name, columnName: c.name, type: c.type }));
    onUpdate([...selectedColumns.filter(c => c.tableName !== table.name), ...newCols]);
  };

  const deselectAll = (table) => {
    onUpdate(selectedColumns.filter(c => c.tableName !== table.name));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <ColumnIcon />
          <span>Select Columns</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Stack spacing={2}>
          {tables.map(table => {
            const cols = schemas[table.path] || [];
            return (
              <Paper key={table.path} variant="outlined" sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {table.name}
                    <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      ({cols.length} columns)
                    </Typography>
                  </Typography>
                  <Stack direction="row" spacing={1}>
                    <Button size="small" onClick={() => selectAll(table)}>Select All</Button>
                    <Button size="small" onClick={() => deselectAll(table)}>Clear</Button>
                  </Stack>
                </Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 0.5 }}>
                  {cols.map(col => {
                    const isSelected = selectedColumns.find(c => c.tableName === table.name && c.columnName === col.name);
                    return (
                      <FormControlLabel
                        key={col.name}
                        control={<Checkbox checked={!!isSelected} onChange={() => toggleColumn(table, col)} size="small" />}
                        label={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Typography variant="body2">{col.name}</Typography>
                            <Typography variant="caption" color="text.secondary">({col.type})</Typography>
                          </Box>
                        }
                      />
                    );
                  })}
                </Box>
              </Paper>
            );
          })}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedColumns.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// FILTER BUILDER MODAL - COMPLETE WITH EDIT/DELETE
// ============================================================================
const FilterBuilderModal = ({ open, tables, schemas, filters, onUpdate, onClose }) => {
  const [editingFilter, setEditingFilter] = useState(null);
  const [newFilter, setNewFilter] = useState({ column: '', operator: 'eq', value: '' });

  const allColumns = tables.flatMap(t =>
    (schemas[t.path] || []).map(c => ({ table: t.name, column: c.name, type: c.type }))
  );

  const addFilter = () => {
    if (!newFilter.column || !newFilter.value) {
      alert('Please fill all fields');
      return;
    }
    if (editingFilter !== null) {
      const updated = [...filters];
      updated[editingFilter] = { ...newFilter, id: filters[editingFilter].id };
      onUpdate(updated);
      setEditingFilter(null);
    } else {
      onUpdate([...filters, { ...newFilter, id: Date.now() }]);
    }
    setNewFilter({ column: '', operator: 'eq', value: '' });
  };

  const editFilter = (index) => { setEditingFilter(index); setNewFilter(filters[index]); };
  const deleteFilter = (index) => {
    if (window.confirm('Delete this filter?')) onUpdate(filters.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <FilterIcon />
          <span>Add Filters (WHERE)</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 'bold' }}>
            {editingFilter !== null
              ? <><EditIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Edit Filter</>
              : <><AddIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Add Filter</>}
          </Typography>

          <Stack spacing={2}>
            <TextField
              select label="Column" fullWidth size="small"
              value={newFilter.column}
              onChange={e => setNewFilter({ ...newFilter, column: e.target.value })}
            >
              <MenuItem value="">-- Select Column --</MenuItem>
              {allColumns.map((col, i) => (
                <MenuItem key={i} value={`${col.table}.${col.column}`}>
                  {col.table}.{col.column} ({col.type})
                </MenuItem>
              ))}
            </TextField>

            <TextField
              select label="Operator" fullWidth size="small"
              value={newFilter.operator}
              onChange={e => setNewFilter({ ...newFilter, operator: e.target.value })}
            >
              <MenuItem value="eq">= (equals)</MenuItem>
              <MenuItem value="ne">!= (not equals)</MenuItem>
              <MenuItem value="gt">&gt; (greater than)</MenuItem>
              <MenuItem value="gte">&gt;= (greater or equal)</MenuItem>
              <MenuItem value="lt">&lt; (less than)</MenuItem>
              <MenuItem value="lte">&lt;= (less or equal)</MenuItem>
              <MenuItem value="in">IN (comma-separated)</MenuItem>
              <MenuItem value="contains">LIKE (contains)</MenuItem>
            </TextField>

            <TextField
              label="Value" fullWidth size="small"
              value={newFilter.value}
              onChange={e => setNewFilter({ ...newFilter, value: e.target.value })}
              placeholder={newFilter.operator === 'in' ? 'val1, val2, val3' : 'value'}
            />
          </Stack>

          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 2 }}>
            {editingFilter !== null && (
              <Button
                variant="outlined"
                onClick={() => { setEditingFilter(null); setNewFilter({ column: '', operator: 'eq', value: '' }); }}
              >
                Cancel
              </Button>
            )}
            <Button variant="contained" onClick={addFilter} startIcon={editingFilter !== null ? <SaveIcon /> : <AddIcon />}>
              {editingFilter !== null ? 'Update' : 'Add Filter'}
            </Button>
          </Stack>
        </Paper>

        {filters.length > 0 && (
          <Box>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 'bold' }}>
              Active Filters ({filters.length})
            </Typography>
            <Stack spacing={1}>
              {filters.map((filter, index) => (
                <Paper key={filter.id} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                    {filter.column} {filter.operator.toUpperCase()} {filter.value}
                  </Typography>
                  <Box>
                    <Tooltip title="Edit">
                      <IconButton size="small" onClick={() => editFilter(index)} color="primary">
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" onClick={() => deleteFilter(index)} color="error">
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Paper>
              ))}
            </Stack>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// SAVE QUERY MODAL — supports both create and update
// ============================================================================
const SaveQueryModal = ({ open, queryConfig, sqlPreview, editingQueryId, editingQueryName, onClose, onSaved }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  // Pre-fill name when editing
  useEffect(() => {
    if (open) {
      setName(editingQueryName || '');
      setDescription('');
    }
  }, [open, editingQueryName]);

  const handleSave = async () => {
    if (!name.trim()) { alert('Please enter a query name'); return; }
    try {
      const payload = { name: name.trim(), description: description || null, query_config: queryConfig };
      let result;
      if (editingQueryId) {
        result = await api.updateQuery(editingQueryId, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated successfully` });
      } else {
        result = await api.saveQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved successfully` });
      }
      if (onSaved && result) onSaved(result.id || editingQueryId, name.trim());
      onClose();
    } catch (error) {
      addNotification({ type: 'error', title: 'Save Error', message: error.message });
    }
  };

  const isEditing = !!editingQueryId;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <SaveIcon />
          <span>{isEditing ? 'Update Query' : 'Save Query'}</span>
          {isEditing && <Chip label="Editing" size="small" color="warning" sx={{ ml: 1 }} />}
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Query Name" required fullWidth
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g., Monthly Sales Report"
            onKeyDown={e => e.key === 'Enter' && handleSave()}
          />
          <TextField
            label="Description" fullWidth multiline rows={2}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Optional description"
          />
          <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
              SQL Preview
            </Typography>
            <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 12, m: 0, whiteSpace: 'pre-wrap', color: 'text.primary', maxHeight: 120, overflowY: 'auto' }}>
              {sqlPreview}
            </Box>
          </Paper>
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {isEditing ? 'Update Query' : 'Save Query'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CompleteQueryBuilder;
