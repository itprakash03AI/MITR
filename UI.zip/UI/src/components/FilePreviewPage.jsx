/**
 * File Preview Page — Query Studio
 *
 * Left panel (280 px):
 *   • Downloads tab  — list all download records, click to preview by file_id
 *   • Browse Files tab — pick a connection → browse files → preview by file_path
 *
 * Right panel:
 *   DataGridViewer (embedded) — full table/chart/pivot/filter capabilities
 */
import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, Chip, CircularProgress, Alert,
  Divider, IconButton, InputAdornment, List, ListItemButton,
  ListItemIcon, ListItemText, Tab, Tabs, TextField, Tooltip,
  MenuItem, Select, FormControl, InputLabel, Paper,
} from '@mui/material';
import {
  FolderOpen as FolderIcon,
  InsertDriveFile as FileIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  TableChart as ExcelIcon,
  DataObject as JsonIcon,
  Storage as StorageIcon,
  ArrowBack as BackIcon,
} from '@mui/icons-material';
import api from '../services/api';
import DataGridViewer from './DataGridViewer';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
const fmtSize = (bytes) => {
  if (!bytes) return '';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
};

const fmtDate = (s) => {
  if (!s) return '';
  return new Date(s).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
};

const FileTypeChip = ({ filename, format }) => {
  const fmt = format || (
    (filename || '').endsWith('.xlsx') ? 'excel' :
    (filename || '').endsWith('.json') ? 'json'  : 'csv'
  );
  const colors = { excel: 'success', json: 'info', csv: 'default' };
  return (
    <Chip
      label={fmt.toUpperCase()}
      size="small"
      color={colors[fmt] || 'default'}
      variant="outlined"
      sx={{ height: 18, fontSize: 10, flexShrink: 0 }}
    />
  );
};

// ─────────────────────────────────────────────────────────────
// Downloads tab — list available download files
// ─────────────────────────────────────────────────────────────
const DownloadsPanel = ({ onSelect, selectedId }) => {
  const [downloads, setDownloads] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.listDownloads('available');
      setDownloads(data || []);
    } catch {
      setDownloads([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = downloads.filter(d =>
    !search || (d.filename || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ p: 1.5, pb: 1 }}>
        <TextField
          size="small" fullWidth placeholder="Search files…"
          value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment>,
            endAdornment: search
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton>
                </InputAdornment>
              : null,
          }}
        />
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, pb: 0.5 }}>
        <Typography variant="caption" color="text.secondary">{filtered.length} files</Typography>
        <Tooltip title="Refresh">
          <IconButton size="small" onClick={load}><RefreshIcon sx={{ fontSize: 16 }} /></IconButton>
        </Tooltip>
      </Box>
      <Divider />
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={24} /></Box>
      ) : filtered.length === 0 ? (
        <Box sx={{ p: 2, textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary">No downloads available</Typography>
        </Box>
      ) : (
        <List dense sx={{ flex: 1, overflow: 'auto', py: 0 }}>
          {filtered.map(d => (
            <ListItemButton
              key={d.file_id}
              selected={selectedId === d.file_id}
              onClick={() => onSelect({ type: 'fileId', id: d.file_id, name: d.filename })}
              sx={{ borderBottom: '1px solid', borderColor: 'divider', alignItems: 'flex-start', py: 1 }}
            >
              <ListItemIcon sx={{ mt: 0.5, minWidth: 32 }}>
                <FileIcon sx={{ fontSize: 18, color: 'text.secondary' }} />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexWrap: 'wrap' }}>
                    <Typography variant="body2" noWrap sx={{ flex: 1, fontSize: 12, fontWeight: 500 }} title={d.filename}>
                      {d.filename}
                    </Typography>
                    <FileTypeChip filename={d.filename} format={d.format} />
                  </Box>
                }
                secondary={
                  <Typography variant="caption" color="text.secondary">
                    {fmtSize(d.file_size_bytes)} · {fmtDate(d.created_at)}
                  </Typography>
                }
              />
            </ListItemButton>
          ))}
        </List>
      )}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// Browse Files tab — connections → files
// ─────────────────────────────────────────────────────────────
const BrowseFilesPanel = ({ onSelect, selectedPath }) => {
  const [connections, setConnections]     = useState([]);
  const [selectedConn, setSelectedConn]  = useState(null);
  const [files, setFiles]                 = useState([]);
  const [filesLoading, setFilesLoading]  = useState(false);
  const [search, setSearch]              = useState('');

  useEffect(() => {
    api.listConnections(true).then(setConnections).catch(() => setConnections([]));
  }, []);

  const loadFiles = async (conn) => {
    setSelectedConn(conn);
    setFiles([]);
    setFilesLoading(true);
    try {
      const data = await api.listConnectionFiles(conn.id, '');
      setFiles(data?.files || data || []);
    } catch {
      setFiles([]);
    } finally {
      setFilesLoading(false);
    }
  };

  const previewableFiles = files.filter(f => {
    const name = (typeof f === 'string' ? f : f.name || f.path || f.filename || '').toLowerCase();
    return name.endsWith('.parquet') || name.endsWith('.csv') || name.endsWith('.txt');
  });

  const filtered = previewableFiles.filter(f => {
    const name = typeof f === 'string' ? f : f.name || f.path || f.filename || '';
    return !search || name.toLowerCase().includes(search.toLowerCase());
  });

  if (!selectedConn) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <Box sx={{ p: 1.5, pb: 0.5 }}>
          <Typography variant="caption" color="text.secondary">Select a connection to browse files</Typography>
        </Box>
        <Divider sx={{ mb: 0.5 }} />
        {connections.length === 0 ? (
          <Box sx={{ p: 2, textAlign: 'center' }}>
            <Typography variant="body2" color="text.secondary">No connections configured</Typography>
          </Box>
        ) : (
          <List dense sx={{ flex: 1, overflow: 'auto', py: 0 }}>
            {connections.map(c => (
              <ListItemButton
                key={c.id}
                onClick={() => loadFiles(c)}
                sx={{ borderBottom: '1px solid', borderColor: 'divider', py: 1 }}
              >
                <ListItemIcon sx={{ minWidth: 32 }}>
                  <StorageIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                </ListItemIcon>
                <ListItemText
                  primary={<Typography variant="body2" sx={{ fontWeight: 500, fontSize: 12 }}>{c.name}</Typography>}
                  secondary={<Typography variant="caption" color="text.secondary">{c.connection_type || c.type}</Typography>}
                />
              </ListItemButton>
            ))}
          </List>
        )}
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Connection breadcrumb */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, px: 1, py: 0.75, bgcolor: 'grey.50', borderBottom: 1, borderColor: 'divider' }}>
        <Tooltip title="Back to connections">
          <IconButton size="small" onClick={() => { setSelectedConn(null); setFiles([]); }}>
            <BackIcon sx={{ fontSize: 16 }} />
          </IconButton>
        </Tooltip>
        <StorageIcon sx={{ fontSize: 16, color: 'primary.main' }} />
        <Typography variant="caption" fontWeight={600} noWrap>{selectedConn.name}</Typography>
      </Box>

      <Box sx={{ p: 1.5, pb: 1 }}>
        <TextField
          size="small" fullWidth placeholder="Search files…"
          value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment>,
            endAdornment: search
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton>
                </InputAdornment>
              : null,
          }}
        />
      </Box>

      <Box sx={{ px: 1.5, pb: 0.5 }}>
        <Typography variant="caption" color="text.secondary">
          {filesLoading ? 'Loading…' : `${filtered.length} previewable file${filtered.length !== 1 ? 's' : ''}`}
        </Typography>
      </Box>
      <Divider />

      {filesLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={24} /></Box>
      ) : filtered.length === 0 ? (
        <Box sx={{ p: 2, textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary">No CSV or Parquet files found</Typography>
        </Box>
      ) : (
        <List dense sx={{ flex: 1, overflow: 'auto', py: 0 }}>
          {filtered.map((f, i) => {
            const rawPath = typeof f === 'string' ? f : f.path || f.name || f.filename || '';
            const name    = rawPath.split('/').pop() || rawPath;
            const isParquet = name.toLowerCase().endsWith('.parquet');
            return (
              <ListItemButton
                key={i}
                selected={selectedPath === rawPath}
                onClick={() => onSelect({ type: 'filePath', path: rawPath, name, connectionId: selectedConn.id })}
                sx={{ borderBottom: '1px solid', borderColor: 'divider', py: 0.75 }}
              >
                <ListItemIcon sx={{ minWidth: 32 }}>
                  <FileIcon sx={{ fontSize: 18, color: isParquet ? 'primary.main' : 'text.secondary' }} />
                </ListItemIcon>
                <ListItemText
                  primary={
                    <Typography variant="body2" noWrap sx={{ fontSize: 12 }} title={rawPath}>{name}</Typography>
                  }
                  secondary={
                    <Chip
                      label={isParquet ? 'Parquet' : 'CSV'}
                      size="small"
                      variant="outlined"
                      color={isParquet ? 'primary' : 'default'}
                      sx={{ height: 16, fontSize: 9 }}
                    />
                  }
                />
              </ListItemButton>
            );
          })}
        </List>
      )}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// Main Page
// ─────────────────────────────────────────────────────────────
const FilePreviewPage = () => {
  const [tab, setTab]           = useState(0); // 0 = Downloads, 1 = Browse Files
  const [selection, setSelection] = useState(null);
  // selection = { type: 'fileId'|'filePath', id?, path?, name }

  const handleSelect = (sel) => setSelection(sel);

  const handleTabChange = (_, v) => {
    setTab(v);
    setSelection(null);
  };

  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 52px)', overflow: 'hidden' }}>

      {/* ── Left panel ────────────────────────────────────────── */}
      <Box sx={{
        width: 300, flexShrink: 0, display: 'flex', flexDirection: 'column',
        borderRight: 1, borderColor: 'divider', bgcolor: 'background.paper',
      }}>
        <Tabs
          value={tab}
          onChange={handleTabChange}
          variant="fullWidth"
          sx={{ borderBottom: 1, borderColor: 'divider', minHeight: 40 }}
          TabIndicatorProps={{ sx: { height: 2 } }}
        >
          <Tab label="Downloads" sx={{ fontSize: 12, minHeight: 40, py: 0 }} />
          <Tab label="Browse Files" sx={{ fontSize: 12, minHeight: 40, py: 0 }} />
        </Tabs>

        <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {tab === 0 && (
            <DownloadsPanel
              onSelect={handleSelect}
              selectedId={selection?.type === 'fileId' ? selection.id : null}
            />
          )}
          {tab === 1 && (
            <BrowseFilesPanel
              onSelect={handleSelect}
              selectedPath={selection?.type === 'filePath' ? selection.path : null}
            />
          )}
        </Box>
      </Box>

      {/* ── Right panel — DataGridViewer ─────────────────────── */}
      <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {!selection ? (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 2 }}>
            <FolderIcon sx={{ fontSize: 80, opacity: 0.08, color: 'text.secondary' }} />
            <Typography variant="h6" color="text.secondary" fontWeight={400}>
              Select a file to preview
            </Typography>
            <Typography variant="body2" color="text.disabled">
              Choose from Downloads or browse your connected data sources
            </Typography>
          </Box>
        ) : selection.type === 'fileId' ? (
          <DataGridViewer
            key={selection.id}
            fileId={selection.id}
            title={selection.name}
            embedded
          />
        ) : (
          <DataGridViewer
            key={selection.path}
            filePath={selection.path}
            connectionId={selection.connectionId}
            title={selection.name}
            embedded
          />
        )}
      </Box>
    </Box>
  );
};

export default FilePreviewPage;
