import React from 'react';
import { useNotifications } from '../context/NotificationContext';
import { Snackbar, Alert, Box } from '@mui/material';

const NotificationCenter = () => {
  const { notifications, removeNotification } = useNotifications();

  // Show up to 3 most recent notifications stacked at bottom-right
  return (
    <>
      {notifications.slice(-3).map((n, i) => (
        <Snackbar
          key={n.id}
          open
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          sx={{ bottom: { xs: 24 + i * 76 } }}
          autoHideDuration={n.type === 'error' ? null : 5000}
          onClose={() => removeNotification(n.id)}
        >
          <Alert
            onClose={() => removeNotification(n.id)}
            severity={n.type === 'info' ? 'info' : n.type}
            variant="filled"
            sx={{ width: '100%', minWidth: 300, maxWidth: 440 }}
          >
            <strong>{n.title}</strong>
            {n.message && (
              <Box sx={{ mt: 0.25, fontSize: '0.8125rem', opacity: 0.92 }}>{n.message}</Box>
            )}
          </Alert>
        </Snackbar>
      ))}
    </>
  );
};

export default NotificationCenter;
