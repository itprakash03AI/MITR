/**
 * Scheduled Downloads Page
 *
 * Lists all schedules with live status.
 * Create / edit dialog: source picker, trigger config, param values, filename template.
 * Row actions: pause, resume, run now, edit, delete.
 * WebSocket: listens for scheduled_job_started / scheduled_job_completed / scheduled_job_failed.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControl, FormControlLabel, Grid, IconButton,
  InputLabel, MenuItem, Paper, Select, Switch, Tab, Tabs, TextField, Tooltip,
  Typography, Table, TableBody, TableCell, TableHead, TableRow, TableContainer,
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  PlayArrow as RunNowIcon, Pause as PauseIcon, PlayCircle as ResumeIcon,
  Refresh as RefreshIcon, Schedule as ScheduleIcon, Close as CloseIcon,
  CheckCircle as SuccessIcon, Error as FailIcon, RadioButtonUnchecked as IdleIcon,
  InfoOutlined as InfoIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';

// ─── Helpers ──────────────────────────────────────────────────────────────

const fmtDate = (iso) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' }); }
  catch { return iso; }
};

const statusChip = (s) => {
  if (!s) return <Chip label="Never run" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
  if (s === 'success') return <Chip icon={<SuccessIcon sx={{ fontSize: '14px !important' }} />} label="Success" color="success" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
  if (s === 'failed')  return <Chip icon={<FailIcon sx={{ fontSize: '14px !important' }} />}    label="Failed"  color="error"   size="small" variant="outlined" sx={{ fontSize: 10 }} />;
  return <Chip label={s} size="small" variant="outlined" sx={{ fontSize: 10 }} />;
};

const triggerLabel = (tc) => {
  if (!tc) return '—';
  if (tc.type === 'cron')     return `Cron: ${tc.cron_expr}`;
  if (tc.type === 'interval') {
    const parts = [];
    if (tc.hours)   parts.push(`${tc.hours}h`);
    if (tc.minutes) parts.push(`${tc.minutes}m`);
    if (tc.seconds) parts.push(`${tc.seconds}s`);
    return `Every ${parts.join(' ')}`;
  }
  return JSON.stringify(tc);
};

// ─── TriggerForm ──────────────────────────────────────────────────────────

function TriggerForm({ trigger, onChange }) {
  return (
    <Box>
      <FormControl size="small" sx={{ minWidth: 160, mr: 2, mb: 1 }}>
        <InputLabel>Trigger Type</InputLabel>
        <Select
          label="Trigger Type" value={trigger.type}
          onChange={e => onChange({ ...trigger, type: e.target.value, cron_expr: '', minutes: '', hours: '', seconds: '' })}
        >
          <MenuItem value="cron">Cron expression</MenuItem>
          <MenuItem value="interval">Interval (every N minutes/hours)</MenuItem>
        </Select>
      </FormControl>

      {trigger.type === 'cron' && (
        <TextField
          label="Cron expression" size="small" sx={{ minWidth: 200 }}
          value={trigger.cron_expr || ''}
          onChange={e => onChange({ ...trigger, cron_expr: e.target.value })}
          helperText='e.g. "0 8 * * 1-5" = weekdays at 08:00 UTC'
          placeholder="0 8 * * 1-5"
        />
      )}

      {trigger.type === 'interval' && (
        <Grid container spacing={1} sx={{ maxWidth: 400 }}>
          <Grid item xs={4}>
            <TextField
              label="Hours" type="number" size="small" fullWidth
              inputProps={{ min: 0 }}
              value={trigger.hours || ''}
              onChange={e => onChange({ ...trigger, hours: e.target.value ? Number(e.target.value) : '' })}
            />
          </Grid>
          <Grid item xs={4}>
            <TextField
              label="Minutes" type="number" size="small" fullWidth
              inputProps={{ min: 0 }}
              value={trigger.minutes || ''}
              onChange={e => onChange({ ...trigger, minutes: e.target.value ? Number(e.target.value) : '' })}
            />
          </Grid>
          <Grid item xs={4}>
            <TextField
              label="Seconds" type="number" size="small" fullWidth
              inputProps={{ min: 0 }}
              value={trigger.seconds || ''}
              onChange={e => onChange({ ...trigger, seconds: e.target.value ? Number(e.target.value) : '' })}
            />
          </Grid>
        </Grid>
      )}
    </Box>
  );
}

// ─── ParamValueFields — for schedule param_values ─────────────────────────

function ParamValueFields({ schema, values, onChange }) {
  if (!schema || schema.length === 0)
    return <Typography variant="caption" color="text.disabled">No parameters defined for this source.</Typography>;

  return (
    <Grid container spacing={1.5}>
      {schema.map(p => (
        <Grid item xs={12} sm={6} key={p.name}>
          <TextField
            label={`${p.label || p.name}${p.required ? ' *' : ''}`}
            size="small" fullWidth
            value={values[p.name] ?? p.default_value ?? ''}
            onChange={e => onChange({ ...values, [p.name]: e.target.value })}
            helperText={p.description || undefined}
          />
        </Grid>
      ))}
    </Grid>
  );
}

// ─── ScheduleDialog — create or edit ─────────────────────────────────────

function ScheduleDialog({ open, onClose, onSaved, initialData, savedQueries, sqlQueries, reports }) {
  const isEdit = !!initialData;
  const blankTrigger = { type: 'cron', cron_expr: '', hours: '', minutes: '', seconds: '' };

  const [form, setForm] = useState({
    name: '', description: '', source_type: 'saved_query', source_id: '',
    param_values: {}, trigger_config: blankTrigger,
    output_filename_template: '{name}_{date}.csv',
  });
  const [sourceSchema, setSourceSchema] = useState([]);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [tab, setTab] = useState(0);

  useEffect(() => {
    if (!open) return;
    if (initialData) {
      setForm({
        name:        initialData.name || '',
        description: initialData.description || '',
        source_type: initialData.source_type || 'saved_query',
        source_id:   initialData.source_id || '',
        param_values: initialData.param_values || {},
        trigger_config: initialData.trigger_config || blankTrigger,
        output_filename_template: initialData.output_filename_template || '{name}_{date}.csv',
      });
    } else {
      setForm({ name: '', description: '', source_type: 'saved_query', source_id: '', param_values: {}, trigger_config: blankTrigger, output_filename_template: '{name}_{date}.csv' });
    }
    setErr('');
    setTab(0);
  }, [open, initialData]);

  // Load param schema when source changes
  useEffect(() => {
    if (!form.source_id) { setSourceSchema([]); return; }
    if (form.source_type === 'report') {
      const r = reports.find(x => String(x.id) === String(form.source_id));
      setSourceSchema(r?.parameters || []);
    } else {
      setSourceSchema([]);
    }
  }, [form.source_type, form.source_id, reports]);

  const sourceList = () => {
    if (form.source_type === 'saved_query') return savedQueries;
    if (form.source_type === 'sql_query')   return sqlQueries;
    if (form.source_type === 'report')      return reports;
    return [];
  };

  const handleSave = async () => {
    if (!form.name.trim()) { setErr('Name is required'); return; }
    if (!form.source_id)   { setErr('Select a source'); return; }
    setSaving(true); setErr('');
    try {
      const tc = { ...form.trigger_config };
      // Cleanup empty interval fields
      if (tc.type === 'interval') {
        if (!tc.hours)   delete tc.hours;
        if (!tc.minutes) delete tc.minutes;
        if (!tc.seconds) delete tc.seconds;
        delete tc.cron_expr;
      } else {
        delete tc.hours; delete tc.minutes; delete tc.seconds;
      }
      const payload = {
        name:                     form.name,
        description:              form.description || null,
        source_type:              form.source_type,
        source_id:                Number(form.source_id),
        param_values:             form.param_values || {},
        trigger_config:           tc,
        output_filename_template: form.output_filename_template || null,
      };
      if (isEdit) {
        await api.updateSchedule(initialData.id, payload);
      } else {
        await api.createSchedule(payload);
      }
      onSaved();
    } catch (e) {
      setErr(e.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ pb: 0 }}>
        {isEdit ? 'Edit Schedule' : 'Create Schedule'}
        <IconButton onClick={onClose} sx={{ position: 'absolute', right: 8, top: 8 }}><CloseIcon /></IconButton>
      </DialogTitle>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ px: 3, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Tab label="Source & Trigger" />
        <Tab label="Parameters & Output" />
      </Tabs>
      <DialogContent dividers sx={{ minHeight: 320 }}>
        <Collapse in={!!err}><Alert severity="error" sx={{ mb: 2 }}>{err}</Alert></Collapse>

        {tab === 0 && (
          <Grid container spacing={2}>
            <Grid item xs={8}>
              <TextField
                label="Schedule Name" size="small" fullWidth required
                value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              />
            </Grid>
            <Grid item xs={4}>
              <FormControl size="small" fullWidth>
                <InputLabel>Source Type</InputLabel>
                <Select
                  label="Source Type" value={form.source_type}
                  onChange={e => setForm(f => ({ ...f, source_type: e.target.value, source_id: '' }))}
                >
                  <MenuItem value="saved_query">Parquet Saved Query</MenuItem>
                  <MenuItem value="sql_query">SQL Saved Query</MenuItem>
                  <MenuItem value="report">Parametric Report</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Description" size="small" fullWidth multiline rows={1}
                value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl size="small" fullWidth>
                <InputLabel>Source *</InputLabel>
                <Select
                  label="Source *" value={form.source_id}
                  onChange={e => setForm(f => ({ ...f, source_id: e.target.value }))}
                >
                  {sourceList().map(q => (
                    <MenuItem key={q.id} value={q.id}>{q.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>Trigger</Typography>
              <TriggerForm
                trigger={form.trigger_config}
                onChange={tc => setForm(f => ({ ...f, trigger_config: tc }))}
              />
            </Grid>
          </Grid>
        )}

        {tab === 1 && (
          <Grid container spacing={2}>
            {sourceSchema.length > 0 && (
              <Grid item xs={12}>
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>Parameter Values</Typography>
                <ParamValueFields
                  schema={sourceSchema}
                  values={form.param_values}
                  onChange={pv => setForm(f => ({ ...f, param_values: pv }))}
                />
              </Grid>
            )}
            {sourceSchema.length === 0 && (
              <Grid item xs={12}>
                <Alert severity="info" icon={<InfoIcon />}>
                  No parameters for this source — output will be generated without substitution.
                </Alert>
              </Grid>
            )}
            <Grid item xs={12}>
              <TextField
                label="Output Filename Template" size="small" fullWidth
                value={form.output_filename_template}
                onChange={e => setForm(f => ({ ...f, output_filename_template: e.target.value }))}
                helperText='Use {name} for schedule name, {date} for YYYYMMDD_HHMMSS timestamp'
              />
            </Grid>
          </Grid>
        )}
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}
          startIcon={saving ? <CircularProgress size={14} /> : null}
        >
          {isEdit ? 'Update' : 'Create Schedule'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────

export default function SchedulesPage() {
  const { lastMessage } = useWebSocket();

  const [schedules, setSchedules] = useState([]);
  const [savedQueries, setSavedQueries] = useState([]);
  const [sqlQueries, setSqlQueries] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [schedulerStatus, setSchedulerStatus] = useState(null);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Per-row live status overlay from WS
  const [liveStatus, setLiveStatus] = useState({});  // { schedule_id: 'running' | 'completed' | 'failed' }

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [scheds, sqs, sqls, rpts, status] = await Promise.all([
        api.listSchedules(false),
        api.listQueries(true),
        api.listSqlQueries(true),
        api.listReports(false),
        api.getSchedulerStatus(),
      ]);
      setSchedules(scheds);
      setSavedQueries(sqs);
      setSqlQueries(sqls);
      setReports(rpts);
      setSchedulerStatus(status);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // WS live updates
  useEffect(() => {
    if (!lastMessage) return;
    const { type, schedule_id } = lastMessage;
    if (!schedule_id) return;
    if (type === 'scheduled_job_started') {
      setLiveStatus(s => ({ ...s, [schedule_id]: 'running' }));
    } else if (type === 'scheduled_job_completed') {
      setLiveStatus(s => ({ ...s, [schedule_id]: 'completed' }));
      // Refresh after a second so next_run_at updates
      setTimeout(load, 1200);
    } else if (type === 'scheduled_job_failed') {
      setLiveStatus(s => ({ ...s, [schedule_id]: 'failed' }));
      setTimeout(load, 1200);
    }
  }, [lastMessage, load]);

  const handlePause = async (s) => {
    try { await api.pauseSchedule(s.id); load(); }
    catch (e) { alert(`Pause failed: ${e.message}`); }
  };

  const handleResume = async (s) => {
    try { await api.resumeSchedule(s.id); load(); }
    catch (e) { alert(`Resume failed: ${e.message}`); }
  };

  const handleRunNow = async (s) => {
    try {
      await api.runScheduleNow(s.id);
      setLiveStatus(ls => ({ ...ls, [s.id]: 'running' }));
    } catch (e) { alert(`Run failed: ${e.message}`); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try { await api.deleteSchedule(deleteTarget.id); setDeleteTarget(null); load(); }
    catch (e) { alert(e.message); }
  };

  const sourceTypeLabel = (t) => {
    if (t === 'saved_query') return 'Parquet';
    if (t === 'sql_query')   return 'SQL';
    if (t === 'report')      return 'Report';
    return t;
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>

      {/* ── Header ───────────────────────────────────────────────────── */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2.5, gap: 2 }}>
        <ScheduleIcon color="primary" />
        <Typography variant="h6" sx={{ fontWeight: 700, flex: 1 }}>Scheduled Downloads</Typography>

        {schedulerStatus && (
          <Chip
            label={schedulerStatus.running ? `Scheduler running · ${schedulerStatus.total_jobs} job(s)` : 'Scheduler offline'}
            color={schedulerStatus.running ? 'success' : 'default'}
            size="small" variant="outlined"
          />
        )}

        <Tooltip title="Refresh">
          <IconButton onClick={load} disabled={loading}><RefreshIcon /></IconButton>
        </Tooltip>
        <Button
          variant="contained" startIcon={<AddIcon />}
          onClick={() => { setEditTarget(null); setDialogOpen(true); }}
        >
          New Schedule
        </Button>
      </Box>

      {/* ── Table ─────────────────────────────────────────────────────── */}
      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ bgcolor: 'grey.50' }}>
              <TableCell sx={{ fontWeight: 600, width: 200 }}>Name</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 90 }}>Source</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Trigger</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 140 }}>Next Run</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 140 }}>Last Run</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 100 }}>Status</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 60, textAlign: 'center' }}>Runs</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 60 }}>Active</TableCell>
              <TableCell sx={{ fontWeight: 600, width: 180 }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={9} sx={{ textAlign: 'center', py: 4 }}>
                  <CircularProgress size={24} />
                </TableCell>
              </TableRow>
            ) : schedules.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="body2" color="text.secondary">No schedules yet. Click "New Schedule" to create one.</Typography>
                </TableCell>
              </TableRow>
            ) : (
              schedules.map(s => {
                const live = liveStatus[s.id];
                return (
                  <TableRow key={s.id} hover>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>{s.name}</Typography>
                      {s.description && (
                        <Typography variant="caption" color="text.secondary">{s.description}</Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Chip label={sourceTypeLabel(s.source_type)} size="small" variant="outlined" sx={{ fontSize: 10, height: 20 }} />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
                        {triggerLabel(s.trigger_config)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{fmtDate(s.next_run_at)}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{fmtDate(s.last_run_at)}</Typography>
                    </TableCell>
                    <TableCell>
                      {live === 'running' ? (
                        <Chip icon={<CircularProgress size={10} />} label="Running" color="info" size="small" variant="outlined" sx={{ fontSize: 10 }} />
                      ) : live === 'completed' ? (
                        <Chip label="Just ran" color="success" size="small" variant="outlined" sx={{ fontSize: 10 }} />
                      ) : live === 'failed' ? (
                        <Chip label="Failed" color="error" size="small" variant="outlined" sx={{ fontSize: 10 }} />
                      ) : (
                        statusChip(s.last_run_status)
                      )}
                      {s.last_error && !live && (
                        <Tooltip title={s.last_error} placement="top">
                          <InfoIcon sx={{ fontSize: 14, color: 'error.main', ml: 0.5, verticalAlign: 'middle' }} />
                        </Tooltip>
                      )}
                    </TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>
                      <Typography variant="caption">{s.run_count ?? 0}</Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={s.is_active ? 'Active' : 'Paused'}
                        color={s.is_active ? 'success' : 'default'}
                        size="small" variant="outlined"
                        sx={{ fontSize: 10, height: 20 }}
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 0.25 }}>
                        {s.is_active ? (
                          <Tooltip title="Pause">
                            <IconButton size="small" onClick={() => handlePause(s)}>
                              <PauseIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        ) : (
                          <Tooltip title="Resume">
                            <IconButton size="small" color="success" onClick={() => handleResume(s)}>
                              <ResumeIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                        <Tooltip title="Run Now">
                          <IconButton size="small" color="primary" onClick={() => handleRunNow(s)}
                            disabled={live === 'running'}
                          >
                            <RunNowIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => { setEditTarget(s); setDialogOpen(true); }}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" color="error" onClick={() => setDeleteTarget(s)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* ── Create / Edit dialog ─────────────────────────────────────── */}
      <ScheduleDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSaved={() => { setDialogOpen(false); load(); }}
        initialData={editTarget}
        savedQueries={savedQueries}
        sqlQueries={sqlQueries}
        reports={reports}
      />

      {/* ── Delete confirm ────────────────────────────────────────────── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs">
        <DialogTitle>Delete Schedule?</DialogTitle>
        <DialogContent>
          <Typography>
            Delete <strong>{deleteTarget?.name}</strong>?
            This will remove the scheduled job permanently.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
