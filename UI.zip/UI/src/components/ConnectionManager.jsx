import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, IconButton, Chip, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Alert, CircularProgress, Tooltip, Stack,
  Divider, InputAdornment, FormHelperText,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  PlayArrow as TestIcon,
  Storage as StorageIcon,
  Folder as FolderIcon,
  CloudQueue as CloudIcon,
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
  Refresh as RefreshIcon,
  Terminal as SqlIcon,
  Visibility as VisibleIcon,
  VisibilityOff as HiddenIcon,
} from '@mui/icons-material';
import api from '../services/api';

// ── Connection type metadata ──────────────────────────────────────────────────
const CONN_TYPE_META = {
  s3:         { label: 'AWS S3 Bucket',   icon: <CloudIcon fontSize="small" />,  color: '#f59e0b' },
  local:      { label: 'Local Folder',    icon: <FolderIcon fontSize="small" />, color: '#6366f1' },
  trino:      { label: 'Trino',           icon: <SqlIcon fontSize="small" />,    color: '#3b82f6' },
  starburst:  { label: 'Starburst',       icon: <SqlIcon fontSize="small" />,    color: '#f97316' },
  snowflake:  { label: 'Snowflake',       icon: <SqlIcon fontSize="small" />,    color: '#22d3ee' },
  databricks: { label: 'Databricks SQL',  icon: <SqlIcon fontSize="small" />,    color: '#ef4444' },
};

const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks'];

const EMPTY_CONFIGS = {
  s3:         { bucket_name: '', region_name: 'us-east-1', aws_access_key_id: '', aws_secret_access_key: '', endpoint_url: '' },
  local:      { base_path: '' },
  trino:      { host: '', port: 443, user: '', auth_type: 'basic', password: '', token: '', catalog: '', schema: '', http_scheme: 'https', verify_ssl: true },
  starburst:  { host: '', port: 443, user: '', auth_type: 'basic', password: '', token: '', catalog: '', schema: '', http_scheme: 'https', verify_ssl: true },
  snowflake:  { account: '', user: '', auth_type: 'password', password: '', private_key: '', private_key_passphrase: '', token: '', warehouse: '', database: '', schema: '', role: '' },
  databricks: { server_hostname: '', http_path: '', access_token: '', catalog: '', schema: '' },
};

const AWS_REGIONS = [
  { value: 'us-east-1',      label: 'US East (N. Virginia)' },
  { value: 'us-east-2',      label: 'US East (Ohio)' },
  { value: 'us-west-1',      label: 'US West (N. California)' },
  { value: 'us-west-2',      label: 'US West (Oregon)' },
  { value: 'eu-west-1',      label: 'EU (Ireland)' },
  { value: 'eu-central-1',   label: 'EU (Frankfurt)' },
  { value: 'ap-south-1',     label: 'Asia Pacific (Mumbai)' },
  { value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' },
  { value: 'ap-northeast-1', label: 'Asia Pacific (Tokyo)' },
];

// ── Password field with show/hide toggle ─────────────────────────────────────
const PasswordField = ({ label, value, onChange, required, placeholder, helperText }) => {
  const [show, setShow] = useState(false);
  return (
    <TextField
      label={label}
      fullWidth
      size="small"
      type={show ? 'text' : 'password'}
      value={value}
      onChange={e => onChange(e.target.value)}
      required={required}
      placeholder={placeholder}
      helperText={helperText}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton size="small" onClick={() => setShow(v => !v)} edge="end">
              {show ? <HiddenIcon sx={{ fontSize: 18 }} /> : <VisibleIcon sx={{ fontSize: 18 }} />}
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};

// ── Section header ─────────────────────────────────────────────────────────────
const SectionLabel = ({ children }) => (
  <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 0.5, mt: 0.5 }}>
    {children}
  </Typography>
);

// ── S3 Config Form ─────────────────────────────────────────────────────────────
const S3Form = ({ config, onChange }) => (
  <Stack spacing={2}>
    <SectionLabel>Bucket Configuration</SectionLabel>
    <TextField
      label="Bucket Name" fullWidth required size="small"
      value={config.bucket_name || ''}
      onChange={e => onChange('bucket_name', e.target.value)}
      placeholder="my-parquet-bucket"
    />
    <TextField
      select label="AWS Region" fullWidth size="small"
      value={config.region_name || 'us-east-1'}
      onChange={e => onChange('region_name', e.target.value)}
    >
      {AWS_REGIONS.map(r => <MenuItem key={r.value} value={r.value}>{r.label}</MenuItem>)}
    </TextField>
    <SectionLabel>Credentials (optional — leave blank for IAM role)</SectionLabel>
    <TextField
      label="AWS Access Key ID" fullWidth size="small"
      value={config.aws_access_key_id || ''}
      onChange={e => onChange('aws_access_key_id', e.target.value)}
      placeholder="AKIAIOSFODNN7EXAMPLE"
    />
    <PasswordField
      label="AWS Secret Access Key"
      value={config.aws_secret_access_key || ''}
      onChange={v => onChange('aws_secret_access_key', v)}
    />
    <TextField
      label="Custom Endpoint URL" fullWidth size="small"
      value={config.endpoint_url || ''}
      onChange={e => onChange('endpoint_url', e.target.value)}
      placeholder="https://s3.custom-endpoint.com"
      helperText="For S3-compatible storage (MinIO, Ceph, etc.)"
    />
  </Stack>
);

// ── Local Folder Form ─────────────────────────────────────────────────────────
const LocalForm = ({ config, onChange }) => (
  <Stack spacing={2}>
    <TextField
      label="Folder Path" fullWidth required size="small"
      value={config.base_path || ''}
      onChange={e => onChange('base_path', e.target.value)}
      placeholder="/data/parquet or C:\Data\Parquet"
      helperText="Absolute path to the folder containing .parquet files"
    />
  </Stack>
);

// ── Trino / Starburst Config Form ─────────────────────────────────────────────
const TrinoForm = ({ config, onChange, connType }) => {
  const authType = config.auth_type || 'basic';
  return (
    <Stack spacing={2}>
      <SectionLabel>Connection</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Host" required size="small" sx={{ flex: 1 }}
          value={config.host || ''}
          onChange={e => onChange('host', e.target.value)}
          placeholder={connType === 'starburst' ? 'galaxy.starburstdata.com' : 'trino.company.com'}
        />
        <TextField
          label="Port" required size="small" type="number" sx={{ width: 120 }}
          value={config.port ?? 443}
          onChange={e => onChange('port', Number(e.target.value))}
        />
      </Box>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          select label="HTTP Scheme" size="small" sx={{ width: 120 }}
          value={config.http_scheme || 'https'}
          onChange={e => onChange('http_scheme', e.target.value)}
        >
          <MenuItem value="https">HTTPS</MenuItem>
          <MenuItem value="http">HTTP</MenuItem>
        </TextField>
        <TextField
          select label="Verify SSL" size="small" sx={{ width: 130 }}
          value={config.verify_ssl === false ? 'false' : 'true'}
          onChange={e => onChange('verify_ssl', e.target.value === 'true')}
        >
          <MenuItem value="true">Yes (secure)</MenuItem>
          <MenuItem value="false">No (skip)</MenuItem>
        </TextField>
      </Box>

      <SectionLabel>Authentication</SectionLabel>
      <TextField
        label="Username" required size="small" fullWidth
        value={config.user || ''}
        onChange={e => onChange('user', e.target.value)}
        placeholder="admin"
      />
      <TextField
        select label="Auth Type" size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
      >
        <MenuItem value="none">None</MenuItem>
        <MenuItem value="basic">Basic (username + password)</MenuItem>
        <MenuItem value="jwt">JWT Token</MenuItem>
        <MenuItem value="kerberos">Kerberos</MenuItem>
        <MenuItem value="oauth2">OAuth2</MenuItem>
      </TextField>
      {authType === 'basic' && (
        <PasswordField
          label="Password" required
          value={config.password || ''}
          onChange={v => onChange('password', v)}
        />
      )}
      {authType === 'jwt' && (
        <PasswordField
          label="JWT Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
          placeholder="eyJhbGciOiJSUzI1NiJ9..."
        />
      )}
      {authType === 'kerberos' && (
        <Alert severity="info" sx={{ py: 0.5, fontSize: 13 }}>
          Kerberos auth uses the host principal from the server. Ensure kinit is configured in the runtime environment.
        </Alert>
      )}
      {authType === 'oauth2' && (
        <PasswordField
          label="OAuth2 Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
        />
      )}

      <SectionLabel>Default Catalog / Schema (optional)</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Default Catalog" size="small" sx={{ flex: 1 }}
          value={config.catalog || ''}
          onChange={e => onChange('catalog', e.target.value)}
          placeholder="hive"
        />
        <TextField
          label="Default Schema" size="small" sx={{ flex: 1 }}
          value={config.schema || ''}
          onChange={e => onChange('schema', e.target.value)}
          placeholder="default"
        />
      </Box>
    </Stack>
  );
};

// ── Snowflake Config Form ─────────────────────────────────────────────────────
const SnowflakeForm = ({ config, onChange }) => {
  const authType = config.auth_type || 'password';
  return (
    <Stack spacing={2}>
      <SectionLabel>Account</SectionLabel>
      <TextField
        label="Account Identifier" required size="small" fullWidth
        value={config.account || ''}
        onChange={e => onChange('account', e.target.value)}
        placeholder="xy12345.us-east-1"
        helperText="From Snowflake URL: https://<account>.snowflakecomputing.com"
      />
      <TextField
        label="Username" required size="small" fullWidth
        value={config.user || ''}
        onChange={e => onChange('user', e.target.value)}
        placeholder="JOHN.DOE@company.com"
      />

      <SectionLabel>Authentication</SectionLabel>
      <TextField
        select label="Auth Type" size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
      >
        <MenuItem value="password">Password</MenuItem>
        <MenuItem value="key_pair">Key Pair (RSA)</MenuItem>
        <MenuItem value="oauth">OAuth Token</MenuItem>
      </TextField>
      {authType === 'password' && (
        <PasswordField
          label="Password" required
          value={config.password || ''}
          onChange={v => onChange('password', v)}
        />
      )}
      {authType === 'key_pair' && (
        <>
          <TextField
            label="Private Key (PEM)" fullWidth size="small" multiline rows={5}
            value={config.private_key || ''}
            onChange={e => onChange('private_key', e.target.value)}
            placeholder={'-----BEGIN RSA PRIVATE KEY-----\n...\n-----END RSA PRIVATE KEY-----'}
            inputProps={{ style: { fontFamily: 'monospace', fontSize: 12 } }}
            helperText="Paste the full PEM content of your RSA private key"
          />
          <PasswordField
            label="Key Passphrase (if encrypted)"
            value={config.private_key_passphrase || ''}
            onChange={v => onChange('private_key_passphrase', v)}
          />
        </>
      )}
      {authType === 'oauth' && (
        <PasswordField
          label="OAuth Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
        />
      )}

      <SectionLabel>Warehouse & Database (optional)</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Warehouse" size="small" sx={{ flex: 1 }}
          value={config.warehouse || ''}
          onChange={e => onChange('warehouse', e.target.value)}
          placeholder="COMPUTE_WH"
        />
        <TextField
          label="Role" size="small" sx={{ flex: 1 }}
          value={config.role || ''}
          onChange={e => onChange('role', e.target.value)}
          placeholder="SYSADMIN"
        />
      </Box>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Database" size="small" sx={{ flex: 1 }}
          value={config.database || ''}
          onChange={e => onChange('database', e.target.value)}
          placeholder="MY_DATABASE"
        />
        <TextField
          label="Default Schema" size="small" sx={{ flex: 1 }}
          value={config.schema || ''}
          onChange={e => onChange('schema', e.target.value)}
          placeholder="PUBLIC"
        />
      </Box>
    </Stack>
  );
};

// ── Databricks Config Form ────────────────────────────────────────────────────
const DatabricksForm = ({ config, onChange }) => (
  <Stack spacing={2}>
    <SectionLabel>SQL Warehouse</SectionLabel>
    <TextField
      label="Server Hostname" required size="small" fullWidth
      value={config.server_hostname || ''}
      onChange={e => onChange('server_hostname', e.target.value)}
      placeholder="adb-1234567890123456.12.azuredatabricks.net"
      helperText="Found in: SQL Warehouse → Connection Details → Server hostname"
    />
    <TextField
      label="HTTP Path" required size="small" fullWidth
      value={config.http_path || ''}
      onChange={e => onChange('http_path', e.target.value)}
      placeholder="/sql/1.0/warehouses/abc123def456"
      helperText="Found in: SQL Warehouse → Connection Details → HTTP path"
    />
    <SectionLabel>Authentication</SectionLabel>
    <PasswordField
      label="Personal Access Token" required
      value={config.access_token || ''}
      onChange={v => onChange('access_token', v)}
      placeholder="dapiXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
      helperText="Generate at: Settings → Developer → Access tokens"
    />
    <SectionLabel>Catalog / Schema (optional)</SectionLabel>
    <Box sx={{ display: 'flex', gap: 1 }}>
      <TextField
        label="Default Catalog" size="small" sx={{ flex: 1 }}
        value={config.catalog || ''}
        onChange={e => onChange('catalog', e.target.value)}
        placeholder="main"
        helperText="Leave blank for legacy hive_metastore"
      />
      <TextField
        label="Default Schema" size="small" sx={{ flex: 1 }}
        value={config.schema || ''}
        onChange={e => onChange('schema', e.target.value)}
        placeholder="default"
      />
    </Box>
  </Stack>
);

// ── Connection type display chip ──────────────────────────────────────────────
const TypeChip = ({ type }) => {
  const meta = CONN_TYPE_META[type] || { label: type, icon: <StorageIcon fontSize="small" />, color: '#888' };
  return (
    <Chip
      icon={React.cloneElement(meta.icon, { style: { color: 'white', fontSize: 14 } })}
      label={meta.label}
      size="small"
      variant="filled"
      sx={{ bgcolor: meta.color, color: 'white', fontWeight: 600, '& .MuiChip-icon': { color: 'white' } }}
    />
  );
};

// ── Connection detail summary ─────────────────────────────────────────────────
const connDetail = (conn) => {
  const c = conn.config || {};
  switch (conn.connection_type) {
    case 's3':         return `s3://${c.bucket_name || '—'}  ·  ${c.region_name || '—'}`;
    case 'local':      return c.base_path || '—';
    case 'trino':
    case 'starburst':  return `${c.http_scheme || 'https'}://${c.host || '—'}:${c.port || ''}  ·  ${c.user || '—'}`;
    case 'snowflake':  return `${c.account || '—'}.snowflakecomputing.com  ·  ${c.user || '—'}`;
    case 'databricks': return `${c.server_hostname || '—'}  ·  ${c.http_path || '—'}`;
    default:           return '—';
  }
};

// ══════════════════════════════════════════════════════════════════════════════
// Main component
// ══════════════════════════════════════════════════════════════════════════════
const ConnectionManager = () => {
  const [connections, setConnections] = useState([]);
  const [loading, setLoading]         = useState(true);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId]   = useState(null);
  const [form, setForm]             = useState({ name: '', connection_type: 's3', config: { ...EMPTY_CONFIGS.s3 } });
  const [saving, setSaving]         = useState(false);
  const [formError, setFormError]   = useState('');

  const [testResult, setTestResult] = useState(null);
  const [testing, setTesting]       = useState(null);   // null | 'dialog' | conn.id

  const [deleteTarget, setDeleteTarget] = useState(null);

  const loadConnections = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listConnections();
      setConnections(data || []);
    } catch { /* silent */ }
    setLoading(false);
  }, []);

  useEffect(() => { loadConnections(); }, [loadConnections]);

  const openCreate = () => {
    setEditingId(null);
    setForm({ name: '', connection_type: 's3', config: { ...EMPTY_CONFIGS.s3 } });
    setTestResult(null);
    setFormError('');
    setDialogOpen(true);
  };

  const openEdit = (conn) => {
    setEditingId(conn.id);
    const empty = EMPTY_CONFIGS[conn.connection_type] || {};
    setForm({ name: conn.name, connection_type: conn.connection_type, config: { ...empty, ...conn.config } });
    setTestResult(null);
    setFormError('');
    setDialogOpen(true);
  };

  const handleTypeChange = (newType) => {
    setForm(prev => ({ ...prev, connection_type: newType, config: { ...(EMPTY_CONFIGS[newType] || {}) } }));
    setTestResult(null);
    setFormError('');
  };

  const updateConfig = (key, value) => {
    setForm(prev => ({ ...prev, config: { ...prev.config, [key]: value } }));
    setTestResult(null);
  };

  const validateForm = () => {
    const { connection_type: ct, config: c } = form;
    if (!form.name.trim()) return 'Connection name is required';
    if (ct === 's3'    && !c.bucket_name?.trim())    return 'Bucket name is required';
    if (ct === 'local' && !c.base_path?.trim())      return 'Folder path is required';
    if ((ct === 'trino' || ct === 'starburst') && !c.host?.trim()) return 'Host is required';
    if ((ct === 'trino' || ct === 'starburst') && !c.user?.trim()) return 'Username is required';
    if (ct === 'snowflake'  && !c.account?.trim())  return 'Account identifier is required';
    if (ct === 'snowflake'  && !c.user?.trim())     return 'Username is required';
    if (ct === 'databricks' && !c.server_hostname?.trim()) return 'Server hostname is required';
    if (ct === 'databricks' && !c.http_path?.trim())       return 'HTTP path is required';
    if (ct === 'databricks' && !c.access_token?.trim())    return 'Access token is required';
    return null;
  };

  const handleTestInDialog = async () => {
    const err = validateForm();
    if (err) { setFormError(err); return; }
    setTesting('dialog');
    setTestResult(null);
    setFormError('');
    try {
      const r = await api.testConnection({ connection_type: form.connection_type, config: form.config });
      setTestResult(r);
    } catch (e) {
      setTestResult({ success: false, message: e.message });
    }
    setTesting(null);
  };

  const handleSave = async () => {
    const err = validateForm();
    if (err) { setFormError(err); return; }
    setSaving(true);
    setFormError('');
    try {
      if (editingId) {
        await api.updateConnection(editingId, form);
      } else {
        await api.createConnection(form);
      }
      setDialogOpen(false);
      loadConnections();
    } catch (e) {
      setFormError(e.message || 'Failed to save connection');
    }
    setSaving(false);
  };

  const handleTestSaved = async (conn) => {
    setTesting(conn.id);
    try {
      // POST /api/connections/{id}/test handles all types (S3, local, SQL)
      // and updates last_test_status in DB so the status chip reflects the result
      await api.testSavedConnection(conn.id);
      loadConnections();
    } catch { loadConnections(); }
    setTesting(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try { await api.deleteConnection(deleteTarget.id); loadConnections(); } catch { /* empty */ }
    setDeleteTarget(null);
  };

  const { connection_type: ct } = form;
  const isSqlType = SQL_TYPES.includes(ct);

  return (
    <Box sx={{ p: 3, maxWidth: 1300, mx: 'auto' }}>

      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>Connection Manager</Typography>
          <Typography variant="subtitle2" color="text.secondary">
            Manage data source connections: S3, Local Folder, Trino/Starburst, Snowflake, Databricks
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadConnections}>Refresh</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>New Connection</Button>
        </Box>
      </Box>

      {/* Connection list */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}><CircularProgress /></Box>
      ) : connections.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <StorageIcon sx={{ fontSize: 56, color: 'text.secondary', mb: 2, opacity: 0.4 }} />
          <Typography variant="h6" gutterBottom>No connections yet</Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            Create your first connection to query data from S3, local files, or SQL warehouses.
          </Typography>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>Create Connection</Button>
        </Paper>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: 'grey.50' } }}>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Details</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Last Tested</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {connections.map(conn => (
                <TableRow key={conn.id} hover sx={{ '&:last-child td': { border: 0 } }}>
                  <TableCell>
                    <Typography fontWeight={600} variant="body2">{conn.name}</Typography>
                  </TableCell>
                  <TableCell><TypeChip type={conn.connection_type} /></TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary"
                      sx={{ fontFamily: 'monospace', fontSize: 12, maxWidth: 380, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {connDetail(conn)}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {conn.last_test_status === 'success' ? (
                      <Chip icon={<SuccessIcon />} label="Connected" size="small" color="success" variant="outlined" />
                    ) : conn.last_test_status === 'failed' ? (
                      <Tooltip title={conn.last_test_message || ''}>
                        <Chip icon={<ErrorIcon />} label="Failed" size="small" color="error" variant="outlined" />
                      </Tooltip>
                    ) : (
                      <Chip label="Untested" size="small" variant="outlined" />
                    )}
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary">
                      {conn.last_tested_at ? new Date(conn.last_tested_at).toLocaleString() : '—'}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="Test Connection">
                      <IconButton size="small" onClick={() => handleTestSaved(conn)} disabled={testing === conn.id}>
                        {testing === conn.id ? <CircularProgress size={16} /> : <TestIcon />}
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Edit">
                      <IconButton size="small" onClick={() => openEdit(conn)}>
                        <EditIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => setDeleteTarget(conn)}>
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* ── Create / Edit Dialog ── */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth
        PaperProps={{ sx: { maxHeight: '90vh' } }}>
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {isSqlType
              ? React.cloneElement(CONN_TYPE_META[ct]?.icon || <SqlIcon />, { sx: { color: CONN_TYPE_META[ct]?.color } })
              : (ct === 's3' ? <CloudIcon color="warning" /> : <FolderIcon color="primary" />)
            }
            <span>{editingId ? 'Edit Connection' : 'New Connection'}</span>
          </Box>
        </DialogTitle>

        <DialogContent dividers sx={{ overflowY: 'auto' }}>
          {formError && <Alert severity="error" sx={{ mb: 2 }}>{formError}</Alert>}

          <Stack spacing={2} sx={{ mt: 0.5 }}>

            {/* Name */}
            <TextField
              label="Connection Name" fullWidth required size="small"
              value={form.name}
              onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
              placeholder="e.g. Prod Starburst"
            />

            {/* Type selector */}
            <TextField
              select label="Connection Type" fullWidth size="small"
              value={ct}
              onChange={e => handleTypeChange(e.target.value)}
            >
              <MenuItem value="s3">
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <CloudIcon fontSize="small" sx={{ color: '#f59e0b' }} /> AWS S3 Bucket
                </Box>
              </MenuItem>
              <MenuItem value="local">
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <FolderIcon fontSize="small" sx={{ color: '#6366f1' }} /> Local Folder
                </Box>
              </MenuItem>
              <Divider />
              <MenuItem disabled sx={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, opacity: 0.6 }}>
                SQL Warehouses
              </MenuItem>
              {['trino', 'starburst', 'snowflake', 'databricks'].map(t => (
                <MenuItem key={t} value={t}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <SqlIcon fontSize="small" sx={{ color: CONN_TYPE_META[t]?.color }} />
                    {CONN_TYPE_META[t]?.label}
                  </Box>
                </MenuItem>
              ))}
            </TextField>

            <Divider />

            {/* Config form per type */}
            {ct === 's3'        && <S3Form       config={form.config} onChange={updateConfig} />}
            {ct === 'local'     && <LocalForm    config={form.config} onChange={updateConfig} />}
            {(ct === 'trino' || ct === 'starburst')
                                && <TrinoForm    config={form.config} onChange={updateConfig} connType={ct} />}
            {ct === 'snowflake' && <SnowflakeForm config={form.config} onChange={updateConfig} />}
            {ct === 'databricks'&& <DatabricksForm config={form.config} onChange={updateConfig} />}

          </Stack>

          {/* Test result */}
          {testResult && (
            <Alert severity={testResult.success ? 'success' : 'error'} sx={{ mt: 2 }}>
              {testResult.message}
            </Alert>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
          <Button
            variant="outlined"
            onClick={handleTestInDialog}
            disabled={testing === 'dialog'}
            startIcon={testing === 'dialog' ? <CircularProgress size={16} /> : <TestIcon />}
          >
            Test Connection
          </Button>
          <Box sx={{ flex: 1 }} />
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : (editingId ? 'Update' : 'Create')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Delete Confirmation ── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Delete Connection</DialogTitle>
        <DialogContent>
          <Typography>
            Delete <strong>{deleteTarget?.name}</strong>? Saved queries using this connection may stop working.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ConnectionManager;
