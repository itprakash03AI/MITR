import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  Typography, IconButton, Divider, Tooltip, AppBar, Toolbar, Chip,
} from '@mui/material';
import {
  MenuOpen as MenuOpenIcon,
  Menu as MenuIcon,
  Storage as StorageIcon,
  Build as BuildIcon,
  Bookmark as BookmarkIcon,
  Assessment as AssessmentIcon,
  History as HistoryIcon,
  Download as DownloadIcon,
  BoltOutlined as BoltIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Terminal as SqlIcon,
  Schedule as ScheduleIcon,
  Summarize as ParamReportIcon,
  FindInPage as FilePreviewIcon,
} from '@mui/icons-material';
import { useWebSocket } from '../context/WebSocketContext';

const DRAWER_WIDTH = 260;
const DRAWER_COLLAPSED = 64;

const navSections = [
  {
    label: 'DATA SOURCES',
    items: [
      { text: 'Connections', icon: <StorageIcon />, path: '/connections' },
    ],
  },
  {
    label: 'QUERY',
    items: [
      { text: 'Query Builder',  icon: <BuildIcon />,      path: '/' },
      { text: 'SQL Query',      icon: <SqlIcon />,        path: '/sql' },
      { text: 'Saved Queries',  icon: <BookmarkIcon />,   path: '/saved-queries' },
      { text: 'Reports',             icon: <AssessmentIcon />,  path: '/reports' },
      { text: 'Parametric Reports',  icon: <ParamReportIcon />, path: '/report-manager' },
    ],
  },
  {
    label: 'AUTOMATION',
    items: [
      { text: 'Schedules', icon: <ScheduleIcon />, path: '/schedules' },
    ],
  },
  {
    label: 'HISTORY',
    items: [
      { text: 'Executions',    icon: <HistoryIcon />,      path: '/executions' },
      { text: 'Exports',       icon: <DownloadIcon />,     path: '/downloads' },
      { text: 'File Preview',  icon: <FilePreviewIcon />,  path: '/file-preview' },
    ],
  },
];

const isActive = (itemPath, currentPath) =>
  itemPath === '/'
    ? currentPath === '/'
    : currentPath.startsWith(itemPath);

const PAGE_TITLES = {
  '/':              'Query Builder',
  '/connections':   'Connections',
  '/saved-queries': 'Saved Queries',
  '/reports':       'Reports',
  '/executions':    'Execution History',
  '/downloads':     'Exports & Downloads',
  '/sql':            'SQL Query',
  '/report-manager': 'Parametric Reports',
  '/schedules':      'Scheduled Downloads',
  '/file-preview':   'File Preview',
};

const Layout = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { isConnected } = useWebSocket();
  const [open, setOpen] = useState(() => {
    const saved = localStorage.getItem('sidebarOpen');
    return saved !== null ? saved === 'true' : true;
  });

  useEffect(() => {
    localStorage.setItem('sidebarOpen', String(open));
  }, [open]);

  const drawerWidth = open ? DRAWER_WIDTH : DRAWER_COLLAPSED;

  // Current page title
  const currentTitle = Object.entries(PAGE_TITLES).find(
    ([path]) => (path === '/' ? location.pathname === '/' : location.pathname.startsWith(path))
  )?.[1] ?? 'Smart Query Studio';

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>

      {/* ══ Sidebar ═════════════════════════════════════════════════════════ */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          transition: 'width 0.2s ease',
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            overflowX: 'hidden',
            transition: 'width 0.2s ease',
            borderRight: '1px solid',
            borderColor: 'divider',
          },
        }}
      >
        {/* Brand */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            px: open ? 2 : 0,
            py: 1.75,
            justifyContent: open ? 'flex-start' : 'center',
            borderBottom: 1,
            borderColor: 'divider',
          }}
        >
          <BoltIcon color="primary" sx={{ fontSize: 26, flexShrink: 0 }} />
          {open && (
            <Box>
              <Typography
                variant="subtitle1"
                sx={{ fontWeight: 700, color: 'primary.main', lineHeight: 1.2 }}
              >
                Smart Query Studio
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Enterprise Data Platform
              </Typography>
            </Box>
          )}
        </Box>

        {/* Collapse toggle */}
        <Box sx={{ display: 'flex', justifyContent: open ? 'flex-end' : 'center', px: 1, py: 0.5 }}>
          <IconButton size="small" onClick={() => setOpen(v => !v)}>
            {open ? <MenuOpenIcon fontSize="small" /> : <MenuIcon fontSize="small" />}
          </IconButton>
        </Box>

        {/* Nav sections */}
        <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
          {navSections.map((section, si) => (
            <React.Fragment key={si}>
              {open && (
                <Typography
                  variant="overline"
                  sx={{
                    px: 2, pt: si > 0 ? 2 : 1, pb: 0.5, display: 'block',
                    color: 'text.disabled', fontSize: '0.62rem', letterSpacing: 1.2,
                  }}
                >
                  {section.label}
                </Typography>
              )}
              {!open && si > 0 && <Divider sx={{ my: 1, mx: 1 }} />}
              <List disablePadding>
                {section.items.map((item) => {
                  const active = isActive(item.path, location.pathname);
                  const button = (
                    <ListItem key={item.text} disablePadding>
                      <ListItemButton
                        selected={active}
                        onClick={() => navigate(item.path)}
                        sx={{
                          minHeight: 44,
                          justifyContent: open ? 'initial' : 'center',
                          px: open ? 2 : 1,
                        }}
                      >
                        <ListItemIcon
                          sx={{
                            minWidth: 0,
                            mr: open ? 1.5 : 0,
                            justifyContent: 'center',
                            color: active ? 'primary.main' : 'text.secondary',
                          }}
                        >
                          {item.icon}
                        </ListItemIcon>
                        {open && (
                          <ListItemText
                            primary={item.text}
                            primaryTypographyProps={{
                              fontSize: '0.875rem',
                              fontWeight: active ? 600 : 400,
                              color: active ? 'primary.main' : 'text.primary',
                            }}
                          />
                        )}
                      </ListItemButton>
                    </ListItem>
                  );
                  return open ? button : (
                    <Tooltip key={item.text} title={item.text} placement="right" arrow>
                      {button}
                    </Tooltip>
                  );
                })}
              </List>
            </React.Fragment>
          ))}
        </Box>

        {/* Footer: connection status */}
        <Box sx={{ p: open ? 2 : 1, borderTop: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: open ? 'space-between' : 'center', gap: 1 }}>
          {open ? (
            <>
              <Typography variant="caption" color="text.disabled">v2.0 · Enterprise Edition</Typography>
              <Chip
                size="small"
                icon={isConnected ? <WifiIcon sx={{ fontSize: '12px !important' }} /> : <WifiOffIcon sx={{ fontSize: '12px !important' }} />}
                label={isConnected ? 'Live' : 'Offline'}
                color={isConnected ? 'success' : 'default'}
                variant="outlined"
                sx={{ height: 20, fontSize: 11 }}
              />
            </>
          ) : (
            <Tooltip title={isConnected ? 'Live' : 'Disconnected'} placement="right">
              {isConnected
                ? <WifiIcon sx={{ fontSize: 18, color: 'success.main' }} />
                : <WifiOffIcon sx={{ fontSize: 18, color: 'text.disabled' }} />
              }
            </Tooltip>
          )}
        </Box>
      </Drawer>

      {/* ══ Main area ═══════════════════════════════════════════════════════ */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          backgroundColor: 'background.default',
          height: '100vh',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Top AppBar */}
        <AppBar
          position="static"
          elevation={0}
          sx={{
            bgcolor: '#00AEEF',
            color: 'white',
          }}
        >
          <Toolbar variant="dense" sx={{ minHeight: 52 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, flex: 1 }}>
              {currentTitle}
            </Typography>
          </Toolbar>
        </AppBar>

        {/* Page content */}
        <Box sx={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
