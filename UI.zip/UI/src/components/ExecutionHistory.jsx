import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, CircularProgress, ToggleButtonGroup, ToggleButton,
  Dialog, DialogTitle, DialogContent, DialogActions, Alert,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Cancel as CancelIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import api from '../services/api';

const fmtDate = (s) => s ? new Date(s).toLocaleString() : '-';
const fmtDuration = (start, end) => {
  if (!start) return '-';
  const ms = (end ? new Date(end) : new Date()) - new Date(start);
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
};
const fmtSize = (bytes) => {
  if (!bytes) return '-';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
};
const isRunning = (status) => status === 'pending' || status === 'processing';

const statusProps = {
  pending:    { label: 'Pending',   color: 'warning' },
  processing: { label: 'Running',  color: 'info' },
  completed:  { label: 'Completed', color: 'success' },
  failed:     { label: 'Failed',    color: 'error' },
  cancelled:  { label: 'Cancelled', color: 'default' },
};

const FILTERS = ['', 'pending', 'processing', 'completed', 'failed', 'cancelled'];
const LABELS  = ['All', 'Pending', 'Running', 'Completed', 'Failed', 'Cancelled'];

const ExecutionHistory = () => {
  const [executions, setExecutions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [selectedExecution, setSelected] = useState(null);
  const [killing, setKilling] = useState({});
  const { addNotification } = useNotifications();
  const { addListener } = useWebSocket();

  useEffect(() => {
    loadExecutions();
    const remove = addListener(msg => {
      if (msg.type?.includes('execution')) loadExecutions();
    });
    return () => remove();
  }, [filter]);

  const loadExecutions = async () => {
    try {
      setLoading(true);
      const params = filter ? { status: filter } : {};
      const data = await api.listExecutions(params);
      setExecutions(data || []);
    } catch (error) {
      addNotification({ type: 'error', title: 'Error Loading Executions', message: error.message });
    } finally {
      setLoading(false);
    }
  };

  const viewDetails = async (executionId) => {
    try {
      const execution = await api.getExecution(executionId);
      setSelected(execution);
    } catch (error) {
      addNotification({ type: 'error', title: 'Error', message: error.message });
    }
  };

  const killExecution = async (executionId) => {
    setKilling(prev => ({ ...prev, [executionId]: true }));
    try {
      await api.cancelExecution(executionId);
      addNotification({ type: 'success', title: 'Cancelled', message: `Execution ${executionId.substring(0, 8)} cancelled` });
      loadExecutions();
      if (selectedExecution?.execution_id === executionId) setSelected(null);
    } catch (error) {
      addNotification({ type: 'error', title: 'Cancel Failed', message: error.message });
    } finally {
      setKilling(prev => ({ ...prev, [executionId]: false }));
    }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5">Execution History</Typography>
          <Typography variant="subtitle2">Monitor and manage query executions</Typography>
        </Box>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadExecutions}>Refresh</Button>
      </Box>

      {/* Filters */}
      <ToggleButtonGroup
        value={filter}
        exclusive
        onChange={(_, val) => val !== null && setFilter(val)}
        size="small"
        sx={{ mb: 3 }}
      >
        {FILTERS.map((f, i) => (
          <ToggleButton key={f} value={f}>{LABELS[i]}</ToggleButton>
        ))}
      </ToggleButtonGroup>

      {/* Content */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 8 }}><CircularProgress /></Box>
      ) : executions.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No executions found</Typography>
          <Typography color="text.secondary">Execute queries in the Query Builder or Reports page</Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 600, backgroundColor: '#f8fafc' } }}>
                <TableCell>ID</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Started</TableCell>
                <TableCell>Duration</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell align="right">Size</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {executions.map(ex => {
                const sp = statusProps[ex.status] || statusProps.pending;
                return (
                  <TableRow key={ex.execution_id} hover
                    sx={isRunning(ex.status) ? { backgroundColor: 'rgba(37, 99, 235, 0.04)' } : {}}
                  >
                    <TableCell>
                      <Typography variant="body2" fontFamily="monospace" fontSize="0.8125rem">
                        {ex.execution_id.substring(0, 8)}...
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip label={sp.label} color={sp.color} size="small" variant="outlined" />
                    </TableCell>
                    <TableCell><Typography variant="body2">{fmtDate(ex.started_at)}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{fmtDuration(ex.started_at, ex.completed_at)}</Typography></TableCell>
                    <TableCell align="right"><Typography variant="body2">{ex.total_rows?.toLocaleString() || '-'}</Typography></TableCell>
                    <TableCell align="right"><Typography variant="body2">{fmtSize(ex.file_size_bytes)}</Typography></TableCell>
                    <TableCell align="right">
                      <Button size="small" startIcon={<InfoIcon />} onClick={() => viewDetails(ex.execution_id)}>
                        Details
                      </Button>
                      {isRunning(ex.status) && (
                        <Button
                          size="small"
                          color="error"
                          startIcon={killing[ex.execution_id] ? <CircularProgress size={14} /> : <CancelIcon />}
                          onClick={() => killExecution(ex.execution_id)}
                          disabled={killing[ex.execution_id]}
                        >
                          Kill
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Details Dialog */}
      <Dialog open={!!selectedExecution} onClose={() => setSelected(null)} maxWidth="md" fullWidth>
        {selectedExecution && (
          <>
            <DialogTitle>
              Execution Details
              <Chip
                label={(statusProps[selectedExecution.status] || statusProps.pending).label}
                color={(statusProps[selectedExecution.status] || statusProps.pending).color}
                size="small"
                sx={{ ml: 2 }}
              />
            </DialogTitle>
            <DialogContent dividers>
              {selectedExecution.error_message && (
                <Alert severity="error" sx={{ mb: 2 }}>{selectedExecution.error_message}</Alert>
              )}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, mb: 3 }}>
                {[
                  ['Execution ID', selectedExecution.execution_id],
                  ['Started', fmtDate(selectedExecution.started_at)],
                  ['Completed', fmtDate(selectedExecution.completed_at)],
                  ['Duration', fmtDuration(selectedExecution.started_at, selectedExecution.completed_at)],
                  ['Total Rows', selectedExecution.total_rows?.toLocaleString() || '0'],
                  ['File Size', fmtSize(selectedExecution.file_size_bytes)],
                  ['Query ID', selectedExecution.query_id || '-'],
                ].map(([k, v]) => (
                  <Box key={k}>
                    <Typography variant="caption" color="text.secondary">{k}</Typography>
                    <Typography variant="body2" fontWeight={500} sx={{ fontFamily: k === 'Execution ID' ? 'monospace' : 'inherit' }}>
                      {v}
                    </Typography>
                  </Box>
                ))}
              </Box>
              <Typography variant="subtitle2" gutterBottom>Query Configuration</Typography>
              <Paper variant="outlined" sx={{ p: 2, backgroundColor: '#f8fafc', overflow: 'auto', maxHeight: 300 }}>
                <pre style={{ margin: 0, fontSize: '0.8125rem', fontFamily: 'monospace' }}>
                  {JSON.stringify(selectedExecution.query_config, null, 2)}
                </pre>
              </Paper>
            </DialogContent>
            <DialogActions>
              {isRunning(selectedExecution.status) && (
                <Button color="error" onClick={() => killExecution(selectedExecution.execution_id)}>
                  Kill Execution
                </Button>
              )}
              <Button onClick={() => setSelected(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default ExecutionHistory;
