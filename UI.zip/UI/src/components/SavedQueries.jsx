import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, Button, Paper, Chip, CircularProgress,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, MenuItem, InputAdornment, IconButton, Tooltip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TableSortLabel, TablePagination, ToggleButton, ToggleButtonGroup,
} from '@mui/material';
import {
  Refresh as RefreshIcon, PlayArrow as PlayIcon, Visibility as ViewIcon,
  Delete as DeleteIcon, Search as SearchIcon, Clear as ClearIcon,
  ViewList as ListIcon, GridView as GridIcon, Edit as EditIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../context/NotificationContext';
import api from '../services/api';

const fmtDate = (s) => s ? new Date(s).toLocaleString() : '—';
const fmtDateShort = (s) => s ? new Date(s).toLocaleDateString() : '—';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

const SavedQueries = () => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedQuery, setSelectedQuery] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Search / sort / pagination
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState('created_at');
  const [sortDir, setSortDir] = useState('desc');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [viewMode, setViewMode] = useState('table'); // 'table' | 'grid'

  const { addNotification } = useNotifications();
  const navigate = useNavigate();

  useEffect(() => { loadQueries(); }, []);
  // Reset page when search changes
  useEffect(() => { setPage(0); }, [search]);

  const loadQueries = async () => {
    try {
      setLoading(true);
      const data = await api.listQueries({ active_only: true });
      setQueries(data);
    } catch (error) {
      addNotification({ type: 'error', title: 'Error Loading Queries', message: error.message });
    } finally {
      setLoading(false);
    }
  };

  const executeQuery = async (queryId, queryName) => {
    try {
      const response = await api.executeQuery({ query_id: queryId, output_format: 'csv' });
      addNotification({ type: 'success', title: 'Query Started', message: `"${queryName}" — ID: ${response.execution_id.substring(0, 8)}...` });
    } catch (error) {
      addNotification({ type: 'error', title: 'Execution Error', message: error.message });
    }
  };

  const handleEdit = (query) => {
    navigate('/', { state: { loadQuery: query } });
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteQuery(deleteTarget.id);
      addNotification({ type: 'success', title: 'Query Deleted', message: `"${deleteTarget.name}" deleted` });
      loadQueries();
    } catch (error) {
      addNotification({ type: 'error', title: 'Delete Error', message: error.message });
    }
    setDeleteTarget(null);
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
    setPage(0);
  };

  // Filter + sort + paginate
  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = q
      ? queries.filter(r =>
          r.name.toLowerCase().includes(q) ||
          (r.description || '').toLowerCase().includes(q)
        )
      : queries;

    rows = [...rows].sort((a, b) => {
      let av = a[sortField] ?? '';
      let bv = b[sortField] ?? '';
      if (sortField === 'execution_count') { av = Number(av); bv = Number(bv); }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return rows;
  }, [queries, search, sortField, sortDir]);

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const SortHeader = ({ field, label, align }) => (
    <TableCell align={align} sx={{ fontWeight: 700, whiteSpace: 'nowrap', bgcolor: 'grey.50' }}>
      <TableSortLabel
        active={sortField === field}
        direction={sortField === field ? sortDir : 'asc'}
        onClick={() => handleSort(field)}
      >
        {label}
      </TableSortLabel>
    </TableCell>
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5">Saved Queries</Typography>
          <Typography variant="subtitle2">
            {loading ? 'Loading…' : `${filtered.length} of ${queries.length} queries`}
          </Typography>
        </Box>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadQueries} disabled={loading}>
          Refresh
        </Button>
      </Box>

      {/* Toolbar: Search + view toggle */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <TextField
          size="small"
          placeholder="Search by name or description…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          sx={{ flex: 1, maxWidth: 480 }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment>,
            endAdornment: search
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton>
                </InputAdornment>
              : null,
          }}
        />
        <TextField
          select size="small" label="Sort by" value={sortField}
          onChange={e => { setSortField(e.target.value); setPage(0); }}
          sx={{ minWidth: 160 }}
        >
          <MenuItem value="created_at">Date Created</MenuItem>
          <MenuItem value="updated_at">Last Modified</MenuItem>
          <MenuItem value="last_executed_at">Last Executed</MenuItem>
          <MenuItem value="execution_count">Run Count</MenuItem>
          <MenuItem value="name">Name</MenuItem>
        </TextField>
        <ToggleButtonGroup
          size="small"
          value={viewMode}
          exclusive
          onChange={(_, v) => v && setViewMode(v)}
        >
          <ToggleButton value="table"><Tooltip title="Table view"><ListIcon /></Tooltip></ToggleButton>
          <ToggleButton value="grid"><Tooltip title="Card view"><GridIcon /></Tooltip></ToggleButton>
        </ToggleButtonGroup>
      </Box>

      {/* Content */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 8 }}><CircularProgress /></Box>
      ) : queries.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No saved queries</Typography>
          <Typography color="text.secondary">Create and save queries in the Query Builder</Typography>
        </Paper>
      ) : filtered.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No results for "{search}"</Typography>
          <Button onClick={() => setSearch('')}>Clear search</Button>
        </Paper>
      ) : viewMode === 'table' ? (
        /* ── TABLE VIEW (best for 1000+ queries) ── */
        <TableContainer component={Paper} variant="outlined">
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                <SortHeader field="name" label="Name" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Description</TableCell>
                <SortHeader field="execution_count" label="Runs" align="right" />
                <SortHeader field="created_at" label="Created" />
                <SortHeader field="last_executed_at" label="Last Run" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginated.map(query => (
                <TableRow
                  key={query.id}
                  hover
                  sx={{ '&:last-child td': { border: 0 } }}
                >
                  <TableCell sx={{ fontWeight: 600, maxWidth: 220 }}>
                    <Typography variant="body2" fontWeight={600} noWrap>{query.name}</Typography>
                  </TableCell>
                  <TableCell sx={{ maxWidth: 320 }}>
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {query.description || '—'}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Chip label={query.execution_count} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    <Typography variant="caption">{fmtDateShort(query.created_at)}</Typography>
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    <Typography variant="caption">{fmtDateShort(query.last_executed_at)}</Typography>
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    <Tooltip title="Execute">
                      <IconButton size="small" color="success" onClick={() => executeQuery(query.id, query.name)}>
                        <PlayIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Edit in Query Builder">
                      <IconButton size="small" color="primary" onClick={() => handleEdit(query)}>
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="View details">
                      <IconButton size="small" onClick={() => setSelectedQuery(query)}>
                        <ViewIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => setDeleteTarget(query)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </TableContainer>
      ) : (
        /* ── GRID VIEW ── */
        <>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 2 }}>
            {paginated.map(query => (
              <Paper key={query.id} variant="outlined" sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Typography variant="subtitle2" fontWeight={700} sx={{ flexGrow: 1, mr: 1 }} noWrap>
                    {query.name}
                  </Typography>
                  <Chip label={`${query.execution_count} runs`} size="small" variant="outlined" />
                </Box>
                {query.description && (
                  <Typography variant="body2" color="text.secondary" sx={{
                    display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden'
                  }}>
                    {query.description}
                  </Typography>
                )}
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mt: 'auto', pt: 0.5 }}>
                  <Typography variant="caption" color="text.disabled">Created: {fmtDateShort(query.created_at)}</Typography>
                  {query.last_executed_at && (
                    <Typography variant="caption" color="text.disabled">Run: {fmtDateShort(query.last_executed_at)}</Typography>
                  )}
                </Box>
                <Box sx={{ display: 'flex', gap: 0.5, pt: 0.5, borderTop: 1, borderColor: 'divider' }}>
                  <Button size="small" variant="contained" startIcon={<PlayIcon />} onClick={() => executeQuery(query.id, query.name)}>
                    Execute
                  </Button>
                  <Button size="small" startIcon={<EditIcon />} onClick={() => handleEdit(query)}>
                    Edit
                  </Button>
                  <Button size="small" startIcon={<ViewIcon />} onClick={() => setSelectedQuery(query)}>
                    View
                  </Button>
                  <Box sx={{ flexGrow: 1 }} />
                  <IconButton size="small" color="error" onClick={() => setDeleteTarget(query)}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              </Paper>
            ))}
          </Box>
          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </>
      )}

      {/* Details Dialog */}
      <Dialog open={!!selectedQuery} onClose={() => setSelectedQuery(null)} maxWidth="md" fullWidth>
        {selectedQuery && (
          <>
            <DialogTitle>{selectedQuery.name}</DialogTitle>
            <DialogContent dividers>
              {selectedQuery.description && (
                <Typography color="text.secondary" sx={{ mb: 2 }}>{selectedQuery.description}</Typography>
              )}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, mb: 3 }}>
                {[
                  ['Query ID', selectedQuery.id],
                  ['Executions', selectedQuery.execution_count],
                  ['Created', fmtDate(selectedQuery.created_at)],
                  ['Updated', fmtDate(selectedQuery.updated_at)],
                  selectedQuery.last_executed_at ? ['Last Executed', fmtDate(selectedQuery.last_executed_at)] : null,
                ].filter(Boolean).map(([k, v]) => (
                  <Box key={k}>
                    <Typography variant="caption" color="text.secondary">{k}</Typography>
                    <Typography variant="body2" fontWeight={500}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <Typography variant="subtitle2" gutterBottom>Query Configuration</Typography>
              <Paper variant="outlined" sx={{ p: 2, backgroundColor: '#f8fafc', overflow: 'auto', maxHeight: 400 }}>
                <pre style={{ margin: 0, fontSize: '0.8125rem', fontFamily: 'monospace' }}>
                  {JSON.stringify(selectedQuery.query_config, null, 2)}
                </pre>
              </Paper>
            </DialogContent>
            <DialogActions>
              <Button variant="contained" onClick={() => { executeQuery(selectedQuery.id, selectedQuery.name); setSelectedQuery(null); }}>
                Execute Query
              </Button>
              <Button startIcon={<EditIcon />} onClick={() => { handleEdit(selectedQuery); setSelectedQuery(null); }}>
                Edit in Builder
              </Button>
              <Button onClick={() => setSelectedQuery(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Delete Query</DialogTitle>
        <DialogContent>
          <Typography>Delete <strong>{deleteTarget?.name}</strong>? This cannot be undone.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SavedQueries;
