/**
 * API Service - TypeScript version
 * Every method maps to an actual backend route.
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

const safeFetch = async (url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const response = await fetch(fullUrl, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers as Record<string, string>) },
  });
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const e = await response.json() as { detail?: unknown; message?: string };
      if (typeof e.detail === 'string') detail = e.detail;
      else if (Array.isArray(e.detail)) detail = (e.detail as { msg?: string }[]).map(d => d.msg || JSON.stringify(d)).join('; ');
      else if (e.detail) detail = JSON.stringify(e.detail);
      else if (e.message) detail = e.message;
    } catch {}
    throw new Error(detail);
  }
  return response.json();
};

const openDownload = (path: string) =>
  window.open(path.startsWith('http') ? path : `${API_BASE_URL}${path}`, '_blank');

interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
}

const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
  };
};

const api = {
  // ── Utility ──────────────────────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: (err as Error).message })),

  // ── Files ─────────────────────────────────────────────────────────────────
  listFiles: (storageType: string | null = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },

  getFileSchema: (filePath: string) =>
    safeFetch(`/api/files/${filePath}/schema`).catch(err => {
      console.warn(`Schema failed for ${filePath}:`, (err as Error).message);
      return { file: filePath, columns: [], num_rows: 0 };
    }),

  uploadFile: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 ────────────────────────────────────────────────────────────────────
  configureS3: (config: object) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Connections ───────────────────────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),
  getConnection: (id: string) => safeFetch(`/api/connections/${id}`),
  createConnection: (data: object) =>
    safeFetch('/api/connections', { method: 'POST', body: JSON.stringify(data) }),
  updateConnection: (id: string, data: object) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnection: (id: string) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),
  testConnection: (data: object) =>
    safeFetch('/api/connections/test', { method: 'POST', body: JSON.stringify(data) }),
  testSavedConnection: (id: string) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),
  listConnectionFiles: (connId: string, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),
  getConnectionFileSchema: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/files/${filePath}/schema`),

  // ── Iceberg (S3 connections only) ─────────────────────────────────────────
  listIcebergTables: (connId: string, prefix = '') =>
    safeFetch(`/api/connections/${connId}/iceberg/tables?prefix=${encodeURIComponent(prefix)}`),
  listIcebergFiles: (connId: string, tablePrefix: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/files?table_prefix=${encodeURIComponent(tablePrefix)}`),

  // ── Saved Queries ─────────────────────────────────────────────────────────
  listQueries: (activeOnly: boolean | { active_only?: boolean } = true) => {
    const active = typeof activeOnly === 'object'
      ? (activeOnly.active_only ?? true)
      : activeOnly;
    return safeFetch(`/api/queries?active_only=${active}`).catch(() => []);
  },
  getSavedQueries: (activeOnly = true) => api.listQueries(activeOnly),
  getSavedQuery: (id: string) =>
    safeFetch(`/api/queries/${id}`).catch(() => null),
  saveQuery: (data: { name: string; description?: string; query_config: QueryConfig; created_by?: string }) => {
    const payload = {
      name:         data.name,
      description:  data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
      created_by:   data.created_by || null,
    };
    return safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(payload) });
  },
  updateQuery: (id: string, data: { name: string; description?: string; query_config: QueryConfig }) =>
    safeFetch(`/api/queries/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: data.name, description: data.description || null,
        query_config: toBackendQueryConfig(data.query_config),
      }),
    }),
  deleteQuery: (id: string) => safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),

  // ── Execution ─────────────────────────────────────────────────────────────
  executeQuery: (payload: { query_config?: QueryConfig; query_id?: string }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute', { method: 'POST', body: JSON.stringify(body) });
  },

  // ── Executions ────────────────────────────────────────────────────────────
  listExecutions: (params: { limit?: number; offset?: number; status?: string } | number = {}) => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  String(p.limit  ?? 50));
    qs.append('offset', String(p.offset ?? 0));
    if (p.status) qs.append('status', p.status);
    return safeFetch(`/api/executions?${qs}`).catch(() => []);
  },
  getExecution: (executionId: string) => safeFetch(`/api/executions/${executionId}`).catch(() => null),
  cancelExecution: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),
  getExecutionStatus: async (executionId: string) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      try {
        const downloads = await api.listDownloads('') as { execution_id: string; file_id: string }[];
        const match = downloads.find(d => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ─────────────────────────────────────────────────────────────
  listDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  getDownloads: (status = 'available') => api.listDownloads(status),
  downloadFile: (fileId: string) => openDownload(`/api/downloads/${fileId}`),
  deleteDownload: (fileId: string) => safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Results ───────────────────────────────────────────────────────────────
  getExecutionResults: (
    executionId: string, page = 1, pageSize = 100,
    sortColumn: string | null = null, sortDirection = 'asc', filters: object | null = null,
  ) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },
  exportResults: (executionId: string, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),
  getExecutionStats: (executionId: string) => safeFetch(`/api/executions/${executionId}/stats`),
  releaseExecutionResults: (executionId: string) =>
    fetch(`${API_BASE_URL}/api/executions/${executionId}/results`, { method: 'DELETE' }).catch(() => {}),

  // ── SQL Queries ───────────────────────────────────────────────────────────
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),
  createSqlQuery: (data: object) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: JSON.stringify(data) }),
  getSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`),
  updateSqlQuery: (id: string, data: object) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),
  executeSqlQuery: (payload: object) =>
    safeFetch('/api/sql/execute', { method: 'POST', body: JSON.stringify(payload) }),
  listSqlCatalogs: (connectionId: string) => safeFetch(`/api/sql/connections/${connectionId}/catalogs`),
  listSqlSchemas: (connectionId: string, catalog: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),
  listSqlTables: (connectionId: string, catalog: string, schema: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),
  listSqlColumns: (connectionId: string, catalog: string, schema: string, table: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),
  testSqlConnection: (connectionId: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Reports ───────────────────────────────────────────────────────────────
  listReports: (activeOnly = true) =>
    safeFetch(`/api/reports?active_only=${activeOnly}`).catch(() => []),
  createReport: (data: object) => safeFetch('/api/reports', { method: 'POST', body: JSON.stringify(data) }),
  getReport: (id: string) => safeFetch(`/api/reports/${id}`),
  updateReport: (id: string, data: object) =>
    safeFetch(`/api/reports/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteReport: (id: string) => safeFetch(`/api/reports/${id}`, { method: 'DELETE' }),
  executeReport: (id: string, paramValues: object = {}, rowLimit: number | null = null, executedBy: string | null = null) =>
    safeFetch(`/api/reports/${id}/execute`, {
      method: 'POST',
      body: JSON.stringify({ param_values: paramValues, row_limit: rowLimit, executed_by: executedBy }),
    }),
  getReportSourceInfo: (id: string) => safeFetch(`/api/reports/${id}/source-info`),
  getReportColumns: (id: string) =>
    safeFetch(`/api/reports/${id}/columns`).catch(() => ({ columns: [], date_shortcuts: [] })),
  getReportParamValues: (id: string, paramName: string, limit = 1000) =>
    safeFetch(`/api/reports/${id}/param-values?param_name=${encodeURIComponent(paramName)}&limit=${limit}`)
      .catch(() => ({ values: [], total: 0, truncated: false })),
  downloadReportDirect: (id: string, paramValues: Record<string, string> = {}) => {
    const qs = new URLSearchParams(paramValues).toString();
    openDownload(`/api/reports/${id}/download${qs ? '?' + qs : ''}`);
  },
  previewDownloadFile: (fileId: string, page = 1, pageSize = 100) =>
    safeFetch(`/api/downloads/${fileId}/preview?page=${page}&page_size=${pageSize}`),

  // ── Schedules ─────────────────────────────────────────────────────────────
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),
  createSchedule: (data: object) =>
    safeFetch('/api/schedules', { method: 'POST', body: JSON.stringify(data) }),
  getSchedule: (id: string) => safeFetch(`/api/schedules/${id}`),
  updateSchedule: (id: string, data: object) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSchedule: (id: string) => safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),
  pauseSchedule: (id: string) => safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),
  resumeSchedule: (id: string) => safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),
  runScheduleNow: (id: string) => safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),
  getSchedulerStatus: () => safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),
};

export default api;
