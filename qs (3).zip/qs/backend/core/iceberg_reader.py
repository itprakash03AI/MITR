"""
Iceberg table reader for S3.

Reads Apache Iceberg v1/v2 table metadata stored on S3 to discover the
active set of Parquet data files for a given table snapshot.

Flow:
  1. Scan S3 prefix for directories that contain a metadata/ subfolder
     with *.metadata.json files → those are Iceberg tables.
  2. Read the latest metadata.json to get current-snapshot-id.
  3. Follow the manifest-list (Avro) → manifest files (Avro) → data file paths.
  4. Return S3 keys for all ADDED/EXISTING Parquet data files.

Requires: fastavro (for Avro manifest reading)
"""

from __future__ import annotations

import io
import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── S3 URI helpers ────────────────────────────────────────────────────────────

def _s3_uri_to_key(uri: str) -> str:
    """Convert s3://bucket/key  or  s3a://bucket/key  →  key only."""
    for scheme in ("s3a://", "s3n://", "s3://"):
        if uri.startswith(scheme):
            path = uri[len(scheme):]
            slash = path.find("/")
            return path[slash + 1:] if slash >= 0 else ""
    return uri  # already a bare key


def _read_s3_bytes(s3_client, bucket: str, key: str) -> bytes:
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    return obj["Body"].read()


def _read_s3_json(s3_client, bucket: str, key: str) -> dict:
    return json.loads(_read_s3_bytes(s3_client, bucket, key))


def _read_avro(data: bytes) -> List[dict]:
    """Deserialise an Avro byte stream using fastavro."""
    try:
        import fastavro
        return list(fastavro.reader(io.BytesIO(data)))
    except ImportError:
        raise RuntimeError(
            "fastavro is required for Iceberg manifest reading. "
            "Install it with: pip install fastavro>=1.9.0"
        )


# ── Table detection ───────────────────────────────────────────────────────────

def is_iceberg_table(s3_client, bucket: str, prefix: str) -> bool:
    """Return True if the S3 prefix looks like an Iceberg table directory."""
    meta_prefix = prefix.rstrip("/") + "/metadata/"
    try:
        resp = s3_client.list_objects_v2(
            Bucket=bucket, Prefix=meta_prefix, MaxKeys=20
        )
        for obj in resp.get("Contents", []):
            if obj["Key"].endswith(".metadata.json"):
                return True
    except Exception:
        pass
    return False


def list_iceberg_tables(
    s3_client, bucket: str, prefix: str = ""
) -> List[Dict[str, Any]]:
    """
    Scan one level of S3 prefix for Iceberg table directories.

    Args:
        s3_client: boto3 S3 client
        bucket:    S3 bucket name
        prefix:    S3 prefix to scan (warehouse path, e.g. "warehouse/db/")

    Returns:
        List of dicts: {name, prefix, type='iceberg_table', path}
    """
    paginator = s3_client.get_paginator("list_objects_v2")
    tables: List[Dict[str, Any]] = []

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]
                name = folder.rstrip("/").split("/")[-1]
                if is_iceberg_table(s3_client, bucket, folder):
                    tables.append({
                        "name":   name,
                        "prefix": folder,
                        "type":   "iceberg_table",
                        # virtual path consumed by the query builder
                        "path":   f"__iceberg__:{folder}",
                        "folder": prefix,
                    })
    except Exception as e:
        logger.error("Error scanning for Iceberg tables at %s: %s", prefix, e)
        raise

    logger.info("Found %d Iceberg tables under prefix '%s'", len(tables), prefix)
    return tables


# ── Metadata + manifest traversal ────────────────────────────────────────────

def _latest_metadata_key(s3_client, bucket: str, meta_prefix: str) -> str:
    """Return the S3 key of the most-recently-modified *.metadata.json file."""
    resp = s3_client.list_objects_v2(Bucket=bucket, Prefix=meta_prefix)
    candidates = [
        obj for obj in resp.get("Contents", [])
        if obj["Key"].endswith(".metadata.json")
    ]
    if not candidates:
        raise ValueError(f"No Iceberg metadata JSON found under {meta_prefix}")
    return max(candidates, key=lambda x: x["LastModified"])["Key"]


def get_iceberg_data_files(
    s3_client, bucket: str, table_prefix: str
) -> List[Dict[str, Any]]:
    """
    Read Iceberg table metadata and return the active Parquet data files.

    Args:
        s3_client:     boto3 S3 client
        bucket:        S3 bucket name
        table_prefix:  S3 prefix of the Iceberg table root (ends with /)

    Returns:
        List of dicts: {key, name, path, size_bytes, last_modified, folder}
    """
    meta_prefix = table_prefix.rstrip("/") + "/metadata/"

    # ── Step 1: Read latest table metadata JSON ───────────────────────────────
    meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
    metadata = _read_s3_json(s3_client, bucket, meta_key)
    logger.info("Iceberg metadata: %s (format-version %s)",
                meta_key, metadata.get("format-version", "?"))

    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        logger.warning("Table %s has no current snapshot — returning empty", table_prefix)
        return []

    snapshots = {s["snapshot-id"]: s for s in metadata.get("snapshots", [])}
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        raise ValueError(
            f"Snapshot {current_snapshot_id} not found in {meta_key}"
        )

    # ── Step 2: Read manifest list ────────────────────────────────────────────
    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        manifest_list_data = _read_s3_bytes(s3_client, bucket, ml_key)
        manifests = _read_avro(manifest_list_data)
    else:
        # Iceberg v1: snapshot may have inline "manifests" list
        manifests = snapshot.get("manifests", [])

    # ── Step 3: Read each manifest and collect data file paths ────────────────
    data_file_keys: List[str] = []
    for manifest in manifests:
        # manifest-list entries have 'manifest_path'; inline v1 entries may vary
        manifest_path = (
            manifest.get("manifest_path")
            or manifest.get("manifest-path")
            or (manifest if isinstance(manifest, str) else None)
        )
        if not manifest_path:
            continue

        manifest_key = _s3_uri_to_key(manifest_path)
        try:
            manifest_data = _read_s3_bytes(s3_client, bucket, manifest_key)
            entries = _read_avro(manifest_data)
        except Exception as e:
            logger.warning("Could not read manifest %s: %s", manifest_key, e)
            continue

        for entry in entries:
            # status: 0=EXISTING  1=ADDED  2=DELETED
            if entry.get("status") == 2:
                continue
            data_file = entry.get("data_file") or {}
            file_path  = data_file.get("file_path") or data_file.get("path", "")
            if file_path.endswith(".parquet"):
                data_file_keys.append(_s3_uri_to_key(file_path))

    logger.info("Iceberg table %s → %d data files", table_prefix, len(data_file_keys))

    # ── Step 4: Fetch S3 metadata for each data file ──────────────────────────
    result: List[Dict[str, Any]] = []
    for key in data_file_keys:
        try:
            head = s3_client.head_object(Bucket=bucket, Key=key)
            result.append({
                "key":           key,
                "name":          key.split("/")[-1],
                "path":          key,
                "size_bytes":    head["ContentLength"],
                "last_modified": head["LastModified"].isoformat(),
                "folder":        "/".join(key.split("/")[:-1]) + "/" if "/" in key else "",
                "type":          "parquet",
            })
        except Exception as e:
            logger.warning("Cannot stat Iceberg data file %s: %s", key, e)
            # Include the file anyway with zero size — it's valid, just inaccessible via HEAD
            result.append({
                "key":           key,
                "name":          key.split("/")[-1],
                "path":          key,
                "size_bytes":    0,
                "last_modified": "",
                "folder":        "/".join(key.split("/")[:-1]) + "/" if "/" in key else "",
                "type":          "parquet",
            })

    return result
