/**
 * Admin Panel — QueryStudio Enterprise
 * Active queries · User activity · System health · Storage · Cache · Audit log
 */
// @ts-nocheck
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Paper, Grid, Chip, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TextField, InputAdornment, Divider, Alert, MenuItem,
  LinearProgress, Tooltip, Stack, IconButton, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions, Avatar, Collapse,
  useTheme,
} from '@mui/material';
import {
  CheckCircle as OkIcon,
  Error as ErrIcon,
  Warning as WarnIcon,
  Refresh as RefreshIcon,
  CleaningServices as CleanupIcon,
  DeleteSweep as ClearCacheIcon,
  Storage as StorageIcon,
  FolderOpen as FolderIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Security as AuditIcon,
  Memory as CacheIcon,
  MonitorHeart as HealthIcon,
  Cancel as CancelIcon,
  PlayCircleOutline as ActiveIcon,
  AccessTime as DurationIcon,
  Block as BlockedIcon,
  Groups as UsersIcon,
  HourglassTop as RunningIcon,
  Settings as SettingsIcon,
  Save as SaveIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { getAuthHeader } from '../context/AuthContext';

const API_BASE = import.meta.env.VITE_API_URL || '';

/** Authenticated fetch — injects Authorization header automatically. */
const authFetch = (url: string, opts: RequestInit = {}) => {
  const h = getAuthHeader();
  const headers: Record<string, string> = { ...(opts.headers as any) };
  if (h) headers['Authorization'] = h;
  return fetch(url, { ...opts, headers });
};

// ── Formatters ──────────────────────────────────────────────────────────────
const fmtSize = (bytes: number) => {
  if (!bytes) return '0 B';
  const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${s[i]}`;
};
const fmtMb   = (mb: number) => mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb} MB`;
const fmtDate = (s: string)  => s ? new Date(s).toLocaleString() : '—';
const fmtDuration = (secs: number) => {
  if (secs < 60)   return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
};

// ── Section header ──────────────────────────────────────────────────────────
const SectionHeader = ({ icon, title, action = null, badge = null }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
    {icon}
    <Typography variant="h6" fontWeight={700} sx={{ flex: 1 }}>{title}</Typography>
    {badge != null && badge > 0 && (
      <Chip size="small" label={badge} color="error"
        sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
    )}
    {action}
  </Box>
);

// ── Stat card ───────────────────────────────────────────────────────────────
const StatCard = ({ label, value, sub = '', warn = false }) => (
  <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 120 }}>
    <Typography variant="caption" color="text.secondary">{label}</Typography>
    <Typography variant="h5" fontWeight={700}
      color={warn ? 'error.main' : 'text.primary'}>
      {value}
    </Typography>
    {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
  </Paper>
);

// ── Status chip ─────────────────────────────────────────────────────────────
const StatusChip = ({ ok, label = '' }) => (
  <Chip
    size="small"
    icon={ok
      ? <OkIcon  sx={{ fontSize: '14px !important' }} />
      : <ErrIcon sx={{ fontSize: '14px !important' }} />}
    label={label || (ok ? 'OK' : 'Error')}
    color={ok ? 'success' : 'error'}
    variant="outlined"
  />
);

// ── Live duration ticker ────────────────────────────────────────────────────
const LiveDuration = ({ seconds: initial, warn }) => {
  const [secs, setSecs] = useState(initial);
  useEffect(() => {
    setSecs(initial);
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [initial]);
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <DurationIcon sx={{ fontSize: 14, color: warn ? 'error.main' : 'text.secondary' }} />
      <Typography variant="body2" fontWeight={warn ? 700 : 400}
        color={warn ? 'error.main' : 'text.primary'}>
        {fmtDuration(secs)}
      </Typography>
    </Box>
  );
};

// ══ Main component ══════════════════════════════════════════════════════════
const AdminPage = () => {
  const { addNotification } = useNotifications();
  const theme = useTheme();

  const [health,      setHealth]      = useState<any>(null);
  const [storage,     setStorage]     = useState<any>(null);
  const [cache,       setCache]       = useState<any>(null);
  const [activeQ,     setActiveQ]     = useState<any[]>([]);
  const [userStats,   setUserStats]   = useState<any[]>([]);
  const [auditLog,    setAuditLog]    = useState<any[]>([]);
  const [poolStats,   setPoolStats]   = useState<any>(null);
  const [poolTasks,   setPoolTasks]   = useState<any[]>([]);
  const [auditPage,   setAuditPage]   = useState(0);
  const [auditTotal,  setAuditTotal]  = useState(0);
  const [auditSearch, setAuditSearch] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [loading,     setLoading]     = useState({
    health: true, storage: true, cache: true,
    activeQ: true, userStats: true, audit: true, pool: true,
  });
  const [cleanupBusy, setCleanupBusy] = useState(false);
  const [cacheBusy,   setCacheBusy]   = useState(false);
  const [cancelTarget, setCancelTarget] = useState<any>(null);
  const [cancelBusy,   setCancelBusy]   = useState(false);
  const [poolCfgOpen,  setPoolCfgOpen]  = useState(false);
  const [poolCfg,      setPoolCfg]      = useState<any>(null);
  const [poolCfgDraft, setPoolCfgDraft] = useState<any>({});
  const [poolCfgSaving, setPoolCfgSaving] = useState(false);

  // User management state
  const [userList, setUserList] = useState<any[]>([]);
  const [userMgmtLoading, setUserMgmtLoading] = useState(true);
  const [userDlg, setUserDlg] = useState<any>({ open: false, mode: 'add', username: '', password: '', role: 'analyst' });
  const [authType, setAuthType] = useState<string>('none');
  const [adLookup, setAdLookup] = useState<any>(null);       // AD lookup result
  const [adLookupLoading, setAdLookupLoading] = useState(false);
  const [adLookupError, setAdLookupError] = useState('');

  const AUDIT_PER_PAGE = 25;
  const WARN_SECS = 300; // 5-min threshold

  const setOne = (k: string, v: boolean) =>
    setLoading(prev => ({ ...prev, [k]: v }));

  const loadSection = useCallback(async (section: string) => {
    setOne(section, true);
    try {
      switch (section) {
        case 'health': {
          const d = await authFetch(`${API_BASE}/health`).then(r => r.json());
          setHealth(d);
          break;
        }
        case 'storage': {
          const d = await authFetch(`${API_BASE}/api/admin/storage`).then(r => r.json());
          setStorage(d);
          break;
        }
        case 'cache': {
          const d = await authFetch(`${API_BASE}/api/cache/stats`).then(r => r.json());
          setCache(d);
          break;
        }
        case 'activeQ': {
          const d = await authFetch(`${API_BASE}/api/admin/active-queries`).then(r => r.json());
          setActiveQ(Array.isArray(d) ? d : []);
          break;
        }
        case 'userStats': {
          const d = await authFetch(`${API_BASE}/api/admin/user-stats`).then(r => r.json());
          setUserStats(Array.isArray(d) ? d : []);
          break;
        }
        case 'pool': {
          const [stats, tasks] = await Promise.all([
            authFetch(`${API_BASE}/api/admin/worker-pool`).then(r => r.json()),
            authFetch(`${API_BASE}/api/admin/worker-pool/tasks`).then(r => r.json()),
          ]);
          setPoolStats(stats);
          setPoolTasks(Array.isArray(tasks) ? tasks : []);
          break;
        }
        case 'audit': {
          const qs = new URLSearchParams({
            limit:  String(AUDIT_PER_PAGE),
            offset: String(auditPage * AUDIT_PER_PAGE),
            ...(auditSearch ? { username: auditSearch } : {}),
            ...(auditAction ? { action:   auditAction } : {}),
          });
          const res  = await authFetch(`${API_BASE}/api/admin/audit-log?${qs}`);
          const data = await res.json();
          setAuditLog(Array.isArray(data) ? data : data.items || []);
          setAuditTotal(data.total || (Array.isArray(data) ? data.length : 0));
          break;
        }
      }
    } catch { /* silent */ }
    setOne(section, false);
  }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  const loadAll = useCallback(() => {
    ['health', 'storage', 'cache', 'activeQ', 'userStats', 'pool', 'audit'].forEach(loadSection);
  }, [loadSection]);

  useEffect(() => { loadAll(); }, []); // eslint-disable-line
  useEffect(() => { loadSection('audit'); }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  // Poll active queries + user stats every 10s
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    pollRef.current = setInterval(() => {
      loadSection('activeQ');
      loadSection('userStats');
      loadSection('pool');
    }, 10_000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []); // eslint-disable-line

  // ── Handlers ────────────────────────────────────────────────────────────
  const handleCleanup = async () => {
    setCleanupBusy(true);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/storage/cleanup`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      addNotification({ type: 'success', title: 'Cleanup Complete', message: 'Stale files removed' });
      loadSection('storage');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cleanup Failed', message: e.message });
    } finally { setCleanupBusy(false); }
  };

  const handleClearCache = async () => {
    setCacheBusy(true);
    try {
      await authFetch(`${API_BASE}/api/cache`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Cache Cleared', message: 'Query result cache cleared' });
      loadSection('cache');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Clear Failed', message: e.message });
    } finally { setCacheBusy(false); }
  };

  const handleAdminCancel = async () => {
    if (!cancelTarget) return;
    setCancelBusy(true);
    try {
      const res  = await authFetch(`${API_BASE}/api/admin/queries/${cancelTarget.execution_id}`, { method: 'DELETE' });
      const body = await res.json();
      addNotification({ type: 'success', title: 'Query Cancelled', message: body.message });
      setCancelTarget(null);
      await Promise.all([loadSection('activeQ'), loadSection('userStats')]);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cancel Failed', message: e.message });
    } finally { setCancelBusy(false); }
  };

  // ── Worker Pool Config ─────────────────────────────────────────────────
  const loadPoolConfig = useCallback(async () => {
    try {
      const data = await authFetch(`${API_BASE}/api/admin/worker-pool/config`).then(r => r.json());
      setPoolCfg(data);
      // Flatten types into draft: { interactive_max_concurrent: 30, ... }
      const draft: any = {};
      if (data?.types) {
        for (const [typeName, cfg] of Object.entries(data.types) as any) {
          const prefix = typeName.toLowerCase();
          draft[`${prefix}_max_concurrent`] = cfg.max_concurrent;
          draft[`${prefix}_default_timeout`] = cfg.default_timeout;
          draft[`${prefix}_max_queue`] = cfg.max_queue;
        }
      }
      setPoolCfgDraft(draft);
    } catch { /* silent */ }
  }, []);

  const handlePoolCfgSave = async () => {
    setPoolCfgSaving(true);
    try {
      // Only send fields that changed from current config
      const changed: any = {};
      if (poolCfg?.types) {
        for (const [typeName, cfg] of Object.entries(poolCfg.types) as any) {
          const prefix = typeName.toLowerCase();
          for (const field of ['max_concurrent', 'default_timeout', 'max_queue']) {
            const key = `${prefix}_${field}`;
            const newVal = Number(poolCfgDraft[key]);
            if (!isNaN(newVal) && newVal !== cfg[field]) {
              changed[key] = newVal;
            }
          }
        }
      }
      if (Object.keys(changed).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'Configuration unchanged' });
        setPoolCfgSaving(false);
        return;
      }
      const res = await authFetch(`${API_BASE}/api/admin/worker-pool/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changed),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || `HTTP ${res.status}`);
      }
      const result = await res.json();
      addNotification({ type: 'success', title: 'Config Saved', message: `Applied ${Object.keys(result.changes || {}).length} change(s)` });
      await loadPoolConfig();
      loadSection('pool');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Config Save Failed', message: e.message });
    } finally { setPoolCfgSaving(false); }
  };

  const updateDraft = (key: string, value: string) => {
    setPoolCfgDraft((prev: any) => ({ ...prev, [key]: value }));
  };

  useEffect(() => {
    if (poolCfgOpen && !poolCfg) loadPoolConfig();
  }, [poolCfgOpen]); // eslint-disable-line

  // ── User management ────────────────────────────────────────────────────
  const loadUsers = useCallback(async () => {
    setUserMgmtLoading(true);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users`);
      const data = await res.json();
      setUserList(Array.isArray(data) ? data : []);
    } catch { setUserList([]); }
    finally { setUserMgmtLoading(false); }
  }, []);

  useEffect(() => {
    loadUsers();
    // Fetch auth type to determine local vs AD mode
    authFetch(`${API_BASE}/auth/config`).then(r => r.json()).then(cfg => {
      setAuthType(cfg.type || 'none');
    }).catch(() => {});
  }, []); // eslint-disable-line

  const isAdMode = authType === 'ad';

  const handleAdLookup = async () => {
    const username = userDlg.username.trim();
    if (!username) return;
    setAdLookupLoading(true);
    setAdLookupError('');
    setAdLookup(null);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users/lookup/${encodeURIComponent(username)}`);
      if (!res.ok) {
        const e = await res.json();
        throw new Error(e.detail || 'User not found');
      }
      const data = await res.json();
      setAdLookup(data);
    } catch (e: any) {
      setAdLookupError(e.message);
    } finally {
      setAdLookupLoading(false);
    }
  };

  const handleSaveUser = async () => {
    const { mode, username, password, role } = userDlg;
    if (!username.trim()) return;
    try {
      const url = mode === 'add'
        ? `${API_BASE}/api/admin/users`
        : `${API_BASE}/api/admin/users/${encodeURIComponent(username)}`;
      const method = mode === 'add' ? 'POST' : 'PUT';
      const body: any = { username: username.trim(), role };
      if (!isAdMode && password) body.password = password;
      const res = await authFetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || 'Failed'); }
      addNotification({ type: 'success', title: mode === 'add' ? 'User Added' : 'User Updated', message: `${username} (${role})` });
      setUserDlg({ ...userDlg, open: false });
      setAdLookup(null);
      setAdLookupError('');
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  const handleDeleteUser = async (username: string) => {
    if (!confirm(`Remove user "${username}"? This cannot be undone.`)) return;
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || 'Failed'); }
      addNotification({ type: 'success', title: 'User Removed', message: username });
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  // ── Derived ──────────────────────────────────────────────────────────────
  const longRunning  = activeQ.filter(q => q.duration_seconds >= WARN_SECS);
  const totalActive  = activeQ.length;

  return (
    <Box sx={{ p: { xs: 1.5, sm: 2, md: 3 }, maxWidth: 1600, mx: 'auto', overflow: 'auto', height: '100%' }}>

      {/* ── Page header ── */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Admin Panel</Typography>
          <Typography variant="body2" color="text.secondary">
            Active queries · Users · System health · Storage · Cache · Audit log
          </Typography>
        </Box>
        <Button variant="outlined" size="small" startIcon={<RefreshIcon />} onClick={loadAll}>
          Refresh All
        </Button>
      </Box>

      {/* Long-running alert */}
      {longRunning.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }} icon={<BlockedIcon />}
          action={
            <Button size="small" color="inherit" onClick={() => loadSection('activeQ')}>Refresh</Button>
          }>
          <strong>{longRunning.length}</strong> quer{longRunning.length > 1 ? 'ies' : 'y'} running
          longer than {WARN_SECS / 60} minutes — consider cancelling to free resources.
        </Alert>
      )}

      <Grid container spacing={3}>

        {/* ════ Active Queries ══════════════════════════════════════════════ */}
        <Grid size={12}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<ActiveIcon color="primary" fontSize="small" />}
              title="Active Queries"
              badge={totalActive}
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => loadSection('activeQ')}>Refresh</Button>
              }
            />
            {loading.activeQ && <LinearProgress sx={{ mb: 1 }} />}

            {!loading.activeQ && activeQ.length === 0 ? (
              <Box sx={{ py: 4, textAlign: 'center', color: 'text.secondary' }}>
                <RunningIcon sx={{ fontSize: 36, mb: 1, opacity: 0.3 }} />
                <Typography variant="body2">No active queries — system is idle</Typography>
              </Box>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['User', 'Status', 'Duration', 'Progress', 'Connection', 'Started', 'Actions'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {activeQ.map((row) => {
                      const isWarn   = row.duration_seconds >= WARN_SECS;
                      const progress = row.chunks_processed > 0
                        ? Math.min(99, Math.round(row.chunks_processed * 5)) : null;
                      return (
                        <TableRow key={row.execution_id} hover
                          sx={isWarn ? { bgcolor: 'rgba(255,152,0,0.06)' } : {}}>

                          {/* User */}
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                              <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                                bgcolor: theme.palette.primary.light }}>
                                {(row.executed_by || 'G')[0].toUpperCase()}
                              </Avatar>
                              <Typography variant="body2">{row.executed_by || 'guest'}</Typography>
                            </Box>
                          </TableCell>

                          {/* Status */}
                          <TableCell>
                            <Chip size="small" label={row.status}
                              color={row.status === 'processing' ? 'primary' : 'default'}
                              variant="outlined"
                              icon={row.status === 'processing'
                                ? <RunningIcon sx={{ fontSize: '12px !important',
                                    animation: 'spin 1.4s linear infinite',
                                    '@keyframes spin': { '0%': { transform: 'rotate(0deg)' }, '100%': { transform: 'rotate(360deg)' } } }} />
                                : undefined}
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          </TableCell>

                          {/* Duration (live ticker) */}
                          <TableCell>
                            <LiveDuration seconds={row.duration_seconds} warn={isWarn} />
                          </TableCell>

                          {/* Progress */}
                          <TableCell sx={{ minWidth: 110 }}>
                            {progress != null ? (
                              <Box>
                                <LinearProgress variant="determinate" value={progress}
                                  sx={{ height: 6, borderRadius: 3, mb: 0.3 }} />
                                <Typography variant="caption" color="text.secondary">
                                  {row.chunks_processed} chunks
                                </Typography>
                              </Box>
                            ) : (
                              <LinearProgress sx={{ height: 6, borderRadius: 3 }} />
                            )}
                          </TableCell>

                          {/* Connection */}
                          <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                            {row.connection_name || '—'}
                          </TableCell>

                          {/* Started */}
                          <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap', color: 'text.secondary' }}>
                            {fmtDate(row.started_at)}
                          </TableCell>

                          {/* Actions */}
                          <TableCell>
                            <Tooltip title="Cancel this query (admin override)">
                              <IconButton size="small" color="error"
                                onClick={() => setCancelTarget(row)}>
                                <CancelIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* ════ System Health ════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<HealthIcon color="primary" fontSize="small" />} title="System Health"
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => loadSection('health')}>Refresh</Button>
              }
            />
            {loading.health && <LinearProgress sx={{ mb: 2 }} />}
            {health && (
              <>
                <Stack direction="row" spacing={1} mb={2} flexWrap="wrap" useFlexGap>
                  <StatusChip ok={health.status === 'healthy'} label={health.status?.toUpperCase()} />
                  <StatusChip ok={health.database?.ok} label={`DB: ${health.database?.ok ? 'OK' : 'Error'}`} />
                  <StatusChip ok={health.s3?.status === 'connected'} label={`S3: ${health.s3?.status || 'n/a'}`} />
                  {health.disk?.warning && <Chip size="small" icon={<WarnIcon />} label="Low Disk" color="warning" />}
                </Stack>
                <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                  <StatCard label="Active Queries"  value={health.queries?.active ?? totalActive}
                    warn={(health.queries?.active ?? totalActive) >= (health.queries?.max_concurrent_global ?? 99)} />
                  <StatCard label="Global Limit"    value={health.queries?.max_concurrent_global ?? '—'} />
                  <StatCard label="Per-User Limit"  value={health.queries?.per_user_limit ?? '—'} />
                  <StatCard label="Queue Waiting"   value={health.queries?.queue_waiting ?? 0}
                    warn={(health.queries?.queue_waiting ?? 0) > 0} />
                  <StatCard label="Disk Free"
                    value={`${health.disk?.free_gb ?? '—'} GB`}
                    warn={health.disk?.warning}
                    sub={`${health.disk?.used_pct ?? '—'}% used`} />
                </Stack>
              </>
            )}
          </Paper>
        </Grid>

        {/* ════ Worker Pool ═════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<RunningIcon color="primary" fontSize="small" />} title="Worker Pool"
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => loadSection('pool')}>Refresh</Button>
              }
            />
            {loading.pool && <LinearProgress sx={{ mb: 2 }} />}
            {poolStats && (
              <>
                <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
                  <StatCard label="Total Workers" value={poolStats.total_workers ?? '—'} />
                  <StatCard label="Active" value={poolStats.active_total ?? 0}
                    warn={(poolStats.active_total ?? 0) >= (poolStats.total_workers ?? 40)} />
                  <StatCard label="Queued" value={poolStats.queued_total ?? 0}
                    warn={(poolStats.queued_total ?? 0) > 0} />
                </Stack>
                {poolStats.by_type && (
                  <TableContainer sx={{ mb: 1 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          {['Type', 'Running', 'Queued', 'Max', 'Completed', 'Failed', 'Timeout', 'Avg Wait', 'Avg Run'].map(h => (
                            <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {Object.entries(poolStats.by_type).map(([type, s]: any) => (
                          <TableRow key={type} hover>
                            <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{type}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <Chip size="small" label={s.running} color={s.running > 0 ? 'primary' : 'default'}
                                sx={{ height: 20, fontSize: 11 }} />
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              {s.queued > 0 ? <Chip size="small" label={s.queued} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>{s.max_concurrent}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>{s.completed}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              {s.failed > 0 ? <Chip size="small" label={s.failed} color="error" sx={{ height: 20, fontSize: 11 }} /> : 0}
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              {s.timeout > 0 ? <Chip size="small" label={s.timeout} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_wait_ms > 0 ? `${s.avg_wait_ms}ms` : '—'}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_run_ms > 0 ? `${(s.avg_run_ms / 1000).toFixed(1)}s` : '—'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
                {poolTasks.length > 0 && (
                  <>
                    <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mt: 1 }}>
                      Active Tasks ({poolTasks.length})
                    </Typography>
                    <TableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            {['Type', 'Execution', 'User', 'Status', 'Duration', 'Action'].map(h => (
                              <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {poolTasks.map((t: any) => (
                            <TableRow key={t.task_id} hover>
                              <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.work_type}</TableCell>
                              <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', fontFamily: 'monospace' }}>
                                {t.execution_id ? t.execution_id.substring(0, 8) + '…' : '—'}
                              </TableCell>
                              <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.username}</TableCell>
                              <TableCell sx={{ py: 0.5, px: 1 }}>
                                <StatusChip ok={t.status === 'running'} label={t.status} />
                              </TableCell>
                              <TableCell sx={{ py: 0.5, px: 1 }}>
                                {t.started_at ? <LiveDuration seconds={Math.round((Date.now() / 1000) - t.started_at)} warn={false} /> : '—'}
                              </TableCell>
                              <TableCell sx={{ py: 0.5, px: 1 }}>
                                <IconButton size="small" color="error"
                                  onClick={async () => {
                                    try {
                                      await authFetch(`${API_BASE}/api/admin/worker-pool/tasks/${t.task_id}/cancel`, { method: 'POST' });
                                      loadSection('pool');
                                    } catch {}
                                  }}>
                                  <CancelIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </>
                )}

                {/* ── Config Editor (collapsible) ── */}
                <Divider sx={{ my: 1.5 }} />
                <Box
                  sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', gap: 0.5, py: 0.5 }}
                  onClick={() => setPoolCfgOpen(o => !o)}
                >
                  <SettingsIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
                  <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ flex: 1 }}>
                    Configure Limits
                  </Typography>
                  {poolCfgOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                </Box>
                <Collapse in={poolCfgOpen}>
                  {poolCfg ? (
                    <Box sx={{ mt: 1 }}>
                      <TableContainer>
                        <Table size="small">
                          <TableHead>
                            <TableRow>
                              {['Type', 'Max Concurrent', 'Default Timeout (s)', 'Max Queue'].map(h => (
                                <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                              ))}
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {['INTERACTIVE', 'REPORT', 'SCHEDULED', 'EXPORT', 'SYSTEM'].map(typeName => {
                              const prefix = typeName.toLowerCase();
                              return (
                                <TableRow key={typeName} hover>
                                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{typeName}</TableCell>
                                  <TableCell sx={{ py: 0.5, px: 1 }}>
                                    <TextField
                                      size="small" type="number" variant="outlined"
                                      value={poolCfgDraft[`${prefix}_max_concurrent`] ?? ''}
                                      onChange={e => updateDraft(`${prefix}_max_concurrent`, e.target.value)}
                                      inputProps={{ min: 1, max: 100, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                                    />
                                  </TableCell>
                                  <TableCell sx={{ py: 0.5, px: 1 }}>
                                    <TextField
                                      size="small" type="number" variant="outlined"
                                      value={poolCfgDraft[`${prefix}_default_timeout`] ?? ''}
                                      onChange={e => updateDraft(`${prefix}_default_timeout`, e.target.value)}
                                      inputProps={{ min: 10, style: { fontSize: 12, padding: '4px 8px', width: 72 } }}
                                    />
                                  </TableCell>
                                  <TableCell sx={{ py: 0.5, px: 1 }}>
                                    <TextField
                                      size="small" type="number" variant="outlined"
                                      value={poolCfgDraft[`${prefix}_max_queue`] ?? ''}
                                      onChange={e => updateDraft(`${prefix}_max_queue`, e.target.value)}
                                      inputProps={{ min: 1, max: 500, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                                    />
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </TableContainer>
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 1.5 }}>
                        <Button size="small" variant="text" onClick={loadPoolConfig} disabled={poolCfgSaving}>
                          Reset
                        </Button>
                        <Button size="small" variant="contained" startIcon={poolCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
                          onClick={handlePoolCfgSave} disabled={poolCfgSaving}>
                          Save
                        </Button>
                      </Box>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                        Changes apply immediately without server restart. Running tasks are not affected.
                      </Typography>
                    </Box>
                  ) : (
                    <LinearProgress sx={{ mt: 1 }} />
                  )}
                </Collapse>
              </>
            )}
          </Paper>
        </Grid>

        {/* ════ User Management ═══════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<AuditIcon color="primary" fontSize="small" />}
              title="User Management"
              action={
                <Button size="small" variant="contained" onClick={() => { setAdLookup(null); setAdLookupError(''); setUserDlg({ open: true, mode: 'add', username: '', password: '', role: 'analyst' }); }}>
                  + Add User
                </Button>
              }
            />
            {userMgmtLoading && <LinearProgress sx={{ mb: 1 }} />}
            {!userMgmtLoading && userList.length === 0 ? (
              <Typography variant="body2" color="text.secondary">No users configured (auth may be disabled)</Typography>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['User', 'Role', 'Actions'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {userList.map(u => (
                      <TableRow key={u.username} hover>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                            <Avatar sx={{ width: 22, height: 22, fontSize: 11, bgcolor: u.role === 'admin' ? theme.palette.error.light : u.role === 'analyst' ? theme.palette.primary.light : theme.palette.grey[400] }}>
                              {u.username[0].toUpperCase()}
                            </Avatar>
                            <Typography variant="body2">{u.username}</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={u.role} color={u.role === 'admin' ? 'error' : u.role === 'analyst' ? 'primary' : 'default'} variant="outlined" sx={{ height: 20, fontSize: 11, fontWeight: 700, textTransform: 'capitalize' }} />
                        </TableCell>
                        <TableCell>
                          <IconButton size="small" onClick={() => setUserDlg({ open: true, mode: 'edit', username: u.username, password: '', role: u.role })}>
                            <SettingsIcon fontSize="small" />
                          </IconButton>
                          <IconButton size="small" color="error" onClick={() => handleDeleteUser(u.username)}>
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* ════ User Activity ════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<UsersIcon color="primary" fontSize="small" />} title="User Activity"
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => { loadSection('userStats'); loadSection('activeQ'); }}>Refresh</Button>
              }
            />
            {loading.userStats && <LinearProgress sx={{ mb: 2 }} />}
            {userStats.length === 0 && !loading.userStats ? (
              <Typography variant="body2" color="text.secondary">No user activity today</Typography>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['User', 'Active Now', 'Queries Today', 'Errors', 'Last Active'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem' }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {userStats.map(u => (
                      <TableRow key={u.username} hover>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                            <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                              bgcolor: theme.palette.primary.light }}>
                              {u.username[0].toUpperCase()}
                            </Avatar>
                            <Typography variant="body2">{u.username}</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          {u.active_now > 0
                            ? <Chip size="small" label={u.active_now} color="primary" variant="outlined"
                                sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
                            : <Typography variant="body2" color="text.disabled">—</Typography>
                          }
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.8rem' }}>{u.queries_today}</TableCell>
                        <TableCell>
                          {u.failed_today > 0
                            ? <Chip size="small" label={u.failed_today} color="error" variant="outlined"
                                sx={{ height: 20, fontSize: 11 }} />
                            : <Typography variant="body2" color="text.disabled">—</Typography>
                          }
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem', color: 'text.secondary', whiteSpace: 'nowrap' }}>
                          {fmtDate(u.last_seen)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* ════ Storage ══════════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 8 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<StorageIcon color="primary" fontSize="small" />}
              title="Storage"
              action={
                <Button size="small"
                  startIcon={cleanupBusy ? <CircularProgress size={14} /> : <CleanupIcon />}
                  variant="outlined" color="warning" onClick={handleCleanup} disabled={cleanupBusy}>
                  Clean Up Now
                </Button>
              }
            />
            {loading.storage && <LinearProgress sx={{ mb: 2 }} />}
            {storage && (
              <>
                <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
                  {Object.entries(storage.directories || {}).map(([name, info]: [string, any]) => (
                    <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <FolderIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                      <Box>
                        <Typography variant="caption" color="text.secondary"
                          sx={{ textTransform: 'capitalize', display: 'block' }}>{name}</Typography>
                        <Typography variant="body2" fontWeight={600}>
                          {fmtSize(info.size_bytes)}
                          <Typography component="span" variant="caption"
                            color="text.secondary" sx={{ ml: 0.5 }}>
                            {info.file_count} files
                          </Typography>
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                </Stack>
                {storage.disk && (
                  <Box sx={{ mb: 1.5 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography variant="caption" color="text.secondary">Disk usage</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {fmtSize(storage.disk.used_gb * 1024 ** 3)} / {fmtSize(storage.disk.total_gb * 1024 ** 3)}
                      </Typography>
                    </Box>
                    <LinearProgress variant="determinate" value={storage.disk.used_pct}
                      color={storage.disk.used_pct > 85 ? 'error' : storage.disk.used_pct > 70 ? 'warning' : 'primary'}
                      sx={{ height: 8, borderRadius: 4 }} />
                  </Box>
                )}
                <Divider sx={{ my: 1.5 }} />
                <Typography variant="caption" color="text.secondary">
                  Downloads expire after <strong>{storage.settings?.downloads_expiry_days}d</strong> ·
                  Execution history kept <strong>{storage.settings?.execution_retention_days}d</strong> ·
                  Cache limit <strong>{fmtMb(storage.settings?.max_cache_size_mb)}</strong> ·
                  Downloads limit <strong>{fmtMb(storage.settings?.max_downloads_size_mb)}</strong>
                </Typography>
              </>
            )}
          </Paper>
        </Grid>

        {/* ════ Cache ════════════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 4 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<CacheIcon color="primary" fontSize="small" />}
              title="Query Cache"
              action={
                <Button size="small"
                  startIcon={cacheBusy ? <CircularProgress size={14} /> : <ClearCacheIcon />}
                  variant="outlined" color="error" onClick={handleClearCache} disabled={cacheBusy}>
                  Clear
                </Button>
              }
            />
            {loading.cache && <LinearProgress sx={{ mb: 2 }} />}
            {cache && (
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <StatCard label="Cached Results" value={cache.total_entries ?? cache.count ?? '—'} />
                <StatCard label="Cache Size"
                  value={fmtSize((cache.total_size_bytes ?? cache.size_bytes) || 0)} />
                <StatCard label="Hit Rate"
                  value={cache.hit_rate != null ? `${Math.round(cache.hit_rate * 100)}%` : '—'} />
              </Stack>
            )}
            {!loading.cache && !cache && (
              <Typography variant="body2" color="text.secondary">Cache stats unavailable</Typography>
            )}
          </Paper>
        </Grid>

        {/* ════ Audit Log ════════════════════════════════════════════════════ */}
        <Grid size={12}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<AuditIcon color="primary" fontSize="small" />} title="Audit Log" />

            <Stack direction="row" spacing={1.5} mb={2}>
              <TextField
                size="small" placeholder="Filter by user"
                value={auditSearch}
                onChange={e => { setAuditSearch(e.target.value); setAuditPage(0); }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                  endAdornment: auditSearch
                    ? <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setAuditSearch('')}>
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    : null,
                }}
                sx={{ width: 200 }}
              />
              <TextField
                size="small" placeholder="Filter by action"
                value={auditAction}
                onChange={e => { setAuditAction(e.target.value); setAuditPage(0); }}
                InputProps={{
                  endAdornment: auditAction
                    ? <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setAuditAction('')}>
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    : null,
                }}
                sx={{ width: 200 }}
              />
            </Stack>

            {loading.audit && <LinearProgress sx={{ mb: 1 }} />}
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Timestamp', 'User', 'Action', 'Resource', 'IP'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {auditLog.length === 0 && !loading.audit ? (
                    <TableRow>
                      <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                        No audit entries found
                      </TableCell>
                    </TableRow>
                  ) : auditLog.map((row, i) => (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                        {fmtDate(row.timestamp)}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{row.username || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.action} variant="outlined"
                          sx={{ fontSize: '0.7rem', height: 20 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                        {row.resource_type
                          ? `${row.resource_type}${row.resource_id ? ` #${String(row.resource_id).substring(0, 8)}` : ''}`
                          : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                        {row.ip_address || '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              component="div"
              count={auditTotal > 0 ? auditTotal : auditLog.length}
              page={auditPage}
              rowsPerPage={AUDIT_PER_PAGE}
              rowsPerPageOptions={[AUDIT_PER_PAGE]}
              onPageChange={(_, p) => setAuditPage(p)}
            />
          </Paper>
        </Grid>

      </Grid>

      {/* ── Cancel confirm dialog ── */}
      <Dialog open={Boolean(cancelTarget)} onClose={() => !cancelBusy && setCancelTarget(null)}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CancelIcon color="error" />
          Cancel Query
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to cancel the query running for{' '}
            <strong>{cancelTarget?.executed_by || 'guest'}</strong>?
            {cancelTarget?.duration_seconds >= WARN_SECS && (
              <><br /><br />
                <Typography component="span" color="warning.main" fontWeight={600}>
                  This query has been running for {fmtDuration(cancelTarget?.duration_seconds)}.
                </Typography>
              </>
            )}
          </DialogContentText>
          {cancelTarget && (
            <Box sx={{ mt: 2, p: 1.5, bgcolor: 'action.hover', borderRadius: 1, fontSize: '0.8rem' }}>
              <strong>ID:</strong> {cancelTarget.execution_id?.substring(0, 16)}…<br />
              <strong>Connection:</strong> {cancelTarget.connection_name || '—'}<br />
              <strong>Started:</strong> {fmtDate(cancelTarget.started_at)}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelTarget(null)} disabled={cancelBusy}>Keep Running</Button>
          <Button variant="contained" color="error" onClick={handleAdminCancel} disabled={cancelBusy}
            startIcon={cancelBusy ? <CircularProgress size={14} /> : <CancelIcon />}>
            Cancel Query
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Add / Edit User Dialog ── */}
      <Dialog open={userDlg.open} onClose={() => setUserDlg({ ...userDlg, open: false })} maxWidth="xs" fullWidth>
        <DialogTitle>{userDlg.mode === 'add' ? 'Add User' : `Edit User — ${userDlg.username}`}</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
          {userDlg.mode === 'add' && (
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField label={isAdMode ? 'Windows ID' : 'Username'} size="small" fullWidth value={userDlg.username}
                onChange={e => { setUserDlg({ ...userDlg, username: e.target.value }); setAdLookup(null); setAdLookupError(''); }}
                autoFocus
                onKeyDown={e => { if (isAdMode && e.key === 'Enter') { e.preventDefault(); handleAdLookup(); } }}
              />
              {isAdMode && (
                <Button size="small" variant="outlined" onClick={handleAdLookup}
                  disabled={!userDlg.username.trim() || adLookupLoading}
                  sx={{ minWidth: 90, whiteSpace: 'nowrap' }}>
                  {adLookupLoading ? <CircularProgress size={18} /> : 'Lookup'}
                </Button>
              )}
            </Box>
          )}

          {/* AD lookup result — show display name & email */}
          {isAdMode && adLookup && (
            <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'success.50' }}>
              <Typography variant="body2" fontWeight={600}>{adLookup.display_name}</Typography>
              {adLookup.email && <Typography variant="caption" color="text.secondary">{adLookup.email}</Typography>}
              {adLookup.groups?.length > 0 && (
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  Groups: {adLookup.groups.slice(0, 5).join(', ')}{adLookup.groups.length > 5 ? ` (+${adLookup.groups.length - 5} more)` : ''}
                </Typography>
              )}
            </Paper>
          )}
          {isAdMode && adLookupError && (
            <Alert severity="error" sx={{ py: 0 }}>{adLookupError}</Alert>
          )}

          {/* Password — only for local auth */}
          {!isAdMode && (
            <TextField label={userDlg.mode === 'add' ? 'Password' : 'New Password (leave blank to keep)'} size="small" fullWidth type="password"
              value={userDlg.password} onChange={e => setUserDlg({ ...userDlg, password: e.target.value })} />
          )}

          <TextField label="Role" size="small" fullWidth select value={userDlg.role}
            onChange={e => setUserDlg({ ...userDlg, role: e.target.value })}>
            <MenuItem value="admin">Admin</MenuItem>
            <MenuItem value="analyst">Analyst</MenuItem>
            <MenuItem value="viewer">Viewer</MenuItem>
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUserDlg({ ...userDlg, open: false })}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveUser}
            disabled={
              userDlg.mode === 'add' && (
                !userDlg.username.trim() ||
                (!isAdMode && !userDlg.password)
              )
            }>
            {userDlg.mode === 'add' ? 'Add User' : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default AdminPage;
