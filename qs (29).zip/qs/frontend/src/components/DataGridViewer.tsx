import React, { useState, useEffect, useRef, useMemo, useCallback, memo } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Box, Typography, Button, Paper, IconButton, Tooltip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TableSortLabel,
  TextField, MenuItem, Select, Menu, ToggleButtonGroup, ToggleButton,
  CircularProgress, LinearProgress, Alert, Chip, Divider,
  FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions,
  Checkbox, InputAdornment, Popover,
} from '@mui/material';
import {
  Download as DownloadIcon, Close as CloseIcon, Refresh as RefreshIcon,
  FilterList as FilterIcon, TableChart as TableIcon, BarChart as ChartIcon,
  PivotTableChart as PivotIcon, FirstPage, LastPage, NavigateBefore, NavigateNext,
  InsertDriveFile as CsvIcon, TableView as ExcelIcon, DataObject as JsonIcon,
  Add as AddIcon, Delete as DeleteIcon,
  ViewColumn as ColumnsIcon, PushPin as PinIcon, Search as SearchIcon,
  InfoOutlined as InfoIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell, ScatterChart, Scatter, ZAxis,
  XAxis, YAxis, CartesianGrid, Tooltip as RTooltip,
  Legend, ResponsiveContainer,
} from 'recharts';

const API_BASE_URL = import.meta.env.VITE_API_URL || '';
const FROZEN_COL_WIDTH = 160;
const MAX_VIS_COLS = 50;   // keep DOM count manageable

// ─────────────────────────────────────────────────────────────
// Number formatting
// ─────────────────────────────────────────────────────────────
const SCIENTIFIC_RE = /^-?[\d.]+[eE][+-]?\d+$/;

const fmtNum = (v) => {
  if (v == null || (typeof v === 'number' && isNaN(v))) return '—';
  const num = typeof v === 'string' ? parseFloat(v) : v;
  if (isNaN(num)) return String(v);
  const isNeg = num < 0;
  const abs   = Math.abs(num);
  const fmt   = Number.isInteger(abs) && abs < 1e15
    ? abs.toLocaleString()
    : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return isNeg ? `(${fmt})` : fmt;
};

// Pre-defined style objects (defined ONCE outside the component) so that
// formatValue never allocates new objects on the hot render path.
const _S = {
  null: { color: '#9e9e9e', fontStyle: 'italic', fontSize: 11, letterSpacing: '0.02em' },
  boolT: { color: '#2e7d32', fontWeight: 700, fontSize: 11 },
  boolF: { color: '#757575', fontWeight: 600, fontSize: 11 },
  neg:   { color: '#d32f2f', fontVariantNumeric: 'tabular-nums' },
  pos:   { fontVariantNumeric: 'tabular-nums' },
};

// Pure function — no React hooks, no MUI components — safe to call inside a
// tight map() on every cell without React overhead per invocation.
const formatValue = (value) => {
  if (value === null || value === undefined)
    return <span style={_S.null}>NULL</span>;
  if (typeof value === 'boolean')
    return <span style={value ? _S.boolT : _S.boolF}>{value ? 'TRUE' : 'FALSE'}</span>;

  let numVal = typeof value === 'number' ? value : null;
  if (numVal === null && typeof value === 'string' && SCIENTIFIC_RE.test(value.trim())) {
    const p = parseFloat(value.trim());
    if (!isNaN(p)) numVal = p;
  }
  if (numVal !== null) {
    const isNeg = numVal < 0;
    const abs   = Math.abs(numVal);
    const fmt   = Number.isInteger(abs) && abs < 1e15
      ? abs.toLocaleString()
      : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
    if (isNeg)
      return <span style={_S.neg}>({fmt})</span>;
    return <span style={_S.pos}>{fmt}</span>;
  }
  return value.toString();
};

// ─────────────────────────────────────────────────────────────
// Advanced AND/OR Filter Builder
// ─────────────────────────────────────────────────────────────
const OPERATORS = [
  { value: 'contains',     label: 'Contains' },
  { value: 'not_contains', label: 'Does not contain' },
  { value: 'equals',       label: 'Equals' },
  { value: 'not_equals',   label: 'Not equals' },
  { value: 'starts_with',  label: 'Starts with' },
  { value: 'ends_with',    label: 'Ends with' },
  { value: 'gt',           label: '>' },
  { value: 'gte',          label: '>=' },
  { value: 'lt',           label: '<' },
  { value: 'lte',          label: '<=' },
  { value: 'is_null',      label: 'Is null' },
  { value: 'is_not_null',  label: 'Is not null' },
];

const NO_VALUE_OPS = new Set(['is_null', 'is_not_null']);

const FilterBuilder = ({ columns, value, onChange }) => {
  const { conjunction = 'AND', conditions = [] } = value || {};

  const setConjunction = (c) => onChange({ conjunction: c, conditions });

  const setCondition = (idx, patch) => {
    const next = conditions.map((c, i) => i === idx ? { ...c, ...patch } : c);
    onChange({ conjunction, conditions: next });
  };

  const addCondition = () => onChange({
    conjunction,
    conditions: [...conditions, { col: columns[0] || '', op: 'contains', val: '' }],
  });

  const removeCondition = (idx) => {
    const next = conditions.filter((_, i) => i !== idx);
    onChange({ conjunction, conditions: next });
  };

  return (
    <Box sx={{ px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
        <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mr: 0.5 }}>
          FILTER
        </Typography>
        <ToggleButtonGroup
          value={conjunction} exclusive
          onChange={(_, v) => v && setConjunction(v)}
          size="small"
          sx={{ '& .MuiToggleButton-root': { px: 1.5, py: 0.25, fontSize: 12, fontWeight: 700, minWidth: 44 } }}
        >
          <ToggleButton value="AND">AND</ToggleButton>
          <ToggleButton value="OR">OR</ToggleButton>
        </ToggleButtonGroup>
        <Button size="small" startIcon={<AddIcon sx={{ fontSize: 14 }} />} onClick={addCondition}
          sx={{ fontSize: 12, textTransform: 'none' }}>
          Add condition
        </Button>
        {conditions.length > 0 && (
          <Button size="small" color="error" sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}
            onClick={() => onChange({ conjunction, conditions: [] })}>
            Clear all
          </Button>
        )}
      </Box>

      {conditions.length === 0 && (
        <Typography variant="caption" color="text.disabled" sx={{ pl: 0.5 }}>
          No filters — showing all rows
        </Typography>
      )}

      {conditions.map((cond, idx) => (
        <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.75, flexWrap: 'wrap' }}>
          {idx > 0 && (
            <Chip label={conjunction} size="small" variant="outlined" color="primary"
              sx={{ height: 22, fontSize: 11, fontWeight: 700, minWidth: 36 }} />
          )}
          {idx === 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ minWidth: 36, textAlign: 'center' }}>
              WHERE
            </Typography>
          )}

          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select value={cond.col} onChange={e => setCondition(idx, { col: e.target.value })}
              sx={{ fontSize: 13 }}>
              {columns.map(c => <MenuItem key={c} value={c} sx={{ fontSize: 13 }}>{c}</MenuItem>)}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 160 }}>
            <Select value={cond.op} onChange={e => setCondition(idx, { op: e.target.value })}
              sx={{ fontSize: 13 }}>
              {OPERATORS.map(o => <MenuItem key={o.value} value={o.value} sx={{ fontSize: 13 }}>{o.label}</MenuItem>)}
            </Select>
          </FormControl>

          {!NO_VALUE_OPS.has(cond.op) && (
            <TextField
              size="small" placeholder="value…" value={cond.val}
              onChange={e => setCondition(idx, { val: e.target.value })}
              onKeyDown={e => e.key === 'Enter' && e.currentTarget.blur()}
              sx={{ minWidth: 160, '& input': { fontSize: 13 } }}
            />
          )}

          <Tooltip title="Remove condition">
            <IconButton size="small" onClick={() => removeCondition(idx)} sx={{ color: 'text.disabled' }}>
              <DeleteIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>
      ))}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// ChartConfig sidebar
// ─────────────────────────────────────────────────────────────
interface ChartConfigProps {
  cols: string[];
  chartType?: string;
  setChartType?: (v: string) => void;
  xCol: string;
  setXCol: (v: string) => void;
  yCol: string;
  setYCol: (v: string) => void;
  agg: string;
  setAgg: (v: string) => void;
  topN: number;
  setTopN: (v: number) => void;
  onRefresh: () => void;
  xLabel?: string;
  yLabel?: string;
  renderLabel?: string;
  hideChartType?: boolean;
}
const ChartConfig = ({
  cols, chartType, setChartType, xCol, setXCol, yCol, setYCol,
  agg, setAgg, topN, setTopN, onRefresh, xLabel, yLabel, renderLabel, hideChartType,
}: ChartConfigProps) => (
  <Box sx={{ width: 220, flexShrink: 0, p: 2, borderRight: 1, borderColor: 'divider', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
    {!hideChartType && (
      <TextField select label="Chart type" size="small" value={chartType} onChange={e => setChartType(e.target.value)}>
        {['bar', 'line', 'pie', 'area', 'scatter'].map(t => <MenuItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</MenuItem>)}
      </TextField>
    )}
    <TextField select label={xLabel || 'X-axis / Group By'} size="small" value={xCol} onChange={e => setXCol(e.target.value)}>
      {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
    </TextField>
    <TextField select label={yLabel || 'Y-axis / Value'} size="small" value={yCol} onChange={e => setYCol(e.target.value)}>
      {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
    </TextField>
    <TextField select label="Aggregation" size="small" value={agg} onChange={e => setAgg(e.target.value)}>
      {['sum','avg','count','max','min'].map(a => <MenuItem key={a} value={a}>{a.toUpperCase()}</MenuItem>)}
    </TextField>
    <TextField select label="Top N" size="small" value={topN} onChange={e => setTopN(+e.target.value)}>
      {[10,20,50,100,200].map(n => <MenuItem key={n} value={n}>Top {n}</MenuItem>)}
    </TextField>
    <Button variant="contained" size="small" onClick={onRefresh}>{renderLabel || 'Render'}</Button>
  </Box>
);

// ─────────────────────────────────────────────────────────────
// Chart helpers
// ─────────────────────────────────────────────────────────────
const CHART_COLORS = ['#00AEEF','#2EB67D','#ECB22E','#E01E5A','#611f69','#9b59b6','#36C5F0','#0089BD','#f39c12','#1abc9c'];

const fmtAxisNum = (v: any): string => {
  const n = Number(v);
  if (v == null || isNaN(n)) return '';
  const abs = Math.abs(n), sign = n < 0 ? '-' : '';
  if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(1)}B`;
  if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(1)}K`;
  return `${sign}${Number.isInteger(abs) ? abs : abs.toFixed(2)}`;
};

const ChartTooltipContent = ({ active, payload, agg, yCol }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  return (
    <Paper elevation={6} sx={{ p: 1.5, maxWidth: 280, border: '1px solid', borderColor: 'divider' }}>
      <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, wordBreak: 'break-word' }}>{d?.label}</Typography>
      <Typography variant="caption" display="block">{(agg || '').toUpperCase()} {yCol}: <strong>{fmtNum(d?.value)}</strong></Typography>
      <Typography variant="caption" display="block" color="text.secondary">Count: {(d?.count ?? 0).toLocaleString()}</Typography>
      <Typography variant="caption" display="block" color="text.secondary">Share: {d?.pct}%</Typography>
    </Paper>
  );
};

const PieTooltipContent = ({ active, payload, agg, yCol }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  return (
    <Paper elevation={6} sx={{ p: 1.5, maxWidth: 280, border: '1px solid', borderColor: 'divider' }}>
      <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, wordBreak: 'break-word' }}>{d?.label}</Typography>
      <Typography variant="caption" display="block">{(agg || '').toUpperCase()} {yCol}: <strong>{fmtNum(d?.value)}</strong></Typography>
      <Typography variant="caption" display="block" color="text.secondary">Count: {(d?.count ?? 0).toLocaleString()}</Typography>
      <Typography variant="caption" display="block" color="text.secondary">Share: {d?.pct}%</Typography>
    </Paper>
  );
};

// ─────────────────────────────────────────────────────────────
// ChartRenderer — Recharts-powered with axes, tooltips, legends
// ─────────────────────────────────────────────────────────────
const ChartRenderer = ({ data, type }: { data: any; type: string }) => {
  if (!data?.data?.length)
    return <Typography color="text.secondary" sx={{ p: 4, textAlign: 'center' }}>No data — configure columns and click Render</Typography>;

  const agg  = data.agg  || 'sum';
  const yCol = data.y_col || 'value';
  const xCol = data.x_col || 'label';
  const items = data.data.slice(0, 50).map((d: any) => ({
    ...d,
    shortLabel: d.label != null && String(d.label).length > 18 ? String(d.label).slice(0, 17) + '…' : String(d.label ?? ''),
  }));

  const seriesName = `${agg.toUpperCase()}(${yCol})`;
  const commonMargin = { top: 16, right: 32, left: 16, bottom: 90 };
  const tooltipEl = <ChartTooltipContent agg={agg} yCol={yCol} />;

  const xAxisProps: any = {
    dataKey: 'shortLabel',
    tick: { fontSize: 11 },
    angle: -38,
    textAnchor: 'end',
    height: 90,
    interval: 0,
    label: { value: xCol, position: 'insideBottom', offset: -4, fontSize: 12, fill: '#666' },
  };
  const yAxisProps: any = {
    tickFormatter: fmtAxisNum,
    tick: { fontSize: 11 },
    width: 72,
    label: { value: seriesName, angle: -90, position: 'insideLeft', offset: 14, fontSize: 12, fill: '#666' },
  };

  const footer = (
    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', px: 2, pb: 1 }}>
      {data.groups} groups · {Number(data.total_rows).toLocaleString()} total rows · Grand total: <strong>{fmtNum(data.grand_total)}</strong>
    </Typography>
  );

  /* ── Bar ── */
  if (type === 'bar') return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <BarChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Bar dataKey="value" name={seriesName} radius={[3, 3, 0, 0]} maxBarSize={60}>
            {items.map((_: any, i: number) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Line ── */
  if (type === 'line') return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <LineChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Line dataKey="value" name={seriesName} type="monotone" stroke={CHART_COLORS[0]}
            strokeWidth={2} dot={{ r: 4, fill: CHART_COLORS[0], strokeWidth: 0 }} activeDot={{ r: 6 }} />
        </LineChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Area ── */
  if (type === 'area') return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <AreaChart data={items} margin={commonMargin}>
          <defs>
            <linearGradient id="chartAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={CHART_COLORS[0]} stopOpacity={0.25} />
              <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0.03} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Area dataKey="value" name={seriesName} type="monotone"
            stroke={CHART_COLORS[0]} fill="url(#chartAreaGrad)"
            strokeWidth={2} dot={{ r: 3, fill: CHART_COLORS[0], strokeWidth: 0 }} activeDot={{ r: 5 }} />
        </AreaChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Scatter (dot plot — category X, numeric Y) ── */
  if (type === 'scatter') {
    const scatterData = items.map((d: any, i: number) => ({ ...d, x: i, y: d.value }));
    return (
      <Box sx={{ width: '100%' }}>
        <ResponsiveContainer width="100%" height={420}>
          <ScatterChart margin={commonMargin}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="x" type="number" domain={[- 0.5, items.length - 0.5]}
              tick={false} height={90}
              label={{ value: xCol, position: 'insideBottom', offset: -4, fontSize: 12, fill: '#666' }} />
            <YAxis dataKey="y" tickFormatter={fmtAxisNum} tick={{ fontSize: 11 }} width={72}
              label={{ value: seriesName, angle: -90, position: 'insideLeft', offset: 14, fontSize: 12, fill: '#666' }} />
            <ZAxis range={[60, 60]} />
            <RTooltip content={tooltipEl} cursor={{ strokeDasharray: '3 3' }} />
            <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
            <Scatter name={seriesName} data={scatterData} fill={CHART_COLORS[0]} fillOpacity={0.8} />
          </ScatterChart>
        </ResponsiveContainer>
        {/* Custom X tick labels since XAxis uses numeric indices */}
        <Box sx={{ display: 'flex', overflow: 'auto', pl: '88px', pr: '32px', gap: 0 }}>
          {items.map((d: any, i: number) => (
            <Typography key={i} variant="caption" sx={{ flex: 1, textAlign: 'center', transform: 'rotate(-38deg)', transformOrigin: 'top center', whiteSpace: 'nowrap', fontSize: 10, color: 'text.secondary', minWidth: 0 }} title={d.label}>
              {d.shortLabel}
            </Typography>
          ))}
        </Box>
        {footer}
      </Box>
    );
  }

  /* ── Pie ── */
  if (type === 'pie') {
    const pieTip = <PieTooltipContent agg={agg} yCol={yCol} />;
    const renderPctLabel = ({ pct, cx, cy, midAngle, innerRadius, outerRadius }: any) => {
      if (pct < 3) return null;
      const RADIAN = Math.PI / 180;
      const radius = innerRadius + (outerRadius - innerRadius) * 0.6;
      const x = cx + radius * Math.cos(-midAngle * RADIAN);
      const y = cy + radius * Math.sin(-midAngle * RADIAN);
      return <text x={x} y={y} fill="#fff" textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight={600}>{pct}%</text>;
    };
    return (
      <Box sx={{ width: '100%' }}>
        <ResponsiveContainer width="100%" height={440}>
          <PieChart>
            <Pie data={items} dataKey="value" nameKey="label"
              cx="50%" cy="45%" outerRadius={150}
              labelLine={false} label={renderPctLabel}>
              {items.map((_: any, i: number) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Pie>
            <RTooltip content={pieTip} />
            <Legend
              formatter={(_v: any, entry: any) => (
                <span style={{ fontSize: 12, color: '#444' }} title={entry?.payload?.label}>{
                  entry?.payload?.label?.length > 30 ? entry.payload.label.slice(0, 29) + '…' : entry?.payload?.label
                }</span>
              )}
              wrapperStyle={{ maxHeight: 120, overflowY: 'auto' }}
            />
          </PieChart>
        </ResponsiveContainer>
        {footer}
      </Box>
    );
  }

  return null;
};

// ─────────────────────────────────────────────────────────────
// VirtualRow — memoized so unchanged rows skip re-render on scroll
// ─────────────────────────────────────────────────────────────
interface VirtualRowProps {
  virtualRow: { index: number; key: string | number; start: number; size: number; [key: string]: any };
  row: Record<string, unknown>;
  rowBg: string;
  startRow: number;
  tableCols: string[];
  pinnedIdxMap: Map<string, number>;
  pinnedVisible: string[];
  refreshing: boolean;
  measureRef: (el: HTMLTableRowElement | null) => void;
}

const VirtualRow = memo(function VirtualRow({
  virtualRow, row, rowBg, startRow, tableCols, pinnedIdxMap, pinnedVisible, refreshing, measureRef,
}: VirtualRowProps) {
  const idx = virtualRow.index;
  const [copiedCol, setCopiedCol] = useState<string | null>(null);

  const handleCellClick = useCallback((col: string, value: unknown) => {
    const text = value === null || value === undefined ? '' : String(value);
    navigator.clipboard.writeText(text).then(() => {
      setCopiedCol(col);
      setTimeout(() => setCopiedCol(null), 900);
    }).catch(() => {});
  }, []);
  return (
    <TableRow
      key={virtualRow.key}
      data-index={idx}
      ref={measureRef}
      hover
      sx={{ opacity: refreshing ? 0.6 : 1, transition: 'opacity 0.15s' }}
    >
      {/* Row number cell */}
      <TableCell sx={{
        color: 'text.secondary', textAlign: 'center', fontVariantNumeric: 'tabular-nums',
        ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 2, bgcolor: rowBg, boxShadow: 'inset -1px 0 0 #e2e8f0' } : {}),
      }}>
        {startRow + idx}
      </TableCell>

      {tableCols.map((col) => {
        const pi = pinnedIdxMap.get(col);
        const isPinned = pi !== undefined;
        const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
        const copied = copiedCol === col;
        return (
          <TableCell
            key={col}
            onClick={() => handleCellClick(col, row[col])}
            title="Click to copy"
            sx={{
              whiteSpace: 'nowrap',
              maxWidth: isPinned ? FROZEN_COL_WIDTH : 300,
              overflow: 'hidden', textOverflow: 'ellipsis',
              cursor: 'pointer',
              transition: 'background-color 0.15s',
              bgcolor: copied ? 'success.light' : undefined,
              ...(isPinned ? {
                position: 'sticky',
                left: 56 + pi * FROZEN_COL_WIDTH,
                zIndex: 2,
                bgcolor: copied ? 'success.light' : rowBg,
                minWidth: FROZEN_COL_WIDTH,
                ...(isLastPinned
                  ? { boxShadow: '3px 0 6px rgba(0,0,0,0.12)' }
                  : { boxShadow: 'inset -1px 0 0 #e2e8f0' }),
              } : {}),
            }}
          >
            {copied ? <span style={{ color: '#2e7d32', fontWeight: 700, fontSize: 11 }}>✓ copied</span> : formatValue(row[col])}
          </TableCell>
        );
      })}
    </TableRow>
  );
});

// ─────────────────────────────────────────────────────────────
// DataGridViewer
// ─────────────────────────────────────────────────────────────
interface DataGridViewerProps {
  executionId?: string;
  fileId?: string;
  filePath?: string;
  connectionId?: string;
  embedded?: boolean;
  title?: string;
  onClose?: () => void;
}

const DataGridViewer = ({
  executionId,
  fileId,
  filePath,
  connectionId,
  embedded = false,
  title,
  onClose,
}: DataGridViewerProps) => {
  const sourceType = executionId ? 'execution' : fileId ? 'fileId' : filePath ? 'filePath' : null;

  const buildDataUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/results?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/preview?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/data?${params}`;
    }
    return null;
  };

  const buildChartUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/chart-data?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/chart-data?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/chart-data?${params}`;
    }
    return null;
  };

  // ── Table state ──────────────────────────────────────────
  const [data,       setData]       = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error,      setError]      = useState(null);
  const [page,       setPage]       = useState(1);
  const [pageSize,   setPageSize]   = useState(100);
  const [totalRows,  setTotalRows]  = useState(0);
  const [sortColumn,    setSortColumn]    = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');

  // ── Column visibility & pinning ──────────────────────────
  // pinnedCols: array of col names (in pin order, left-to-right)
  // visibleCols: null = all visible, Set<string> = explicit visible subset
  const [pinnedCols,   setPinnedCols]   = useState([]);
  const [visibleCols,  setVisibleCols]  = useState(null);
  const [showColPanel, setShowColPanel] = useState(false);
  const [colSearch,    setColSearch]    = useState('');

  // ── Wide-table column projection ─────────────────────────
  // When backend auto-projects (>50 cols), it returns all_columns metadata
  const [allSourceColumns, setAllSourceColumns] = useState<string[] | null>(null);
  const [columnProjection, setColumnProjection] = useState(false);
  const [autoPartition, setAutoPartition] = useState<Record<string, string> | null>(null);

  // ── Column stats panel ───────────────────────────────────
  const [statsCol,    setStatsCol]    = useState<string | null>(null);
  const [statsData,   setStatsData]   = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  // ── Filters ──────────────────────────────────────────────
  const [showFilters,   setShowFilters]   = useState(false);
  const [advFilter,     setAdvFilter]     = useState({ conjunction: 'AND', conditions: [] });
  const [appliedFilter, setAppliedFilter] = useState(null);

  // ── View ─────────────────────────────────────────────────
  const [viewMode,       setViewMode]       = useState('table');
  const [exportMsg,      setExportMsg]      = useState(null);
  const [exportAnchorEl, setExportAnchorEl] = useState(null);

  // ── Chart / Pivot ─────────────────────────────────────────
  const [chartType,    setChartType]    = useState('bar');
  const [chartXCol,    setChartXCol]    = useState('');
  const [chartYCol,    setChartYCol]    = useState('');
  const [chartAgg,     setChartAgg]     = useState('sum');
  const [chartTopN,    setChartTopN]    = useState(20);
  const [chartData,    setChartData]    = useState(null);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartError,   setChartError]   = useState(null);

  const abortRef          = useRef(null);
  const hasDataRef        = useRef(false);  // true after first successful load for current source
  const colsInitRef       = useRef(false);  // true after auto-col-init for current source
  const tableContainerRef = useRef(null);   // scrolling container for row virtualizer
  const chartContainerRef = useRef<HTMLDivElement>(null);
  // Prefetch cache: key → page data. Keyed by page+sort+filter+pageSize so stale
  // entries are never served after the user changes query params.
  const prefetchCacheRef   = useRef<Map<string, any>>(new Map());
  // In-flight set: keys currently being fetched in the background.
  // Prevents duplicate prefetch requests when multiple renders fire before one resolves.
  const prefetchInflightRef = useRef<Set<string>>(new Set());

  // ── Release temp result file when switching to a NEW execution ──────────────
  // Only fires when executionId changes from one non-null value to another.
  // We do NOT delete on unmount — the server's 30-min cleanup job handles that.
  // This avoids the race where React re-renders/remounts delete the file before
  // the grid has a chance to load it.
  const prevExecutionIdRef = useRef<string | undefined>(undefined);
  useEffect(() => {
    const old = prevExecutionIdRef.current;
    prevExecutionIdRef.current = executionId;
    if (old && executionId && old !== executionId) {
      // Switched to a different result — release the old temp file
      fetch(`${API_BASE_URL}/api/executions/${old}/results`, { method: 'DELETE' }).catch(() => {});
    }
  }, [executionId]); // eslint-disable-line

  // ── Reset on source change ───────────────────────────────
  useEffect(() => {
    hasDataRef.current  = false;
    colsInitRef.current = false;
    prefetchCacheRef.current.clear();
    prefetchInflightRef.current.clear();
    setData(null); setError(null); setPage(1);
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setSortColumn(null); setChartData(null);
    setViewMode('table'); setLoading(true); setRefreshing(false);
    setPinnedCols([]); setVisibleCols(null); setColSearch('');
    setChartXCol(''); setChartYCol('');
    setAllSourceColumns(null); setColumnProjection(false); setAutoPartition(null);
  }, [executionId, fileId, filePath, connectionId]); // eslint-disable-line

  // ── Auto-init columns on first data load ─────────────────
  useEffect(() => {
    if (!data?.columns || colsInitRef.current) return;
    colsInitRef.current = true;
    const c = data.columns;

    // Limit visible cols for wide datasets
    if (c.length > MAX_VIS_COLS) {
      setVisibleCols(new Set(c.slice(0, MAX_VIS_COLS)));
    }

    // Auto-pick chart columns
    if (!chartXCol) {
      const firstRow = data.rows?.[0] || {};
      const textCols = c.filter(col => typeof firstRow[col] === 'string');
      const numCols  = c.filter(col => typeof firstRow[col] === 'number');
      setChartXCol(textCols[0] || c[0]);
      setChartYCol(numCols[0]  || c[1] || c[0]);
    }
  }, [data]); // eslint-disable-line

  // ── Load page ─────────────────────────────────────────────
  useEffect(() => {
    if (!sourceType) return;

    if (abortRef.current) abortRef.current.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    // Stable cache key — encodes every query dimension
    const filterStr  = appliedFilter?.conditions?.length ? JSON.stringify(appliedFilter) : '';
    const cacheKey   = (p: number) => `${p}|${pageSize}|${sortColumn||''}|${sortDirection}|${filterStr}`;
    const buildUrl   = (p: number) => {
      const params = new URLSearchParams({ page: String(p), page_size: String(pageSize) });
      if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
      if (appliedFilter?.conditions?.length) params.append('adv_filters', filterStr);
      return buildDataUrl(params);
    };

    // Background prefetch helper — fires and forgets; never touches React state.
    // Guards against duplicate fetches with both a cache check AND an in-flight set.
    const prefetchPage = (p: number, totalPages: number) => {
      if (p < 1 || p > totalPages) return;
      const k = cacheKey(p);
      if (prefetchCacheRef.current.has(k)) return;       // already cached
      if (prefetchInflightRef.current.has(k)) return;    // already fetching
      const url = buildUrl(p);
      if (!url) return;
      prefetchInflightRef.current.add(k);
      fetch(url, { signal: ac.signal })
        .then(r => r.ok ? r.json() : null)
        .then(d => {
          prefetchInflightRef.current.delete(k);
          if (d && !ac.signal.aborted) prefetchCacheRef.current.set(k, d);
        })
        .catch(() => { prefetchInflightRef.current.delete(k); });
    };

    // Serve from prefetch cache — instant page switch, no spinner
    const cached = prefetchCacheRef.current.get(cacheKey(page));
    if (cached) {
      setData(cached);
      setTotalRows(cached.total_rows);
      hasDataRef.current = true;
      setError(null);
      setLoading(false);
      setRefreshing(false);
      if (tableContainerRef.current) tableContainerRef.current.scrollTop = 0;
      // Eagerly prefetch surrounding pages from the cached result
      prefetchPage(page + 1, cached.total_pages);
      prefetchPage(page + 2, cached.total_pages);
      prefetchPage(page - 1, cached.total_pages);
      prefetchPage(page - 2, cached.total_pages);
      return () => { ac.abort(); };
    }

    if (hasDataRef.current) setRefreshing(true);
    else setLoading(true);

    const run = async () => {
      let aborted = false;
      try {
        const url = buildUrl(page);
        if (!url) throw new Error('No data source configured');

        const res = await fetch(url, { signal: ac.signal });
        if (!res.ok) {
          const detail = await res.json().catch(() => ({}));
          throw new Error(detail?.detail || `HTTP ${res.status}`);
        }
        const result = await res.json();

        // Cache this page and evict if cache grows too large
        prefetchCacheRef.current.set(cacheKey(page), result);
        if (prefetchCacheRef.current.size > 25) {
          prefetchCacheRef.current.delete(prefetchCacheRef.current.keys().next().value);
        }

        setData(result);
        setTotalRows(result.total_rows);
        hasDataRef.current = true;
        setError(null);
        if (tableContainerRef.current) tableContainerRef.current.scrollTop = 0;

        // Capture wide-table column projection metadata (first page only)
        if (result.column_projection_applied && result.all_columns) {
          setAllSourceColumns(result.all_columns);
          setColumnProjection(true);
        }
        // Capture auto-partition metadata
        if (result.auto_partition) {
          setAutoPartition(result.auto_partition);
        }

        // Eagerly prefetch next and previous pages in background
        prefetchPage(page + 1, result.total_pages);
        prefetchPage(page + 2, result.total_pages);
        prefetchPage(page - 1, result.total_pages);
        prefetchPage(page - 2, result.total_pages);
      } catch (_e) {
        const err = _e as Error;
        if (err.name === 'AbortError') { aborted = true; return; }
        setError(err.message);
      } finally {
        if (!aborted) { setLoading(false); setRefreshing(false); }
      }
    };

    run();
    return () => { ac.abort(); };
  }, [executionId, fileId, filePath, connectionId, page, pageSize, sortColumn, sortDirection, appliedFilter]); // eslint-disable-line

  // ── Derive cols/rows early — useCallback below depends on `cols` ─────────
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const cols = useMemo(() => data?.columns || [], [data]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const rows = useMemo(() => data?.rows    || [], [data]);

  // ── Filter helpers ────────────────────────────────────────
  const handleApplyFilters = useCallback(() => {
    setAppliedFilter({ ...advFilter });
    setPage(1);
  }, [advFilter]);

  const handleClearFilters = useCallback(() => {
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setPage(1);
  }, []);

  // ── View helpers ──────────────────────────────────────────
  const handleViewModeChange = useCallback((_, val) => {
    if (!val) return;
    setViewMode(val);
    if (val === 'chart' || val === 'pivot') setChartData(null);
  }, []);

  const handleSort = useCallback((col) => {
    if (sortColumn === col) setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortColumn(col); setSortDirection('asc'); }
    setPage(1);
  }, [sortColumn]);

  // ── Column visibility helpers ─────────────────────────────
  const toggleColVisibility = useCallback((col, checked) => {
    setVisibleCols(prev => {
      const next = prev === null ? new Set(cols) : new Set(prev);
      if (checked) next.add(col);
      else next.delete(col);
      return next.size === cols.length ? null : next;
    });
  }, [cols]);

  const togglePinCol = useCallback((col) => {
    setPinnedCols(prev =>
      prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]
    );
  }, []);

  // ── Column stats loader ───────────────────────────────────
  const openColStats = useCallback(async (col: string) => {
    if (!executionId) return;
    setStatsCol(col);
    setStatsData(null);
    setStatsLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/executions/${executionId}/stats`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const colStat = data.columns?.find((c: any) => c.name === col) || null;
      setStatsData(colStat ? { ...colStat, total_rows: data.total_rows } : null);
    } catch {
      setStatsData(null);
    } finally {
      setStatsLoading(false);
    }
  }, [executionId]);

  // ── Chart loader ──────────────────────────────────────────
  const loadChartData = async () => {
    if (!chartXCol || !chartYCol) return;
    setChartLoading(true); setChartError(null);
    try {
      const params = new URLSearchParams({ x_col: chartXCol, y_col: chartYCol, agg: chartAgg, top_n: String(chartTopN) });
      const url = buildChartUrl(params);
      if (!url) throw new Error('Chart data not available for this source');
      const res = await fetch(url);
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || `HTTP ${res.status}`); }
      setChartData(await res.json());
    } catch (_e) {
      const err = _e as Error;
      setChartError((err as Error).message);
    } finally {
      setChartLoading(false);
    }
  };

  // ── Chart PNG export ──────────────────────────────────────
  const exportChartPng = useCallback(() => {
    const container = chartContainerRef.current;
    if (!container) return;
    const svg = container.querySelector('svg');
    if (!svg) return;
    const { width, height } = svg.getBoundingClientRect();
    const serialized = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([serialized], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * 2; canvas.height = height * 2;
      const ctx = canvas.getContext('2d')!;
      ctx.scale(2, 2);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `chart_${chartXCol}_vs_${chartYCol}.png`;
      a.click();
    };
    img.src = url;
  }, [chartXCol, chartYCol]);

  // ── Export helpers ────────────────────────────────────────
  const exportBackground = async (format) => {
    setExportAnchorEl(null);
    setExportMsg(`Starting ${format.toUpperCase()} export…`);
    try {
      const res = await fetch(`${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const result = await res.json();
      setExportMsg(result.message);
      setTimeout(() => setExportMsg(null), 6000);
    } catch (_e) {
      const err = _e as Error;
      setExportMsg(`Export failed: ${err.message}`);
      setTimeout(() => setExportMsg(null), 5000);
    }
  };
  const downloadFile = () => window.open(`${API_BASE_URL}/api/downloads/${fileId}/download`, '_blank');

  // ── Derived values ────────────────────────────────────────
  const totalPages = Math.max(1, Math.ceil((data?.filtered_rows ?? totalRows) / pageSize));
  const startRow   = (page - 1) * pageSize + 1;
  const endRow     = Math.min(page * pageSize, data?.filtered_rows ?? totalRows);
  const activeFilters = appliedFilter?.conditions?.length || 0;

  // Memoize every derived column array so they are stable between renders
  // that don't change col/visibility/pin state (e.g. scroll, pagination).
  const displayCols = useMemo(
    () => visibleCols === null ? cols : cols.filter(c => visibleCols.has(c)),
    [cols, visibleCols],
  );
  const pinnedVisible = useMemo(
    () => pinnedCols.filter(c => displayCols.includes(c)),
    [pinnedCols, displayCols],
  );
  const pinnedSet = useMemo(() => new Set(pinnedVisible), [pinnedVisible]);
  const nonPinnedVis = useMemo(
    () => displayCols.filter(c => !pinnedSet.has(c)),
    [displayCols, pinnedSet],
  );
  const tableCols = useMemo(
    () => [...pinnedVisible, ...nonPinnedVis],
    [pinnedVisible, nonPinnedVis],
  );
  // Map from col name → pin index for O(1) lookup during render
  const pinnedIdxMap = useMemo(
    () => new Map(pinnedVisible.map((c, i) => [c, i])),
    [pinnedVisible],
  );

  // Column picker search
  const colSearchLower = colSearch.toLowerCase();
  const filteredColList = useMemo(
    () => colSearchLower ? cols.filter(c => c.toLowerCase().includes(colSearchLower)) : cols,
    [cols, colSearchLower],
  );

  const headerTitle = title || (
    sourceType === 'execution' ? 'Query Results' :
    sourceType === 'fileId'   ? (data?.filename || 'File Preview') :
    sourceType === 'filePath' ? (data?.filename || filePath?.split('/').pop() || 'File Preview') :
    'Preview'
  );

  // ── Row virtualizer (renders only visible rows for large pages) ─
  // Hook must be called before any early returns (React rules of hooks).
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 33,  // MUI Table size="small" row ~33px
    overscan: 10,
  });
  const virtualRows       = rowVirtualizer.getVirtualItems();
  const totalVirtualHeight = rowVirtualizer.getTotalSize();
  const vPaddingTop    = virtualRows.length > 0 ? (virtualRows[0]?.start ?? 0) : 0;
  const vPaddingBottom = virtualRows.length > 0
    ? totalVirtualHeight - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0;

  // ── Initial load spinner ──────────────────────────────────
  if (loading && !data) {
    const Wrap: React.ElementType = embedded ? Box : Paper;
    return (
      <Wrap sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 200, ...(embedded ? {} : { p: 4 }) }}>
        <CircularProgress size={48} sx={{ mb: 2 }} />
        <Typography color="text.secondary">Loading…</Typography>
      </Wrap>
    );
  }

  if (error && !data) {
    const Wrap: React.ElementType = embedded ? Box : Paper;
    return (
      <Wrap sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 200, ...(embedded ? {} : { p: 4 }) }}>
        <Alert severity="error" sx={{ mb: 2, width: '100%', maxWidth: 520 }}>
          <Typography variant="subtitle2" fontWeight="bold">Preview Error</Typography>
          <Typography variant="body2">{error}</Typography>
        </Alert>
        {!embedded && <Button variant="outlined" onClick={onClose}>Close</Button>}
      </Wrap>
    );
  }

  const Wrapper: React.ElementType = embedded ? Box : Paper;

  return (
    <Wrapper sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* ── Header (non-embedded only) ───────────────────── */}
      {!embedded && (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider' }}>
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1.5 }}>
            <Typography variant="h6">{headerTitle}</Typography>
            <Typography variant="body2" color="text.secondary">
              {refreshing ? 'Refreshing…' : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${totalRows.toLocaleString()} rows`}
            </Typography>
          </Box>
          {onClose && (
            <Tooltip title="Close"><IconButton onClick={onClose} size="small"><CloseIcon /></IconButton></Tooltip>
          )}
        </Box>
      )}

      {exportMsg && (
        <Alert severity={exportMsg.includes('failed') ? 'error' : exportMsg.includes('Starting') ? 'info' : 'success'}
          sx={{ borderRadius: 0 }} onClose={() => setExportMsg(null)}>
          {exportMsg}
        </Alert>
      )}

      {/* ── Toolbar ──────────────────────────────────────── */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderBottom: 1, borderColor: 'divider', flexWrap: 'wrap', gap: 1, flexShrink: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {embedded && (
            <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
              {refreshing ? (
                <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.75 }}>
                  <CircularProgress size={12} /> Updating…
                </Box>
              ) : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${(data?.filtered_rows ?? totalRows).toLocaleString()} rows`}
              {activeFilters > 0 && (
                <Chip label={`${activeFilters} filter${activeFilters > 1 ? 's' : ''}`} size="small" color="primary"
                  variant="outlined" sx={{ ml: 1, height: 18, fontSize: 11 }} onDelete={handleClearFilters} />
              )}
            </Typography>
          )}

          <ToggleButtonGroup value={viewMode} exclusive onChange={handleViewModeChange} size="small">
            <ToggleButton value="table"><Tooltip title="Table"><TableIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Table</ToggleButton>
            <ToggleButton value="chart"><Tooltip title="Chart"><ChartIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Chart</ToggleButton>
            <ToggleButton value="pivot"><Tooltip title="Pivot"><PivotIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Pivot</ToggleButton>
          </ToggleButtonGroup>

          {viewMode === 'table' && (
            <Button
              variant={showFilters ? 'contained' : 'outlined'}
              size="small" startIcon={<FilterIcon />}
              onClick={() => setShowFilters(v => !v)}
              color={activeFilters > 0 ? 'primary' : 'inherit'}
            >
              Filters{activeFilters > 0 ? ` (${activeFilters})` : ''}
            </Button>
          )}

          {viewMode === 'table' && cols.length > 0 && (
            <Button
              variant="outlined"
              size="small"
              startIcon={<ColumnsIcon />}
              onClick={() => setShowColPanel(true)}
              color={pinnedCols.length > 0 || visibleCols !== null || columnProjection ? 'primary' : 'inherit'}
            >
              Columns ({displayCols.length}{displayCols.length !== cols.length ? `/${cols.length}` : ''}
              {columnProjection && allSourceColumns ? ` of ${allSourceColumns.length}` : ''})
              {pinnedCols.length > 0 && ` · ${pinnedCols.length} pinned`}
            </Button>
          )}
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TextField select size="small" value={pageSize} onChange={e => { setPageSize(+e.target.value); setPage(1); }} sx={{ minWidth: 110 }}>
            {[50, 100, 250, 500, 1000].map(n => <MenuItem key={n} value={n}>{n} rows</MenuItem>)}
          </TextField>

          {sourceType === 'execution' && (
            <>
              <Button variant="outlined" size="small" startIcon={<DownloadIcon />}
                onClick={e => setExportAnchorEl(e.currentTarget)}>Export</Button>
              <Menu anchorEl={exportAnchorEl} open={Boolean(exportAnchorEl)} onClose={() => setExportAnchorEl(null)}>
                <MenuItem onClick={() => exportBackground('csv')}><CsvIcon sx={{ mr: 1, fontSize: 20 }} />CSV</MenuItem>
                <MenuItem onClick={() => exportBackground('excel')}><ExcelIcon sx={{ mr: 1, fontSize: 20 }} />Excel</MenuItem>
                <MenuItem onClick={() => exportBackground('json')}><JsonIcon sx={{ mr: 1, fontSize: 20 }} />JSON</MenuItem>
              </Menu>
            </>
          )}
          {sourceType === 'fileId' && (
            <Button variant="outlined" size="small" startIcon={<DownloadIcon />} onClick={downloadFile}>Download</Button>
          )}
        </Box>
      </Box>

      {/* ── TABLE VIEW ───────────────────────────────────── */}
      {viewMode === 'table' && (
        <>
          {showFilters && (
            <>
              <FilterBuilder columns={displayCols} value={advFilter} onChange={setAdvFilter} />
              <Box sx={{ display: 'flex', gap: 1, px: 2, py: 1, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50', flexShrink: 0 }}>
                <Button
                  size="small" variant="contained" onClick={handleApplyFilters}
                  disabled={advFilter.conditions.length === 0}
                  sx={{ fontSize: 12, textTransform: 'none' }}
                >
                  Apply Filters
                </Button>
                {activeFilters > 0 && (
                  <Button size="small" variant="outlined" onClick={handleClearFilters}
                    sx={{ fontSize: 12, textTransform: 'none' }}>
                    Clear Applied
                  </Button>
                )}
              </Box>
            </>
          )}

          {/* Wide-table column projection banner */}
          {columnProjection && allSourceColumns && (
            <Box sx={{
              display: 'flex', alignItems: 'center', gap: 1,
              px: 1.5, py: 0.5, bgcolor: '#eff6ff', borderBottom: '1px solid #bfdbfe',
            }}>
              <ColumnsIcon sx={{ fontSize: 14, color: '#2563eb' }} />
              <Typography sx={{ fontSize: 12, color: '#1e40af', fontWeight: 500 }}>
                Showing {cols.length} of {allSourceColumns.length} columns (auto-optimized for performance).
                Select specific columns in the query builder and re-execute to see different columns.
              </Typography>
            </Box>
          )}

          {/* Auto-partition filter banner */}
          {autoPartition && (
            <Box sx={{
              display: 'flex', alignItems: 'center', gap: 1,
              px: 1.5, py: 0.5, bgcolor: '#f0fdf4', borderBottom: '1px solid #bbf7d0',
            }}>
              <InfoIcon sx={{ fontSize: 14, color: '#16a34a' }} />
              <Typography sx={{ fontSize: 12, color: '#166534', fontWeight: 500 }}>
                Showing latest partition ({Object.entries(autoPartition).map(([k, v]) => `${k} = ${v}`).join(', ')}).
                Add a partition filter in the query builder to select a different date range.
              </Typography>
            </Box>
          )}

          {refreshing && <LinearProgress sx={{ height: 2 }} />}

          <TableContainer ref={tableContainerRef} sx={{ flex: 1, overflow: 'auto', position: 'relative' }}>
            {refreshing && (
              <Box sx={{
                position: 'absolute', inset: 0, zIndex: 10,
                bgcolor: 'rgba(255,255,255,0.55)', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-end', p: 1,
                pointerEvents: 'none',
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, bgcolor: 'background.paper',
                  border: 1, borderColor: 'divider', borderRadius: 1, px: 1.5, py: 0.5, boxShadow: 1 }}>
                  <CircularProgress size={14} />
                  <Typography variant="caption" color="text.secondary">Loading page {page}…</Typography>
                </Box>
              </Box>
            )}

            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {/* Row number header */}
                  <TableCell sx={{
                    fontWeight: 'bold', bgcolor: 'grey.100', width: 56, textAlign: 'center',
                    ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 5, boxShadow: 'inset -1px 0 0 #e2e8f0' } : {}),
                  }}>
                    #
                  </TableCell>

                  {tableCols.map((col) => {
                    const pi = pinnedIdxMap.get(col);
                    const isPinned = pi !== undefined;
                    const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
                    return (
                      <TableCell key={col}
                        sortDirection={sortColumn === col ? sortDirection as 'asc' | 'desc' : false}
                        sx={{
                          fontWeight: 'bold', bgcolor: 'grey.100', whiteSpace: 'nowrap',
                          // Show the pin button on hover of this header cell
                          '&:hover .col-pin-btn': { opacity: 1 },
                          ...(isPinned ? {
                            position: 'sticky',
                            left: 56 + pi * FROZEN_COL_WIDTH,
                            zIndex: 4,
                            minWidth: FROZEN_COL_WIDTH,
                            ...(isLastPinned
                              ? { boxShadow: '3px 0 6px rgba(0,0,0,0.12)' }
                              : { boxShadow: 'inset -1px 0 0 #e2e8f0' }),
                          } : {}),
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
                          <TableSortLabel
                            active={sortColumn === col}
                            direction={sortColumn === col ? sortDirection as 'asc' | 'desc' : 'asc'}
                            onClick={() => handleSort(col)}
                          >
                            {col}
                          </TableSortLabel>
                          {/* Pin / freeze icon — always visible when pinned, hover-only otherwise */}
                          <Tooltip title={isPinned ? 'Unfreeze column' : 'Freeze column (pin left)'} placement="top">
                            <IconButton
                              className="col-pin-btn"
                              size="small"
                              onClick={(e) => { e.stopPropagation(); togglePinCol(col); }}
                              sx={{
                                p: 0.25,
                                opacity: isPinned ? 1 : 0,
                                transition: 'opacity 0.15s',
                                color: isPinned ? 'primary.main' : 'text.secondary',
                                '&:hover': { bgcolor: 'action.hover' },
                              }}
                            >
                              <PinIcon sx={{ fontSize: 12, transform: isPinned ? 'none' : 'rotate(45deg)' }} />
                            </IconButton>
                          </Tooltip>
                          {/* Column stats icon — shown on header hover, only for execution sources */}
                          {executionId && (
                            <Tooltip title="Column statistics" placement="top">
                              <IconButton
                                className="col-pin-btn"
                                size="small"
                                onClick={(e) => { e.stopPropagation(); openColStats(col); }}
                                sx={{ p: 0.25, opacity: 0, transition: 'opacity 0.15s', color: 'info.main', '&:hover': { bgcolor: 'action.hover' } }}
                              >
                                <InfoIcon sx={{ fontSize: 12 }} />
                              </IconButton>
                            </Tooltip>
                          )}
                        </Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              </TableHead>

              <TableBody>
                {/* Top spacer — keeps scroll thumb positioned correctly */}
                {vPaddingTop > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingTop, p: 0, border: 0 }} /></TableRow>
                )}

                {virtualRows.map((virtualRow) => {
                  const idx  = virtualRow.index;
                  const row  = rows[idx];
                  const rowBg = idx % 2 === 0 ? 'grey.50' : 'background.paper';
                  return (
                    <VirtualRow
                      key={virtualRow.key}
                      virtualRow={virtualRow as VirtualRowProps['virtualRow']}
                      row={row}
                      rowBg={rowBg}
                      startRow={startRow}
                      tableCols={tableCols}
                      pinnedIdxMap={pinnedIdxMap}
                      pinnedVisible={pinnedVisible}
                      refreshing={refreshing}
                      measureRef={rowVirtualizer.measureElement}
                    />
                  );
                })}

                {/* Bottom spacer */}
                {vPaddingBottom > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingBottom, p: 0, border: 0 }} /></TableRow>
                )}

                {/* Empty state — only show when NOT loading or refreshing */}
                {rows.length === 0 && !loading && !refreshing && (
                  <TableRow>
                    <TableCell colSpan={tableCols.length + 1} sx={{ textAlign: 'center', py: 6, color: 'text.disabled' }}>
                      No rows match the current filters
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination */}
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderTop: 1, borderColor: 'divider', flexShrink: 0 }}>
            <Typography variant="body2" color="text.secondary">
              {(data?.filtered_rows ?? totalRows).toLocaleString()} row{(data?.filtered_rows ?? totalRows) !== 1 ? 's' : ''}
              {activeFilters > 0 && totalRows !== (data?.filtered_rows ?? totalRows)
                ? ` (filtered from ${totalRows.toLocaleString()})`
                : ''}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Tooltip title="First page">
                <span><IconButton size="small" onClick={() => setPage(1)} disabled={page === 1 || refreshing}><FirstPage /></IconButton></span>
              </Tooltip>
              <Tooltip title="Previous page">
                <span><IconButton size="small" onClick={() => setPage(p => p - 1)} disabled={page === 1 || refreshing}><NavigateBefore /></IconButton></span>
              </Tooltip>
              <Typography variant="body2" sx={{ mx: 1, minWidth: 80, textAlign: 'center', display: 'flex', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                {refreshing && <CircularProgress size={12} />}
                Page {page} / {totalPages}
              </Typography>
              <Tooltip title="Next page">
                <span><IconButton size="small" onClick={() => setPage(p => p + 1)} disabled={page >= totalPages || refreshing}><NavigateNext /></IconButton></span>
              </Tooltip>
              <Tooltip title="Last page">
                <span><IconButton size="small" onClick={() => setPage(totalPages)} disabled={page >= totalPages || refreshing}><LastPage /></IconButton></span>
              </Tooltip>
            </Box>
          </Box>
        </>
      )}

      {/* ── CHART VIEW ───────────────────────────────────── */}
      {viewMode === 'chart' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <ChartConfig cols={displayCols} chartType={chartType} setChartType={setChartType}
            xCol={chartXCol} setXCol={setChartXCol} yCol={chartYCol} setYCol={setChartYCol}
            agg={chartAgg} setAgg={setChartAgg} topN={chartTopN} setTopN={setChartTopN}
            onRefresh={loadChartData} renderLabel="Render Chart" />
          <Box sx={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', p: 2 }}>
            {chartLoading && <Box sx={{ textAlign: 'center' }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Aggregating {totalRows.toLocaleString()} rows…</Typography></Box>}
            {chartError && <Alert severity="error" sx={{ width: '100%' }}>{chartError}</Alert>}
            {!chartLoading && !chartError && chartData && (
              <>
                <Box sx={{ alignSelf: 'flex-end', mb: 1 }}>
                  <Tooltip title="Export chart as PNG">
                    <Button size="small" variant="outlined" startIcon={<DownloadIcon />} onClick={exportChartPng}>
                      PNG
                    </Button>
                  </Tooltip>
                </Box>
                <Box ref={chartContainerRef} sx={{ width: '100%' }}>
                  <ChartRenderer data={chartData} type={chartType} />
                </Box>
              </>
            )}
            {!chartLoading && !chartError && !chartData && (
              <Box sx={{ textAlign: 'center' }}>
                <ChartIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                <Typography variant="body1" color="text.secondary">Configure settings on the left, then click <strong>Render Chart</strong></Typography>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── PIVOT VIEW ───────────────────────────────────── */}
      {viewMode === 'pivot' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <ChartConfig cols={displayCols} hideChartType
            xCol={chartXCol} setXCol={setChartXCol} yCol={chartYCol} setYCol={setChartYCol}
            agg={chartAgg} setAgg={setChartAgg} topN={chartTopN} setTopN={setChartTopN}
            onRefresh={loadChartData} xLabel="Group By (Row)" yLabel="Value Column" renderLabel="Render Pivot" />
          <Box sx={{ flex: 1, overflow: 'auto', p: 2 }}>
            {chartLoading && <Box sx={{ textAlign: 'center', mt: 4 }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Aggregating…</Typography></Box>}
            {chartError && <Alert severity="error">{chartError}</Alert>}
            {!chartLoading && !chartError && chartData && (
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  {chartData.agg.toUpperCase()} of <strong>{chartData.y_col}</strong> by <strong>{chartData.x_col}</strong> — {chartData.groups} groups
                </Typography>
                <Table size="small" sx={{ width: 'auto' }}>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100' }}>{chartData.x_col}</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>{chartData.agg.toUpperCase()}({chartData.y_col})</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>Count</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: 'grey.100', textAlign: 'right' }}>%</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {chartData.data.map((row, i) => (
                      <TableRow key={i} hover>
                        <TableCell>{row.label}</TableCell>
                        <TableCell sx={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                          {row.value != null ? (row.value < 0 ? <span style={{ color: '#d32f2f' }}>({fmtNum(-row.value)})</span> : fmtNum(row.value)) : '—'}
                        </TableCell>
                        <TableCell sx={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{row.count.toLocaleString()}</TableCell>
                        <TableCell sx={{ textAlign: 'right' }}>{row.pct}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Box>
            )}
            {!chartLoading && !chartError && !chartData && (
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                <Box sx={{ textAlign: 'center' }}>
                  <PivotIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                  <Typography variant="body1" color="text.secondary">Configure settings on the left, then click <strong>Render Pivot</strong></Typography>
                </Box>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── Column Picker Dialog ──────────────────────────── */}
      <Dialog
        open={showColPanel}
        onClose={() => { setShowColPanel(false); setColSearch(''); }}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { maxHeight: '80vh' } }}
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6">Columns</Typography>
            <Typography variant="caption" color="text.secondary">
              {displayCols.length} visible · {pinnedCols.length} pinned · {cols.length} loaded
              {columnProjection && allSourceColumns ? ` · ${allSourceColumns.length} in source` : ''}
            </Typography>
          </Box>
          {columnProjection && allSourceColumns && (
            <Typography variant="caption" sx={{ color: '#2563eb', display: 'block', mt: 0.5 }}>
              Only {cols.length} of {allSourceColumns.length} columns were fetched.
              Use the query builder column selector to choose specific columns, then re-execute.
            </Typography>
          )}
        </DialogTitle>

        <DialogContent sx={{ pt: 0 }}>
          <TextField
            size="small" fullWidth placeholder="Search columns…" value={colSearch}
            onChange={e => setColSearch(e.target.value)} autoFocus
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment> }}
            sx={{ mb: 1.5 }}
          />

          <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
            <Button size="small" variant="outlined"
              onClick={() => setVisibleCols(null)}
              sx={{ fontSize: 12, textTransform: 'none' }}>
              Show all
            </Button>
            {cols.length > MAX_VIS_COLS && (
              <Button size="small" variant="outlined"
                onClick={() => setVisibleCols(new Set(cols.slice(0, MAX_VIS_COLS)))}
                sx={{ fontSize: 12, textTransform: 'none' }}>
                First {MAX_VIS_COLS}
              </Button>
            )}
            <Button size="small" variant="outlined" color="error"
              onClick={() => setPinnedCols([])}
              disabled={pinnedCols.length === 0}
              sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}>
              Unpin all
            </Button>
          </Box>

          <Box sx={{ overflow: 'auto', maxHeight: 380 }}>
            {filteredColList.map(col => {
              const isVisible = visibleCols === null || visibleCols.has(col);
              const isPinned  = pinnedCols.includes(col);
              return (
                <Box key={col} sx={{
                  display: 'flex', alignItems: 'center', gap: 0.5,
                  py: 0.25, px: 0.5, borderRadius: 1,
                  '&:hover': { bgcolor: 'action.hover' },
                }}>
                  <Checkbox
                    checked={isVisible} size="small"
                    onChange={e => toggleColVisibility(col, e.target.checked)}
                    sx={{ p: 0.5 }}
                  />
                  <Typography variant="body2" title={col}
                    sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {col}
                  </Typography>
                  {isPinned && (
                    <Chip label="pinned" size="small" color="primary" variant="filled"
                      sx={{ height: 16, fontSize: 10, mr: 0.5, '& .MuiChip-label': { px: 0.75 } }} />
                  )}
                  <Tooltip title={isPinned ? 'Unpin' : 'Pin to left'}>
                    <IconButton size="small" onClick={() => togglePinCol(col)}
                      sx={{ color: isPinned ? 'primary.main' : 'text.disabled', p: 0.5 }}>
                      <PinIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </Tooltip>
                </Box>
              );
            })}
            {filteredColList.length === 0 && (
              <Typography variant="body2" color="text.disabled" sx={{ textAlign: 'center', py: 3 }}>
                No columns match "{colSearch}"
              </Typography>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => { setShowColPanel(false); setColSearch(''); }} variant="contained" size="small">
            Done
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Column Stats Dialog ───────────────────────────── */}
      <Dialog
        open={statsCol !== null}
        onClose={() => { setStatsCol(null); setStatsData(null); }}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" sx={{ fontFamily: 'monospace', fontSize: 15 }}>{statsCol}</Typography>
            <IconButton size="small" onClick={() => { setStatsCol(null); setStatsData(null); }}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <Typography variant="caption" color="text.secondary">Column Statistics</Typography>
        </DialogTitle>
        <DialogContent>
          {statsLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}><CircularProgress size={28} /></Box>}
          {!statsLoading && !statsData && <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>No stats available</Typography>}
          {!statsLoading && statsData && (() => {
            const s = statsData;
            const nullPct = s.total_rows > 0 ? ((s.null_count / s.total_rows) * 100).toFixed(1) : '0.0';
            const fillPct = s.total_rows > 0 ? (((s.total_rows - s.null_count) / s.total_rows) * 100) : 0;
            return (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
                  {[
                    ['Type', s.type],
                    ['Total Rows', fmtNum(s.total_rows)],
                    ['Null Count', `${fmtNum(s.null_count)} (${nullPct}%)`],
                    ['Unique Values', fmtNum(s.unique_count)],
                    ...(s.min !== undefined ? [
                      ['Min', fmtNum(s.min)],
                      ['Max', fmtNum(s.max)],
                      ['Mean', fmtNum(s.mean)],
                    ] : []),
                  ].map(([label, val]) => (
                    <Paper key={label as string} variant="outlined" sx={{ p: 1, borderRadius: 1 }}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>{label}</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>{val}</Typography>
                    </Paper>
                  ))}
                </Box>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" color="text.secondary">Fill rate</Typography>
                    <Typography variant="caption" color="text.secondary">{fillPct.toFixed(1)}%</Typography>
                  </Box>
                  <Box sx={{ height: 8, bgcolor: 'grey.200', borderRadius: 1, overflow: 'hidden' }}>
                    <Box sx={{ height: '100%', width: `${fillPct}%`, bgcolor: fillPct > 90 ? 'success.main' : fillPct > 50 ? 'warning.main' : 'error.main', borderRadius: 1 }} />
                  </Box>
                </Box>
              </Box>
            );
          })()}
        </DialogContent>
      </Dialog>

    </Wrapper>
  );
};

export default DataGridViewer;
