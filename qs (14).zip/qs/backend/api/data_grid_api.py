"""
Data Grid API — DuckDB-Powered
Key changes:
  1. DuckDB replaces pandas for all data reads — handles 5-10 GB files without loading into RAM
  2. Advanced AND/OR filter via adv_filters parameter (JSON: {conjunction, conditions})
  3. Legacy per-column filters still supported for backwards compat
  4. All chart-data endpoints use DuckDB aggregation
  5. /export and /stats retain pandas (they process full dataset intentionally)
"""

from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from fastapi.responses import FileResponse, StreamingResponse
try:
    from fastapi.responses import ORJSONResponse as _JSONResp
    _USE_ORJSON = True
except ImportError:
    from fastapi.responses import JSONResponse as _JSONResp
    _USE_ORJSON = False
import pandas as pd
from pathlib import Path
import json
from typing import Optional
import io
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor as _TPE
from datetime import datetime, timedelta, timezone

try:
    import duckdb as _duckdb
    _DUCKDB_AVAILABLE = True
except ImportError:
    _DUCKDB_AVAILABLE = False

router = APIRouter()

# Dedicated thread pool for blocking DuckDB / pandas calls so they never
# stall the asyncio event loop.  DuckDB in-memory connections are per-call
# (_duckdb_con() creates a new one each time), so this is thread-safe.
_duckdb_executor = _TPE(max_workers=8, thread_name_prefix="duckdb")

# ── Schema + row-count cache ─────────────────────────────────────────────────
# Keyed by resolved file path string.
# Avoids running `SELECT COUNT(*)` and schema-detection queries on every page.
# Entries are invalidated when the file's mtime changes or after 2 hours.
import time as _time
import threading as _threading

_meta_cache: dict = {}          # path_str → {columns, total_rows, mtime, ts}
_meta_cache_lock = _threading.Lock()
_META_TTL = 7200                # seconds


def _get_cached_meta(path: Path) -> dict | None:
    key = str(path)
    with _meta_cache_lock:
        entry = _meta_cache.get(key)
        if not entry:
            return None
        try:
            if path.stat().st_mtime != entry["mtime"]:
                del _meta_cache[key]
                return None
        except OSError:
            del _meta_cache[key]
            return None
        if _time.monotonic() - entry["ts"] > _META_TTL:
            del _meta_cache[key]
            return None
        return entry


def _set_cached_meta(path: Path, columns: list, total_rows: int) -> None:
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return
    with _meta_cache_lock:
        _meta_cache[str(path)] = {
            "columns":    columns,
            "total_rows": total_rows,
            "mtime":      mtime,
            "ts":         _time.monotonic(),
        }


def _evict_cached_meta(path: Path) -> None:
    """Call when a file is deleted so the cache doesn't serve stale entries."""
    with _meta_cache_lock:
        _meta_cache.pop(str(path), None)
        # Also evict any filter-count entries for this file
        prefix = str(path) + "|"
        stale = [k for k in _meta_cache if k.startswith(prefix)]
        for k in stale:
            del _meta_cache[k]


def _get_filtered_count_cache(path: Path, filter_key: str) -> int | None:
    key = str(path) + "|" + filter_key
    with _meta_cache_lock:
        entry = _meta_cache.get(key)
        if not entry:
            return None
        if _time.monotonic() - entry["ts"] > _META_TTL:
            del _meta_cache[key]
            return None
        return entry["count"]


def _set_filtered_count_cache(path: Path, filter_key: str, count: int) -> None:
    key = str(path) + "|" + filter_key
    with _meta_cache_lock:
        _meta_cache[key] = {"count": count, "ts": _time.monotonic()}


def _serialize_df(df: pd.DataFrame) -> pd.DataFrame:
    """Convert non-JSON-serializable pandas/numpy types to plain Python types.

    Handles: Timestamp → ISO string, NaT → None, numpy scalars → int/float.
    Called before to_dict('records') so orjson / JSONResponse never sees
    pandas internals.
    """
    import numpy as np
    df = df.copy()
    for col in df.columns:
        dtype = df[col].dtype
        if pd.api.types.is_datetime64_any_dtype(dtype):
            # Convert to ISO-8601 strings; NaT becomes None
            df[col] = df[col].apply(
                lambda v: v.isoformat() if not pd.isnull(v) else None
            )
        elif hasattr(dtype, "tz") and dtype.tz is not None:
            # Timezone-aware datetime
            df[col] = df[col].apply(
                lambda v: v.isoformat() if not pd.isnull(v) else None
            )
        elif pd.api.types.is_integer_dtype(dtype):
            df[col] = df[col].where(df[col].notna(), None).astype(object)
        elif pd.api.types.is_float_dtype(dtype):
            df[col] = df[col].where(df[col].notna(), None).astype(object)
    return df


async def _aduckdb(fn):
    """Run a blocking DuckDB or pandas function off the event loop."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_duckdb_executor, fn)


# Injected from main.py at startup
_db_manager    = None
_ws_manager    = None
_main_loop     = None
_downloads_dir: Optional[Path] = None   # config-driven, set via set_paths()
_parquet_dir:   Optional[Path] = None   # config-driven, set via set_paths()

# ── Eager own-instance init ─────────────────────────────────────────
# Uses core.config so the BYOS/network-drive paths are respected even
# before main.py calls set_db_manager() / set_paths().
import logging as _init_log
try:
    from core.config import paths as _cfg_paths, database as _cfg_db
    from core.database import DatabaseManager as _OwnDBManager
    _cfg_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _cfg_paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _db_manager = _OwnDBManager(db_url=_cfg_db.db_url)
    _init_log.getLogger(__name__).info(
        "data_grid_api: eager init OK — db=%s  downloads=%s",
        _cfg_db.db_url, _cfg_paths.downloads_dir)
except Exception as _init_exc:
    _init_log.getLogger(__name__).warning(
        "data_grid_api: eager init failed (%s) — will rely on main.py injection", _init_exc)
    _db_manager = None


def set_db_manager(db):
    global _db_manager
    _db_manager = db


def set_paths(downloads_dir: Path, parquet_dir: Path) -> None:
    """Called by main.py at startup to inject config-driven paths."""
    global _downloads_dir, _parquet_dir
    _downloads_dir = downloads_dir
    _parquet_dir   = parquet_dir


def _get_downloads_dir() -> Path:
    if _downloads_dir is not None:
        return _downloads_dir
    try:
        from core.config import paths as _p
        return _p.downloads_dir
    except Exception:
        return Path(__file__).resolve().parent.parent / "data" / "downloads"


def _get_parquet_dir() -> Path:
    if _parquet_dir is not None:
        return _parquet_dir
    try:
        from core.config import paths as _p
        return _p.parquet_dir
    except Exception:
        return Path(__file__).resolve().parent.parent / "data" / "parquet"


def set_ws_manager(ws_mgr, loop):
    global _ws_manager, _main_loop
    _ws_manager = ws_mgr
    _main_loop  = loop


def _get_db():
    """Return the DatabaseManager.

    Tier 1: module-level global (set eagerly at import time OR via set_db_manager).
    Tier 2: sys.modules lookup — final safety net for unusual import scenarios.
    """
    global _db_manager
    if _db_manager is not None:
        return _db_manager

    # Tier 2: look inside sys.modules for main.db_manager
    import sys
    for mod_name in ("main", "__main__"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            dm = getattr(mod, "db_manager", None)
            if dm is not None:
                _db_manager = dm
                return _db_manager

    import logging as _log
    _log.getLogger(__name__).error(
        "_get_db: all tiers failed — DatabaseManager unavailable")
    return None


def find_csv_file(execution_id: str) -> Optional[Path]:
    """
    Find the result file for an execution.
    Prefers .parquet (new format, faster) but falls back to .csv for legacy files.
    Searches the config-driven downloads_dir first, then legacy fallbacks.
    Falls back to the DB-recorded output_file path (handles cache-hit executions
    whose result lives in data/cache/ rather than data/downloads/).
    """
    dl = _get_downloads_dir()
    for ext in (".parquet", ".csv"):
        for base in [dl, Path("./data/downloads"), Path("data/downloads")]:
            try:
                candidate = base / f"{execution_id}{ext}"
                if candidate.exists():
                    return candidate
            except (OSError, ValueError):
                pass

    # Fallback: look up the execution record's stored output_file path
    # (needed for cache-hit executions stored outside downloads_dir)
    try:
        db = _get_db()
        rec = db.get_execution(execution_id)
        if rec:
            p = rec.get("output_file")
            if p:
                fp = Path(p)
                if fp.exists():
                    return fp
    except Exception:
        pass
    return None


# ═══════════════════════════════════════════════════════════════════
# DuckDB helpers
# ═══════════════════════════════════════════════════════════════════

def _duckdb_con():
    """New in-memory DuckDB connection (each request gets its own)."""
    return _duckdb.connect(database=":memory:")


# ── DuckDB S3 / Iceberg helpers ───────────────────────────────────────────────

_DUCKDB_HTTPFS_OK   = None   # None = not yet tested
_DUCKDB_ICEBERG_OK  = None


def _try_load_extension(con, ext: str) -> bool:
    """Attempt to INSTALL + LOAD a DuckDB extension.  Returns True on success."""
    try:
        con.execute(f"INSTALL '{ext}';")
        con.execute(f"LOAD '{ext}';")
        return True
    except Exception:
        try:
            con.execute(f"LOAD '{ext}';")  # may already be installed
            return True
        except Exception:
            return False


def _duckdb_con_with_s3(conn_config: dict) -> "duckdb.DuckDBPyConnection":  # type: ignore[name-defined]
    """Return a DuckDB connection pre-configured with S3 credentials.

    conn_config is the 'config' sub-dict of a saved Connection record
    (connection_type='s3').  Supported keys:
      aws_access_key_id, aws_secret_access_key, aws_session_token,
      region_name / region, endpoint_url / endpoint
    """
    global _DUCKDB_HTTPFS_OK
    con = _duckdb.connect(database=":memory:")
    if _DUCKDB_HTTPFS_OK is False:
        return con   # extension unavailable — caller handles graceful fallback

    ok = _try_load_extension(con, "httpfs")
    _DUCKDB_HTTPFS_OK = ok
    if not ok:
        _init_log.getLogger(__name__).warning(
            "DuckDB httpfs extension unavailable — S3 direct queries disabled"
        )
        return con

    region = conn_config.get("region_name") or conn_config.get("region") or "us-east-1"
    key    = conn_config.get("aws_access_key_id", "")
    secret = conn_config.get("aws_secret_access_key", "")
    token  = conn_config.get("aws_session_token", "")
    ep     = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")

    con.execute(f"SET s3_region='{region}';")
    if key:
        con.execute(f"SET s3_access_key_id='{key}';")
    if secret:
        con.execute(f"SET s3_secret_access_key='{secret}';")
    if token:
        con.execute(f"SET s3_session_token='{token}';")
    if ep:
        # Strip protocol for DuckDB (it expects host[:port] only)
        ep_clean = ep.replace("https://", "").replace("http://", "").rstrip("/")
        con.execute(f"SET s3_endpoint='{ep_clean}';")
        con.execute("SET s3_use_ssl=false;")

    return con


def _duckdb_iceberg_source(table_prefix: str) -> str:
    """Return a DuckDB iceberg_scan() table expression for an Iceberg table on S3.

    table_prefix is the S3 URI of the table root, e.g. 's3://bucket/warehouse/db/table/'.
    allow_moved_paths=true handles AWS Glue / EMR layouts where manifest paths
    reference a different S3 key prefix than the actual data location.
    """
    global _DUCKDB_ICEBERG_OK
    safe = table_prefix.replace("'", "''")
    return f"iceberg_scan('{safe}', allow_moved_paths=true)"


def _ensure_iceberg_extension(con) -> bool:
    global _DUCKDB_ICEBERG_OK
    if _DUCKDB_ICEBERG_OK is False:
        return False
    ok = _try_load_extension(con, "iceberg")
    _DUCKDB_ICEBERG_OK = ok
    if not ok:
        _init_log.getLogger(__name__).warning(
            "DuckDB iceberg extension unavailable — falling back to manifest reader"
        )
    return ok


def _duckdb_source(path: Path) -> str:
    """Return the DuckDB table-function expression for a file.
    Uses .as_posix() so Windows backslashes are not misinterpreted
    as SQL/octal escape sequences inside DuckDB string literals.
    """
    p = path.resolve().as_posix().replace("'", "''")
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return f"read_parquet('{p}')"
    if suffix == ".json":
        return f"read_json_auto('{p}')"
    # CSV / TXT (and anything else): auto-detect.
    # sample_size=1000 caps schema-inference to the first 1000 rows so DuckDB
    # doesn't scan the entire file just to figure out column types — critical
    # for 1000-column files where a full scan takes 30-60 s.
    return f"read_csv_auto('{p}', ignore_errors=true, all_varchar=false, sample_size=1000)"


def _duckdb_valid_cols(con, source: str) -> list:
    """Return ordered list of column names from the source."""
    try:
        df = con.execute(f"SELECT * FROM {source} LIMIT 0").fetchdf()
        return df.columns.tolist()
    except Exception:
        return []


def _build_where(adv_filters_json: Optional[str], valid_cols: list) -> tuple:
    """
    Parse adv_filters JSON into a (WHERE-clause-string, params-list) pair.

    adv_filters format:
      { "conjunction": "AND" | "OR",
        "conditions": [
          { "col": "region", "op": "equals",   "val": "US" },
          { "col": "revenue","op": "gt",        "val": "1000" },
          ...
        ]
      }
    Supported ops: contains, not_contains, equals, not_equals,
                   starts_with, ends_with, gt, gte, lt, lte,
                   is_null, is_not_null
    """
    if not adv_filters_json:
        return "", []
    try:
        af = json.loads(adv_filters_json)
    except Exception:
        return "", []

    conjunction = af.get("conjunction", "AND").upper()
    if conjunction not in ("AND", "OR"):
        conjunction = "AND"

    valid_set = set(valid_cols)
    parts, params = [], []

    for cond in af.get("conditions", []):
        col = cond.get("col", "")
        op  = cond.get("op", "contains")
        val = cond.get("val", "")
        if col not in valid_set:
            continue

        qcol     = f'"{col}"'
        cast_col = f'CAST({qcol} AS VARCHAR)'

        if op == "contains":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"%{val}%")
        elif op == "not_contains":
            parts.append(f"({cast_col} NOT ILIKE ? OR {qcol} IS NULL)");  params.append(f"%{val}%")
        elif op == "equals":
            parts.append(f"{cast_col} = ?");      params.append(str(val))
        elif op == "not_equals":
            parts.append(f"({cast_col} != ? OR {qcol} IS NULL)");  params.append(str(val))
        elif op == "starts_with":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"{val}%")
        elif op == "ends_with":
            parts.append(f"{cast_col} ILIKE ?");  params.append(f"%{val}")
        elif op in ("gt", "gte", "lt", "lte"):
            try:
                nval = float(val)
                sym  = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[op]
                parts.append(f"TRY_CAST({qcol} AS DOUBLE) {sym} ?");  params.append(nval)
            except (ValueError, TypeError):
                pass
        elif op == "is_null":
            parts.append(f"{qcol} IS NULL")
        elif op == "is_not_null":
            parts.append(f"{qcol} IS NOT NULL")

    if not parts:
        return "", []
    return f" WHERE {(' ' + conjunction + ' ').join(parts)}", params


def _duckdb_paginate(
    path: Path,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
) -> dict:
    """
    DuckDB-powered pagination — works for CSV, Parquet, JSON of any size.
    Uses pushdown predicates; never loads the full file into Python RAM.
    Falls back to pandas for Excel (.xlsx/.xls).
    """
    suffix = path.suffix.lower()

    # Excel: DuckDB can't read natively
    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)

    if not _DUCKDB_AVAILABLE:
        # Fallback to pandas (limited to files that fit in RAM)
        if suffix == ".parquet":
            df = pd.read_parquet(path)
        else:
            df = pd.read_csv(path)
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)

    # Empty file → execution produced 0 rows.  Return an empty-but-valid response
    # instead of letting DuckDB fail on a schema-less file.
    if path.stat().st_size == 0:
        return {
            "columns":       [],
            "rows":          [],
            "total_rows":    0,
            "filtered_rows": 0,
            "page":          page,
            "page_size":     page_size,
            "total_pages":   1,
            "filename":      filename_hint or path.name,
        }

    # ── Safety check: route snappy-compressed parquet through pandas/PyArrow ──
    # DuckDB can segfault on snappy parquet on some platforms/versions.
    # PyArrow always handles its own compression correctly.
    if suffix == ".parquet":
        try:
            import pyarrow.parquet as _pq_check
            _pf = _pq_check.ParquetFile(str(path))
            _meta = _pf.metadata
            _has_snappy = any(
                (_meta.row_group(rg).column(col).compression or "").upper() == "SNAPPY"
                for rg in range(_meta.num_row_groups)
                for col in range(_meta.row_group(rg).num_columns)
            )
            if _has_snappy:
                df = pd.read_parquet(path)
                return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)
        except Exception:
            pass  # If metadata read fails, continue with DuckDB path

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        # ── Schema + total_rows: use cache, compute only on first page ────────
        cached = _get_cached_meta(path)
        if cached:
            valid_cols = cached["columns"]
            total_rows = cached["total_rows"]
        else:
            valid_cols = _duckdb_valid_cols(con, source)
            if not valid_cols:
                raise HTTPException(status_code=500, detail="Cannot read file schema")
            total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
            _set_cached_meta(path, valid_cols, total_rows)

        where_clause, params = _build_where(adv_filters_json, valid_cols)

        order_clause = ""
        if sort_col and sort_col in valid_cols:
            direction = "ASC" if sort_dir == "asc" else "DESC"
            order_clause = f' ORDER BY "{sort_col}" {direction}'

        offset = (page - 1) * page_size

        # Filtered row count — cache per (file, filter) so paging within a
        # filter only scans the file once instead of on every page flip.
        if where_clause:
            _fkey = adv_filters_json or ""
            filtered_rows = _get_filtered_count_cache(path, _fkey)
            if filtered_rows is None:
                filtered_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}{where_clause}", params).fetchone()[0])
                _set_filtered_count_cache(path, _fkey, filtered_rows)
        else:
            filtered_rows = total_rows

        # Data page — the only query that must run every request
        data_sql   = f"SELECT * FROM {source}{where_clause}{order_clause} LIMIT {page_size} OFFSET {offset}"
        result_df  = con.execute(data_sql, params).fetchdf()
        result_df  = result_df.where(pd.notnull(result_df), None)
        result_df  = _serialize_df(result_df)

        return {
            "columns":       valid_cols,
            "rows":          result_df.to_dict("records"),
            "total_rows":    total_rows,
            "filtered_rows": filtered_rows,
            "page":          page,
            "page_size":     page_size,
            "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
            "filename":      filename_hint or path.name,
        }
    except HTTPException:
        raise
    except Exception as _duck_err:
        # DuckDB raised a Python exception — fall back to pandas/PyArrow
        import logging as _lg
        _lg.getLogger(__name__).warning("DuckDB read failed (%s), falling back to pandas: %s", path.name, _duck_err)
        if suffix == ".parquet":
            df = pd.read_parquet(path)
        elif suffix in (".csv", ".txt"):
            df = pd.read_csv(path)
        else:
            raise HTTPException(status_code=500, detail=f"Cannot read file: {_duck_err}")
        return _pandas_paginate(df, page, page_size, sort_col, sort_dir, adv_filters_json, filename_hint or path.name)
    finally:
        try:
            con.close()
        except Exception:
            pass


def _pandas_paginate(
    df: pd.DataFrame,
    page: int,
    page_size: int,
    sort_col: Optional[str],
    sort_dir: str,
    adv_filters_json: Optional[str],
    filename_hint: str = "",
) -> dict:
    """Pandas pagination (Excel files or DuckDB-unavailable fallback)."""
    total_rows = len(df)

    if adv_filters_json:
        try:
            af = json.loads(adv_filters_json)
            conjunction = af.get("conjunction", "AND").upper()
            masks = []
            for cond in af.get("conditions", []):
                col = cond.get("col", "")
                op  = cond.get("op", "contains")
                val = str(cond.get("val", ""))
                if col not in df.columns:
                    continue
                s = df[col].astype(str)
                if   op == "contains":      masks.append(s.str.contains(val, case=False, na=False))
                elif op == "not_contains":  masks.append(~s.str.contains(val, case=False, na=False))
                elif op == "equals":        masks.append(s.str.lower() == val.lower())
                elif op == "not_equals":    masks.append(s.str.lower() != val.lower())
                elif op == "starts_with":   masks.append(s.str.startswith(val, na=False))
                elif op == "ends_with":     masks.append(s.str.endswith(val, na=False))
                elif op in ("gt", "gte", "lt", "lte"):
                    try:
                        nval   = float(val)
                        numcol = pd.to_numeric(df[col], errors="coerce")
                        sym_fn = {"gt": numcol.__gt__, "gte": numcol.__ge__,
                                  "lt": numcol.__lt__, "lte": numcol.__le__}[op]
                        masks.append(sym_fn(nval).fillna(False))
                    except (ValueError, TypeError):
                        pass
                elif op == "is_null":     masks.append(df[col].isna())
                elif op == "is_not_null": masks.append(df[col].notna())
            if masks:
                combined = masks[0]
                for m in masks[1:]:
                    combined = (combined | m) if conjunction == "OR" else (combined & m)
                df = df[combined]
        except Exception:
            pass

    filtered_rows = len(df)
    if sort_col and sort_col in df.columns:
        df = df.sort_values(by=sort_col, ascending=(sort_dir == "asc"))

    start   = (page - 1) * page_size
    page_df = df.iloc[start: start + page_size]
    page_df = page_df.where(pd.notnull(page_df), None)
    page_df = _serialize_df(page_df)

    return {
        "columns":       df.columns.tolist(),
        "rows":          page_df.to_dict("records"),
        "total_rows":    total_rows,
        "filtered_rows": filtered_rows,
        "page":          page,
        "page_size":     page_size,
        "total_pages":   max(1, (filtered_rows + page_size - 1) // page_size),
        "filename":      filename_hint,
    }


def _duckdb_chart(path: Path, x_col: str, y_col: str, agg: str, top_n: int) -> dict:
    """DuckDB-powered chart aggregation — full scan, server-side groupby."""
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name)

    if not _DUCKDB_AVAILABLE:
        df = pd.read_parquet(path) if suffix == ".parquet" else pd.read_csv(path)
        return _pandas_chart(df, x_col, y_col, agg, top_n, path.name)

    if path.stat().st_size == 0:
        return {"x_col": x_col, "y_col": y_col, "agg": agg,
                "total_rows": 0, "groups": 0, "grand_total": 0.0, "data": []}

    source = _duckdb_source(path)
    con = _duckdb_con()
    try:
        valid_cols = set(_duckdb_valid_cols(con, source))
        if x_col not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Column '{x_col}' not found")
        if y_col not in valid_cols:
            raise HTTPException(status_code=400, detail=f"Column '{y_col}' not found")

        agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(agg, "SUM")
        total_rows  = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
        groups_cnt  = int(con.execute(f'SELECT COUNT(DISTINCT CAST("{x_col}" AS VARCHAR)) FROM {source}').fetchone()[0])

        agg_sql = f"""
            SELECT
                CAST("{x_col}" AS VARCHAR) AS label,
                {agg_fn}(TRY_CAST("{y_col}" AS DOUBLE)) AS value,
                COUNT(*) AS cnt
            FROM {source}
            GROUP BY "{x_col}"
            ORDER BY value DESC NULLS LAST
            LIMIT {top_n}
        """
        result_df   = con.execute(agg_sql).fetchdf()
        grand_total = float(result_df["value"].sum()) if len(result_df) > 0 else 0.0

        data = []
        for _, row in result_df.iterrows():
            v = None if pd.isna(row["value"]) else float(row["value"])
            data.append({
                "label": str(row["label"]),
                "value": v,
                "count": int(row["cnt"]),
                "pct":   round(v / grand_total * 100, 2) if grand_total and v is not None else 0,
            })

        return {"x_col": x_col, "y_col": y_col, "agg": agg,
                "total_rows": total_rows, "groups": groups_cnt, "grand_total": grand_total, "data": data}
    finally:
        con.close()


def _pandas_chart(df: pd.DataFrame, x_col: str, y_col: str, agg: str, top_n: int, name: str) -> dict:
    if x_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Column '{x_col}' not found")
    if y_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Column '{y_col}' not found")
    df[y_col] = pd.to_numeric(df[y_col], errors="coerce")
    grouped   = df.groupby(x_col, dropna=False)
    agg_map   = {"sum": "sum", "avg": "mean", "max": "max", "min": "min", "count": "count"}
    agg_s     = getattr(grouped[y_col], agg_map.get(agg, "sum"))()
    cnt_s     = grouped[y_col].count()
    res       = pd.DataFrame({"label": agg_s.index.astype(str), "value": agg_s.values, "count": cnt_s.values})\
                  .sort_values("value", ascending=False).head(top_n)
    total     = float(res["value"].sum())
    return {
        "x_col": x_col, "y_col": y_col, "agg": agg,
        "total_rows": len(df), "groups": len(agg_s), "grand_total": total,
        "data": [
            {"label": r["label"],
             "value": None if pd.isna(r["value"]) else float(r["value"]),
             "count": int(r["count"]),
             "pct":   round(float(r["value"]) / total * 100, 2) if total and not pd.isna(r["value"]) else 0}
            for _, r in res.iterrows()
        ],
    }


# ═══════════════════════════════════════════════════════════════════
# Paginated results — execution (1M+ rows supported via DuckDB)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/results")
async def get_paginated_results(
    execution_id:   str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=5000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy per-column
):
    """Paginated results with DuckDB — handles any file size."""
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")

    # Coerce legacy per-column filters into adv_filters format
    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conditions = [
                {"col": col, "op": "contains", "val": val}
                for col, val in json.loads(filters).items()
                if val
            ]
            if conditions:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conditions})
        except Exception:
            pass

    try:
        result = await _aduckdb(lambda: _duckdb_paginate(
            csv_file, page, page_size, sort_column, sort_direction or "asc", effective_adv))
        return _JSONResp(content=result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading results: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Chart data — full dataset aggregation (DuckDB)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/chart-data")
async def get_chart_data(
    execution_id: str,
    x_col: str,
    y_col: str,
    agg:   str = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n: int = Query(50, ge=1, le=500),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    try:
        return await _aduckdb(lambda: _duckdb_chart(csv_file, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Export — background task (pandas OK here — converts once to target format)
# ═══════════════════════════════════════════════════════════════════
def _do_export(execution_id, export_format, output_path, file_id, filename, loop=None):
    import asyncio
    import shutil
    import logging as _logging
    _log = _logging.getLogger(__name__)
    try:
        csv_file = find_csv_file(execution_id)
        if not csv_file:
            _log.error(f"Export [{execution_id}]: source CSV not found")
            return

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        is_parquet = csv_file.suffix.lower() == ".parquet"

        if export_format == "csv":
            if is_parquet:
                # Convert parquet → CSV for the user's download
                df = pd.read_parquet(csv_file)
                df.to_csv(str(out), index=False)
            else:
                shutil.copy2(str(csv_file), str(out))
        else:
            # Excel / JSON need the DataFrame
            df = pd.read_parquet(csv_file) if is_parquet else pd.read_csv(csv_file)
            if export_format == "excel":
                with pd.ExcelWriter(str(out), engine="openpyxl") as writer:
                    df.to_excel(writer, index=False, sheet_name="Query Results")
            elif export_format == "json":
                out.write_text(df.to_json(orient="records", indent=2), encoding="utf-8")

        file_size = out.stat().st_size
        _db = _get_db()
        if _db:
            _db.create_download_file(
                file_id=file_id, execution_id=execution_id, filename=filename,
                file_path=str(out), file_size_bytes=file_size,
                expires_at=datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=7),
            )
        _emit_loop = loop or _main_loop
        if _ws_manager and _emit_loop:
            asyncio.run_coroutine_threadsafe(
                _ws_manager.broadcast({
                    "type": "export_completed", "file_id": file_id, "filename": filename,
                    "format": export_format, "execution_id": execution_id,
                    "file_size_bytes": file_size, "timestamp": datetime.now(timezone.utc).isoformat(),
                }),
                _emit_loop,
            )
        _log.info(f"Export completed [{execution_id}] → {filename}")
    except Exception as e:
        _logging.getLogger(__name__).error(f"Export failed [{execution_id}]: {e}")


@router.post("/api/executions/{execution_id}/export")
async def export_results_background(
    execution_id: str,
    background_tasks: BackgroundTasks,
    format: str = Query("csv", pattern="^(csv|excel|json)$"),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    ext     = {"csv": ".csv", "excel": ".xlsx", "json": ".json"}[format]
    file_id = str(uuid.uuid4())
    fname   = f"export_{execution_id[:8]}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}{ext}"
    out_path = str(_get_downloads_dir() / f"{file_id}{ext}")
    import asyncio as _a
    try:    loop = _a.get_running_loop()
    except RuntimeError: loop = None
    background_tasks.add_task(_do_export, execution_id, format, out_path, file_id, fname, loop)
    return {"file_id": file_id, "filename": fname, "format": format,
            "message": f"Export started. '{fname}' will appear on the Downloads page shortly."}


@router.get("/api/executions/{execution_id}/export")
async def export_results_direct(
    execution_id: str,
    format: str = Query("csv", pattern="^(csv|excel|json)$"),
):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")
    is_parquet = csv_file.suffix.lower() == ".parquet"
    if format == "csv":
        if not is_parquet:
            return FileResponse(path=csv_file, filename=f"query_results_{execution_id}.csv", media_type="text/csv")
        # Convert parquet → CSV stream
        try:
            buf = io.StringIO()
            pd.read_parquet(csv_file).to_csv(buf, index=False)
            buf.seek(0)
            return StreamingResponse(buf, media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.csv"})
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")
    try:
        df = pd.read_parquet(csv_file) if is_parquet else pd.read_csv(csv_file)
        if format == "excel":
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w:
                df.to_excel(w, index=False, sheet_name="Query Results")
            buf.seek(0)
            return StreamingResponse(buf,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.xlsx"})
        if format == "json":
            return StreamingResponse(io.StringIO(df.to_json(orient="records", indent=2)),
                media_type="application/json",
                headers={"Content-Disposition": f"attachment; filename=query_results_{execution_id}.json"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Release execution result — delete temp CSV when user is done
# ═══════════════════════════════════════════════════════════════════
@router.delete("/api/executions/{execution_id}/results")
async def release_execution_results(execution_id: str):
    """
    Delete the temporary CSV produced by a SQL execution.
    Called by the frontend when the user closes the result grid.
    This prevents temp files from accumulating on disk.
    """
    import logging as _lg
    _log = _lg.getLogger(__name__)
    csv_file = find_csv_file(execution_id)
    if csv_file and csv_file.exists():
        try:
            csv_file.unlink()
            _evict_cached_meta(csv_file)
            _log.info(f"Released execution result: {csv_file.name}")
        except OSError as e:
            _log.warning(f"Could not delete {csv_file}: {e}")
    return {"deleted": bool(csv_file), "execution_id": execution_id}


# ═══════════════════════════════════════════════════════════════════
# Column stats — full dataset
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/executions/{execution_id}/stats")
async def get_result_stats(execution_id: str):
    csv_file = find_csv_file(execution_id)
    if not csv_file:
        raise HTTPException(status_code=404, detail="Results file not found")

    def _compute():
        if csv_file.suffix.lower() == ".parquet":
            df = pd.read_parquet(csv_file)
        else:
            df = pd.read_csv(csv_file)
        stats = {"total_rows": len(df), "total_columns": len(df.columns),
                 "file_size_bytes": csv_file.stat().st_size, "columns": []}
        for col in df.columns:
            cs = {"name": col, "type": str(df[col].dtype),
                  "null_count": int(df[col].isnull().sum()),
                  "unique_count": int(df[col].nunique())}
            if pd.api.types.is_numeric_dtype(df[col]):
                cs["min"]  = float(df[col].min())  if not pd.isna(df[col].min())  else None
                cs["max"]  = float(df[col].max())  if not pd.isna(df[col].max())  else None
                cs["mean"] = float(df[col].mean()) if not pd.isna(df[col].mean()) else None
            stats["columns"].append(cs)
        return stats

    try:
        return await _aduckdb(_compute)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing stats: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Download file helpers
# ═══════════════════════════════════════════════════════════════════
def _resolve_download_path(record: dict, file_id: str) -> Optional[Path]:
    """Try multiple locations to find a DownloadFile on disk."""
    stored       = record.get("file_path", "")
    filename     = record.get("filename", "")
    execution_id = record.get("execution_id", "")

    candidates: list = []
    if stored:
        candidates.append(Path(stored))
    if stored and stored.startswith("./"):
        candidates.append(Path(stored[2:]))
    dl = _get_downloads_dir()
    for base in (dl, Path("data/downloads"), Path("./data/downloads")):
        candidates.append(base / f"{file_id}.parquet")
        candidates.append(base / f"{file_id}.csv")
        if filename:
            candidates.append(base / filename)
        if execution_id:
            candidates.append(base / f"{execution_id}.parquet")
            candidates.append(base / f"{execution_id}.csv")

    for c in candidates:
        try:
            if c.exists() and c.is_file():
                return c
        except Exception:
            pass
    return None


# ═══════════════════════════════════════════════════════════════════
# Preview by file_id — DuckDB, any size
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/downloads/{file_id}/preview")
async def preview_download_file(
    file_id:        str,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=500),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,   # legacy
):
    path     = None
    filename = ""

    # Preferred: DB lookup for the DownloadFile record
    _db = _get_db()
    if _db:
        loop   = asyncio.get_running_loop()
        record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
        if record:
            path     = _resolve_download_path(record, file_id)
            filename = record.get("filename", "")

    # Fallback: treat file_id as an execution_id and look for the raw CSV
    if path is None:
        path = find_csv_file(file_id)

    if path is None:
        raise HTTPException(
            status_code=404,
            detail=f"No download record or results file found for id={file_id}")

    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conds = [{"col": c, "op": "contains", "val": v} for c, v in json.loads(filters).items() if v]
            if conds:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conds})
        except Exception:
            pass

    try:
        result = await _aduckdb(lambda: _duckdb_paginate(
            path, page, page_size, sort_column,
            sort_direction or "asc", effective_adv, filename))
        return _JSONResp(content=result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Chart data for download file (by file_id)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/downloads/{file_id}/chart-data")
async def chart_data_download_file(
    file_id: str,
    x_col:   str,
    y_col:   str,
    agg:     str  = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:   int  = Query(50, ge=1, le=500),
):
    path = None
    _db  = _get_db()
    if _db:
        loop   = asyncio.get_running_loop()
        record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
        if record:
            path = _resolve_download_path(record, file_id)
    if path is None:
        path = find_csv_file(file_id)
    if path is None:
        raise HTTPException(status_code=404,
            detail=f"No download record or results file found for id={file_id}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Direct download of a DownloadFile by file_id
# ═══════════════════════════════════════════════════════════════════


@router.get("/api/downloads/{file_id}/download")
async def download_file_direct(file_id: str):
    _db = _get_db()
    if not _db:
        raise HTTPException(status_code=503, detail="Service unavailable")
    loop = asyncio.get_running_loop()
    record = await loop.run_in_executor(_duckdb_executor, _db.get_download_file, file_id)
    if not record:
        raise HTTPException(status_code=404, detail=f"No download record for file_id={file_id}")
    path = _resolve_download_path(record, file_id)
    if path is None:
        raise HTTPException(status_code=404, detail="File not found on disk")
    filename   = record.get("filename", path.name)
    media_map  = {".csv": "text/csv", ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  ".json": "application/json"}
    media_type = media_map.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(path=str(path), filename=filename, media_type=media_type)


# ═══════════════════════════════════════════════════════════════════
# Raw file path resolution helper
# ═══════════════════════════════════════════════════════════════════
def _resolve_raw_path(file_path: str, connection_id: Optional[int]) -> Path:
    """Resolve a relative/absolute path, trying connection base_path as fallback."""
    path = Path(file_path)
    if path.is_absolute() and path.exists():
        return path
    _db = _get_db()
    if connection_id and _db:
        try:
            conn = _db.get_connection_raw(connection_id)
            if conn:
                cfg  = conn.get("config", {})
                base = cfg.get("base_path") or cfg.get("folder_path")
                if base:
                    candidate = Path(base) / file_path
                    if candidate.exists():
                        return candidate
        except Exception:
            pass
    default = _get_parquet_dir() / file_path
    if default.exists():
        return default
    return path


# ═══════════════════════════════════════════════════════════════════
# Raw file preview — CSV or Parquet by path (DuckDB, any size)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/data")
async def get_raw_file_data(
    file_path:      str,
    connection_id:  Optional[int] = None,
    page:           int           = Query(1, ge=1),
    page_size:      int           = Query(100, ge=1, le=5000),
    sort_column:    Optional[str] = None,
    sort_direction: Optional[str] = Query("asc", pattern="^(asc|desc)$"),
    adv_filters:    Optional[str] = None,
    filters:        Optional[str] = None,  # legacy
):
    """Paginated preview of any file (CSV/Parquet/Excel/JSON).
    Supply connection_id when file_path is relative to a connection's base_path."""
    path = _resolve_raw_path(file_path, connection_id)
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

    effective_adv = adv_filters
    if not effective_adv and filters:
        try:
            conds = [{"col": c, "op": "contains", "val": v} for c, v in json.loads(filters).items() if v]
            if conds:
                effective_adv = json.dumps({"conjunction": "AND", "conditions": conds})
        except Exception:
            pass

    try:
        result = await _aduckdb(lambda: _duckdb_paginate(
            path, page, page_size, sort_column, sort_direction or "asc", effective_adv))
        return _JSONResp(content=result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# Raw file chart data (CSV or Parquet, by path)
# ═══════════════════════════════════════════════════════════════════
@router.get("/api/files/chart-data")
async def get_raw_file_chart_data(
    file_path:     str,
    x_col:         str,
    y_col:         str,
    connection_id: Optional[int] = None,
    agg:           str  = Query("sum", pattern="^(sum|avg|count|max|min)$"),
    top_n:         int  = Query(50, ge=1, le=500),
):
    path = _resolve_raw_path(file_path, connection_id)
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    try:
        return await _aduckdb(lambda: _duckdb_chart(path, x_col, y_col, agg, top_n))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error computing chart data: {str(e)}")


# ═══════════════════════════════════════════════════════════════════
# /api/query/preview  — Direct DuckDB preview (no file created)
#
# Queries source files (local parquet, S3 parquet, or S3 Iceberg tables)
# directly via DuckDB without executing the full pipeline or writing any
# result file to disk.  Ideal for "preview first 500 rows" in the UI
# before committing to a full execution.
# ═══════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _BM


class _PreviewRequest(_BM):
    files:         list                     # local paths or s3:// URIs or __iceberg__:... refs
    adv_filters:   Optional[str]  = None   # adv_filters JSON (date expressions resolved internally)
    columns:       Optional[list] = None
    limit:         int            = 500
    connection_id: Optional[int]  = None   # resolve S3 credentials from saved connection


@router.post("/api/query/preview")
async def direct_preview(req: _PreviewRequest):
    """Return up to `limit` rows from source files without creating any execution
    record or writing any result file to disk.

    Supports local parquet/csv/json, S3 parquet (via httpfs), and S3 Iceberg
    tables (via iceberg_scan — __iceberg__: prefix).
    Date expressions in adv_filters are resolved before the query is issued.
    """
    from core.date_resolver import resolve_adv_filters

    adv = resolve_adv_filters(req.adv_filters)
    conn_config: dict = {}
    if req.connection_id:
        db = _get_db()
        if db:
            rec = db.get_connection_raw(req.connection_id)
            if rec:
                conn_config = rec.get("config") or {}

    def _run() -> dict:
        has_remote  = any(f.startswith("s3://") or f.startswith("__iceberg__:") for f in req.files)
        has_iceberg = any(f.startswith("__iceberg__:") for f in req.files)

        con = _duckdb_con_with_s3(conn_config) if (has_remote and conn_config) else _duckdb_con()
        if has_iceberg:
            _ensure_iceberg_extension(con)

        sources = []
        for f in req.files:
            if f.startswith("__iceberg__:"):
                table_uri = f[len("__iceberg__:"):]
                if not table_uri.startswith("s3://"):
                    bucket = conn_config.get("bucket_name", "")
                    table_uri = f"s3://{bucket}/{table_uri.lstrip('/')}"
                sources.append(_duckdb_iceberg_source(table_uri))
            elif f.startswith("s3://"):
                safe = f.replace("'", "''")
                sources.append(f"read_parquet('{safe}')")
            else:
                sources.append(_duckdb_source(Path(f)))

        if not sources:
            return {"columns": [], "rows": [], "total_rows": 0, "returned": 0}

        if len(sources) == 1:
            from_clause = sources[0]
        else:
            # Detect if all sources are plain parquet (local or S3) — no iceberg
            plain_parquet_paths = []
            all_plain_parquet = True
            for f in req.files:
                if f.startswith("__iceberg__:"):
                    all_plain_parquet = False
                    break
                elif f.startswith("s3://"):
                    plain_parquet_paths.append(f"'{f.replace(chr(39), chr(39)*2)}'")
                else:
                    plain_parquet_paths.append(f"'{Path(f).resolve().as_posix().replace(chr(39), chr(39)*2)}'")

            if all_plain_parquet:
                # read_parquet with a list + union_by_name handles schema differences
                from_clause = f"read_parquet([{', '.join(plain_parquet_paths)}], union_by_name=true)"
            else:
                # Mixed types (iceberg + parquet, etc.) — UNION ALL BY NAME aligns columns by name
                from_clause = (
                    "(" + " UNION ALL BY NAME ".join(f"SELECT * FROM {s}" for s in sources) + ")"
                )

        try:
            valid_cols = con.execute(f"SELECT * FROM {from_clause} LIMIT 0").fetchdf().columns.tolist()
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Cannot read source schema: {exc}")

        select_cols = (
            ", ".join(f'"{c}"' for c in req.columns if c in valid_cols) or "*"
            if req.columns else "*"
        )

        where, params = _build_where(adv, valid_cols)

        try:
            total_rows = int(con.execute(
                f"SELECT COUNT(*) FROM {from_clause}{where}", params or []
            ).fetchone()[0])
        except Exception:
            total_rows = -1   # unknown (e.g. Iceberg with complex predicate)

        limit_n = min(req.limit, 5000)    # hard cap to protect server RAM
        df = con.execute(
            f"SELECT {select_cols} FROM {from_clause}{where} LIMIT {limit_n}", params or []
        ).fetchdf()
        df = _serialize_df(df)

        return {
            "columns":    df.columns.tolist(),
            "rows":       df.to_dict("records"),
            "total_rows": total_rows,
            "returned":   len(df),
        }

    try:
        return await _aduckdb(_run)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
