# ============================================================
# app/core/settings.py
# ============================================================
from pydantic_settings import BaseSettings
from typing import Optional
from pathlib import Path


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────
    app_name:    str  = "Smart Parquet Query API"
    app_version: str  = "1.0.0"
    debug:       bool = False
    log_level:   str  = "INFO"

    # ── Server ───────────────────────────────────────────────
    host:    str = "0.0.0.0"
    port:    int = 8000
    workers: int = 4

    # ── DuckDB per-worker ────────────────────────────────────
    duckdb_threads:       int = 4       # threads PER query
    duckdb_memory_limit:  str = "8GB"   # RAISED — 9M×1000col needs headroom
    duckdb_temp_dir:      str = "/tmp/duckdb"  # spill-to-disk when over limit
    query_timeout_seconds: int = 300

    # ── Large data guards ─────────────────────────────────────
    # Block SELECT * on query/stream endpoints
    # SELECT * is ALLOWED on export endpoint (that is the whole point)
    block_select_star:    bool = True
    max_columns_in_query: int = 50

    # ── NDJSON Streaming ──────────────────────────────────────
    stream_chunk_size:      int = 10_000
    max_concurrent_streams: int = 4

    # ── S3 Parquet Export ─────────────────────────────────────
    export_row_group_size:    int = 100_000
    export_presigned_url_ttl: int = 14_400
    s3_export_prefix:         str = "exports"

    # Max rows returned per page — LOWERED for large files
    # 9M rows × 50 cols × 50 bytes = 22MB per page at 10k rows
    # Keep pages small so Redis / client can handle them
    default_page_size:    int = 1_000
    max_page_size:        int = 10_000  # LOWERED from 50k — protect memory

    # Result size threshold — above this goes to S3 as Parquet, not Redis JSON
    # LOWERED from 10MB → 1MB because:
    #   9M rows × any reasonable column set easily hits 10MB+
    #   Redis JSON is 3-5× bigger than Parquet
    result_size_threshold_mb: float = 1.0

    # Max rows allowed in inline Redis result
    # Above this → S3 regardless of byte size
    result_inline_max_rows: int = 5_000

    # ── Queue separation by data size ─────────────────────────
    # Separate queues prevent 9M-row jobs blocking 500k-row jobs
    queue_high:   str = "jobs:high"    # < 500k rows (interactive)
    queue_normal: str = "jobs:normal"  # 500k – 3M rows
    queue_low:    str = "jobs:low"     # > 3M rows (batch)

    # Row count thresholds for auto-routing (used in submit endpoint)
    queue_threshold_high_rows:   int = 500_000
    queue_threshold_normal_rows: int = 3_000_000

    # ── Concurrency ──────────────────────────────────────────
    # For heavy queries (9M rows): run FEWER in parallel
    # Each query needs 2-4GB RAM — too many = OOM
    # Rule: DUCKDB_MEMORY_LIMIT / expected_query_memory
    # 8GB worker, 2GB per 9M query → max 4 concurrent
    max_concurrent_queries: int = 2     # LOWERED for large data safety
    thread_pool_size:       int = 4
    max_queue_depth:        int = 200

    # ── Distributed / Redis ───────────────────────────────────
    distributed_mode: bool = False
    redis_url:        str  = "redis://localhost:6379/0"
    job_ttl_seconds:  int  = 3600
    worker_id: Optional[str] = None

    # S3 results prefix
    s3_results_prefix: str = "query-results"
    spark_result_partitions: int = 4

    # ── Cache ────────────────────────────────────────────────
    cache_enabled:     bool = True
    cache_ttl_seconds: int  = 300   # 5 min — large results stale quickly

    # ── Storage: Local ───────────────────────────────────────
    local_data_dir: str = str(Path(__file__).parent.parent.parent / "data")

    # ── Storage: S3 ──────────────────────────────────────────
    s3_enabled:            bool          = False
    s3_bucket:             str           = ""
    s3_region:             str           = "us-east-1"
    s3_endpoint_url:       Optional[str] = None
    aws_access_key_id:     Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token:     Optional[str] = None

    # ── Config paths ─────────────────────────────────────────
    queries_config_path: str = str(
        Path(__file__).parent.parent.parent / "config" / "queries.yaml"
    )

    # ── Generic endpoint security ────────────────────────────
    generic_endpoint_enabled:           bool = True
    generic_endpoint_allowed_prefixes:  str  = "SELECT,WITH,EXPLAIN"
    generic_endpoint_max_rows:          int  = 10_000

    # ── Apache Iceberg ───────────────────────────────────────
    iceberg_enabled:          bool         = False
    iceberg_catalog_type:     str          = "rest"
    iceberg_catalog_name:     str          = "default"
    iceberg_rest_uri:         Optional[str] = None
    iceberg_rest_credential:  Optional[str] = None
    iceberg_rest_token:       Optional[str] = None
    iceberg_rest_warehouse:   Optional[str] = None
    iceberg_hive_uri:         Optional[str] = None
    iceberg_glue_region:      Optional[str] = None
    iceberg_hadoop_warehouse: Optional[str] = None
    iceberg_nessie_uri:       Optional[str] = None
    iceberg_nessie_ref:       str           = "main"
    iceberg_extra_properties: Optional[str] = None

    # ── Auth (optional) ──────────────────────────────────────
    api_key_enabled: bool         = False
    api_key:         Optional[str] = None

    class Config:
        env_file           = ".env"
        env_file_encoding  = "utf-8"


settings = Settings()
