# ============================================================
# app/core/logging.py — Structured JSON logging (structlog)
# ============================================================
"""
LOG FORMAT
══════════
Production (LOG_LEVEL=INFO, DEBUG=false):
  {"event":"job_submitted","job_id":"abc-123","priority":"high","timestamp":"2024-01-15T10:30:00Z","level":"info","request_id":"f3a9b2"}

Development (DEBUG=true):
  2024-01-15 10:30:00 [info     ] job_submitted    job_id=abc-123 priority=high

Every log line carries:
  request_id   — traces one HTTP request through all log lines
  worker_id    — which worker process handled it (distributed mode)
  timestamp    — ISO 8601 UTC
  level        — debug/info/warning/error
  event        — machine-readable event name (snake_case)
  + arbitrary context fields

GREP PATTERNS (production)
═══════════════════════════
  # All errors
  docker logs api | jq 'select(.level=="error")'

  # Slow queries (>5s)
  docker logs worker | jq 'select(.execution_ms > 5000)'

  # One request's full trace
  docker logs api | jq 'select(.request_id=="f3a9b2")'

  # Job lifecycle
  docker logs worker | jq 'select(.job_id=="abc-123")'
"""
import logging
import sys

import structlog
from app.core.settings import settings


def setup_logging() -> None:
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)

    shared_processors = [
        structlog.contextvars.merge_contextvars,           # request_id, worker_id etc
        structlog.stdlib.add_logger_name,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if settings.debug:
        # Human-readable for local dev
        processors = shared_processors + [structlog.dev.ConsoleRenderer(colors=True)]
    else:
        # Machine-readable JSON for production / log aggregators (ELK, Splunk, Datadog)
        processors = shared_processors + [
            structlog.processors.dict_tracebacks,
            structlog.processors.JSONRenderer(),
        ]

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
        cache_logger_on_first_use=True,
    )

    # Propagate stdlib logging through structlog
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=log_level,
    )
    logging.root.setLevel(log_level)

    # Silence very noisy third-party loggers
    for lib in (
        "uvicorn.access",    # handled by our middleware
        "boto3", "botocore", "s3transfer",
        "urllib3.connectionpool",
        "pyiceberg",
    ):
        logging.getLogger(lib).setLevel(logging.WARNING)


logger = structlog.get_logger()
