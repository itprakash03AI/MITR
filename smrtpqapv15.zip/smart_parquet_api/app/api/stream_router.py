# ============================================================
# app/api/stream_router.py  —  Streaming + Export endpoints
# ============================================================
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

import structlog

from app.core.streaming import stream_query_ndjson
from app.core.sql_analyzer import sql_analyzer
from app.core.job_queue import Job, JobPriority, JobQueueClient, get_job_queue
from app.core.settings import settings

logger = structlog.get_logger()

stream_router = APIRouter(prefix="/api/stream", tags=["🌊 Streaming & Export"])


# ═══════════════════════════════════════════════════════════════════════════
# NDJSON Streaming  —  Scenario 1: 9M × 50 columns
# ═══════════════════════════════════════════════════════════════════════════

@stream_router.get(
    "/sql",
    summary="Stream query result as NDJSON",
    description="""
## True Row Streaming

Executes SQL and streams the result as NDJSON (Newline-Delimited JSON).
One JSON object per line. Client receives rows as DuckDB reads them.

**Use this for:**
- Large result sets that won't fit in memory
- Up to 50 columns (specify explicitly — no SELECT *)
- Up to ~9M rows — each row is ~2-5KB of JSON
- When you need rows immediately, not after full execution

**Do NOT use for:**
- `SELECT *` on 1000-column files → use `/api/export/sql` instead
- Aggregations (GROUP BY) → result must be fully computed first, use `/api/jobs/submit`
- Results you want to paginate → use `/api/execute/sql?page=N`

## Response Format

```
{"account_id":"ACC-001","fiscal_year":2024,"debit_amount":1234.56}
{"account_id":"ACC-002","fiscal_year":2024,"debit_amount":2345.67}
... (one line per row, continuously)
{"_stream_complete":true,"total_rows":9000000,"elapsed_ms":45231}
```

Last line is always the `_stream_complete` sentinel. Connection then closes.

## Consuming the Stream

**Python (requests):**
```python
import requests, json

url = "http://localhost:8000/api/stream/sql"
params = {"sql": "SELECT account_id, fiscal_year FROM read_parquet('...')"}

with requests.get(url, params=params, stream=True) as r:
    for line in r.iter_lines():
        if line:
            row = json.loads(line)
            if "_stream_complete" in row:
                print(f"Done: {row['total_rows']} rows")
            else:
                process(row)
```

**curl:**
```bash
curl -N "http://localhost:8000/api/stream/sql?sql=SELECT+account_id,fiscal_year+FROM+..."
# -N = no buffering, rows appear as they arrive
```

**JavaScript (fetch):**
```javascript
const res = await fetch(`/api/stream/sql?sql=${encodeURIComponent(sql)}`);
const reader = res.body.getReader();
const decoder = new TextDecoder();
let buffer = '';
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\\n');
    buffer = lines.pop();
    for (const line of lines) {
        if (line) {
            const row = JSON.parse(line);
            if (!row._stream_complete) handleRow(row);
        }
    }
}
```
""",
    response_class=StreamingResponse,
)
async def stream_sql(
    sql: str = Query(
        ...,
        description="SELECT SQL — no aggregations, max 50 columns, no SELECT *"
    ),
    chunk_size: int = Query(
        default=None,
        ge=100,
        le=100_000,
        description=f"Rows per chunk (default: {settings.stream_chunk_size})"
    ),
):
    # SQL validation — SELECT * still blocked here (too large for NDJSON)
    stripped = sql.strip().upper()
    if not any(stripped.startswith(p) for p in ("SELECT", "WITH")):
        raise HTTPException(status_code=400, detail="Only SELECT/WITH allowed")

    analysis = sql_analyzer.analyze(sql)
    if not analysis.is_safe:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "SQL blocked",
                "errors":  analysis.errors,
                "hint":    "For 1000 columns use POST /api/export/sql instead",
            }
        )

    if analysis.has_select_star:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "SELECT * not allowed in streaming endpoint",
                "hint": (
                    "Specify up to 50 column names explicitly. "
                    "For all 1000 columns use POST /api/export/sql — "
                    "it writes Parquet to S3 which handles 1000 cols efficiently."
                ),
            }
        )

    logger.info(
        "stream_start",
        sql_preview=sql[:100],
        chunk_size=chunk_size or settings.stream_chunk_size,
        estimated_columns=analysis.estimated_columns,
        has_where=analysis.has_where,
        warnings=analysis.warnings,
    )

    return StreamingResponse(
        stream_query_ndjson(sql, chunk_size=chunk_size),
        media_type="application/x-ndjson",
        headers={
            "X-Accel-Buffering":      "no",   # disable nginx buffering
            "Cache-Control":          "no-cache",
            "Transfer-Encoding":      "chunked",
            "X-Stream-Chunk-Size":    str(chunk_size or settings.stream_chunk_size),
        },
    )


# ═══════════════════════════════════════════════════════════════════════════
# S3 Parquet Export  —  Scenario 2: 9M × 1000 columns or large aggregations
# ═══════════════════════════════════════════════════════════════════════════

@stream_router.post(
    "/export",
    summary="Export query result to S3 as Parquet (async job)",
    description="""
## S3 Parquet Export

For queries where the result is too large for JSON streaming:
- `SELECT *` on 1000-column files
- Heavy aggregations with millions of result rows
- Results intended for pandas, BI tools, or downstream pipelines

**How it works:**
1. Submit export → get `job_id` immediately
2. Worker runs the full query (may take 1-5 minutes for 9M rows)
3. Worker writes partitioned Parquet directly to S3 using DuckDB COPY
4. Poll `GET /api/jobs/{job_id}` until `status=done`
5. Get result: list of presigned S3 URLs, one per Parquet part

**SELECT * is ALLOWED here** — exporting all 1000 columns is the whole point.

**Result structure:**
```json
{
  "export_id":  "abc-123",
  "total_rows": 9000000,
  "total_mb":   1840.5,
  "part_count": 4,
  "parts": [
    {
      "part":      0,
      "size_mb":   487.3,
      "row_count": 2250000,
      "url":       "https://s3.amazonaws.com/...",
      "expires_at":"2024-01-15T18:00:00Z"
    }
  ],
  "how_to_read": {
    "pandas":  "pd.read_parquet('s3://bucket/exports/abc-123/')",
    "duckdb":  "SELECT * FROM read_parquet('s3://bucket/exports/abc-123/*.parquet')",
    "direct_dl": "Use the presigned 'url' in each part for direct download"
  }
}
```

**Consuming with pandas:**
```python
import pandas as pd
df = pd.read_parquet("s3://bucket/exports/abc-123/")
# or part by part:
for part in result["parts"]:
    df = pd.read_parquet(part["url"])
    process(df)
```

**Consuming with DuckDB:**
```python
import duckdb
df = duckdb.sql("SELECT * FROM read_parquet('s3://bucket/exports/abc-123/*.parquet')").df()
```

**Direct download (curl):**
```bash
for url in $(curl .../result | jq -r '.parts[].url'); do
    wget "$url"
done
```

**Requires:** S3_ENABLED=true, S3_BUCKET set in env.
""",
)
async def export_to_s3(
    sql: str = Query(
        ...,
        description="SQL to export — SELECT * allowed here"
    ),
    priority: JobPriority = Query(
        default=JobPriority.LOW,
        description="Queue priority (exports default to low — they are long-running)"
    ),
    estimated_rows: Optional[int] = Query(
        default=None,
        description="Hint: source table row count. Used for queue routing."
    ),
    queue: JobQueueClient = Depends(get_job_queue),
):
    if not settings.s3_enabled or not settings.s3_bucket:
        raise HTTPException(
            status_code=503,
            detail={
                "message": "S3 export not configured",
                "fix":     "Set S3_ENABLED=true and S3_BUCKET in your .env file",
            }
        )

    stripped = sql.strip().upper()
    if not any(stripped.startswith(p) for p in ("SELECT", "WITH")):
        raise HTTPException(status_code=400, detail="Only SELECT/WITH allowed")

    # Run safety check BUT allow SELECT * (export is the valid use case)
    # Only block dangerous patterns (DDL, shell, etc.)
    from app.core.sql_analyzer import SQLAnalyzer
    analyzer = SQLAnalyzer()
    # Temporarily allow SELECT * for export
    import app.core.settings as _s
    original = _s.settings.block_select_star
    _s.settings.block_select_star = False
    analysis = analyzer.analyze(sql, estimated_row_hint=estimated_rows)
    _s.settings.block_select_star = original

    if not analysis.is_safe:
        raise HTTPException(
            status_code=400,
            detail={"message": "SQL blocked", "errors": analysis.errors}
        )

    # Tag this job as an export — worker.py checks this tag
    job = Job(
        sql=sql,
        priority=priority,
        page=1,
        page_size=1,        # not used for exports
        cache=False,        # never cache exports
        tags={"mode": "export", "estimated_rows": str(estimated_rows or "unknown")},
    )

    job_id = await queue.submit(job)
    logger.info(
        "export_submitted",
        job_id=job_id,
        sql_preview=sql[:80],
        priority=str(priority),
        s3_bucket=settings.s3_bucket,
        s3_prefix=settings.s3_export_prefix,
    )

    return {
        "job_id":   job_id,
        "status":   "queued",
        "mode":     "export",
        "message":  f"Poll GET /api/jobs/{job_id} — export writes to S3 (takes 1-5 min for 9M rows)",
        "result_endpoint": f"/api/jobs/{job_id}/result",
        "note": (
            "Result will contain presigned S3 URLs for each Parquet part. "
            f"URLs valid for {settings.export_presigned_url_ttl // 3600} hours."
        ),
    }
