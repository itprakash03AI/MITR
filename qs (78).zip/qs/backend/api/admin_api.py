"""
Admin, system configuration, audit, and user management endpoints.
Extracted from main.py (Phase 29 enterprise refactoring).
"""
from __future__ import annotations

import json
import os
import logging
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, HTTPException, Depends, Request, Query
from fastapi.responses import Response as _Resp, StreamingResponse
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin, require_role, require_execute_access
from core.execution_state import (
    running_tasks, cancellation_flags, user_query_counts, user_query_lock,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["admin"])

# ── Module-level singletons — populated by set_admin_dependencies() ──────────
_db_manager  = None
_engine      = None
_paths       = None
_qe_cfg      = None
_auth_cfg    = None
_ws_manager  = None


def set_admin_dependencies(db_manager, engine, paths, qe_cfg, auth_cfg, ws_manager):
    """Call once from main.py after all components are initialised."""
    global _db_manager, _engine, _paths, _qe_cfg, _auth_cfg, _ws_manager
    _db_manager = db_manager
    _engine     = engine
    _paths      = paths
    _qe_cfg     = qe_cfg
    _auth_cfg   = auth_cfg
    _ws_manager = ws_manager


# ── Pydantic models ────────────────────────────────────────────────────────────

class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent:  Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue:       Optional[int] = None
    report_max_concurrent:       Optional[int] = None
    report_default_timeout:      Optional[int] = None
    report_max_queue:            Optional[int] = None
    scheduled_max_concurrent:    Optional[int] = None
    scheduled_default_timeout:   Optional[int] = None
    scheduled_max_queue:         Optional[int] = None
    export_max_concurrent:       Optional[int] = None
    export_default_timeout:      Optional[int] = None
    export_max_queue:            Optional[int] = None
    system_max_concurrent:       Optional[int] = None
    system_default_timeout:      Optional[int] = None
    system_max_queue:            Optional[int] = None


class AppConfigUpdateRequest(BaseModel):
    limits:     Optional[dict] = None
    features:   Optional[dict] = None
    s3_results: Optional[dict] = None


class QueueConfigUpdateRequest(BaseModel):
    backend:        Optional[str]  = None
    redis_url:      Optional[str]  = None
    redis_password: Optional[str]  = None
    redis_db:       Optional[int]  = None
    redis_ssl:      Optional[bool] = None
    key_prefix:     Optional[str]  = None
    task_ttl_hours: Optional[int]  = None


class _UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"


class CacheInvalidateSourceRequest(BaseModel):
    table_name:    Optional[str] = None   # registered table name (e.g. "orders")
    file_prefix:   Optional[str] = None   # S3/local prefix (e.g. "data/orders/")
    connection_id: Optional[int] = None   # invalidate all queries for a connection


class _SubjectExportRequest(BaseModel):
    username: str


# ── Helper functions ───────────────────────────────────────────────────────────

def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest: oldest = mt
                    if newest is None or mt > newest: newest = mt
                except OSError as exc:
                    logger.debug("Recoverable error: %s", exc, exc_info=True)
    return {
        "path":       str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb":    round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        _db_manager.audit(username, action, resource_type=resource_type,
                          resource_id=resource_id, ip_address=ip,
                          user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


def _oldest_age_secs(tasks: list) -> float:
    """Return age in seconds of oldest task by created_at."""
    oldest = None
    for t in tasks:
        ca = t.get("created_at")
        if not ca:
            continue
        try:
            dt = datetime.fromisoformat(ca)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if oldest is None or dt < oldest:
                oldest = dt
        except Exception:
            pass
    if oldest is None:
        return 0.0
    now = datetime.now(timezone.utc)
    return (now - oldest).total_seconds()


async def _scheduler_worker_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Proxy a request to the scheduler worker's internal HTTP API.

    Used when ``scheduler.mode = "external"`` — the scheduler runs in a
    separate process (``scheduler_worker.py``) and exposes a small FastAPI
    control API on ``scheduler.worker_host:scheduler.worker_port``.
    """
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")


def _update_config_users(username: str, password: Optional[str], role: Optional[str], action: str):
    """Persist user change to config.json and reload config in-memory.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    config_file = Path(__file__).resolve().parent.parent / "config.json"
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    auth_section = cfg.setdefault("auth", {})

    # Parse current local_users and user_roles
    raw_users = auth_section.get("local_users", "")
    users_dict = {}
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            users_dict[u.strip()] = p.strip()

    raw_roles = auth_section.get("user_roles", "")
    roles_dict = {}
    for pair in raw_roles.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, r = pair.split(":", 1)
            roles_dict[u.strip().lower()] = r.strip().lower()

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    auth_section["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
    auth_section["user_roles"]  = ",".join(f"{u}:{r}" for u, r in roles_dict.items())

    with open(config_file, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Reload in-memory config
    from core import config as _config_mod
    _config_mod.reload()
    logger.info("Config reloaded after user %s: %s", action, username)


# ── Storage management endpoints ───────────────────────────────────────────────

@router.get("/api/admin/storage")
async def get_storage_summary(_user: dict = Depends(require_admin)):
    """Return per-directory disk usage and configured retention settings."""
    import shutil as _shutil
    dirs = {
        "downloads": _paths.downloads_dir,
        "cache":     _paths.data_dir / "cache",
        "parquet":   _paths.parquet_dir,
        "uploads":   _paths.data_dir / "uploads",
    }
    breakdown = {name: _dir_stats(Path(p)) for name, p in dirs.items()}

    try:
        du = _shutil.disk_usage(str(_paths.data_dir))
        disk = {
            "total_gb": round(du.total / (1024 ** 3), 2),
            "used_gb":  round(du.used  / (1024 ** 3), 2),
            "free_gb":  round(du.free  / (1024 ** 3), 2),
            "used_pct": round(du.used  / du.total * 100, 1),
        }
    except Exception:
        disk = {}

    from core.config import storage as _stg_cfg, scheduler as _sched_cfg
    return {
        "disk": disk,
        "directories": breakdown,
        "settings": {
            "downloads_expiry_days":    _stg_cfg.downloads_expiry_days,
            "execution_retention_days": _sched_cfg.execution_retention_days,
            "max_cache_size_mb":        _stg_cfg.max_cache_size_mb,
            "max_downloads_size_mb":    _stg_cfg.max_downloads_size_mb,
        },
        "tracked_downloads": _db_manager.get_downloads_size_bytes() // (1024 * 1024),
    }


@router.post("/api/admin/storage/cleanup")
async def trigger_cleanup(_user: dict = Depends(require_admin)):
    """Manually trigger all cleanup jobs immediately (admin action)."""
    from core.scheduler import _cleanup_temp_files, _enforce_storage_quotas, _cleanup_execution_history
    results = {}
    for name, fn in [
        ("temp_files",        _cleanup_temp_files),
        ("storage_quotas",    _enforce_storage_quotas),
        ("execution_history", _cleanup_execution_history),
    ]:
        try:
            fn()
            results[name] = "ok"
        except Exception as exc:
            results[name] = str(exc)
    _audit(_user, "manual_storage_cleanup", None, details=results)
    logger.info("Manual storage cleanup triggered by %s: %s", (_user or {}).get("username", "guest"), results)
    return {"status": "completed", "results": results}


# ── Active queries / user stats ────────────────────────────────────────────────

@router.get("/api/admin/active-queries")
async def get_active_queries(_user: dict = Depends(require_admin)):
    """Return all currently running/pending executions with live duration and connection info.

    Source of truth is running_tasks (in-memory), not DB status — the DB record
    may still show 'pending' while the background task is already executing.
    """
    now = datetime.now(timezone.utc)

    # 1. Live execution IDs — from pool + legacy globals.
    try:
        from core.worker_pool import get_pool
        _pool_tasks = get_pool().get_active_tasks()
        live_ids = {t["execution_id"] for t in _pool_tasks if t.get("execution_id")}
    except RuntimeError:
        live_ids = set()
    # Also check legacy globals (for anything not yet migrated)
    live_ids |= (
        {eid for eid, task in running_tasks.items() if not task.done()} |
        set(cancellation_flags.keys())
    )

    # 2. DB rows for pending/processing (catches tasks not yet in running_tasks)
    db_rows: dict = {}
    for status in ("processing", "pending"):
        for r in _db_manager.list_executions(limit=500, status=status):
            db_rows[r["execution_id"]] = r

    # 3. Fetch DB records for any live task not already captured above
    for eid in live_ids:
        if eid not in db_rows:
            r = _db_manager.get_execution(eid)
            if r:
                db_rows[r["execution_id"]] = r
            else:
                # Task exists in memory but no DB record yet — synthesise a minimal row
                db_rows[eid] = {
                    "execution_id":     eid,
                    "status":           "processing",
                    "started_at":       now.isoformat(),
                    "executed_by":      None,
                    "chunks_processed": 0,
                    "query_config":     {},
                }

    conn_cache: dict = {}

    def _conn_name(cid):
        if cid is None:
            return None
        if cid not in conn_cache:
            try:
                c = _db_manager.get_connection_raw(cid)
                conn_cache[cid] = c.get("name", f"#{cid}") if c else f"#{cid}"
            except Exception:
                conn_cache[cid] = f"#{cid}"
        return conn_cache[cid]

    enriched = []
    for r in db_rows.values():
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                duration_s = int((now - dt).total_seconds())
            except Exception:
                duration_s = 0
        else:
            duration_s = 0

        qcfg    = r.get("query_config") or {}
        conn_id = qcfg.get("connection_id") or r.get("connection_id")

        enriched.append({
            **r,
            "duration_seconds": duration_s,
            "connection_name":  _conn_name(conn_id),
            "task_alive":       r["execution_id"] in live_ids,
        })

    enriched.sort(key=lambda x: x["duration_seconds"], reverse=True)
    return enriched


@router.get("/api/admin/user-stats")
async def get_user_stats(_user: dict = Depends(require_admin)):
    """Per-user query activity: active now, completed today, last seen."""
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    # All executions from today
    all_today = _db_manager.list_executions(limit=2000)
    user_map: dict = {}

    for r in all_today:
        u = r.get("executed_by") or "guest"
        if u not in user_map:
            user_map[u] = {"username": u, "queries_today": 0, "last_seen": None,
                           "active_now": 0, "failed_today": 0}
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt >= today_start:
                    user_map[u]["queries_today"] += 1
                    if r.get("status") == "failed":
                        user_map[u]["failed_today"] += 1
                if user_map[u]["last_seen"] is None or started > user_map[u]["last_seen"]:
                    user_map[u]["last_seen"] = started
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Overlay live active counts
    with user_query_lock:
        for uname, cnt in user_query_counts.items():
            if uname not in user_map:
                user_map[uname] = {"username": uname, "queries_today": 0, "last_seen": None,
                                   "active_now": cnt, "failed_today": 0}
            else:
                user_map[uname]["active_now"] = cnt

    return sorted(user_map.values(), key=lambda x: x["active_now"], reverse=True)


@router.get("/api/admin/query-eta")
async def get_query_eta(connection_id: Optional[int] = None,
                        _user: dict = Depends(get_current_user)):
    """Return estimated execution time (seconds) based on recent completed executions.
    Optionally scoped to a specific connection_id for a more accurate estimate.
    """
    try:
        recent = _db_manager.list_executions(limit=200, status="completed")
        durations = []
        for r in recent:
            s = r.get("started_at")
            c = r.get("completed_at")
            if not s or not c:
                continue
            # Filter by connection if requested
            if connection_id is not None:
                qcfg = r.get("query_config") or {}
                if isinstance(qcfg, str):
                    try:
                        qcfg = json.loads(qcfg)
                    except Exception:
                        qcfg = {}
                if not isinstance(qcfg, dict):
                    continue
                # Compare as int — stored value may be str or int
                try:
                    if int(qcfg.get("connection_id", -1)) != int(connection_id):
                        continue
                except (ValueError, TypeError):
                    continue
            try:
                dt_s = datetime.fromisoformat(s)
                dt_c = datetime.fromisoformat(c)
                if dt_s.tzinfo is None: dt_s = dt_s.replace(tzinfo=timezone.utc)
                if dt_c.tzinfo is None: dt_c = dt_c.replace(tzinfo=timezone.utc)
                secs = (dt_c - dt_s).total_seconds()
                if 0 < secs < 3600:  # ignore outliers > 1hr
                    durations.append(secs)
            except Exception:
                continue
        if not durations:
            return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}
        durations.sort()
        p75_idx = int(len(durations) * 0.75)
        avg = sum(durations) / len(durations)
        p75 = durations[min(p75_idx, len(durations) - 1)]
        return {
            "avg_seconds":  round(avg, 1),
            "p75_seconds":  round(p75, 1),
            "min_seconds":  round(min(durations), 1),
            "max_seconds":  round(max(durations), 1),
            "sample_count": len(durations),
            "connection_id": connection_id,
        }
    except Exception as exc:
        logger.error("query-eta failed: %s", exc, exc_info=True)
        return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}


@router.delete("/api/admin/queries/{execution_id}")
async def admin_cancel_execution(execution_id: str, _user: dict = Depends(require_admin)):
    """Admin-level cancel — no ownership check. Uses same cancel machinery."""
    try:
        execution = _db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution.get("status") not in ("pending", "processing"):
            return {"execution_id": execution_id,
                    "message": f"Already {execution.get('status')}"}

        from core.worker_pool import get_pool
        try:
            get_pool().cancel_by_execution_id(execution_id)
        except RuntimeError:
            cancel_event = cancellation_flags.get(execution_id)
            if cancel_event:
                cancel_event.set()
            task = running_tasks.get(execution_id)
            if task and not task.done():
                task.cancel()

        cancelled_by = (_user or {}).get("username", "admin")
        _db_manager.update_execution(execution_id, status="cancelled",
                                     error_message=f"Cancelled by admin: {cancelled_by}")
        await _ws_manager.broadcast({
            "type":         "execution_cancelled",
            "execution_id": execution_id,
            "cancelled_by": cancelled_by,
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
        _audit(_user, "admin_cancel_query", None, "execution", execution_id,
               {"cancelled_user": execution.get("executed_by")})
        return {"execution_id": execution_id, "message": "Cancelled by admin"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Worker Pool admin endpoints ────────────────────────────────────────────────

@router.get("/api/admin/worker-pool")
async def admin_worker_pool_stats(_user: dict = Depends(require_admin)):
    """Pool stats: by-type counts, queue depth, avg wait/run times."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_stats()
    except RuntimeError:
        return {"error": "Worker pool not initialised"}


@router.get("/api/admin/worker-pool/tasks")
async def admin_worker_pool_tasks(
    work_type: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """All active tasks, optionally filtered by work type."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_active_tasks(wt)


@router.get("/api/admin/worker-pool/history")
async def admin_worker_pool_history(
    limit: int = 100,
    work_type: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Recent completed/failed/cancelled tasks (newest first)."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_task_history(limit=min(limit, 500), work_type=wt)


@router.post("/api/admin/worker-pool/tasks/{task_id}/cancel")
async def admin_worker_pool_cancel(task_id: str, _user: dict = Depends(require_admin)):
    """Cancel any task by its internal task_id."""
    from core.worker_pool import get_pool
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")
    if not pool.cancel(task_id):
        raise HTTPException(status_code=404, detail="Task not found or already completed")
    cancelled_by = (_user or {}).get("username", "admin")
    _db_manager.audit(cancelled_by, "cancel_pool_task", resource_type="task", resource_id=task_id)
    return {"task_id": task_id, "message": "Cancelled"}


@router.get("/api/admin/worker-pool/config")
async def admin_worker_pool_config(_user: dict = Depends(require_admin)):
    """Return current worker pool configuration."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_config()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")


@router.put("/api/admin/worker-pool/config")
async def admin_worker_pool_reconfigure(req: WorkerPoolConfigUpdate, _user: dict = Depends(require_admin)):
    """Hot-reconfigure worker pool limits. Running tasks are NOT affected."""
    from core.worker_pool import get_pool, WorkType, TypeConfig
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")

    current = pool.get_config()["types"]
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes", "changes": {}}

    # Build new TypeConfig for each type that has changes
    _TYPE_MAP = {
        "interactive": WorkType.INTERACTIVE, "report": WorkType.REPORT,
        "scheduled":   WorkType.SCHEDULED,   "export": WorkType.EXPORT,
        "system":      WorkType.SYSTEM,
    }
    new_cfgs: dict = {}
    for prefix, wt in _TYPE_MAP.items():
        cur = current[wt.name]
        mc = updates.get(f"{prefix}_max_concurrent",  cur["max_concurrent"])
        dt = updates.get(f"{prefix}_default_timeout", cur["default_timeout"])
        mq = updates.get(f"{prefix}_max_queue",       cur["max_queue"])
        if mc != cur["max_concurrent"] or dt != cur["default_timeout"] or mq != cur["max_queue"]:
            if mc < 1:
                raise HTTPException(400, f"{prefix}_max_concurrent must be >= 1")
            if dt < 10:
                raise HTTPException(400, f"{prefix}_default_timeout must be >= 10")
            if mq < 1:
                raise HTTPException(400, f"{prefix}_max_queue must be >= 1")
            new_cfgs[wt] = TypeConfig(mc, dt, mq)

    changes = pool.reconfigure(new_cfgs)

    # Persist to config.json so changes survive restart
    try:
        from core import config as _cfg
        cfg_path = _cfg._CONFIG_FILE
        existing = {}
        if cfg_path.exists():
            with open(cfg_path, "r") as f:
                existing = json.load(f)
        wp = existing.setdefault("worker_pool", {})
        for k, v in updates.items():
            wp[k] = v
        with open(cfg_path, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception as e:
        logger.warning("Could not persist worker pool config: %s", e)

    changed_by = (_user or {}).get("username", "admin")
    _db_manager.audit(changed_by, "reconfigure_worker_pool", resource_type="worker_pool",
                      details={"changes": changes, "updates": updates})
    return {"message": "Reconfigured", "changes": changes}


# ── Application Configuration ──────────────────────────────────────────────────

@router.get("/api/admin/app-config")
async def admin_get_app_config(_user: dict = Depends(require_admin)):
    """Return current application limits and feature toggle configuration."""
    from core.config import limits as _limits_cfg, features as _features_cfg, s3_results as _s3r_cfg
    return {
        "limits": {
            "max_stream_files":           _limits_cfg.max_stream_files,
            "stream_query_limit_default": _limits_cfg.stream_query_limit_default,
            "stream_query_limit_max":     _limits_cfg.stream_query_limit_max,
            "stream_page_size_default":   _limits_cfg.stream_page_size_default,
            "stream_page_size_max":       _limits_cfg.stream_page_size_max,
            "stream_chart_top_n":         _limits_cfg.stream_chart_top_n,
            "stream_chart_max_series":    _limits_cfg.stream_chart_max_series,
            "max_upload_size_mb":         _limits_cfg.max_upload_size_bytes // (1024 * 1024),
            "max_display_cols":           _limits_cfg.max_display_cols,
            "col_auto_project":           _limits_cfg.col_auto_project,
            "default_query_limit":        _limits_cfg.default_query_limit,
            "streaming_default_on":       _limits_cfg.streaming_default_on,
            "stream_bg_download_default": _limits_cfg.stream_bg_download_default,
            # Query engine settings (from query_engine config section)
            "duckdb_threads_per_query":   _qe_cfg.duckdb_threads_per_query,
            "duckdb_memory_limit_mb":     _qe_cfg.duckdb_memory_limit_mb,
            "query_timeout_seconds":      _qe_cfg.query_timeout_seconds,
            "max_concurrent_per_user":    _qe_cfg.max_concurrent_per_user,
            "max_concurrent_global":      _qe_cfg.max_concurrent_global,
        },
        "features": {
            "streaming_mode":             _features_cfg.streaming_mode,
            "streaming_enabled_roles":    ",".join(_features_cfg.streaming_enabled_roles),
            "export_enabled_roles":       ",".join(_features_cfg.export_enabled_roles),
            "sql_editor_enabled_roles":   ",".join(_features_cfg.sql_editor_enabled_roles),
            "scheduler_enabled_roles":    ",".join(_features_cfg.scheduler_enabled_roles),
            "connections_enabled_roles":  ",".join(_features_cfg.connections_enabled_roles),
            "upload_enabled_roles":       ",".join(_features_cfg.upload_enabled_roles),
            "max_query_limit_by_role":    ",".join(f"{r}:{v}" for r, v in _features_cfg.max_query_limit_by_role.items()),
        },
        "s3_results": {
            "enabled":                    _s3r_cfg.enabled,
            "storage_mode":               _s3r_cfg.storage_mode,
            "size_threshold_mb":          _s3r_cfg.size_threshold_mb,
            "prefix":                     _s3r_cfg.prefix,
            "delete_local_after_upload":  _s3r_cfg.delete_local_after_upload,
            "bucket_override":            _s3r_cfg.bucket_override,
        },
    }


@router.put("/api/admin/app-config")
async def admin_update_app_config(request: AppConfigUpdateRequest,
                                  _user: dict = Depends(require_admin)):
    """Hot-reconfigure application limits and feature toggles."""
    from core import config as _config_mod

    # Keys that belong to query_engine config section (not limits)
    _QE_KEYS = {"duckdb_threads_per_query", "duckdb_memory_limit_mb",
                "query_timeout_seconds", "max_concurrent_per_user", "max_concurrent_global"}

    updates = {}
    if request.limits:
        # Split: route query_engine keys to their own section
        qe_vals  = {k: v for k, v in request.limits.items() if k in _QE_KEYS}
        lim_vals = {k: v for k, v in request.limits.items() if k not in _QE_KEYS}
        if lim_vals:
            updates["limits"] = lim_vals
        if qe_vals:
            updates["query_engine"] = qe_vals
    if request.features:
        updates["features"] = request.features
    if request.s3_results:
        updates["s3_results"] = request.s3_results
    if not updates:
        return {"message": "No changes"}

    # Persist to config.json
    cfg_path = _config_mod._CONFIG_FILE
    existing = {}
    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = {}
    for section, values in updates.items():
        sec = existing.setdefault(section, {})
        for k, v in values.items():
            sec[k] = v
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Hot-reload in-memory config
    _config_mod.reload()

    changed_by = (_user or {}).get("username", "admin")
    _db_manager.audit(changed_by, "update_app_config", resource_type="app_config",
                      details={"updates": updates})
    return {"message": "Configuration updated", "updates": updates}


# ── Queue Backend Configuration ────────────────────────────────────────────────

@router.get("/api/admin/queue-config")
async def admin_get_queue_config(_user: dict = Depends(require_admin)):
    """Return queue backend configuration and live status."""
    from core.config import queue as _queue_cfg
    from core.queue_backend import get_queue_status
    status = get_queue_status()
    return {
        "config": {
            "backend":        _queue_cfg.backend,
            "redis_url":      _queue_cfg.redis_url,
            "redis_password": "***" if _queue_cfg.redis_password else "",
            "redis_db":       _queue_cfg.redis_db,
            "redis_ssl":      _queue_cfg.redis_ssl,
            "key_prefix":     _queue_cfg.key_prefix,
            "task_ttl_hours": _queue_cfg.task_ttl_hours,
        },
        "status": status,
    }


@router.put("/api/admin/queue-config")
async def admin_update_queue_config(request: QueueConfigUpdateRequest,
                                    _user: dict = Depends(require_admin)):
    """Update queue backend config. Requires restart to take effect."""
    from core import config as _config_mod

    updates = {}
    if request.backend is not None:
        if request.backend not in ("sqlite", "redis"):
            raise HTTPException(400, "backend must be 'sqlite' or 'redis'")
        updates["backend"] = request.backend
    if request.redis_url is not None:
        updates["redis_url"] = request.redis_url
    if request.redis_password is not None:
        updates["redis_password"] = request.redis_password
    if request.redis_db is not None:
        updates["redis_db"] = request.redis_db
    if request.redis_ssl is not None:
        updates["redis_ssl"] = request.redis_ssl
    if request.key_prefix is not None:
        updates["key_prefix"] = request.key_prefix
    if request.task_ttl_hours is not None:
        updates["task_ttl_hours"] = request.task_ttl_hours

    if not updates:
        return {"message": "No changes"}

    # Persist to config.json
    cfg_path = _config_mod._CONFIG_FILE
    existing = {}
    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = {}
    queue_sec = existing.setdefault("queue", {})
    for k, v in updates.items():
        queue_sec[k] = v
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Hot-reload config (note: queue backend switch requires process restart)
    _config_mod.reload()

    changed_by = (_user or {}).get("username", "admin")
    _db_manager.audit(changed_by, "update_queue_config", resource_type="queue_config",
                      details={"updates": {k: v for k, v in updates.items() if k != "redis_password"}})
    return {
        "message": "Queue configuration updated. Restart required for backend switch to take effect.",
        "updates": {k: v for k, v in updates.items() if k != "redis_password"},
        "restart_required": "backend" in updates,
    }


@router.post("/api/admin/queue-config/test-redis")
async def admin_test_redis(_user: dict = Depends(require_admin)):
    """Test Redis connectivity using current config."""
    from core.config import queue as _queue_cfg
    if _queue_cfg.backend != "redis" and not _queue_cfg.redis_url:
        return {"connected": False, "error": "No Redis URL configured"}
    try:
        import redis
        r = redis.from_url(
            _queue_cfg.redis_url,
            password=_queue_cfg.redis_password or None,
            db=_queue_cfg.redis_db,
            ssl=_queue_cfg.redis_ssl,
            socket_connect_timeout=5,
        )
        try:
            info = r.info("server")
            return {
                "connected":        True,
                "redis_version":    info.get("redis_version", "?"),
                "uptime_seconds":   info.get("uptime_in_seconds", 0),
                "used_memory_human": info.get("used_memory_human", "?"),
            }
        finally:
            r.close()
    except ImportError:
        return {"connected": False, "error": "redis package not installed (pip install redis)"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}


@router.get("/api/admin/queue/depths")
async def admin_queue_depths(_user: dict = Depends(require_admin)):
    """Return queue depth counts by status and task type."""
    from core.queue_backend import get_task_queue, get_queue_status
    tq = get_task_queue()
    status_info = get_queue_status()

    pending  = tq.list_tasks(status="pending",    limit=1000)
    active   = tq.list_tasks(status="processing", limit=1000)
    done     = tq.list_tasks(status="completed",  limit=200)
    failed   = tq.list_tasks(status="failed",     limit=200)

    def _by_type(tasks):
        counts = {}
        for t in tasks:
            tt = t.get("task_type", "unknown")
            counts[tt] = counts.get(tt, 0) + 1
        return counts

    # Priority breakdown for pending tasks
    priority_buckets = {"high": 0, "normal": 0, "low": 0}
    for t in pending:
        p = t.get("priority", 5)
        if p <= 2:
            priority_buckets["high"] += 1
        elif p <= 6:
            priority_buckets["normal"] += 1
        else:
            priority_buckets["low"] += 1

    return {
        "backend": status_info.get("backend", "sqlite"),
        "totals": {
            "pending":    len(pending),
            "processing": len(active),
            "completed":  len(done),
            "failed":     len(failed),
        },
        "by_type": {
            "pending":    _by_type(pending),
            "processing": _by_type(active),
        },
        "priority_breakdown": priority_buckets,
        "oldest_pending_age_secs": (
            _oldest_age_secs(pending) if pending else 0
        ),
    }


# ── Dead-Letter Queue Admin ────────────────────────────────────────────────────

@router.get("/api/admin/queue/dead-letter")
async def admin_list_dead_letter(
    resolved: Optional[bool] = None,
    limit: int = Query(default=100, ge=1, le=1000),
    _user: dict = Depends(require_admin),
):
    """List dead-letter queue entries (permanently failed tasks)."""
    entries = _db_manager.list_dead_letter(resolved=resolved, limit=limit)
    return {"entries": entries, "count": len(entries)}


@router.post("/api/admin/queue/dead-letter/{task_id}/resolve")
async def admin_resolve_dead_letter(
    task_id: str,
    _user: dict = Depends(require_admin),
):
    """Mark a DLQ entry as resolved (acknowledged, no retry)."""
    ok = _db_manager.resolve_dead_letter(task_id, resolved_by=_user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="DLQ entry not found")
    return {"resolved": True, "task_id": task_id}


@router.post("/api/admin/queue/dead-letter/{task_id}/requeue")
async def admin_requeue_dead_letter(
    task_id: str,
    _user: dict = Depends(require_admin),
):
    """Requeue a DLQ entry for another attempt and mark it resolved."""
    entries = _db_manager.list_dead_letter(resolved=False, limit=1000)
    entry = next((e for e in entries if e["task_id"] == task_id), None)
    if not entry:
        raise HTTPException(status_code=404, detail="DLQ entry not found or already resolved")

    from core.queue_backend import get_task_queue
    tq = get_task_queue()
    new_task_id = str(uuid.uuid4())
    tq.enqueue_task(
        task_id=new_task_id,
        task_type=entry.get("task_type", "parquet_query"),
        payload=entry.get("payload") or {},
        execution_id=entry.get("execution_id"),
        created_by=_user["username"],
        priority=5,
        retry_count=0,
        max_retries=3,
    )
    _db_manager.resolve_dead_letter(task_id, resolved_by=_user["username"])
    return {"requeued": True, "task_id": task_id, "new_task_id": new_task_id}


# ── Batch Submit API ───────────────────────────────────────────────────────────

class _BatchQueryItem(BaseModel):
    query_id:       Optional[int]  = None
    raw_sql:        Optional[str]  = None
    connection_id:  Optional[int]  = None
    output_format:  str            = Field(default="csv", pattern="^(csv|json)$")
    cache_strategy: str            = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    callback_url:   Optional[str]  = None
    priority:       int            = Field(default=5, ge=0, le=9)
    label:          Optional[str]  = None   # caller-defined label for tracking


class _BatchSubmitRequest(BaseModel):
    queries: List[_BatchQueryItem] = Field(..., min_length=1, max_length=50)


@router.post("/api/jobs/submit-batch", status_code=202)
async def submit_batch_queries(
    request: _BatchSubmitRequest,
    _user: dict = Depends(require_execute_access),
):
    """Enqueue multiple queries atomically. Returns list of execution_ids.
    Requires executor.mode = 'external'. Max 50 queries per batch."""
    from core.config import executor as _exec_cfg
    if _exec_cfg.mode != "external":
        raise HTTPException(
            400,
            "Batch submit requires executor.mode = 'external'. "
            "Use POST /api/execute individually in embedded mode."
        )
    from core.queue_backend import get_task_queue

    _username = (_user or {}).get("username", "guest")
    results = []

    for i, item in enumerate(request.queries):
        # Resolve query config
        if item.query_id:
            saved = _db_manager.get_query(item.query_id)
            if not saved:
                results.append({"index": i, "label": item.label, "error": f"query_id {item.query_id} not found"})
                continue
            qc_dict = saved["query_config"]
        elif item.raw_sql:
            qc_dict = {"files": [], "raw_sql": item.raw_sql}
        else:
            results.append({"index": i, "label": item.label, "error": "query_id or raw_sql required"})
            continue

        execution_id = str(uuid.uuid4())
        task_id      = str(uuid.uuid4())
        try:
            _db_manager.create_execution(
                execution_id=execution_id,
                query_id=item.query_id,
                query_config=qc_dict,
                executed_by=_username,
            )
            get_task_queue().enqueue_task(
                task_id=task_id,
                task_type="parquet_query",
                payload={
                    "execution_id": execution_id,
                    "query_config": qc_dict,
                    "connection_id": item.connection_id,
                    "executed_by": _username,
                    "raw_sql": item.raw_sql,
                    "cache_strategy": item.cache_strategy,
                    "callback_url": item.callback_url or "",
                },
                execution_id=execution_id,
                created_by=_username,
                priority=item.priority,
            )
            results.append({
                "index":        i,
                "label":        item.label,
                "execution_id": execution_id,
                "task_id":      task_id,
                "status":       "queued",
            })
        except Exception as exc:
            results.append({"index": i, "label": item.label, "error": str(exc)})

    queued = sum(1 for r in results if r.get("status") == "queued")
    failed = len(results) - queued
    return {
        "submitted": len(request.queries),
        "queued":    queued,
        "errors":    failed,
        "results":   results,
    }


# ── App Settings (role-resolved, for frontend) ─────────────────────────────────

@router.get("/api/app-settings")
async def get_app_settings(_user: dict = Depends(get_current_user)):
    """Return role-resolved application settings for the frontend."""
    from core.config import limits as _limits_cfg, features as _features_cfg
    role = (_user or {}).get("role", "viewer")
    role_limit = _features_cfg.max_query_limit_by_role.get(role, 0)
    return {
        "limits": {
            "col_auto_project":           _limits_cfg.col_auto_project,
            "default_query_limit":        _limits_cfg.default_query_limit,
            "streaming_default_on":       _limits_cfg.streaming_default_on,
            "stream_bg_download_default": _limits_cfg.stream_bg_download_default,
            "max_display_cols":           _limits_cfg.max_display_cols,
            "stream_query_limit_max":     _limits_cfg.stream_query_limit_max,
            "max_stream_files":           _limits_cfg.max_stream_files,
        },
        "features": {
            "streaming_mode":      _features_cfg.streaming_mode,
            "streaming_enabled":   role in _features_cfg.streaming_enabled_roles,
            "export_enabled":      role in _features_cfg.export_enabled_roles,
            "sql_editor_enabled":  role in _features_cfg.sql_editor_enabled_roles,
            "scheduler_enabled":   role in _features_cfg.scheduler_enabled_roles,
            "connections_enabled": role in _features_cfg.connections_enabled_roles,
            "upload_enabled":      role in _features_cfg.upload_enabled_roles,
            "max_query_limit":     role_limit,
        },
        "role": role,
        "component_visibility": (
            _db_manager.get_ui_visibility_for_role(role) if _db_manager else {}
        ),
        "active_connection_profile": (
            lambda p: {"id": p["id"], "name": p["name"]} if p else None
        )(_db_manager.get_active_profile() if _db_manager else None),
        "workspaces": (
            _db_manager.list_workspaces(
                username=(_user or {}).get("username") if _auth_cfg and _auth_cfg.type != "none" else None
            ) if _db_manager else []
        ),
    }


# ── Scheduler admin endpoints ──────────────────────────────────────────────────

@router.get("/api/admin/scheduler")
async def admin_scheduler_status(_user: dict = Depends(require_admin)):
    """Return scheduler state: running, paused, job list."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        return await _scheduler_worker_proxy("GET", "/control/status")
    from core.scheduler import get_scheduler_status
    return get_scheduler_status()


@router.post("/api/admin/scheduler/pause")
async def admin_scheduler_pause(_user: dict = Depends(require_admin)):
    """Pause all scheduled jobs. Running jobs finish normally."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        result = await _scheduler_worker_proxy("POST", "/control/pause")
    else:
        from core.scheduler import pause_scheduler
        ok = pause_scheduler()
        if not ok:
            raise HTTPException(status_code=400, detail="Scheduler not running")
        result = {"message": "Scheduler paused — no new jobs will fire"}
    username = (_user or {}).get("username", "admin")
    _db_manager.audit(username, "pause_scheduler", resource_type="scheduler")
    return result


@router.post("/api/admin/scheduler/resume")
async def admin_scheduler_resume(_user: dict = Depends(require_admin)):
    """Resume all scheduled jobs."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        result = await _scheduler_worker_proxy("POST", "/control/resume")
    else:
        from core.scheduler import resume_scheduler
        ok = resume_scheduler()
        if not ok:
            raise HTTPException(status_code=400, detail="Scheduler not initialized")
        result = {"message": "Scheduler resumed"}
    username = (_user or {}).get("username", "admin")
    _db_manager.audit(username, "resume_scheduler", resource_type="scheduler")
    return result


# ── Audit log endpoints ────────────────────────────────────────────────────────

@router.get("/api/admin/audit-log")
async def get_audit_log(
    username:      Optional[str] = None,
    action:        Optional[str] = None,
    resource_type: Optional[str] = None,
    date_from:     Optional[str] = None,
    date_to:       Optional[str] = None,
    limit:         int = 200,
    offset:        int = 0,
    _user: dict = Depends(require_admin),
):
    """Return audit log entries (admin only). Filterable by username, action, resource_type, dates."""
    return _db_manager.get_audit_log_filtered(
        username=username, action=action, resource_type=resource_type,
        date_from=date_from, date_to=date_to,
        limit=min(limit, 1000), offset=offset,
    )


@router.get("/api/admin/audit-log/export")
async def export_audit_log(
    username:      Optional[str] = None,
    action:        Optional[str] = None,
    resource_type: Optional[str] = None,
    date_from:     Optional[str] = None,
    date_to:       Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Stream the filtered audit log as a CSV file (admin only)."""
    import csv
    import io
    rows = _db_manager.get_audit_log_filtered(
        username=username, action=action, resource_type=resource_type,
        date_from=date_from, date_to=date_to, limit=100000, offset=0,
    )
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=["id", "timestamp", "username", "action",
                                              "resource_type", "resource_id",
                                              "ip_address", "details"])
    writer.writeheader()
    for r in rows:
        writer.writerow({k: r.get(k, "") for k in writer.fieldnames})
    content = buf.getvalue()
    return _Resp(
        content=content,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=audit_log.csv"},
    )


@router.get("/api/admin/audit-log/data-access-summary")
async def get_data_access_summary(_user: dict = Depends(require_admin)):
    """Return per-user aggregate data access statistics (admin only)."""
    return {"summary": _db_manager.get_data_access_summary()}


@router.post("/api/admin/compliance/subject-export")
async def generate_subject_export(req: _SubjectExportRequest, _user: dict = Depends(require_admin)):
    """GDPR: generate a ZIP export of all data for a given user (admin only)."""
    import csv
    import io
    import zipfile
    data = _db_manager.get_user_data_export(req.username)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # audit_log.csv
        audit_buf = io.StringIO()
        if data["audit_log"]:
            fields = list(data["audit_log"][0].keys())
            w = csv.DictWriter(audit_buf, fieldnames=fields)
            w.writeheader()
            for r in data["audit_log"]:
                w.writerow({k: r.get(k, "") for k in fields})
        zf.writestr("audit_log.csv", audit_buf.getvalue())
        # JSON files
        import json as _json
        zf.writestr("saved_queries.json", _json.dumps(data["saved_queries"],  indent=2, default=str))
        zf.writestr("sql_queries.json",   _json.dumps(data["sql_queries"],    indent=2, default=str))
        zf.writestr("executions.json",    _json.dumps(data["executions"],     indent=2, default=str))
        zf.writestr("downloads.json",     _json.dumps(data["downloads"],      indent=2, default=str))
        zf.writestr("schedules.json",     _json.dumps(data["schedules"],      indent=2, default=str))

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=subject_export_{req.username}.zip"},
    )


# ── User management endpoints ──────────────────────────────────────────────────

@router.get("/api/admin/users")
async def list_users(_user: dict = Depends(require_admin)):
    """List all configured users (local or AD auth)."""
    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        user_roles  = _auth_cfg.user_roles
        return [
            {"username": u, "role": user_roles.get(u.lower(), "viewer")}
            for u in local_users
        ]
    if _auth_cfg.type == "ad":
        # AD mode: return users from the role mapping
        user_roles = _auth_cfg.user_roles
        return [
            {"username": u, "role": r}
            for u, r in user_roles.items()
        ]
    return {"auth_type": _auth_cfg.type, "message": "User management not available when auth is disabled"}


@router.get("/api/admin/users/lookup/{username}")
async def lookup_user_ad(username: str, _user: dict = Depends(require_admin)):
    """Look up a user in Active Directory by Windows ID (sAMAccountName)."""
    if _auth_cfg.type != "ad":
        raise HTTPException(400, "AD lookup only available when auth.type = 'ad'")
    from core.ad_auth import lookup_ad_user
    result = lookup_ad_user(username)
    if not result:
        raise HTTPException(404, f"User '{username}' not found in Active Directory")
    return result


@router.post("/api/admin/users", status_code=201)
async def add_user(req: _UserPayload, _user: dict = Depends(require_admin)):
    """Add a new user (local: with password, AD: role mapping only)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if req.role not in ("admin", "analyst", "viewer"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        if not req.password:
            raise HTTPException(400, "Password is required for local users")
        local_users = _auth_cfg.local_users
        if req.username in local_users:
            raise HTTPException(409, f"User '{req.username}' already exists")
        _update_config_users(req.username, req.password, req.role, action="add")
    else:
        # AD mode: just save the role mapping (no password needed)
        user_roles = _auth_cfg.user_roles
        if req.username.lower() in user_roles:
            raise HTTPException(409, f"User '{req.username}' already exists")
        _update_config_users(req.username, None, req.role, action="add_role")

    return {"username": req.username, "role": req.role}


@router.put("/api/admin/users/{username}")
async def update_user(username: str, req: _UserPayload, _user: dict = Depends(require_admin)):
    """Update a user's role (and optionally password for local auth)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if req.role not in ("admin", "analyst", "viewer"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        _update_config_users(username, req.password, req.role, action="update")
    else:
        # AD mode: update role mapping only
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        _update_config_users(username, None, req.role, action="update_role")

    return {"username": username, "role": req.role}


@router.delete("/api/admin/users/{username}")
async def remove_user(username: str, req: Request, _user: dict = Depends(require_admin)):
    """Remove a user (local: delete entirely, AD: remove role mapping)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if username.lower() == (_user or {}).get("username", "").lower():
        raise HTTPException(400, "Cannot delete your own account")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        _update_config_users(username, None, None, action="remove")
    else:
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        _update_config_users(username, None, None, action="remove_role")

    _audit(_user, "remove_user", req, "user", 0, {"username": username})
    return {"message": f"User '{username}' removed"}


# ── Cache management endpoints ─────────────────────────────────────────────────

@router.get("/api/cache/stats")
async def get_cache_stats(_user: dict = Depends(get_current_user)):
    from core.query_cache import get_stats
    return get_stats()


@router.delete("/api/cache")
async def clear_cache(_user: dict = Depends(require_admin)):
    from core.query_cache import cleanup_expired
    count = cleanup_expired()
    return {"message": f"Removed {count} expired cache entries"}


@router.post("/api/cache/invalidate-source")
async def invalidate_cache_by_source(
    body: CacheInvalidateSourceRequest,
    _user: dict = Depends(require_execute_access),
):
    """Invalidate cache entries that reference a changed data source.

    Intended to be called by an external consumer (e.g. Kafka -> Oracle pipeline)
    when new data is ingested.  Matching entries are evicted; the next query
    execution will fetch fresh data from S3 and repopulate the cache automatically.

    Provide at least one of: table_name, file_prefix, connection_id.
    """
    if not any([body.table_name, body.file_prefix, body.connection_id is not None]):
        raise HTTPException(status_code=400,
                            detail="Provide at least one of: table_name, file_prefix, connection_id")
    from core.query_cache import invalidate_by_source
    evicted = invalidate_by_source(
        table_name=body.table_name,
        file_prefix=body.file_prefix,
        connection_id=body.connection_id,
    )
    logger.info("[cache/invalidate-source] %d entries evicted by %s (table=%s prefix=%s conn=%s)",
                evicted, _user.get("username", "?"), body.table_name, body.file_prefix, body.connection_id)
    return {"evicted": evicted, "message": f"Invalidated {evicted} cache entries"}


@router.get("/api/admin/cache/entries")
async def list_cache_entries(
    limit: int = 100,
    offset: int = 0,
    _user: dict = Depends(require_admin),
):
    """List all query result cache entries with pagination."""
    entries = _db_manager.list_cache_entries() if _db_manager else []
    return {"entries": entries[offset:offset + limit], "total": len(entries)}


@router.delete("/api/admin/cache/clear")
async def clear_all_cache(_user: dict = Depends(require_admin)):
    """Clear all query result cache entries (expired and non-expired)."""
    from core.query_cache import cleanup_expired, invalidate
    # First remove expired entries
    count = cleanup_expired()
    # Then remove all remaining (non-expired) entries
    entries = _db_manager.list_cache_entries() if _db_manager else []
    for entry in entries:
        invalidate(entry["cache_key"])
    return {"cleared": len(entries) + count}


# ── Iceberg File Cache ─────────────────────────────────────────────────────────

@router.get("/api/admin/iceberg-cache/stats")
async def iceberg_cache_stats(_user: dict = Depends(require_admin)):
    """Get Iceberg file cache statistics (L1 in-memory + L2 persistent)."""
    import time as _t
    from main import _ICE_FILE_CACHE, _ICE_FILE_CACHE_TTL
    now = _t.monotonic()
    l1_entries = len(_ICE_FILE_CACHE)
    l1_active = sum(1 for v in _ICE_FILE_CACHE.values() if now - v["ts"] < _ICE_FILE_CACHE_TTL)
    # L2 stats from DB
    l2_entries = 0
    try:
        all_l2 = _db_manager.list_iceberg_file_cache() if hasattr(_db_manager, "list_iceberg_file_cache") else []
        l2_entries = len(all_l2)
    except Exception:
        pass
    return {"l1_total": l1_entries, "l1_active": l1_active, "l2_total": l2_entries}


@router.delete("/api/admin/iceberg-cache/clear")
async def clear_iceberg_cache(
    connection_id: int = None, table_name: str = None,
    _user: dict = Depends(require_admin),
):
    """Clear Iceberg file cache. Optional connection_id/table_name filters."""
    from main import _ICE_FILE_CACHE
    l1_cleared = 0
    l2_cleared = 0
    if connection_id or table_name:
        # Selective clear
        keys_to_remove = []
        for k in list(_ICE_FILE_CACHE.keys()):
            cid, tname, _ = k
            if connection_id and cid != connection_id:
                continue
            if table_name and tname != table_name:
                continue
            keys_to_remove.append(k)
        for k in keys_to_remove:
            _ICE_FILE_CACHE.pop(k, None)
            l1_cleared += 1
        try:
            _db_manager.delete_iceberg_file_cache(
                connection_id=connection_id, table_name=table_name)
            l2_cleared = -1  # unknown exact count
        except Exception:
            pass
    else:
        l1_cleared = len(_ICE_FILE_CACHE)
        _ICE_FILE_CACHE.clear()
        try:
            _db_manager.delete_iceberg_file_cache()
            l2_cleared = -1
        except Exception:
            pass
    return {"l1_cleared": l1_cleared, "l2_cleared": "all" if l2_cleared == -1 else l2_cleared}


# ── Webhooks ───────────────────────────────────────────────────────────────────

@router.post("/api/webhooks/test")
async def test_webhook_url(body: dict, _user: dict = Depends(get_current_user)):
    """Test a webhook URL by sending a sample notification."""
    url = body.get("url", "")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    from core.webhook_service import test_webhook
    return test_webhook(url)


# ── Exports listing ────────────────────────────────────────────────────────────

@router.get("/api/exports")
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').
    """
    try:
        all_files = _db_manager.list_download_files(status=status, limit=limit * 3, offset=0)
        # Exclude internal auto-generated results
        exports = [f for f in all_files if f.get("created_by") != "internal"]
        return exports[:limit]
    except Exception as e:
        logger.error(f"Error listing exports: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Circuit Breaker endpoints ────────────────────────────────────────────────

@router.get("/api/admin/circuit-breakers")
async def list_circuit_breakers(_user: dict = Depends(require_admin)):
    """List circuit breaker states for all connections."""
    from core.circuit_breaker import get_circuit_states
    return {"circuit_breakers": get_circuit_states()}


@router.get("/api/admin/circuit-breakers/{connection_id}")
async def get_circuit_breaker(connection_id: int, _user: dict = Depends(require_admin)):
    """Get circuit breaker state for a specific connection."""
    from core.circuit_breaker import get_circuit_state
    state = get_circuit_state(connection_id)
    if not state:
        raise HTTPException(status_code=404, detail="No circuit breaker for this connection")
    return state


@router.post("/api/admin/circuit-breakers/{connection_id}/reset")
async def reset_circuit_breaker(connection_id: int, _user: dict = Depends(require_admin)):
    """Manually reset circuit breaker for a connection (force CLOSED)."""
    from core.circuit_breaker import reset_circuit
    result = reset_circuit(connection_id)
    if not result:
        raise HTTPException(status_code=404, detail="No circuit breaker for this connection")
    return result


# -- Anomaly Detection endpoints (Phase 38) ------------------------------------

@router.get("/api/admin/anomalies")
async def list_anomalies(
    schedule_id: int = None,
    limit: int = 50,
    _user: dict = Depends(require_admin),
):
    """List recent anomaly detections across all scheduled reports."""
    return {"anomalies": _db_manager.list_anomalies(schedule_id=schedule_id, limit=limit)}


# -- Connection Pool endpoints (Phase 40) --------------------------------------

@router.get("/api/admin/connection-pools")
async def get_connection_pool_stats(
    _user: dict = Depends(require_admin),
):
    """Return connection pool statistics."""
    from core.connection_pool import get_pool_stats
    return {"pools": get_pool_stats()}


# ── UI Component Visibility (admin control per role) ────────────────────────────

KNOWN_COMPONENTS = [
    # key, display label, group
    ("query_builder",       "Query Builder",         "Data"),
    ("sql_editor",          "SQL Editor",            "Data"),
    ("saved_queries",       "Saved Queries",         "Data"),
    ("dashboards",          "Dashboards",            "Analytics"),
    ("reports",             "Reports",               "Analytics"),
    ("report_catalog",      "Report Catalog",        "Analytics"),
    ("report_connectors",   "Report Connectors",     "Analytics"),
    ("parametric_reports",  "Parametric Reports",    "Analytics"),
    ("schedules",           "Schedules",             "Automation"),
    ("executions",          "Executions",            "Automation"),
    ("downloads",           "Downloads",             "Automation"),
    ("connections",         "Connections",           "Admin"),
    ("materialized_views",  "Materialized Views",    "Admin"),
    ("local_tables",        "Local Tables",          "Admin"),
    ("lineage",             "Data Lineage",          "Admin"),
    ("lineage_history",     "Lineage History",       "Admin"),
    ("data_freshness",      "Data Freshness",        "Admin"),
    ("semantic_layer",      "Semantic Layer",        "Admin"),
    ("federation",          "Federation Engine",     "Admin"),
    ("agg_cache",           "Aggregation Cache",     "Admin"),
    ("aws_portal",          "AWS Portal Auth",       "Admin"),
    ("business_reports",    "Business Reports",      "Analytics"),
    ("chatbot",             "NL Chatbot",            "Analytics"),
    ("admin",               "Admin Panel",           "Admin"),
]

KNOWN_ROLES = ["admin", "analyst", "viewer"]


@router.get("/api/admin/ui-visibility")
async def get_ui_visibility(_user: dict = Depends(require_admin)):
    """
    Return the full component-visibility matrix.
    Rows not in DB default to enabled=True.
    """
    stored = {(r["component_key"], r["role"]): r["enabled"]
              for r in _db_manager.get_ui_visibility()}
    result = []
    for key, label, group in KNOWN_COMPONENTS:
        for role in KNOWN_ROLES:
            result.append({
                "component_key": key,
                "label":         label,
                "group":         group,
                "role":          role,
                "enabled":       stored.get((key, role), True),
            })
    return {"visibility": result, "components": KNOWN_COMPONENTS, "roles": KNOWN_ROLES}


@router.put("/api/admin/ui-visibility")
async def set_ui_visibility(
    body: dict,
    _user: dict = Depends(require_admin),
):
    """
    Bulk-upsert visibility rules.
    Body: { "rules": [{"component_key": str, "role": str, "enabled": bool}, ...] }
    """
    rules = body.get("rules", [])
    if not rules:
        raise HTTPException(status_code=400, detail="rules list required")
    valid_keys  = {k for k, _, _ in KNOWN_COMPONENTS}
    valid_roles = set(KNOWN_ROLES)
    cleaned = []
    for r in rules:
        ck = r.get("component_key", "")
        ro = r.get("role", "")
        if ck not in valid_keys or ro not in valid_roles:
            raise HTTPException(status_code=422, detail=f"Unknown component_key={ck!r} or role={ro!r}")
        cleaned.append({"component_key": ck, "role": ro, "enabled": bool(r.get("enabled", True))})
    count = _db_manager.bulk_set_ui_visibility(cleaned)
    username = (_user or {}).get("username", "admin")
    _db_manager.audit(username, "set_ui_visibility", resource_type="ui_visibility",
                      resource_id=f"{count}_rules")
    return {"updated": count}


# ── Lineage Feature Config (Phase 52) ─────────────────────────────────────────

@router.get("/api/admin/lineage/config")
async def get_lineage_config(_user: dict = Depends(require_admin)):
    """Return current lineage snapshot + freshness configuration."""
    from core import config as _cfg
    return {
        "snapshots_enabled":           _cfg.lineage.snapshots_enabled,
        "freshness_enabled":           _cfg.lineage.freshness_enabled,
        "snapshot_retention_days":     _cfg.lineage.snapshot_retention_days,
        "default_stale_threshold_hours": _cfg.lineage.default_stale_threshold_hours,
        "auto_extract":                _cfg.lineage.auto_extract,
    }


@router.put("/api/admin/lineage/config")
async def set_lineage_config(body: dict, _user: dict = Depends(require_admin)):
    """Update lineage feature flags in the runtime config.

    Body keys (all optional):
      snapshots_enabled: bool
      freshness_enabled: bool
      snapshot_retention_days: int
      default_stale_threshold_hours: int
      auto_extract: bool
    """
    from core import config as _cfg
    allowed = {
        "snapshots_enabled", "freshness_enabled",
        "snapshot_retention_days", "default_stale_threshold_hours", "auto_extract",
    }
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("lineage", key, val)
    username = (_user or {}).get("username", "admin")
    _db_manager.audit(username, "set_lineage_config", resource_type="lineage_config",
                      resource_id=str(updates))
    return {"updated": updates}


# ── Phase 57 — NL Chatbot Config ──────────────────────────────────────────

@router.get("/api/admin/chatbot/config")
async def get_chatbot_config(_user: dict = Depends(require_admin)):
    """Return current NL chatbot configuration."""
    from core import config as _cfg
    return {
        "semantic_context_enabled":  _cfg.chatbot.semantic_context_enabled,
        "time_intelligence_enabled": _cfg.chatbot.time_intelligence_enabled,
        "max_pattern_alternatives":  _cfg.chatbot.max_pattern_alternatives,
    }


@router.put("/api/admin/chatbot/config")
async def set_chatbot_config(body: dict, _user: dict = Depends(require_admin)):
    """Update NL chatbot feature flags at runtime."""
    from core import config as _cfg
    allowed = {"semantic_context_enabled", "time_intelligence_enabled", "max_pattern_alternatives"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("chatbot", key, val)
    username = (_user or {}).get("username", "admin")
    _db_manager.audit(username, "set_chatbot_config", resource_type="chatbot_config",
                      resource_id=str(updates))
    return {"updated": updates}


# ── AWS Portal Credential Provider ─────────────────────────────────────────

@router.get("/api/admin/aws-portal/config")
async def get_aws_portal_config(_user: dict = Depends(require_admin)):
    """Return current AWS portal configuration (passwords masked)."""
    from core import config as _cfg
    section = dict(_cfg._DEFAULTS.get("aws_portal", {}))
    # Overlay runtime overrides
    for k in section:
        section[k] = _cfg.get("aws_portal", k, section[k])
    # Mask sensitive values
    if section.get("service_password"):
        section["service_password"] = "********"
    return section


class AWSPortalConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    jwt_url: Optional[str] = None
    creds_url_template: Optional[str] = None
    account_id: Optional[str] = None
    role_name: Optional[str] = None
    service_username: Optional[str] = None
    service_password: Optional[str] = None
    verify_ssl: Optional[bool] = None
    creds_ttl_seconds: Optional[int] = None
    timeout_seconds: Optional[int] = None


@router.put("/api/admin/aws-portal/config")
async def set_aws_portal_config(body: AWSPortalConfigUpdate, _user: dict = Depends(require_admin)):
    """Update AWS portal configuration."""
    from core import config as _cfg
    updates = {k: v for k, v in body.model_dump(exclude_none=True).items()}
    if not updates:
        raise HTTPException(status_code=400, detail="No valid fields provided")
    for key, val in updates.items():
        _cfg.set("aws_portal", key, val)
    username = (_user or {}).get("username", "admin")
    # Mask password in audit
    audit_updates = dict(updates)
    if "service_password" in audit_updates:
        audit_updates["service_password"] = "********"
    _db_manager.audit(username, "set_aws_portal_config", resource_type="aws_portal_config",
                      resource_id=str(audit_updates))
    return {"updated": audit_updates}


@router.post("/api/admin/aws-portal/test")
async def test_aws_portal_config(_user: dict = Depends(require_admin)):
    """Test the AWS portal connection using the configured service account."""
    from core.aws_portal_auth import fetch_credentials, PortalAuthError, clear_cache
    from core import config as _cfg
    svc_user = _cfg.aws_portal.service_username
    svc_pass = _cfg.aws_portal.service_password
    if not svc_user or not svc_pass:
        raise HTTPException(status_code=400, detail="Service account credentials not configured")
    try:
        clear_cache(svc_user)
        creds = fetch_credentials(svc_user, svc_pass)
        return {
            "success": True,
            "message": f"Successfully obtained AWS credentials for service account '{svc_user}'",
            "access_key_prefix": creds["aws_access_key_id"][:8] + "...",
            "expires_at": creds.get("expires_at"),
        }
    except PortalAuthError as exc:
        return {"success": False, "message": str(exc)}


@router.get("/api/admin/aws-portal/cache")
async def get_aws_portal_cache_stats(_user: dict = Depends(require_admin)):
    """Return AWS portal credential cache statistics."""
    from core.aws_portal_auth import cache_stats
    return cache_stats()


@router.delete("/api/admin/aws-portal/cache")
async def clear_aws_portal_cache(username: Optional[str] = None, _user: dict = Depends(require_admin)):
    """Clear cached AWS portal credentials."""
    from core.aws_portal_auth import clear_cache
    cleared = clear_cache(username)
    return {"cleared": cleared, "username": username or "all"}


# ── User-facing portal auth (per-user mode) ──

class PortalAuthRequest(BaseModel):
    username: str = Field(min_length=1)
    password: str = Field(min_length=1)


@router.post("/api/aws-portal/authenticate")
async def user_portal_authenticate(body: PortalAuthRequest, _user: dict = Depends(get_current_user)):
    """Authenticate the current user against the AWS portal and cache creds.

    This is for per-user mode — user provides their own portal credentials.
    For shared/system account mode, admin configures service_username/password
    and all connections auto-use those creds.
    """
    from core import config as _cfg
    if not _cfg.aws_portal.enabled:
        raise HTTPException(status_code=400, detail="AWS portal authentication is not enabled")
    from core.aws_portal_auth import fetch_credentials, PortalAuthError
    try:
        creds = fetch_credentials(body.username, body.password)
        return {
            "success": True,
            "message": "AWS credentials obtained successfully",
            "access_key_prefix": creds["aws_access_key_id"][:8] + "...",
            "expires_in_seconds": int(creds.get("expires_at", 0) - __import__("time").time()),
        }
    except PortalAuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc))


@router.get("/api/aws-portal/status")
async def user_portal_status(_user: dict = Depends(get_current_user)):
    """Check if the current user has active AWS portal credentials."""
    from core import config as _cfg
    if not _cfg.aws_portal.enabled:
        return {"enabled": False, "authenticated": False, "mode": "disabled"}
    from core.aws_portal_auth import get_cached_credentials
    import time as _time
    username = (_user or {}).get("username", "")
    cached = get_cached_credentials(username)
    has_service = bool(_cfg.aws_portal.service_username and _cfg.aws_portal.service_password)
    svc_cached = get_cached_credentials(_cfg.aws_portal.service_username) if has_service else None
    return {
        "enabled": True,
        "mode": "service_account" if has_service else "per_user",
        "authenticated": bool(cached or svc_cached),
        "user_creds_active": bool(cached),
        "service_creds_active": bool(svc_cached),
        "expires_in_seconds": int(cached["expires_at"] - _time.time()) if cached else (
            int(svc_cached["expires_at"] - _time.time()) if svc_cached else 0),
    }
