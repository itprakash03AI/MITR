"""
Report Catalog API (Phase 23A)

Endpoints:
  GET    /api/report-catalog            — full catalog tree (folders + tags + reports)
  GET    /api/report-folders            — list folders (optionally by parent)
  POST   /api/report-folders            — create folder
  PUT    /api/report-folders/{id}       — rename / recolor
  DELETE /api/report-folders/{id}       — delete (re-parents children)

  POST   /api/reports/{id}/folder       — assign report to folder (or None to un-assign)
  GET    /api/report-tags               — list all tags
  POST   /api/report-tags               — create tag
  DELETE /api/report-tags/{id}          — delete tag + remove assignments
  POST   /api/reports/{id}/tags         — replace tag assignments for a report
  GET    /api/reports/{id}/tags         — get tags for a report

  POST   /api/reports/{id}/favorite     — toggle user favorite
  GET    /api/reports/favorites         — user's favorited report ids
  POST   /api/reports/{id}/view         — record a report view (recently viewed)
  GET    /api/reports/recent            — recently viewed report ids
  GET    /api/reports/search            — full-text search
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as QParam, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None


def set_catalog_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


# ── Auth helper (mirrors pattern from reports_api) ────────────────────────────

def _get_user(request: Request) -> dict:
    """Extract username from Basic-auth header. Returns {"username": ..., "role": ...}."""
    import base64
    auth_header = request.headers.get("authorization", "")
    if auth_header.startswith("Basic "):
        try:
            decoded = base64.b64decode(auth_header[6:]).decode()
            username = decoded.split(":")[0]
            return {"username": username, "role": "analyst"}
        except Exception:
            pass
    return {"username": "anonymous", "role": "viewer"}


# ── Pydantic models ───────────────────────────────────────────────────────────

class FolderCreate(BaseModel):
    name:        str
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        str = "folder"
    color:       str = "#1976d2"


class FolderUpdate(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        Optional[str] = None
    color:       Optional[str] = None


class TagCreate(BaseModel):
    name:  str
    color: str = "#666666"


class TagAssignRequest(BaseModel):
    tag_ids: List[int]


class FolderAssignRequest(BaseModel):
    folder_id: Optional[int] = None   # None = remove from folder


# ── Folder endpoints ──────────────────────────────────────────────────────────

@router.get("/api/report-catalog")
async def get_report_catalog(request: Request):
    """Return full catalog: folder tree + all tags + reports per folder."""
    user = _get_user(request)
    folders_all = _db_manager.list_folders(all_folders=True)
    tags_all    = _db_manager.list_tags()
    favorites   = _db_manager.get_user_favorites(user["username"])
    recent_ids  = _db_manager.get_recently_viewed(user["username"], limit=10)

    # Build folder tree
    def _build_tree(parent_id):
        children = [f for f in folders_all if f["parent_id"] == parent_id]
        for c in children:
            c["children"] = _build_tree(c["id"])
        return children

    return {
        "folders":   _build_tree(None),
        "tags":      tags_all,
        "favorites": favorites,
        "recent":    recent_ids,
    }


@router.get("/api/report-folders")
async def list_folders(parent_id: Optional[int] = None):
    return {"folders": _db_manager.list_folders(parent_id=parent_id)}


@router.post("/api/report-folders", status_code=201)
async def create_folder(body: FolderCreate, request: Request):
    user = _get_user(request)
    folder = _db_manager.create_folder(
        name=body.name, description=body.description,
        parent_id=body.parent_id, created_by=user["username"],
        icon=body.icon, color=body.color,
    )
    return folder


@router.put("/api/report-folders/{folder_id}")
async def update_folder(folder_id: int, body: FolderUpdate):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _db_manager.update_folder(folder_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Folder not found")
    return result


@router.delete("/api/report-folders/{folder_id}")
async def delete_folder(folder_id: int):
    ok = _db_manager.delete_folder(folder_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Folder not found")
    return {"deleted": True, "folder_id": folder_id}


@router.post("/api/reports/{report_id}/folder")
async def assign_report_folder(report_id: int, body: FolderAssignRequest):
    _db_manager.set_report_folder(report_id, body.folder_id)
    return {"report_id": report_id, "folder_id": body.folder_id}


# ── Tag endpoints ─────────────────────────────────────────────────────────────

@router.get("/api/report-tags")
async def list_tags():
    return {"tags": _db_manager.list_tags()}


@router.post("/api/report-tags", status_code=201)
async def create_tag(body: TagCreate, request: Request):
    user = _get_user(request)
    tag = _db_manager.create_tag(name=body.name, color=body.color,
                                  created_by=user["username"])
    return tag


@router.delete("/api/report-tags/{tag_id}")
async def delete_tag(tag_id: int):
    ok = _db_manager.delete_tag(tag_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Tag not found")
    return {"deleted": True, "tag_id": tag_id}


@router.post("/api/reports/{report_id}/tags")
async def assign_tags(report_id: int, body: TagAssignRequest):
    _db_manager.assign_report_tags(report_id, body.tag_ids)
    return {"report_id": report_id, "tag_ids": body.tag_ids}


@router.get("/api/reports/{report_id}/tags")
async def get_report_tags(report_id: int):
    return {"tags": _db_manager.get_report_tags(report_id)}


# ── Favorites & Recently Viewed ───────────────────────────────────────────────

@router.post("/api/reports/{report_id}/favorite")
async def toggle_favorite(report_id: int, request: Request):
    user = _get_user(request)
    added = _db_manager.toggle_report_favorite(report_id, user["username"])
    return {"report_id": report_id, "favorited": added}


@router.get("/api/reports/favorites")
async def get_favorites(request: Request):
    user = _get_user(request)
    return {"report_ids": _db_manager.get_user_favorites(user["username"])}


@router.post("/api/reports/{report_id}/view")
async def record_view(report_id: int, request: Request):
    user = _get_user(request)
    _db_manager.record_report_view(report_id, user["username"])
    return {"recorded": True}


@router.get("/api/reports/recent")
async def get_recent(request: Request,
                     limit: int = QParam(default=10, ge=1, le=50)):
    user = _get_user(request)
    return {"report_ids": _db_manager.get_recently_viewed(user["username"], limit)}


# ── Search ────────────────────────────────────────────────────────────────────

@router.get("/api/reports/search")
async def search_reports(q: str = QParam(min_length=1),
                         limit: int = QParam(default=30, ge=1, le=100)):
    results = _db_manager.search_reports(q, limit=limit)
    return {"results": results, "count": len(results)}
