import { defineConfig, createLogger } from 'vite';
import react from '@vitejs/plugin-react';

// Suppress noisy WebSocket proxy disconnect errors (ECONNABORTED / ECONNRESET).
// These fire every time a browser tab closes or refreshes and are expected.
const logger = createLogger();
const _origError = logger.error.bind(logger);
logger.error = (msg, opts) => {
  if (msg.indexOf('ECONNABORTED') !== -1 || msg.indexOf('ECONNRESET') !== -1) return;
  _origError(msg, opts);
};

export default defineConfig({
  customLogger: logger,
  plugins: [react()],
  server: {
    port: 4000,
    proxy: {
      '/api':     'http://localhost:8000',
      '/auth':    'http://localhost:8000',
      '/health':  'http://localhost:8000',
      '/metrics': 'http://localhost:8000',
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        configure: (proxy) => {
          proxy.on('error', (err: Error & { code?: string }) => {
            if (!err?.message) return;
            if (err.code === 'ECONNABORTED' || err.code === 'ECONNRESET') return;
            if (err.message.indexOf('ECONNABORTED') !== -1 || err.message.indexOf('ECONNRESET') !== -1) return;
            console.error('[ws proxy]', err.message);
          });
        },
      },
    },
  },
  build: {
    outDir: 'build',
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-mui': ['@mui/material', '@mui/icons-material'],
          'vendor-charts': ['recharts'],
          'vendor-grid': ['@mui/x-data-grid'],
          'page-admin': ['./src/components/AdminPage'],
          'page-catalog': ['./src/components/ReportCatalogPage'],
          'page-lineage': ['./src/components/LineagePage'],
          'page-editor': ['./src/components/CompleteQueryBuilder'],
        },
      },
    },
  },
});
