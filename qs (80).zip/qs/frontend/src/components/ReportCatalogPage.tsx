/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-nocheck
/**
 * Report Catalog (Phase 23A)
 *
 * Browse all parametric reports organized by folders and tags.
 * Features: folder tree, tag filter, favorites, recently viewed, full-text search.
 * Clicking a report card navigates to /report-manager with the report pre-selected.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Divider, IconButton, InputAdornment,
  List, ListItemButton, ListItemIcon, ListItemText, Paper,
  TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add as AddIcon,
  Assessment as ReportIcon,
  Bookmark as BookmarkIcon,
  ChevronRight as ChevronRightIcon,
  Clear as ClearIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  ExpandLess as CollapseIcon,
  ExpandMore as ExpandMoreIcon,
  Folder as FolderIcon,
  FolderOpen as FolderOpenIcon,
  History as RecentIcon,
  Label as TagIcon,
  PlayArrow as RunIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  Star as StarIcon,
  StarBorder as StarBorderIcon,
} from '@mui/icons-material';
import api from '../services/api';

// ── Helpers ───────────────────────────────────────────────────────────────

const sourceLabel = (r: any) =>
  r.saved_query_id ? 'Parquet' : r.sql_saved_query_id ? 'SQL' : '—';

// ── FolderTreeItem ────────────────────────────────────────────────────────

function FolderTreeItem({
  folder, depth, selectedFolderId, onSelect, onEdit, onDelete,
}: {
  folder: any; depth: number; selectedFolderId: number | null;
  onSelect: (id: number | null) => void;
  onEdit: (f: any) => void;
  onDelete: (f: any) => void;
}) {
  const [expanded, setExpanded] = useState(depth === 0);
  const hasChildren = (folder.children || []).length > 0;
  const active = selectedFolderId === folder.id;

  return (
    <>
      <ListItemButton
        dense
        selected={active}
        sx={{ pl: 1.5 + depth * 2, pr: 1, py: 0.4, borderRadius: 1, mb: 0.25 }}
        onClick={() => onSelect(active ? null : folder.id)}
      >
        <ListItemIcon sx={{ minWidth: 28 }}>
          {active ? <FolderOpenIcon sx={{ fontSize: 16, color: folder.color || '#1976d2' }} />
                  : <FolderIcon sx={{ fontSize: 16, color: folder.color || '#1976d2' }} />}
        </ListItemIcon>
        <ListItemText
          primary={folder.name}
          primaryTypographyProps={{ variant: 'body2', fontWeight: active ? 600 : 400, noWrap: true }}
        />
        {hasChildren && (
          <IconButton size="small" sx={{ p: 0.25 }} onClick={e => { e.stopPropagation(); setExpanded(v => !v); }}>
            {expanded ? <CollapseIcon sx={{ fontSize: 14 }} /> : <ExpandMoreIcon sx={{ fontSize: 14 }} />}
          </IconButton>
        )}
        <IconButton size="small" sx={{ p: 0.25, opacity: 0, '.MuiListItemButton-root:hover &': { opacity: 1 } }}
          onClick={e => { e.stopPropagation(); onEdit(folder); }}>
          <EditIcon sx={{ fontSize: 12 }} />
        </IconButton>
        <IconButton size="small" color="error" sx={{ p: 0.25, opacity: 0, '.MuiListItemButton-root:hover &': { opacity: 1 } }}
          onClick={e => { e.stopPropagation(); onDelete(folder); }}>
          <DeleteIcon sx={{ fontSize: 12 }} />
        </IconButton>
      </ListItemButton>
      {hasChildren && expanded && folder.children.map((child: any) => (
        <FolderTreeItem key={child.id} folder={child} depth={depth + 1}
          selectedFolderId={selectedFolderId} onSelect={onSelect}
          onEdit={onEdit} onDelete={onDelete} />
      ))}
    </>
  );
}

// ── ReportCard ────────────────────────────────────────────────────────────

function ReportCard({
  report, tags, favoriteIds, onToggleFavorite, onRun,
}: {
  report: any; tags: any[]; favoriteIds: number[];
  onToggleFavorite: (id: number) => void;
  onRun: (r: any) => void;
}) {
  const isFav = favoriteIds.includes(report.id);
  const reportTags = (report.tags || []);

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2, display: 'flex', flexDirection: 'column', gap: 1,
        cursor: 'pointer', transition: 'box-shadow 0.15s',
        '&:hover': { boxShadow: 3, borderColor: 'primary.light' },
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
        <ReportIcon sx={{ fontSize: 20, color: 'primary.main', mt: 0.25, flexShrink: 0 }} />
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="body2" fontWeight={600} noWrap title={report.name}>
            {report.name}
          </Typography>
          {report.description && (
            <Typography variant="caption" color="text.secondary" noWrap title={report.description}>
              {report.description}
            </Typography>
          )}
        </Box>
        <Tooltip title={isFav ? 'Remove from favorites' : 'Add to favorites'}>
          <IconButton size="small" sx={{ p: 0.25 }} onClick={e => { e.stopPropagation(); onToggleFavorite(report.id); }}>
            {isFav
              ? <StarIcon sx={{ fontSize: 16, color: 'warning.main' }} />
              : <StarBorderIcon sx={{ fontSize: 16, color: 'text.disabled' }} />}
          </IconButton>
        </Tooltip>
      </Box>

      <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', alignItems: 'center' }}>
        <Chip label={sourceLabel(report)} size="small" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
        {(report.parameters || []).length > 0 && (
          <Chip label={`${report.parameters.length} param${report.parameters.length !== 1 ? 's' : ''}`}
            size="small" color="primary" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
        )}
        {(report.execution_count || 0) > 0 && (
          <Chip label={`${report.execution_count} runs`} size="small" variant="outlined"
            sx={{ height: 18, fontSize: 10 }} />
        )}
        {reportTags.map((t: any) => (
          <Chip key={t.id || t} label={t.name || t} size="small"
            sx={{ height: 18, fontSize: 10, bgcolor: t.color || '#e0e0e0', color: '#fff' }} />
        ))}
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button size="small" variant="contained" startIcon={<RunIcon />}
          onClick={() => onRun(report)}>
          Run
        </Button>
      </Box>
    </Paper>
  );
}

// ── FolderDialog ──────────────────────────────────────────────────────────

function FolderDialog({ open, folder, onClose, onSaved }: {
  open: boolean; folder: any; onClose: () => void; onSaved: () => void;
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#1976d2');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setName(folder?.name || '');
      setColor(folder?.color || '#1976d2');
      setError('');
    }
  }, [open, folder]);

  const handleSave = async () => {
    if (!name.trim()) { setError('Name is required'); return; }
    setSaving(true);
    try {
      if (folder?.id) {
        await api.updateReportFolder(folder.id, { name: name.trim(), color });
      } else {
        await api.createReportFolder({ name: name.trim(), color });
      }
      onSaved();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>{folder?.id ? 'Edit Folder' : 'New Folder'}</DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}
        <TextField label="Folder name" fullWidth size="small" value={name}
          onChange={e => setName(e.target.value)} autoFocus sx={{ mb: 2, mt: 1 }} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="body2" color="text.secondary">Color:</Typography>
          <input type="color" value={color} onChange={e => setColor(e.target.value)}
            style={{ width: 40, height: 28, border: 'none', padding: 0, cursor: 'pointer' }} />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── TagDialog ─────────────────────────────────────────────────────────────

function TagDialog({ open, onClose, onSaved }: {
  open: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#1976d2');
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) { setName(''); setColor('#1976d2'); } }, [open]);

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await api.createReportTag({ name: name.trim(), color });
      onSaved();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>New Tag</DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        <TextField label="Tag name" fullWidth size="small" value={name}
          onChange={e => setName(e.target.value)} autoFocus sx={{ mb: 2, mt: 1 }} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="body2" color="text.secondary">Color:</Typography>
          <input type="color" value={color} onChange={e => setColor(e.target.value)}
            style={{ width: 40, height: 28, border: 'none', padding: 0, cursor: 'pointer' }} />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={16} /> : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────

export default function ReportCatalogPage() {
  const navigate = useNavigate();

  // Data
  const [catalog, setCatalog] = useState<any>({ folders: [], tags: [], favorites: [], recent: [] });
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Navigation state
  const [selectedFolderId, setSelectedFolderId] = useState<number | null>(null);
  const [selectedTagId, setSelectedTagId] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'favorites' | 'recent'>('all');
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  // Favorites (mutable)
  const [favoriteIds, setFavoriteIds] = useState<number[]>([]);

  // Dialogs
  const [folderDialogOpen, setFolderDialogOpen] = useState(false);
  const [editFolder, setEditFolder] = useState<any>(null);
  const [deleteFolder, setDeleteFolder] = useState<any>(null);
  const [tagDialogOpen, setTagDialogOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [cat, rpts] = await Promise.all([
        api.getReportCatalog(),
        api.listReports(false),
      ]);
      setCatalog(cat);
      setReports(rpts);
      setFavoriteIds(cat.favorites || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Search debounce
  useEffect(() => {
    if (!searchQ.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await api.searchReportCatalog(searchQ.trim());
        setSearchResults(res.results || []);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [searchQ]);

  const handleToggleFavorite = async (reportId: number) => {
    try {
      await api.toggleReportFavorite(reportId);
      setFavoriteIds(prev =>
        prev.includes(reportId) ? prev.filter(id => id !== reportId) : [...prev, reportId]
      );
    } catch (e: any) { alert(e.message); }
  };

  const handleRun = async (report: any) => {
    await api.recordReportView(report.id);
    navigate(`/report-manager?reportId=${report.id}`);
  };

  const handleDeleteFolder = async () => {
    if (!deleteFolder) return;
    try {
      await api.deleteReportFolder(deleteFolder.id);
      if (selectedFolderId === deleteFolder.id) setSelectedFolderId(null);
      setDeleteFolder(null);
      load();
    } catch (e: any) { alert(e.message); }
  };

  // Compute visible reports
  const visibleReports = React.useMemo(() => {
    if (searchQ.trim()) return searchResults;

    let list = [...reports];

    if (viewMode === 'favorites') {
      list = list.filter(r => favoriteIds.includes(r.id));
    } else if (viewMode === 'recent') {
      const recentIds: number[] = catalog.recent || [];
      const idx = Object.fromEntries(recentIds.map((id, i) => [id, i]));
      list = list.filter(r => recentIds.includes(r.id));
      list.sort((a, b) => (idx[a.id] ?? 999) - (idx[b.id] ?? 999));
    } else if (selectedFolderId != null) {
      // Only reports assigned to this folder — we'd need assignment info
      // For now filter by folder_id field if present
      list = list.filter(r => r.folder_id === selectedFolderId);
    }

    if (selectedTagId != null) {
      list = list.filter(r => (r.tags || []).some((t: any) => (t.id || t) === selectedTagId));
    }

    return list;
  }, [reports, searchQ, searchResults, viewMode, selectedFolderId, selectedTagId, favoriteIds, catalog]);

  const tags = catalog.tags || [];
  const folders = catalog.folders || [];

  return (
    <Box sx={{ display: 'flex', height: '100%', overflow: 'hidden' }}>
      {/* ── Left Sidebar ─────────────────────────────────────────── */}
      <Box sx={{
        width: 240, flexShrink: 0, borderRight: '1px solid', borderColor: 'divider',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        {/* Sidebar header */}
        <Box sx={{ px: 1.5, py: 1, display: 'flex', alignItems: 'center', gap: 0.5,
          borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" fontWeight={600} sx={{ flex: 1 }}>Catalog</Typography>
          <Tooltip title="Refresh">
            <IconButton size="small" onClick={load} disabled={loading}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>

        <Box sx={{ flex: 1, overflowY: 'auto', px: 1, py: 1 }}>
          {/* View shortcuts */}
          <Typography variant="caption" color="text.disabled" sx={{ px: 0.5, display: 'block', mb: 0.5 }}>
            VIEWS
          </Typography>
          {[
            { id: 'all',       label: 'All Reports', icon: <ReportIcon sx={{ fontSize: 16 }} /> },
            { id: 'favorites', label: 'Favorites',   icon: <StarIcon sx={{ fontSize: 16, color: 'warning.main' }} /> },
            { id: 'recent',    label: 'Recently Viewed', icon: <RecentIcon sx={{ fontSize: 16 }} /> },
          ].map(v => (
            <ListItemButton key={v.id} dense selected={viewMode === v.id && selectedFolderId == null}
              sx={{ borderRadius: 1, mb: 0.25, pl: 1.5 }}
              onClick={() => { setViewMode(v.id as any); setSelectedFolderId(null); setSelectedTagId(null); }}>
              <ListItemIcon sx={{ minWidth: 26 }}>{v.icon}</ListItemIcon>
              <ListItemText primary={v.label} primaryTypographyProps={{ variant: 'body2' }} />
            </ListItemButton>
          ))}

          <Divider sx={{ my: 1 }} />

          {/* Folders */}
          <Box sx={{ display: 'flex', alignItems: 'center', px: 0.5, mb: 0.5 }}>
            <Typography variant="caption" color="text.disabled" sx={{ flex: 1 }}>FOLDERS</Typography>
            <Tooltip title="New folder">
              <IconButton size="small" sx={{ p: 0.25 }} onClick={() => { setEditFolder(null); setFolderDialogOpen(true); }}>
                <AddIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
          </Box>
          {folders.length === 0 ? (
            <Typography variant="caption" color="text.disabled" sx={{ px: 1, display: 'block' }}>
              No folders yet
            </Typography>
          ) : folders.map((f: any) => (
            <FolderTreeItem key={f.id} folder={f} depth={0}
              selectedFolderId={selectedFolderId}
              onSelect={id => { setSelectedFolderId(id); setViewMode('all'); }}
              onEdit={folder => { setEditFolder(folder); setFolderDialogOpen(true); }}
              onDelete={setDeleteFolder}
            />
          ))}

          <Divider sx={{ my: 1 }} />

          {/* Tags */}
          <Box sx={{ display: 'flex', alignItems: 'center', px: 0.5, mb: 0.5 }}>
            <Typography variant="caption" color="text.disabled" sx={{ flex: 1 }}>TAGS</Typography>
            <Tooltip title="New tag">
              <IconButton size="small" sx={{ p: 0.25 }} onClick={() => setTagDialogOpen(true)}>
                <AddIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
          </Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, px: 0.5 }}>
            {tags.map((t: any) => (
              <Chip key={t.id} label={t.name} size="small"
                onClick={() => setSelectedTagId(selectedTagId === t.id ? null : t.id)}
                onDelete={() => api.deleteReportTag(t.id).then(load)}
                sx={{
                  height: 20, fontSize: 10,
                  bgcolor: selectedTagId === t.id ? (t.color || '#1976d2') : undefined,
                  color: selectedTagId === t.id ? '#fff' : undefined,
                  borderColor: t.color || '#9e9e9e',
                  border: '1px solid',
                }}
                variant="outlined"
              />
            ))}
            {tags.length === 0 && (
              <Typography variant="caption" color="text.disabled">No tags yet</Typography>
            )}
          </Box>
        </Box>
      </Box>

      {/* ── Main Area ─────────────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Search bar + context header */}
        <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider',
          display: 'flex', alignItems: 'center', gap: 1.5, flexShrink: 0 }}>
          <TextField
            size="small" placeholder="Search reports…" value={searchQ}
            onChange={e => setSearchQ(e.target.value)}
            sx={{ flex: 1, maxWidth: 400 }}
            InputProps={{
              startAdornment: <InputAdornment position="start">
                {searching ? <CircularProgress size={14} /> : <SearchIcon fontSize="small" />}
              </InputAdornment>,
              endAdornment: searchQ ? (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearchQ('')}><ClearIcon fontSize="small" /></IconButton>
                </InputAdornment>
              ) : null,
            }}
          />
          <Typography variant="body2" color="text.secondary">
            {searchQ.trim()
              ? `${visibleReports.length} result${visibleReports.length !== 1 ? 's' : ''}`
              : `${visibleReports.length} report${visibleReports.length !== 1 ? 's' : ''}`}
          </Typography>
          {selectedTagId != null && (
            <Chip
              label={`Tag: ${tags.find((t: any) => t.id === selectedTagId)?.name || selectedTagId}`}
              size="small" onDelete={() => setSelectedTagId(null)} color="primary"
            />
          )}
        </Box>

        {/* Report grid */}
        <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', pt: 6 }}>
              <CircularProgress />
            </Box>
          ) : visibleReports.length === 0 ? (
            <Box sx={{ textAlign: 'center', pt: 8 }}>
              <ReportIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
              <Typography variant="h6" color="text.secondary">
                {searchQ.trim() ? 'No reports match your search' : 'No reports in this view'}
              </Typography>
              <Typography variant="body2" color="text.disabled" sx={{ mb: searchQ.trim() ? 0 : 1.5 }}>
                {searchQ.trim() ? 'Try a different search term' : 'Reports created in Parametric Reports appear here automatically.'}
              </Typography>
              {!searchQ.trim() && (
                <Button variant="contained" size="small" onClick={() => navigate('/report-manager')}>
                  Go to Parametric Reports →
                </Button>
              )}
            </Box>
          ) : (
            <Box sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
              gap: 2,
            }}>
              {visibleReports.map((r: any) => (
                <ReportCard key={r.id} report={r} tags={tags}
                  favoriteIds={favoriteIds}
                  onToggleFavorite={handleToggleFavorite}
                  onRun={handleRun}
                />
              ))}
            </Box>
          )}
        </Box>
      </Box>

      {/* ── Dialogs ───────────────────────────────────────────────── */}
      <FolderDialog
        open={folderDialogOpen}
        folder={editFolder}
        onClose={() => setFolderDialogOpen(false)}
        onSaved={() => { setFolderDialogOpen(false); load(); }}
      />

      <TagDialog
        open={tagDialogOpen}
        onClose={() => setTagDialogOpen(false)}
        onSaved={() => { setTagDialogOpen(false); load(); }}
      />

      <Dialog open={!!deleteFolder} onClose={() => setDeleteFolder(null)} maxWidth="xs">
        <DialogTitle>Delete Folder?</DialogTitle>
        <DialogContent>
          <Typography>
            Delete folder <strong>{deleteFolder?.name}</strong>?
            Reports inside will be unassigned (not deleted).
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteFolder(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDeleteFolder}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
