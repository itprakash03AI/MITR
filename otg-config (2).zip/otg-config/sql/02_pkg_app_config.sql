-- ============================================================
-- 02_pkg_app_config.sql
-- Package: PKG_APP_CONFIG
-- All DML for OTG_APP_CONFIG goes through this package.
-- Python calls these procedures — zero inline SQL in Python.
-- ============================================================

-- ── Package Specification ──────────────────────────────────────────────────

CREATE OR REPLACE PACKAGE PKG_APP_CONFIG AS

    -- Custom exceptions
    EX_NOT_FOUND        EXCEPTION;
    EX_DUPLICATE        EXCEPTION;
    PRAGMA EXCEPTION_INIT(EX_NOT_FOUND, -20001);
    PRAGMA EXCEPTION_INIT(EX_DUPLICATE, -20002);

    /**
     * Create a new application config entry.
     * Returns the generated APPID via OUT parameter.
     */
    PROCEDURE CREATE_APP (
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT 'Y',
        p_createdby     IN  OTG_APP_CONFIG.CREATEDBY%TYPE      DEFAULT NULL,
        p_appid         OUT OTG_APP_CONFIG.APPID%TYPE
    );

    /**
     * Update an existing application config.
     * Only supplied (non-null) fields are updated.
     */
    PROCEDURE UPDATE_APP (
        p_appid         IN  OTG_APP_CONFIG.APPID%TYPE,
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE        DEFAULT NULL,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE            DEFAULT NULL,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT NULL,
        p_updatedby     IN  OTG_APP_CONFIG.UPDATEDBY%TYPE      DEFAULT NULL
    );

    /**
     * Soft-delete: sets ACTIVE = 'N'.
     */
    PROCEDURE DEACTIVATE_APP (
        p_appid     IN  OTG_APP_CONFIG.APPID%TYPE,
        p_updatedby IN  OTG_APP_CONFIG.UPDATEDBY%TYPE DEFAULT 'SYSTEM'
    );

    /**
     * Fetch a single app by PK. Returns SYS_REFCURSOR.
     */
    FUNCTION GET_APP (
        p_appid IN OTG_APP_CONFIG.APPID%TYPE
    ) RETURN SYS_REFCURSOR;

    /**
     * List apps with optional filters. Returns SYS_REFCURSOR.
     */
    FUNCTION LIST_APPS (
        p_env    IN OTG_APP_CONFIG.ENV%TYPE    DEFAULT NULL,
        p_active IN OTG_APP_CONFIG.ACTIVE%TYPE DEFAULT NULL,
        p_limit  IN NUMBER DEFAULT 100,
        p_offset IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR;

END PKG_APP_CONFIG;
/

-- ── Package Body ──────────────────────────────────────────────────────────────

CREATE OR REPLACE PACKAGE BODY PKG_APP_CONFIG AS

    -- ── CREATE_APP ────────────────────────────────────────────────────────────
    PROCEDURE CREATE_APP (
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT 'Y',
        p_createdby     IN  OTG_APP_CONFIG.CREATEDBY%TYPE      DEFAULT NULL,
        p_appid         OUT OTG_APP_CONFIG.APPID%TYPE
    ) IS
        v_count NUMBER;
    BEGIN
        -- Check for duplicate name+env
        SELECT COUNT(*)
          INTO v_count
          FROM OTG_APP_CONFIG
         WHERE APPNAME = p_appname
           AND ENV     = p_env;

        IF v_count > 0 THEN
            RAISE_APPLICATION_ERROR(-20002,
                'App [' || p_appname || '] already exists in env [' || p_env || ']');
        END IF;

        p_appid := OTG_APP_CONFIG_SEQ.NEXTVAL;

        INSERT INTO OTG_APP_CONFIG (
            APPID, APPNAME, ENV, HOSTNAME, DB_TYPE, DB_CONNECTION, ACTIVE, CREATEDON, CREATEDBY
        ) VALUES (
            p_appid, p_appname, p_env, p_hostname, p_db_type, p_db_connection,
            NVL(p_active, 'Y'), SYSDATE, p_createdby
        );

        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END CREATE_APP;

    -- ── UPDATE_APP ────────────────────────────────────────────────────────────
    PROCEDURE UPDATE_APP (
        p_appid         IN  OTG_APP_CONFIG.APPID%TYPE,
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE        DEFAULT NULL,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE            DEFAULT NULL,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT NULL,
        p_updatedby     IN  OTG_APP_CONFIG.UPDATEDBY%TYPE      DEFAULT NULL
    ) IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM OTG_APP_CONFIG WHERE APPID = p_appid;
        IF v_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'App ID [' || p_appid || '] not found');
        END IF;

        UPDATE OTG_APP_CONFIG
           SET APPNAME       = NVL(p_appname,       APPNAME),
               ENV           = NVL(p_env,           ENV),
               HOSTNAME      = NVL(p_hostname,      HOSTNAME),
               DB_TYPE       = NVL(p_db_type,       DB_TYPE),
               DB_CONNECTION = NVL(p_db_connection, DB_CONNECTION),
               ACTIVE        = NVL(p_active,        ACTIVE),
               UPDATEDON     = SYSDATE,
               UPDATEDBY     = p_updatedby
         WHERE APPID = p_appid;

        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END UPDATE_APP;

    -- ── DEACTIVATE_APP ────────────────────────────────────────────────────────
    PROCEDURE DEACTIVATE_APP (
        p_appid     IN  OTG_APP_CONFIG.APPID%TYPE,
        p_updatedby IN  OTG_APP_CONFIG.UPDATEDBY%TYPE DEFAULT 'SYSTEM'
    ) IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM OTG_APP_CONFIG WHERE APPID = p_appid;
        IF v_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'App ID [' || p_appid || '] not found');
        END IF;

        UPDATE OTG_APP_CONFIG
           SET ACTIVE    = 'N',
               UPDATEDON = SYSDATE,
               UPDATEDBY = p_updatedby
         WHERE APPID = p_appid;

        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END DEACTIVATE_APP;

    -- ── GET_APP ───────────────────────────────────────────────────────────────
    FUNCTION GET_APP (
        p_appid IN OTG_APP_CONFIG.APPID%TYPE
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT APPID, APPNAME, ENV, HOSTNAME, DB_TYPE, DB_CONNECTION,
                   ACTIVE, CREATEDON, CREATEDBY, UPDATEDON, UPDATEDBY
              FROM OTG_APP_CONFIG
             WHERE APPID = p_appid;
        RETURN v_cur;
    END GET_APP;

    -- ── LIST_APPS ─────────────────────────────────────────────────────────────
    FUNCTION LIST_APPS (
        p_env    IN OTG_APP_CONFIG.ENV%TYPE    DEFAULT NULL,
        p_active IN OTG_APP_CONFIG.ACTIVE%TYPE DEFAULT NULL,
        p_limit  IN NUMBER DEFAULT 100,
        p_offset IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT APPID, APPNAME, ENV, HOSTNAME, DB_TYPE, DB_CONNECTION,
                   ACTIVE, CREATEDON, CREATEDBY, UPDATEDON, UPDATEDBY
              FROM OTG_APP_CONFIG
             WHERE (p_env    IS NULL OR ENV    = p_env)
               AND (p_active IS NULL OR ACTIVE = p_active)
             ORDER BY APPID
            OFFSET p_offset ROWS FETCH NEXT p_limit ROWS ONLY;
        RETURN v_cur;
    END LIST_APPS;

END PKG_APP_CONFIG;
/

SHOW ERRORS PACKAGE BODY PKG_APP_CONFIG;
