-- ============================================================
-- 04_pkg_dag_config.sql
-- Package: PKG_DAG_CONFIG
-- Manages OTG_AIRFLOW_DAG_CONFIG + OTG_AIRFLOW_DAG_PARAM_CONFIG
-- ============================================================

CREATE OR REPLACE PACKAGE PKG_DAG_CONFIG AS

    EX_NOT_FOUND      EXCEPTION;
    EX_DUPLICATE_DAG  EXCEPTION;
    EX_INVALID_REPORT EXCEPTION;
    PRAGMA EXCEPTION_INIT(EX_NOT_FOUND,      -20001);
    PRAGMA EXCEPTION_INIT(EX_DUPLICATE_DAG,  -20004);
    PRAGMA EXCEPTION_INIT(EX_INVALID_REPORT, -20005);

    PROCEDURE CREATE_DAG (
        p_fk_report_id     IN  OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_fk_dest_appid    IN  OTG_AIRFLOW_DAG_CONFIG.FK_DEST_APPID%TYPE      DEFAULT NULL,
        p_dag_id           IN  OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE,
        p_dag_group        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE          DEFAULT NULL,
        p_dag_url          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_URL%TYPE            DEFAULT NULL,
        p_dag_type         IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE           DEFAULT NULL,
        p_schedule         IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE  DEFAULT NULL,
        p_max_active_runs  IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE    DEFAULT 1,
        p_concurrency      IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE        DEFAULT 1,
        p_auto_trigger     IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE       DEFAULT 'N',
        p_auto_skip        IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE          DEFAULT 'N',
        p_tags             IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE               DEFAULT NULL,
        p_active           IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE             DEFAULT 'Y',
        p_param_keys       IN  VARCHAR2 DEFAULT NULL,   -- pipe-separated
        p_param_values     IN  VARCHAR2 DEFAULT NULL,   -- pipe-separated
        p_otg_dag_id       OUT OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    );

    PROCEDURE UPDATE_DAG (
        p_otg_dag_id       IN  OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE,
        p_dag_group        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE         DEFAULT NULL,
        p_dag_url          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_URL%TYPE           DEFAULT NULL,
        p_dag_type         IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE          DEFAULT NULL,
        p_schedule         IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE DEFAULT NULL,
        p_max_active_runs  IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE   DEFAULT NULL,
        p_concurrency      IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE       DEFAULT NULL,
        p_auto_trigger     IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE      DEFAULT NULL,
        p_auto_skip        IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE         DEFAULT NULL,
        p_tags             IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE              DEFAULT NULL,
        p_active           IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE            DEFAULT NULL,
        p_updatedby        IN  OTG_AIRFLOW_DAG_CONFIG.UPDATEDBY%TYPE         DEFAULT NULL
    );

    PROCEDURE DEACTIVATE_DAG (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE,
        p_updatedby  IN OTG_AIRFLOW_DAG_CONFIG.UPDATEDBY%TYPE DEFAULT 'SYSTEM'
    );

    PROCEDURE ADD_DAG_PARAM (
        p_otg_dag_id  IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.FK_OTG_DAG_ID%TYPE,
        p_key         IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.KEY%TYPE,
        p_val         IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.VAL%TYPE   DEFAULT NULL,
        p_active      IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.ACTIVE%TYPE DEFAULT 'Y',
        p_createdby   IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.CREATEDBY%TYPE DEFAULT NULL,
        p_param_id    OUT OTG_AIRFLOW_DAG_PARAM_CONFIG.ID%TYPE
    );

    PROCEDURE DEACTIVATE_DAG_PARAM (
        p_param_id IN OTG_AIRFLOW_DAG_PARAM_CONFIG.ID%TYPE
    );

    FUNCTION GET_DAG (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    ) RETURN SYS_REFCURSOR;

    FUNCTION LIST_DAGS (
        p_fk_report_id IN OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE DEFAULT NULL,
        p_dag_type     IN OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE     DEFAULT NULL,
        p_active       IN OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE       DEFAULT NULL,
        p_search       IN VARCHAR2 DEFAULT NULL,
        p_limit        IN NUMBER DEFAULT 50,
        p_offset       IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_DAG_PARAMS (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_PARAM_CONFIG.FK_OTG_DAG_ID%TYPE
    ) RETURN SYS_REFCURSOR;

END PKG_DAG_CONFIG;
/

CREATE OR REPLACE PACKAGE BODY PKG_DAG_CONFIG AS

    TYPE t_str_arr IS TABLE OF VARCHAR2(2000) INDEX BY PLS_INTEGER;

    FUNCTION SPLIT_PIPE (p_str IN VARCHAR2) RETURN t_str_arr IS
        v_arr t_str_arr; v_str VARCHAR2(32767) := p_str;
        v_pos NUMBER; v_idx PLS_INTEGER := 1;
    BEGIN
        IF p_str IS NULL THEN RETURN v_arr; END IF;
        LOOP
            v_pos := INSTR(v_str, '|');
            IF v_pos = 0 THEN v_arr(v_idx) := v_str; EXIT; END IF;
            v_arr(v_idx) := SUBSTR(v_str, 1, v_pos - 1);
            v_str := SUBSTR(v_str, v_pos + 1);
            v_idx := v_idx + 1;
        END LOOP;
        RETURN v_arr;
    END SPLIT_PIPE;

    -- ── CREATE_DAG ────────────────────────────────────────────────────────────
    PROCEDURE CREATE_DAG (
        p_fk_report_id     IN  OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_fk_dest_appid    IN  OTG_AIRFLOW_DAG_CONFIG.FK_DEST_APPID%TYPE      DEFAULT NULL,
        p_dag_id           IN  OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE,
        p_dag_group        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE          DEFAULT NULL,
        p_dag_url          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_URL%TYPE            DEFAULT NULL,
        p_dag_type         IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE           DEFAULT NULL,
        p_schedule         IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE  DEFAULT NULL,
        p_max_active_runs  IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE    DEFAULT 1,
        p_concurrency      IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE        DEFAULT 1,
        p_auto_trigger     IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE       DEFAULT 'N',
        p_auto_skip        IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE          DEFAULT 'N',
        p_tags             IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE               DEFAULT NULL,
        p_active           IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE             DEFAULT 'Y',
        p_param_keys       IN  VARCHAR2 DEFAULT NULL,
        p_param_values     IN  VARCHAR2 DEFAULT NULL,
        p_otg_dag_id       OUT OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    ) IS
        v_rpt_count  NUMBER;
        v_dup_count  NUMBER;
        v_keys       t_str_arr;
        v_vals       t_str_arr;
        v_param_id   OTG_AIRFLOW_DAG_PARAM_CONFIG.ID%TYPE;
    BEGIN
        -- Validate parent report
        SELECT COUNT(*) INTO v_rpt_count
          FROM OTG_REPORT_CONFIG
         WHERE REPORTID = p_fk_report_id AND ACTIVE = 'Y';
        IF v_rpt_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20005,
                'Active Report ID [' || p_fk_report_id || '] not found');
        END IF;

        -- Check unique DAG_ID
        SELECT COUNT(*) INTO v_dup_count
          FROM OTG_AIRFLOW_DAG_CONFIG
         WHERE DAG_ID = p_dag_id;
        IF v_dup_count > 0 THEN
            RAISE_APPLICATION_ERROR(-20004,
                'DAG ID [' || p_dag_id || '] already exists');
        END IF;

        p_otg_dag_id := OTG_DAG_CONFIG_SEQ.NEXTVAL;

        INSERT INTO OTG_AIRFLOW_DAG_CONFIG (
            OTG_DAG_ID, FK_REPORT_ID, FK_DEST_APPID, DAG_ID, DAG_GROUP,
            DAG_URL, DAG_TYPE, SCHEDULE_INTERVAL, MAX_ACTIVE_RUNS,
            CONCURRENCY, AUTO_TRIGGER, AUTO_SKIP, TAGS, ACTIVE, CREATED_DATE
        ) VALUES (
            p_otg_dag_id, p_fk_report_id, p_fk_dest_appid, p_dag_id, p_dag_group,
            p_dag_url, p_dag_type, p_schedule,
            NVL(p_max_active_runs, 1), NVL(p_concurrency, 1),
            NVL(p_auto_trigger, 'N'), NVL(p_auto_skip, 'N'),
            p_tags, NVL(p_active, 'Y'), SYSDATE
        );

        -- Insert DAG params
        IF p_param_keys IS NOT NULL THEN
            v_keys := SPLIT_PIPE(p_param_keys);
            v_vals := SPLIT_PIPE(p_param_values);
            FOR i IN 1 .. v_keys.COUNT LOOP
                v_param_id := OTG_DAG_PARAM_SEQ.NEXTVAL;
                INSERT INTO OTG_AIRFLOW_DAG_PARAM_CONFIG (
                    ID, FK_OTG_DAG_ID, KEY, VAL, ACTIVE, CREATEDON
                ) VALUES (
                    v_param_id, p_otg_dag_id, v_keys(i),
                    CASE WHEN v_vals.EXISTS(i) THEN v_vals(i) ELSE NULL END,
                    'Y', SYSDATE
                );
            END LOOP;
        END IF;

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END CREATE_DAG;

    -- ── UPDATE_DAG ────────────────────────────────────────────────────────────
    PROCEDURE UPDATE_DAG (
        p_otg_dag_id       IN  OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE,
        p_dag_group        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE         DEFAULT NULL,
        p_dag_url          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_URL%TYPE           DEFAULT NULL,
        p_dag_type         IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE          DEFAULT NULL,
        p_schedule         IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE DEFAULT NULL,
        p_max_active_runs  IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE   DEFAULT NULL,
        p_concurrency      IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE       DEFAULT NULL,
        p_auto_trigger     IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE      DEFAULT NULL,
        p_auto_skip        IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE         DEFAULT NULL,
        p_tags             IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE              DEFAULT NULL,
        p_active           IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE            DEFAULT NULL,
        p_updatedby        IN  OTG_AIRFLOW_DAG_CONFIG.UPDATEDBY%TYPE         DEFAULT NULL
    ) IS
    BEGIN
        UPDATE OTG_AIRFLOW_DAG_CONFIG
           SET DAG_GROUP        = NVL(p_dag_group,       DAG_GROUP),
               DAG_URL          = NVL(p_dag_url,         DAG_URL),
               DAG_TYPE         = NVL(p_dag_type,        DAG_TYPE),
               SCHEDULE_INTERVAL= NVL(p_schedule,        SCHEDULE_INTERVAL),
               MAX_ACTIVE_RUNS  = NVL(p_max_active_runs, MAX_ACTIVE_RUNS),
               CONCURRENCY      = NVL(p_concurrency,     CONCURRENCY),
               AUTO_TRIGGER     = NVL(p_auto_trigger,    AUTO_TRIGGER),
               AUTO_SKIP        = NVL(p_auto_skip,       AUTO_SKIP),
               TAGS             = NVL(p_tags,            TAGS),
               ACTIVE           = NVL(p_active,          ACTIVE),
               UPDATEDON        = SYSDATE,
               UPDATEDBY        = p_updatedby
         WHERE OTG_DAG_ID = p_otg_dag_id;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'DAG ID [' || p_otg_dag_id || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END UPDATE_DAG;

    -- ── DEACTIVATE_DAG ────────────────────────────────────────────────────────
    PROCEDURE DEACTIVATE_DAG (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE,
        p_updatedby  IN OTG_AIRFLOW_DAG_CONFIG.UPDATEDBY%TYPE DEFAULT 'SYSTEM'
    ) IS
    BEGIN
        UPDATE OTG_AIRFLOW_DAG_CONFIG
           SET ACTIVE = 'N', UPDATEDON = SYSDATE, UPDATEDBY = p_updatedby
         WHERE OTG_DAG_ID = p_otg_dag_id;
        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'DAG ID [' || p_otg_dag_id || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END DEACTIVATE_DAG;

    -- ── ADD_DAG_PARAM ─────────────────────────────────────────────────────────
    PROCEDURE ADD_DAG_PARAM (
        p_otg_dag_id  IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.FK_OTG_DAG_ID%TYPE,
        p_key         IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.KEY%TYPE,
        p_val         IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.VAL%TYPE   DEFAULT NULL,
        p_active      IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.ACTIVE%TYPE DEFAULT 'Y',
        p_createdby   IN  OTG_AIRFLOW_DAG_PARAM_CONFIG.CREATEDBY%TYPE DEFAULT NULL,
        p_param_id    OUT OTG_AIRFLOW_DAG_PARAM_CONFIG.ID%TYPE
    ) IS
    BEGIN
        p_param_id := OTG_DAG_PARAM_SEQ.NEXTVAL;
        INSERT INTO OTG_AIRFLOW_DAG_PARAM_CONFIG (ID, FK_OTG_DAG_ID, KEY, VAL, ACTIVE, CREATEDON, CREATEDBY)
        VALUES (p_param_id, p_otg_dag_id, p_key, p_val, NVL(p_active,'Y'), SYSDATE, p_createdby);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END ADD_DAG_PARAM;

    -- ── DEACTIVATE_DAG_PARAM ──────────────────────────────────────────────────
    PROCEDURE DEACTIVATE_DAG_PARAM (
        p_param_id IN OTG_AIRFLOW_DAG_PARAM_CONFIG.ID%TYPE
    ) IS
    BEGIN
        UPDATE OTG_AIRFLOW_DAG_PARAM_CONFIG
           SET ACTIVE = 'N', UPDATEDON = SYSDATE
         WHERE ID = p_param_id;
        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'DAG Param ID [' || p_param_id || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END DEACTIVATE_DAG_PARAM;

    -- ── GET_DAG ───────────────────────────────────────────────────────────────
    FUNCTION GET_DAG (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT d.OTG_DAG_ID, d.FK_REPORT_ID, d.FK_DEST_APPID, d.FK_DAG_TEMPLATEID,
                   d.DAG_ID, d.DAG_GROUP, d.DAG_URL, d.DAG_TYPE, d.SCHEDULE_INTERVAL,
                   d.MAX_ACTIVE_RUNS, d.CONCURRENCY, d.AUTO_TRIGGER, d.AUTO_SKIP,
                   d.TAGS, d.ACTIVE, d.CREATED_DATE, d.UPDATEDON, d.UPDATEDBY,
                   r.FILE_NAME AS REPORT_NAME
              FROM OTG_AIRFLOW_DAG_CONFIG d
              JOIN OTG_REPORT_CONFIG      r ON r.REPORTID = d.FK_REPORT_ID
             WHERE d.OTG_DAG_ID = p_otg_dag_id;
        RETURN v_cur;
    END GET_DAG;

    -- ── LIST_DAGS ─────────────────────────────────────────────────────────────
    FUNCTION LIST_DAGS (
        p_fk_report_id IN OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE DEFAULT NULL,
        p_dag_type     IN OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE     DEFAULT NULL,
        p_active       IN OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE       DEFAULT NULL,
        p_search       IN VARCHAR2 DEFAULT NULL,
        p_limit        IN NUMBER DEFAULT 50,
        p_offset       IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT d.OTG_DAG_ID, d.FK_REPORT_ID, d.FK_DEST_APPID, d.FK_DAG_TEMPLATEID,
                   d.DAG_ID, d.DAG_GROUP, d.DAG_URL, d.DAG_TYPE, d.SCHEDULE_INTERVAL,
                   d.MAX_ACTIVE_RUNS, d.CONCURRENCY, d.AUTO_TRIGGER, d.AUTO_SKIP,
                   d.TAGS, d.ACTIVE, d.CREATED_DATE, d.UPDATEDON, d.UPDATEDBY
              FROM OTG_AIRFLOW_DAG_CONFIG d
             WHERE (p_fk_report_id IS NULL OR d.FK_REPORT_ID = p_fk_report_id)
               AND (p_dag_type     IS NULL OR d.DAG_TYPE     = p_dag_type)
               AND (p_active       IS NULL OR d.ACTIVE       = p_active)
               AND (p_search       IS NULL
                    OR LOWER(d.DAG_ID)    LIKE '%' || LOWER(p_search) || '%'
                    OR LOWER(d.DAG_GROUP) LIKE '%' || LOWER(p_search) || '%'
                    OR LOWER(d.TAGS)      LIKE '%' || LOWER(p_search) || '%')
             ORDER BY d.OTG_DAG_ID
            OFFSET p_offset ROWS FETCH NEXT p_limit ROWS ONLY;
        RETURN v_cur;
    END LIST_DAGS;

    -- ── GET_DAG_PARAMS ────────────────────────────────────────────────────────
    FUNCTION GET_DAG_PARAMS (
        p_otg_dag_id IN OTG_AIRFLOW_DAG_PARAM_CONFIG.FK_OTG_DAG_ID%TYPE
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT ID, FK_OTG_DAG_ID, FK_TASKID, KEY, VAL, ACTIVE, CREATEDON, CREATEDBY
              FROM OTG_AIRFLOW_DAG_PARAM_CONFIG
             WHERE FK_OTG_DAG_ID = p_otg_dag_id
             ORDER BY ID;
        RETURN v_cur;
    END GET_DAG_PARAMS;

END PKG_DAG_CONFIG;
/

SHOW ERRORS PACKAGE BODY PKG_DAG_CONFIG;
