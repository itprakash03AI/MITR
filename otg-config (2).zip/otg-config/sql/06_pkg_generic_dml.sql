-- ============================================================
-- 06_pkg_generic_dml.sql
-- Generic DML Package + Audit Infrastructure
--
-- Design principles:
--  1. ALL allowed tables + columns registered in OTG_DML_TABLE_REGISTRY
--  2. Oracle validates table/column against registry BEFORE any EXECUTE IMMEDIATE
--  3. Every operation written to OTG_DML_AUDIT_LOG (immutable, no DELETE)
--  4. Python passes column-value pairs as pipe-separated strings
--  5. No raw SQL ever reaches Python — Oracle builds and executes the statement
-- ============================================================

-- ── Audit Log Table ────────────────────────────────────────────────────────

CREATE TABLE OTG_DML_AUDIT_LOG (
    AUDIT_ID        NUMBER(15)      NOT NULL,
    OPERATION       VARCHAR2(10)    NOT NULL,      -- INSERT | UPDATE
    TABLE_NAME      VARCHAR2(100)   NOT NULL,
    PK_COLUMN       VARCHAR2(100),
    PK_VALUE        VARCHAR2(500),
    COLUMNS_CHANGED VARCHAR2(4000),                -- pipe-separated col=val pairs
    ROW_COUNT       NUMBER(10)      DEFAULT 0,
    STATUS          VARCHAR2(20)    DEFAULT 'OK',  -- OK | ERROR
    ERROR_MSG       VARCHAR2(2000),
    EXECUTED_BY     VARCHAR2(200)   NOT NULL,       -- AD username
    AD_GROUPS       VARCHAR2(1000),                 -- AD groups at time of call
    CLIENT_IP       VARCHAR2(100),
    EXECUTED_ON     TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    SESSION_ID      VARCHAR2(200),
    CONSTRAINT PK_DML_AUDIT         PRIMARY KEY (AUDIT_ID),
    CONSTRAINT CHK_AUDIT_OP         CHECK (OPERATION IN ('INSERT','UPDATE'))
);

COMMENT ON TABLE  OTG_DML_AUDIT_LOG IS 'Immutable audit log for all generic DML operations';
COMMENT ON COLUMN OTG_DML_AUDIT_LOG.EXECUTED_BY IS 'AD sAMAccountName of the user';

CREATE SEQUENCE OTG_DML_AUDIT_SEQ START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE INDEX IDX_AUDIT_TABLE   ON OTG_DML_AUDIT_LOG(TABLE_NAME);
CREATE INDEX IDX_AUDIT_USER    ON OTG_DML_AUDIT_LOG(EXECUTED_BY);
CREATE INDEX IDX_AUDIT_DATE    ON OTG_DML_AUDIT_LOG(EXECUTED_ON);


-- ── Table Registry — what tables + columns are DML-allowed ────────────────────

CREATE TABLE OTG_DML_TABLE_REGISTRY (
    REGISTRY_ID     NUMBER(10)      NOT NULL,
    TABLE_NAME      VARCHAR2(100)   NOT NULL,
    COLUMN_NAME     VARCHAR2(100)   NOT NULL,
    COLUMN_DATATYPE VARCHAR2(50)    NOT NULL,  -- VARCHAR2 | NUMBER | DATE | CHAR
    IS_PK           CHAR(1)         DEFAULT 'N' NOT NULL,
    IS_NULLABLE     CHAR(1)         DEFAULT 'Y' NOT NULL,
    ALLOW_INSERT    CHAR(1)         DEFAULT 'Y' NOT NULL,
    ALLOW_UPDATE    CHAR(1)         DEFAULT 'Y' NOT NULL,
    MIN_GROUP       VARCHAR2(100)   DEFAULT 'OTG_SUPPORT',  -- minimum AD group required
    DISPLAY_LABEL   VARCHAR2(200),
    DISPLAY_ORDER   NUMBER(5)       DEFAULT 99,
    ACTIVE          CHAR(1)         DEFAULT 'Y' NOT NULL,
    CONSTRAINT PK_DML_REGISTRY      PRIMARY KEY (REGISTRY_ID),
    CONSTRAINT UQ_REGISTRY_COL      UNIQUE (TABLE_NAME, COLUMN_NAME),
    CONSTRAINT CHK_REG_ACTIVE       CHECK (ACTIVE IN ('Y','N')),
    CONSTRAINT CHK_REG_IS_PK        CHECK (IS_PK IN ('Y','N')),
    CONSTRAINT CHK_REG_NULLABLE     CHECK (IS_NULLABLE IN ('Y','N')),
    CONSTRAINT CHK_REG_INS          CHECK (ALLOW_INSERT IN ('Y','N')),
    CONSTRAINT CHK_REG_UPD          CHECK (ALLOW_UPDATE IN ('Y','N'))
);

CREATE SEQUENCE OTG_DML_REGISTRY_SEQ START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE INDEX IDX_REG_TABLE ON OTG_DML_TABLE_REGISTRY(TABLE_NAME);


-- ── Seed Registry: register all OTG columns available for generic DML ─────────
-- OTG_APP_CONFIG
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','APPID','NUMBER','Y','N','N','N','OTG_ADMIN','App ID',1,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','APPNAME','VARCHAR2','N','N','Y','Y','OTG_SUPPORT','App Name',2,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','ENV','VARCHAR2','N','N','Y','Y','OTG_SUPPORT','Environment',3,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','HOSTNAME','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','Hostname',4,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','DB_TYPE','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','DB Type',5,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','DB_CONNECTION','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','Connection',6,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_APP_CONFIG','ACTIVE','CHAR','N','N','Y','Y','OTG_SUPPORT','Active',7,'Y');

-- OTG_REPORT_CONFIG
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','REPORTID','NUMBER','Y','N','N','N','OTG_ADMIN','Report ID',1,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','FK_APPID','NUMBER','N','N','Y','Y','OTG_SUPPORT','App ID',2,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','FILE_TYPE','VARCHAR2','N','N','Y','Y','OTG_SUPPORT','File Type',3,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','FILE_NAME','VARCHAR2','N','N','Y','Y','OTG_SUPPORT','File Name',4,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','FILE_FORMAT','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','File Format',5,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','FILE_LOCATION','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','File Location',6,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','REPORT_DESCRIPTION','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','Description',7,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','PRIORITY','NUMBER','N','N','Y','Y','OTG_SUPPORT','Priority',8,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_REPORT_CONFIG','ACTIVE','CHAR','N','N','Y','Y','OTG_SUPPORT','Active',9,'Y');

-- OTG_AIRFLOW_DAG_CONFIG
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','OTG_DAG_ID','NUMBER','Y','N','N','N','OTG_ADMIN','DAG ID',1,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','DAG_ID','VARCHAR2','N','N','Y','N','OTG_ADMIN','DAG Identifier',2,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','DAG_GROUP','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','DAG Group',3,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','SCHEDULE_INTERVAL','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','Schedule',4,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','MAX_ACTIVE_RUNS','NUMBER','N','N','Y','Y','OTG_SUPPORT','Max Active Runs',5,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','CONCURRENCY','NUMBER','N','N','Y','Y','OTG_SUPPORT','Concurrency',6,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','AUTO_TRIGGER','CHAR','N','N','Y','Y','OTG_SUPPORT','Auto Trigger',7,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','AUTO_SKIP','CHAR','N','N','Y','Y','OTG_SUPPORT','Auto Skip',8,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','ACTIVE','CHAR','N','N','Y','Y','OTG_SUPPORT','Active',9,'Y');
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (OTG_DML_REGISTRY_SEQ.NEXTVAL,'OTG_AIRFLOW_DAG_CONFIG','TAGS','VARCHAR2','N','Y','Y','Y','OTG_SUPPORT','Tags',10,'Y');

COMMIT;


-- ── PKG_GENERIC_DML Package Spec ──────────────────────────────────────────────

CREATE OR REPLACE PACKAGE PKG_GENERIC_DML AS

    EX_TABLE_NOT_ALLOWED    EXCEPTION;
    EX_COLUMN_NOT_ALLOWED   EXCEPTION;
    EX_NO_PK_FOR_UPDATE     EXCEPTION;
    EX_INSUFFICIENT_ACCESS  EXCEPTION;
    PRAGMA EXCEPTION_INIT(EX_TABLE_NOT_ALLOWED,   -20010);
    PRAGMA EXCEPTION_INIT(EX_COLUMN_NOT_ALLOWED,  -20011);
    PRAGMA EXCEPTION_INIT(EX_NO_PK_FOR_UPDATE,    -20012);
    PRAGMA EXCEPTION_INIT(EX_INSUFFICIENT_ACCESS, -20013);

    /**
     * Generic INSERT on any registered OTG table.
     *
     * p_table_name  : exact table name (validated against registry)
     * p_col_names   : pipe-separated column names  e.g. "APPNAME|ENV|HOSTNAME"
     * p_col_values  : pipe-separated column values e.g. "SalesDB|PROD|db.company.com"
     * p_executed_by : AD sAMAccountName
     * p_ad_groups   : pipe-separated AD groups of caller
     * p_client_ip   : caller IP (from HTTP header)
     * p_row_count   : OUT — rows inserted (1 on success)
     * p_audit_id    : OUT — audit log ID
     */
    PROCEDURE GENERIC_INSERT (
        p_table_name    IN  VARCHAR2,
        p_col_names     IN  VARCHAR2,
        p_col_values    IN  VARCHAR2,
        p_executed_by   IN  VARCHAR2,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,
        p_client_ip     IN  VARCHAR2 DEFAULT NULL,
        p_row_count     OUT NUMBER,
        p_audit_id      OUT NUMBER
    );

    /**
     * Generic UPDATE on any registered OTG table.
     *
     * p_pk_column  : PK column name (must be registered as IS_PK='Y')
     * p_pk_value   : PK value to identify the row
     * p_col_names  : pipe-separated columns to update
     * p_col_values : pipe-separated new values
     */
    PROCEDURE GENERIC_UPDATE (
        p_table_name    IN  VARCHAR2,
        p_pk_column     IN  VARCHAR2,
        p_pk_value      IN  VARCHAR2,
        p_col_names     IN  VARCHAR2,
        p_col_values    IN  VARCHAR2,
        p_executed_by   IN  VARCHAR2,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,
        p_client_ip     IN  VARCHAR2 DEFAULT NULL,
        p_row_count     OUT NUMBER,
        p_audit_id      OUT NUMBER
    );

    /**
     * Returns registered tables and their columns as SYS_REFCURSOR.
     * Used by the UI to dynamically build forms.
     */
    FUNCTION LIST_ALLOWED_TABLES (
        p_ad_groups IN VARCHAR2 DEFAULT NULL   -- filter by group visibility
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_TABLE_COLUMNS (
        p_table_name IN VARCHAR2
    ) RETURN SYS_REFCURSOR;

    /**
     * Returns audit log entries.
     */
    FUNCTION GET_AUDIT_LOG (
        p_table_name    IN VARCHAR2 DEFAULT NULL,
        p_executed_by   IN VARCHAR2 DEFAULT NULL,
        p_from_date     IN DATE     DEFAULT NULL,
        p_limit         IN NUMBER   DEFAULT 100,
        p_offset        IN NUMBER   DEFAULT 0
    ) RETURN SYS_REFCURSOR;

END PKG_GENERIC_DML;
/


-- ── PKG_GENERIC_DML Package Body ──────────────────────────────────────────────

CREATE OR REPLACE PACKAGE BODY PKG_GENERIC_DML AS

    -- ── Private: split pipe-separated string ─────────────────────────────────
    TYPE t_str_arr IS TABLE OF VARCHAR2(4000) INDEX BY PLS_INTEGER;

    FUNCTION SPLIT_PIPE (p_str IN VARCHAR2) RETURN t_str_arr IS
        v_arr t_str_arr; v_str VARCHAR2(32767) := p_str;
        v_pos NUMBER; v_idx PLS_INTEGER := 1;
    BEGIN
        IF p_str IS NULL THEN RETURN v_arr; END IF;
        LOOP
            v_pos := INSTR(v_str, '|');
            IF v_pos = 0 THEN v_arr(v_idx) := v_str; EXIT; END IF;
            v_arr(v_idx) := SUBSTR(v_str, 1, v_pos - 1);
            v_str := SUBSTR(v_str, v_pos + 1);
            v_idx := v_idx + 1;
        END LOOP;
        RETURN v_arr;
    END SPLIT_PIPE;

    -- ── Private: validate table is in registry ────────────────────────────────
    PROCEDURE VALIDATE_TABLE (p_table_name IN VARCHAR2) IS
        v_cnt NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt
          FROM OTG_DML_TABLE_REGISTRY
         WHERE TABLE_NAME = UPPER(TRIM(p_table_name))
           AND ACTIVE = 'Y'
           AND ROWNUM = 1;
        IF v_cnt = 0 THEN
            RAISE_APPLICATION_ERROR(-20010,
                'Table [' || p_table_name || '] is not registered for generic DML');
        END IF;
    END VALIDATE_TABLE;

    -- ── Private: validate a column for a specific operation ───────────────────
    PROCEDURE VALIDATE_COLUMN (
        p_table_name  IN VARCHAR2,
        p_column_name IN VARCHAR2,
        p_operation   IN VARCHAR2,   -- INSERT | UPDATE
        p_ad_groups   IN VARCHAR2
    ) IS
        v_cnt       NUMBER;
        v_min_group VARCHAR2(100);
    BEGIN
        SELECT COUNT(*), MAX(MIN_GROUP)
          INTO v_cnt, v_min_group
          FROM OTG_DML_TABLE_REGISTRY
         WHERE TABLE_NAME  = UPPER(TRIM(p_table_name))
           AND COLUMN_NAME = UPPER(TRIM(p_column_name))
           AND ACTIVE      = 'Y'
           AND CASE p_operation
                 WHEN 'INSERT' THEN ALLOW_INSERT
                 WHEN 'UPDATE' THEN ALLOW_UPDATE
                 ELSE 'N'
               END = 'Y';

        IF v_cnt = 0 THEN
            RAISE_APPLICATION_ERROR(-20011,
                'Column [' || p_column_name || '] on table [' || p_table_name ||
                '] is not allowed for ' || p_operation);
        END IF;

        -- Group check: OTG_ADMIN satisfies any MIN_GROUP requirement
        IF v_min_group = 'OTG_ADMIN'
           AND INSTR(NVL(p_ad_groups,''), 'OTG_ADMIN') = 0 THEN
            RAISE_APPLICATION_ERROR(-20013,
                'Column [' || p_column_name || '] requires OTG_ADMIN group');
        END IF;
    END VALIDATE_COLUMN;

    -- ── Private: write to audit log (never throws) ────────────────────────────
    PROCEDURE WRITE_AUDIT (
        p_operation     IN VARCHAR2,
        p_table_name    IN VARCHAR2,
        p_pk_column     IN VARCHAR2,
        p_pk_value      IN VARCHAR2,
        p_col_pairs     IN VARCHAR2,
        p_row_count     IN NUMBER,
        p_status        IN VARCHAR2,
        p_error_msg     IN VARCHAR2,
        p_executed_by   IN VARCHAR2,
        p_ad_groups     IN VARCHAR2,
        p_client_ip     IN VARCHAR2,
        p_audit_id      OUT NUMBER
    ) IS
        PRAGMA AUTONOMOUS_TRANSACTION;   -- audit always commits regardless of caller tx
    BEGIN
        p_audit_id := OTG_DML_AUDIT_SEQ.NEXTVAL;
        INSERT INTO OTG_DML_AUDIT_LOG (
            AUDIT_ID, OPERATION, TABLE_NAME, PK_COLUMN, PK_VALUE,
            COLUMNS_CHANGED, ROW_COUNT, STATUS, ERROR_MSG,
            EXECUTED_BY, AD_GROUPS, CLIENT_IP, EXECUTED_ON, SESSION_ID
        ) VALUES (
            p_audit_id, p_operation, UPPER(p_table_name), p_pk_column, p_pk_value,
            SUBSTR(p_col_pairs, 1, 4000), NVL(p_row_count, 0),
            p_status, SUBSTR(p_error_msg, 1, 2000),
            p_executed_by, p_ad_groups, p_client_ip,
            SYSTIMESTAMP,
            SYS_CONTEXT('USERENV','SESSION_USER') || ':' || SYS_CONTEXT('USERENV','SESSIONID')
        );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;  -- audit failure should not break main operation
    END WRITE_AUDIT;

    -- ── GENERIC_INSERT ────────────────────────────────────────────────────────
    PROCEDURE GENERIC_INSERT (
        p_table_name    IN  VARCHAR2,
        p_col_names     IN  VARCHAR2,
        p_col_values    IN  VARCHAR2,
        p_executed_by   IN  VARCHAR2,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,
        p_client_ip     IN  VARCHAR2 DEFAULT NULL,
        p_row_count     OUT NUMBER,
        p_audit_id      OUT NUMBER
    ) IS
        v_cols      t_str_arr;
        v_vals      t_str_arr;
        v_col_list  VARCHAR2(4000) := '';
        v_bind_list VARCHAR2(4000) := '';
        v_sql       VARCHAR2(8000);
        v_binds     DBMS_SQL.VARCHAR2_TABLE;
        v_cur       INTEGER;
        v_pairs     VARCHAR2(4000) := '';
        v_err_msg   VARCHAR2(2000);
        v_table     VARCHAR2(100) := UPPER(TRIM(p_table_name));
    BEGIN
        VALIDATE_TABLE(v_table);

        v_cols := SPLIT_PIPE(p_col_names);
        v_vals := SPLIT_PIPE(p_col_values);

        IF v_cols.COUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20011, 'No columns provided for INSERT');
        END IF;

        -- Validate every column and build SQL fragments
        FOR i IN 1 .. v_cols.COUNT LOOP
            VALIDATE_COLUMN(v_table, v_cols(i), 'INSERT', p_ad_groups);
            v_col_list  := v_col_list  || UPPER(TRIM(v_cols(i))) || ',';
            v_bind_list := v_bind_list || ':b' || i || ',';
            v_pairs     := v_pairs || UPPER(TRIM(v_cols(i))) || '=' ||
                           SUBSTR(NVL(v_vals(i),''), 1, 200) || '|';
        END LOOP;

        v_col_list  := RTRIM(v_col_list,  ',');
        v_bind_list := RTRIM(v_bind_list, ',');
        v_sql := 'INSERT INTO ' || v_table || ' (' || v_col_list || ') VALUES (' || v_bind_list || ')';

        -- Execute using DBMS_SQL for dynamic bind variables
        v_cur := DBMS_SQL.OPEN_CURSOR;
        BEGIN
            DBMS_SQL.PARSE(v_cur, v_sql, DBMS_SQL.NATIVE);
            FOR i IN 1 .. v_cols.COUNT LOOP
                DBMS_SQL.BIND_VARIABLE(v_cur, ':b' || i,
                    CASE WHEN v_vals.EXISTS(i) THEN v_vals(i) ELSE NULL END);
            END LOOP;
            p_row_count := DBMS_SQL.EXECUTE(v_cur);
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_SQL.CLOSE_CURSOR(v_cur);
                v_err_msg := SQLERRM;
                WRITE_AUDIT('INSERT', v_table, NULL, NULL, v_pairs, 0,
                            'ERROR', v_err_msg, p_executed_by, p_ad_groups,
                            p_client_ip, p_audit_id);
                RAISE;
        END;
        DBMS_SQL.CLOSE_CURSOR(v_cur);

        WRITE_AUDIT('INSERT', v_table, NULL, NULL, v_pairs, p_row_count,
                    'OK', NULL, p_executed_by, p_ad_groups, p_client_ip, p_audit_id);
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END GENERIC_INSERT;

    -- ── GENERIC_UPDATE ────────────────────────────────────────────────────────
    PROCEDURE GENERIC_UPDATE (
        p_table_name    IN  VARCHAR2,
        p_pk_column     IN  VARCHAR2,
        p_pk_value      IN  VARCHAR2,
        p_col_names     IN  VARCHAR2,
        p_col_values    IN  VARCHAR2,
        p_executed_by   IN  VARCHAR2,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,
        p_client_ip     IN  VARCHAR2 DEFAULT NULL,
        p_row_count     OUT NUMBER,
        p_audit_id      OUT NUMBER
    ) IS
        v_cols       t_str_arr;
        v_vals       t_str_arr;
        v_set_clause VARCHAR2(4000) := '';
        v_sql        VARCHAR2(8000);
        v_cur        INTEGER;
        v_pk_cnt     NUMBER;
        v_pairs      VARCHAR2(4000) := '';
        v_err_msg    VARCHAR2(2000);
        v_table      VARCHAR2(100) := UPPER(TRIM(p_table_name));
        v_pk_col     VARCHAR2(100) := UPPER(TRIM(p_pk_column));
    BEGIN
        VALIDATE_TABLE(v_table);

        -- Confirm PK column is registered as PK
        SELECT COUNT(*) INTO v_pk_cnt
          FROM OTG_DML_TABLE_REGISTRY
         WHERE TABLE_NAME  = v_table
           AND COLUMN_NAME = v_pk_col
           AND IS_PK       = 'Y'
           AND ACTIVE      = 'Y';

        IF v_pk_cnt = 0 THEN
            RAISE_APPLICATION_ERROR(-20012,
                'Column [' || v_pk_col || '] is not a registered PK for ' || v_table);
        END IF;

        v_cols := SPLIT_PIPE(p_col_names);
        v_vals := SPLIT_PIPE(p_col_values);

        IF v_cols.COUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20011, 'No columns provided for UPDATE');
        END IF;

        FOR i IN 1 .. v_cols.COUNT LOOP
            VALIDATE_COLUMN(v_table, v_cols(i), 'UPDATE', p_ad_groups);
            v_set_clause := v_set_clause || UPPER(TRIM(v_cols(i))) || '=:b' || i || ',';
            v_pairs := v_pairs || UPPER(TRIM(v_cols(i))) || '=' ||
                       SUBSTR(NVL(v_vals(i),''), 1, 200) || '|';
        END LOOP;

        v_set_clause := RTRIM(v_set_clause, ',');
        -- PK bind is always :pk — separated from column binds for clarity
        v_sql := 'UPDATE ' || v_table || ' SET ' || v_set_clause ||
                 ' WHERE ' || v_pk_col || '=:pk';

        v_cur := DBMS_SQL.OPEN_CURSOR;
        BEGIN
            DBMS_SQL.PARSE(v_cur, v_sql, DBMS_SQL.NATIVE);
            FOR i IN 1 .. v_cols.COUNT LOOP
                DBMS_SQL.BIND_VARIABLE(v_cur, ':b' || i,
                    CASE WHEN v_vals.EXISTS(i) THEN v_vals(i) ELSE NULL END);
            END LOOP;
            DBMS_SQL.BIND_VARIABLE(v_cur, ':pk', p_pk_value);
            p_row_count := DBMS_SQL.EXECUTE(v_cur);
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_SQL.CLOSE_CURSOR(v_cur);
                v_err_msg := SQLERRM;
                WRITE_AUDIT('UPDATE', v_table, v_pk_col, p_pk_value, v_pairs, 0,
                            'ERROR', v_err_msg, p_executed_by, p_ad_groups,
                            p_client_ip, p_audit_id);
                RAISE;
        END;
        DBMS_SQL.CLOSE_CURSOR(v_cur);

        IF p_row_count = 0 THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,
                'No row found in ' || v_table || ' where ' || v_pk_col || '=' || p_pk_value);
        END IF;

        WRITE_AUDIT('UPDATE', v_table, v_pk_col, p_pk_value, v_pairs, p_row_count,
                    'OK', NULL, p_executed_by, p_ad_groups, p_client_ip, p_audit_id);
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END GENERIC_UPDATE;

    -- ── LIST_ALLOWED_TABLES ───────────────────────────────────────────────────
    FUNCTION LIST_ALLOWED_TABLES (
        p_ad_groups IN VARCHAR2 DEFAULT NULL
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT DISTINCT TABLE_NAME,
                   COUNT(*) AS COLUMN_COUNT,
                   SUM(CASE WHEN ALLOW_INSERT='Y' THEN 1 ELSE 0 END) AS INSERTABLE_COLS,
                   SUM(CASE WHEN ALLOW_UPDATE='Y' THEN 1 ELSE 0 END) AS UPDATABLE_COLS
              FROM OTG_DML_TABLE_REGISTRY
             WHERE ACTIVE = 'Y'
               AND (p_ad_groups IS NULL
                    OR MIN_GROUP = 'OTG_SUPPORT'           -- support can see all
                    OR INSTR(NVL(p_ad_groups,''), 'OTG_ADMIN') > 0)
             GROUP BY TABLE_NAME
             ORDER BY TABLE_NAME;
        RETURN v_cur;
    END LIST_ALLOWED_TABLES;

    -- ── GET_TABLE_COLUMNS ─────────────────────────────────────────────────────
    FUNCTION GET_TABLE_COLUMNS (
        p_table_name IN VARCHAR2
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT COLUMN_NAME, COLUMN_DATATYPE, IS_PK, IS_NULLABLE,
                   ALLOW_INSERT, ALLOW_UPDATE, MIN_GROUP,
                   DISPLAY_LABEL, DISPLAY_ORDER
              FROM OTG_DML_TABLE_REGISTRY
             WHERE TABLE_NAME = UPPER(TRIM(p_table_name))
               AND ACTIVE     = 'Y'
             ORDER BY DISPLAY_ORDER;
        RETURN v_cur;
    END GET_TABLE_COLUMNS;

    -- ── GET_AUDIT_LOG ─────────────────────────────────────────────────────────
    FUNCTION GET_AUDIT_LOG (
        p_table_name    IN VARCHAR2 DEFAULT NULL,
        p_executed_by   IN VARCHAR2 DEFAULT NULL,
        p_from_date     IN DATE     DEFAULT NULL,
        p_limit         IN NUMBER   DEFAULT 100,
        p_offset        IN NUMBER   DEFAULT 0
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT AUDIT_ID, OPERATION, TABLE_NAME, PK_COLUMN, PK_VALUE,
                   COLUMNS_CHANGED, ROW_COUNT, STATUS, ERROR_MSG,
                   EXECUTED_BY, AD_GROUPS, CLIENT_IP, EXECUTED_ON
              FROM OTG_DML_AUDIT_LOG
             WHERE (p_table_name  IS NULL OR TABLE_NAME  = UPPER(p_table_name))
               AND (p_executed_by IS NULL OR LOWER(EXECUTED_BY) = LOWER(p_executed_by))
               AND (p_from_date   IS NULL OR TRUNC(EXECUTED_ON) >= TRUNC(p_from_date))
             ORDER BY EXECUTED_ON DESC
            OFFSET p_offset ROWS FETCH NEXT p_limit ROWS ONLY;
        RETURN v_cur;
    END GET_AUDIT_LOG;

END PKG_GENERIC_DML;
/

SHOW ERRORS PACKAGE BODY PKG_GENERIC_DML;
COMMIT;
