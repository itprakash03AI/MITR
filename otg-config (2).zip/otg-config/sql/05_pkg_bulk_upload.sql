-- ============================================================
-- 05_pkg_bulk_upload.sql
-- Package: PKG_BULK_UPLOAD
-- Handles bulk INSERT operations called from Python upload router.
-- Python passes each row; the package handles validation + insert.
-- ============================================================

CREATE OR REPLACE PACKAGE PKG_BULK_UPLOAD AS

    /**
     * Bulk insert a single REPORT row.
     * Called once per validated Excel row from Python.
     * Returns the generated REPORTID or raises an application error.
     */
    PROCEDURE INSERT_REPORT_ROW (
        p_fk_appid      IN  OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT 5,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_CONFIG.CREATED_BY%TYPE        DEFAULT 'BULK_UPLOAD',
        p_reportid      OUT OTG_REPORT_CONFIG.REPORTID%TYPE
    );

    /**
     * Bulk insert a single DAG row.
     */
    PROCEDURE INSERT_DAG_ROW (
        p_fk_report_id    IN  OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_fk_dest_appid   IN  OTG_AIRFLOW_DAG_CONFIG.FK_DEST_APPID%TYPE     DEFAULT NULL,
        p_dag_id          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE,
        p_dag_group       IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE         DEFAULT NULL,
        p_dag_type        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE          DEFAULT NULL,
        p_schedule        IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE DEFAULT NULL,
        p_max_active_runs IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE   DEFAULT 1,
        p_concurrency     IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE       DEFAULT 1,
        p_auto_trigger    IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE      DEFAULT 'N',
        p_auto_skip       IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE         DEFAULT 'N',
        p_tags            IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE              DEFAULT NULL,
        p_active          IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_otg_dag_id      OUT OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    );

    /**
     * Bulk insert a single APP row.
     */
    PROCEDURE INSERT_APP_ROW (
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT 'Y',
        p_created_by    IN  OTG_APP_CONFIG.CREATEDBY%TYPE      DEFAULT 'BULK_UPLOAD',
        p_appid         OUT OTG_APP_CONFIG.APPID%TYPE
    );

    /**
     * Validate a report row without inserting.
     * Returns error message or NULL if valid.
     */
    FUNCTION VALIDATE_REPORT_ROW (
        p_fk_appid  IN OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type IN OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name IN OTG_REPORT_CONFIG.FILE_NAME%TYPE
    ) RETURN VARCHAR2;

    /**
     * Validate a DAG row without inserting.
     */
    FUNCTION VALIDATE_DAG_ROW (
        p_fk_report_id IN OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_dag_id       IN OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE
    ) RETURN VARCHAR2;

    /**
     * Validate an APP row without inserting.
     */
    FUNCTION VALIDATE_APP_ROW (
        p_appname IN OTG_APP_CONFIG.APPNAME%TYPE,
        p_env     IN OTG_APP_CONFIG.ENV%TYPE
    ) RETURN VARCHAR2;

END PKG_BULK_UPLOAD;
/

CREATE OR REPLACE PACKAGE BODY PKG_BULK_UPLOAD AS

    -- Note: each row is committed by the Python layer after collecting results.
    -- These procedures do NOT commit — Python calls COMMIT after all rows succeed,
    -- or ROLLBACK on failure. This gives Python control over transaction scope.

    PROCEDURE INSERT_REPORT_ROW (
        p_fk_appid      IN  OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT 5,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_CONFIG.CREATED_BY%TYPE        DEFAULT 'BULK_UPLOAD',
        p_reportid      OUT OTG_REPORT_CONFIG.REPORTID%TYPE
    ) IS
    BEGIN
        p_reportid := OTG_REPORT_CONFIG_SEQ.NEXTVAL;
        INSERT INTO OTG_REPORT_CONFIG (
            REPORTID, FK_APPID, FILE_TYPE, FILE_NAME, FILE_FORMAT,
            FILE_LOCATION, REPORT_DESCRIPTION, PRIORITY, ACTIVE, CREATED_ON, CREATED_BY
        ) VALUES (
            p_reportid, p_fk_appid, p_file_type, p_file_name, p_file_format,
            p_file_location, p_description,
            NVL(p_priority, 5), NVL(p_active, 'Y'), SYSDATE, p_created_by
        );
        -- No COMMIT: caller (Python) controls the transaction
    END INSERT_REPORT_ROW;

    PROCEDURE INSERT_DAG_ROW (
        p_fk_report_id    IN  OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_fk_dest_appid   IN  OTG_AIRFLOW_DAG_CONFIG.FK_DEST_APPID%TYPE     DEFAULT NULL,
        p_dag_id          IN  OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE,
        p_dag_group       IN  OTG_AIRFLOW_DAG_CONFIG.DAG_GROUP%TYPE         DEFAULT NULL,
        p_dag_type        IN  OTG_AIRFLOW_DAG_CONFIG.DAG_TYPE%TYPE          DEFAULT NULL,
        p_schedule        IN  OTG_AIRFLOW_DAG_CONFIG.SCHEDULE_INTERVAL%TYPE DEFAULT NULL,
        p_max_active_runs IN  OTG_AIRFLOW_DAG_CONFIG.MAX_ACTIVE_RUNS%TYPE   DEFAULT 1,
        p_concurrency     IN  OTG_AIRFLOW_DAG_CONFIG.CONCURRENCY%TYPE       DEFAULT 1,
        p_auto_trigger    IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_TRIGGER%TYPE      DEFAULT 'N',
        p_auto_skip       IN  OTG_AIRFLOW_DAG_CONFIG.AUTO_SKIP%TYPE         DEFAULT 'N',
        p_tags            IN  OTG_AIRFLOW_DAG_CONFIG.TAGS%TYPE              DEFAULT NULL,
        p_active          IN  OTG_AIRFLOW_DAG_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_otg_dag_id      OUT OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID%TYPE
    ) IS
    BEGIN
        p_otg_dag_id := OTG_DAG_CONFIG_SEQ.NEXTVAL;
        INSERT INTO OTG_AIRFLOW_DAG_CONFIG (
            OTG_DAG_ID, FK_REPORT_ID, FK_DEST_APPID, DAG_ID, DAG_GROUP,
            DAG_TYPE, SCHEDULE_INTERVAL, MAX_ACTIVE_RUNS, CONCURRENCY,
            AUTO_TRIGGER, AUTO_SKIP, TAGS, ACTIVE, CREATED_DATE
        ) VALUES (
            p_otg_dag_id, p_fk_report_id, p_fk_dest_appid, p_dag_id, p_dag_group,
            p_dag_type, p_schedule,
            NVL(p_max_active_runs,1), NVL(p_concurrency,1),
            NVL(p_auto_trigger,'N'), NVL(p_auto_skip,'N'),
            p_tags, NVL(p_active,'Y'), SYSDATE
        );
    END INSERT_DAG_ROW;

    PROCEDURE INSERT_APP_ROW (
        p_appname       IN  OTG_APP_CONFIG.APPNAME%TYPE,
        p_env           IN  OTG_APP_CONFIG.ENV%TYPE,
        p_hostname      IN  OTG_APP_CONFIG.HOSTNAME%TYPE       DEFAULT NULL,
        p_db_type       IN  OTG_APP_CONFIG.DB_TYPE%TYPE        DEFAULT NULL,
        p_db_connection IN  OTG_APP_CONFIG.DB_CONNECTION%TYPE  DEFAULT NULL,
        p_active        IN  OTG_APP_CONFIG.ACTIVE%TYPE         DEFAULT 'Y',
        p_created_by    IN  OTG_APP_CONFIG.CREATEDBY%TYPE      DEFAULT 'BULK_UPLOAD',
        p_appid         OUT OTG_APP_CONFIG.APPID%TYPE
    ) IS
    BEGIN
        p_appid := OTG_APP_CONFIG_SEQ.NEXTVAL;
        INSERT INTO OTG_APP_CONFIG (
            APPID, APPNAME, ENV, HOSTNAME, DB_TYPE, DB_CONNECTION, ACTIVE, CREATEDON, CREATEDBY
        ) VALUES (
            p_appid, p_appname, p_env, p_hostname, p_db_type, p_db_connection,
            NVL(p_active,'Y'), SYSDATE, p_created_by
        );
    END INSERT_APP_ROW;

    FUNCTION VALIDATE_REPORT_ROW (
        p_fk_appid  IN OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type IN OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name IN OTG_REPORT_CONFIG.FILE_NAME%TYPE
    ) RETURN VARCHAR2 IS
        v_count NUMBER;
    BEGIN
        IF p_file_name IS NULL THEN RETURN 'file_name: required'; END IF;
        IF p_file_type NOT IN ('CSV','PARQUET','EXCEL','JSON','ORC') THEN
            RETURN 'file_type: must be CSV|PARQUET|EXCEL|JSON|ORC';
        END IF;
        SELECT COUNT(*) INTO v_count FROM OTG_APP_CONFIG WHERE APPID = p_fk_appid;
        IF v_count = 0 THEN RETURN 'fk_appid: App ID ' || p_fk_appid || ' not found'; END IF;
        RETURN NULL;  -- NULL = valid
    END VALIDATE_REPORT_ROW;

    FUNCTION VALIDATE_DAG_ROW (
        p_fk_report_id IN OTG_AIRFLOW_DAG_CONFIG.FK_REPORT_ID%TYPE,
        p_dag_id       IN OTG_AIRFLOW_DAG_CONFIG.DAG_ID%TYPE
    ) RETURN VARCHAR2 IS
        v_count NUMBER;
    BEGIN
        IF p_dag_id IS NULL THEN RETURN 'dag_id: required'; END IF;
        SELECT COUNT(*) INTO v_count FROM OTG_REPORT_CONFIG WHERE REPORTID = p_fk_report_id;
        IF v_count = 0 THEN RETURN 'fk_report_id: Report ID ' || p_fk_report_id || ' not found'; END IF;
        SELECT COUNT(*) INTO v_count FROM OTG_AIRFLOW_DAG_CONFIG WHERE DAG_ID = p_dag_id;
        IF v_count > 0 THEN RETURN 'dag_id: [' || p_dag_id || '] already exists'; END IF;
        RETURN NULL;
    END VALIDATE_DAG_ROW;

    FUNCTION VALIDATE_APP_ROW (
        p_appname IN OTG_APP_CONFIG.APPNAME%TYPE,
        p_env     IN OTG_APP_CONFIG.ENV%TYPE
    ) RETURN VARCHAR2 IS
        v_count NUMBER;
    BEGIN
        IF p_appname IS NULL THEN RETURN 'appname: required'; END IF;
        IF p_env NOT IN ('DEV','QA','UAT','PROD','STAGING') THEN
            RETURN 'env: must be DEV|QA|UAT|PROD|STAGING';
        END IF;
        SELECT COUNT(*) INTO v_count FROM OTG_APP_CONFIG
         WHERE APPNAME = p_appname AND ENV = p_env;
        IF v_count > 0 THEN RETURN 'appname+env: [' || p_appname || '/' || p_env || '] already exists'; END IF;
        RETURN NULL;
    END VALIDATE_APP_ROW;

END PKG_BULK_UPLOAD;
/

SHOW ERRORS PACKAGE BODY PKG_BULK_UPLOAD;
