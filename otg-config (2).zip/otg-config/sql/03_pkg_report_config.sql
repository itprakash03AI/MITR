-- ============================================================
-- 03_pkg_report_config.sql
-- Package: PKG_REPORT_CONFIG
-- Manages OTG_REPORT_CONFIG + OTG_REPORT_PARAM_CONFIG
-- ============================================================

CREATE OR REPLACE PACKAGE PKG_REPORT_CONFIG AS

    EX_NOT_FOUND    EXCEPTION;
    EX_INVALID_APP  EXCEPTION;
    PRAGMA EXCEPTION_INIT(EX_NOT_FOUND,   -20001);
    PRAGMA EXCEPTION_INIT(EX_INVALID_APP, -20003);

    /**
     * Create report + optional parameters in one atomic call.
     * p_param_keys / p_param_values are pipe-separated strings:
     *   e.g. 'START_DATE|END_DATE' and '{{ ds }}|{{ tomorrow_ds }}'
     */
    PROCEDURE CREATE_REPORT (
        p_fk_appid      IN  OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT 5,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_CONFIG.CREATED_BY%TYPE        DEFAULT NULL,
        p_param_keys    IN  VARCHAR2 DEFAULT NULL,   -- pipe-separated keys
        p_param_values  IN  VARCHAR2 DEFAULT NULL,   -- pipe-separated values
        p_reportid      OUT OTG_REPORT_CONFIG.REPORTID%TYPE
    );

    PROCEDURE UPDATE_REPORT (
        p_reportid      IN  OTG_REPORT_CONFIG.REPORTID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE         DEFAULT NULL,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE         DEFAULT NULL,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT NULL,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT NULL,
        p_updated_by    IN  OTG_REPORT_CONFIG.UPDATED_BY%TYPE        DEFAULT NULL
    );

    PROCEDURE DEACTIVATE_REPORT (
        p_reportid   IN OTG_REPORT_CONFIG.REPORTID%TYPE,
        p_updated_by IN OTG_REPORT_CONFIG.UPDATED_BY%TYPE DEFAULT 'SYSTEM'
    );

    PROCEDURE ADD_PARAM (
        p_reportid      IN  OTG_REPORT_PARAM_CONFIG.FK_REPORTID%TYPE,
        p_key           IN  OTG_REPORT_PARAM_CONFIG.OPERATION_KEY%TYPE,
        p_value         IN  OTG_REPORT_PARAM_CONFIG.OPERATION_VALUE%TYPE DEFAULT NULL,
        p_active        IN  OTG_REPORT_PARAM_CONFIG.ACTIVE%TYPE          DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_PARAM_CONFIG.CREATED_BY%TYPE      DEFAULT NULL,
        p_param_id      OUT OTG_REPORT_PARAM_CONFIG.REPORT_PARAM_CONFIG_ID%TYPE
    );

    PROCEDURE DEACTIVATE_PARAM (
        p_param_id IN OTG_REPORT_PARAM_CONFIG.REPORT_PARAM_CONFIG_ID%TYPE
    );

    FUNCTION GET_REPORT (
        p_reportid IN OTG_REPORT_CONFIG.REPORTID%TYPE
    ) RETURN SYS_REFCURSOR;

    FUNCTION LIST_REPORTS (
        p_fk_appid  IN OTG_REPORT_CONFIG.FK_APPID%TYPE    DEFAULT NULL,
        p_file_type IN OTG_REPORT_CONFIG.FILE_TYPE%TYPE   DEFAULT NULL,
        p_active    IN OTG_REPORT_CONFIG.ACTIVE%TYPE      DEFAULT NULL,
        p_search    IN VARCHAR2                            DEFAULT NULL,
        p_limit     IN NUMBER DEFAULT 50,
        p_offset    IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_REPORT_PARAMS (
        p_reportid IN OTG_REPORT_PARAM_CONFIG.FK_REPORTID%TYPE
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_REPORT_STATS RETURN SYS_REFCURSOR;

END PKG_REPORT_CONFIG;
/

CREATE OR REPLACE PACKAGE BODY PKG_REPORT_CONFIG AS

    -- ── Private helper: split pipe-separated string ───────────────────────────
    TYPE t_str_arr IS TABLE OF VARCHAR2(2000) INDEX BY PLS_INTEGER;

    FUNCTION SPLIT_PIPE (p_str IN VARCHAR2) RETURN t_str_arr IS
        v_arr   t_str_arr;
        v_str   VARCHAR2(32767) := p_str;
        v_pos   NUMBER;
        v_idx   PLS_INTEGER := 1;
    BEGIN
        IF p_str IS NULL THEN RETURN v_arr; END IF;
        LOOP
            v_pos := INSTR(v_str, '|');
            IF v_pos = 0 THEN
                v_arr(v_idx) := v_str;
                EXIT;
            END IF;
            v_arr(v_idx) := SUBSTR(v_str, 1, v_pos - 1);
            v_str := SUBSTR(v_str, v_pos + 1);
            v_idx := v_idx + 1;
        END LOOP;
        RETURN v_arr;
    END SPLIT_PIPE;

    -- ── CREATE_REPORT ─────────────────────────────────────────────────────────
    PROCEDURE CREATE_REPORT (
        p_fk_appid      IN  OTG_REPORT_CONFIG.FK_APPID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT 5,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_CONFIG.CREATED_BY%TYPE        DEFAULT NULL,
        p_param_keys    IN  VARCHAR2 DEFAULT NULL,
        p_param_values  IN  VARCHAR2 DEFAULT NULL,
        p_reportid      OUT OTG_REPORT_CONFIG.REPORTID%TYPE
    ) IS
        v_app_count NUMBER;
        v_keys      t_str_arr;
        v_vals      t_str_arr;
        v_param_id  OTG_REPORT_PARAM_CONFIG.REPORT_PARAM_CONFIG_ID%TYPE;
    BEGIN
        -- Validate parent app exists
        SELECT COUNT(*) INTO v_app_count
          FROM OTG_APP_CONFIG
         WHERE APPID = p_fk_appid AND ACTIVE = 'Y';

        IF v_app_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20003,
                'Active App ID [' || p_fk_appid || '] not found');
        END IF;

        p_reportid := OTG_REPORT_CONFIG_SEQ.NEXTVAL;

        INSERT INTO OTG_REPORT_CONFIG (
            REPORTID, FK_APPID, FILE_TYPE, FILE_NAME, FILE_FORMAT,
            FILE_LOCATION, REPORT_DESCRIPTION, PRIORITY, ACTIVE, CREATED_ON, CREATED_BY
        ) VALUES (
            p_reportid, p_fk_appid, p_file_type, p_file_name, p_file_format,
            p_file_location, p_description, NVL(p_priority, 5),
            NVL(p_active, 'Y'), SYSDATE, p_created_by
        );

        -- Insert parameters if provided
        IF p_param_keys IS NOT NULL THEN
            v_keys := SPLIT_PIPE(p_param_keys);
            v_vals := SPLIT_PIPE(p_param_values);

            FOR i IN 1 .. v_keys.COUNT LOOP
                v_param_id := OTG_REPORT_PARAM_SEQ.NEXTVAL;
                INSERT INTO OTG_REPORT_PARAM_CONFIG (
                    REPORT_PARAM_CONFIG_ID, FK_REPORTID, OPERATION_KEY,
                    OPERATION_VALUE, ACTIVE, CREATED_ON, CREATED_BY
                ) VALUES (
                    v_param_id, p_reportid, v_keys(i),
                    CASE WHEN v_vals.EXISTS(i) THEN v_vals(i) ELSE NULL END,
                    'Y', SYSDATE, p_created_by
                );
            END LOOP;
        END IF;

        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END CREATE_REPORT;

    -- ── UPDATE_REPORT ─────────────────────────────────────────────────────────
    PROCEDURE UPDATE_REPORT (
        p_reportid      IN  OTG_REPORT_CONFIG.REPORTID%TYPE,
        p_file_type     IN  OTG_REPORT_CONFIG.FILE_TYPE%TYPE         DEFAULT NULL,
        p_file_name     IN  OTG_REPORT_CONFIG.FILE_NAME%TYPE         DEFAULT NULL,
        p_file_format   IN  OTG_REPORT_CONFIG.FILE_FORMAT%TYPE       DEFAULT NULL,
        p_file_location IN  OTG_REPORT_CONFIG.FILE_LOCATION%TYPE     DEFAULT NULL,
        p_description   IN  OTG_REPORT_CONFIG.REPORT_DESCRIPTION%TYPE DEFAULT NULL,
        p_priority      IN  OTG_REPORT_CONFIG.PRIORITY%TYPE          DEFAULT NULL,
        p_active        IN  OTG_REPORT_CONFIG.ACTIVE%TYPE            DEFAULT NULL,
        p_updated_by    IN  OTG_REPORT_CONFIG.UPDATED_BY%TYPE        DEFAULT NULL
    ) IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM OTG_REPORT_CONFIG WHERE REPORTID = p_reportid;
        IF v_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Report ID [' || p_reportid || '] not found');
        END IF;

        UPDATE OTG_REPORT_CONFIG
           SET FILE_TYPE           = NVL(p_file_type,     FILE_TYPE),
               FILE_NAME           = NVL(p_file_name,     FILE_NAME),
               FILE_FORMAT         = NVL(p_file_format,   FILE_FORMAT),
               FILE_LOCATION       = NVL(p_file_location, FILE_LOCATION),
               REPORT_DESCRIPTION  = NVL(p_description,   REPORT_DESCRIPTION),
               PRIORITY            = NVL(p_priority,      PRIORITY),
               ACTIVE              = NVL(p_active,        ACTIVE),
               UPDATED_ON          = SYSDATE,
               UPDATED_BY          = p_updated_by
         WHERE REPORTID = p_reportid;

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END UPDATE_REPORT;

    -- ── DEACTIVATE_REPORT ─────────────────────────────────────────────────────
    PROCEDURE DEACTIVATE_REPORT (
        p_reportid   IN OTG_REPORT_CONFIG.REPORTID%TYPE,
        p_updated_by IN OTG_REPORT_CONFIG.UPDATED_BY%TYPE DEFAULT 'SYSTEM'
    ) IS
    BEGIN
        UPDATE OTG_REPORT_CONFIG
           SET ACTIVE = 'N', UPDATED_ON = SYSDATE, UPDATED_BY = p_updated_by
         WHERE REPORTID = p_reportid;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Report ID [' || p_reportid || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END DEACTIVATE_REPORT;

    -- ── ADD_PARAM ─────────────────────────────────────────────────────────────
    PROCEDURE ADD_PARAM (
        p_reportid      IN  OTG_REPORT_PARAM_CONFIG.FK_REPORTID%TYPE,
        p_key           IN  OTG_REPORT_PARAM_CONFIG.OPERATION_KEY%TYPE,
        p_value         IN  OTG_REPORT_PARAM_CONFIG.OPERATION_VALUE%TYPE DEFAULT NULL,
        p_active        IN  OTG_REPORT_PARAM_CONFIG.ACTIVE%TYPE          DEFAULT 'Y',
        p_created_by    IN  OTG_REPORT_PARAM_CONFIG.CREATED_BY%TYPE      DEFAULT NULL,
        p_param_id      OUT OTG_REPORT_PARAM_CONFIG.REPORT_PARAM_CONFIG_ID%TYPE
    ) IS
    BEGIN
        p_param_id := OTG_REPORT_PARAM_SEQ.NEXTVAL;
        INSERT INTO OTG_REPORT_PARAM_CONFIG (
            REPORT_PARAM_CONFIG_ID, FK_REPORTID, OPERATION_KEY,
            OPERATION_VALUE, ACTIVE, CREATED_ON, CREATED_BY
        ) VALUES (
            p_param_id, p_reportid, p_key, p_value,
            NVL(p_active,'Y'), SYSDATE, p_created_by
        );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END ADD_PARAM;

    -- ── DEACTIVATE_PARAM ──────────────────────────────────────────────────────
    PROCEDURE DEACTIVATE_PARAM (
        p_param_id IN OTG_REPORT_PARAM_CONFIG.REPORT_PARAM_CONFIG_ID%TYPE
    ) IS
    BEGIN
        UPDATE OTG_REPORT_PARAM_CONFIG
           SET ACTIVE = 'N', UPDATED_ON = SYSDATE
         WHERE REPORT_PARAM_CONFIG_ID = p_param_id;
        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Param ID [' || p_param_id || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END DEACTIVATE_PARAM;

    -- ── GET_REPORT ────────────────────────────────────────────────────────────
    FUNCTION GET_REPORT (
        p_reportid IN OTG_REPORT_CONFIG.REPORTID%TYPE
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT r.REPORTID, r.FK_APPID, r.FILE_TYPE, r.FILE_NAME, r.FILE_FORMAT,
                   r.FILE_LOCATION, r.REPORT_DESCRIPTION, r.PRIORITY, r.ACTIVE,
                   r.CREATED_ON, r.CREATED_BY, r.UPDATED_ON, r.UPDATED_BY,
                   a.APPNAME, a.ENV AS APP_ENV
              FROM OTG_REPORT_CONFIG r
              JOIN OTG_APP_CONFIG    a ON a.APPID = r.FK_APPID
             WHERE r.REPORTID = p_reportid;
        RETURN v_cur;
    END GET_REPORT;

    -- ── LIST_REPORTS ──────────────────────────────────────────────────────────
    FUNCTION LIST_REPORTS (
        p_fk_appid  IN OTG_REPORT_CONFIG.FK_APPID%TYPE    DEFAULT NULL,
        p_file_type IN OTG_REPORT_CONFIG.FILE_TYPE%TYPE   DEFAULT NULL,
        p_active    IN OTG_REPORT_CONFIG.ACTIVE%TYPE      DEFAULT NULL,
        p_search    IN VARCHAR2                            DEFAULT NULL,
        p_limit     IN NUMBER DEFAULT 50,
        p_offset    IN NUMBER DEFAULT 0
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT r.REPORTID, r.FK_APPID, r.FILE_TYPE, r.FILE_NAME,
                   r.FILE_FORMAT, r.FILE_LOCATION, r.REPORT_DESCRIPTION,
                   r.PRIORITY, r.ACTIVE, r.CREATED_ON, r.CREATED_BY,
                   r.UPDATED_ON, r.UPDATED_BY,
                   a.APPNAME, a.ENV AS APP_ENV
              FROM OTG_REPORT_CONFIG r
              JOIN OTG_APP_CONFIG    a ON a.APPID = r.FK_APPID
             WHERE (p_fk_appid  IS NULL OR r.FK_APPID   = p_fk_appid)
               AND (p_file_type IS NULL OR r.FILE_TYPE  = p_file_type)
               AND (p_active    IS NULL OR r.ACTIVE     = p_active)
               AND (p_search    IS NULL
                    OR LOWER(r.FILE_NAME) LIKE '%' || LOWER(p_search) || '%'
                    OR LOWER(r.REPORT_DESCRIPTION) LIKE '%' || LOWER(p_search) || '%')
             ORDER BY r.REPORTID
            OFFSET p_offset ROWS FETCH NEXT p_limit ROWS ONLY;
        RETURN v_cur;
    END LIST_REPORTS;

    -- ── GET_REPORT_PARAMS ─────────────────────────────────────────────────────
    FUNCTION GET_REPORT_PARAMS (
        p_reportid IN OTG_REPORT_PARAM_CONFIG.FK_REPORTID%TYPE
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT REPORT_PARAM_CONFIG_ID, FK_REPORTID, OPERATION_KEY,
                   OPERATION_VALUE, ACTIVE, CREATED_ON, CREATED_BY
              FROM OTG_REPORT_PARAM_CONFIG
             WHERE FK_REPORTID = p_reportid
             ORDER BY REPORT_PARAM_CONFIG_ID;
        RETURN v_cur;
    END GET_REPORT_PARAMS;

    -- ── GET_REPORT_STATS ──────────────────────────────────────────────────────
    FUNCTION GET_REPORT_STATS RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT
                COUNT(*)                                   AS TOTAL,
                SUM(CASE WHEN ACTIVE='Y' THEN 1 ELSE 0 END) AS ACTIVE_COUNT,
                SUM(CASE WHEN ACTIVE='N' THEN 1 ELSE 0 END) AS INACTIVE_COUNT
            FROM OTG_REPORT_CONFIG;
        RETURN v_cur;
    END GET_REPORT_STATS;

END PKG_REPORT_CONFIG;
/

SHOW ERRORS PACKAGE BODY PKG_REPORT_CONFIG;
