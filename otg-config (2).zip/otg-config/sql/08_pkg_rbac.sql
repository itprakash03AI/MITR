-- ============================================================
-- 08_pkg_rbac.sql
-- PKG_RBAC — all RBAC operations
--
-- Key operations:
--   SYNC_USER_ON_LOGIN   — upsert user + auto-assign roles from AD groups
--   HAS_PERMISSION       — fast single-permission check (VARCHAR2 Y/N)
--   GET_USER_PERMISSIONS — full permission set as SYS_REFCURSOR (for JWT)
--   ASSIGN_ROLE / REVOKE_ROLE / CREATE_ROLE / UPDATE_ROLE
--   GRANT_PERMISSION / REVOKE_PERMISSION on a role
--   MAP_AD_GROUP_TO_ROLE / UNMAP_AD_GROUP
--   LIST_USERS / LIST_ROLES / GET_USER_DETAIL
-- ============================================================

CREATE OR REPLACE PACKAGE PKG_RBAC AS

    -- ── Exceptions ────────────────────────────────────────────────────────────
    EX_USER_NOT_FOUND    EXCEPTION;
    EX_ROLE_NOT_FOUND    EXCEPTION;
    EX_PERM_NOT_FOUND    EXCEPTION;
    EX_ROLE_EXISTS       EXCEPTION;
    EX_USER_LOCKED       EXCEPTION;
    EX_SYSTEM_ROLE       EXCEPTION;
    EX_DUPLICATE         EXCEPTION;
    PRAGMA EXCEPTION_INIT(EX_USER_NOT_FOUND, -20020);
    PRAGMA EXCEPTION_INIT(EX_ROLE_NOT_FOUND, -20021);
    PRAGMA EXCEPTION_INIT(EX_PERM_NOT_FOUND, -20022);
    PRAGMA EXCEPTION_INIT(EX_ROLE_EXISTS,    -20023);
    PRAGMA EXCEPTION_INIT(EX_USER_LOCKED,    -20024);
    PRAGMA EXCEPTION_INIT(EX_SYSTEM_ROLE,    -20025);
    PRAGMA EXCEPTION_INIT(EX_DUPLICATE,      -20026);

    -- ── Login / User sync ─────────────────────────────────────────────────────

    /**
     * Called on every successful AD login.
     * - Upserts the user record (creates if first login)
     * - Resolves AD group → role mappings → assigns those roles (SOURCE=AD_GROUP)
     * - Removes AD_GROUP roles that no longer apply
     * - Leaves MANUAL role assignments untouched
     * - Returns USER_ID
     */
    PROCEDURE SYNC_USER_ON_LOGIN (
        p_username      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2 DEFAULT NULL,
        p_email         IN  VARCHAR2 DEFAULT NULL,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,   -- pipe-separated AD group CNs
        p_user_id       OUT NUMBER
    );

    -- ── Permission checking ───────────────────────────────────────────────────

    /**
     * Fast check: does this user have component:action permission?
     * Returns 'Y' or 'N'. Never raises — returns 'N' on any error.
     */
    FUNCTION HAS_PERMISSION (
        p_username      IN VARCHAR2,
        p_component_key IN VARCHAR2,
        p_action_key    IN VARCHAR2
    ) RETURN VARCHAR2;

    /**
     * Returns all effective permissions for a user as a flat cursor.
     * Used at login to embed permissions in JWT.
     * Deduplicates — a permission granted via multiple roles appears once.
     */
    FUNCTION GET_USER_PERMISSIONS (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR;

    /**
     * Returns user's roles.
     */
    FUNCTION GET_USER_ROLES (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR;

    -- ── User management ───────────────────────────────────────────────────────

    PROCEDURE CREATE_USER (
        p_username      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2 DEFAULT NULL,
        p_email         IN  VARCHAR2 DEFAULT NULL,
        p_status        IN  VARCHAR2 DEFAULT 'ACTIVE',
        p_created_by    IN  VARCHAR2 DEFAULT 'SYSTEM',
        p_user_id       OUT NUMBER
    );

    PROCEDURE UPDATE_USER (
        p_user_id       IN NUMBER,
        p_display_name  IN VARCHAR2 DEFAULT NULL,
        p_email         IN VARCHAR2 DEFAULT NULL,
        p_status        IN VARCHAR2 DEFAULT NULL,
        p_updated_by    IN VARCHAR2 DEFAULT 'SYSTEM'
    );

    PROCEDURE ASSIGN_ROLE (
        p_username   IN VARCHAR2,
        p_role_key   IN VARCHAR2,
        p_assigned_by IN VARCHAR2 DEFAULT 'SYSTEM',
        p_expires_on IN DATE     DEFAULT NULL
    );

    PROCEDURE REVOKE_ROLE (
        p_username   IN VARCHAR2,
        p_role_key   IN VARCHAR2,
        p_revoked_by IN VARCHAR2 DEFAULT 'SYSTEM'
    );

    FUNCTION LIST_USERS (
        p_status    IN VARCHAR2 DEFAULT NULL,
        p_search    IN VARCHAR2 DEFAULT NULL,
        p_limit     IN NUMBER   DEFAULT 50,
        p_offset    IN NUMBER   DEFAULT 0
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_USER_DETAIL (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR;

    -- ── Role management ───────────────────────────────────────────────────────

    PROCEDURE CREATE_ROLE (
        p_role_key      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2,
        p_description   IN  VARCHAR2 DEFAULT NULL,
        p_color         IN  VARCHAR2 DEFAULT '#58A6FF',
        p_created_by    IN  VARCHAR2 DEFAULT 'SYSTEM',
        p_role_id       OUT NUMBER
    );

    PROCEDURE UPDATE_ROLE (
        p_role_id       IN NUMBER,
        p_display_name  IN VARCHAR2 DEFAULT NULL,
        p_description   IN VARCHAR2 DEFAULT NULL,
        p_color         IN VARCHAR2 DEFAULT NULL,
        p_active        IN VARCHAR2 DEFAULT NULL,
        p_updated_by    IN VARCHAR2 DEFAULT 'SYSTEM'
    );

    PROCEDURE GRANT_PERMISSION_TO_ROLE (
        p_role_key       IN VARCHAR2,
        p_permission_key IN VARCHAR2,
        p_granted_by     IN VARCHAR2 DEFAULT 'SYSTEM'
    );

    PROCEDURE REVOKE_PERMISSION_FROM_ROLE (
        p_role_key       IN VARCHAR2,
        p_permission_key IN VARCHAR2
    );

    FUNCTION LIST_ROLES (
        p_active IN VARCHAR2 DEFAULT NULL
    ) RETURN SYS_REFCURSOR;

    FUNCTION GET_ROLE_PERMISSIONS (
        p_role_key IN VARCHAR2
    ) RETURN SYS_REFCURSOR;

    -- ── AD Group mapping ──────────────────────────────────────────────────────

    PROCEDURE MAP_AD_GROUP_TO_ROLE (
        p_ad_group_cn IN VARCHAR2,
        p_role_key    IN VARCHAR2,
        p_created_by  IN VARCHAR2 DEFAULT 'SYSTEM'
    );

    PROCEDURE UNMAP_AD_GROUP_FROM_ROLE (
        p_ad_group_cn IN VARCHAR2,
        p_role_key    IN VARCHAR2
    );

    FUNCTION LIST_AD_GROUP_MAPPINGS RETURN SYS_REFCURSOR;

    -- ── Components / Permissions catalogue ────────────────────────────────────

    FUNCTION LIST_COMPONENTS RETURN SYS_REFCURSOR;
    FUNCTION LIST_PERMISSIONS RETURN SYS_REFCURSOR;
    FUNCTION GET_PERMISSION_MATRIX RETURN SYS_REFCURSOR;

END PKG_RBAC;
/


CREATE OR REPLACE PACKAGE BODY PKG_RBAC AS

    -- ── Private: split pipe-separated string ─────────────────────────────────
    TYPE t_str_arr IS TABLE OF VARCHAR2(1000) INDEX BY PLS_INTEGER;

    FUNCTION SPLIT_PIPE (p_str IN VARCHAR2) RETURN t_str_arr IS
        v_arr t_str_arr; v_str VARCHAR2(32767) := p_str;
        v_pos NUMBER; v_idx PLS_INTEGER := 1;
    BEGIN
        IF p_str IS NULL THEN RETURN v_arr; END IF;
        LOOP
            v_pos := INSTR(v_str, '|');
            IF v_pos = 0 THEN v_arr(v_idx) := TRIM(v_str); EXIT; END IF;
            v_arr(v_idx) := TRIM(SUBSTR(v_str, 1, v_pos - 1));
            v_str := SUBSTR(v_str, v_pos + 1);
            v_idx := v_idx + 1;
        END LOOP;
        RETURN v_arr;
    END SPLIT_PIPE;

    -- ── SYNC_USER_ON_LOGIN ────────────────────────────────────────────────────
    PROCEDURE SYNC_USER_ON_LOGIN (
        p_username      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2 DEFAULT NULL,
        p_email         IN  VARCHAR2 DEFAULT NULL,
        p_ad_groups     IN  VARCHAR2 DEFAULT NULL,
        p_user_id       OUT NUMBER
    ) IS
        v_uname  VARCHAR2(200) := LOWER(TRIM(p_username));
        v_cnt    NUMBER;
        v_status VARCHAR2(20);
        v_groups t_str_arr;
    BEGIN
        -- Upsert user
        SELECT COUNT(*), MAX(STATUS), MAX(USER_ID)
          INTO v_cnt, v_status, p_user_id
          FROM OTG_USERS WHERE USERNAME = v_uname;

        IF v_cnt = 0 THEN
            p_user_id := OTG_USER_SEQ.NEXTVAL;
            INSERT INTO OTG_USERS (USER_ID, USERNAME, DISPLAY_NAME, EMAIL,
                                   AD_GROUPS, STATUS, LAST_LOGIN, LOGIN_COUNT, CREATED_BY)
            VALUES (p_user_id, v_uname, p_display_name, p_email,
                    p_ad_groups, 'ACTIVE', SYSTIMESTAMP, 1, 'AD_SYNC');
        ELSE
            IF v_status = 'LOCKED' THEN
                RAISE_APPLICATION_ERROR(-20024, 'User [' || v_uname || '] is locked');
            END IF;
            UPDATE OTG_USERS
               SET DISPLAY_NAME = NVL(p_display_name, DISPLAY_NAME),
                   EMAIL        = NVL(p_email,        EMAIL),
                   AD_GROUPS    = p_ad_groups,
                   LAST_LOGIN   = SYSTIMESTAMP,
                   LOGIN_COUNT  = LOGIN_COUNT + 1,
                   UPDATED_ON   = SYSDATE,
                   UPDATED_BY   = 'AD_SYNC'
             WHERE USER_ID = p_user_id;
        END IF;

        -- Remove stale AD_GROUP-sourced roles (groups user no longer has)
        DELETE FROM OTG_USER_ROLES ur
         WHERE ur.USER_ID = p_user_id
           AND ur.SOURCE  = 'AD_GROUP'
           AND NOT EXISTS (
               SELECT 1 FROM OTG_AD_GROUP_ROLES agr
                JOIN OTG_ROLES r ON r.ROLE_ID = agr.ROLE_ID
               WHERE agr.ROLE_ID  = ur.ROLE_ID
                 AND agr.ACTIVE   = 'Y'
                 AND INSTR(NVL(p_ad_groups,''), agr.AD_GROUP_CN) > 0
           );

        -- Add new AD_GROUP roles
        IF p_ad_groups IS NOT NULL THEN
            v_groups := SPLIT_PIPE(p_ad_groups);
            FOR i IN 1 .. v_groups.COUNT LOOP
                FOR mapping IN (
                    SELECT agr.ROLE_ID
                      FROM OTG_AD_GROUP_ROLES agr
                     WHERE agr.AD_GROUP_CN = v_groups(i)
                       AND agr.ACTIVE = 'Y'
                ) LOOP
                    BEGIN
                        INSERT INTO OTG_USER_ROLES (ID, USER_ID, ROLE_ID, SOURCE, ASSIGNED_BY)
                        VALUES (OTG_USER_ROLE_SEQ.NEXTVAL, p_user_id, mapping.ROLE_ID, 'AD_GROUP', 'AD_SYNC');
                    EXCEPTION
                        WHEN DUP_VAL_ON_INDEX THEN NULL;  -- already assigned
                    END;
                END LOOP;
            END LOOP;
        END IF;

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END SYNC_USER_ON_LOGIN;

    -- ── HAS_PERMISSION ────────────────────────────────────────────────────────
    FUNCTION HAS_PERMISSION (
        p_username      IN VARCHAR2,
        p_component_key IN VARCHAR2,
        p_action_key    IN VARCHAR2
    ) RETURN VARCHAR2 IS
        v_cnt NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt
          FROM OTG_USER_ROLES  ur
          JOIN OTG_ROLES        r  ON r.ROLE_ID       = ur.ROLE_ID
          JOIN OTG_ROLE_PERMISSIONS rp ON rp.ROLE_ID  = r.ROLE_ID
          JOIN OTG_PERMISSIONS  p  ON p.PERMISSION_ID = rp.PERMISSION_ID
          JOIN OTG_COMPONENTS   c  ON c.COMPONENT_ID  = p.COMPONENT_ID
          JOIN OTG_ACTIONS      a  ON a.ACTION_ID     = p.ACTION_ID
          JOIN OTG_USERS        u  ON u.USER_ID       = ur.USER_ID
         WHERE LOWER(u.USERNAME)  = LOWER(TRIM(p_username))
           AND c.COMPONENT_KEY    = UPPER(TRIM(p_component_key))
           AND a.ACTION_KEY       = UPPER(TRIM(p_action_key))
           AND ur.ACTIVE   = 'Y'
           AND r.ACTIVE    = 'Y'
           AND p.ACTIVE    = 'Y'
           AND u.STATUS    = 'ACTIVE'
           AND (ur.EXPIRES_ON IS NULL OR ur.EXPIRES_ON >= TRUNC(SYSDATE))
           AND ROWNUM = 1;
        RETURN CASE WHEN v_cnt > 0 THEN 'Y' ELSE 'N' END;
    EXCEPTION
        WHEN OTHERS THEN RETURN 'N';
    END HAS_PERMISSION;

    -- ── GET_USER_PERMISSIONS ──────────────────────────────────────────────────
    FUNCTION GET_USER_PERMISSIONS (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT DISTINCT
                   p.PERMISSION_KEY,
                   c.COMPONENT_KEY,
                   c.DISPLAY_NAME AS COMPONENT_NAME,
                   a.ACTION_KEY,
                   a.DISPLAY_NAME AS ACTION_NAME,
                   a.SEVERITY
              FROM OTG_USER_ROLES  ur
              JOIN OTG_ROLES        r  ON r.ROLE_ID       = ur.ROLE_ID
              JOIN OTG_ROLE_PERMISSIONS rp ON rp.ROLE_ID  = r.ROLE_ID
              JOIN OTG_PERMISSIONS  p  ON p.PERMISSION_ID = rp.PERMISSION_ID
              JOIN OTG_COMPONENTS   c  ON c.COMPONENT_ID  = p.COMPONENT_ID
              JOIN OTG_ACTIONS      a  ON a.ACTION_ID     = p.ACTION_ID
              JOIN OTG_USERS        u  ON u.USER_ID       = ur.USER_ID
             WHERE LOWER(u.USERNAME) = LOWER(TRIM(p_username))
               AND ur.ACTIVE  = 'Y'
               AND r.ACTIVE   = 'Y'
               AND p.ACTIVE   = 'Y'
               AND c.ACTIVE   = 'Y'
               AND a.ACTIVE   = 'Y'
               AND u.STATUS   = 'ACTIVE'
               AND (ur.EXPIRES_ON IS NULL OR ur.EXPIRES_ON >= TRUNC(SYSDATE))
             ORDER BY c.DISPLAY_ORDER, a.DISPLAY_ORDER;
        RETURN v_cur;
    END GET_USER_PERMISSIONS;

    -- ── GET_USER_ROLES ────────────────────────────────────────────────────────
    FUNCTION GET_USER_ROLES (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT r.ROLE_ID, r.ROLE_KEY, r.DISPLAY_NAME, r.DESCRIPTION,
                   r.COLOR, ur.SOURCE, ur.ASSIGNED_ON, ur.EXPIRES_ON
              FROM OTG_USER_ROLES ur
              JOIN OTG_ROLES r ON r.ROLE_ID = ur.ROLE_ID
              JOIN OTG_USERS u ON u.USER_ID = ur.USER_ID
             WHERE LOWER(u.USERNAME) = LOWER(TRIM(p_username))
               AND ur.ACTIVE = 'Y'
               AND r.ACTIVE  = 'Y'
             ORDER BY r.DISPLAY_NAME;
        RETURN v_cur;
    END GET_USER_ROLES;

    -- ── CREATE_USER ───────────────────────────────────────────────────────────
    PROCEDURE CREATE_USER (
        p_username      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2 DEFAULT NULL,
        p_email         IN  VARCHAR2 DEFAULT NULL,
        p_status        IN  VARCHAR2 DEFAULT 'ACTIVE',
        p_created_by    IN  VARCHAR2 DEFAULT 'SYSTEM',
        p_user_id       OUT NUMBER
    ) IS
        v_cnt NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM OTG_USERS WHERE USERNAME = LOWER(TRIM(p_username));
        IF v_cnt > 0 THEN
            RAISE_APPLICATION_ERROR(-20026, 'User [' || p_username || '] already exists');
        END IF;
        p_user_id := OTG_USER_SEQ.NEXTVAL;
        INSERT INTO OTG_USERS (USER_ID, USERNAME, DISPLAY_NAME, EMAIL, STATUS, CREATED_BY)
        VALUES (p_user_id, LOWER(TRIM(p_username)), p_display_name, p_email,
                NVL(p_status,'ACTIVE'), p_created_by);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END CREATE_USER;

    -- ── UPDATE_USER ───────────────────────────────────────────────────────────
    PROCEDURE UPDATE_USER (
        p_user_id       IN NUMBER,
        p_display_name  IN VARCHAR2 DEFAULT NULL,
        p_email         IN VARCHAR2 DEFAULT NULL,
        p_status        IN VARCHAR2 DEFAULT NULL,
        p_updated_by    IN VARCHAR2 DEFAULT 'SYSTEM'
    ) IS
    BEGIN
        UPDATE OTG_USERS
           SET DISPLAY_NAME = NVL(p_display_name, DISPLAY_NAME),
               EMAIL        = NVL(p_email,        EMAIL),
               STATUS       = NVL(p_status,       STATUS),
               UPDATED_ON   = SYSDATE,
               UPDATED_BY   = p_updated_by
         WHERE USER_ID = p_user_id;
        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20020, 'User ID [' || p_user_id || '] not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END UPDATE_USER;

    -- ── ASSIGN_ROLE ───────────────────────────────────────────────────────────
    PROCEDURE ASSIGN_ROLE (
        p_username    IN VARCHAR2,
        p_role_key    IN VARCHAR2,
        p_assigned_by IN VARCHAR2 DEFAULT 'SYSTEM',
        p_expires_on  IN DATE     DEFAULT NULL
    ) IS
        v_uid  NUMBER;
        v_rid  NUMBER;
    BEGIN
        SELECT USER_ID INTO v_uid FROM OTG_USERS WHERE USERNAME = LOWER(TRIM(p_username));
        SELECT ROLE_ID INTO v_rid FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)) AND ACTIVE = 'Y';

        -- Upsert: if already assigned, just reactivate + update
        MERGE INTO OTG_USER_ROLES ur
        USING (SELECT v_uid AS UID, v_rid AS RID FROM DUAL) src
           ON (ur.USER_ID = src.UID AND ur.ROLE_ID = src.RID)
         WHEN MATCHED THEN
              UPDATE SET ACTIVE = 'Y', ASSIGNED_ON = SYSDATE,
                         ASSIGNED_BY = p_assigned_by, EXPIRES_ON = p_expires_on,
                         SOURCE = 'MANUAL'
         WHEN NOT MATCHED THEN
              INSERT (ID, USER_ID, ROLE_ID, ASSIGNED_BY, EXPIRES_ON, SOURCE, ACTIVE)
              VALUES (OTG_USER_ROLE_SEQ.NEXTVAL, v_uid, v_rid, p_assigned_by, p_expires_on, 'MANUAL', 'Y');
        COMMIT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20021, 'Role [' || p_role_key || '] or user [' || p_username || '] not found');
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END ASSIGN_ROLE;

    -- ── REVOKE_ROLE ───────────────────────────────────────────────────────────
    PROCEDURE REVOKE_ROLE (
        p_username   IN VARCHAR2,
        p_role_key   IN VARCHAR2,
        p_revoked_by IN VARCHAR2 DEFAULT 'SYSTEM'
    ) IS
    BEGIN
        UPDATE OTG_USER_ROLES ur
           SET ACTIVE = 'N', ASSIGNED_BY = p_revoked_by
         WHERE USER_ID = (SELECT USER_ID FROM OTG_USERS WHERE USERNAME = LOWER(TRIM(p_username)))
           AND ROLE_ID = (SELECT ROLE_ID FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)));
        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20021, 'Role assignment not found');
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END REVOKE_ROLE;

    -- ── LIST_USERS ────────────────────────────────────────────────────────────
    FUNCTION LIST_USERS (
        p_status    IN VARCHAR2 DEFAULT NULL,
        p_search    IN VARCHAR2 DEFAULT NULL,
        p_limit     IN NUMBER   DEFAULT 50,
        p_offset    IN NUMBER   DEFAULT 0
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT u.USER_ID, u.USERNAME, u.DISPLAY_NAME, u.EMAIL,
                   u.STATUS, u.LAST_LOGIN, u.LOGIN_COUNT, u.CREATED_ON,
                   (SELECT LISTAGG(r.ROLE_KEY, ',') WITHIN GROUP (ORDER BY r.ROLE_KEY)
                      FROM OTG_USER_ROLES ur2
                      JOIN OTG_ROLES r ON r.ROLE_ID = ur2.ROLE_ID
                     WHERE ur2.USER_ID = u.USER_ID AND ur2.ACTIVE = 'Y') AS ROLES,
                   (SELECT LISTAGG(r.COLOR, ',') WITHIN GROUP (ORDER BY r.ROLE_KEY)
                      FROM OTG_USER_ROLES ur2
                      JOIN OTG_ROLES r ON r.ROLE_ID = ur2.ROLE_ID
                     WHERE ur2.USER_ID = u.USER_ID AND ur2.ACTIVE = 'Y') AS ROLE_COLORS
              FROM OTG_USERS u
             WHERE (p_status IS NULL OR u.STATUS = p_status)
               AND (p_search IS NULL
                    OR LOWER(u.USERNAME)     LIKE '%' || LOWER(p_search) || '%'
                    OR LOWER(u.DISPLAY_NAME) LIKE '%' || LOWER(p_search) || '%'
                    OR LOWER(u.EMAIL)        LIKE '%' || LOWER(p_search) || '%')
             ORDER BY u.USERNAME
            OFFSET p_offset ROWS FETCH NEXT p_limit ROWS ONLY;
        RETURN v_cur;
    END LIST_USERS;

    -- ── GET_USER_DETAIL ───────────────────────────────────────────────────────
    FUNCTION GET_USER_DETAIL (
        p_username IN VARCHAR2
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT USER_ID, USERNAME, DISPLAY_NAME, EMAIL, AD_GROUPS,
                   STATUS, LAST_LOGIN, LOGIN_COUNT, CREATED_ON
              FROM OTG_USERS WHERE USERNAME = LOWER(TRIM(p_username));
        RETURN v_cur;
    END GET_USER_DETAIL;

    -- ── CREATE_ROLE ───────────────────────────────────────────────────────────
    PROCEDURE CREATE_ROLE (
        p_role_key      IN  VARCHAR2,
        p_display_name  IN  VARCHAR2,
        p_description   IN  VARCHAR2 DEFAULT NULL,
        p_color         IN  VARCHAR2 DEFAULT '#58A6FF',
        p_created_by    IN  VARCHAR2 DEFAULT 'SYSTEM',
        p_role_id       OUT NUMBER
    ) IS
        v_cnt NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key));
        IF v_cnt > 0 THEN
            RAISE_APPLICATION_ERROR(-20023, 'Role [' || p_role_key || '] already exists');
        END IF;
        p_role_id := OTG_ROLE_SEQ.NEXTVAL;
        INSERT INTO OTG_ROLES (ROLE_ID, ROLE_KEY, DISPLAY_NAME, DESCRIPTION, IS_SYSTEM, COLOR, CREATED_BY)
        VALUES (p_role_id, UPPER(TRIM(p_role_key)), p_display_name, p_description, 'N', NVL(p_color,'#58A6FF'), p_created_by);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END CREATE_ROLE;

    -- ── UPDATE_ROLE ───────────────────────────────────────────────────────────
    PROCEDURE UPDATE_ROLE (
        p_role_id       IN NUMBER,
        p_display_name  IN VARCHAR2 DEFAULT NULL,
        p_description   IN VARCHAR2 DEFAULT NULL,
        p_color         IN VARCHAR2 DEFAULT NULL,
        p_active        IN VARCHAR2 DEFAULT NULL,
        p_updated_by    IN VARCHAR2 DEFAULT 'SYSTEM'
    ) IS
        v_sys CHAR(1);
    BEGIN
        SELECT IS_SYSTEM INTO v_sys FROM OTG_ROLES WHERE ROLE_ID = p_role_id;
        IF v_sys = 'Y' AND p_active = 'N' THEN
            RAISE_APPLICATION_ERROR(-20025, 'Cannot deactivate a system role');
        END IF;
        UPDATE OTG_ROLES
           SET DISPLAY_NAME = NVL(p_display_name, DISPLAY_NAME),
               DESCRIPTION  = NVL(p_description,  DESCRIPTION),
               COLOR        = NVL(p_color,        COLOR),
               ACTIVE       = NVL(p_active,       ACTIVE)
         WHERE ROLE_ID = p_role_id;
        COMMIT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20021, 'Role ID [' || p_role_id || '] not found');
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END UPDATE_ROLE;

    -- ── GRANT_PERMISSION_TO_ROLE ──────────────────────────────────────────────
    PROCEDURE GRANT_PERMISSION_TO_ROLE (
        p_role_key       IN VARCHAR2,
        p_permission_key IN VARCHAR2,
        p_granted_by     IN VARCHAR2 DEFAULT 'SYSTEM'
    ) IS
        v_rid NUMBER; v_pid NUMBER;
    BEGIN
        SELECT ROLE_ID       INTO v_rid FROM OTG_ROLES       WHERE ROLE_KEY       = UPPER(TRIM(p_role_key));
        SELECT PERMISSION_ID INTO v_pid FROM OTG_PERMISSIONS WHERE PERMISSION_KEY = UPPER(TRIM(p_permission_key));
        BEGIN
            INSERT INTO OTG_ROLE_PERMISSIONS (ID, ROLE_ID, PERMISSION_ID, GRANTED_BY)
            VALUES (OTG_ROLE_PERM_SEQ.NEXTVAL, v_rid, v_pid, p_granted_by);
            COMMIT;
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN NULL;  -- already granted
        END;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20022, 'Role or permission not found');
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END GRANT_PERMISSION_TO_ROLE;

    -- ── REVOKE_PERMISSION_FROM_ROLE ───────────────────────────────────────────
    PROCEDURE REVOKE_PERMISSION_FROM_ROLE (
        p_role_key       IN VARCHAR2,
        p_permission_key IN VARCHAR2
    ) IS
    BEGIN
        DELETE FROM OTG_ROLE_PERMISSIONS
         WHERE ROLE_ID       = (SELECT ROLE_ID FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)))
           AND PERMISSION_ID = (SELECT PERMISSION_ID FROM OTG_PERMISSIONS WHERE PERMISSION_KEY = UPPER(TRIM(p_permission_key)));
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END REVOKE_PERMISSION_FROM_ROLE;

    -- ── LIST_ROLES ────────────────────────────────────────────────────────────
    FUNCTION LIST_ROLES (
        p_active IN VARCHAR2 DEFAULT NULL
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT r.ROLE_ID, r.ROLE_KEY, r.DISPLAY_NAME, r.DESCRIPTION,
                   r.IS_SYSTEM, r.COLOR, r.ACTIVE, r.CREATED_ON,
                   (SELECT COUNT(*) FROM OTG_ROLE_PERMISSIONS WHERE ROLE_ID = r.ROLE_ID) AS PERMISSION_COUNT,
                   (SELECT COUNT(*) FROM OTG_USER_ROLES WHERE ROLE_ID = r.ROLE_ID AND ACTIVE = 'Y') AS USER_COUNT
              FROM OTG_ROLES r
             WHERE (p_active IS NULL OR r.ACTIVE = p_active)
             ORDER BY r.IS_SYSTEM DESC, r.DISPLAY_NAME;
        RETURN v_cur;
    END LIST_ROLES;

    -- ── GET_ROLE_PERMISSIONS ──────────────────────────────────────────────────
    FUNCTION GET_ROLE_PERMISSIONS (
        p_role_key IN VARCHAR2
    ) RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT p.PERMISSION_KEY, c.COMPONENT_KEY, c.DISPLAY_NAME AS COMPONENT_NAME,
                   a.ACTION_KEY, a.DISPLAY_NAME AS ACTION_NAME, a.SEVERITY
              FROM OTG_ROLE_PERMISSIONS rp
              JOIN OTG_PERMISSIONS p ON p.PERMISSION_ID = rp.PERMISSION_ID
              JOIN OTG_COMPONENTS  c ON c.COMPONENT_ID  = p.COMPONENT_ID
              JOIN OTG_ACTIONS     a ON a.ACTION_ID     = p.ACTION_ID
             WHERE rp.ROLE_ID = (SELECT ROLE_ID FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)))
             ORDER BY c.DISPLAY_ORDER, a.DISPLAY_ORDER;
        RETURN v_cur;
    END GET_ROLE_PERMISSIONS;

    -- ── MAP_AD_GROUP_TO_ROLE ──────────────────────────────────────────────────
    PROCEDURE MAP_AD_GROUP_TO_ROLE (
        p_ad_group_cn IN VARCHAR2,
        p_role_key    IN VARCHAR2,
        p_created_by  IN VARCHAR2 DEFAULT 'SYSTEM'
    ) IS
        v_rid NUMBER;
    BEGIN
        SELECT ROLE_ID INTO v_rid FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)) AND ACTIVE = 'Y';
        BEGIN
            INSERT INTO OTG_AD_GROUP_ROLES (ID, AD_GROUP_CN, ROLE_ID, CREATED_BY)
            VALUES (OTG_AD_GROUP_ROLE_SEQ.NEXTVAL, TRIM(p_ad_group_cn), v_rid, p_created_by);
            COMMIT;
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
                UPDATE OTG_AD_GROUP_ROLES SET ACTIVE = 'Y'
                 WHERE AD_GROUP_CN = TRIM(p_ad_group_cn) AND ROLE_ID = v_rid;
                COMMIT;
        END;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20021, 'Role [' || p_role_key || '] not found');
        WHEN OTHERS THEN ROLLBACK; RAISE;
    END MAP_AD_GROUP_TO_ROLE;

    -- ── UNMAP_AD_GROUP_FROM_ROLE ──────────────────────────────────────────────
    PROCEDURE UNMAP_AD_GROUP_FROM_ROLE (
        p_ad_group_cn IN VARCHAR2,
        p_role_key    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE OTG_AD_GROUP_ROLES SET ACTIVE = 'N'
         WHERE AD_GROUP_CN = TRIM(p_ad_group_cn)
           AND ROLE_ID     = (SELECT ROLE_ID FROM OTG_ROLES WHERE ROLE_KEY = UPPER(TRIM(p_role_key)));
        COMMIT;
    END UNMAP_AD_GROUP_FROM_ROLE;

    -- ── LIST_AD_GROUP_MAPPINGS ────────────────────────────────────────────────
    FUNCTION LIST_AD_GROUP_MAPPINGS RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT agr.ID, agr.AD_GROUP_CN, r.ROLE_KEY, r.DISPLAY_NAME AS ROLE_NAME,
                   r.COLOR, agr.ACTIVE, agr.CREATED_ON
              FROM OTG_AD_GROUP_ROLES agr
              JOIN OTG_ROLES r ON r.ROLE_ID = agr.ROLE_ID
             ORDER BY agr.AD_GROUP_CN, r.DISPLAY_NAME;
        RETURN v_cur;
    END LIST_AD_GROUP_MAPPINGS;

    -- ── LIST_COMPONENTS ───────────────────────────────────────────────────────
    FUNCTION LIST_COMPONENTS RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT COMPONENT_ID, COMPONENT_KEY, DISPLAY_NAME, DESCRIPTION, ICON, DISPLAY_ORDER
              FROM OTG_COMPONENTS WHERE ACTIVE = 'Y' ORDER BY DISPLAY_ORDER;
        RETURN v_cur;
    END LIST_COMPONENTS;

    -- ── LIST_PERMISSIONS ──────────────────────────────────────────────────────
    FUNCTION LIST_PERMISSIONS RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT p.PERMISSION_ID, p.PERMISSION_KEY,
                   c.COMPONENT_KEY, c.DISPLAY_NAME AS COMPONENT_NAME,
                   a.ACTION_KEY,    a.DISPLAY_NAME AS ACTION_NAME, a.SEVERITY
              FROM OTG_PERMISSIONS p
              JOIN OTG_COMPONENTS  c ON c.COMPONENT_ID = p.COMPONENT_ID
              JOIN OTG_ACTIONS     a ON a.ACTION_ID    = p.ACTION_ID
             WHERE p.ACTIVE = 'Y'
             ORDER BY c.DISPLAY_ORDER, a.DISPLAY_ORDER;
        RETURN v_cur;
    END LIST_PERMISSIONS;

    -- ── GET_PERMISSION_MATRIX ─────────────────────────────────────────────────
    -- Returns one row per component, with one column per action (Y/N presence flag)
    FUNCTION GET_PERMISSION_MATRIX RETURN SYS_REFCURSOR IS
        v_cur SYS_REFCURSOR;
    BEGIN
        OPEN v_cur FOR
            SELECT c.COMPONENT_KEY, c.DISPLAY_NAME,
                   MAX(CASE WHEN a.ACTION_KEY='READ'    THEN p.PERMISSION_KEY END) AS READ_PERM,
                   MAX(CASE WHEN a.ACTION_KEY='WRITE'   THEN p.PERMISSION_KEY END) AS WRITE_PERM,
                   MAX(CASE WHEN a.ACTION_KEY='DELETE'  THEN p.PERMISSION_KEY END) AS DELETE_PERM,
                   MAX(CASE WHEN a.ACTION_KEY='EXECUTE' THEN p.PERMISSION_KEY END) AS EXECUTE_PERM,
                   MAX(CASE WHEN a.ACTION_KEY='EXPORT'  THEN p.PERMISSION_KEY END) AS EXPORT_PERM
              FROM OTG_COMPONENTS  c
              LEFT JOIN OTG_PERMISSIONS p ON p.COMPONENT_ID = c.COMPONENT_ID AND p.ACTIVE='Y'
              LEFT JOIN OTG_ACTIONS     a ON a.ACTION_ID    = p.ACTION_ID
             WHERE c.ACTIVE = 'Y'
             GROUP BY c.COMPONENT_ID, c.COMPONENT_KEY, c.DISPLAY_NAME, c.DISPLAY_ORDER
             ORDER BY c.DISPLAY_ORDER;
        RETURN v_cur;
    END GET_PERMISSION_MATRIX;

END PKG_RBAC;
/

SHOW ERRORS PACKAGE BODY PKG_RBAC;
COMMIT;
