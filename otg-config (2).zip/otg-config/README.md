# OTG Configuration Platform

Enterprise config management for Reports and Airflow DAGs.
FastAPI + React TypeScript + Oracle stored packages + AD/JWT auth.

---

## Architecture

```
Browser (React + Vite)
  JWT in sessionStorage, Bearer on every request
  ▼
FastAPI (Python)
  AD/LDAP bind via ldap3 → JWT issue/verify (PyJWT)
  All Oracle via oracle_utils.py — zero inline SQL
  ▼
Oracle Packages
  PKG_APP_CONFIG      — CRUD OTG_APP_CONFIG
  PKG_REPORT_CONFIG   — CRUD OTG_REPORT_CONFIG + params
  PKG_DAG_CONFIG      — CRUD OTG_AIRFLOW_DAG_CONFIG + params
  PKG_BULK_UPLOAD     — validate + bulk insert rows
  PKG_GENERIC_DML     — generic INSERT/UPDATE on any registered table
                        + OTG_DML_TABLE_REGISTRY (whitelist)
                        + OTG_DML_AUDIT_LOG (immutable, AUTONOMOUS_TRANSACTION)
```

---

## SQL — run in order

| Script | Creates |
|--------|---------|
| 01_tables.sql | All OTG tables, sequences, indexes, audit triggers |
| 02_pkg_app_config.sql | PKG_APP_CONFIG |
| 03_pkg_report_config.sql | PKG_REPORT_CONFIG |
| 04_pkg_dag_config.sql | PKG_DAG_CONFIG |
| 05_pkg_bulk_upload.sql | PKG_BULK_UPLOAD |
| 06_pkg_generic_dml.sql | PKG_GENERIC_DML + OTG_DML_TABLE_REGISTRY + OTG_DML_AUDIT_LOG |

---

## Authentication — Active Directory

### Flow

1. User submits AD username + password on `/login`
2. `ldap3` binds to AD using the user's own credentials (no service account needed)
3. `memberOf` groups resolved → filtered to OTG functional groups
4. JWT issued: `{ sub, name, email, groups, otg_role, exp }`
5. Every API call validated: `Authorization: Bearer <token>`

### Functional Groups

| AD Group CN | OTG Role | Can do |
|---|---|---|
| `OTG-Platform-Admin` | `OTG_ADMIN` | Full DML on all registered tables |
| `OTG-Platform-Support` | `OTG_SUPPORT` | UPDATE non-PK columns + view audit log |
| `OTG-Platform-ReadOnly` | `OTG_READONLY` | GET endpoints only |

Configure group CNs: `AD_GROUP_ADMIN`, `AD_GROUP_SUPPORT`, `AD_GROUP_READONLY` env vars.

### Dev bypass (AD_SERVER not set)

```
admin_user   / any password → OTG_ADMIN
support_user / any password → OTG_SUPPORT
other        / any password → OTG_READONLY
```

---

## Generic DML — /api/v1/admin/dml

### Purpose

Ad-hoc INSERT / UPDATE on any registered table.
For production support fixes, incident response, emergency corrections.

### Endpoints

```
POST /api/v1/admin/dml/execute               — run INSERT or UPDATE
GET  /api/v1/admin/dml/tables                — list allowed tables
GET  /api/v1/admin/dml/tables/{name}/columns — column metadata (drives UI form)
GET  /api/v1/admin/dml/audit-log             — immutable audit trail
```

### Example — UPDATE

```json
POST /api/v1/admin/dml/execute
Authorization: Bearer <token>

{
  "operation":  "UPDATE",
  "table_name": "OTG_APP_CONFIG",
  "pk_column":  "APPID",
  "pk_value":   "42",
  "columns": {
    "HOSTNAME":  "new-db.company.com",
    "ACTIVE":    "Y"
  }
}
```

### Example — INSERT

```json
{
  "operation":  "INSERT",
  "table_name": "OTG_APP_CONFIG",
  "columns": {
    "APPNAME": "AnalyticsDB",
    "ENV":     "PROD",
    "DB_TYPE": "snowflake",
    "ACTIVE":  "Y"
  }
}
```

### Security layers (defence-in-depth)

```
1. JWT required             — FastAPI Depends(require_auth)
2. OTG_SUPPORT minimum      — FastAPI Depends(require_group(ROLE_SUPPORT))
3. Table whitelisted        — OTG_DML_TABLE_REGISTRY (Oracle) → ORA-20010
4. Column allowed for op    — ALLOW_INSERT / ALLOW_UPDATE flags → ORA-20011
5. Column group check       — MIN_GROUP='OTG_ADMIN' columns block support users → ORA-20013
6. PK validation (UPDATE)   — IS_PK='Y' required in registry → ORA-20012
7. Bind variables only      — DBMS_SQL.BIND_VARIABLE, never string concat in SQL
8. Audit always written     — AUTONOMOUS_TRANSACTION, commits even on rollback
```

### Controlling access via registry

```sql
-- Expose a new column for SUPPORT-level UPDATE:
INSERT INTO OTG_DML_TABLE_REGISTRY VALUES (
  OTG_DML_REGISTRY_SEQ.NEXTVAL,
  'OTG_APP_CONFIG', 'DB_CONNECTION', 'VARCHAR2',
  'N','Y','N','Y', 'OTG_SUPPORT', 'DB Connection', 6, 'Y'
);

-- Restrict a column to ADMIN only:
UPDATE OTG_DML_TABLE_REGISTRY
   SET MIN_GROUP = 'OTG_ADMIN'
 WHERE TABLE_NAME='OTG_AIRFLOW_DAG_CONFIG' AND COLUMN_NAME='DAG_ID';

-- Hide a column entirely:
UPDATE OTG_DML_TABLE_REGISTRY
   SET ACTIVE = 'N'
 WHERE TABLE_NAME='OTG_APP_CONFIG' AND COLUMN_NAME='DB_CONNECTION';
```

---

## Frontend Routes

| Route | Requires | Description |
|---|---|---|
| `/login` | — | AD login form with group legend |
| `/dashboard` | Any role | Stats + activity |
| `/config/new` | Any role | Config builder |
| `/config/upload` | Any role | Excel bulk upload |
| `/apps` | Any role | App registry |
| `/admin/dml` | OTG_SUPPORT+ | Generic DML console + audit log |

The Admin DML nav item is hidden from OTG_READONLY users and the route is protected server-side.

---

## Required env vars

```bash
# Oracle
ORACLE_HOST=your-oracle.company.com
ORACLE_PORT=1521
ORACLE_SERVICE=ORCLPDB1
ORACLE_USER=otg_user
ORACLE_PASSWORD=***
ORACLE_SCHEMA=OTG_OWNER

# Auth
SECRET_KEY=***  # python -c "import secrets; print(secrets.token_hex(32))"
TOKEN_EXPIRE_MINUTES=480

# Active Directory
AD_SERVER=ldap://ad.company.com    # ldaps:// for TLS; empty = dev bypass
AD_DOMAIN=COMPANY
AD_BASE_DN=DC=company,DC=com
AD_AUTH_METHOD=NTLM                # NTLM | SIMPLE

# Functional Groups (exact AD CN= values)
AD_GROUP_ADMIN=OTG-Platform-Admin
AD_GROUP_SUPPORT=OTG-Platform-Support
AD_GROUP_READONLY=OTG-Platform-ReadOnly
```

---

## Local dev

```bash
# Backend
cd backend && pip install -r requirements.txt
cp .env.example .env   # fill Oracle; leave AD_SERVER blank for dev bypass
uvicorn main:app --reload --port 8000

# Frontend
cd frontend && npm install && npm run dev
# → http://localhost:5173

# Login: admin_user / any password
```

## Docker

```bash
docker-compose up
# backend  → http://localhost:8000
# frontend → http://localhost:3000
```

## OpenShift

```bash
# 1. Create secret
oc create secret generic otg-backend-secret \
  --from-literal=ORACLE_PASSWORD='your_password' \
  --from-literal=SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(32))')" \
  -n otg-platform

# 2. Edit placeholder values in:
#    openshift/otg-backend-configmap.yaml  (ORACLE_HOST, AD_SERVER, AD_GROUP_*)
#    openshift/otg-services-routes.yaml    (Route hostnames)
#    openshift/otg-buildconfig.yaml        (git URI)

# 3. Deploy
./deploy.sh otg-platform --build
```
