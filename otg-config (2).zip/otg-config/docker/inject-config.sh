#!/bin/sh
# ============================================================
# inject-config.sh
# Runs at container START (before nginx) via /docker-entrypoint.d/
#
# OpenShift pattern: inject runtime env vars into the SPA's index.html
# so the React app can read them via window.__OTG_CONFIG__
# This allows ONE Docker image to be promoted across DEV → UAT → PROD
# without rebuilding, just by changing the ConfigMap.
# ============================================================

set -e

INDEX_FILE="/usr/share/nginx/html/index.html"

if [ ! -f "$INDEX_FILE" ]; then
  echo "[inject-config] WARNING: index.html not found at $INDEX_FILE"
  exit 0
fi

# Build the window.__OTG_CONFIG__ JSON from environment variables
# Only override values that are explicitly set in the environment
CONFIG_JSON="{"

append_if_set() {
  KEY="$1"
  JS_KEY="$2"
  VALUE="$3"
  if [ -n "$VALUE" ]; then
    CONFIG_JSON="${CONFIG_JSON}\"${JS_KEY}\":\"${VALUE}\","
  fi
}

append_if_set ""  "apiBaseUrl"        "${RUNTIME_API_BASE_URL:-}"
append_if_set ""  "wsBaseUrl"         "${RUNTIME_WS_BASE_URL:-}"
append_if_set ""  "appName"           "${RUNTIME_APP_NAME:-}"
append_if_set ""  "appEnv"            "${RUNTIME_APP_ENV:-}"
append_if_set ""  "appVersion"        "${RUNTIME_APP_VERSION:-}"

# Remove trailing comma if present
CONFIG_JSON=$(echo "$CONFIG_JSON" | sed 's/,$//')
CONFIG_JSON="${CONFIG_JSON}}"

# Skip injection if config is empty
if [ "$CONFIG_JSON" = "{}" ]; then
  echo "[inject-config] No RUNTIME_* variables set, skipping injection"
  exit 0
fi

SCRIPT_TAG="<script>window.__OTG_CONFIG__=${CONFIG_JSON};</script>"

# Inject before closing </head> tag
sed -i "s|</head>|${SCRIPT_TAG}</head>|" "$INDEX_FILE"

echo "[inject-config] Injected runtime config: $CONFIG_JSON"
