#!/usr/bin/env bash
# ============================================================
# deploy.sh — OTG Config Platform OpenShift Deployment
# Usage: ./deploy.sh <namespace> [--build]
# ============================================================
set -euo pipefail

NAMESPACE="${1:-otg-platform}"
BUILD="${2:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OCP_DIR="$SCRIPT_DIR/openshift"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Pre-flight ──────────────────────────────────────────────────────────────
command -v oc &>/dev/null || error "oc CLI not found. Install OpenShift CLI."
oc whoami &>/dev/null    || error "Not logged into OpenShift. Run: oc login"

info "Deploying OTG Config Platform to namespace: $NAMESPACE"
info "Logged in as: $(oc whoami)"

# ── Namespace ───────────────────────────────────────────────────────────────
if ! oc get namespace "$NAMESPACE" &>/dev/null; then
  info "Creating namespace $NAMESPACE..."
  oc new-project "$NAMESPACE"
else
  oc project "$NAMESPACE"
fi

# ── Secrets (skip if already exist) ─────────────────────────────────────────
if ! oc get secret otg-backend-secret -n "$NAMESPACE" &>/dev/null; then
  warn "Secret 'otg-backend-secret' not found."
  warn "Create it with:"
  warn "  oc create secret generic otg-backend-secret \\"
  warn "    --from-literal=ORACLE_PASSWORD='<password>' \\"
  warn "    --from-literal=SECRET_KEY='\$(python3 -c \"import secrets; print(secrets.token_hex(32))\")' \\"
  warn "    -n $NAMESPACE"
  error "Please create the secret before deploying."
fi

# ── ConfigMaps ──────────────────────────────────────────────────────────────
info "Applying ConfigMaps..."
oc apply -f "$OCP_DIR/otg-backend-configmap.yaml" -n "$NAMESPACE"

# ── Services, Routes, Deployments ───────────────────────────────────────────
info "Applying services and routes..."
oc apply -f "$OCP_DIR/otg-services-routes.yaml" -n "$NAMESPACE"

# ── BuildConfigs (optional) ──────────────────────────────────────────────────
if [ "$BUILD" = "--build" ]; then
  info "Applying BuildConfigs and ImageStreams..."
  oc apply -f "$OCP_DIR/otg-buildconfig.yaml" -n "$NAMESPACE"

  info "Starting builds..."
  oc start-build otg-backend-build -n "$NAMESPACE" --follow
  oc start-build otg-frontend-build -n "$NAMESPACE" --follow
fi

# ── Deployments ──────────────────────────────────────────────────────────────
info "Applying Deployments..."
oc apply -f "$OCP_DIR/otg-backend-deployment.yaml" -n "$NAMESPACE"

# ── Wait for rollout ─────────────────────────────────────────────────────────
info "Waiting for backend rollout..."
oc rollout status deployment/otg-backend -n "$NAMESPACE" --timeout=5m

info "Waiting for frontend rollout..."
oc rollout status deployment/otg-frontend -n "$NAMESPACE" --timeout=5m

# ── Summary ──────────────────────────────────────────────────────────────────
BACKEND_URL=$(oc get route otg-backend  -n "$NAMESPACE" -o jsonpath='{.spec.host}' 2>/dev/null || echo "not-found")
FRONTEND_URL=$(oc get route otg-frontend -n "$NAMESPACE" -o jsonpath='{.spec.host}' 2>/dev/null || echo "not-found")

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   OTG Config Platform deployed successfully!     ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC}  UI:     https://$FRONTEND_URL"
echo -e "${GREEN}║${NC}  API:    https://$BACKEND_URL/api/health"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
