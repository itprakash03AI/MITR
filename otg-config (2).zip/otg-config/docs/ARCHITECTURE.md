# OTG Config Platform — Architecture & Technical Reference

## Overview

OTG Config Platform is an enterprise configuration management system for **Reports** and **Airflow DAGs**. It provides a centralized UI and REST API to manage data source registries, report definitions, DAG schedules, and bulk configuration uploads — all backed by Oracle stored packages with a full audit trail.

---

## Stack

| Layer | Technology |
|-------|-----------|
| Backend API | FastAPI 0.115 (Python 3.11) |
| Database | Oracle (oracledb thin mode — no client library required) |
| ORM | SQLAlchemy 2.0 (query layer only; all DML via Oracle packages) |
| Authentication | Active Directory via ldap3 + JWT (PyJWT HS256) |
| Authorization | Component × Action RBAC stored in Oracle |
| Frontend | React 18 + TypeScript + Vite + TailwindCSS |
| State | Zustand + TanStack React Query |
| Real-time | WebSocket (FastAPI native) |
| Deployment | Docker Compose (local) / OpenShift (production) |

---

## Repository Layout

```
otg-config/
├── backend/                  # FastAPI application
│   ├── main.py               # App entry point, middleware, router registration
│   ├── config.py             # Pydantic settings (all env vars)
│   ├── auth.py               # Active Directory / LDAP connector
│   ├── rbac.py               # JWT, permission model, FastAPI dependencies
│   ├── database.py           # SQLAlchemy engine (read queries)
│   ├── oracle_utils.py       # oracledb connection pool + stored proc helpers
│   ├── models.py             # SQLAlchemy ORM models (read-only views)
│   ├── schemas.py            # Pydantic request / response models
│   ├── websocket_manager.py  # Broadcast hub for real-time notifications
│   ├── routers/
│   │   ├── auth_router.py    # POST /api/auth/login, GET /api/auth/me
│   │   ├── app_config.py     # CRUD /api/v1/app-config
│   │   ├── report_config.py  # CRUD /api/v1/report-config
│   │   ├── dag_config.py     # CRUD /api/v1/dag-config
│   │   ├── param_config.py   # CRUD /api/v1/param-config
│   │   ├── upload.py         # POST /api/v1/upload (Excel bulk)
│   │   ├── admin_dml.py      # POST /api/v1/admin/dml/execute
│   │   └── user_mgmt.py      # CRUD /api/v1/rbac (users, roles, AD mappings)
│   └── requirements.txt
├── frontend/                 # React SPA
│   ├── src/
│   │   ├── App.tsx           # Root router
│   │   ├── api/client.ts     # Axios instance (auto-injects Bearer token)
│   │   ├── stores/authStore.ts # Zustand: token + user info
│   │   ├── hooks/useWebSocket.ts # WS reconnection hook
│   │   ├── pages/            # One file per route
│   │   ├── components/       # Shared UI components
│   │   └── types/index.ts    # Shared TypeScript types
│   ├── vite.config.ts        # Dev proxy + build chunk splitting
│   └── package.json
├── sql/
│   ├── 01_tables.sql         # Core DDL
│   ├── 02-05_pkg_*.sql       # Config CRUD packages
│   ├── 06_pkg_generic_dml.sql # Admin DML + audit log
│   ├── 07_rbac_schema.sql    # RBAC tables + seed data
│   └── 08_pkg_rbac.sql       # RBAC stored package
├── docker/
│   ├── Dockerfile.backend
│   ├── Dockerfile.frontend
│   ├── nginx.conf
│   └── inject-config.sh      # Runtime env injection for Nginx container
├── openshift/                # OpenShift manifests
├── docker-compose.yml
└── deploy.sh                 # OpenShift deployment script
```

---

## Authentication & Authorization Flow

### Login Flow

```
Browser  →  POST /api/auth/login  →  auth.py (authenticate_ad)
                                      │
                                      ├─ AD_SERVER set? → ldap3 bind with user credentials
                                      │                   resolve AD group memberships
                                      └─ AD_SERVER empty? → dev bypass (username heuristic)
                                      │
                                      ↓
                                   rbac.py (sync_user_and_build_token)
                                      │
                                      ├─ PKG_RBAC.SYNC_USER_ON_LOGIN  (upsert user, sync AD groups)
                                      ├─ PKG_RBAC.GET_USER_PERMISSIONS (load permission set)
                                      └─ PKG_RBAC.GET_USER_ROLES       (load role list)
                                      │
                                      ↓
                                   JWT issued containing:
                                     sub, name, email, roles[], permissions[], user_id, exp
```

### Permission Check Flow (every protected request)

```
Request  →  Authorization: Bearer <token>
         →  rbac.require_perm(Permission.XXX_YYY)   [FastAPI Depends]
         →  decode_token()  →  TokenPayload.has(perm) → True/False
         →  403 if denied, route handler if allowed
```

### Permission Keys

Permissions follow the pattern `COMPONENT:ACTION`.

| Component | Actions |
|-----------|---------|
| `APP_CONFIG` | READ, WRITE, DELETE, EXPORT |
| `REPORT_CONFIG` | READ, WRITE, DELETE, EXPORT |
| `DAG_CONFIG` | READ, WRITE, DELETE, EXECUTE, EXPORT |
| `BULK_UPLOAD` | READ, EXECUTE |
| `ADMIN_DML` | READ, WRITE, EXECUTE |
| `AUDIT_LOG` | READ |
| `USER_MGMT` | READ, WRITE, DELETE |
| `DASHBOARD` | READ |

Default roles seeded in `sql/07_rbac_schema.sql`:

| Role | Permissions |
|------|------------|
| `PLATFORM_ADMIN` | All permissions |
| `SUPPORT_ENGINEER` | Read all, write configs, view audit |
| `PLATFORM_READONLY` | Read-only on all components |

---

## Database Design

### Zero Inline SQL Rule

**All DML operations go through Oracle stored packages.** The Python routers call:
- `oracle_utils.call_proc(conn, "PKG_X.PROC", params)` for INSERT/UPDATE/DELETE
- `oracle_utils.call_func_cursor(conn, "PKG_X.FUNC", params)` for SELECT returning a cursor

This approach:
- Eliminates SQL injection risk entirely
- Centralises business rules in Oracle
- Creates an immutable audit trail (AUTONOMOUS_TRANSACTION)
- Allows DBAs to tune queries independently of application deploys

### Core Tables

| Table | Purpose |
|-------|---------|
| `OTG_APP_CONFIG` | Data source / application registry |
| `OTG_REPORT_CONFIG` | Report output definitions (file type, name, location) |
| `OTG_REPORT_PARAM_CONFIG` | Report query parameters |
| `OTG_AIRFLOW_DAG_CONFIG` | Airflow DAG definitions (schedule, type, URL) |
| `OTG_AIRFLOW_DAG_PARAM_CONFIG` | DAG runtime key/value parameters |
| `OTG_REPORT_DEPENDENCY_MAPPING` | DAG dependency graph edges |

### RBAC Tables

| Table | Purpose |
|-------|---------|
| `OTG_COMPONENTS` | Component registry |
| `OTG_ACTIONS` | Action registry |
| `OTG_PERMISSIONS` | Component × Action matrix |
| `OTG_ROLES` | Named roles |
| `OTG_ROLE_PERMISSIONS` | Role → Permission (many-to-many) |
| `OTG_USERS` | User directory (synced from AD on login) |
| `OTG_USER_ROLES` | User → Role with optional expiry |
| `OTG_AD_GROUP_ROLES` | AD group CN → Role auto-mapping |

### Audit

`OTG_DML_AUDIT_LOG` records every generic DML operation (table, operation, columns, values, user, IP, timestamp) using `AUTONOMOUS_TRANSACTION` — entries cannot be rolled back by the calling transaction.

---

## API Reference

### Base URLs

| Environment | URL |
|-------------|-----|
| Local dev (backend) | `http://localhost:8000` |
| Local dev (frontend) | `http://localhost:5173` |
| Docker Compose | `http://localhost:3000` (Nginx proxy) |

### Endpoints

#### Authentication (no JWT required)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/auth/login` | Bind AD credentials, get JWT |
| `GET` | `/api/auth/me` | Returns current user info (JWT required) |
| `POST` | `/api/auth/logout` | Client-side token discard instruction |

**Login request:**
```json
{ "username": "jdoe", "password": "secret" }
```

**Login response:**
```json
{
  "access_token": "<jwt>",
  "token_type": "bearer",
  "username": "jdoe",
  "display_name": "John Doe",
  "email": "jdoe@company.com",
  "roles": ["SUPPORT_ENGINEER"],
  "permissions": ["APP_CONFIG:READ", "REPORT_CONFIG:READ", ...],
  "expires_in": 28800
}
```

#### App Config — requires `APP_CONFIG:READ` / `WRITE` / `DELETE`

| Method | Path | Permission |
|--------|------|-----------|
| `GET` | `/api/v1/app-config/` | `APP_CONFIG:READ` |
| `GET` | `/api/v1/app-config/{id}` | `APP_CONFIG:READ` |
| `POST` | `/api/v1/app-config/` | `APP_CONFIG:WRITE` |
| `PUT` | `/api/v1/app-config/{id}` | `APP_CONFIG:WRITE` |
| `DELETE` | `/api/v1/app-config/{id}` | `APP_CONFIG:DELETE` |

#### Report Config — requires `REPORT_CONFIG:READ` / `WRITE` / `DELETE`

| Method | Path | Permission |
|--------|------|-----------|
| `GET` | `/api/v1/report-config/stats/summary` | `REPORT_CONFIG:READ` |
| `GET` | `/api/v1/report-config/` | `REPORT_CONFIG:READ` |
| `GET` | `/api/v1/report-config/{id}` | `REPORT_CONFIG:READ` |
| `GET` | `/api/v1/report-config/{id}/params` | `REPORT_CONFIG:READ` |
| `POST` | `/api/v1/report-config/` | `REPORT_CONFIG:WRITE` |
| `PUT` | `/api/v1/report-config/{id}` | `REPORT_CONFIG:WRITE` |
| `DELETE` | `/api/v1/report-config/{id}` | `REPORT_CONFIG:DELETE` |

#### DAG Config — requires `DAG_CONFIG:READ` / `WRITE` / `DELETE`

| Method | Path | Permission |
|--------|------|-----------|
| `GET` | `/api/v1/dag-config/` | `DAG_CONFIG:READ` |
| `GET` | `/api/v1/dag-config/{id}` | `DAG_CONFIG:READ` |
| `GET` | `/api/v1/dag-config/{id}/params` | `DAG_CONFIG:READ` |
| `POST` | `/api/v1/dag-config/` | `DAG_CONFIG:WRITE` |
| `PUT` | `/api/v1/dag-config/{id}` | `DAG_CONFIG:WRITE` |
| `DELETE` | `/api/v1/dag-config/{id}` | `DAG_CONFIG:DELETE` |

#### Admin DML — requires `ADMIN_DML:*`

| Method | Path | Permission |
|--------|------|-----------|
| `GET` | `/api/v1/admin/dml/tables` | `ADMIN_DML:READ` |
| `GET` | `/api/v1/admin/dml/tables/{name}/columns` | `ADMIN_DML:READ` |
| `GET` | `/api/v1/admin/dml/audit-log` | `AUDIT_LOG:READ` |
| `POST` | `/api/v1/admin/dml/execute` | `ADMIN_DML:EXECUTE` |

#### RBAC Management — requires `USER_MGMT:*`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/v1/rbac/users` | List users |
| `GET` | `/api/v1/rbac/users/{username}` | Get user |
| `POST` | `/api/v1/rbac/users/{username}/roles` | Assign role |
| `DELETE` | `/api/v1/rbac/users/{username}/roles/{role}` | Revoke role |
| `GET` | `/api/v1/rbac/roles` | List roles |
| `GET` | `/api/v1/rbac/ad-group-mappings` | List AD group → role mappings |
| `POST` | `/api/v1/rbac/ad-group-mappings` | Create mapping |

#### Health

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/health` | Liveness — always 200 |
| `GET` | `/api/health/ready` | Readiness — checks Oracle |
| `GET` | `/api/runtime-config` | Current config (non-sensitive) |

#### Interactive Docs

- Swagger UI: `http://localhost:8000/docs` (dev only)
- ReDoc: `http://localhost:8000/redoc` (dev only)

---

## Environment Variables

### Backend (`backend/.env`)

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_ENV` | `development` | `development` / `staging` / `production` |
| `LOG_LEVEL` | `INFO` | Python log level |
| `SECRET_KEY` | *(required)* | JWT signing key — override in production |
| `TOKEN_EXPIRE_MINUTES` | `480` | JWT lifetime (8 hours) |
| `ORACLE_USER` | — | DB username |
| `ORACLE_PASSWORD` | — | DB password |
| `ORACLE_HOST` | — | DB host |
| `ORACLE_PORT` | `1521` | DB port |
| `ORACLE_SERVICE` | — | Oracle service name |
| `ORACLE_SCHEMA` | — | Schema prefix (optional) |
| `ORACLE_THIN_MODE` | `true` | No Oracle client library needed |
| `DB_POOL_SIZE` | `10` | oracledb pool max size |
| `CORS_ORIGINS` | `http://localhost:5173,...` | Comma-separated allowed origins |
| `AD_SERVER` | *(empty = dev bypass)* | LDAP URL e.g. `ldap://ad.company.com` |
| `AD_DOMAIN` | — | NTLM domain e.g. `COMPANY` |
| `AD_BASE_DN` | — | e.g. `DC=company,DC=com` |
| `AD_AUTH_METHOD` | `NTLM` | `NTLM` or `SIMPLE` |
| `AD_GROUP_ADMIN` | — | CN of admin AD group |
| `AD_GROUP_SUPPORT` | — | CN of support AD group |
| `AD_GROUP_READONLY` | — | CN of readonly AD group |
| `MAX_UPLOAD_SIZE_MB` | `10` | Max Excel file size |
| `WS_MAX_CONNECTIONS` | `200` | Concurrent WebSocket cap |

### Frontend (`frontend/.env.local`)

| Variable | Description |
|----------|-------------|
| `VITE_API_BASE_URL` | Backend base URL |
| `VITE_WS_BASE_URL` | WebSocket base URL |
| `VITE_APP_NAME` | Display name |
| `VITE_APP_ENV` | Environment label |
| `VITE_MAX_UPLOAD_MB` | Max upload size shown in UI |
| `VITE_FEATURE_BULK_UPLOAD` | Feature flag for bulk upload |
| `VITE_FEATURE_NOTIFICATIONS` | Feature flag for WS notifications |

---

## Local Development

### Prerequisites
- Python 3.11+
- Node 20+
- Access to an Oracle database (or use the dev bypass with a mock DB)

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env — set Oracle credentials; leave AD_SERVER empty for dev bypass
uvicorn main:app --reload --port 8000
```

**Dev bypass users** (when `AD_SERVER` is not set):

| Username pattern | Role |
|-----------------|------|
| Contains `admin` | `PLATFORM_ADMIN` (all permissions) |
| Contains `support` | `SUPPORT_ENGINEER` |
| Anything else | `PLATFORM_READONLY` |

Any password is accepted in dev bypass mode.

### Frontend

```bash
cd frontend
npm install
cp .env.example .env.local
# VITE_API_BASE_URL=http://localhost:8000
npm run dev   # http://localhost:5173
```

### Docker Compose

```bash
docker-compose up
# Frontend: http://localhost:3000
# Backend:  http://localhost:8000
# API Docs: http://localhost:8000/docs
```

---

## OpenShift Deployment

```bash
# First time: create secrets manually
oc create secret generic otg-backend-secret \
  --from-literal=ORACLE_PASSWORD=<pw> \
  --from-literal=SECRET_KEY=<random-256-bit-hex>

# Deploy (includes building images via BuildConfig)
./deploy.sh otg-platform --build

# Redeploy without rebuild
./deploy.sh otg-platform
```

The script applies manifests in this order:
1. ConfigMaps (non-sensitive settings)
2. Services & Routes
3. Deployments (rolling update strategy)
4. Optionally triggers BuildConfigs

---

## Key Design Decisions

### Why Oracle Packages Only?

All INSERT/UPDATE/DELETE operations call `PKG_*.PROC()`. This means:
- **No SQL injection possible** — Python never constructs SQL strings
- **Business rules live in Oracle** — consistent regardless of which client calls the API
- **Audit trail is automatic** — `PKG_GENERIC_DML` writes to `OTG_DML_AUDIT_LOG` via `AUTONOMOUS_TRANSACTION`

### Why Two Auth Modules?

`auth.py` handles **AD connectivity** (ldap3 bind, group resolution, dev bypass).
`rbac.py` handles **JWT lifecycle** and **permission enforcement** (FastAPI dependencies).

They have separate concerns:
- `auth.py` → answers "who is this person and what AD groups do they have?"
- `rbac.py` → answers "what are they allowed to do in this application?"

On login, `auth_router.py` calls `auth.authenticate_ad()` first, then `rbac.sync_user_and_build_token()` to translate AD groups into platform permissions stored in Oracle.

### Thin Mode Oracle

`ORACLE_THIN_MODE=true` (default) uses the pure-Python `oracledb` driver — no Oracle Instant Client libraries required. This keeps Docker images small and eliminates client version management.
