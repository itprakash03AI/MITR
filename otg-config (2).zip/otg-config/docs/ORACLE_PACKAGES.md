# Oracle Stored Packages Reference

All DML in OTG Config Platform goes through Oracle stored packages. No inline SQL exists in the Python layer.

## Package Summary

| Package | SQL File | Purpose |
|---------|----------|---------|
| `PKG_APP_CONFIG` | `02_pkg_app_config.sql` | App/datasource registry CRUD |
| `PKG_REPORT_CONFIG` | `03_pkg_report_config.sql` | Report definition CRUD |
| `PKG_DAG_CONFIG` | `04_pkg_dag_config.sql` | Airflow DAG CRUD |
| `PKG_BULK_UPLOAD` | `05_pkg_bulk_upload.sql` | Excel bulk import |
| `PKG_GENERIC_DML` | `06_pkg_generic_dml.sql` | Admin DML console + audit |
| `PKG_RBAC` | `08_pkg_rbac.sql` | User/role management |

---

## PKG_APP_CONFIG

| Procedure / Function | Parameters | Description |
|---------------------|-----------|-------------|
| `CREATE_APP` | `p_appname, p_env, p_hostname, p_db_type, p_db_connection, p_active, p_createdby` → `p_appid OUT` | Creates new app entry |
| `UPDATE_APP` | `p_appid, p_appname, p_env, p_hostname, p_db_type, p_db_connection, p_active, p_updatedby` | Updates existing app |
| `DEACTIVATE_APP` | `p_appid, p_updatedby` | Soft-delete (sets ACTIVE='N') |
| `GET_APP` | `p_appid` → cursor | Returns single app by ID |
| `LIST_APPS` | `p_env, p_active, p_limit, p_offset` → cursor | Filtered app list |

---

## PKG_REPORT_CONFIG

| Procedure / Function | Parameters | Description |
|---------------------|-----------|-------------|
| `CREATE_REPORT` | `p_fk_appid, p_file_type, p_file_name, p_file_format, p_file_location, p_description, p_priority, p_active, p_created_by, p_param_keys, p_param_values` → `p_reportid OUT` | Creates report + params (pipe-separated param strings) |
| `UPDATE_REPORT` | `p_reportid, p_file_type, p_file_name, p_file_format, p_file_location, p_description, p_priority, p_active, p_updated_by` | Updates report metadata |
| `DEACTIVATE_REPORT` | `p_reportid, p_updated_by` | Soft-delete |
| `GET_REPORT` | `p_reportid` → cursor | Single report |
| `LIST_REPORTS` | `p_fk_appid, p_file_type, p_active, p_search, p_limit, p_offset` → cursor | Filtered list |
| `GET_REPORT_PARAMS` | `p_reportid` → cursor | Report parameters |
| `GET_REPORT_STATS` | *(none)* → cursor | Summary statistics |

**Note on pipe-separated params:** Multiple params are passed as `key1|key2|key3` and `val1|val2|val3`. The package splits these internally.

---

## PKG_DAG_CONFIG

| Procedure / Function | Parameters | Description |
|---------------------|-----------|-------------|
| `CREATE_DAG` | `p_fk_report_id, p_fk_dest_appid, p_dag_id, p_dag_group, p_dag_url, p_dag_type, p_schedule, p_max_active_runs, p_concurrency, p_auto_trigger, p_auto_skip, p_tags, p_active, p_param_keys, p_param_values` → `p_otg_dag_id OUT` | Creates DAG |
| `UPDATE_DAG` | `p_otg_dag_id, p_dag_group, p_dag_url, p_dag_type, p_schedule, p_max_active_runs, p_concurrency, p_auto_trigger, p_auto_skip, p_tags, p_active, p_updatedby` | Updates DAG |
| `DEACTIVATE_DAG` | `p_otg_dag_id, p_updatedby` | Soft-delete |
| `GET_DAG` | `p_otg_dag_id` → cursor | Single DAG |
| `LIST_DAGS` | `p_fk_report_id, p_dag_type, p_active, p_search, p_limit, p_offset` → cursor | Filtered list |
| `GET_DAG_PARAMS` | `p_otg_dag_id` → cursor | DAG parameters |

---

## PKG_GENERIC_DML

Provides a controlled admin interface for generic INSERT/UPDATE with full auditing.

| Procedure / Function | Description |
|---------------------|-------------|
| `GENERIC_INSERT(p_table_name, p_col_names, p_col_values, p_executed_by, p_ad_groups, p_client_ip)` → `p_row_count OUT, p_audit_id OUT` | INSERT into any whitelisted table |
| `GENERIC_UPDATE(p_table_name, p_col_names, p_col_values, p_pk_column, p_pk_value, p_executed_by, p_ad_groups, p_client_ip)` → `p_row_count OUT, p_audit_id OUT` | UPDATE any whitelisted table |
| `LIST_ALLOWED_TABLES(p_ad_groups)` → cursor | Tables the user's groups can access |
| `GET_TABLE_COLUMNS(p_table_name)` → cursor | Columns + permission metadata for a table |
| `GET_AUDIT_LOG(p_table_name, p_executed_by, p_from_date, p_limit, p_offset)` → cursor | Audit trail |

Column names and values are passed as pipe-separated strings: `COL1|COL2|COL3`.

The `OTG_DML_TABLE_REGISTRY` table whitelists which tables are accessible and their required group level.

---

## PKG_RBAC

| Procedure / Function | Description |
|---------------------|-------------|
| `SYNC_USER_ON_LOGIN(p_username, p_display_name, p_email, p_ad_groups)` → `p_user_id OUT` | Upsert user in OTG_USERS; sync AD group → role mappings |
| `GET_USER_PERMISSIONS(p_username)` → cursor | All `PERMISSION_KEY` values for the user |
| `GET_USER_ROLES(p_username)` → cursor | All `ROLE_KEY` values for the user |
| `ASSIGN_ROLE(p_username, p_role_key, p_assigned_by, p_expires_on)` | Grant a role to a user |
| `REVOKE_ROLE(p_username, p_role_key, p_revoked_by)` | Remove a role from a user |
| `LIST_USERS(p_limit, p_offset)` → cursor | Paginated user list |
| `GET_USER(p_username)` → cursor | Single user detail |
| `LIST_ROLES` → cursor | All defined roles |
| `CREATE_AD_GROUP_MAPPING(p_ad_group_cn, p_role_key, p_created_by)` | Map AD group to role |
| `DELETE_AD_GROUP_MAPPING(p_ad_group_cn, p_role_key)` | Remove AD group mapping |
| `LIST_AD_GROUP_MAPPINGS` → cursor | All AD group → role mappings |

---

## Error Codes

Oracle packages raise `RAISE_APPLICATION_ERROR` with these codes:

| Code | HTTP Status | Meaning |
|------|------------|---------|
| `-20001` | 404 | Record not found |
| `-20002` | 409 | Duplicate / unique constraint violation |
| `-20003` | 400 | Invalid input / business rule violation |
| `-20004` | 409 | DAG ID already exists |
| `-20005` | 400 | Invalid DAG configuration |
| `-20010` | 400 | Table not in registry |
| `-20011` | 400 | Column not allowed |
| `-20012` | 400 | Invalid DML operation |
| `-20013` | 403 | Insufficient group privileges for DML |
| `-20020` to `-20026` | 400/409 | RBAC-specific violations |

The Python routers map these codes to appropriate HTTP responses via the `_raise_oracle()` helper pattern.

---

## Python Call Helpers (oracle_utils.py)

```python
from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, call_func_scalar, serialise_row

# Procedure with IN and OUT parameters
with get_oracle_conn() as conn:
    out = call_proc(conn, "PKG_APP_CONFIG.CREATE_APP", {
        "p_appname":  "MyApp",
        "p_env":      "PROD",
        "p_appid":    oracledb.NUMBER,   # OUT parameter — pass the type constant
    })
    new_id = int(out["p_appid"])

# Function returning a cursor (SELECT)
with get_oracle_conn() as conn:
    rows = call_func_cursor(conn, "PKG_APP_CONFIG.LIST_APPS", {
        "p_env":    "PROD",
        "p_active": "Y",
        "p_limit":  50,
        "p_offset": 0,
    })
# rows is a list of dicts; use serialise_row() to handle Oracle types
data = [serialise_row(r) for r in rows]

# Function returning a scalar
value = call_func_scalar(conn, "PKG_X.GET_COUNT", {"p_env": "PROD"})
```

`serialise_row()` converts Oracle-specific types (LOBs, DATE, TIMESTAMP, Decimal) to JSON-serialisable Python types.
