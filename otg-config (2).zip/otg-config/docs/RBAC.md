# RBAC — Role-Based Access Control

## Model

```
User ──── UserRoles ──── Role ──── RolePermissions ──── Permission
                                                          │
                                                  Component × Action
                                                  e.g. "REPORT_CONFIG:WRITE"
```

Permissions are stored as `COMPONENT:ACTION` strings in `OTG_PERMISSIONS`.
They are loaded from Oracle at login and embedded in the JWT so no DB call is needed per request.

## Components & Actions

| Component Key | Actions available |
|--------------|------------------|
| `APP_CONFIG` | READ, WRITE, DELETE, EXPORT |
| `REPORT_CONFIG` | READ, WRITE, DELETE, EXPORT |
| `DAG_CONFIG` | READ, WRITE, DELETE, EXECUTE, EXPORT |
| `BULK_UPLOAD` | READ, EXECUTE |
| `ADMIN_DML` | READ, WRITE, EXECUTE |
| `AUDIT_LOG` | READ |
| `USER_MGMT` | READ, WRITE, DELETE |
| `DASHBOARD` | READ |

## Default Roles

### PLATFORM_ADMIN
Full access to everything. Assigned to members of `AD_GROUP_ADMIN`.

### SUPPORT_ENGINEER
- Read + Write + Delete on APP_CONFIG, REPORT_CONFIG, DAG_CONFIG
- BULK_UPLOAD:READ + EXECUTE
- AUDIT_LOG:READ
- ADMIN_DML:READ (view allowed tables and columns only)
- USER_MGMT:READ

Assigned to members of `AD_GROUP_SUPPORT`.

### PLATFORM_READONLY
- READ on all components (APP_CONFIG, REPORT_CONFIG, DAG_CONFIG, DASHBOARD)
- No write, delete, or execute capabilities

Assigned to all authenticated users not in admin or support groups.

## AD Group → Role Mapping

On first login, `PKG_RBAC.SYNC_USER_ON_LOGIN` checks `OTG_AD_GROUP_ROLES` for each AD group the user belongs to and auto-assigns matching roles. This runs on every login so group changes in AD are reflected at next login.

Manual role assignments (in `OTG_USER_ROLES`) take precedence and can have an expiry date.

## Adding a New Permission

1. Insert into `OTG_COMPONENTS` (if new component)
2. Insert into `OTG_ACTIONS` (if new action)
3. Insert into `OTG_PERMISSIONS` with `PERMISSION_KEY = 'COMPONENT:ACTION'`
4. Insert into `OTG_ROLE_PERMISSIONS` to grant it to existing roles
5. Add the enum value to `rbac.py → Permission`
6. Use `Depends(require_perm(Permission.NEW_PERM))` in the router

## Adding a New Role

```sql
INSERT INTO OTG_ROLES (ROLE_ID, ROLE_KEY, ROLE_NAME, DESCRIPTION)
VALUES (OTG_ROLE_SEQ.NEXTVAL, 'DAG_OPERATOR', 'DAG Operator', 'Can trigger and manage DAGs');

INSERT INTO OTG_ROLE_PERMISSIONS (ROLE_ID, PERMISSION_ID)
SELECT r.ROLE_ID, p.PERMISSION_ID
FROM OTG_ROLES r, OTG_PERMISSIONS p
WHERE r.ROLE_KEY = 'DAG_OPERATOR'
  AND p.PERMISSION_KEY IN ('DAG_CONFIG:READ','DAG_CONFIG:EXECUTE','DASHBOARD:READ');
COMMIT;
```

Then assign via API (`POST /api/v1/rbac/users/{username}/roles`) or map to an AD group.

## FastAPI Usage

```python
from rbac import require_perm, Permission, TokenPayload
from fastapi import Depends

@router.get("/")
async def list_items(user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_READ))):
    # user.username, user.roles, user.permissions available here
    ...

# Multiple permissions (user needs at least ONE)
@router.post("/trigger")
async def trigger(user: TokenPayload = Depends(require_perm(
    Permission.DAG_EXECUTE, Permission.ADMIN_DML_EXECUTE
))):
    ...

# Manual check inside handler
if not user.has(Permission.APP_CONFIG_EXPORT):
    raise HTTPException(403, "Export permission required")
```

## JWT Claims

```json
{
  "sub": "jdoe",
  "name": "John Doe",
  "email": "jdoe@company.com",
  "roles": ["SUPPORT_ENGINEER"],
  "permissions": ["APP_CONFIG:READ", "REPORT_CONFIG:READ", "REPORT_CONFIG:WRITE"],
  "user_id": 42,
  "iat": 1700000000,
  "exp": 1700028800,
  "iss": "OTG Config Platform"
}
```

Token lifetime is controlled by `TOKEN_EXPIRE_MINUTES` (default: 480 = 8 hours).
