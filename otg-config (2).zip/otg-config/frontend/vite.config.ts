import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        '/api': {
          target: env.VITE_API_BASE_URL || 'http://localhost:8000',
          changeOrigin: true,
        },
        '/ws': {
          target: (env.VITE_WS_BASE_URL || 'ws://localhost:8000').replace('wss://', 'https://').replace('ws://', 'http://'),
          ws: true,
          changeOrigin: true,
        },
      },
    },
    build: {
      outDir: 'dist',
      sourcemap: mode !== 'production',
      rollupOptions: {
        output: {
          manualChunks: {
            vendor:  ['react', 'react-dom', 'react-router-dom'],
            query:   ['@tanstack/react-query'],
            forms:   ['react-hook-form', '@hookform/resolvers', 'zod'],
            utils:   ['axios', 'zustand', 'date-fns', 'clsx'],
          },
        },
      },
    },
    define: {
      // Make build timestamp available
      __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
    },
  };
});
