import { useEffect, useRef, useCallback } from 'react';
import { useNotificationStore } from '../stores/notificationStore';
import { buildWsUrl, appConfig } from '../config';
import type { WsNotification } from '../types';

export function useWebSocket(clientId: string) {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout>>();
  const { addNotification } = useNotificationStore();

  const connect = useCallback(() => {
    if (!appConfig.features.notifications) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const ws = new WebSocket(buildWsUrl(clientId));
    wsRef.current = ws;

    ws.onopen = () => console.info('[WS] Connected to', buildWsUrl(clientId));

    ws.onmessage = (event) => {
      try {
        const n: WsNotification = JSON.parse(event.data);
        n.id = `${Date.now()}-${Math.random()}`;
        addNotification(n);
      } catch {
        console.warn('[WS] Unparseable message:', event.data);
      }
    };

    ws.onerror = (e) => console.error('[WS] Error:', e);

    ws.onclose = () => {
      console.info(`[WS] Disconnected. Reconnecting in ${appConfig.wsReconnectDelayMs}ms...`);
      reconnectTimer.current = setTimeout(connect, appConfig.wsReconnectDelayMs);
    };
  }, [clientId, addNotification]);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [connect]);

  return wsRef;
}
