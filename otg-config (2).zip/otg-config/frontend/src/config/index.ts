/**
 * OTG Config Platform - Frontend Configuration
 *
 * All runtime config flows through this module.
 * Values come from Vite environment variables (VITE_* prefix required).
 *
 * Build-time injection:
 *   - Local dev: frontend/.env.local
 *   - OpenShift:  ConfigMap mounted as environment variables into the build,
 *                 OR injected at runtime via window.__OTG_CONFIG__ (see index.html)
 */

// ── Runtime config injected by OpenShift at container start ────────────────
// OpenShift injects this via an init script that writes to index.html
declare global {
  interface Window {
    __OTG_CONFIG__?: Partial<AppConfig>;
  }
}

export interface AppConfig {
  /** Base URL of the FastAPI backend, e.g. https://otg-api.apps.cluster.company.com */
  apiBaseUrl: string;
  /** WebSocket base URL, e.g. wss://otg-api.apps.cluster.company.com */
  wsBaseUrl: string;
  /** Application display name */
  appName: string;
  /** Environment label shown in the UI */
  appEnv: string;
  /** Application version */
  appVersion: string;
  /** Show Swagger/API docs link in sidebar */
  showApiDocs: boolean;
  /** Max file upload size in MB (should match backend MAX_UPLOAD_SIZE_MB) */
  maxUploadMb: number;
  /** WebSocket reconnect delay in milliseconds */
  wsReconnectDelayMs: number;
  /** How long toast notifications stay visible (ms) */
  toastDurationMs: number;
  /** Rows per page for paginated tables */
  defaultPageSize: number;
  /** Feature flags */
  features: {
    bulkUpload: boolean;
    dependencyMapping: boolean;
    notifications: boolean;
  };
}

/**
 * Build the config by merging (in priority order):
 * 1. window.__OTG_CONFIG__   — runtime injection by OpenShift init script
 * 2. import.meta.env.*       — Vite build-time env vars
 * 3. Hard-coded defaults     — sensible fallbacks
 */
function buildConfig(): AppConfig {
  const runtime = window.__OTG_CONFIG__ ?? {};

  const defaults: AppConfig = {
    apiBaseUrl:          import.meta.env.VITE_API_BASE_URL          ?? 'http://localhost:8000',
    wsBaseUrl:           import.meta.env.VITE_WS_BASE_URL            ?? 'ws://localhost:8000',
    appName:             import.meta.env.VITE_APP_NAME               ?? 'OTG Config Platform',
    appEnv:              import.meta.env.VITE_APP_ENV                ?? 'development',
    appVersion:          import.meta.env.VITE_APP_VERSION            ?? '1.0.0',
    showApiDocs:         import.meta.env.VITE_SHOW_API_DOCS === 'true',
    maxUploadMb:         Number(import.meta.env.VITE_MAX_UPLOAD_MB   ?? 10),
    wsReconnectDelayMs:  Number(import.meta.env.VITE_WS_RECONNECT_MS ?? 3000),
    toastDurationMs:     Number(import.meta.env.VITE_TOAST_DURATION_MS ?? 5000),
    defaultPageSize:     Number(import.meta.env.VITE_DEFAULT_PAGE_SIZE ?? 50),
    features: {
      bulkUpload:          import.meta.env.VITE_FEATURE_BULK_UPLOAD         !== 'false',
      dependencyMapping:   import.meta.env.VITE_FEATURE_DEPENDENCY_MAPPING  === 'true',
      notifications:       import.meta.env.VITE_FEATURE_NOTIFICATIONS       !== 'false',
    },
  };

  return { ...defaults, ...runtime };
}

/** Singleton config instance — import this everywhere */
export const appConfig: AppConfig = buildConfig();

/** Derived API path helpers */
export const apiPaths = {
  health:        `${appConfig.apiBaseUrl}/api/health`,
  healthReady:   `${appConfig.apiBaseUrl}/api/health/ready`,
  runtimeConfig: `${appConfig.apiBaseUrl}/api/runtime-config`,
  apiDocs:       `${appConfig.apiBaseUrl}/api/docs`,

  // REST base paths
  appConfig:    `${appConfig.apiBaseUrl}/api/v1/app-config`,
  reportConfig: `${appConfig.apiBaseUrl}/api/v1/report-config`,
  dagConfig:    `${appConfig.apiBaseUrl}/api/v1/dag-config`,
  paramConfig:  `${appConfig.apiBaseUrl}/api/v1/param-config`,
  upload:       `${appConfig.apiBaseUrl}/api/v1/upload`,
} as const;

/** WebSocket URL builder */
export function buildWsUrl(clientId: string): string {
  return `${appConfig.wsBaseUrl}/ws/${clientId}`;
}

/** Type-safe environment check */
export const isProduction = appConfig.appEnv === 'production';
export const isDevelopment = appConfig.appEnv === 'development';
