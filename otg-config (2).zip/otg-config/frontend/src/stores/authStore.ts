import { create } from 'zustand';

export interface AuthUser {
  username:     string;
  display_name: string;
  email:        string;
  roles:        string[];
  permissions:  string[];  // ["APP_CONFIG:READ", "REPORT_CONFIG:WRITE", ...]
  user_id?:     number;
}

interface AuthState {
  token:       string | null;
  user:        AuthUser | null;
  setAuth:     (token: string, user: AuthUser) => void;
  logout:      () => void;
  hasPerm:     (perm: string) => boolean;
  hasAnyPerm:  (...perms: string[]) => boolean;
}

const TOKEN_KEY = 'otg_token';
const USER_KEY  = 'otg_user';

const storedToken = sessionStorage.getItem(TOKEN_KEY);
const storedUser  = (() => {
  try { return JSON.parse(sessionStorage.getItem(USER_KEY) || 'null'); }
  catch { return null; }
})();

export const useAuthStore = create<AuthState>()((set, get) => ({
  token: storedToken,
  user:  storedUser,

  setAuth: (token, user) => {
    sessionStorage.setItem(TOKEN_KEY, token);
    sessionStorage.setItem(USER_KEY, JSON.stringify(user));
    set({ token, user });
  },

  logout: () => {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(USER_KEY);
    set({ token: null, user: null });
  },

  hasPerm:    (perm)    => get().user?.permissions?.includes(perm) ?? false,
  hasAnyPerm: (...p)    => p.some(x => get().user?.permissions?.includes(x) ?? false),
}));
