import { useState, useRef, useCallback } from 'react';
import { useMutation } from '@tanstack/react-query';
import {
  Download, Upload, CheckCircle, XCircle,
  AlertTriangle, FileSpreadsheet, ArrowRight,
  RefreshCw, Info
} from 'lucide-react';
import { uploadApi } from '../api/client';
import type { EntityType, ValidationResult, BulkUploadResult } from '../types';

type UploadStep = 'select' | 'validate' | 'import' | 'done';

const ENTITY_INFO = {
  report: {
    label: 'Report Config',
    icon: '📊',
    description: 'Upload multiple report configurations with file type, location, and parameters',
    color: '#2F81F7',
  },
  dag: {
    label: 'DAG Config',
    icon: '🔄',
    description: 'Upload Airflow DAG configurations with schedule, concurrency and runtime params',
    color: '#3FB950',
  },
  app: {
    label: 'App Registry',
    icon: '🔌',
    description: 'Register multiple data source connections (Oracle, Snowflake, Starburst, etc.)',
    color: '#7C3AED',
  },
};

export function BulkUploadPage() {
  const [entityType, setEntityType] = useState<EntityType>('report');
  const [step, setStep] = useState<UploadStep>('select');
  const [file, setFile] = useState<File | null>(null);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [importResult, setImportResult] = useState<BulkUploadResult | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateMutation = useMutation({
    mutationFn: (f: File) => uploadApi.validate(entityType, f),
    onSuccess: (data) => {
      setValidationResult(data);
      setStep('validate');
    },
  });

  const importMutation = useMutation({
    mutationFn: (f: File) => uploadApi.import(entityType, f),
    onSuccess: (data) => {
      setImportResult(data);
      setStep('done');
    },
  });

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped?.name.endsWith('.xlsx') || dropped?.name.endsWith('.xls')) {
      setFile(dropped);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  };

  const reset = () => {
    setStep('select');
    setFile(null);
    setValidationResult(null);
    setImportResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const info = ENTITY_INFO[entityType];

  return (
    <div className="upload-page">
      {/* Step Indicator */}
      <div className="steps-bar">
        {['select', 'validate', 'import', 'done'].map((s, idx) => {
          const steps = ['select', 'validate', 'import', 'done'];
          const currentIdx = steps.indexOf(step);
          const isActive = step === s;
          const isDone = currentIdx > idx;
          return (
            <div key={s} className={`step ${isActive ? 'step--active' : ''} ${isDone ? 'step--done' : ''}`}>
              <div className="step-circle">
                {isDone ? <CheckCircle size={14} /> : idx + 1}
              </div>
              <span className="step-label">
                {s === 'select' ? 'Select File' : s === 'validate' ? 'Validate' : s === 'import' ? 'Import' : 'Complete'}
              </span>
              {idx < 3 && <div className={`step-line ${isDone ? 'step-line--done' : ''}`} />}
            </div>
          );
        })}
      </div>

      <div className="upload-layout">
        {/* LEFT: Entity Selector + Template Download */}
        <div className="upload-sidebar">
          <div className="card">
            <div className="card-header">
              <span className="card-title">
                <Info size={14} /> Configuration Type
              </span>
            </div>
            <div style={{ padding: '12px' }}>
              {(Object.keys(ENTITY_INFO) as EntityType[]).map((key) => {
                const i = ENTITY_INFO[key];
                return (
                  <button
                    key={key}
                    className={`entity-btn ${entityType === key ? 'entity-btn--active' : ''}`}
                    onClick={() => { setEntityType(key); reset(); }}
                    style={{ '--entity-color': i.color } as any}
                  >
                    <span className="entity-icon">{i.icon}</span>
                    <div>
                      <div className="entity-label">{i.label}</div>
                      <div className="entity-desc">{i.description}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">
                <Download size={14} /> Download Template
              </span>
            </div>
            <div style={{ padding: '16px' }}>
              <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 12, lineHeight: 1.6 }}>
                Download the Excel template for <strong style={{ color: 'var(--text2)' }}>{info.label}</strong>.
                Fill in your data starting from row 4 and upload below.
              </p>
              <button
                className="btn-primary"
                style={{ width: '100%', justifyContent: 'center' }}
                onClick={() => uploadApi.downloadTemplate(entityType)}
              >
                <Download size={14} />
                Download {info.label} Template
              </button>
              <div style={{ marginTop: 10, padding: '8px 10px', background: 'var(--bg3)', borderRadius: 'var(--radius)', fontSize: 11, color: 'var(--text3)' }}>
                💡 Row 2 = Headers &nbsp;|&nbsp; Row 3 = Help text &nbsp;|&nbsp; Row 4+ = Your data
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: Upload Area */}
        <div className="upload-main">
          {step === 'select' && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">
                  <Upload size={14} /> Upload {info.label} File
                </span>
              </div>
              <div style={{ padding: '24px' }}>
                <div
                  className={`drop-zone ${isDragging ? 'drop-zone--dragging' : ''} ${file ? 'drop-zone--has-file' : ''}`}
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls"
                    style={{ display: 'none' }}
                    onChange={handleFileChange}
                  />

                  {file ? (
                    <div className="file-selected">
                      <FileSpreadsheet size={32} style={{ color: '#3FB950' }} />
                      <div className="file-name">{file.name}</div>
                      <div className="file-size">{(file.size / 1024).toFixed(1)} KB</div>
                    </div>
                  ) : (
                    <div className="drop-prompt">
                      <FileSpreadsheet size={40} style={{ color: 'var(--text3)' }} />
                      <div className="drop-title">Drag & drop your Excel file here</div>
                      <div className="drop-sub">or click to browse</div>
                      <div className="drop-hint">.xlsx or .xls files only</div>
                    </div>
                  )}
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
                  {file && (
                    <button
                      className="btn-primary"
                      onClick={() => validateMutation.mutate(file)}
                      disabled={validateMutation.isPending}
                    >
                      {validateMutation.isPending ? (
                        <><RefreshCw size={14} className="spin" /> Validating...</>
                      ) : (
                        <>Validate File <ArrowRight size={14} /></>
                      )}
                    </button>
                  )}
                </div>

                {validateMutation.isError && (
                  <div className="error-banner">
                    <XCircle size={14} />
                    {(validateMutation.error as any)?.response?.data?.detail || 'Validation failed'}
                  </div>
                )}
              </div>
            </div>
          )}

          {step === 'validate' && validationResult && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">
                  {validationResult.is_valid
                    ? <><CheckCircle size={14} style={{ color: '#3FB950' }} /> Validation Passed</>
                    : <><AlertTriangle size={14} style={{ color: '#D29922' }} /> Validation Issues</>
                  }
                </span>
                <button className="btn-secondary" onClick={reset}>
                  <RefreshCw size={12} /> Start Over
                </button>
              </div>
              <div style={{ padding: '20px' }}>
                {/* Summary */}
                <div className="validation-stats">
                  <div className="vstat vstat--total">
                    <div className="vstat-val">{validationResult.total_rows}</div>
                    <div className="vstat-label">Total Rows</div>
                  </div>
                  <div className="vstat vstat--valid">
                    <div className="vstat-val">{validationResult.valid_rows}</div>
                    <div className="vstat-label">Valid</div>
                  </div>
                  <div className="vstat vstat--error">
                    <div className="vstat-val">{validationResult.errors.length}</div>
                    <div className="vstat-label">Errors</div>
                  </div>
                </div>

                {/* Errors */}
                {validationResult.errors.length > 0 && (
                  <div className="errors-section">
                    <div className="section-title">Validation Errors</div>
                    <div className="errors-list">
                      {validationResult.errors.map((e, i) => (
                        <div key={i} className="error-item">
                          <span className="error-row">Row {e.row}</span>
                          <span className="error-field">{e.field}</span>
                          <span className="error-msg">{e.message}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Preview */}
                {validationResult.preview.length > 0 && (
                  <div style={{ marginTop: 20 }}>
                    <div className="section-title">Preview (first {validationResult.preview.length} valid rows)</div>
                    <div style={{ overflowX: 'auto' }}>
                      <table className="data-table">
                        <thead>
                          <tr>
                            {Object.keys(validationResult.preview[0]).map(k => (
                              <th key={k}>{k}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {validationResult.preview.map((row, i) => (
                            <tr key={i}>
                              {Object.values(row).map((v, j) => (
                                <td key={j} className="td-mono" style={{ fontSize: 11 }}>{v || '—'}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
                  <button className="btn-secondary" onClick={reset}>
                    <RefreshCw size={12} /> Re-upload
                  </button>
                  {validationResult.valid_rows > 0 && (
                    <button
                      className="btn-primary"
                      onClick={() => { setStep('import'); importMutation.mutate(file!); }}
                      disabled={importMutation.isPending}
                    >
                      {importMutation.isPending ? (
                        <><RefreshCw size={14} className="spin" /> Importing...</>
                      ) : (
                        <>Import {validationResult.valid_rows} rows <ArrowRight size={14} /></>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {step === 'done' && importResult && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">
                  <CheckCircle size={14} style={{ color: '#3FB950' }} /> Import Complete
                </span>
              </div>
              <div style={{ padding: '32px', textAlign: 'center' }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>
                  {importResult.error_count === 0 ? '✅' : '⚠️'}
                </div>
                <div className="validation-stats" style={{ justifyContent: 'center', marginBottom: 24 }}>
                  <div className="vstat vstat--valid">
                    <div className="vstat-val">{importResult.success_count}</div>
                    <div className="vstat-label">Imported</div>
                  </div>
                  <div className="vstat vstat--error">
                    <div className="vstat-val">{importResult.error_count}</div>
                    <div className="vstat-label">Failed</div>
                  </div>
                </div>

                {importResult.created_ids.length > 0 && (
                  <div style={{ marginBottom: 20, fontSize: 12, color: 'var(--text3)' }}>
                    Created IDs: {importResult.created_ids.join(', ')}
                  </div>
                )}

                {importResult.errors.length > 0 && (
                  <div className="errors-list" style={{ textAlign: 'left', marginBottom: 20 }}>
                    {importResult.errors.map((e, i) => (
                      <div key={i} className="error-item">
                        <span className="error-row">Row {e.row}</span>
                        <span className="error-field">{e.field}</span>
                        <span className="error-msg">{e.message}</span>
                      </div>
                    ))}
                  </div>
                )}

                <button className="btn-primary" onClick={reset}>
                  <Upload size={14} /> Upload Another File
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .upload-page { max-width: 1100px; }

        .steps-bar {
          display: flex;
          align-items: center;
          gap: 0;
          margin-bottom: 24px;
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 16px 24px;
        }

        .step {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 1;
          color: var(--text3);
          font-size: 12px;
        }

        .step-circle {
          width: 24px; height: 24px;
          border-radius: 50%;
          background: var(--bg3);
          border: 1.5px solid var(--border);
          display: flex; align-items: center; justify-content: center;
          font-size: 11px; font-weight: 700;
          flex-shrink: 0;
          transition: all 0.2s;
        }

        .step--active .step-circle { background: var(--accent); border-color: var(--accent); color: white; }
        .step--active .step-label { color: var(--text); font-weight: 600; }
        .step--done .step-circle { background: var(--success); border-color: var(--success); color: white; }
        .step--done .step-label { color: var(--text2); }

        .step-line {
          flex: 1; height: 1.5px;
          background: var(--border);
          margin: 0 8px;
          transition: background 0.2s;
        }
        .step-line--done { background: var(--success); }

        .upload-layout {
          display: grid;
          grid-template-columns: 280px 1fr;
          gap: 16px;
          align-items: start;
        }

        @media (max-width: 800px) { .upload-layout { grid-template-columns: 1fr; } }

        .upload-sidebar { display: flex; flex-direction: column; gap: 16px; }

        .entity-btn {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          width: 100%;
          padding: 10px 12px;
          background: transparent;
          border: 1.5px solid var(--border);
          border-radius: var(--radius);
          cursor: pointer;
          text-align: left;
          transition: all 0.15s;
          margin-bottom: 6px;
          font-family: var(--font);
        }

        .entity-btn:last-child { margin-bottom: 0; }
        .entity-btn:hover { border-color: var(--entity-color, var(--accent)); background: rgba(255,255,255,0.02); }
        .entity-btn--active { border-color: var(--entity-color, var(--accent)); background: rgba(47,129,247,0.06); }

        .entity-icon { font-size: 20px; line-height: 1; flex-shrink: 0; }
        .entity-label { font-size: 13px; font-weight: 600; color: var(--text); }
        .entity-desc { font-size: 11px; color: var(--text3); margin-top: 2px; line-height: 1.4; }

        .drop-zone {
          border: 2px dashed var(--border);
          border-radius: var(--radius-lg);
          padding: 48px 24px;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
          background: var(--bg3);
        }
        .drop-zone:hover { border-color: var(--accent); background: var(--accent-glow); }
        .drop-zone--dragging { border-color: var(--accent); background: var(--accent-glow); transform: scale(1.01); }
        .drop-zone--has-file { border-color: var(--success); background: rgba(63,185,80,0.05); }

        .drop-title { font-size: 15px; font-weight: 600; color: var(--text); margin: 12px 0 4px; }
        .drop-sub { font-size: 13px; color: var(--text3); }
        .drop-hint { font-size: 11px; color: var(--text3); margin-top: 8px; font-family: var(--font-mono); }

        .file-selected { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        .file-name { font-size: 14px; font-weight: 600; color: var(--text); }
        .file-size { font-size: 11px; color: var(--text3); font-family: var(--font-mono); }

        .validation-stats {
          display: flex;
          gap: 12px;
          margin-bottom: 20px;
        }

        .vstat {
          flex: 1;
          padding: 12px;
          border-radius: var(--radius);
          text-align: center;
          border: 1px solid var(--border);
        }
        .vstat--total { background: rgba(255,255,255,0.03); }
        .vstat--valid { background: rgba(63,185,80,0.1); border-color: rgba(63,185,80,0.3); }
        .vstat--error { background: rgba(248,81,73,0.1); border-color: rgba(248,81,73,0.3); }
        .vstat-val { font-size: 28px; font-weight: 700; color: var(--text); }
        .vstat-label { font-size: 11px; color: var(--text3); margin-top: 2px; }

        .errors-section { margin-top: 20px; }
        .errors-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
          max-height: 200px;
          overflow-y: auto;
        }
        .error-item {
          display: grid;
          grid-template-columns: 60px 120px 1fr;
          gap: 8px;
          padding: 6px 10px;
          background: rgba(248,81,73,0.05);
          border: 1px solid rgba(248,81,73,0.15);
          border-radius: 4px;
          font-size: 11.5px;
          align-items: center;
        }
        .error-row { font-weight: 700; color: var(--danger); font-family: var(--font-mono); }
        .error-field { color: var(--warning); font-family: var(--font-mono); }
        .error-msg { color: var(--text2); }

        .error-banner {
          display: flex; align-items: center; gap: 8px;
          margin-top: 12px;
          padding: 10px 14px;
          background: rgba(248,81,73,0.1);
          border: 1px solid rgba(248,81,73,0.3);
          border-radius: var(--radius);
          color: var(--danger);
          font-size: 12.5px;
        }

        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .spin { animation: spin 1s linear infinite; }
      `}</style>
    </div>
  );
}
