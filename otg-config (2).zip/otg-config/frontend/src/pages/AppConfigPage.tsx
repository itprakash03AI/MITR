import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Database, Edit2, Trash2, X, Save } from 'lucide-react';
import { appConfigApi } from '../api/client';
import type { AppConfig } from '../types';

const schema = z.object({
  appname: z.string().min(1, 'Required'),
  env: z.enum(['DEV', 'QA', 'UAT', 'PROD', 'STAGING']),
  hostname: z.string().optional(),
  db_type: z.string().optional(),
  db_connection: z.string().optional(),
  active: z.enum(['Y', 'N']).default('Y'),
  createdby: z.string().optional(),
});

const ENV_COLORS: Record<string, string> = {
  DEV: '#58A6FF', QA: '#A78BFA', UAT: '#D29922', PROD: '#3FB950', STAGING: '#F85149',
};

const DB_TYPES = ['oracle', 'snowflake', 'starburst', 'postgres', 'mysql', 'databricks', 'bigquery'];

function AppModal({ onClose, existing }: { onClose: () => void; existing?: AppConfig }) {
  const qc = useQueryClient();
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: existing ? {
      appname: existing.appname, env: existing.env as any,
      hostname: existing.hostname || '', db_type: existing.db_type || '',
      db_connection: existing.db_connection || '', active: existing.active,
      createdby: existing.createdby || '',
    } : { active: 'Y', env: 'DEV' },
  });

  const mutation = useMutation({
    mutationFn: (d: z.infer<typeof schema>) =>
      existing ? appConfigApi.update(existing.appid, d) : appConfigApi.create(d as any),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['apps'] }); onClose(); },
  });

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <span>{existing ? 'Edit App' : 'Register New App'}</span>
          <button className="modal-close" onClick={onClose}><X size={16} /></button>
        </div>
        <form onSubmit={handleSubmit(d => mutation.mutate(d))} className="modal-body">
          <div className="form-grid-2">
            <div className="form-field">
              <label className="field-label">App Name *</label>
              <input className="input" {...register('appname')} placeholder="e.g. SalesDB" />
              {errors.appname && <span className="field-error">{errors.appname.message}</span>}
            </div>
            <div className="form-field">
              <label className="field-label">Environment *</label>
              <div className="select-wrap">
                <select className="input select" {...register('env')}>
                  {['DEV', 'QA', 'UAT', 'PROD', 'STAGING'].map(e => <option key={e}>{e}</option>)}
                </select>
              </div>
            </div>
            <div className="form-field">
              <label className="field-label">DB Type</label>
              <div className="select-wrap">
                <select className="input select" {...register('db_type')}>
                  <option value="">Select...</option>
                  {DB_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="form-field">
              <label className="field-label">Hostname</label>
              <input className="input" {...register('hostname')} placeholder="db.company.com" />
            </div>
          </div>
          <div className="form-field" style={{ marginTop: 12 }}>
            <label className="field-label">Connection String</label>
            <textarea className="input textarea" {...register('db_connection')} rows={2}
              placeholder="host=...;port=...;database=..." />
          </div>
          <div className="form-grid-2" style={{ marginTop: 12 }}>
            <div className="form-field">
              <label className="field-label">Active</label>
              <div className="select-wrap">
                <select className="input select" {...register('active')}>
                  <option value="Y">Yes</option>
                  <option value="N">No</option>
                </select>
              </div>
            </div>
            <div className="form-field">
              <label className="field-label">Created By</label>
              <input className="input" {...register('createdby')} placeholder="username" />
            </div>
          </div>
          {mutation.isError && (
            <div className="form-error-banner" style={{ marginTop: 12 }}>
              {(mutation.error as any)?.response?.data?.detail || 'Error saving'}
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 20 }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={mutation.isPending}>
              <Save size={14} /> {existing ? 'Update' : 'Register'}
            </button>
          </div>
        </form>
      </div>

      <style>{`
        .modal-overlay {
          position: fixed; inset: 0;
          background: rgba(0,0,0,0.6);
          z-index: 500;
          display: flex; align-items: center; justify-content: center;
        }
        .modal {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          width: 560px;
          max-width: 95vw;
          box-shadow: var(--shadow-lg);
        }
        .modal-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 16px 20px;
          border-bottom: 1px solid var(--border);
          font-size: 14px; font-weight: 600; color: var(--text);
        }
        .modal-close {
          width: 28px; height: 28px; background: var(--bg3);
          border: 1px solid var(--border); border-radius: var(--radius);
          color: var(--text3); cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s;
        }
        .modal-close:hover { color: var(--text); }
        .modal-body { padding: 20px; }
      `}</style>
    </div>
  );
}

export function AppConfigPage() {
  const [modal, setModal] = useState<{ open: boolean; app?: AppConfig }>({ open: false });
  const qc = useQueryClient();

  const { data: apps = [], isLoading } = useQuery<AppConfig[]>({
    queryKey: ['apps'],
    queryFn: () => appConfigApi.list({ limit: 200 }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => appConfigApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['apps'] }),
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <p style={{ color: 'var(--text3)', fontSize: 13 }}>
          Manage data source connections for Reports and Airflow DAGs
        </p>
        <button className="btn-primary" onClick={() => setModal({ open: true })}>
          <Plus size={15} /> Register App
        </button>
      </div>

      <div className="apps-grid">
        {isLoading ? (
          <div style={{ color: 'var(--text3)', padding: 40, textAlign: 'center' }}>Loading...</div>
        ) : apps.length === 0 ? (
          <div style={{ color: 'var(--text3)', padding: 40, textAlign: 'center', gridColumn: '1/-1' }}>
            <Database size={40} style={{ marginBottom: 12, opacity: 0.3 }} />
            <div>No apps registered. Click "Register App" to add a data source.</div>
          </div>
        ) : apps.map(app => (
          <div key={app.appid} className="app-card">
            <div className="app-card-header">
              <div className="app-db-icon">
                <Database size={18} />
              </div>
              <span className="env-tag" style={{ background: `${ENV_COLORS[app.env]}22`, color: ENV_COLORS[app.env] }}>
                {app.env}
              </span>
              <span className={`tag ${app.active === 'Y' ? 'tag--green' : 'tag--red'}`}>
                {app.active === 'Y' ? 'Active' : 'Inactive'}
              </span>
            </div>
            <div className="app-name">{app.appname}</div>
            <div className="app-meta">
              {app.db_type && <span className="app-db-type">{app.db_type}</span>}
              {app.hostname && <span className="app-hostname">{app.hostname}</span>}
            </div>
            <div className="app-actions">
              <button className="btn-icon" onClick={() => setModal({ open: true, app })}>
                <Edit2 size={13} />
              </button>
              <button
                className="btn-icon btn-icon--danger"
                onClick={() => { if (confirm('Deactivate this app?')) deleteMutation.mutate(app.appid); }}
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {modal.open && (
        <AppModal onClose={() => setModal({ open: false })} existing={modal.app} />
      )}

      <style>{`
        .apps-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: 12px;
        }

        .app-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 16px;
          transition: border-color 0.15s;
        }
        .app-card:hover { border-color: #444; }

        .app-card-header {
          display: flex; align-items: center; gap: 8px;
          margin-bottom: 10px;
        }

        .app-db-icon {
          width: 32px; height: 32px;
          background: rgba(47,129,247,0.1);
          border-radius: var(--radius);
          display: flex; align-items: center; justify-content: center;
          color: var(--accent);
          margin-right: 4px;
        }

        .env-tag {
          font-size: 10px; font-weight: 700;
          padding: 2px 7px;
          border-radius: 4px;
          font-family: var(--font-mono);
        }

        .app-name {
          font-size: 15px; font-weight: 600;
          color: var(--text);
          margin-bottom: 6px;
        }

        .app-meta {
          display: flex; flex-direction: column; gap: 3px;
          margin-bottom: 12px;
        }

        .app-db-type {
          font-size: 11px;
          font-family: var(--font-mono);
          color: var(--accent);
          text-transform: uppercase;
        }

        .app-hostname {
          font-size: 11px;
          color: var(--text3);
          font-family: var(--font-mono);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .app-actions {
          display: flex; gap: 6px;
          border-top: 1px solid var(--border);
          padding-top: 10px;
        }

        .btn-icon {
          width: 30px; height: 30px;
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          color: var(--text3);
          cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s;
        }
        .btn-icon:hover { border-color: var(--accent); color: var(--accent); }
        .btn-icon--danger:hover { border-color: var(--danger); color: var(--danger); background: rgba(248,81,73,0.05); }
      `}</style>
    </div>
  );
}
