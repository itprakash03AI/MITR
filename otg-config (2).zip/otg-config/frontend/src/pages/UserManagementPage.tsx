import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import {
  Users, Shield, Grid3X3, Link2, Plus, Search, RefreshCw,
  ChevronDown, ChevronUp, Pencil, Trash2, Check, X, Loader,
  UserPlus, Lock, Unlock, AlertTriangle, CheckCircle, Info,
  ArrowRight, Minus, Save, Copy
} from 'lucide-react';
import { appConfig } from '../config';
import { useAuthStore } from '../stores/authStore';

/* ─────────────────────── types ─────────────────────────── */
interface User {
  user_id: number; username: string; display_name: string;
  email: string; status: string; last_login: string;
  login_count: number; roles: string; role_colors: string;
}
interface UserDetail extends User {
  ad_groups: string;
  roles: Array<{ role_id:number; role_key:string; display_name:string; color:string; source:string; expires_on:string }>;
  permissions: Array<{ permission_key:string; component_key:string; component_name:string; action_key:string; action_name:string }>;
}
interface Role {
  role_id: number; role_key: string; display_name: string;
  description: string; is_system: string; color: string;
  active: string; permission_count: number; user_count: number;
}
interface RolePerm {
  permission_key: string; component_key: string; component_name: string;
  action_key: string; action_name: string; severity: string;
}
interface PermRow {
  permission_id: number; permission_key: string; component_key: string;
  component_name: string; action_key: string; action_name: string; severity: string;
}
interface Component { component_id: number; component_key: string; display_name: string; icon: string; }
interface AdMapping { id:number; ad_group_cn:string; role_key:string; role_name:string; color:string; active:string; }
interface MatrixRow {
  component_key: string; display_name: string;
  read_perm:string; write_perm:string; delete_perm:string; execute_perm:string; export_perm:string;
}

const ACTIONS = ['READ','WRITE','DELETE','EXECUTE','EXPORT'] as const;
type Action = typeof ACTIONS[number];

const ACTION_COLOR: Record<Action,string> = {
  READ:    '#58A6FF', WRITE:  '#3FB950', DELETE: '#F85149',
  EXECUTE: '#D29922', EXPORT: '#A78BFA',
};
const SEV_COLOR: Record<string,string> = { LOW:'#3FB950', MEDIUM:'#D29922', HIGH:'#F85149' };

const BASE = `${appConfig.apiBaseUrl}/api/v1/rbac`;

/* ─────────────────────── helpers ───────────────────────── */
function useApi<T>(url:string, deps:unknown[]=[]) {
  const { token } = useAuthStore();
  const [data, setData] = useState<T|null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState('');
  const fetch = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const r = await axios.get<T>(url, { headers:{ Authorization:`Bearer ${token}` } });
      setData(r.data);
    } catch(e:any) { setError(e.response?.data?.detail || e.message); }
    finally { setLoading(false); }
  }, [url, token, ...deps]);
  useEffect(() => { fetch(); }, [fetch]);
  return { data, loading, error, refetch: fetch };
}

function authH(token:string|null) { return { Authorization:`Bearer ${token}` }; }

function StatusBadge({ status }:{ status:string }) {
  const c = status==='ACTIVE'?'#3FB950': status==='LOCKED'?'#F85149':'#6E7681';
  return <span style={{ display:'inline-flex', alignItems:'center', gap:4, padding:'2px 8px',
    borderRadius:12, fontSize:10.5, fontWeight:700, fontFamily:'var(--font-mono)',
    background:`${c}20`, color:c, border:`1px solid ${c}40` }}>{status}</span>;
}

function RolePill({ label, color }:{ label:string; color?:string }) {
  const bg = color || '#58A6FF';
  return <span style={{ display:'inline-flex', alignItems:'center', padding:'1px 7px',
    borderRadius:4, fontSize:10, fontWeight:700, fontFamily:'var(--font-mono)',
    background:`${bg}20`, color:bg, border:`1px solid ${bg}40`, marginRight:3 }}>{label}</span>;
}

function toast(msg:string, type:'ok'|'err'='ok') {
  const d = document.createElement('div');
  d.textContent = msg;
  d.style.cssText = `position:fixed;bottom:20px;right:20px;z-index:9999;padding:10px 16px;
    border-radius:8px;font-size:12.5px;font-family:var(--font);font-weight:600;
    background:${type==='ok'?'#1a3a1a':'#3a1a1a'};color:${type==='ok'?'#3FB950':'#F85149'};
    border:1px solid ${type==='ok'?'#3FB95040':'#F8514940'};box-shadow:0 4px 16px rgba(0,0,0,.4)`;
  document.body.appendChild(d);
  setTimeout(()=>d.remove(), 3000);
}

/* ═══════════════════════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════════════════════════ */
export default function UserManagementPage() {
  const [tab, setTab] = useState<'users'|'roles'|'matrix'|'ad'>('users');
  const TABS = [
    { id:'users',  icon:Users,   label:'Users'           },
    { id:'roles',  icon:Shield,  label:'Roles'           },
    { id:'matrix', icon:Grid3X3, label:'Permission Matrix'},
    { id:'ad',     icon:Link2,   label:'AD Group Mapping' },
  ] as const;

  return (
    <div className="rbac-page">
      <div className="rbac-header">
        <div>
          <h2 className="rbac-title"><Shield size={17}/> User &amp; Role Management</h2>
          <p className="rbac-subtitle">
            Manage users, create roles, assign component-level permissions, and map AD groups to roles.
          </p>
        </div>
      </div>

      <div className="rbac-tabs">
        {TABS.map(({id,icon:Icon,label})=>(
          <button key={id} className={`rbac-tab ${tab===id?'rbac-tab--active':''}`}
            onClick={()=>setTab(id)}>
            <Icon size={13}/> {label}
          </button>
        ))}
      </div>

      <div className="rbac-body">
        {tab==='users'  && <UsersTab/>}
        {tab==='roles'  && <RolesTab/>}
        {tab==='matrix' && <MatrixTab/>}
        {tab==='ad'     && <AdMappingTab/>}
      </div>

      <style>{CSS}</style>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   USERS TAB
══════════════════════════════════════════════════════════════ */
function UsersTab() {
  const { token } = useAuthStore();
  const [search, setSearch]   = useState('');
  const [statusF, setStatusF] = useState('');
  const [detail, setDetail]   = useState<UserDetail|null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [assignOpen, setAssignOpen] = useState<string|null>(null); // username
  const [allRoles, setAllRoles] = useState<Role[]>([]);

  const { data:users, loading, refetch } =
    useApi<User[]>(`${BASE}/users?search=${encodeURIComponent(search)}&status=${statusF}&limit=100`,[search,statusF]);

  useEffect(()=>{
    axios.get<Role[]>(`${BASE}/roles?active=Y`,{headers:authH(token)}).then(r=>setAllRoles(r.data)).catch(()=>{});
  },[token]);

  const openDetail = async (u:User) => {
    const r = await axios.get<UserDetail>(`${BASE}/users/${u.username}/detail`,{headers:authH(token)});
    setDetail(r.data); setDetailOpen(true);
  };

  const updateStatus = async (u:User, status:string) => {
    try {
      await axios.put(`${BASE}/users/${u.user_id}`,{status},{headers:authH(token)});
      toast(`User ${u.username} status → ${status}`); refetch();
    } catch(e:any){ toast(e.response?.data?.detail||'Error','err'); }
  };

  const revokeRole = async (username:string, roleKey:string) => {
    try {
      await axios.delete(`${BASE}/users/${username}/revoke-role/${roleKey}`,{headers:authH(token)});
      toast(`Role ${roleKey} revoked`); refetch();
      if(detail) {
        const r = await axios.get<UserDetail>(`${BASE}/users/${username}/detail`,{headers:authH(token)});
        setDetail(r.data);
      }
    } catch(e:any){ toast(e.response?.data?.detail||'Error','err'); }
  };

  return (
    <div>
      {/* toolbar */}
      <div className="toolbar">
        <div className="search-wrap">
          <Search size={13} className="search-icon"/>
          <input className="input search-input" placeholder="Search users…"
            value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>
        <div className="select-wrap" style={{width:140}}>
          <select className="input select" value={statusF} onChange={e=>setStatusF(e.target.value)}>
            <option value="">All statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
            <option value="LOCKED">Locked</option>
          </select>
          <ChevronDown size={12} className="select-arrow"/>
        </div>
        <button className="btn-secondary" onClick={()=>refetch()}><RefreshCw size={12}/> Refresh</button>
        <button className="btn-primary" onClick={()=>setCreateOpen(true)}><UserPlus size={13}/> Add User</button>
      </div>

      {/* table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title"><Users size={13}/> Users</span>
          <span className="badge-count">{users?.length??0}</span>
        </div>
        <table className="data-table">
          <thead><tr>
            <th>Username</th><th>Display Name</th><th>Email</th>
            <th>Roles</th><th>Status</th><th>Last Login</th><th>Logins</th><th></th>
          </tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={8} className="empty-row"><Loader size={14} className="spin"/> Loading…</td></tr>
            : !users?.length ? <tr><td colSpan={8} className="empty-row">No users found</td></tr>
            : users.map(u=>(
              <tr key={u.user_id}>
                <td className="td-main td-mono" style={{fontSize:12}}>{u.username}</td>
                <td>{u.display_name||'—'}</td>
                <td className="td-muted" style={{fontSize:11}}>{u.email||'—'}</td>
                <td>
                  {u.roles ? u.roles.split(',').map((r,i)=>(
                    <RolePill key={r} label={r} color={u.role_colors?.split(',')[i]}/>
                  )) : <span className="td-muted">—</span>}
                </td>
                <td><StatusBadge status={u.status}/></td>
                <td className="td-muted" style={{fontSize:10.5}}>{u.last_login ? new Date(u.last_login).toLocaleDateString() : '—'}</td>
                <td className="td-mono td-muted" style={{textAlign:'center',fontSize:11}}>{u.login_count}</td>
                <td>
                  <div className="row-actions">
                    <button className="icon-btn" title="View detail" onClick={()=>openDetail(u)}><Info size={13}/></button>
                    <button className="icon-btn" title="Assign role"
                      onClick={()=>setAssignOpen(u.username)}><Plus size={13}/></button>
                    {u.status==='ACTIVE'
                      ? <button className="icon-btn icon-btn--warn" title="Lock user"
                          onClick={()=>updateStatus(u,'LOCKED')}><Lock size={13}/></button>
                      : <button className="icon-btn icon-btn--ok" title="Activate user"
                          onClick={()=>updateStatus(u,'ACTIVE')}><Unlock size={13}/></button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create user modal */}
      {createOpen && <CreateUserModal roles={allRoles} token={token}
        onClose={()=>setCreateOpen(false)} onDone={()=>{ setCreateOpen(false); refetch(); }}/>}

      {/* Assign role modal */}
      {assignOpen && <AssignRoleModal username={assignOpen} roles={allRoles} token={token}
        onClose={()=>setAssignOpen(null)} onDone={()=>{ setAssignOpen(null); refetch(); }}/>}

      {/* User detail drawer */}
      {detailOpen && detail && (
        <Drawer title={`${detail.display_name||detail.username}`} onClose={()=>setDetailOpen(false)}>
          <div className="detail-section">
            <div className="detail-kv">
              <span>Username</span><code>{detail.username}</code>
              <span>Email</span><span>{detail.email||'—'}</span>
              <span>Status</span><StatusBadge status={detail.status}/>
              <span>Last Login</span><span>{detail.last_login?new Date(detail.last_login).toLocaleString():'Never'}</span>
              <span>AD Groups</span>
              <span style={{fontSize:10.5,wordBreak:'break-all',color:'var(--text3)'}}>
                {detail.ad_groups?.split('|').map(g=><span key={g} className="mini-pill">{g}</span>)||'—'}
              </span>
            </div>
          </div>

          <div className="detail-section">
            <div className="detail-section-title">Assigned Roles</div>
            {!detail.roles?.length ? <p className="td-muted" style={{fontSize:12}}>No roles assigned</p>
            : detail.roles.map(r=>(
              <div key={r.role_key} className="role-row-detail">
                <RolePill label={r.role_key} color={r.color}/>
                <span className="td-muted" style={{fontSize:10.5}}>{r.display_name}</span>
                <span className="source-tag">{r.source}</span>
                {r.source==='MANUAL' && (
                  <button className="icon-btn icon-btn--danger" title="Revoke"
                    onClick={()=>revokeRole(detail.username, r.role_key)}><X size={11}/></button>
                )}
              </div>
            ))}
          </div>

          <div className="detail-section">
            <div className="detail-section-title">Effective Permissions ({detail.permissions?.length||0})</div>
            <div className="perm-grid">
              {Object.entries(
                (detail.permissions||[]).reduce<Record<string,string[]>>((acc,p)=>{
                  (acc[p.component_name]??=[]).push(p.action_key); return acc;
                },{})).map(([comp,acts])=>(
                <div key={comp} className="perm-comp-row">
                  <span className="perm-comp-name">{comp}</span>
                  <div className="perm-acts">
                    {acts.map(a=>(
                      <span key={a} className="perm-act-chip"
                        style={{background:`${ACTION_COLOR[a as Action]||'#aaa'}18`,color:ACTION_COLOR[a as Action]||'#aaa'}}>
                        {a}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Drawer>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ROLES TAB
══════════════════════════════════════════════════════════════ */
function RolesTab() {
  const { token } = useAuthStore();
  const [createOpen, setCreateOpen] = useState(false);
  const [editRole, setEditRole]     = useState<Role|null>(null);
  const [permOpen, setPermOpen]     = useState<Role|null>(null);
  const [allPerms, setAllPerms]     = useState<PermRow[]>([]);
  const [rolePerms, setRolePerms]   = useState<RolePerm[]>([]);
  const [components, setComponents] = useState<Component[]>([]);

  const { data:roles, loading, refetch } = useApi<Role[]>(`${BASE}/roles`,[]);

  useEffect(()=>{
    axios.get<PermRow[]>(`${BASE}/permissions`,{headers:authH(token)}).then(r=>setAllPerms(r.data)).catch(()=>{});
    axios.get<Component[]>(`${BASE}/components`,{headers:authH(token)}).then(r=>setComponents(r.data)).catch(()=>{});
  },[token]);

  const openPermEditor = async (role:Role) => {
    const r = await axios.get<RolePerm[]>(`${BASE}/roles/${role.role_key}/permissions`,{headers:authH(token)});
    setRolePerms(r.data); setPermOpen(role);
  };

  const togglePerm = async (role:Role, permKey:string, granted:boolean) => {
    try {
      if(granted) {
        await axios.delete(`${BASE}/roles/${role.role_key}/revoke-permission/${permKey}`,{headers:authH(token)});
        setRolePerms(prev=>prev.filter(p=>p.permission_key!==permKey));
      } else {
        await axios.post(`${BASE}/roles/${role.role_key}/grant-permission`,
          {permission_key:permKey},{headers:authH(token)});
        const found = allPerms.find(p=>p.permission_key===permKey);
        if(found) setRolePerms(prev=>[...prev,found as unknown as RolePerm]);
      }
    } catch(e:any){ toast(e.response?.data?.detail||'Error','err'); }
  };

  const deactivateRole = async (role:Role) => {
    if(role.is_system==='Y'){ toast('Cannot deactivate a system role','err'); return; }
    try {
      await axios.put(`${BASE}/roles/${role.role_id}`,{active:'N'},{headers:authH(token)});
      toast(`Role ${role.role_key} deactivated`); refetch();
    } catch(e:any){ toast(e.response?.data?.detail||'Error','err'); }
  };

  const grantedSet = new Set(rolePerms.map(p=>p.permission_key));

  return (
    <div>
      <div className="toolbar">
        <button className="btn-secondary" onClick={()=>refetch()}><RefreshCw size={12}/> Refresh</button>
        <button className="btn-primary" onClick={()=>setCreateOpen(true)}><Plus size={13}/> New Role</button>
      </div>

      <div className="roles-grid">
        {loading ? <div className="loading-state center"><Loader size={16} className="spin"/> Loading roles…</div>
        : roles?.map(role=>(
          <div key={role.role_id} className={`role-card ${role.active==='N'?'role-card--inactive':''}`}>
            <div className="role-card-top">
              <div className="role-color-dot" style={{background:role.color}}/>
              <div className="role-card-meta">
                <span className="role-card-name">{role.display_name}</span>
                <code className="role-card-key">{role.role_key}</code>
              </div>
              {role.is_system==='Y' && <span className="sys-badge">SYSTEM</span>}
            </div>
            <p className="role-card-desc">{role.description||'—'}</p>
            <div className="role-card-stats">
              <span><Shield size={10}/> {role.permission_count} perms</span>
              <span><Users size={10}/> {role.user_count} users</span>
            </div>
            <div className="role-card-actions">
              <button className="btn-secondary btn-sm" onClick={()=>openPermEditor(role)}>
                <Grid3X3 size={11}/> Permissions
              </button>
              <button className="btn-secondary btn-sm" onClick={()=>setEditRole(role)}>
                <Pencil size={11}/> Edit
              </button>
              {role.is_system!=='Y' && (
                <button className="btn-secondary btn-sm btn-sm--danger" onClick={()=>deactivateRole(role)}>
                  <Trash2 size={11}/>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {createOpen && <CreateRoleModal token={token}
        onClose={()=>setCreateOpen(false)} onDone={()=>{ setCreateOpen(false); refetch(); }}/>}

      {editRole && <EditRoleModal role={editRole} token={token}
        onClose={()=>setEditRole(null)} onDone={()=>{ setEditRole(null); refetch(); }}/>}

      {/* Permission editor drawer */}
      {permOpen && (
        <Drawer title={`Permissions — ${permOpen.display_name}`} onClose={()=>setPermOpen(null)} wide>
          <div style={{marginBottom:12}}>
            <p style={{fontSize:12,color:'var(--text3)'}}>
              Click a cell to grant or revoke. Changes are applied immediately.
            </p>
          </div>
          <div className="perm-matrix-editor">
            <div className="pm-header">
              <span className="pm-comp-col">Component</span>
              {ACTIONS.map(a=>(
                <span key={a} className="pm-act-col" style={{color:ACTION_COLOR[a]}}>{a}</span>
              ))}
            </div>
            {components.map(comp=>(
              <div key={comp.component_key} className="pm-row">
                <span className="pm-comp-name">{comp.display_name}</span>
                {ACTIONS.map(act=>{
                  const pkey = `${comp.component_key}:${act}`;
                  const exists = allPerms.find(p=>p.permission_key===pkey);
                  const granted = grantedSet.has(pkey);
                  if(!exists) return <span key={act} className="pm-cell pm-cell--na"><Minus size={10}/></span>;
                  return (
                    <button key={act}
                      className={`pm-cell pm-cell--toggle ${granted?'pm-cell--on':''}`}
                      style={granted?{background:`${ACTION_COLOR[act]}18`,color:ACTION_COLOR[act],borderColor:`${ACTION_COLOR[act]}40`}:{}}
                      onClick={()=>togglePerm(permOpen, pkey, granted)}
                      title={granted?`Revoke ${pkey}`:`Grant ${pkey}`}>
                      {granted ? <Check size={12}/> : <X size={12}/>}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </Drawer>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   PERMISSION MATRIX (read-only overview for all roles)
══════════════════════════════════════════════════════════════ */
function MatrixTab() {
  const { token } = useAuthStore();
  const { data:matrix, loading } = useApi<MatrixRow[]>(`${BASE}/permissions/matrix`,[]);
  const { data:roles } = useApi<Role[]>(`${BASE}/roles?active=Y`,[]);
  const [selectedRole, setSelectedRole] = useState('');
  const [rolePerms, setRolePerms] = useState<Set<string>>(new Set());

  useEffect(()=>{
    if(!selectedRole) { setRolePerms(new Set()); return; }
    axios.get<RolePerm[]>(`${BASE}/roles/${selectedRole}/permissions`,{headers:authH(token)})
      .then(r=>setRolePerms(new Set(r.data.map(p=>p.permission_key))))
      .catch(()=>{});
  },[selectedRole,token]);

  const compToAction = (row:MatrixRow, act:Action): string|null => {
    const key = `${act.toLowerCase()}_perm` as keyof MatrixRow;
    return row[key] as string|null;
  };

  return (
    <div>
      <div className="toolbar" style={{marginBottom:14}}>
        <span style={{fontSize:12,color:'var(--text3)'}}>Filter by role to highlight permissions:</span>
        <div className="select-wrap" style={{width:220}}>
          <select className="input select" value={selectedRole} onChange={e=>setSelectedRole(e.target.value)}>
            <option value="">Show all permissions</option>
            {roles?.map(r=><option key={r.role_key} value={r.role_key}>{r.display_name}</option>)}
          </select>
          <ChevronDown size={12} className="select-arrow"/>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title"><Grid3X3 size={13}/> Component × Action Matrix</span>
          {selectedRole && <span style={{fontSize:11,color:'var(--text3)'}}>
            Highlighted = granted to <RolePill label={selectedRole}
              color={roles?.find(r=>r.role_key===selectedRole)?.color}/>
          </span>}
        </div>
        {loading ? <div className="loading-state" style={{padding:32,justifyContent:'center'}}>
          <Loader size={14} className="spin"/> Loading matrix…</div>
        : (
          <div style={{overflowX:'auto'}}>
            <table className="data-table">
              <thead><tr>
                <th style={{minWidth:180}}>Component</th>
                {ACTIONS.map(a=>(
                  <th key={a} style={{textAlign:'center',color:ACTION_COLOR[a],minWidth:90}}>{a}</th>
                ))}
              </tr></thead>
              <tbody>
                {matrix?.map(row=>(
                  <tr key={row.component_key}>
                    <td className="td-main">{row.display_name}</td>
                    {ACTIONS.map(act=>{
                      const pkey = compToAction(row, act);
                      const granted = pkey ? (selectedRole ? rolePerms.has(pkey) : true) : false;
                      return (
                        <td key={act} style={{textAlign:'center'}}>
                          {!pkey ? <span className="td-muted">—</span>
                          : selectedRole
                            ? <span style={{
                                display:'inline-flex',alignItems:'center',justifyContent:'center',
                                width:26,height:26,borderRadius:6,
                                background: granted?`${ACTION_COLOR[act]}18`:'transparent',
                                color: granted?ACTION_COLOR[act]:'var(--border2)',
                                border:`1px solid ${granted?`${ACTION_COLOR[act]}40`:'var(--border)'}`,
                              }}>
                                {granted?<Check size={12}/>:<X size={12}/>}
                              </span>
                            : <span className="perm-act-chip"
                                style={{background:`${ACTION_COLOR[act]}14`,color:ACTION_COLOR[act]}}>
                                {act}
                              </span>
                          }
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   AD GROUP MAPPING TAB
══════════════════════════════════════════════════════════════ */
function AdMappingTab() {
  const { token } = useAuthStore();
  const [addOpen, setAddOpen] = useState(false);
  const { data:mappings, loading, refetch } = useApi<AdMapping[]>(`${BASE}/ad-group-mappings`,[]);
  const { data:roles } = useApi<Role[]>(`${BASE}/roles?active=Y`,[]);

  const removeMapping = async (cn:string, roleKey:string) => {
    try {
      await axios.delete(`${BASE}/ad-group-mappings/${encodeURIComponent(cn)}/role/${roleKey}`,
        {headers:authH(token)});
      toast('Mapping removed'); refetch();
    } catch(e:any){ toast(e.response?.data?.detail||'Error','err'); }
  };

  return (
    <div>
      <div className="toolbar">
        <div className="info-banner">
          <Info size={13}/>
          <span>When a user logs in via AD, their group memberships are resolved against this mapping and roles are auto-assigned. Manual role assignments are not affected.</span>
        </div>
        <button className="btn-primary" onClick={()=>setAddOpen(true)}><Plus size={13}/> Add Mapping</button>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title"><Link2 size={13}/> AD Group → Role Mappings</span>
          <span className="badge-count">{mappings?.length??0}</span>
        </div>
        <table className="data-table">
          <thead><tr>
            <th>AD Group CN</th>
            <th>Maps to Role</th>
            <th>Status</th>
            <th></th>
          </tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={4} className="empty-row"><Loader size={14} className="spin"/> Loading…</td></tr>
            : !mappings?.length ? <tr><td colSpan={4} className="empty-row">No mappings configured yet</td></tr>
            : mappings.map(m=>(
              <tr key={m.id}>
                <td>
                  <code style={{fontSize:11.5,color:'var(--text)',background:'var(--bg3)',
                    padding:'2px 7px',borderRadius:4}}>{m.ad_group_cn}</code>
                </td>
                <td>
                  <div style={{display:'flex',alignItems:'center',gap:8}}>
                    <ArrowRight size={12} style={{color:'var(--text3)'}}/>
                    <RolePill label={m.role_key} color={m.color}/>
                    <span style={{fontSize:11.5,color:'var(--text2)'}}>{m.role_name}</span>
                  </div>
                </td>
                <td>
                  <StatusBadge status={m.active==='Y'?'ACTIVE':'INACTIVE'}/>
                </td>
                <td>
                  <button className="icon-btn icon-btn--danger" title="Remove mapping"
                    onClick={()=>removeMapping(m.ad_group_cn, m.role_key)}><Trash2 size={13}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {addOpen && <AddAdMappingModal roles={roles||[]} token={token}
        onClose={()=>setAddOpen(false)} onDone={()=>{ setAddOpen(false); refetch(); }}/>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   MODALS
══════════════════════════════════════════════════════════════ */
function Modal({ title, onClose, children, width=480 }:
  { title:string; onClose:()=>void; children:React.ReactNode; width?:number }) {
  return (
    <div className="modal-overlay" onClick={e=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal-box" style={{width}}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}><X size={15}/></button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

function Drawer({ title, onClose, children, wide=false }:
  { title:string; onClose:()=>void; children:React.ReactNode; wide?:boolean }) {
  return (
    <>
      <div className="modal-overlay" onClick={onClose}/>
      <div className={`drawer ${wide?'drawer--wide':''}`}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}><X size={15}/></button>
        </div>
        <div className="drawer-body">{children}</div>
      </div>
    </>
  );
}

function CreateUserModal({ roles, token, onClose, onDone }:
  { roles:Role[]; token:string|null; onClose:()=>void; onDone:()=>void }) {
  const [form, setForm] = useState({ username:'', display_name:'', email:'', status:'ACTIVE', role_key:'' });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const submit = async () => {
    if(!form.username.trim()){ setErr('Username is required'); return; }
    setLoading(true); setErr('');
    try {
      const r = await axios.post(`${BASE}/users`, form, {headers:authH(token)});
      if(form.role_key) {
        await axios.post(`${BASE}/users/${form.username.toLowerCase()}/assign-role`,
          {role_key:form.role_key},{headers:authH(token)});
      }
      toast(`User '${form.username}' created`); onDone();
    } catch(e:any){ setErr(e.response?.data?.detail||'Error'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title="Add User" onClose={onClose}>
      <div className="form-fields">
        <Field label="Username *"><input className="input" placeholder="AD sAMAccountName"
          value={form.username} onChange={e=>setForm(p=>({...p,username:e.target.value}))}/></Field>
        <Field label="Display Name"><input className="input" placeholder="Full name"
          value={form.display_name} onChange={e=>setForm(p=>({...p,display_name:e.target.value}))}/></Field>
        <Field label="Email"><input className="input" type="email" placeholder="user@company.com"
          value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))}/></Field>
        <Field label="Initial Role">
          <div className="select-wrap">
            <select className="input select" value={form.role_key}
              onChange={e=>setForm(p=>({...p,role_key:e.target.value}))}>
              <option value="">None</option>
              {roles.filter(r=>r.active==='Y').map(r=>(
                <option key={r.role_key} value={r.role_key}>{r.display_name}</option>
              ))}
            </select>
            <ChevronDown size={12} className="select-arrow"/>
          </div>
        </Field>
      </div>
      {err && <div className="modal-err"><AlertTriangle size={12}/>{err}</div>}
      <div className="modal-footer">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={submit} disabled={loading}>
          {loading?<><Loader size={12} className="spin"/> Creating…</>:<><Check size={12}/> Create User</>}
        </button>
      </div>
    </Modal>
  );
}

function AssignRoleModal({ username, roles, token, onClose, onDone }:
  { username:string; roles:Role[]; token:string|null; onClose:()=>void; onDone:()=>void }) {
  const [roleKey, setRoleKey]   = useState('');
  const [expiresOn, setExpiresOn] = useState('');
  const [loading, setLoading]   = useState(false);
  const [err, setErr] = useState('');

  const submit = async () => {
    if(!roleKey){ setErr('Select a role'); return; }
    setLoading(true); setErr('');
    try {
      await axios.post(`${BASE}/users/${username}/assign-role`,
        { role_key:roleKey, expires_on:expiresOn||undefined },{headers:authH(token)});
      toast(`Role assigned to ${username}`); onDone();
    } catch(e:any){ setErr(e.response?.data?.detail||'Error'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title={`Assign Role — ${username}`} onClose={onClose} width={420}>
      <div className="form-fields">
        <Field label="Role *">
          <div className="select-wrap">
            <select className="input select" value={roleKey} onChange={e=>setRoleKey(e.target.value)}>
              <option value="">Select role…</option>
              {roles.filter(r=>r.active==='Y').map(r=>(
                <option key={r.role_key} value={r.role_key}>{r.display_name} ({r.role_key})</option>
              ))}
            </select>
            <ChevronDown size={12} className="select-arrow"/>
          </div>
        </Field>
        <Field label="Expires On (optional)">
          <input className="input" type="date" value={expiresOn}
            onChange={e=>setExpiresOn(e.target.value)}/>
        </Field>
      </div>
      {err && <div className="modal-err"><AlertTriangle size={12}/>{err}</div>}
      <div className="modal-footer">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={submit} disabled={loading}>
          {loading?<><Loader size={12} className="spin"/> Assigning…</>:<><Check size={12}/> Assign</>}
        </button>
      </div>
    </Modal>
  );
}

function CreateRoleModal({ token, onClose, onDone }:
  { token:string|null; onClose:()=>void; onDone:()=>void }) {
  const [form, setForm] = useState({ role_key:'', display_name:'', description:'', color:'#58A6FF' });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const PRESETS = ['#F85149','#3FB950','#58A6FF','#D29922','#A78BFA','#FF8C00','#EC4899','#06B6D4'];

  const submit = async () => {
    if(!form.role_key.trim()||!form.display_name.trim()){ setErr('Key and name are required'); return; }
    if(!/^[A-Z0-9_]+$/.test(form.role_key)){ setErr('Role key: uppercase letters, digits, underscores only'); return; }
    setLoading(true); setErr('');
    try {
      await axios.post(`${BASE}/roles`, form, {headers:authH(token)});
      toast(`Role '${form.role_key}' created`); onDone();
    } catch(e:any){ setErr(e.response?.data?.detail||'Error'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title="Create Role" onClose={onClose}>
      <div className="form-fields">
        <Field label="Role Key *" hint="Uppercase, underscores. e.g. REPORT_VIEWER">
          <input className="input td-mono" placeholder="MY_CUSTOM_ROLE"
            value={form.role_key}
            onChange={e=>setForm(p=>({...p,role_key:e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g,'')}))}/>
        </Field>
        <Field label="Display Name *">
          <input className="input" placeholder="My Custom Role"
            value={form.display_name} onChange={e=>setForm(p=>({...p,display_name:e.target.value}))}/>
        </Field>
        <Field label="Description">
          <textarea className="input textarea" placeholder="What this role allows…" rows={2}
            value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}/>
        </Field>
        <Field label="Badge Color">
          <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
            {PRESETS.map(c=>(
              <button key={c} onClick={()=>setForm(p=>({...p,color:c}))}
                style={{ width:22,height:22,borderRadius:6,background:c,border:`2px solid ${form.color===c?'white':'transparent'}`,cursor:'pointer'}}/>
            ))}
            <input type="color" className="input" style={{width:32,height:28,padding:2,cursor:'pointer'}}
              value={form.color} onChange={e=>setForm(p=>({...p,color:e.target.value}))}/>
            <code style={{fontSize:11,color:'var(--text3)'}}>{form.color}</code>
          </div>
        </Field>
      </div>
      {err && <div className="modal-err"><AlertTriangle size={12}/>{err}</div>}
      <div className="modal-footer">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={submit} disabled={loading}>
          {loading?<><Loader size={12} className="spin"/> Creating…</>:<><Check size={12}/> Create Role</>}
        </button>
      </div>
    </Modal>
  );
}

function EditRoleModal({ role, token, onClose, onDone }:
  { role:Role; token:string|null; onClose:()=>void; onDone:()=>void }) {
  const [form, setForm] = useState({ display_name:role.display_name, description:role.description, color:role.color });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');
  const PRESETS = ['#F85149','#3FB950','#58A6FF','#D29922','#A78BFA','#FF8C00','#EC4899','#06B6D4'];

  const submit = async () => {
    setLoading(true); setErr('');
    try {
      await axios.put(`${BASE}/roles/${role.role_id}`, form, {headers:authH(token)});
      toast(`Role updated`); onDone();
    } catch(e:any){ setErr(e.response?.data?.detail||'Error'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title={`Edit Role — ${role.role_key}`} onClose={onClose}>
      <div className="form-fields">
        <Field label="Display Name">
          <input className="input" value={form.display_name} onChange={e=>setForm(p=>({...p,display_name:e.target.value}))}/>
        </Field>
        <Field label="Description">
          <textarea className="input textarea" rows={2} value={form.description}
            onChange={e=>setForm(p=>({...p,description:e.target.value}))}/>
        </Field>
        <Field label="Badge Color">
          <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
            {PRESETS.map(c=>(
              <button key={c} onClick={()=>setForm(p=>({...p,color:c}))}
                style={{width:22,height:22,borderRadius:6,background:c,border:`2px solid ${form.color===c?'white':'transparent'}`,cursor:'pointer'}}/>
            ))}
            <input type="color" className="input" style={{width:32,height:28,padding:2,cursor:'pointer'}}
              value={form.color} onChange={e=>setForm(p=>({...p,color:e.target.value}))}/>
          </div>
        </Field>
      </div>
      {err && <div className="modal-err"><AlertTriangle size={12}/>{err}</div>}
      <div className="modal-footer">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={submit} disabled={loading}>
          {loading?<><Loader size={12} className="spin"/> Saving…</>:<><Save size={12}/> Save</>}
        </button>
      </div>
    </Modal>
  );
}

function AddAdMappingModal({ roles, token, onClose, onDone }:
  { roles:Role[]; token:string|null; onClose:()=>void; onDone:()=>void }) {
  const [adGroup, setAdGroup] = useState('');
  const [roleKey, setRoleKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const submit = async () => {
    if(!adGroup.trim()||!roleKey){ setErr('Both fields required'); return; }
    setLoading(true); setErr('');
    try {
      await axios.post(`${BASE}/ad-group-mappings`,{ad_group_cn:adGroup.trim(),role_key:roleKey},{headers:authH(token)});
      toast('Mapping added'); onDone();
    } catch(e:any){ setErr(e.response?.data?.detail||'Error'); }
    finally { setLoading(false); }
  };

  return (
    <Modal title="Add AD Group Mapping" onClose={onClose} width={440}>
      <div className="form-fields">
        <Field label="AD Group CN *" hint="Exact CN= value from Active Directory (case-sensitive)">
          <input className="input td-mono" placeholder="OTG-Platform-ReadOnly"
            value={adGroup} onChange={e=>setAdGroup(e.target.value)}/>
        </Field>
        <Field label="Maps to Role *">
          <div className="select-wrap">
            <select className="input select" value={roleKey} onChange={e=>setRoleKey(e.target.value)}>
              <option value="">Select role…</option>
              {roles.filter(r=>r.active==='Y').map(r=>(
                <option key={r.role_key} value={r.role_key}>{r.display_name}</option>
              ))}
            </select>
            <ChevronDown size={12} className="select-arrow"/>
          </div>
        </Field>
      </div>
      <div style={{padding:'8px 0 4px',fontSize:11.5,color:'var(--text3)',lineHeight:1.6}}>
        On next login, users in <strong style={{color:'var(--text)'}}>{adGroup||'this group'}</strong> will
        automatically be assigned the <strong style={{color:'var(--text)'}}>{roleKey||'selected'}</strong> role.
      </div>
      {err && <div className="modal-err"><AlertTriangle size={12}/>{err}</div>}
      <div className="modal-footer">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={submit} disabled={loading}>
          {loading?<><Loader size={12} className="spin"/> Adding…</>:<><Link2 size={12}/> Add Mapping</>}
        </button>
      </div>
    </Modal>
  );
}

/* small reusables */
function Field({ label, hint, children }:{ label:string; hint?:string; children:React.ReactNode }) {
  return (
    <div className="form-field">
      <label className="field-label">{label}</label>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   CSS
══════════════════════════════════════════════════════════════ */
const CSS = `
.rbac-page { display:flex; flex-direction:column; gap:14px; }
.rbac-header { display:flex; align-items:flex-start; justify-content:space-between; gap:14px; }
.rbac-title { display:flex; align-items:center; gap:7px; font-size:16px; font-weight:700; color:var(--text); }
.rbac-subtitle { font-size:12px; color:var(--text3); margin-top:4px; }

.rbac-tabs { display:flex; gap:1px; background:var(--bg3); padding:3px; border-radius:var(--radius); width:fit-content; }
.rbac-tab { display:flex; align-items:center; gap:6px; padding:6px 14px; border:none; background:none; color:var(--text2); font-size:12.5px; font-family:var(--font); cursor:pointer; border-radius:5px; transition:all var(--transition); }
.rbac-tab--active { background:var(--bg2); color:var(--text); box-shadow:var(--shadow); }
.rbac-tab:hover:not(.rbac-tab--active) { color:var(--text); }
.rbac-body { }

/* toolbar */
.toolbar { display:flex; align-items:center; gap:8px; margin-bottom:12px; flex-wrap:wrap; }
.search-wrap { position:relative; flex:1; min-width:180px; max-width:300px; }
.search-icon { position:absolute; left:9px; top:50%; transform:translateY(-50%); color:var(--text3); pointer-events:none; }
.search-input { padding-left:30px; }
.badge-count { font-size:10px; font-family:var(--font-mono); background:var(--bg3); border:1px solid var(--border); padding:1px 7px; border-radius:10px; color:var(--text3); }

/* info banner */
.info-banner { display:flex; align-items:flex-start; gap:7px; flex:1; padding:8px 12px; background:rgba(88,166,255,.06); border:1px solid rgba(88,166,255,.2); border-radius:var(--radius); font-size:11.5px; color:var(--text2); line-height:1.5; }

/* roles grid */
.roles-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:12px; }
.role-card { background:var(--bg2); border:1px solid var(--border); border-radius:var(--radius-lg); padding:14px; display:flex; flex-direction:column; gap:10px; transition:border-color var(--transition); }
.role-card:hover { border-color:var(--border2); }
.role-card--inactive { opacity:.5; }
.role-card-top { display:flex; align-items:center; gap:9px; }
.role-color-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }
.role-card-meta { flex:1; }
.role-card-name { display:block; font-size:13px; font-weight:600; color:var(--text); }
.role-card-key  { display:block; font-size:10px; color:var(--text3); margin-top:1px; }
.sys-badge { font-size:9px; font-weight:800; padding:1px 5px; border-radius:3px; background:rgba(248,81,73,.15); color:#F85149; letter-spacing:.05em; }
.role-card-desc { font-size:11.5px; color:var(--text3); line-height:1.5; flex:1; }
.role-card-stats { display:flex; gap:10px; font-size:10.5px; color:var(--text3); font-family:var(--font-mono); }
.role-card-stats span { display:flex; align-items:center; gap:4px; }
.role-card-actions { display:flex; gap:5px; border-top:1px solid var(--border); padding-top:10px; margin-top:auto; }
.btn-sm { padding:4px 9px; font-size:11px; }
.btn-sm--danger { border-color:rgba(248,81,73,.3); color:#F85149; }
.btn-sm--danger:hover { border-color:#F85149; background:rgba(248,81,73,.1); }

/* row actions */
.row-actions { display:flex; align-items:center; gap:4px; }
.icon-btn { width:26px; height:26px; display:flex; align-items:center; justify-content:center; background:transparent; border:1px solid var(--border); border-radius:var(--radius); color:var(--text3); cursor:pointer; transition:all var(--transition); }
.icon-btn:hover { border-color:var(--accent); color:var(--accent); }
.icon-btn--warn:hover  { border-color:var(--warning); color:var(--warning); }
.icon-btn--ok:hover    { border-color:var(--success); color:var(--success); }
.icon-btn--danger:hover { border-color:var(--danger); color:var(--danger); }

/* drawer */
.drawer { position:fixed; top:0; right:0; bottom:0; width:460px; background:var(--bg2); border-left:1px solid var(--border); z-index:300; display:flex; flex-direction:column; box-shadow:-8px 0 32px rgba(0,0,0,.4); animation:slideIn .2s ease; }
.drawer--wide { width:640px; }
@keyframes slideIn { from{transform:translateX(60px);opacity:0} to{transform:translateX(0);opacity:1} }
.drawer-body { flex:1; overflow-y:auto; padding:16px 20px; display:flex; flex-direction:column; gap:16px; }
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.55); z-index:200; }
.modal-box { background:var(--bg2); border:1px solid var(--border); border-radius:var(--radius-lg); margin:auto; margin-top:10vh; box-shadow:var(--shadow-lg); max-height:80vh; display:flex; flex-direction:column; }
.modal-header { display:flex; align-items:center; justify-content:space-between; padding:14px 18px; border-bottom:1px solid var(--border); }
.modal-title { font-size:13.5px; font-weight:700; color:var(--text); }
.modal-close { background:none; border:none; color:var(--text3); cursor:pointer; padding:3px; border-radius:4px; display:flex; transition:color var(--transition); }
.modal-close:hover { color:var(--text); }
.modal-body { padding:16px 18px; overflow-y:auto; }
.modal-footer { display:flex; justify-content:flex-end; gap:8px; padding:14px 18px; border-top:1px solid var(--border); }
.modal-err { display:flex; align-items:center; gap:6px; padding:8px 10px; background:rgba(248,81,73,.08); border:1px solid rgba(248,81,73,.3); border-radius:var(--radius); color:var(--danger); font-size:12px; margin-top:10px; }

/* form fields */
.form-fields { display:flex; flex-direction:column; gap:12px; }
.field-hint { font-size:10.5px; color:var(--text3); margin-top:3px; display:block; }
.textarea { resize:vertical; min-height:60px; }

/* detail drawer */
.detail-section { background:var(--bg3); border:1px solid var(--border); border-radius:var(--radius); padding:12px 14px; }
.detail-section-title { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:var(--text3); margin-bottom:10px; }
.detail-kv { display:grid; grid-template-columns:100px 1fr; gap:7px 12px; align-items:start; font-size:12px; }
.detail-kv span:nth-child(odd) { color:var(--text3); font-size:11px; padding-top:1px; }
.role-row-detail { display:flex; align-items:center; gap:7px; margin-bottom:6px; }
.source-tag { font-size:9.5px; font-family:var(--font-mono); background:var(--bg); border:1px solid var(--border); padding:1px 5px; border-radius:3px; color:var(--text3); margin-left:auto; }
.mini-pill { display:inline-block; font-size:9.5px; background:var(--bg); border:1px solid var(--border); border-radius:4px; padding:0 5px; margin:1px; color:var(--text3); font-family:var(--font-mono); }

/* perm display */
.perm-grid { display:flex; flex-direction:column; gap:6px; }
.perm-comp-row { display:flex; align-items:center; gap:8px; }
.perm-comp-name { font-size:11.5px; font-weight:600; color:var(--text); min-width:140px; }
.perm-acts { display:flex; gap:4px; flex-wrap:wrap; }
.perm-act-chip { font-size:10px; font-weight:700; font-family:var(--font-mono); padding:1px 6px; border-radius:3px; }

/* permission matrix editor */
.perm-matrix-editor { border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; }
.pm-header { display:grid; grid-template-columns:180px repeat(5,1fr); background:var(--bg3); padding:8px 12px; gap:4px; }
.pm-comp-col { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:var(--text3); }
.pm-act-col { font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.06em; text-align:center; }
.pm-row { display:grid; grid-template-columns:180px repeat(5,1fr); padding:6px 12px; gap:4px; align-items:center; border-top:1px solid rgba(48,54,61,.5); }
.pm-row:hover { background:rgba(255,255,255,.015); }
.pm-comp-name { font-size:12px; font-weight:500; color:var(--text); }
.pm-cell { display:flex; align-items:center; justify-content:center; width:32px; height:28px; margin:auto; border-radius:6px; font-size:11px; cursor:default; }
.pm-cell--na { color:var(--border2); border:none; background:none; }
.pm-cell--toggle { background:var(--bg3); border:1px solid var(--border); cursor:pointer; color:var(--text3); transition:all var(--transition); }
.pm-cell--toggle:hover { border-color:var(--accent); }
.pm-cell--on { font-weight:700; }

.loading-state { display:flex; align-items:center; gap:8px; color:var(--text3); font-size:12px; }
`;
