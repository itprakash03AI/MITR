import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Database, Plus, RefreshCw, History, AlertTriangle, CheckCircle,
         ChevronDown, Loader, Shield, Lock } from 'lucide-react';
import axios from 'axios';
import { appConfig } from '../config';
import { useAuthStore } from '../stores/authStore';

/* ── Types ──────────────────────────────────────────────────────────────── */
interface TableMeta {
  table_name:      string;
  column_count:    number;
  insertable_cols: number;
  updatable_cols:  number;
}

interface ColumnMeta {
  column_name:    string;
  column_datatype:string;
  is_pk:          string;
  is_nullable:    string;
  allow_insert:   string;
  allow_update:   string;
  min_group:      string;
  display_label:  string;
  user_can_use:   boolean;
}

interface AuditEntry {
  audit_id:        number;
  operation:       string;
  table_name:      string;
  pk_column:       string;
  pk_value:        string;
  columns_changed: string;
  row_count:       number;
  status:          string;
  error_msg:       string;
  executed_by:     string;
  executed_on:     string;
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */
function authHeader(token: string) {
  return { Authorization: `Bearer ${token}` };
}

const BASE = `${appConfig.apiBaseUrl}/api/v1/admin/dml`;

const OP_COLORS: Record<string, string> = {
  INSERT: 'tag--blue',
  UPDATE: 'tag--yellow',
};

const STATUS_COLORS: Record<string, string> = {
  OK:    'tag--green',
  ERROR: 'tag--red',
};

/* ── Component ───────────────────────────────────────────────────────────── */
export default function AdminDMLPage() {
  const { token, user } = useAuthStore();
  const navigate = useNavigate();

  // Guard: must be OTG_SUPPORT or OTG_ADMIN
  useEffect(() => {
    if (!token) { navigate('/login'); return; }
    if (user && !user.is_support) { navigate('/dashboard'); }
  }, [token, user, navigate]);

  const [activeTab, setActiveTab] = useState<'dml' | 'audit'>('dml');

  // Form state
  const [operation,  setOperation]  = useState<'INSERT' | 'UPDATE'>('UPDATE');
  const [tables,     setTables]     = useState<TableMeta[]>([]);
  const [selTable,   setSelTable]   = useState('');
  const [columns,    setColumns]    = useState<ColumnMeta[]>([]);
  const [pkColumn,   setPkColumn]   = useState('');
  const [pkValue,    setPkValue]    = useState('');
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [loading,    setLoading]    = useState(false);
  const [tablesLoading, setTablesLoading] = useState(true);
  const [colsLoading, setColsLoading]   = useState(false);
  const [result,     setResult]     = useState<any>(null);
  const [error,      setError]      = useState('');

  // Audit log
  const [auditRows,    setAuditRows]    = useState<AuditEntry[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditFilter,  setAuditFilter]  = useState({ table: '', user: '' });

  // ── Load tables ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (!token) return;
    setTablesLoading(true);
    axios.get(`${BASE}/tables`, { headers: authHeader(token) })
      .then(r => { setTables(r.data); if (r.data.length > 0) setSelTable(r.data[0].table_name); })
      .catch(() => setError('Failed to load table list'))
      .finally(() => setTablesLoading(false));
  }, [token]);

  // ── Load columns when table changes ──────────────────────────────────────
  useEffect(() => {
    if (!selTable || !token) return;
    setColsLoading(true);
    setColumns([]);
    setFormValues({});
    setResult(null);
    setError('');
    axios.get(`${BASE}/tables/${selTable}/columns`, { headers: authHeader(token) })
      .then(r => {
        setColumns(r.data);
        const pk = r.data.find((c: ColumnMeta) => c.is_pk === 'Y');
        if (pk) setPkColumn(pk.column_name);
        // Pre-fill form with empty strings for allowed columns
        const init: Record<string, string> = {};
        r.data.forEach((c: ColumnMeta) => {
          if (c.user_can_use && c.allow_update === 'Y') init[c.column_name] = '';
        });
        setFormValues(init);
      })
      .catch(() => setError('Failed to load columns'))
      .finally(() => setColsLoading(false));
  }, [selTable, token]);

  // ── Load audit log ────────────────────────────────────────────────────────
  const loadAudit = () => {
    if (!token) return;
    setAuditLoading(true);
    const params: any = { limit: 50, offset: 0 };
    if (auditFilter.table) params.table_name  = auditFilter.table;
    if (auditFilter.user)  params.executed_by = auditFilter.user;
    axios.get(`${BASE}/audit-log`, { headers: authHeader(token), params })
      .then(r => setAuditRows(r.data))
      .catch(() => {})
      .finally(() => setAuditLoading(false));
  };

  useEffect(() => { if (activeTab === 'audit') loadAudit(); }, [activeTab]);

  // ── Submit DML ────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    setError('');
    setResult(null);

    // Build columns dict from formValues (skip empty string → skip, not null)
    const cols: Record<string, string | null> = {};
    Object.entries(formValues).forEach(([k, v]) => {
      if (v !== '') cols[k] = v || null;
    });

    if (Object.keys(cols).length === 0) {
      setError('Please fill in at least one column value');
      return;
    }

    if (operation === 'UPDATE' && (!pkColumn || !pkValue)) {
      setError('PK column and PK value are required for UPDATE');
      return;
    }

    const body: any = { operation, table_name: selTable, columns: cols };
    if (operation === 'UPDATE') { body.pk_column = pkColumn; body.pk_value = pkValue; }

    setLoading(true);
    try {
      const { data } = await axios.post(`${BASE}/execute`, body,
        { headers: authHeader(token!) });
      setResult(data);
      // Reload audit silently
      if (activeTab === 'audit') loadAudit();
    } catch (e: any) {
      setError(e.response?.data?.detail || e.message || 'DML execution failed');
    } finally {
      setLoading(false);
    }
  };

  // ── Column filter based on operation ─────────────────────────────────────
  const editableCols = columns.filter(c =>
    c.user_can_use &&
    (operation === 'INSERT' ? c.allow_insert === 'Y' : c.allow_update === 'Y') &&
    c.is_pk !== 'Y'
  );

  const nonEditableCols = columns.filter(c =>
    !c.user_can_use ||
    (operation === 'INSERT' ? c.allow_insert !== 'Y' : c.allow_update !== 'Y')
  );

  return (
    <div className="admin-page">
      {/* Header */}
      <div className="admin-header">
        <div>
          <h2 className="admin-title"><Database size={17} /> Generic DML Console</h2>
          <p className="admin-subtitle">
            Direct INSERT / UPDATE on registered OTG tables.
            All operations are audited and require AD group membership.
          </p>
        </div>
        <div className="role-badge" style={{
          background: user?.is_admin ? 'rgba(63,185,80,0.12)' : 'rgba(210,153,34,0.12)',
          color:      user?.is_admin ? 'var(--success)' : 'var(--warning)',
          border:     `1px solid ${user?.is_admin ? 'rgba(63,185,80,0.3)' : 'rgba(210,153,34,0.3)'}`,
        }}>
          <Shield size={12} />
          {user?.otg_role} — {user?.display_name}
        </div>
      </div>

      {/* Tabs */}
      <div className="admin-tabs">
        {(['dml', 'audit'] as const).map(t => (
          <button key={t} className={`admin-tab ${activeTab === t ? 'admin-tab--active' : ''}`}
            onClick={() => setActiveTab(t)}>
            {t === 'dml' ? <><Plus size={13} /> Execute DML</> : <><History size={13} /> Audit Log</>}
          </button>
        ))}
      </div>

      {/* ── DML Tab ── */}
      {activeTab === 'dml' && (
        <div className="dml-layout">
          {/* Sidebar: table selector */}
          <div className="dml-sidebar">
            <div className="sidebar-section-label">Tables</div>
            {tablesLoading ? (
              <div className="loading-state"><Loader size={14} className="spin" /> Loading…</div>
            ) : tables.map(t => (
              <button key={t.table_name}
                className={`table-btn ${selTable === t.table_name ? 'table-btn--active' : ''}`}
                onClick={() => setSelTable(t.table_name)}>
                <span className="table-btn-name">{t.table_name.replace('OTG_', '')}</span>
                <span className="table-btn-meta">{t.updatable_cols} cols</span>
              </button>
            ))}
          </div>

          {/* Main form */}
          <div className="dml-main">
            {/* Operation toggle */}
            <div className="op-toggle-row">
              <div className="op-toggle">
                {(['UPDATE', 'INSERT'] as const).map(op => (
                  <button key={op}
                    className={`op-btn ${operation === op ? 'op-btn--active' : ''}`}
                    onClick={() => { setOperation(op); setResult(null); setError(''); }}>
                    {op}
                  </button>
                ))}
              </div>
              <div className="target-table-label">
                <Database size={13} /> {selTable || 'Select a table'}
              </div>
            </div>

            {colsLoading && (
              <div className="loading-state center"><Loader size={16} className="spin" /> Loading columns…</div>
            )}

            {!colsLoading && selTable && (
              <>
                {/* PK row (UPDATE only) */}
                {operation === 'UPDATE' && (
                  <div className="pk-row card">
                    <div className="pk-row-title"><Lock size={12} /> WHERE condition (PK)</div>
                    <div className="pk-fields">
                      <div className="form-field">
                        <label className="field-label">PK Column</label>
                        <div className="select-wrap">
                          <select className="input select" value={pkColumn}
                            onChange={e => setPkColumn(e.target.value)}>
                            {columns.filter(c => c.is_pk === 'Y').map(c => (
                              <option key={c.column_name} value={c.column_name}>
                                {c.display_label || c.column_name}
                              </option>
                            ))}
                          </select>
                          <ChevronDown size={13} className="select-arrow" />
                        </div>
                      </div>
                      <div className="form-field">
                        <label className="field-label">PK Value <span className="required">*</span></label>
                        <input className="input" placeholder="e.g. 42" value={pkValue}
                          onChange={e => setPkValue(e.target.value)} />
                      </div>
                    </div>
                  </div>
                )}

                {/* Editable columns */}
                <div className="card">
                  <div className="card-header">
                    <span className="card-title">
                      <Plus size={13} />
                      {operation === 'INSERT' ? 'Column Values to INSERT' : 'Columns to UPDATE'}
                    </span>
                    <span className="cols-count">{editableCols.length} editable</span>
                  </div>
                  <div className="cols-form">
                    {editableCols.length === 0 ? (
                      <div className="empty-params">No editable columns for this operation with your role.</div>
                    ) : (
                      <div className="cols-grid">
                        {editableCols.map(col => (
                          <div key={col.column_name} className="form-field">
                            <label className="field-label">
                              {col.display_label || col.column_name}
                              {col.is_nullable === 'N' && <span className="required"> *</span>}
                              <span className="col-type-hint">{col.column_datatype}</span>
                            </label>
                            <input
                              className="input"
                              placeholder={col.is_nullable === 'Y' ? 'optional' : 'required'}
                              value={formValues[col.column_name] ?? ''}
                              onChange={e => setFormValues(prev => ({
                                ...prev, [col.column_name]: e.target.value,
                              }))}
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Locked columns notice */}
                {nonEditableCols.length > 0 && (
                  <div className="locked-cols-notice">
                    <Lock size={11} />
                    Locked (managed by Oracle / higher role required):{' '}
                    {nonEditableCols.map(c => c.column_name).join(', ')}
                  </div>
                )}

                {/* Result / Error */}
                {result && (
                  <div className="result-banner result-banner--ok">
                    <CheckCircle size={15} />
                    <div>
                      <div className="result-title">{result.message}</div>
                      <div className="result-meta">Audit ID: <strong>#{result.audit_id}</strong></div>
                    </div>
                  </div>
                )}

                {error && (
                  <div className="result-banner result-banner--err">
                    <AlertTriangle size={15} />
                    <div className="result-title">{error}</div>
                  </div>
                )}

                {/* Submit */}
                <div className="form-actions">
                  <button className="btn-secondary" onClick={() => {
                    setFormValues({}); setPkValue(''); setResult(null); setError('');
                  }}>Clear</button>
                  <button className="btn-primary" onClick={handleSubmit} disabled={loading}>
                    {loading
                      ? <><Loader size={13} className="spin" /> Executing…</>
                      : <><Database size={13} /> Execute {operation}</>
                    }
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Audit Tab ── */}
      {activeTab === 'audit' && (
        <div className="audit-section">
          <div className="audit-filters">
            <input className="input" style={{ width: 200 }} placeholder="Filter by table…"
              value={auditFilter.table}
              onChange={e => setAuditFilter(v => ({ ...v, table: e.target.value }))} />
            {user?.is_admin && (
              <input className="input" style={{ width: 180 }} placeholder="Filter by user…"
                value={auditFilter.user}
                onChange={e => setAuditFilter(v => ({ ...v, user: e.target.value }))} />
            )}
            <button className="btn-secondary" onClick={loadAudit} disabled={auditLoading}>
              <RefreshCw size={13} className={auditLoading ? 'spin' : ''} /> Refresh
            </button>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title"><History size={13} /> DML Audit Log</span>
              <span className="cols-count">{auditRows.length} entries</span>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Audit ID</th>
                  <th>Operation</th>
                  <th>Table</th>
                  <th>PK</th>
                  <th>Changes</th>
                  <th>Rows</th>
                  <th>Status</th>
                  <th>User</th>
                  <th>Executed On</th>
                </tr>
              </thead>
              <tbody>
                {auditLoading ? (
                  <tr><td colSpan={9} className="empty-row"><Loader size={14} className="spin" /> Loading…</td></tr>
                ) : auditRows.length === 0 ? (
                  <tr><td colSpan={9} className="empty-row">No audit entries found</td></tr>
                ) : auditRows.map(row => (
                  <tr key={row.audit_id}>
                    <td className="td-mono td-muted">#{row.audit_id}</td>
                    <td><span className={`tag ${OP_COLORS[row.operation] || 'tag--blue'}`}>{row.operation}</span></td>
                    <td className="td-main td-mono" style={{ fontSize: 11 }}>{row.table_name}</td>
                    <td className="td-mono td-muted" style={{ fontSize: 11 }}>
                      {row.pk_column ? `${row.pk_column}=${row.pk_value}` : '—'}
                    </td>
                    <td className="td-muted" style={{ fontSize: 10, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                        title={row.columns_changed}>
                      {row.columns_changed?.replace(/\|/g, ' | ') || '—'}
                    </td>
                    <td className="td-mono" style={{ textAlign: 'center' }}>{row.row_count}</td>
                    <td><span className={`tag ${STATUS_COLORS[row.status] || 'tag--blue'}`}>{row.status}</span></td>
                    <td className="td-mono td-muted" style={{ fontSize: 11 }}>{row.executed_by}</td>
                    <td className="td-mono td-muted" style={{ fontSize: 10 }}>
                      {row.executed_on ? new Date(row.executed_on).toLocaleString() : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <style>{`
        .admin-page { display: flex; flex-direction: column; gap: 16px; }
        .admin-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
        .admin-title { display: flex; align-items: center; gap: 7px; font-size: 16px; font-weight: 700; color: var(--text); }
        .admin-subtitle { font-size: 12px; color: var(--text3); margin-top: 4px; }
        .role-badge { display: flex; align-items: center; gap: 6px; padding: 7px 12px; border-radius: 20px; font-size: 11.5px; font-weight: 700; font-family: var(--font-mono); white-space: nowrap; }
        .admin-tabs { display: flex; gap: 1px; background: var(--bg3); padding: 3px; border-radius: var(--radius); width: fit-content; }
        .admin-tab { display: flex; align-items: center; gap: 6px; padding: 6px 14px; border: none; background: none; color: var(--text2); font-size: 12.5px; font-family: var(--font); cursor: pointer; border-radius: 5px; transition: all var(--transition); }
        .admin-tab--active { background: var(--bg2); color: var(--text); box-shadow: var(--shadow); }
        .admin-tab:hover:not(.admin-tab--active) { color: var(--text); }

        .dml-layout { display: grid; grid-template-columns: 200px 1fr; gap: 14px; }
        .dml-sidebar { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 10px 8px; }
        .sidebar-section-label { font-size: 9.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text3); padding: 4px 8px 8px; }
        .table-btn { width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 7px 10px; border: none; background: none; color: var(--text2); font-size: 11.5px; font-family: var(--font); cursor: pointer; border-radius: var(--radius); transition: all var(--transition); text-align: left; }
        .table-btn:hover { background: var(--bg3); color: var(--text); }
        .table-btn--active { background: var(--accent-glow); color: var(--accent); }
        .table-btn-name { font-weight: 600; }
        .table-btn-meta { font-size: 9.5px; color: var(--text3); font-family: var(--font-mono); }

        .dml-main { display: flex; flex-direction: column; gap: 12px; }
        .op-toggle-row { display: flex; align-items: center; gap: 12px; }
        .op-toggle { display: flex; gap: 2px; background: var(--bg3); padding: 3px; border-radius: var(--radius); }
        .op-btn { padding: 5px 16px; border: none; background: none; font-size: 12px; font-weight: 700; font-family: var(--font-mono); cursor: pointer; border-radius: 4px; color: var(--text2); transition: all var(--transition); }
        .op-btn--active { background: var(--accent); color: white; }
        .target-table-label { display: flex; align-items: center; gap: 5px; font-size: 12px; color: var(--text3); font-family: var(--font-mono); }

        .pk-row { padding: 14px 16px; }
        .pk-row-title { display: flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 700; color: var(--warning); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 12px; }
        .pk-fields { display: grid; grid-template-columns: 180px 1fr; gap: 12px; }

        .cols-form { padding: 14px 16px; }
        .cols-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; }
        .cols-count { font-size: 10px; font-family: var(--font-mono); color: var(--text3); }
        .col-type-hint { font-size: 9px; font-family: var(--font-mono); color: var(--text3); margin-left: 5px; background: var(--bg3); padding: 0 4px; border-radius: 3px; }

        .locked-cols-notice { display: flex; align-items: center; gap: 6px; font-size: 10.5px; color: var(--text3); padding: 8px 12px; background: var(--bg3); border-radius: var(--radius); border: 1px solid var(--border); }

        .result-banner { display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: var(--radius); }
        .result-banner--ok  { background: rgba(63,185,80,0.08);  border: 1px solid rgba(63,185,80,0.3);  color: var(--success); }
        .result-banner--err { background: rgba(248,81,73,0.08);  border: 1px solid rgba(248,81,73,0.3);  color: var(--danger); }
        .result-title { font-size: 12.5px; font-weight: 600; }
        .result-meta  { font-size: 11px; opacity: 0.8; margin-top: 3px; }

        .loading-state { display: flex; align-items: center; gap: 8px; padding: 20px; color: var(--text3); font-size: 12px; }
        .loading-state.center { justify-content: center; }

        .audit-section { display: flex; flex-direction: column; gap: 12px; }
        .audit-filters { display: flex; align-items: center; gap: 8px; }
      `}</style>
    </div>
  );
}
