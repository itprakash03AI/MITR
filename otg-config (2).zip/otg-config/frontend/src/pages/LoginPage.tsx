import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, Lock, User, Eye, EyeOff, AlertCircle, Shield } from 'lucide-react';
import axios from 'axios';
import { appConfig, apiPaths } from '../config';
import { useAuthStore } from '../stores/authStore';

const ROLE_COLORS: Record<string, string> = {
  OTG_ADMIN:    '#3FB950',
  OTG_SUPPORT:  '#D29922',
  OTG_READONLY: '#8B949E',
};

export default function LoginPage() {
  const navigate   = useNavigate();
  const { setAuth } = useAuthStore();

  const [username,  setUsername]  = useState('');
  const [password,  setPassword]  = useState('');
  const [showPwd,   setShowPwd]   = useState(false);
  const [loading,   setLoading]   = useState(false);
  const [error,     setError]     = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    setError('');

    try {
      const { data } = await axios.post(`${appConfig.apiBaseUrl}/api/auth/login`, {
        username: username.trim(),
        password,
      });

      setAuth(data.access_token, {
        username:     data.username,
        display_name: data.display_name,
        email:        data.email,
        otg_role:     data.otg_role,
        groups:       data.groups,
        is_admin:     data.groups.includes('OTG_ADMIN'),
        is_support:   data.groups.includes('OTG_SUPPORT') || data.groups.includes('OTG_ADMIN'),
      });

      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      const msg = err.response?.data?.detail || err.message || 'Login failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-root">
      <div className="login-card">
        {/* Brand */}
        <div className="login-brand">
          <div className="login-brand-icon">
            <Zap size={28} />
          </div>
          <h1 className="login-title">{appConfig.appName}</h1>
          <p className="login-subtitle">Sign in with your Active Directory credentials</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-field">
            <label className="field-label">Username <span className="required">*</span></label>
            <div className="input-icon-wrap">
              <User size={15} className="input-icon" />
              <input
                className="input input-with-icon"
                type="text"
                placeholder="sAMAccountName (no domain)"
                value={username}
                onChange={e => setUsername(e.target.value)}
                autoComplete="username"
                autoFocus
                disabled={loading}
              />
            </div>
            <span className="field-hint">Enter your Windows/AD username without domain prefix</span>
          </div>

          <div className="form-field">
            <label className="field-label">Password <span className="required">*</span></label>
            <div className="input-icon-wrap">
              <Lock size={15} className="input-icon" />
              <input
                className="input input-with-icon input-with-action"
                type={showPwd ? 'text' : 'password'}
                placeholder="AD password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="current-password"
                disabled={loading}
              />
              <button type="button" className="input-action" onClick={() => setShowPwd(v => !v)} tabIndex={-1}>
                {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="login-error">
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}

          <button className="btn-primary btn-block" type="submit" disabled={loading || !username || !password}>
            {loading ? <><span className="spin">⟳</span> Authenticating…</> : <><Lock size={14} /> Sign in</>}
          </button>
        </form>

        {/* AD Group legend */}
        <div className="login-roles">
          <div className="roles-title"><Shield size={12} /> Functional Group Access</div>
          {[
            { role: 'OTG_ADMIN',    label: 'OTG-Platform-Admin',    desc: 'Full DML on all tables + audit log' },
            { role: 'OTG_SUPPORT',  label: 'OTG-Platform-Support',  desc: 'UPDATE non-PK columns + audit view' },
            { role: 'OTG_READONLY', label: 'OTG-Platform-ReadOnly', desc: 'Read-only access, no DML' },
          ].map(({ role, label, desc }) => (
            <div key={role} className="role-row">
              <span className="role-dot" style={{ background: ROLE_COLORS[role] }} />
              <div>
                <span className="role-name">{label}</span>
                <span className="role-desc">{desc}</span>
              </div>
            </div>
          ))}
        </div>

        {appConfig.appEnv !== 'production' && (
          <div className="login-dev-hint">
            <span>Dev bypass active — use <code>admin_user</code> / <code>support_user</code> with any password</span>
          </div>
        )}
      </div>

      <style>{`
        .login-root {
          min-height: 100vh; background: var(--bg);
          display: flex; align-items: center; justify-content: center;
          padding: 20px;
        }
        .login-card {
          width: 100%; max-width: 420px;
          background: var(--bg2); border: 1px solid var(--border);
          border-radius: 14px; overflow: hidden;
          box-shadow: var(--shadow-lg);
        }
        .login-brand {
          padding: 28px 28px 20px; text-align: center;
          border-bottom: 1px solid var(--border);
          background: linear-gradient(180deg, rgba(47,129,247,0.04) 0%, transparent 100%);
        }
        .login-brand-icon {
          width: 52px; height: 52px; margin: 0 auto 12px;
          background: linear-gradient(135deg, var(--accent), #7C3AED);
          border-radius: 14px; display: flex; align-items: center; justify-content: center;
          color: white; box-shadow: 0 4px 14px rgba(47,129,247,0.3);
        }
        .login-title { font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 4px; }
        .login-subtitle { font-size: 12px; color: var(--text3); }
        .login-form { padding: 22px 28px; display: flex; flex-direction: column; gap: 14px; }
        .field-hint { font-size: 10.5px; color: var(--text3); margin-top: 3px; display: block; }
        .input-icon-wrap { position: relative; display: flex; align-items: center; }
        .input-icon { position: absolute; left: 10px; color: var(--text3); pointer-events: none; }
        .input-with-icon { padding-left: 32px; }
        .input-with-action { padding-right: 36px; }
        .input-action {
          position: absolute; right: 8px;
          background: none; border: none; color: var(--text3);
          cursor: pointer; padding: 4px; border-radius: 4px;
          display: flex; align-items: center;
        }
        .input-action:hover { color: var(--text); }
        .login-error {
          display: flex; align-items: center; gap: 7px;
          padding: 9px 12px; background: rgba(248,81,73,0.08);
          border: 1px solid rgba(248,81,73,0.3); border-radius: var(--radius);
          color: var(--danger); font-size: 12px;
        }
        .btn-block { width: 100%; justify-content: center; padding: 10px; font-size: 13.5px; }
        .login-roles {
          padding: 16px 28px 18px;
          border-top: 1px solid var(--border);
          background: rgba(255,255,255,0.01);
        }
        .roles-title {
          display: flex; align-items: center; gap: 5px;
          font-size: 10px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 0.08em; color: var(--text3); margin-bottom: 10px;
        }
        .role-row { display: flex; align-items: flex-start; gap: 8px; margin-bottom: 7px; }
        .role-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; margin-top: 5px; }
        .role-name { font-size: 11px; font-weight: 600; color: var(--text); font-family: var(--font-mono); display: block; }
        .role-desc { font-size: 10.5px; color: var(--text3); display: block; margin-top: 1px; }
        .login-dev-hint {
          padding: 10px 28px 14px; font-size: 10.5px; color: var(--warning);
          border-top: 1px solid var(--border); text-align: center;
          background: rgba(210,153,34,0.04);
        }
        .login-dev-hint code {
          background: var(--bg3); padding: 1px 5px; border-radius: 3px;
          font-family: var(--font-mono); font-size: 10px;
        }
      `}</style>
    </div>
  );
}
