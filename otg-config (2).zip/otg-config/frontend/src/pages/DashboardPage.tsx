import { useQuery } from '@tanstack/react-query';
import { Database, FileText, Wind, TrendingUp, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { appConfigApi, reportConfigApi, dagConfigApi } from '../api/client';
import { format } from 'date-fns';
import type { AppConfig, ReportConfig, DagConfig } from '../types';

export function DashboardPage() {
  const { data: apps = [] } = useQuery<AppConfig[]>({
    queryKey: ['apps'],
    queryFn: () => appConfigApi.list({ limit: 100 }),
  });

  const { data: reports = [] } = useQuery<ReportConfig[]>({
    queryKey: ['reports'],
    queryFn: () => reportConfigApi.list({ limit: 100 }),
  });

  const { data: dags = [] } = useQuery<DagConfig[]>({
    queryKey: ['dags'],
    queryFn: () => dagConfigApi.list({ limit: 100 }),
  });

  const stats = [
    {
      label: 'App Connections',
      value: apps.length,
      active: apps.filter(a => a.active === 'Y').length,
      icon: Database,
      color: '#7C3AED',
      bg: 'rgba(124,58,237,0.1)',
    },
    {
      label: 'Report Configs',
      value: reports.length,
      active: reports.filter(r => r.active === 'Y').length,
      icon: FileText,
      color: '#2F81F7',
      bg: 'rgba(47,129,247,0.1)',
    },
    {
      label: 'Airflow DAGs',
      value: dags.length,
      active: dags.filter(d => d.active === 'Y').length,
      icon: Wind,
      color: '#3FB950',
      bg: 'rgba(63,185,80,0.1)',
    },
    {
      label: 'Active Rate',
      value:
        reports.length > 0
          ? `${Math.round((reports.filter(r => r.active === 'Y').length / reports.length) * 100)}%`
          : '—',
      active: null,
      icon: TrendingUp,
      color: '#D29922',
      bg: 'rgba(210,153,34,0.1)',
    },
  ];

  const recentReports = [...reports]
    .sort((a, b) => (b.created_on || '').localeCompare(a.created_on || ''))
    .slice(0, 8);

  const recentDags = [...dags]
    .sort((a, b) => (b.created_date || '').localeCompare(a.created_date || ''))
    .slice(0, 8);

  return (
    <div>
      {/* Stats */}
      <div className="stats-grid">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="stat-card">
              <div className="stat-icon" style={{ background: stat.bg, color: stat.color }}>
                <Icon size={22} />
              </div>
              <div className="stat-body">
                <div className="stat-value">{stat.value}</div>
                <div className="stat-label">{stat.label}</div>
                {stat.active !== null && (
                  <div className="stat-sub">
                    <CheckCircle size={11} style={{ color: '#3FB950' }} />
                    {stat.active} active
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Tables */}
      <div className="two-col-grid">
        <div className="card">
          <div className="card-header">
            <span className="card-title">
              <FileText size={16} /> Recent Reports
            </span>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {recentReports.length === 0 ? (
                <tr><td colSpan={5} className="empty-row">No reports configured yet</td></tr>
              ) : recentReports.map(r => (
                <tr key={r.reportid}>
                  <td className="td-main">{r.file_name}</td>
                  <td><span className="tag tag--blue">{r.file_type}</span></td>
                  <td className="td-mono">{r.priority}</td>
                  <td>
                    <span className={`tag ${r.active === 'Y' ? 'tag--green' : 'tag--red'}`}>
                      {r.active === 'Y' ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="td-muted">
                    {r.created_on ? format(new Date(r.created_on), 'dd MMM yy') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">
              <Wind size={16} /> Recent DAGs
            </span>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>DAG ID</th>
                <th>Type</th>
                <th>Schedule</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentDags.length === 0 ? (
                <tr><td colSpan={4} className="empty-row">No DAGs configured yet</td></tr>
              ) : recentDags.map(d => (
                <tr key={d.otg_dag_id}>
                  <td className="td-mono" style={{ fontSize: 12 }}>{d.dag_id}</td>
                  <td><span className="tag tag--purple">{d.dag_type || 'N/A'}</span></td>
                  <td className="td-mono" style={{ fontSize: 11 }}>{d.schedule_interval || '—'}</td>
                  <td>
                    <span className={`tag ${d.active === 'Y' ? 'tag--green' : 'tag--red'}`}>
                      {d.active === 'Y' ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <style>{`
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 1100px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }

        .stat-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 20px;
          display: flex;
          gap: 16px;
          align-items: flex-start;
          transition: border-color 0.2s;
        }
        .stat-card:hover { border-color: #444; }

        .stat-icon {
          width: 48px; height: 48px;
          border-radius: var(--radius);
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }

        .stat-value { font-size: 28px; font-weight: 700; color: var(--text); line-height: 1; }
        .stat-label { font-size: 12px; color: var(--text3); margin-top: 4px; }
        .stat-sub {
          display: flex; align-items: center; gap: 4px;
          font-size: 11px; color: var(--text3); margin-top: 6px;
        }

        .two-col-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }
        @media (max-width: 900px) { .two-col-grid { grid-template-columns: 1fr; } }

        .card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          overflow: hidden;
        }

        .card-header {
          padding: 14px 18px;
          border-bottom: 1px solid var(--border);
          display: flex; align-items: center; justify-content: space-between;
        }

        .card-title {
          display: flex; align-items: center; gap: 8px;
          font-size: 13px; font-weight: 600; color: var(--text);
        }

        .data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12.5px;
        }
        .data-table th {
          padding: 8px 16px;
          text-align: left;
          font-size: 11px;
          font-weight: 600;
          color: var(--text3);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          background: rgba(255,255,255,0.02);
          border-bottom: 1px solid var(--border);
        }
        .data-table td {
          padding: 10px 16px;
          border-bottom: 1px solid rgba(48,54,61,0.5);
          color: var(--text2);
        }
        .data-table tr:last-child td { border-bottom: none; }
        .data-table tr:hover td { background: rgba(255,255,255,0.02); }

        .td-main { color: var(--text); font-weight: 500; }
        .td-mono { font-family: var(--font-mono); }
        .td-muted { color: var(--text3); }

        .empty-row {
          text-align: center;
          color: var(--text3);
          font-size: 12px;
          padding: 32px 16px !important;
        }

        .tag {
          display: inline-flex; align-items: center;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          font-family: var(--font-mono);
        }
        .tag--blue { background: rgba(47,129,247,0.15); color: #58A6FF; }
        .tag--green { background: rgba(63,185,80,0.15); color: #3FB950; }
        .tag--red { background: rgba(248,81,73,0.15); color: #F85149; }
        .tag--purple { background: rgba(124,58,237,0.15); color: #A78BFA; }
        .tag--yellow { background: rgba(210,153,34,0.15); color: #D29922; }
      `}</style>
    </div>
  );
}
