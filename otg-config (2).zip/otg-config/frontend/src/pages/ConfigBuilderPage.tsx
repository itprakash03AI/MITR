import { useState } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { FileText, Wind, Plus, Trash2, ChevronDown, Save, Check } from 'lucide-react';
import { appConfigApi, reportConfigApi, dagConfigApi } from '../api/client';
import type { AppConfig, ReportConfig } from '../types';

// ─── ZOD SCHEMAS ──────────────────────────────────────────────────────────────

const reportSchema = z.object({
  fk_appid: z.number({ required_error: 'App is required' }),
  file_type: z.enum(['CSV', 'PARQUET', 'EXCEL', 'JSON', 'ORC']),
  file_name: z.string().min(1, 'File name is required'),
  file_format: z.string().optional(),
  file_location: z.string().optional(),
  report_description: z.string().optional(),
  priority: z.number().min(1).max(10).default(5),
  active: z.enum(['Y', 'N']).default('Y'),
  created_by: z.string().optional(),
  params: z.array(z.object({
    operation_key: z.string().min(1, 'Key required'),
    operation_value: z.string().optional(),
    active: z.enum(['Y', 'N']).default('Y'),
  })).default([]),
});

const dagSchema = z.object({
  fk_report_id: z.number({ required_error: 'Report is required' }),
  fk_dest_appid: z.number().optional(),
  dag_id: z.string().min(1, 'DAG ID is required').regex(/^[a-zA-Z0-9_\-.]+$/, 'Alphanumeric, underscores, hyphens, dots only'),
  dag_group: z.string().optional(),
  dag_type: z.string().optional(),
  schedule_interval: z.string().optional(),
  max_active_runs: z.number().min(1).default(1),
  concurrency: z.number().min(1).default(1),
  auto_trigger: z.enum(['Y', 'N']).default('N'),
  auto_skip: z.enum(['Y', 'N']).default('N'),
  tags: z.string().optional(),
  active: z.enum(['Y', 'N']).default('Y'),
  params: z.array(z.object({
    key: z.string().min(1, 'Key required'),
    val: z.string().optional(),
    active: z.enum(['Y', 'N']).default('Y'),
  })).default([]),
});

type Tab = 'report' | 'dag';

// ─── SHARED COMPONENTS ────────────────────────────────────────────────────────

function FormField({ label, required, error, children }: {
  label: string; required?: boolean; error?: string; children: React.ReactNode;
}) {
  return (
    <div className="form-field">
      <label className="field-label">
        {label} {required && <span className="required">*</span>}
      </label>
      {children}
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}

function Input({ ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input className="input" {...props} />;
}

function Select({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="select-wrap">
      <select className="input select" {...props}>{children}</select>
      <ChevronDown size={14} className="select-arrow" />
    </div>
  );
}

function Textarea({ ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="input textarea" {...props} />;
}

// ─── REPORT FORM ─────────────────────────────────────────────────────────────

function ReportForm({ apps }: { apps: AppConfig[] }) {
  const qc = useQueryClient();
  const { register, control, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: zodResolver(reportSchema),
    defaultValues: { priority: 5, active: 'Y', params: [] },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'params' });

  const mutation = useMutation({
    mutationFn: (data: z.infer<typeof reportSchema>) => reportConfigApi.create(data as any),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reports'] });
      reset();
    },
  });

  return (
    <form onSubmit={handleSubmit(d => mutation.mutate(d))} className="config-form">
      <div className="form-section">
        <div className="section-title">Basic Information</div>
        <div className="form-grid-2">
          <FormField label="Application" required error={errors.fk_appid?.message}>
            <Select {...register('fk_appid', { valueAsNumber: true })}>
              <option value="">Select application...</option>
              {apps.map(a => (
                <option key={a.appid} value={a.appid}>
                  [{a.env}] {a.appname}
                </option>
              ))}
            </Select>
          </FormField>

          <FormField label="File Type" required error={errors.file_type?.message}>
            <Select {...register('file_type')}>
              <option value="">Select type...</option>
              {['CSV', 'PARQUET', 'EXCEL', 'JSON', 'ORC'].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </Select>
          </FormField>

          <FormField label="File Name" required error={errors.file_name?.message}>
            <Input {...register('file_name')} placeholder="e.g. daily_sales_report" />
          </FormField>

          <FormField label="File Format" error={errors.file_format?.message}>
            <Input {...register('file_format')} placeholder="e.g. yyyy-MM-dd" />
          </FormField>

          <FormField label="File Location" error={errors.file_location?.message}>
            <Input {...register('file_location')} placeholder="s3://bucket/path/ or /data/exports/" />
          </FormField>

          <FormField label="Priority (1–10)" error={errors.priority?.message}>
            <Input type="number" min={1} max={10} {...register('priority', { valueAsNumber: true })} />
          </FormField>
        </div>

        <FormField label="Description" error={errors.report_description?.message}>
          <Textarea {...register('report_description')} rows={3} placeholder="Describe what this report contains..." />
        </FormField>

        <div className="form-grid-2">
          <FormField label="Created By">
            <Input {...register('created_by')} placeholder="your.username" />
          </FormField>
          <FormField label="Active">
            <Select {...register('active')}>
              <option value="Y">Yes</option>
              <option value="N">No</option>
            </Select>
          </FormField>
        </div>
      </div>

      {/* Parameters */}
      <div className="form-section">
        <div className="section-header-row">
          <div className="section-title">Report Parameters</div>
          <button type="button" className="btn-add" onClick={() => append({ operation_key: '', operation_value: '', active: 'Y' })}>
            <Plus size={14} /> Add Parameter
          </button>
        </div>

        {fields.length === 0 && (
          <div className="empty-params">No parameters added. Click "Add Parameter" to define query or operation parameters.</div>
        )}

        {fields.map((field, idx) => (
          <div key={field.id} className="param-row">
            <Input {...register(`params.${idx}.operation_key`)} placeholder="Key (e.g. START_DATE)" />
            <Input {...register(`params.${idx}.operation_value`)} placeholder="Value or macro (e.g. {{ ds }})" />
            <Select {...register(`params.${idx}.active`)}>
              <option value="Y">Active</option>
              <option value="N">Inactive</option>
            </Select>
            <button type="button" className="btn-remove" onClick={() => remove(idx)}>
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>

      <div className="form-actions">
        <button type="button" className="btn-secondary" onClick={() => reset()}>Reset</button>
        <button type="submit" className="btn-primary" disabled={mutation.isPending}>
          {mutation.isPending ? (
            <span className="btn-loading">Saving...</span>
          ) : mutation.isSuccess ? (
            <><Check size={15} /> Saved!</>
          ) : (
            <><Save size={15} /> Create Report</>
          )}
        </button>
      </div>

      {mutation.isError && (
        <div className="form-error-banner">
          Failed: {(mutation.error as any)?.response?.data?.detail || 'Unknown error'}
        </div>
      )}
    </form>
  );
}

// ─── DAG FORM ─────────────────────────────────────────────────────────────────

function DagForm({ apps, reports }: { apps: AppConfig[]; reports: ReportConfig[] }) {
  const qc = useQueryClient();
  const { register, control, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: zodResolver(dagSchema),
    defaultValues: { max_active_runs: 1, concurrency: 1, auto_trigger: 'N', auto_skip: 'N', active: 'Y', params: [] },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'params' });

  const mutation = useMutation({
    mutationFn: (data: z.infer<typeof dagSchema>) => dagConfigApi.create(data as any),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['dags'] });
      reset();
    },
  });

  const SCHEDULES = [
    { value: '@daily', label: '@daily — Once per day at midnight' },
    { value: '@hourly', label: '@hourly — Once per hour' },
    { value: '@weekly', label: '@weekly — Once per week' },
    { value: '@monthly', label: '@monthly — Once per month' },
    { value: '0 6 * * *', label: '0 6 * * * — Every day at 6am' },
    { value: '0 */4 * * *', label: '0 */4 * * * — Every 4 hours' },
    { value: 'None', label: 'None — Manual trigger only' },
  ];

  return (
    <form onSubmit={handleSubmit(d => mutation.mutate(d))} className="config-form">
      <div className="form-section">
        <div className="section-title">DAG Identity</div>
        <div className="form-grid-2">
          <FormField label="Parent Report" required error={errors.fk_report_id?.message}>
            <Select {...register('fk_report_id', { valueAsNumber: true })}>
              <option value="">Select report...</option>
              {reports.map(r => (
                <option key={r.reportid} value={r.reportid}>
                  [{r.file_type}] {r.file_name}
                </option>
              ))}
            </Select>
          </FormField>

          <FormField label="Destination App" error={errors.fk_dest_appid?.message}>
            <Select {...register('fk_dest_appid', { valueAsNumber: true })}>
              <option value="">None</option>
              {apps.map(a => (
                <option key={a.appid} value={a.appid}>[{a.env}] {a.appname}</option>
              ))}
            </Select>
          </FormField>

          <FormField label="DAG ID" required error={errors.dag_id?.message}>
            <Input {...register('dag_id')} placeholder="e.g. daily_sales_extract_dag" />
          </FormField>

          <FormField label="DAG Group" error={errors.dag_group?.message}>
            <Input {...register('dag_group')} placeholder="e.g. REPORTING" />
          </FormField>

          <FormField label="DAG Type" error={errors.dag_type?.message}>
            <Input {...register('dag_type')} placeholder="e.g. EXTRACT, TRANSFORM, LOAD" />
          </FormField>

          <FormField label="Tags (comma-separated)" error={errors.tags?.message}>
            <Input {...register('tags')} placeholder="e.g. sales, daily, critical" />
          </FormField>
        </div>
      </div>

      <div className="form-section">
        <div className="section-title">Schedule & Execution</div>
        <div className="form-grid-2">
          <FormField label="Schedule Interval" error={errors.schedule_interval?.message}>
            <Select {...register('schedule_interval')}>
              <option value="">Select or type custom cron...</option>
              {SCHEDULES.map(s => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </Select>
          </FormField>

          <FormField label="DAG URL" error={errors.dag_url?.message}>
            <Input {...register('dag_url')} placeholder="http://airflow.company.com/dags/..." />
          </FormField>

          <FormField label="Max Active Runs" error={errors.max_active_runs?.message}>
            <Input type="number" min={1} {...register('max_active_runs', { valueAsNumber: true })} />
          </FormField>

          <FormField label="Concurrency" error={errors.concurrency?.message}>
            <Input type="number" min={1} {...register('concurrency', { valueAsNumber: true })} />
          </FormField>
        </div>

        <div className="form-grid-3">
          <FormField label="Auto Trigger">
            <Select {...register('auto_trigger')}>
              <option value="N">No</option>
              <option value="Y">Yes</option>
            </Select>
          </FormField>
          <FormField label="Auto Skip">
            <Select {...register('auto_skip')}>
              <option value="N">No</option>
              <option value="Y">Yes</option>
            </Select>
          </FormField>
          <FormField label="Active">
            <Select {...register('active')}>
              <option value="Y">Yes</option>
              <option value="N">No</option>
            </Select>
          </FormField>
        </div>
      </div>

      <div className="form-section">
        <div className="section-header-row">
          <div className="section-title">DAG Parameters</div>
          <button type="button" className="btn-add" onClick={() => append({ key: '', val: '', active: 'Y' })}>
            <Plus size={14} /> Add Parameter
          </button>
        </div>

        {fields.length === 0 && (
          <div className="empty-params">No parameters. Add key-value pairs to configure DAG runtime settings.</div>
        )}

        {fields.map((field, idx) => (
          <div key={field.id} className="param-row">
            <Input {...register(`params.${idx}.key`)} placeholder="Key (e.g. CONNECTION_ID)" />
            <Input {...register(`params.${idx}.val`)} placeholder="Value" />
            <Select {...register(`params.${idx}.active`)}>
              <option value="Y">Active</option>
              <option value="N">Inactive</option>
            </Select>
            <button type="button" className="btn-remove" onClick={() => remove(idx)}>
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>

      <div className="form-actions">
        <button type="button" className="btn-secondary" onClick={() => reset()}>Reset</button>
        <button type="submit" className="btn-primary" disabled={mutation.isPending}>
          {mutation.isPending ? 'Saving...' : mutation.isSuccess ? <><Check size={15} /> Saved!</> : <><Save size={15} /> Create DAG</>}
        </button>
      </div>

      {mutation.isError && (
        <div className="form-error-banner">
          Failed: {(mutation.error as any)?.response?.data?.detail || 'Unknown error'}
        </div>
      )}
    </form>
  );
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────

export function ConfigBuilderPage() {
  const [tab, setTab] = useState<Tab>('report');

  const { data: apps = [] } = useQuery<AppConfig[]>({
    queryKey: ['apps'],
    queryFn: () => appConfigApi.list({ limit: 200 }),
  });

  const { data: reports = [] } = useQuery<ReportConfig[]>({
    queryKey: ['reports'],
    queryFn: () => reportConfigApi.list({ limit: 200 }),
    enabled: tab === 'dag',
  });

  return (
    <div className="builder-page">
      <div className="page-intro">
        <p>Create new report configurations and Airflow DAG definitions from a single interface.</p>
      </div>

      <div className="tab-bar">
        <button
          className={`tab-btn ${tab === 'report' ? 'tab-btn--active' : ''}`}
          onClick={() => setTab('report')}
        >
          <FileText size={16} /> Report Configuration
        </button>
        <button
          className={`tab-btn ${tab === 'dag' ? 'tab-btn--active' : ''}`}
          onClick={() => setTab('dag')}
        >
          <Wind size={16} /> Airflow DAG Configuration
        </button>
      </div>

      <div className="builder-body">
        {tab === 'report' ? (
          <ReportForm apps={apps} />
        ) : (
          <DagForm apps={apps} reports={reports} />
        )}
      </div>

      <style>{`
        .builder-page { max-width: 900px; }
        .page-intro { color: var(--text3); font-size: 13px; margin-bottom: 20px; }

        .tab-bar {
          display: flex;
          gap: 4px;
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 4px;
          margin-bottom: 20px;
          width: fit-content;
        }

        .tab-btn {
          display: flex; align-items: center; gap: 8px;
          padding: 8px 20px;
          border-radius: var(--radius);
          border: none;
          background: transparent;
          color: var(--text2);
          font-size: 13.5px;
          font-weight: 500;
          cursor: pointer;
          font-family: var(--font);
          transition: all 0.15s;
        }

        .tab-btn:hover { background: var(--bg3); color: var(--text); }
        .tab-btn--active { background: var(--accent); color: white; }

        .builder-body {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          overflow: hidden;
        }

        .config-form { padding: 24px; }

        .form-section {
          margin-bottom: 28px;
          padding-bottom: 28px;
          border-bottom: 1px solid var(--border);
        }
        .form-section:last-of-type { border-bottom: none; margin-bottom: 0; }

        .section-title {
          font-size: 12px;
          font-weight: 600;
          color: var(--text3);
          text-transform: uppercase;
          letter-spacing: 0.08em;
          margin-bottom: 16px;
        }

        .section-header-row {
          display: flex; align-items: center; justify-content: space-between;
          margin-bottom: 16px;
        }
        .section-header-row .section-title { margin-bottom: 0; }

        .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .form-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-top: 16px; }

        .form-field { display: flex; flex-direction: column; gap: 6px; }

        .field-label {
          font-size: 12px;
          font-weight: 500;
          color: var(--text2);
        }

        .required { color: var(--danger); }
        .field-error { font-size: 11px; color: var(--danger); }

        .input {
          width: 100%;
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 8px 12px;
          color: var(--text);
          font-size: 13px;
          font-family: var(--font);
          transition: border-color 0.15s;
          outline: none;
        }
        .input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-glow); }
        .input::placeholder { color: var(--text3); }

        .select-wrap { position: relative; }
        .select { appearance: none; padding-right: 32px; cursor: pointer; }
        .select-arrow {
          position: absolute; right: 10px; top: 50%;
          transform: translateY(-50%);
          color: var(--text3);
          pointer-events: none;
        }

        .textarea { resize: vertical; min-height: 80px; }

        .param-row {
          display: grid;
          grid-template-columns: 1fr 1fr 100px 36px;
          gap: 8px;
          margin-bottom: 8px;
          align-items: start;
        }

        .btn-add {
          display: flex; align-items: center; gap: 6px;
          padding: 6px 12px;
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          color: var(--text2);
          font-size: 12px;
          font-family: var(--font);
          cursor: pointer;
          transition: all 0.15s;
        }
        .btn-add:hover { border-color: var(--accent); color: var(--accent); }

        .btn-remove {
          width: 36px; height: 36px;
          background: transparent;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          color: var(--text3);
          cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s;
          margin-top: 0;
        }
        .btn-remove:hover { border-color: var(--danger); color: var(--danger); background: rgba(248,81,73,0.05); }

        .empty-params {
          padding: 16px;
          text-align: center;
          color: var(--text3);
          font-size: 12px;
          background: var(--bg3);
          border: 1px dashed var(--border);
          border-radius: var(--radius);
          margin-bottom: 16px;
        }

        .form-actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          padding-top: 20px;
          border-top: 1px solid var(--border);
          margin-top: 20px;
        }

        .btn-primary {
          display: flex; align-items: center; gap: 6px;
          padding: 9px 20px;
          background: var(--accent);
          border: none;
          border-radius: var(--radius);
          color: white;
          font-size: 13.5px;
          font-weight: 600;
          font-family: var(--font);
          cursor: pointer;
          transition: all 0.15s;
        }
        .btn-primary:hover { background: var(--accent2); }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }

        .btn-secondary {
          padding: 9px 16px;
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          color: var(--text2);
          font-size: 13px;
          font-family: var(--font);
          cursor: pointer;
          transition: all 0.15s;
        }
        .btn-secondary:hover { border-color: var(--accent); color: var(--accent); }

        .form-error-banner {
          margin-top: 12px;
          padding: 10px 14px;
          background: rgba(248,81,73,0.1);
          border: 1px solid rgba(248,81,73,0.3);
          border-radius: var(--radius);
          color: var(--danger);
          font-size: 12.5px;
        }
      `}</style>
    </div>
  );
}
