import { useState } from 'react';
import { X, Bell, CheckCircle, XCircle, AlertTriangle, Info, Trash2 } from 'lucide-react';
import { useNotificationStore } from '../../stores/notificationStore';
import { format } from 'date-fns';
import type { WsNotification } from '../../types';

const ICONS = { success: CheckCircle, error: XCircle, warning: AlertTriangle, info: Info };
const COLORS = {
  success: '#3FB950', error: '#F85149', warning: '#D29922', info: '#2F81F7'
};

let drawerOpen = false;
let setDrawerOpenGlobal: (v: boolean) => void = () => {};

export function useNotificationDrawer() {
  return { open: () => setDrawerOpenGlobal(true), close: () => setDrawerOpenGlobal(false) };
}

function NotifItem({ n }: { n: WsNotification }) {
  const Icon = ICONS[n.type] || Info;
  const color = COLORS[n.type] || COLORS.info;
  return (
    <div className="notif-item">
      <Icon size={15} style={{ color, flexShrink: 0, marginTop: 2 }} />
      <div className="notif-item-body">
        <div className="notif-item-title">{n.title}</div>
        <div className="notif-item-msg">{n.message}</div>
        <div className="notif-item-time">
          {format(new Date(n.timestamp), 'dd MMM · HH:mm:ss')}
          {n.entity_type && (
            <span className="notif-entity">{n.entity_type} {n.entity_id ? `#${n.entity_id}` : ''}</span>
          )}
        </div>
      </div>
    </div>
  );
}

export function NotificationDrawer() {
  const [open, setOpen] = useState(false);
  setDrawerOpenGlobal = setOpen;
  const { notifications, clearAll } = useNotificationStore();

  return (
    <>
      {open && <div className="drawer-overlay" onClick={() => setOpen(false)} />}
      <div className={`notif-drawer ${open ? 'notif-drawer--open' : ''}`}>
        <div className="drawer-header">
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Bell size={16} />
            Notifications
            {notifications.length > 0 && (
              <span className="drawer-count">{notifications.length}</span>
            )}
          </span>
          <div style={{ display: 'flex', gap: 8 }}>
            {notifications.length > 0 && (
              <button className="drawer-action" onClick={clearAll} title="Clear all">
                <Trash2 size={13} />
              </button>
            )}
            <button className="drawer-action" onClick={() => setOpen(false)}>
              <X size={14} />
            </button>
          </div>
        </div>

        <div className="drawer-body">
          {notifications.length === 0 ? (
            <div className="drawer-empty">
              <Bell size={28} style={{ color: 'var(--text3)', marginBottom: 8 }} />
              <div>No notifications yet</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>Events from backend will appear here</div>
            </div>
          ) : (
            notifications.map(n => <NotifItem key={n.id} n={n} />)
          )}
        </div>
      </div>

      <style>{`
        .drawer-overlay {
          position: fixed; inset: 0;
          background: rgba(0,0,0,0.5);
          z-index: 200;
        }

        .notif-drawer {
          position: fixed;
          top: 0; right: 0; bottom: 0;
          width: 340px;
          background: var(--bg2);
          border-left: 1px solid var(--border);
          z-index: 201;
          display: flex;
          flex-direction: column;
          transform: translateX(100%);
          transition: transform 0.25s ease;
        }
        .notif-drawer--open { transform: translateX(0); }

        .drawer-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 18px;
          border-bottom: 1px solid var(--border);
          font-size: 14px;
          font-weight: 600;
          color: var(--text);
        }

        .drawer-count {
          background: var(--accent);
          color: white;
          font-size: 10px;
          padding: 1px 6px;
          border-radius: 8px;
          font-weight: 700;
        }

        .drawer-action {
          width: 28px; height: 28px;
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          color: var(--text3);
          cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s;
        }
        .drawer-action:hover { color: var(--text); border-color: var(--accent); }

        .drawer-body {
          flex: 1;
          overflow-y: auto;
          padding: 8px;
        }

        .drawer-empty {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 200px;
          color: var(--text3);
          font-size: 13px;
          text-align: center;
        }

        .notif-item {
          display: flex;
          gap: 10px;
          padding: 10px 12px;
          border-radius: var(--radius);
          margin-bottom: 2px;
          transition: background 0.15s;
        }
        .notif-item:hover { background: var(--bg3); }

        .notif-item-body { flex: 1; }
        .notif-item-title { font-size: 12.5px; font-weight: 600; color: var(--text); }
        .notif-item-msg { font-size: 11.5px; color: var(--text2); margin-top: 2px; line-height: 1.4; }
        .notif-item-time { font-size: 10px; color: var(--text3); margin-top: 4px; display: flex; align-items: center; gap: 8px; font-family: var(--font-mono); }

        .notif-entity {
          background: var(--bg3);
          padding: 1px 6px;
          border-radius: 3px;
          font-size: 9px;
          font-weight: 600;
          color: var(--accent);
        }
      `}</style>
    </>
  );
}
