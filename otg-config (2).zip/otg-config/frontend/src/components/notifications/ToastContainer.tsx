import { useEffect } from 'react';
import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';
import { useNotificationStore } from '../../stores/notificationStore';
import type { WsNotification } from '../../types';

const ICONS = {
  success: CheckCircle,
  error: XCircle,
  warning: AlertTriangle,
  info: Info,
};

const COLORS = {
  success: { bg: 'rgba(63,185,80,0.12)', border: 'rgba(63,185,80,0.35)', icon: '#3FB950' },
  error: { bg: 'rgba(248,81,73,0.12)', border: 'rgba(248,81,73,0.35)', icon: '#F85149' },
  warning: { bg: 'rgba(210,153,34,0.12)', border: 'rgba(210,153,34,0.35)', icon: '#D29922' },
  info: { bg: 'rgba(47,129,247,0.12)', border: 'rgba(47,129,247,0.35)', icon: '#2F81F7' },
};

function Toast({ notification }: { notification: WsNotification }) {
  const { removeNotification } = useNotificationStore();
  const color = COLORS[notification.type] || COLORS.info;
  const Icon = ICONS[notification.type] || Info;

  useEffect(() => {
    const timer = setTimeout(() => {
      if (notification.id) removeNotification(notification.id);
    }, 5000);
    return () => clearTimeout(timer);
  }, [notification.id, removeNotification]);

  return (
    <div
      className="toast"
      style={{ background: color.bg, borderColor: color.border }}
    >
      <Icon size={16} style={{ color: color.icon, flexShrink: 0, marginTop: 1 }} />
      <div className="toast-body">
        <div className="toast-title">{notification.title}</div>
        <div className="toast-message">{notification.message}</div>
      </div>
      <button
        className="toast-close"
        onClick={() => notification.id && removeNotification(notification.id)}
      >
        <X size={13} />
      </button>

      <style>{`
        .toast {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 12px 14px;
          border: 1px solid;
          border-radius: var(--radius);
          min-width: 280px;
          max-width: 380px;
          animation: slideIn 0.25s ease;
          backdrop-filter: blur(8px);
          box-shadow: var(--shadow-lg);
        }

        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }

        .toast-body { flex: 1; }
        .toast-title { font-size: 12.5px; font-weight: 600; color: var(--text); }
        .toast-message { font-size: 11.5px; color: var(--text2); margin-top: 2px; line-height: 1.4; }

        .toast-close {
          background: none;
          border: none;
          color: var(--text3);
          cursor: pointer;
          padding: 2px;
          border-radius: 3px;
          display: flex;
          transition: color 0.15s;
          flex-shrink: 0;
        }
        .toast-close:hover { color: var(--text); }
      `}</style>
    </div>
  );
}

export function ToastContainer() {
  const { notifications } = useNotificationStore();
  // Only show the most recent 4 toasts
  const visible = notifications.slice(0, 4);

  return (
    <div style={{
      position: 'fixed',
      bottom: 24,
      right: 24,
      zIndex: 9999,
      display: 'flex',
      flexDirection: 'column-reverse',
      gap: 8,
    }}>
      {visible.map(n => (
        <Toast key={n.id} notification={n} />
      ))}
    </div>
  );
}
