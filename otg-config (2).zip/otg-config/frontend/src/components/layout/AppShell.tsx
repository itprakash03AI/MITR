import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Settings, Upload, Database,
  Bell, ChevronRight, Zap, Activity, ExternalLink,
  Terminal, LogOut, Users, Shield,
} from 'lucide-react';
import { useState } from 'react';
import { useNotificationStore } from '../../stores/notificationStore';
import { useAuthStore } from '../../stores/authStore';
import { appConfig, apiPaths, isProduction } from '../../config';
import { clsx } from 'clsx';

const ENV_PILL: Record<string,{bg:string;text:string}> = {
  development: {bg:'#1F3A5F',text:'#58A6FF'},
  staging:     {bg:'#3A2A1F',text:'#D29922'},
  production:  {bg:'#1F3A2A',text:'#3FB950'},
};

export function AppShell({ children }: { children: React.ReactNode }) {
  const [notifOpen, setNotifOpen] = useState(false);
  const { notifications } = useNotificationStore();
  const { user, logout, hasAnyPerm } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const unread   = notifications.length;
  const envStyle = ENV_PILL[appConfig.appEnv] || ENV_PILL.development;

  // Role display: pick highest from roles array
  const topRole = user?.roles?.[0] || '';
  const ROLE_COLOR: Record<string,string> = {
    PLATFORM_ADMIN:   '#F85149', SUPPORT_ENGINEER: '#FF8C00',
    CONFIG_MANAGER:   '#3FB950', DAG_OPERATOR:     '#D29922',
    REPORT_VIEWER:    '#58A6FF', BULK_UPLOAD_USER: '#A78BFA',
    USER_ADMIN:       '#EC4899', PLATFORM_READONLY:'#6E7681',
  };
  const roleColor = ROLE_COLOR[topRole] || '#6E7681';

  const NAV: Array<{to:string; icon:any; label:string; perm?:string[]; divider?:boolean}> = [
    { to:'/dashboard',    icon:LayoutDashboard, label:'Dashboard' },
    { to:'/apps',         icon:Database,         label:'App Registry',   perm:['APP_CONFIG:READ']         },
    { to:'/config/new',   icon:Settings,         label:'Config Builder', perm:['REPORT_CONFIG:WRITE','DAG_CONFIG:WRITE'] },
    { to:'/config/upload',icon:Upload,            label:'Bulk Upload',    perm:['BULK_UPLOAD:EXECUTE']     },
    { to:'/admin/dml',    icon:Terminal,          label:'Admin DML',      perm:['ADMIN_DML:EXECUTE','ADMIN_DML:READ'] },
    { to:'/admin/users',  icon:Users,             label:'Users & Roles',  perm:['USER_MGMT:READ']         },
  ].filter(n => !n.perm || hasAnyPerm(...n.perm));

  const pageTitle = NAV.find(n => location.pathname.startsWith(n.to))?.label ?? 'OTG';

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-icon"><Zap size={20}/></div>
          <div className="brand-text">
            <span className="brand-name">{appConfig.appName}</span>
            <span className="brand-version">v{appConfig.appVersion}</span>
          </div>
        </div>

        <div className="env-pill" style={{background:envStyle.bg,color:envStyle.text}}>
          <Activity size={10}/> {appConfig.appEnv.toUpperCase()}
        </div>

        <nav className="sidebar-nav">
          <span className="nav-section-label">Navigation</span>
          {NAV.map(({to,icon:Icon,label})=>(
            <NavLink key={to} to={to}
              className={({isActive})=>clsx('nav-item',{'nav-item--active':isActive})}>
              <Icon size={17} className="nav-icon"/>
              <span className="nav-label">{label}</span>
              <ChevronRight size={13} className="nav-arrow"/>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          {user && (
            <div className="user-info">
              <div className="user-avatar-sm" style={{background:`linear-gradient(135deg,${roleColor},var(--accent))`}}>
                {user.username.charAt(0).toUpperCase()}
              </div>
              <div className="user-details">
                <span className="user-display">{user.display_name||user.username}</span>
                <span className="user-role" style={{color:roleColor,fontSize:9.5}}>
                  {topRole || 'No role'}
                </span>
              </div>
            </div>
          )}
          {!isProduction && appConfig.showApiDocs && (
            <a href={apiPaths.apiDocs} target="_blank" rel="noreferrer" className="sidebar-link">
              <ExternalLink size={12}/> API Docs
            </a>
          )}
          <div className="sidebar-meta">
            <div className="connection-indicator"><span className="live-dot"/> Live</div>
            <button className="logout-btn" onClick={()=>{ logout(); navigate('/login'); }} title="Logout">
              <LogOut size={13}/>
            </button>
          </div>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <h1 className="page-title">{pageTitle}</h1>
            <div className="breadcrumb">
              <span>OTG</span><ChevronRight size={11}/><span>{pageTitle}</span>
            </div>
          </div>
          <div className="topbar-right">
            {user && (
              <div className="perm-count" title={`${user.permissions?.length||0} permissions`}>
                <Shield size={11}/>
                {user.permissions?.length||0} perms
              </div>
            )}
            <button className="notif-btn" onClick={()=>setNotifOpen(o=>!o)}>
              <Bell size={17}/>
              {unread>0 && <span className="notif-count">{unread>99?'99+':unread}</span>}
            </button>
            {user && (
              <div className="user-avatar" style={{background:`linear-gradient(135deg,${roleColor},var(--accent))`}}>
                {user.username.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
        </header>
        <main className="page-content">{children}</main>
      </div>

      {notifOpen && <div className="notif-overlay" onClick={()=>setNotifOpen(false)}/>}
      <div className={clsx('notif-panel',{'notif-panel--open':notifOpen})}>
        <div className="notif-panel-header">
          <span>Notifications {unread>0&&<span className="n-count">{unread}</span>}</span>
          <button onClick={()=>setNotifOpen(false)} className="notif-close">✕</button>
        </div>
        <div className="notif-panel-body">
          {!notifications.length
            ? <div className="notif-empty"><Bell size={24}/><span>No notifications yet</span></div>
            : notifications.map(n=>(
              <div key={n.id} className={`notif-row notif-row--${n.type}`}>
                <div className="notif-row-title">{n.title}</div>
                <div className="notif-row-msg">{n.message}</div>
                <div className="notif-row-time">{new Date(n.timestamp).toLocaleTimeString()}</div>
              </div>
            ))}
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=DM+Mono:wght@400;500&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{
          --bg:#0D1117;--bg2:#161B22;--bg3:#21262D;
          --border:#30363D;--border2:#3D444D;
          --text:#E6EDF3;--text2:#8B949E;--text3:#6E7681;
          --accent:#2F81F7;--accent2:#1F6FEB;--accent-glow:rgba(47,129,247,.15);
          --success:#3FB950;--warning:#D29922;--danger:#F85149;--info:#58A6FF;
          --sidebar-w:220px;--topbar-h:54px;
          --radius:7px;--radius-lg:11px;
          --font:'DM Sans',system-ui,sans-serif;--font-mono:'DM Mono',monospace;
          --shadow:0 1px 4px rgba(0,0,0,.4);--shadow-lg:0 8px 32px rgba(0,0,0,.5);
          --transition:.15s ease;
        }
        body{font-family:var(--font);background:var(--bg);color:var(--text);line-height:1.5}
        button{font-family:var(--font)} a{text-decoration:none}
        .app-shell{display:flex;min-height:100vh}
        .sidebar{width:var(--sidebar-w);min-height:100vh;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:100}
        .sidebar-brand{display:flex;align-items:center;gap:10px;padding:16px 14px 12px;border-bottom:1px solid var(--border)}
        .brand-icon{width:32px;height:32px;background:linear-gradient(135deg,var(--accent),#7C3AED);border-radius:8px;display:flex;align-items:center;justify-content:center;color:white;flex-shrink:0;box-shadow:0 2px 8px rgba(47,129,247,.3)}
        .brand-name{font-size:13.5px;font-weight:700;color:var(--text);display:block}
        .brand-version{font-size:9.5px;color:var(--text3);font-family:var(--font-mono)}
        .env-pill{display:flex;align-items:center;gap:6px;margin:7px 14px;padding:3px 9px;border-radius:20px;font-size:9.5px;font-weight:700;letter-spacing:.08em;font-family:var(--font-mono);width:fit-content}
        .sidebar-nav{flex:1;padding:7px;display:flex;flex-direction:column;gap:1px}
        .nav-section-label{font-size:9.5px;font-weight:700;letter-spacing:.12em;color:var(--text3);text-transform:uppercase;padding:7px 8px 4px}
        .nav-item{display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:var(--radius);color:var(--text2);font-size:12.5px;font-weight:500;cursor:pointer;transition:all var(--transition)}
        .nav-item:hover{background:var(--bg3);color:var(--text)}
        .nav-item--active{background:var(--accent-glow);color:var(--accent)}
        .nav-icon{flex-shrink:0}
        .nav-label{flex:1}
        .nav-arrow{opacity:0;color:var(--text3);transition:opacity var(--transition)}
        .nav-item:hover .nav-arrow,.nav-item--active .nav-arrow{opacity:1}
        .sidebar-footer{padding:10px 14px 14px;border-top:1px solid var(--border);display:flex;flex-direction:column;gap:7px}
        .user-info{display:flex;align-items:center;gap:8px;padding:8px;background:var(--bg3);border-radius:var(--radius)}
        .user-avatar-sm{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:white;flex-shrink:0}
        .user-details{flex:1;overflow:hidden}
        .user-display{font-size:11.5px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block}
        .user-role{font-family:var(--font-mono);font-weight:700;display:block}
        .sidebar-link{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text3);transition:color var(--transition)}
        .sidebar-link:hover{color:var(--accent)}
        .sidebar-meta{display:flex;align-items:center;justify-content:space-between}
        .connection-indicator{display:flex;align-items:center;gap:6px;font-size:10.5px;color:var(--success);font-family:var(--font-mono)}
        .live-dot{width:6px;height:6px;background:var(--success);border-radius:50%;animation:pulse 2s infinite}
        .logout-btn{background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);padding:5px 7px;color:var(--text3);cursor:pointer;display:flex;align-items:center;transition:all var(--transition)}
        .logout-btn:hover{border-color:var(--danger);color:var(--danger)}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
        .main-area{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh}
        .topbar{height:var(--topbar-h);background:var(--bg2);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 20px;position:sticky;top:0;z-index:50}
        .topbar-left{display:flex;flex-direction:column;gap:1px}
        .page-title{font-size:14.5px;font-weight:600;color:var(--text)}
        .breadcrumb{display:flex;align-items:center;gap:4px;font-size:10px;color:var(--text3)}
        .topbar-right{display:flex;align-items:center;gap:9px}
        .perm-count{display:flex;align-items:center;gap:4px;font-size:10.5px;font-family:var(--font-mono);color:var(--text3);background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);padding:3px 8px}
        .notif-btn{position:relative;width:32px;height:32px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);color:var(--text2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all var(--transition)}
        .notif-btn:hover{border-color:var(--accent);color:var(--accent)}
        .notif-count{position:absolute;top:-4px;right:-4px;min-width:16px;height:16px;background:var(--danger);color:white;font-size:9px;font-weight:700;border-radius:8px;display:flex;align-items:center;justify-content:center;padding:0 3px}
        .user-avatar{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:white;cursor:pointer}
        .page-content{flex:1;padding:20px;overflow-y:auto}
        .notif-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:200}
        .notif-panel{position:fixed;top:0;right:0;bottom:0;width:300px;background:var(--bg2);border-left:1px solid var(--border);z-index:201;display:flex;flex-direction:column;transform:translateX(100%);transition:transform .25s ease}
        .notif-panel--open{transform:translateX(0)}
        .notif-panel-header{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--border);font-size:13px;font-weight:600;color:var(--text)}
        .n-count{background:var(--accent);color:white;font-size:9px;padding:1px 5px;border-radius:8px;margin-left:6px}
        .notif-close{background:none;border:none;color:var(--text3);cursor:pointer;font-size:14px;padding:2px 6px;border-radius:4px}
        .notif-panel-body{flex:1;overflow-y:auto;padding:8px}
        .notif-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:140px;gap:10px;color:var(--text3);font-size:12px}
        .notif-row{padding:9px 11px;border-radius:var(--radius);margin-bottom:3px;border-left:3px solid transparent}
        .notif-row--success{border-color:var(--success);background:rgba(63,185,80,.06)}
        .notif-row--error{border-color:var(--danger);background:rgba(248,81,73,.06)}
        .notif-row--warning{border-color:var(--warning);background:rgba(210,153,34,.06)}
        .notif-row--info{border-color:var(--info);background:rgba(88,166,255,.06)}
        .notif-row-title{font-size:12px;font-weight:600;color:var(--text)}
        .notif-row-msg{font-size:11px;color:var(--text2);margin-top:2px}
        .notif-row-time{font-size:10px;color:var(--text3);margin-top:4px;font-family:var(--font-mono)}
        /* Globals */
        .form-field{display:flex;flex-direction:column;gap:5px}
        .field-label{font-size:11.5px;font-weight:600;color:var(--text2)}
        .required{color:var(--danger)}
        .input{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);padding:7px 11px;color:var(--text);font-size:12.5px;font-family:var(--font);outline:none;transition:border-color var(--transition),box-shadow var(--transition)}
        .input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-glow)}
        .input:hover:not(:focus){border-color:var(--border2)}
        .input::placeholder{color:var(--text3)}
        .select-wrap{position:relative}
        .select{appearance:none;padding-right:28px;cursor:pointer}
        .select-arrow{position:absolute;right:8px;top:50%;transform:translateY(-50%);color:var(--text3);pointer-events:none}
        .textarea{resize:vertical;min-height:64px}
        .btn-primary{display:inline-flex;align-items:center;gap:6px;padding:7px 16px;background:var(--accent);border:none;border-radius:var(--radius);color:white;font-size:12.5px;font-weight:600;font-family:var(--font);cursor:pointer;transition:all var(--transition)}
        .btn-primary:hover:not(:disabled){background:var(--accent2);box-shadow:0 2px 8px rgba(47,129,247,.3)}
        .btn-primary:disabled{opacity:.55;cursor:not-allowed}
        .btn-secondary{display:inline-flex;align-items:center;gap:6px;padding:7px 13px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);color:var(--text2);font-size:12px;font-family:var(--font);cursor:pointer;transition:all var(--transition)}
        .btn-secondary:hover:not(:disabled){border-color:var(--accent);color:var(--accent)}
        .card{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius-lg);overflow:hidden}
        .card-header{padding:11px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
        .card-title{display:flex;align-items:center;gap:7px;font-size:12.5px;font-weight:600;color:var(--text)}
        .data-table{width:100%;border-collapse:collapse;font-size:12px}
        .data-table th{padding:7px 14px;text-align:left;font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;background:rgba(255,255,255,.015);border-bottom:1px solid var(--border)}
        .data-table td{padding:8px 14px;border-bottom:1px solid rgba(48,54,61,.5);color:var(--text2)}
        .data-table tr:last-child td{border-bottom:none}
        .data-table tr:hover td{background:rgba(255,255,255,.02)}
        .td-main{color:var(--text);font-weight:500}
        .td-mono{font-family:var(--font-mono)}
        .td-muted{color:var(--text3)}
        .empty-row{text-align:center;color:var(--text3);font-size:12px;padding:28px 16px!important}
        .tag{display:inline-flex;align-items:center;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700;font-family:var(--font-mono)}
        .loading-state{display:flex;align-items:center;gap:8px;color:var(--text3);font-size:12px;padding:16px}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        .spin{animation:spin .9s linear infinite}
      `}</style>
    </div>
  );
}
