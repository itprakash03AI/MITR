// OTG Configuration Platform - TypeScript Type Definitions

export type ActiveFlag = 'Y' | 'N';
export type EnvType = 'DEV' | 'QA' | 'UAT' | 'PROD' | 'STAGING';
export type FileType = 'CSV' | 'PARQUET' | 'EXCEL' | 'JSON' | 'ORC';
export type EntityType = 'report' | 'dag' | 'app';
export type NotificationType = 'success' | 'error' | 'info' | 'warning';

// ─── APP CONFIG ────────────────────────────────────────────────────────────

export interface AppConfig {
  appid: number;
  appname: string;
  env: EnvType;
  hostname?: string;
  db_type?: string;
  db_connection?: string;
  active: ActiveFlag;
  createdon?: string;
  updatedon?: string;
  createdby?: string;
}

export interface AppConfigCreate {
  appname: string;
  env: EnvType;
  hostname?: string;
  db_type?: string;
  db_connection?: string;
  active?: ActiveFlag;
  createdby?: string;
}

export interface AppConfigUpdate extends Partial<AppConfigCreate> {
  updatedby?: string;
}

// ─── REPORT CONFIG ─────────────────────────────────────────────────────────

export interface ReportParam {
  report_param_config_id: number;
  fk_reportid: number;
  operation_key: string;
  operation_value?: string;
  active: ActiveFlag;
  created_on?: string;
}

export interface ReportParamCreate {
  operation_key: string;
  operation_value?: string;
  active?: ActiveFlag;
}

export interface ReportConfig {
  reportid: number;
  fk_appid: number;
  file_type: FileType;
  file_name: string;
  file_format?: string;
  file_location?: string;
  report_description?: string;
  priority: number;
  active: ActiveFlag;
  created_on?: string;
  updated_on?: string;
  created_by?: string;
  params: ReportParam[];
}

export interface ReportConfigCreate {
  fk_appid: number;
  file_type: FileType;
  file_name: string;
  file_format?: string;
  file_location?: string;
  report_description?: string;
  priority?: number;
  active?: ActiveFlag;
  created_by?: string;
  params?: ReportParamCreate[];
}

export interface ReportConfigUpdate extends Partial<Omit<ReportConfigCreate, 'fk_appid' | 'params'>> {
  updated_by?: string;
}

// ─── DAG CONFIG ────────────────────────────────────────────────────────────

export interface DagParam {
  id: number;
  fk_otg_dag_id: number;
  key: string;
  val?: string;
  active: ActiveFlag;
  createdon?: string;
}

export interface DagParamCreate {
  key: string;
  val?: string;
  active?: ActiveFlag;
}

export interface DagConfig {
  otg_dag_id: number;
  fk_report_id: number;
  fk_dest_appid?: number;
  fk_dag_templateid?: number;
  dag_id: string;
  dag_group?: string;
  dag_url?: string;
  dag_type?: string;
  schedule_interval?: string;
  max_active_runs: number;
  concurrency: number;
  auto_trigger: ActiveFlag;
  auto_skip: ActiveFlag;
  tags?: string;
  active: ActiveFlag;
  created_date?: string;
  updatedon?: string;
  params: DagParam[];
}

export interface DagConfigCreate {
  fk_report_id: number;
  fk_dest_appid?: number;
  dag_id: string;
  dag_group?: string;
  dag_url?: string;
  dag_type?: string;
  schedule_interval?: string;
  max_active_runs?: number;
  concurrency?: number;
  auto_trigger?: ActiveFlag;
  auto_skip?: ActiveFlag;
  tags?: string;
  active?: ActiveFlag;
  params?: DagParamCreate[];
}

export interface DagConfigUpdate extends Partial<Omit<DagConfigCreate, 'fk_report_id' | 'dag_id' | 'params'>> {
  updatedby?: string;
}

// ─── UPLOAD ────────────────────────────────────────────────────────────────

export interface ValidationError {
  row: number;
  field: string;
  message: string;
}

export interface ValidationResult {
  is_valid: boolean;
  total_rows: number;
  valid_rows: number;
  errors: ValidationError[];
  preview: Record<string, string>[];
}

export interface BulkUploadResult {
  total_rows: number;
  success_count: number;
  error_count: number;
  errors: ValidationError[];
  created_ids: number[];
}

// ─── NOTIFICATION ──────────────────────────────────────────────────────────

export interface WsNotification {
  type: NotificationType;
  title: string;
  message: string;
  entity_type?: EntityType;
  entity_id?: number;
  timestamp: string;
  id?: string; // client-side unique id
}

// ─── PAGINATION ────────────────────────────────────────────────────────────

export interface PaginationParams {
  skip?: number;
  limit?: number;
  search?: string;
  active?: ActiveFlag;
}

export interface DashboardStats {
  apps: { total: number; active: number };
  reports: { total: number; active: number };
  dags: { total: number; active: number };
}
