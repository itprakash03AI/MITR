import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useRef } from 'react';
import { useAuthStore } from './stores/authStore';
import { useWebSocket } from './hooks/useWebSocket';
import { AppShell } from './components/layout/AppShell';
import { ToastContainer } from './components/notifications/ToastContainer';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ConfigBuilderPage from './pages/ConfigBuilderPage';
import BulkUploadPage from './pages/BulkUploadPage';
import AppConfigPage from './pages/AppConfigPage';
import AdminDMLPage from './pages/AdminDMLPage';
import UserManagementPage from './pages/UserManagementPage';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, retry: 2 } },
});

function hasPerm(permissions: string[], ...perms: string[]) {
  return perms.some(p => permissions.includes(p));
}

function ProtectedApp() {
  const clientId = useRef(`client-${Date.now()}`).current;
  useWebSocket(clientId);
  const { user } = useAuthStore();
  const perms: string[] = (user as any)?.permissions || [];

  return (
    <AppShell>
      <Routes>
        <Route path="/dashboard"    element={<DashboardPage />} />
        <Route path="/config/new"   element={<ConfigBuilderPage />} />
        <Route path="/config/upload"element={<BulkUploadPage />} />
        <Route path="/apps"         element={<AppConfigPage />} />
        {hasPerm(perms,'ADMIN_DML:EXECUTE','ADMIN_DML:READ') && (
          <Route path="/admin/dml"  element={<AdminDMLPage />} />
        )}
        {hasPerm(perms,'USER_MGMT:READ','USER_MGMT:WRITE') && (
          <Route path="/admin/users" element={<UserManagementPage />} />
        )}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppShell>
  );
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { token } = useAuthStore();
  if (!token) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <ToastContainer />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/*" element={<RequireAuth><ProtectedApp /></RequireAuth>} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
