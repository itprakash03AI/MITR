import axios, { AxiosInstance, AxiosError } from 'axios';
import { appConfig, apiPaths } from '../config';
import type {
  AppConfig, AppConfigCreate, AppConfigUpdate,
  ReportConfig, ReportConfigCreate, ReportConfigUpdate,
  DagConfig, DagConfigCreate, DagConfigUpdate,
  ValidationResult, BulkUploadResult, PaginationParams,
} from '../types';

// ── Axios instance driven by centralised config ────────────────────────────
const api: AxiosInstance = axios.create({
  baseURL: `${appConfig.apiBaseUrl}/api/v1`,
  timeout: 30_000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('otg_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (e: AxiosError) => {
    if (e.response?.status === 401) window.location.href = '/login';
    return Promise.reject(e);
  }
);

// ── App Config ─────────────────────────────────────────────────────────────
export const appConfigApi = {
  list: (params?: PaginationParams & { env?: string }) =>
    api.get<AppConfig[]>('/app-config/', { params }).then(r => r.data),
  get: (id: number) => api.get<AppConfig>(`/app-config/${id}`).then(r => r.data),
  create: (data: AppConfigCreate) => api.post<AppConfig>('/app-config/', data).then(r => r.data),
  update: (id: number, data: AppConfigUpdate) => api.put<AppConfig>(`/app-config/${id}`, data).then(r => r.data),
  delete: (id: number) => api.delete(`/app-config/${id}`),
};

// ── Report Config ──────────────────────────────────────────────────────────
export const reportConfigApi = {
  list: (params?: PaginationParams & { app_id?: number; file_type?: string }) =>
    api.get<ReportConfig[]>('/report-config/', { params }).then(r => r.data),
  get: (id: number) => api.get<ReportConfig>(`/report-config/${id}`).then(r => r.data),
  create: (data: ReportConfigCreate) => api.post<ReportConfig>('/report-config/', data).then(r => r.data),
  update: (id: number, data: ReportConfigUpdate) => api.put<ReportConfig>(`/report-config/${id}`, data).then(r => r.data),
  delete: (id: number) => api.delete(`/report-config/${id}`),
  stats: () => api.get('/report-config/stats/summary').then(r => r.data),
};

// ── DAG Config ─────────────────────────────────────────────────────────────
export const dagConfigApi = {
  list: (params?: PaginationParams & { report_id?: number; dag_type?: string }) =>
    api.get<DagConfig[]>('/dag-config/', { params }).then(r => r.data),
  get: (id: number) => api.get<DagConfig>(`/dag-config/${id}`).then(r => r.data),
  create: (data: DagConfigCreate) => api.post<DagConfig>('/dag-config/', data).then(r => r.data),
  update: (id: number, data: DagConfigUpdate) => api.put<DagConfig>(`/dag-config/${id}`, data).then(r => r.data),
  delete: (id: number) => api.delete(`/dag-config/${id}`),
};

// ── Upload ─────────────────────────────────────────────────────────────────
export const uploadApi = {
  downloadTemplate: (entityType: 'report' | 'dag' | 'app') => {
    const link = document.createElement('a');
    link.href = `${appConfig.apiBaseUrl}/api/v1/upload/template/${entityType}`;
    link.download = `otg_${entityType}_config_template.xlsx`;
    link.click();
  },
  validate: (entityType: 'report' | 'dag' | 'app', file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post<ValidationResult>(`/upload/validate/${entityType}`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },
  import: (entityType: 'report' | 'dag' | 'app', file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post<BulkUploadResult>(`/upload/import/${entityType}`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },
};

export default api;
