"""
SQLAlchemy ORM Models - Maps exactly to OTG database schema
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, DateTime, Numeric, CHAR,
    ForeignKey, Index, CheckConstraint, text
)
from sqlalchemy.orm import relationship
from database import Base


class AppConfig(Base):
    """OTG_APP_CONFIG - Application/Data Source Registry"""
    __tablename__ = "OTG_APP_CONFIG"

    appid = Column("APPID", Numeric(10), primary_key=True, autoincrement=True)
    appname = Column("APPNAME", String(200), nullable=False, unique=True)
    env = Column("ENV", String(50), nullable=False)
    hostname = Column("HOSTNAME", String(500))
    db_type = Column("DB_TYPE", String(50))  # oracle, snowflake, starburst, etc.
    db_connection = Column("DB_CONNECTION", String(1000))
    active = Column("ACTIVE", CHAR(1), default="Y")
    createdon = Column("CREATEDON", DateTime, default=datetime.utcnow)
    createdby = Column("CREATEDBY", String(100))
    updatedon = Column("UPDATEDON", DateTime, onupdate=datetime.utcnow)
    updatedby = Column("UPDATEDBY", String(100))

    # Relationships
    reports = relationship("ReportConfig", back_populates="app", cascade="all, delete-orphan")
    dags = relationship("AirflowDagConfig", foreign_keys="AirflowDagConfig.fk_dest_appid", back_populates="dest_app")

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_app_active"),
        Index("idx_app_name_env", "APPNAME", "ENV"),
    )


class ReportConfig(Base):
    """OTG_REPORT_CONFIG - Report definitions"""
    __tablename__ = "OTG_REPORT_CONFIG"

    reportid = Column("REPORTID", Numeric(10), primary_key=True, autoincrement=True)
    fk_appid = Column("FK_APPID", Numeric(10), ForeignKey("OTG_APP_CONFIG.APPID"), nullable=False)
    file_type = Column("FILE_TYPE", String(50))      # CSV, PARQUET, EXCEL, JSON
    file_name = Column("FILE_NAME", String(500), nullable=False)
    file_format = Column("FILE_FORMAT", String(200))
    file_location = Column("FILE_LOCATION", String(1000))
    report_description = Column("REPORT_DESCRIPTION", String(2000))
    priority = Column("PRIORITY", Numeric(5), default=5)
    active = Column("ACTIVE", CHAR(1), default="Y")
    created_on = Column("CREATED_ON", DateTime, default=datetime.utcnow)
    created_by = Column("CREATED_BY", String(100))
    updated_on = Column("UPDATED_ON", DateTime, onupdate=datetime.utcnow)
    updated_by = Column("UPDATED_BY", String(100))

    # Relationships
    app = relationship("AppConfig", back_populates="reports")
    params = relationship("ReportParamConfig", back_populates="report", cascade="all, delete-orphan")
    dags = relationship("AirflowDagConfig", back_populates="report")
    source_dependencies = relationship(
        "ReportDependencyMapping",
        foreign_keys="ReportDependencyMapping.fk_report_id",
        back_populates="report"
    )

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_report_active"),
        CheckConstraint("FILE_TYPE IN ('CSV','PARQUET','EXCEL','JSON','ORC')", name="chk_file_type"),
        Index("idx_report_appid", "FK_APPID"),
    )


class ReportParamConfig(Base):
    """OTG_REPORT_PARAM_CONFIG - Report query parameters"""
    __tablename__ = "OTG_REPORT_PARAM_CONFIG"

    report_param_config_id = Column("REPORT_PARAM_CONFIG_ID", Numeric(10), primary_key=True, autoincrement=True)
    fk_reportid = Column("FK_REPORTID", Numeric(10), ForeignKey("OTG_REPORT_CONFIG.REPORTID"), nullable=False)
    operation_key = Column("OPERATION_KEY", String(200), nullable=False)
    operation_value = Column("OPERATION_VALUE", String(2000))
    active = Column("ACTIVE", CHAR(1), default="Y")
    created_on = Column("CREATED_ON", DateTime, default=datetime.utcnow)
    created_by = Column("CREATED_BY", String(100))
    updated_on = Column("UPDATED_ON", DateTime, onupdate=datetime.utcnow)
    updated_by = Column("UPDATED_BY", String(100))

    # Relationships
    report = relationship("ReportConfig", back_populates="params")

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_rparam_active"),
        Index("idx_rparam_reportid", "FK_REPORTID"),
    )


class AirflowDagConfig(Base):
    """OTG_AIRFLOW_DAG_CONFIG - Airflow DAG definitions"""
    __tablename__ = "OTG_AIRFLOW_DAG_CONFIG"

    otg_dag_id = Column("OTG_DAG_ID", Numeric(10), primary_key=True, autoincrement=True)
    fk_report_id = Column("FK_REPORT_ID", Numeric(10), ForeignKey("OTG_REPORT_CONFIG.REPORTID"), nullable=False)
    fk_dest_appid = Column("FK_DEST_APPID", Numeric(10), ForeignKey("OTG_APP_CONFIG.APPID"))
    fk_dag_templateid = Column("FK_DAG_TEMPLATEID", Numeric(10))
    dag_id = Column("DAG_ID", String(300), nullable=False, unique=True)
    dag_group = Column("DAG_GROUP", String(200))
    dag_url = Column("DAG_URL", String(1000))
    dag_type = Column("DAG_TYPE", String(100))
    schedule_interval = Column("SCHEDULE_INTERVAL", String(100))   # cron expression
    max_active_runs = Column("MAX_ACTIVE_RUNS", Numeric(5), default=1)
    concurrency = Column("CONCURRENCY", Numeric(5), default=1)
    auto_trigger = Column("AUTO_TRIGGER", CHAR(1), default="N")
    auto_skip = Column("AUTO_SKIP", CHAR(1), default="N")
    tags = Column("TAGS", String(500))
    active = Column("ACTIVE", CHAR(1), default="Y")
    created_date = Column("CREATED_DATE", DateTime, default=datetime.utcnow)
    updatedon = Column("UPDATEDON", DateTime, onupdate=datetime.utcnow)
    updatedby = Column("UPDATEDBY", String(100))

    # Relationships
    report = relationship("ReportConfig", back_populates="dags")
    dest_app = relationship("AppConfig", foreign_keys=[fk_dest_appid], back_populates="dags")
    params = relationship("DagParamConfig", back_populates="dag", cascade="all, delete-orphan")
    dependencies = relationship("ReportDependencyMapping", foreign_keys="ReportDependencyMapping.fk_site_dag_id", back_populates="site_dag")

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_dag_active"),
        CheckConstraint("AUTO_TRIGGER IN ('Y','N')", name="chk_auto_trigger"),
        Index("idx_dag_report", "FK_REPORT_ID"),
        Index("idx_dag_id_unique", "DAG_ID"),
    )


class DagParamConfig(Base):
    """OTG_AIRFLOW_DAG_PARAM_CONFIG - DAG runtime parameters"""
    __tablename__ = "OTG_AIRFLOW_DAG_PARAM_CONFIG"

    id = Column("ID", Numeric(10), primary_key=True, autoincrement=True)
    fk_otg_dag_id = Column("FK_OTG_DAG_ID", Numeric(10), ForeignKey("OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID"), nullable=False)
    fk_taskid = Column("FK_TASKID", Numeric(10))
    key = Column("KEY", String(300), nullable=False)
    val = Column("VAL", String(2000))
    active = Column("ACTIVE", CHAR(1), default="Y")
    createdon = Column("CREATEDON", DateTime, default=datetime.utcnow)
    createdby = Column("CREATEDBY", String(100))
    updatedon = Column("UPDATEDON", DateTime, onupdate=datetime.utcnow)
    updatedby = Column("UPDATEDBY", String(100))

    # Relationships
    dag = relationship("AirflowDagConfig", back_populates="params")

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_dparam_active"),
        Index("idx_dparam_dagid", "FK_OTG_DAG_ID"),
    )


class ReportDependencyMapping(Base):
    """OTG_REPORT_DEPENDENCY_MAPPING - DAG dependency graph"""
    __tablename__ = "OTG_REPORT_DEPENDENCY_MAPPING"

    id = Column("ID", Numeric(10), primary_key=True, autoincrement=True)
    fk_report_id = Column("FK_REPORT_ID", Numeric(10), ForeignKey("OTG_REPORT_CONFIG.REPORTID"), nullable=False)
    fk_site_dag_id = Column("FK_SITE_DAG_ID", Numeric(10), ForeignKey("OTG_AIRFLOW_DAG_CONFIG.OTG_DAG_ID"))
    fk_dependency_type_id = Column("FK_DEPENDENCY_TYPE_ID", Numeric(10))
    fk_dependency_id = Column("FK_DEPENDENCY_ID", Numeric(10))
    active = Column("ACTIVE", CHAR(1), default="Y")

    # Relationships
    report = relationship("ReportConfig", foreign_keys=[fk_report_id], back_populates="source_dependencies")
    site_dag = relationship("AirflowDagConfig", foreign_keys=[fk_site_dag_id], back_populates="dependencies")

    __table_args__ = (
        CheckConstraint("ACTIVE IN ('Y','N')", name="chk_dep_active"),
        Index("idx_dep_report", "FK_REPORT_ID"),
    )
