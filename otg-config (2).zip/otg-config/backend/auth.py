"""
auth.py — Active Directory + JWT Authentication
================================================
Flow:
  1. POST /api/auth/login  → ldap3 binds with user credentials against AD
  2. On success → resolve group memberships → issue JWT
  3. All protected routes use Depends(require_auth) or Depends(require_group(...))
  4. Groups drive RBAC: OTG_ADMIN > OTG_SUPPORT > OTG_READONLY

AD Group mapping (in .env → AD_GROUP_ADMIN / AD_GROUP_SUPPORT / AD_GROUP_READONLY):
  OTG_ADMIN    — full generic DML (INSERT + UPDATE all tables)
  OTG_SUPPORT  — UPDATE on non-PK columns, view audit log
  OTG_READONLY — read-only API access (GET endpoints only)
"""
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional, List

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from ldap3 import Server, Connection, ALL, NTLM, SIMPLE, SUBTREE
from ldap3.core.exceptions import LDAPBindError, LDAPSocketOpenError

from config import get_settings

logger = logging.getLogger("otg.auth")
settings = get_settings()

# ── Constants ─────────────────────────────────────────────────────────────────

ROLE_ADMIN    = "OTG_ADMIN"
ROLE_SUPPORT  = "OTG_SUPPORT"
ROLE_READONLY = "OTG_READONLY"

ROLE_HIERARCHY = {ROLE_ADMIN: 3, ROLE_SUPPORT: 2, ROLE_READONLY: 1}

bearer_scheme = HTTPBearer(auto_error=False)


# ── JWT helpers ───────────────────────────────────────────────────────────────

class TokenPayload:
    def __init__(self, username: str, display_name: str, email: str,
                 groups: List[str], otg_role: str):
        self.username     = username
        self.display_name = display_name
        self.email        = email
        self.groups       = groups
        self.otg_role     = otg_role       # highest OTG role

    @property
    def is_admin(self) -> bool:
        return ROLE_ADMIN in self.groups

    @property
    def is_support(self) -> bool:
        return ROLE_SUPPORT in self.groups or self.is_admin

    @property
    def ad_groups_str(self) -> str:
        return "|".join(self.groups)


def create_token(payload: TokenPayload) -> str:
    now = datetime.now(timezone.utc)
    claims = {
        "sub":          payload.username,
        "name":         payload.display_name,
        "email":        payload.email,
        "groups":       payload.groups,
        "otg_role":     payload.otg_role,
        "iat":          now,
        "exp":          now + timedelta(minutes=settings.TOKEN_EXPIRE_MINUTES),
        "iss":          settings.APP_NAME,
    }
    return jwt.encode(claims, settings.SECRET_KEY, algorithm="HS256")


def decode_token(token: str) -> TokenPayload:
    try:
        claims = jwt.decode(
            token, settings.SECRET_KEY, algorithms=["HS256"],
            options={"require": ["sub", "exp", "groups"]}
        )
        return TokenPayload(
            username=claims["sub"],
            display_name=claims.get("name", claims["sub"]),
            email=claims.get("email", ""),
            groups=claims.get("groups", []),
            otg_role=claims.get("otg_role", ROLE_READONLY),
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {e}")


# ── AD / LDAP connector ───────────────────────────────────────────────────────

def _resolve_otg_role(groups: List[str]) -> str:
    """Return the highest OTG role the user holds."""
    best = ROLE_READONLY
    best_level = 0
    for g in groups:
        level = ROLE_HIERARCHY.get(g, 0)
        if level > best_level:
            best_level = level
            best = g
    return best


def _get_cn(dn: str) -> str:
    """Extract CN value from a Distinguished Name."""
    for part in dn.split(","):
        part = part.strip()
        if part.upper().startswith("CN="):
            return part[3:]
    return dn


def authenticate_ad(username: str, password: str) -> TokenPayload:
    """
    Bind to AD with user credentials, resolve group membership, return TokenPayload.
    Raises HTTPException on failure.
    """
    ad_server   = settings.AD_SERVER
    ad_domain   = settings.AD_DOMAIN
    ad_base_dn  = settings.AD_BASE_DN
    ad_auth     = settings.AD_AUTH_METHOD.upper()   # NTLM | SIMPLE

    if not ad_server:
        # Dev bypass: accept any non-empty password when AD is not configured
        logger.warning("AD_SERVER not configured — using dev bypass auth")
        return _dev_bypass_auth(username)

    try:
        server = Server(ad_server, get_info=ALL, connect_timeout=5)
        bind_user = f"{ad_domain}\\{username}" if ad_auth == "NTLM" else f"{username}@{ad_domain}"
        auth_type = NTLM if ad_auth == "NTLM" else SIMPLE

        conn = Connection(server, user=bind_user, password=password,
                         authentication=auth_type, auto_bind=True)

    except LDAPBindError:
        logger.warning(f"AD bind failed for user: {username}")
        raise HTTPException(status_code=401,
                            detail="Invalid credentials — check username and password")
    except LDAPSocketOpenError:
        logger.error(f"Cannot reach AD server: {ad_server}")
        raise HTTPException(status_code=503,
                            detail="Authentication service unavailable — contact support")
    except Exception as e:
        logger.error(f"AD error for {username}: {e}")
        raise HTTPException(status_code=503, detail="Authentication error")

    # Search for the user to get display name, email, groups
    search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
    conn.search(
        search_base=ad_base_dn,
        search_filter=search_filter,
        search_scope=SUBTREE,
        attributes=["cn", "mail", "memberOf", "displayName"],
    )

    if not conn.entries:
        conn.unbind()
        raise HTTPException(status_code=401, detail="User not found in directory")

    entry        = conn.entries[0]
    display_name = str(entry.displayName or entry.cn or username)
    email        = str(entry.mail or "")
    member_of    = list(entry.memberOf) if entry.memberOf else []
    conn.unbind()

    # Extract CN names from memberOf DNs
    raw_groups = [_get_cn(dn) for dn in member_of]

    # Filter to only OTG functional groups
    otg_functional_groups = {
        settings.AD_GROUP_ADMIN:    ROLE_ADMIN,
        settings.AD_GROUP_SUPPORT:  ROLE_SUPPORT,
        settings.AD_GROUP_READONLY: ROLE_READONLY,
    }
    otg_groups = [
        role for grp, role in otg_functional_groups.items()
        if grp and any(grp.lower() == g.lower() for g in raw_groups)
    ]

    if not otg_groups:
        logger.warning(f"User {username} has no OTG functional groups")
        raise HTTPException(status_code=403,
                            detail="Access denied — you are not a member of any OTG functional group")

    role = _resolve_otg_role(otg_groups)
    logger.info(f"AD auth success: {username} | role={role} | groups={otg_groups}")

    return TokenPayload(
        username=username,
        display_name=display_name,
        email=email,
        groups=otg_groups,
        otg_role=role,
    )


def _dev_bypass_auth(username: str) -> TokenPayload:
    """
    Dev-mode fallback when AD_SERVER is not set.
    Maps test usernames to roles:
      admin_user  → OTG_ADMIN
      support_user → OTG_SUPPORT
      *           → OTG_READONLY
    """
    if "admin" in username.lower():
        groups = [ROLE_ADMIN, ROLE_SUPPORT, ROLE_READONLY]
        role   = ROLE_ADMIN
    elif "support" in username.lower():
        groups = [ROLE_SUPPORT, ROLE_READONLY]
        role   = ROLE_SUPPORT
    else:
        groups = [ROLE_READONLY]
        role   = ROLE_READONLY

    return TokenPayload(
        username=username,
        display_name=f"Dev {username.title()}",
        email=f"{username}@dev.local",
        groups=groups,
        otg_role=role,
    )


# ── FastAPI dependencies ──────────────────────────────────────────────────────

async def require_auth(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> TokenPayload:
    """Base dependency — requires a valid JWT. Returns the token payload."""
    if not credentials:
        raise HTTPException(status_code=401,
                            detail="Missing Authorization header (Bearer token required)")
    token = decode_token(credentials.credentials)
    # Attach to request state so routers can access it without re-decoding
    request.state.user = token
    return token


def require_group(min_role: str):
    """
    Factory: returns a dependency that requires at least min_role.
    Usage:  Depends(require_group(ROLE_ADMIN))
    """
    async def _check(user: TokenPayload = Depends(require_auth)) -> TokenPayload:
        user_level = ROLE_HIERARCHY.get(user.otg_role, 0)
        need_level = ROLE_HIERARCHY.get(min_role, 999)
        if user_level < need_level:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied — requires {min_role}, you have {user.otg_role}"
            )
        return user
    return _check


def get_client_ip(request: Request) -> str:
    """Extract real client IP, honouring X-Forwarded-For from OpenShift HAProxy."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
