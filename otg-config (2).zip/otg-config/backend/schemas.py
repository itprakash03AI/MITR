"""
Pydantic v2 Schemas - Request/Response validation and serialization
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator, model_validator
import re


# ─── APP CONFIG ────────────────────────────────────────────────────────────────

class AppConfigBase(BaseModel):
    appname: str = Field(..., min_length=1, max_length=200, description="Unique application name")
    env: str = Field(..., min_length=1, max_length=50, description="Environment: DEV, QA, UAT, PROD")
    hostname: Optional[str] = Field(None, max_length=500)
    db_type: Optional[str] = Field(None, description="oracle | snowflake | starburst | postgres")
    db_connection: Optional[str] = Field(None, max_length=1000)
    active: str = Field("Y", pattern="^[YN]$")
    createdby: Optional[str] = Field(None, max_length=100)

    @field_validator("env")
    @classmethod
    def validate_env(cls, v):
        allowed = {"DEV", "QA", "UAT", "PROD", "STAGING"}
        if v.upper() not in allowed:
            raise ValueError(f"env must be one of {allowed}")
        return v.upper()


class AppConfigCreate(AppConfigBase):
    pass


class AppConfigUpdate(BaseModel):
    appname: Optional[str] = Field(None, max_length=200)
    env: Optional[str] = None
    hostname: Optional[str] = None
    db_type: Optional[str] = None
    db_connection: Optional[str] = None
    active: Optional[str] = Field(None, pattern="^[YN]$")
    updatedby: Optional[str] = None


class AppConfigResponse(AppConfigBase):
    appid: int
    createdon: Optional[datetime]
    updatedon: Optional[datetime]

    model_config = {"from_attributes": True}


# ─── REPORT CONFIG ─────────────────────────────────────────────────────────────

class ReportParamBase(BaseModel):
    operation_key: str = Field(..., min_length=1, max_length=200)
    operation_value: Optional[str] = Field(None, max_length=2000)
    active: str = Field("Y", pattern="^[YN]$")


class ReportParamCreate(ReportParamBase):
    pass


class ReportParamResponse(ReportParamBase):
    report_param_config_id: int
    fk_reportid: int
    created_on: Optional[datetime]

    model_config = {"from_attributes": True}


class ReportConfigBase(BaseModel):
    fk_appid: int = Field(..., description="Parent App Config ID")
    file_type: str = Field(..., description="CSV | PARQUET | EXCEL | JSON | ORC")
    file_name: str = Field(..., min_length=1, max_length=500)
    file_format: Optional[str] = Field(None, max_length=200)
    file_location: Optional[str] = Field(None, max_length=1000)
    report_description: Optional[str] = Field(None, max_length=2000)
    priority: int = Field(5, ge=1, le=10)
    active: str = Field("Y", pattern="^[YN]$")
    created_by: Optional[str] = Field(None, max_length=100)

    @field_validator("file_type")
    @classmethod
    def validate_file_type(cls, v):
        allowed = {"CSV", "PARQUET", "EXCEL", "JSON", "ORC"}
        if v.upper() not in allowed:
            raise ValueError(f"file_type must be one of {allowed}")
        return v.upper()


class ReportConfigCreate(ReportConfigBase):
    params: Optional[List[ReportParamCreate]] = Field(default_factory=list)


class ReportConfigUpdate(BaseModel):
    file_type: Optional[str] = None
    file_name: Optional[str] = None
    file_format: Optional[str] = None
    file_location: Optional[str] = None
    report_description: Optional[str] = None
    priority: Optional[int] = Field(None, ge=1, le=10)
    active: Optional[str] = Field(None, pattern="^[YN]$")
    updated_by: Optional[str] = None


class ReportConfigResponse(ReportConfigBase):
    reportid: int
    created_on: Optional[datetime]
    updated_on: Optional[datetime]
    params: List[ReportParamResponse] = []

    model_config = {"from_attributes": True}


# ─── DAG CONFIG ────────────────────────────────────────────────────────────────

class DagParamBase(BaseModel):
    key: str = Field(..., min_length=1, max_length=300)
    val: Optional[str] = Field(None, max_length=2000)
    active: str = Field("Y", pattern="^[YN]$")


class DagParamCreate(DagParamBase):
    pass


class DagParamResponse(DagParamBase):
    id: int
    fk_otg_dag_id: int
    createdon: Optional[datetime]

    model_config = {"from_attributes": True}


class DagConfigBase(BaseModel):
    fk_report_id: int = Field(..., description="Parent Report Config ID")
    fk_dest_appid: Optional[int] = Field(None, description="Destination App Config ID")
    dag_id: str = Field(..., min_length=1, max_length=300, description="Unique Airflow DAG ID")
    dag_group: Optional[str] = Field(None, max_length=200)
    dag_url: Optional[str] = Field(None, max_length=1000)
    dag_type: Optional[str] = Field(None, max_length=100)
    schedule_interval: Optional[str] = Field(None, max_length=100, description="Cron expression or @daily etc.")
    max_active_runs: int = Field(1, ge=1, le=100)
    concurrency: int = Field(1, ge=1, le=50)
    auto_trigger: str = Field("N", pattern="^[YN]$")
    auto_skip: str = Field("N", pattern="^[YN]$")
    tags: Optional[str] = Field(None, max_length=500)
    active: str = Field("Y", pattern="^[YN]$")

    @field_validator("dag_id")
    @classmethod
    def validate_dag_id(cls, v):
        if not re.match(r'^[a-zA-Z0-9_\-\.]+$', v):
            raise ValueError("dag_id must contain only alphanumeric chars, underscores, hyphens, dots")
        return v

    @field_validator("schedule_interval")
    @classmethod
    def validate_schedule(cls, v):
        if v is None:
            return v
        presets = {"@once", "@hourly", "@daily", "@weekly", "@monthly", "@yearly", "None"}
        if v in presets:
            return v
        # Basic cron validation: 5 space-separated parts
        parts = v.split()
        if len(parts) != 5:
            raise ValueError("schedule_interval must be a valid cron expression (5 parts) or a preset like @daily")
        return v


class DagConfigCreate(DagConfigBase):
    params: Optional[List[DagParamCreate]] = Field(default_factory=list)


class DagConfigUpdate(BaseModel):
    dag_group: Optional[str] = None
    dag_url: Optional[str] = None
    dag_type: Optional[str] = None
    schedule_interval: Optional[str] = None
    max_active_runs: Optional[int] = Field(None, ge=1)
    concurrency: Optional[int] = Field(None, ge=1)
    auto_trigger: Optional[str] = Field(None, pattern="^[YN]$")
    auto_skip: Optional[str] = Field(None, pattern="^[YN]$")
    tags: Optional[str] = None
    active: Optional[str] = Field(None, pattern="^[YN]$")
    updatedby: Optional[str] = None


class DagConfigResponse(DagConfigBase):
    otg_dag_id: int
    fk_dag_templateid: Optional[int]
    created_date: Optional[datetime]
    updatedon: Optional[datetime]
    params: List[DagParamResponse] = []

    model_config = {"from_attributes": True}


# ─── BULK UPLOAD ───────────────────────────────────────────────────────────────

class BulkUploadResult(BaseModel):
    total_rows: int
    success_count: int
    error_count: int
    errors: List[dict] = []
    created_ids: List[int] = []


class ValidationResult(BaseModel):
    is_valid: bool
    total_rows: int
    valid_rows: int
    errors: List[dict] = []
    preview: List[dict] = []


# ─── NOTIFICATION ──────────────────────────────────────────────────────────────

class NotificationPayload(BaseModel):
    type: str           # "success" | "error" | "info" | "warning"
    title: str
    message: str
    entity_type: Optional[str] = None   # "report" | "dag" | "app"
    entity_id: Optional[int] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
