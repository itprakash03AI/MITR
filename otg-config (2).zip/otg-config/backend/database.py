"""
Oracle Database - Connection pool using centralized Settings
"""
import logging
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from sqlalchemy.pool import QueuePool
import oracledb

from config import get_settings

logger = logging.getLogger("otg.database")
settings = get_settings()

# ── Oracle client init ──────────────────────────────────────────────────────
if not settings.ORACLE_THIN_MODE:
    if settings.ORACLE_CLIENT_LIB_DIR:
        oracledb.init_oracle_client(lib_dir=settings.ORACLE_CLIENT_LIB_DIR)
        logger.info(f"Oracle thick mode: client at {settings.ORACLE_CLIENT_LIB_DIR}")
    else:
        oracledb.init_oracle_client()
        logger.info("Oracle thick mode: using system Oracle Client")
else:
    logger.info("Oracle thin mode (no client library required)")

# ── Engine ─────────────────────────────────────────────────────────────────
engine = create_engine(
    settings.database_url,
    poolclass=QueuePool,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_timeout=settings.DB_POOL_TIMEOUT,
    pool_recycle=settings.DB_POOL_RECYCLE,
    pool_pre_ping=True,
    echo=settings.DB_ECHO,
    connect_args={"retry_count": 3, "retry_delay": 1},
)


@event.listens_for(engine, "connect")
def on_connect(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS'")
    cursor.execute("ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF3'")
    if settings.ORACLE_SCHEMA:
        cursor.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {settings.ORACLE_SCHEMA}")
    cursor.close()
    logger.debug("Oracle connection initialized")


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        logger.error(f"DB session error: {e}")
        db.rollback()
        raise
    finally:
        db.close()


def check_db_connection() -> bool:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1 FROM DUAL"))
        return True
    except Exception as e:
        logger.error(f"DB health check failed: {e}")
        return False
