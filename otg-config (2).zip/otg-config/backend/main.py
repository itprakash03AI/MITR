"""
OTG Config Platform - FastAPI Entry Point
All Oracle DML via stored packages. AD auth via ldap3 + JWT.
"""
import logging
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager

from config import get_settings
from oracle_utils import get_oracle_conn
from websocket_manager import manager
from routers import app_config, report_config, dag_config, param_config, upload
from routers import auth_router, admin_dml, user_mgmt

settings = get_settings()

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("otg.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"🚀 {settings.APP_NAME} v{settings.APP_VERSION} [{settings.APP_ENV}]")
    if settings.POD_NAME:
        logger.info(f"   Pod: {settings.POD_NAME} | NS: {settings.POD_NAMESPACE}")
    logger.info(f"   AD Server: {settings.AD_SERVER or 'NOT CONFIGURED (dev bypass active)'}")
    logger.info("   Oracle pool: lazy — will connect on first request")

    yield
    logger.info("🛑 Shutdown complete")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Enterprise config management for Reports and Airflow DAGs. "
        "AD-authenticated. All DML via Oracle stored packages."
    ),
    docs_url=settings.docs_url,
    redoc_url=settings.redoc_url,
    lifespan=lifespan,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Public routes (no auth) ────────────────────────────────────────────────────
app.include_router(auth_router.router, prefix="/api/auth", tags=["Authentication"])

# ── Protected routes (JWT required) ───────────────────────────────────────────
app.include_router(app_config.router,    prefix="/api/v1/app-config",    tags=["App Config"])
app.include_router(report_config.router, prefix="/api/v1/report-config", tags=["Report Config"])
app.include_router(dag_config.router,    prefix="/api/v1/dag-config",    tags=["DAG Config"])
app.include_router(param_config.router,  prefix="/api/v1/param-config",  tags=["Param Config"])
app.include_router(upload.router,        prefix="/api/v1/upload",         tags=["Bulk Upload"])

# ── Admin DML (OTG_SUPPORT / OTG_ADMIN only) ──────────────────────────────────
app.include_router(user_mgmt.router,     prefix="/api/v1/rbac",          tags=["RBAC"])
app.include_router(admin_dml.router,     prefix="/api/v1/admin/dml",     tags=["Admin DML"])


@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    if manager.connected_count >= settings.WS_MAX_CONNECTIONS:
        await websocket.close(code=1008, reason="Max connections reached")
        return
    await manager.connect(websocket, client_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(client_id)


@app.get("/api/health", tags=["Health"])
async def health():
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION, "env": settings.APP_ENV}


@app.get("/api/health/ready", tags=["Health"])
async def readiness():
    db_ok = False
    try:
        with get_oracle_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM DUAL")
        db_ok = True
    except Exception:
        pass
    return {"status": "ready" if db_ok else "not_ready", "oracle": "ok" if db_ok else "unreachable",
            "ws_connections": manager.connected_count}


@app.get("/api/runtime-config", tags=["Health"])
async def runtime_config():
    return {
        "app": settings.APP_NAME, "version": settings.APP_VERSION, "env": settings.APP_ENV,
        "oracle_host": settings.ORACLE_HOST, "oracle_port": settings.ORACLE_PORT,
        "oracle_service": settings.ORACLE_SERVICE, "ad_server": settings.AD_SERVER or "not configured",
        "ad_group_admin": settings.AD_GROUP_ADMIN, "ad_group_support": settings.AD_GROUP_SUPPORT,
        "pod_name": settings.POD_NAME, "pod_namespace": settings.POD_NAMESPACE,
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host=settings.HOST, port=settings.PORT,
                workers=settings.WORKERS, reload=settings.RELOAD,
                log_level=settings.LOG_LEVEL.lower())
