"""
oracle_utils.py
---------------
The ONLY module that executes Oracle procedures, functions, and REF CURSORs.
No inline SQL in routers. All DML goes through Oracle packages.

Usage pattern:
    with get_oracle_conn() as conn:
        result = call_proc(conn, "PKG_APP_CONFIG.CREATE_APP", {...})
        rows   = call_func_cursor(conn, "PKG_APP_CONFIG.LIST_APPS", {...})
"""
import logging
from contextlib import contextmanager
from typing import Any, Optional
import oracledb

from config import get_settings

logger = logging.getLogger("otg.oracle")
settings = get_settings()


# ── Connection pool (separate from SQLAlchemy — used for raw proc calls) ─────

_pool: Optional[oracledb.ConnectionPool] = None


def init_pool() -> None:
    """Call once at startup to create the oracledb connection pool."""
    global _pool
    if _pool is not None:
        return

    dsn = oracledb.makedsn(
        host=settings.ORACLE_HOST,
        port=settings.ORACLE_PORT,
        service_name=settings.ORACLE_SERVICE,
    )
    _pool = oracledb.create_pool(
        user=settings.ORACLE_USER,
        password=settings.ORACLE_PASSWORD,
        dsn=dsn,
        min=0,
        max=settings.DB_POOL_SIZE,
        increment=1,
        getmode=oracledb.POOL_GETMODE_WAIT,
        wait_timeout=settings.DB_POOL_TIMEOUT * 1000,  # ms
    )
    logger.info(
        f"Oracle pool initialised: {settings.ORACLE_USER}@"
        f"{settings.ORACLE_HOST}/{settings.ORACLE_SERVICE} "
        f"(min=2 max={settings.DB_POOL_SIZE})"
    )


@contextmanager
def get_oracle_conn():
    """Context manager — acquires a connection from the pool, returns it on exit."""
    if _pool is None:
        init_pool()
    conn = _pool.acquire()
    try:
        if settings.ORACLE_SCHEMA:
            with conn.cursor() as cur:
                cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {settings.ORACLE_SCHEMA}")
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        _pool.release(conn)


# ── Core helpers ──────────────────────────────────────────────────────────────

def _map_out_vars(cursor, out_params: dict) -> dict:
    """Resolve oracledb Variable objects into plain Python values."""
    return {k: (v.getvalue() if hasattr(v, 'getvalue') else v)
            for k, v in out_params.items()}


def call_proc(conn: oracledb.Connection, proc_name: str, params: dict) -> dict:
    """
    Call a stored procedure and return OUT parameter values.

    params dict uses sentinels:
      - oracledb.NUMBER  → OUT NUMBER
      - oracledb.STRING  → OUT VARCHAR2
      - plain value      → IN parameter

    Example:
        out_id = oracledb.NUMBER
        result = call_proc(conn, "PKG_APP_CONFIG.CREATE_APP", {
            "p_appname": "SalesDB",
            "p_env":     "PROD",
            "p_appid":   out_id,   # OUT
        })
        new_id = result["p_appid"]
    """
    with conn.cursor() as cur:
        # Separate IN params from OUT vars
        bound = {}
        for key, val in params.items():
            if val in (oracledb.NUMBER, oracledb.STRING, oracledb.CURSOR):
                bound[key] = cur.var(val)
            else:
                bound[key] = val

        cur.callproc(proc_name, keywordParameters=bound)

        return _map_out_vars(cur, {k: v for k, v in bound.items()
                                   if hasattr(v, 'getvalue')})


def call_func_cursor(conn: oracledb.Connection, func_name: str,
                     params: dict) -> list[dict]:
    """
    Call a stored function that returns SYS_REFCURSOR.
    Returns a list of row dicts.

    Example:
        rows = call_func_cursor(conn, "PKG_APP_CONFIG.LIST_APPS", {
            "p_env": "PROD", "p_active": "Y",
        })
    """
    with conn.cursor() as cur:
        ref_cur = cur.callfunc(func_name, oracledb.CURSOR,
                               keywordParameters=params)
        columns = [col[0].lower() for col in ref_cur.description]
        rows = [dict(zip(columns, row)) for row in ref_cur]
        ref_cur.close()
        return rows


def call_func_scalar(conn: oracledb.Connection, func_name: str,
                     return_type, params: dict) -> Any:
    """
    Call a stored function that returns a scalar (NUMBER, VARCHAR2).

    Example:
        err = call_func_scalar(conn, "PKG_BULK_UPLOAD.VALIDATE_REPORT_ROW",
                               oracledb.STRING, {"p_fk_appid": 1, ...})
    """
    with conn.cursor() as cur:
        result = cur.callfunc(func_name, return_type, keywordParameters=params)
        return result


def execute_query(conn: oracledb.Connection, sql: str,
                  params: Optional[dict] = None) -> list[dict]:
    """
    Execute a SELECT query (read-only; used only for lightweight admin queries).
    Prefer package functions wherever possible.
    """
    with conn.cursor() as cur:
        cur.execute(sql, params or {})
        columns = [col[0].lower() for col in cur.description]
        return [dict(zip(columns, row)) for row in cur]


# ── Serialisation helper ──────────────────────────────────────────────────────

def serialise_row(row: dict) -> dict:
    """Convert Oracle-specific types to JSON-serialisable Python types."""
    import datetime
    result = {}
    for k, v in row.items():
        if isinstance(v, datetime.datetime):
            result[k] = v.isoformat()
        elif isinstance(v, datetime.date):
            result[k] = v.isoformat()
        elif hasattr(v, 'read'):
            result[k] = v.read()        # LOB
        else:
            result[k] = v
    return result
