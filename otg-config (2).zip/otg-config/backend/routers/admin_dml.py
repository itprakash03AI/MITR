from typing import Optional
from fastapi import APIRouter, Request, Depends, HTTPException, Query
from pydantic import BaseModel, Field, model_validator
import oracledb
from rbac import require_perm, Permission, TokenPayload, get_client_ip
from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, serialise_row
import logging

router = APIRouter()
logger = logging.getLogger("otg.admin_dml")

class DmlRequest(BaseModel):
    operation:  str = Field(..., pattern="^(INSERT|UPDATE)$")
    table_name: str = Field(..., min_length=1, max_length=100)
    columns:    dict[str, Optional[str]] = Field(..., min_length=1)
    pk_column:  Optional[str] = None
    pk_value:   Optional[str] = None
    @model_validator(mode="after")
    def check_update(self):
        if self.operation == "UPDATE" and (not self.pk_column or not self.pk_value):
            raise ValueError("pk_column and pk_value required for UPDATE")
        return self

class DmlResponse(BaseModel):
    success: bool; operation: str; table_name: str
    rows_affected: int; audit_id: int; executed_by: str; message: str

@router.post("/execute", response_model=DmlResponse)
async def execute_dml(request: Request, body: DmlRequest,
                      user: TokenPayload = Depends(require_perm(Permission.ADMIN_DML_EXECUTE))):
    col_names  = "|".join(body.columns.keys())
    col_values = "|".join(v if v is not None else "" for v in body.columns.values())
    ip = get_client_ip(request)
    logger.info(f"GenericDML|{body.operation}|{body.table_name}|{user.username}|{ip}")
    try:
        with get_oracle_conn() as conn:
            proc = "PKG_GENERIC_DML.GENERIC_INSERT" if body.operation=="INSERT" else "PKG_GENERIC_DML.GENERIC_UPDATE"
            params = {
                "p_table_name": body.table_name.upper(), "p_col_names": col_names,
                "p_col_values": col_values, "p_executed_by": user.username,
                "p_ad_groups": "|".join(user.roles), "p_client_ip": ip,
                "p_row_count": oracledb.NUMBER, "p_audit_id": oracledb.NUMBER,
            }
            if body.operation=="UPDATE":
                params["p_pk_column"] = body.pk_column.upper()
                params["p_pk_value"]  = body.pk_value
            out = call_proc(conn, proc, params)
    except HTTPException: raise
    except Exception as e:
        msg = str(e)
        for code, status in [("-20010",400),("-20011",400),("-20012",400),("-20013",403),("-20001",404)]:
            if code in msg: raise HTTPException(status, detail=msg.split(f"ORA{code}:")[-1].strip())
        raise HTTPException(500, detail=str(e))
    rows, aid = int(out.get("p_row_count",0) or 0), int(out.get("p_audit_id",0) or 0)
    return DmlResponse(success=True, operation=body.operation, table_name=body.table_name.upper(),
                       rows_affected=rows, audit_id=aid, executed_by=user.username,
                       message=f"{body.operation} done — {rows} row(s). Audit #{aid}")

@router.get("/tables")
async def list_tables(user: TokenPayload = Depends(require_perm(Permission.ADMIN_DML_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_GENERIC_DML.LIST_ALLOWED_TABLES", {"p_ad_groups": "|".join(user.roles)})
    return [serialise_row(r) for r in rows]

@router.get("/tables/{table_name}/columns")
async def get_columns(table_name: str, user: TokenPayload = Depends(require_perm(Permission.ADMIN_DML_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_GENERIC_DML.GET_TABLE_COLUMNS", {"p_table_name": table_name.upper()})
    if not rows: raise HTTPException(404, detail=f"Table '{table_name}' not in registry")
    result = []
    for r in rows:
        row = serialise_row(r)
        row["user_can_use"] = r.get("min_group","OTG_SUPPORT") == "OTG_SUPPORT" or "PLATFORM_ADMIN" in user.roles
        result.append(row)
    return result

@router.get("/audit-log")
async def audit_log(table_name: Optional[str]=Query(None), executed_by: Optional[str]=Query(None),
                    limit: int=Query(50,ge=1,le=500), offset: int=Query(0,ge=0),
                    user: TokenPayload = Depends(require_perm(Permission.AUDIT_READ))):
    eff_user = executed_by
    if not user.can_write("ADMIN_DML") and not executed_by:
        eff_user = user.username
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_GENERIC_DML.GET_AUDIT_LOG",
                                {"p_table_name": table_name, "p_executed_by": eff_user,
                                 "p_from_date": None, "p_limit": limit, "p_offset": offset})
    return [serialise_row(r) for r in rows]
