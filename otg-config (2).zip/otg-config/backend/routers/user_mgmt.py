"""
User & Role Management Router
All operations via PKG_RBAC Oracle package.
Requires USER_MGMT:READ for GET, USER_MGMT:WRITE for mutations.
"""
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Query, Depends, status
from pydantic import BaseModel, Field
import oracledb

from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, serialise_row
from rbac import require_perm, Permission, TokenPayload

router = APIRouter()


def _ora(e: Exception, ctx: str):
    msg = str(e)
    for code, http in [("-20020", 404), ("-20021", 404), ("-20022", 404),
                       ("-20023", 409), ("-20024", 423), ("-20025", 403),
                       ("-20026", 409)]:
        if code in msg:
            raise HTTPException(http, detail=msg.split(f"ORA{code}:")[-1].strip())
    raise HTTPException(500, detail=f"{ctx}: {msg}")


# ── User endpoints ─────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username:     str = Field(..., min_length=1, max_length=200)
    display_name: Optional[str] = None
    email:        Optional[str] = None
    status:       str = Field("ACTIVE", pattern="^(ACTIVE|INACTIVE)$")

class UserUpdate(BaseModel):
    display_name: Optional[str] = None
    email:        Optional[str] = None
    status:       Optional[str] = Field(None, pattern="^(ACTIVE|INACTIVE|LOCKED)$")

class RoleAssignment(BaseModel):
    role_key:    str = Field(..., min_length=1)
    expires_on:  Optional[str] = None   # ISO date string YYYY-MM-DD

class AdGroupMapping(BaseModel):
    ad_group_cn: str = Field(..., min_length=1)
    role_key:    str = Field(..., min_length=1)


@router.get("/users")
async def list_users(
    status:  Optional[str] = Query(None),
    search:  Optional[str] = Query(None),
    limit:   int = Query(50, ge=1, le=200),
    offset:  int = Query(0, ge=0),
    user:    TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.LIST_USERS", {
            "p_status": status, "p_search": search,
            "p_limit": limit, "p_offset": offset,
        })
    return [serialise_row(r) for r in rows]


@router.get("/users/{username}/detail")
async def get_user_detail(
    username: str,
    user:     TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows      = call_func_cursor(conn, "PKG_RBAC.GET_USER_DETAIL",  {"p_username": username})
        role_rows = call_func_cursor(conn, "PKG_RBAC.GET_USER_ROLES",   {"p_username": username})
        perm_rows = call_func_cursor(conn, "PKG_RBAC.GET_USER_PERMISSIONS", {"p_username": username})

    if not rows:
        raise HTTPException(404, detail=f"User '{username}' not found")

    user_data = serialise_row(rows[0])
    user_data["roles"]       = [serialise_row(r) for r in role_rows]
    user_data["permissions"] = [serialise_row(r) for r in perm_rows]
    return user_data


@router.post("/users", status_code=status.HTTP_201_CREATED)
async def create_user(
    payload: UserCreate,
    caller:  TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_RBAC.CREATE_USER", {
                "p_username":     payload.username.lower(),
                "p_display_name": payload.display_name,
                "p_email":        payload.email,
                "p_status":       payload.status,
                "p_created_by":   caller.username,
                "p_user_id":      oracledb.NUMBER,
            })
    except HTTPException: raise
    except Exception as e: _ora(e, "create_user")
    return {"user_id": int(out["p_user_id"]), "username": payload.username.lower()}


@router.put("/users/{user_id}")
async def update_user(
    user_id: int,
    payload: UserUpdate,
    caller:  TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.UPDATE_USER", {
                "p_user_id":      user_id,
                "p_display_name": payload.display_name,
                "p_email":        payload.email,
                "p_status":       payload.status,
                "p_updated_by":   caller.username,
            })
    except Exception as e: _ora(e, "update_user")
    return {"message": f"User {user_id} updated"}


@router.post("/users/{username}/assign-role", status_code=status.HTTP_201_CREATED)
async def assign_role(
    username: str,
    payload:  RoleAssignment,
    caller:   TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    from datetime import datetime
    expires = None
    if payload.expires_on:
        try:
            expires = datetime.strptime(payload.expires_on, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(400, detail="expires_on must be YYYY-MM-DD")
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.ASSIGN_ROLE", {
                "p_username":    username.lower(),
                "p_role_key":    payload.role_key.upper(),
                "p_assigned_by": caller.username,
                "p_expires_on":  expires,
            })
    except Exception as e: _ora(e, "assign_role")
    return {"message": f"Role '{payload.role_key}' assigned to '{username}'"}


@router.delete("/users/{username}/revoke-role/{role_key}", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_role(
    username: str,
    role_key: str,
    caller:   TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.REVOKE_ROLE", {
                "p_username":   username.lower(),
                "p_role_key":   role_key.upper(),
                "p_revoked_by": caller.username,
            })
    except Exception as e: _ora(e, "revoke_role")


# ── Role endpoints ─────────────────────────────────────────────────────────────

class RoleCreate(BaseModel):
    role_key:     str = Field(..., min_length=1, max_length=100,
                               pattern="^[A-Z0-9_]+$",
                               description="Uppercase letters, digits, underscores only")
    display_name: str = Field(..., min_length=1)
    description:  Optional[str] = None
    color:        str = Field("#58A6FF", pattern="^#[0-9A-Fa-f]{6}$")

class RoleUpdate(BaseModel):
    display_name: Optional[str] = None
    description:  Optional[str] = None
    color:        Optional[str] = Field(None, pattern="^#[0-9A-Fa-f]{6}$")
    active:       Optional[str] = Field(None, pattern="^(Y|N)$")

class PermissionToggle(BaseModel):
    permission_key: str = Field(..., description="e.g. APP_CONFIG:WRITE")


@router.get("/roles")
async def list_roles(
    active: Optional[str] = Query(None),
    user:   TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.LIST_ROLES", {"p_active": active})
    return [serialise_row(r) for r in rows]


@router.get("/roles/{role_key}/permissions")
async def get_role_permissions(
    role_key: str,
    user:     TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.GET_ROLE_PERMISSIONS",
                                {"p_role_key": role_key.upper()})
    return [serialise_row(r) for r in rows]


@router.post("/roles", status_code=status.HTTP_201_CREATED)
async def create_role(
    payload: RoleCreate,
    caller:  TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_RBAC.CREATE_ROLE", {
                "p_role_key":     payload.role_key.upper(),
                "p_display_name": payload.display_name,
                "p_description":  payload.description,
                "p_color":        payload.color,
                "p_created_by":   caller.username,
                "p_role_id":      oracledb.NUMBER,
            })
    except Exception as e: _ora(e, "create_role")
    return {"role_id": int(out["p_role_id"]), "role_key": payload.role_key.upper()}


@router.put("/roles/{role_id}")
async def update_role(
    role_id: int,
    payload: RoleUpdate,
    caller:  TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.UPDATE_ROLE", {
                "p_role_id":      role_id,
                "p_display_name": payload.display_name,
                "p_description":  payload.description,
                "p_color":        payload.color,
                "p_active":       payload.active,
                "p_updated_by":   caller.username,
            })
    except Exception as e: _ora(e, "update_role")
    return {"message": f"Role {role_id} updated"}


@router.post("/roles/{role_key}/grant-permission")
async def grant_permission(
    role_key: str,
    payload:  PermissionToggle,
    caller:   TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.GRANT_PERMISSION_TO_ROLE", {
                "p_role_key":       role_key.upper(),
                "p_permission_key": payload.permission_key.upper(),
                "p_granted_by":     caller.username,
            })
    except Exception as e: _ora(e, "grant_permission")
    return {"message": f"Permission '{payload.permission_key}' granted to role '{role_key}'"}


@router.delete("/roles/{role_key}/revoke-permission/{permission_key}",
               status_code=status.HTTP_204_NO_CONTENT)
async def revoke_permission(
    role_key:       str,
    permission_key: str,
    caller:         TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.REVOKE_PERMISSION_FROM_ROLE", {
                "p_role_key":       role_key.upper(),
                "p_permission_key": permission_key.upper(),
            })
    except Exception as e: _ora(e, "revoke_permission")


# ── Catalogue endpoints (permissions + components) ────────────────────────────

@router.get("/permissions/matrix")
async def permission_matrix(
    user: TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.GET_PERMISSION_MATRIX", {})
    return [serialise_row(r) for r in rows]


@router.get("/permissions")
async def list_permissions(
    user: TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.LIST_PERMISSIONS", {})
    return [serialise_row(r) for r in rows]


@router.get("/components")
async def list_components(
    user: TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.LIST_COMPONENTS", {})
    return [serialise_row(r) for r in rows]


# ── AD Group mapping ──────────────────────────────────────────────────────────

@router.get("/ad-group-mappings")
async def list_ad_mappings(
    user: TokenPayload = Depends(require_perm(Permission.USER_MGMT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_RBAC.LIST_AD_GROUP_MAPPINGS", {})
    return [serialise_row(r) for r in rows]


@router.post("/ad-group-mappings", status_code=status.HTTP_201_CREATED)
async def map_ad_group(
    payload: AdGroupMapping,
    caller:  TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.MAP_AD_GROUP_TO_ROLE", {
                "p_ad_group_cn": payload.ad_group_cn,
                "p_role_key":    payload.role_key.upper(),
                "p_created_by":  caller.username,
            })
    except Exception as e: _ora(e, "map_ad_group")
    return {"message": f"AD group '{payload.ad_group_cn}' mapped to role '{payload.role_key}'"}


@router.delete("/ad-group-mappings/{ad_group_cn}/role/{role_key}",
               status_code=status.HTTP_204_NO_CONTENT)
async def unmap_ad_group(
    ad_group_cn: str,
    role_key:    str,
    caller:      TokenPayload = Depends(require_perm(Permission.USER_MGMT_WRITE)),
):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_RBAC.UNMAP_AD_GROUP_FROM_ROLE", {
                "p_ad_group_cn": ad_group_cn,
                "p_role_key":    role_key.upper(),
            })
    except Exception as e: _ora(e, "unmap_ad_group")
