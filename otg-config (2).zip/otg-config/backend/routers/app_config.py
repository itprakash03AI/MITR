from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, status
import oracledb
from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, serialise_row
from schemas import AppConfigCreate, AppConfigUpdate, AppConfigResponse
from rbac import require_perm, Permission, TokenPayload, get_client_ip
from websocket_manager import manager
from fastapi import Request, Depends

router = APIRouter()

def _ora(e, ctx):
    msg = str(e)
    if "-20001" in msg: raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
    if "-20002" in msg: raise HTTPException(409, detail=msg.split("ORA-20002:")[-1].strip())
    raise HTTPException(500, detail=f"{ctx}: {msg}")

@router.get("/", response_model=List[AppConfigResponse])
async def list_apps(
    env: Optional[str]=Query(None), active: Optional[str]=Query(None),
    limit: int=Query(100,ge=1,le=500), offset: int=Query(0,ge=0),
    user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_APP_CONFIG.LIST_APPS",
                                {"p_env":env,"p_active":active,"p_limit":limit,"p_offset":offset})
    return [serialise_row(r) for r in rows]

@router.get("/{app_id}", response_model=AppConfigResponse)
async def get_app(app_id: int, user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_APP_CONFIG.GET_APP", {"p_appid": app_id})
    if not rows: raise HTTPException(404, detail=f"App {app_id} not found")
    return serialise_row(rows[0])

@router.post("/", response_model=AppConfigResponse, status_code=status.HTTP_201_CREATED)
async def create_app(payload: AppConfigCreate, user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_WRITE))):
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_APP_CONFIG.CREATE_APP", {
                "p_appname": payload.appname, "p_env": payload.env,
                "p_hostname": payload.hostname, "p_db_type": payload.db_type,
                "p_db_connection": payload.db_connection, "p_active": payload.active or "Y",
                "p_createdby": user.username, "p_appid": oracledb.NUMBER,
            })
            new_id = int(out["p_appid"])
            rows = call_func_cursor(conn, "PKG_APP_CONFIG.GET_APP", {"p_appid": new_id})
    except HTTPException: raise
    except Exception as e: _ora(e, "create_app")
    await manager.notify("success","App Created",f"'{payload.appname}' in {payload.env}",entity_type="app",entity_id=new_id)
    return serialise_row(rows[0])

@router.put("/{app_id}", response_model=AppConfigResponse)
async def update_app(app_id: int, payload: AppConfigUpdate, user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_WRITE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_APP_CONFIG.UPDATE_APP", {
                "p_appid": app_id, "p_appname": payload.appname, "p_env": payload.env,
                "p_hostname": payload.hostname, "p_db_type": payload.db_type,
                "p_db_connection": payload.db_connection, "p_active": payload.active,
                "p_updatedby": user.username,
            })
            rows = call_func_cursor(conn, "PKG_APP_CONFIG.GET_APP", {"p_appid": app_id})
    except HTTPException: raise
    except Exception as e: _ora(e, "update_app")
    return serialise_row(rows[0])

@router.delete("/{app_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_app(app_id: int, user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_DELETE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_APP_CONFIG.DEACTIVATE_APP", {"p_appid": app_id, "p_updatedby": user.username})
    except Exception as e: _ora(e, "delete_app")
