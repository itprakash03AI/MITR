"""
Bulk Upload Router
- Template download (openpyxl — no Oracle)
- Validate: calls PKG_BULK_UPLOAD.VALIDATE_*_ROW for each Excel row
- Import:   calls PKG_BULK_UPLOAD.INSERT_*_ROW for each valid row
            Python controls the transaction (COMMIT on full success, ROLLBACK on any error)
Zero inline SQL in this file.
"""
import io
import logging
from typing import Literal
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import oracledb

from oracle_utils import get_oracle_conn, call_proc, call_func_scalar, serialise_row
from websocket_manager import manager

router = APIRouter()
logger = logging.getLogger("otg.upload")

EntityType = Literal["report", "dag", "app"]

# ── Template column definitions ───────────────────────────────────────────────

TEMPLATES = {
    "report": {
        "title": "OTG Report Config - Bulk Upload Template",
        "columns": [
            ("fk_appid",      "App ID (required)",             "1"),
            ("file_type",     "CSV/PARQUET/EXCEL/JSON/ORC",    "CSV"),
            ("file_name",     "Report file name (required)",   "sales_report"),
            ("file_format",   "File format/delimiter",         "utf-8"),
            ("file_location", "Output path or S3 URI",         "s3://bucket/reports/"),
            ("description",   "Description",                   "Daily sales report"),
            ("priority",      "1-10 (default 5)",              "5"),
            ("active",        "Y or N",                        "Y"),
        ],
    },
    "dag": {
        "title": "OTG DAG Config - Bulk Upload Template",
        "columns": [
            ("fk_report_id",   "Report ID (required)",                 "1"),
            ("fk_dest_appid",  "Destination App ID",                   ""),
            ("dag_id",         "Unique DAG ID (required)",             "sales_report_dag"),
            ("dag_group",      "DAG group/folder",                     "reporting"),
            ("dag_type",       "DAG type (e.g. REPORTING, EXPORT)",    "REPORTING"),
            ("schedule",       "Cron or @daily/@hourly etc",           "0 6 * * *"),
            ("max_active_runs","Max concurrent runs (default 1)",      "1"),
            ("concurrency",    "Max tasks in parallel (default 1)",    "1"),
            ("auto_trigger",   "Y or N",                               "N"),
            ("auto_skip",      "Y or N",                               "N"),
            ("tags",           "Comma-separated tags",                 "reporting,daily"),
            ("active",         "Y or N",                               "Y"),
        ],
    },
    "app": {
        "title": "OTG App Config - Bulk Upload Template",
        "columns": [
            ("appname",       "Application name (required)",          "SalesDB"),
            ("env",           "DEV/QA/UAT/PROD/STAGING (required)",   "PROD"),
            ("hostname",      "Host or URL",                          "db.company.com"),
            ("db_type",       "oracle/snowflake/starburst/postgres",  "oracle"),
            ("db_connection", "Connection string or DSN",             "host=db;port=1521;svc=PROD"),
            ("active",        "Y or N",                               "Y"),
        ],
    },
}

# ── Styles ────────────────────────────────────────────────────────────────────

HDR_FILL  = PatternFill("solid", fgColor="1F3A5F")
HDR_FONT  = Font(bold=True, color="FFFFFF", size=10)
INST_FILL = PatternFill("solid", fgColor="2D333B")
INST_FONT = Font(italic=True, color="8B949E", size=9)
DATA_FONT = Font(color="C9D1D9", size=9)
TITLE_FONT= Font(bold=True, color="58A6FF", size=12)


def _build_template(entity: EntityType) -> io.BytesIO:
    tmpl = TEMPLATES[entity]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"{entity.upper()}_TEMPLATE"

    cols = tmpl["columns"]
    n = len(cols)

    # Row 1: merged title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n)
    title_cell = ws.cell(1, 1, tmpl["title"])
    title_cell.font = TITLE_FONT
    title_cell.fill = PatternFill("solid", fgColor="0D1117")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 24

    # Row 2: headers
    for col_idx, (col_name, _, _) in enumerate(cols, 1):
        c = ws.cell(2, col_idx, col_name.upper())
        c.font = HDR_FONT; c.fill = HDR_FILL
        c.alignment = Alignment(horizontal="center")

    # Row 3: instructions
    for col_idx, (_, instruction, _) in enumerate(cols, 1):
        c = ws.cell(3, col_idx, instruction)
        c.font = INST_FONT; c.fill = INST_FILL
        c.alignment = Alignment(wrap_text=True)
    ws.row_dimensions[3].height = 30

    # Row 4: sample data
    for col_idx, (_, _, sample) in enumerate(cols, 1):
        c = ws.cell(4, col_idx, sample)
        c.font = DATA_FONT
        c.fill = PatternFill("solid", fgColor="161B22")

    # Column widths
    for col_idx, (col_name, instruction, _) in enumerate(cols, 1):
        width = max(len(col_name), len(instruction) // 3, 14)
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width + 2

    ws.freeze_panes = "A4"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/template/{entity_type}")
async def download_template(entity_type: EntityType):
    buf = _build_template(entity_type)
    filename = f"otg_{entity_type}_config_template.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _read_excel_rows(file_bytes: bytes, entity: EntityType) -> list[dict]:
    """Parse Excel → list of dicts using TEMPLATES column names (row 4+)."""
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
    ws = wb.active
    col_names = [c[0] for c in TEMPLATES[entity]["columns"]]
    rows = []
    for row in ws.iter_rows(min_row=4, values_only=True):  # skip title + header + instructions
        vals = list(row)
        if all(v is None for v in vals):
            continue
        row_dict = {col_names[i]: (str(vals[i]).strip() if vals[i] is not None else "")
                    for i in range(min(len(col_names), len(vals)))}
        rows.append(row_dict)
    wb.close()
    return rows


def _to_int_or_none(val: str):
    try:
        return int(val) if val else None
    except ValueError:
        return None


@router.post("/validate/{entity_type}")
async def validate_upload(entity_type: EntityType, file: UploadFile = File(...)):
    content = await file.read()
    try:
        data_rows = _read_excel_rows(content, entity_type)
    except Exception as e:
        raise HTTPException(400, detail=f"Cannot parse Excel file: {e}")

    if not data_rows:
        raise HTTPException(400, detail="No data rows found (expected data from row 4)")

    errors = []
    valid_preview = []

    with get_oracle_conn() as conn:
        for row_num, row in enumerate(data_rows, start=4):
            err_msg = None

            if entity_type == "report":
                err_msg = call_func_scalar(
                    conn, "PKG_BULK_UPLOAD.VALIDATE_REPORT_ROW",
                    oracledb.STRING,
                    {
                        "p_fk_appid":  _to_int_or_none(row.get("fk_appid", "")),
                        "p_file_type": row.get("file_type", ""),
                        "p_file_name": row.get("file_name", ""),
                    },
                )
            elif entity_type == "dag":
                err_msg = call_func_scalar(
                    conn, "PKG_BULK_UPLOAD.VALIDATE_DAG_ROW",
                    oracledb.STRING,
                    {
                        "p_fk_report_id": _to_int_or_none(row.get("fk_report_id", "")),
                        "p_dag_id":       row.get("dag_id", ""),
                    },
                )
            elif entity_type == "app":
                err_msg = call_func_scalar(
                    conn, "PKG_BULK_UPLOAD.VALIDATE_APP_ROW",
                    oracledb.STRING,
                    {
                        "p_appname": row.get("appname", ""),
                        "p_env":     row.get("env", ""),
                    },
                )

            if err_msg:
                field, msg = (err_msg.split(":", 1) + [""])[:2]
                errors.append({"row": row_num, "field": field.strip(), "message": msg.strip()})
            elif len(valid_preview) < 5:
                valid_preview.append(row)

    return {
        "total_rows":    len(data_rows),
        "valid_count":   len(data_rows) - len(errors),
        "error_count":   len(errors),
        "errors":        errors,
        "valid_preview": valid_preview,
    }


@router.post("/import/{entity_type}")
async def import_upload(entity_type: EntityType, file: UploadFile = File(...)):
    content = await file.read()
    try:
        data_rows = _read_excel_rows(content, entity_type)
    except Exception as e:
        raise HTTPException(400, detail=f"Cannot parse Excel file: {e}")

    created_ids = []
    errors      = []

    # Python owns the transaction: INSERT every valid row, ROLLBACK all on any failure
    with get_oracle_conn() as conn:
        try:
            for row_num, row in enumerate(data_rows, start=4):
                out = {}
                if entity_type == "report":
                    out = call_proc(conn, "PKG_BULK_UPLOAD.INSERT_REPORT_ROW", {
                        "p_fk_appid":      _to_int_or_none(row.get("fk_appid")),
                        "p_file_type":     row.get("file_type"),
                        "p_file_name":     row.get("file_name"),
                        "p_file_format":   row.get("file_format") or None,
                        "p_file_location": row.get("file_location") or None,
                        "p_description":   row.get("description") or None,
                        "p_priority":      _to_int_or_none(row.get("priority")) or 5,
                        "p_active":        row.get("active") or "Y",
                        "p_created_by":    "BULK_UPLOAD",
                        "p_reportid":      oracledb.NUMBER,   # OUT
                    })
                    created_ids.append(int(out["p_reportid"]))

                elif entity_type == "dag":
                    out = call_proc(conn, "PKG_BULK_UPLOAD.INSERT_DAG_ROW", {
                        "p_fk_report_id":   _to_int_or_none(row.get("fk_report_id")),
                        "p_fk_dest_appid":  _to_int_or_none(row.get("fk_dest_appid")) or None,
                        "p_dag_id":         row.get("dag_id"),
                        "p_dag_group":      row.get("dag_group") or None,
                        "p_dag_type":       row.get("dag_type") or None,
                        "p_schedule":       row.get("schedule") or None,
                        "p_max_active_runs":_to_int_or_none(row.get("max_active_runs")) or 1,
                        "p_concurrency":    _to_int_or_none(row.get("concurrency")) or 1,
                        "p_auto_trigger":   row.get("auto_trigger") or "N",
                        "p_auto_skip":      row.get("auto_skip") or "N",
                        "p_tags":           row.get("tags") or None,
                        "p_active":         row.get("active") or "Y",
                        "p_otg_dag_id":     oracledb.NUMBER,  # OUT
                    })
                    created_ids.append(int(out["p_otg_dag_id"]))

                elif entity_type == "app":
                    out = call_proc(conn, "PKG_BULK_UPLOAD.INSERT_APP_ROW", {
                        "p_appname":       row.get("appname"),
                        "p_env":           row.get("env"),
                        "p_hostname":      row.get("hostname") or None,
                        "p_db_type":       row.get("db_type") or None,
                        "p_db_connection": row.get("db_connection") or None,
                        "p_active":        row.get("active") or "Y",
                        "p_created_by":    "BULK_UPLOAD",
                        "p_appid":         oracledb.NUMBER,   # OUT
                    })
                    created_ids.append(int(out["p_appid"]))

            conn.commit()   # single commit after all rows succeed
            logger.info(f"Bulk import {entity_type}: {len(created_ids)} rows committed")

        except Exception as e:
            conn.rollback()
            logger.error(f"Bulk import {entity_type} failed: {e} — rolled back")
            raise HTTPException(500, detail=f"Import failed: {e} — all rows rolled back")

    await manager.notify(
        "success", "Bulk Import Complete",
        f"Imported {len(created_ids)} {entity_type} records",
        entity_type=entity_type
    )
    return {
        "imported_count": len(created_ids),
        "created_ids":    created_ids,
        "errors":         errors,
    }
