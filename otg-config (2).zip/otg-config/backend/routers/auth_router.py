"""
Auth Router — login, me, logout
Uses new RBAC engine: sync_user_and_build_token on login.
"""
from fastapi import APIRouter, Request
from pydantic import BaseModel, Field
from auth import authenticate_ad
from rbac import sync_user_and_build_token, _dev_bypass_token, decode_token, require_auth, TokenPayload
from config import get_settings
from typing import Optional
from fastapi import Depends

router   = APIRouter()
settings = get_settings()


class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=1)


class LoginResponse(BaseModel):
    access_token: str
    token_type:   str = "bearer"
    username:     str
    display_name: str
    email:        str
    roles:        list[str]
    permissions:  list[str]
    expires_in:   int


@router.post("/login", response_model=LoginResponse)
async def login(request: Request, body: LoginRequest):
    if settings.AD_SERVER:
        # Real AD auth
        ad_user = authenticate_ad(body.username, body.password)
        token   = sync_user_and_build_token(
            username=     ad_user.username,
            display_name= ad_user.display_name,
            email=        ad_user.email,
            ad_groups=    ad_user.groups,
        )
    else:
        # Dev bypass — no real AD, use username heuristic
        token = _dev_bypass_token(body.username)

    payload = decode_token(token)
    return LoginResponse(
        access_token=token,
        username=    payload.username,
        display_name=payload.display_name,
        email=       payload.email,
        roles=       payload.roles,
        permissions= list(payload.permissions),
        expires_in=  settings.TOKEN_EXPIRE_MINUTES * 60,
    )


@router.get("/me")
async def me(user: TokenPayload = Depends(require_auth)):
    return {
        "username":     user.username,
        "display_name": user.display_name,
        "email":        user.email,
        "user_id":      user.user_id,
        "roles":        user.roles,
        "permissions":  list(user.permissions),
    }


@router.post("/logout")
async def logout():
    return {"message": "Logged out. Please discard your token."}
