"""
Param Config Router
All DML via PKG_REPORT_CONFIG / PKG_DAG_CONFIG Oracle packages. Zero inline SQL.
"""
from fastapi import APIRouter, HTTPException, status
import oracledb

from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, serialise_row
from schemas import ReportParamCreate, DagParamCreate

router = APIRouter()


# ── Report Params ─────────────────────────────────────────────────────────────

@router.get("/report/{report_id}")
async def get_report_params(report_id: int):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT_PARAMS",
                                {"p_reportid": report_id})
    return [serialise_row(r) for r in rows]


@router.post("/report/{report_id}", status_code=status.HTTP_201_CREATED)
async def add_report_param(report_id: int, payload: ReportParamCreate):
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_REPORT_CONFIG.ADD_PARAM", {
                "p_reportid":   report_id,
                "p_key":        payload.operation_key,
                "p_value":      payload.operation_value,
                "p_active":     payload.active or "Y",
                "p_created_by": payload.created_by,
                "p_param_id":   oracledb.NUMBER,   # OUT
            })
    except Exception as e:
        msg = str(e)
        if "-20001" in msg:
            raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
        raise HTTPException(500, detail=str(e))

    return {"report_param_config_id": int(out["p_param_id"]), "report_id": report_id}


@router.delete("/report-param/{param_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_report_param(param_id: int):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_REPORT_CONFIG.DEACTIVATE_PARAM", {"p_param_id": param_id})
    except Exception as e:
        msg = str(e)
        if "-20001" in msg:
            raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
        raise HTTPException(500, detail=str(e))


# ── DAG Params ────────────────────────────────────────────────────────────────

@router.get("/dag/{dag_id}")
async def get_dag_params(dag_id: int):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_DAG_CONFIG.GET_DAG_PARAMS",
                                {"p_otg_dag_id": dag_id})
    return [serialise_row(r) for r in rows]


@router.post("/dag/{dag_id}", status_code=status.HTTP_201_CREATED)
async def add_dag_param(dag_id: int, payload: DagParamCreate):
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_DAG_CONFIG.ADD_DAG_PARAM", {
                "p_otg_dag_id": dag_id,
                "p_key":        payload.key,
                "p_val":        payload.val,
                "p_active":     payload.active or "Y",
                "p_createdby":  payload.createdby,
                "p_param_id":   oracledb.NUMBER,   # OUT
            })
    except Exception as e:
        msg = str(e)
        if "-20001" in msg:
            raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
        raise HTTPException(500, detail=str(e))

    return {"id": int(out["p_param_id"]), "dag_id": dag_id}


@router.delete("/dag-param/{param_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dag_param(param_id: int):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_DAG_CONFIG.DEACTIVATE_DAG_PARAM", {"p_param_id": param_id})
    except Exception as e:
        msg = str(e)
        if "-20001" in msg:
            raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
        raise HTTPException(500, detail=str(e))
