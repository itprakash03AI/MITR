"""
Report Config Router
All DML via PKG_REPORT_CONFIG Oracle package. Zero inline SQL.
"""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, status, Depends
import oracledb

from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, call_func_scalar, serialise_row
from schemas import ReportConfigCreate, ReportConfigUpdate, ReportConfigResponse
from rbac import require_perm, Permission, TokenPayload
from websocket_manager import manager

router = APIRouter()


def _raise_oracle(e: Exception, ctx: str):
    msg = str(e)
    if "-20001" in msg:
        raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
    if "-20003" in msg:
        raise HTTPException(400, detail=msg.split("ORA-20003:")[-1].strip())
    raise HTTPException(500, detail=f"{ctx}: {msg}")


@router.get("/stats/summary")
async def get_stats(user: TokenPayload = Depends(require_perm(Permission.REPORT_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT_STATS", {})
    return serialise_row(rows[0]) if rows else {}


@router.get("/", response_model=List[ReportConfigResponse])
async def list_reports(
    fk_appid:  Optional[int] = Query(None),
    file_type: Optional[str] = Query(None),
    active:    Optional[str] = Query(None),
    search:    Optional[str] = Query(None),
    limit:     int = Query(50, ge=1, le=500),
    offset:    int = Query(0,  ge=0),
    user:      TokenPayload = Depends(require_perm(Permission.REPORT_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.LIST_REPORTS", {
            "p_fk_appid":  fk_appid,
            "p_file_type": file_type,
            "p_active":    active,
            "p_search":    search,
            "p_limit":     limit,
            "p_offset":    offset,
        })
    return [serialise_row(r) for r in rows]


@router.get("/{report_id}/params")
async def get_report_params(report_id: int, user: TokenPayload = Depends(require_perm(Permission.REPORT_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT_PARAMS", {"p_reportid": report_id})
    return [serialise_row(r) for r in rows]


@router.get("/{report_id}", response_model=ReportConfigResponse)
async def get_report(report_id: int, user: TokenPayload = Depends(require_perm(Permission.REPORT_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT", {"p_reportid": report_id})
    if not rows:
        raise HTTPException(404, detail=f"Report {report_id} not found")
    return serialise_row(rows[0])


@router.post("/", response_model=ReportConfigResponse, status_code=status.HTTP_201_CREATED)
async def create_report(payload: ReportConfigCreate, user: TokenPayload = Depends(require_perm(Permission.REPORT_WRITE))):
    # Build pipe-separated param strings for the package proc
    param_keys   = "|".join(p.operation_key   for p in payload.params) if payload.params else None
    param_values = "|".join(p.operation_value or "" for p in payload.params) if payload.params else None

    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_REPORT_CONFIG.CREATE_REPORT", {
                "p_fk_appid":      payload.fk_appid,
                "p_file_type":     payload.file_type,
                "p_file_name":     payload.file_name,
                "p_file_format":   payload.file_format,
                "p_file_location": payload.file_location,
                "p_description":   payload.report_description,
                "p_priority":      payload.priority or 5,
                "p_active":        payload.active or "Y",
                "p_created_by":    payload.created_by,
                "p_param_keys":    param_keys,
                "p_param_values":  param_values,
                "p_reportid":      oracledb.NUMBER,   # OUT
            })
            new_id = int(out["p_reportid"])
            rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT", {"p_reportid": new_id})
    except HTTPException:
        raise
    except Exception as e:
        _raise_oracle(e, "create_report")

    await manager.notify("success", "Report Created",
                         f"Report '{payload.file_name}' created", entity_type="report", entity_id=new_id)
    return serialise_row(rows[0])


@router.put("/{report_id}", response_model=ReportConfigResponse)
async def update_report(report_id: int, payload: ReportConfigUpdate,
                        user: TokenPayload = Depends(require_perm(Permission.REPORT_WRITE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_REPORT_CONFIG.UPDATE_REPORT", {
                "p_reportid":      report_id,
                "p_file_type":     payload.file_type,
                "p_file_name":     payload.file_name,
                "p_file_format":   payload.file_format,
                "p_file_location": payload.file_location,
                "p_description":   payload.report_description,
                "p_priority":      payload.priority,
                "p_active":        payload.active,
                "p_updated_by":    payload.updated_by,
            })
            rows = call_func_cursor(conn, "PKG_REPORT_CONFIG.GET_REPORT", {"p_reportid": report_id})
    except HTTPException:
        raise
    except Exception as e:
        _raise_oracle(e, "update_report")

    return serialise_row(rows[0])


@router.delete("/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_report(report_id: int, user: TokenPayload = Depends(require_perm(Permission.REPORT_DELETE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_REPORT_CONFIG.DEACTIVATE_REPORT", {
                "p_reportid":   report_id,
                "p_updated_by": user.username,
            })
    except Exception as e:
        _raise_oracle(e, "delete_report")
