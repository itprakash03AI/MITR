"""
DAG Config Router
All DML via PKG_DAG_CONFIG Oracle package. Zero inline SQL.
"""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, status, Depends
import oracledb

from oracle_utils import get_oracle_conn, call_proc, call_func_cursor, serialise_row
from schemas import DagConfigCreate, DagConfigUpdate, DagConfigResponse
from rbac import require_perm, Permission, TokenPayload
from websocket_manager import manager

router = APIRouter()


def _raise_oracle(e: Exception, ctx: str):
    msg = str(e)
    if "-20001" in msg:
        raise HTTPException(404, detail=msg.split("ORA-20001:")[-1].strip())
    if "-20004" in msg:
        raise HTTPException(409, detail=msg.split("ORA-20004:")[-1].strip())
    if "-20005" in msg:
        raise HTTPException(400, detail=msg.split("ORA-20005:")[-1].strip())
    raise HTTPException(500, detail=f"{ctx}: {msg}")


@router.get("/", response_model=List[DagConfigResponse])
async def list_dags(
    fk_report_id: Optional[int] = Query(None),
    dag_type:     Optional[str] = Query(None),
    active:       Optional[str] = Query(None),
    search:       Optional[str] = Query(None),
    limit:        int = Query(50, ge=1, le=500),
    offset:       int = Query(0,  ge=0),
    user:         TokenPayload = Depends(require_perm(Permission.DAG_READ)),
):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_DAG_CONFIG.LIST_DAGS", {
            "p_fk_report_id": fk_report_id,
            "p_dag_type":     dag_type,
            "p_active":       active,
            "p_search":       search,
            "p_limit":        limit,
            "p_offset":       offset,
        })
    return [serialise_row(r) for r in rows]


@router.get("/{dag_id}/params")
async def get_dag_params(dag_id: int, user: TokenPayload = Depends(require_perm(Permission.DAG_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_DAG_CONFIG.GET_DAG_PARAMS", {"p_otg_dag_id": dag_id})
    return [serialise_row(r) for r in rows]


@router.get("/{dag_id}", response_model=DagConfigResponse)
async def get_dag(dag_id: int, user: TokenPayload = Depends(require_perm(Permission.DAG_READ))):
    with get_oracle_conn() as conn:
        rows = call_func_cursor(conn, "PKG_DAG_CONFIG.GET_DAG", {"p_otg_dag_id": dag_id})
    if not rows:
        raise HTTPException(404, detail=f"DAG {dag_id} not found")
    return serialise_row(rows[0])


@router.post("/", response_model=DagConfigResponse, status_code=status.HTTP_201_CREATED)
async def create_dag(payload: DagConfigCreate, user: TokenPayload = Depends(require_perm(Permission.DAG_WRITE))):
    param_keys   = "|".join(p.key       for p in payload.params) if payload.params else None
    param_values = "|".join(p.val or "" for p in payload.params) if payload.params else None

    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_DAG_CONFIG.CREATE_DAG", {
                "p_fk_report_id":    payload.fk_report_id,
                "p_fk_dest_appid":   payload.fk_dest_appid,
                "p_dag_id":          payload.dag_id,
                "p_dag_group":       payload.dag_group,
                "p_dag_url":         payload.dag_url,
                "p_dag_type":        payload.dag_type,
                "p_schedule":        payload.schedule_interval,
                "p_max_active_runs": payload.max_active_runs or 1,
                "p_concurrency":     payload.concurrency or 1,
                "p_auto_trigger":    payload.auto_trigger or "N",
                "p_auto_skip":       payload.auto_skip or "N",
                "p_tags":            payload.tags,
                "p_active":          payload.active or "Y",
                "p_param_keys":      param_keys,
                "p_param_values":    param_values,
                "p_otg_dag_id":      oracledb.NUMBER,   # OUT
            })
            new_id = int(out["p_otg_dag_id"])
            rows = call_func_cursor(conn, "PKG_DAG_CONFIG.GET_DAG", {"p_otg_dag_id": new_id})
    except HTTPException:
        raise
    except Exception as e:
        _raise_oracle(e, "create_dag")

    await manager.notify("success", "DAG Created",
                         f"DAG '{payload.dag_id}' created", entity_type="dag", entity_id=new_id)
    return serialise_row(rows[0])


@router.put("/{dag_id}", response_model=DagConfigResponse)
async def update_dag(dag_id: int, payload: DagConfigUpdate,
                     user: TokenPayload = Depends(require_perm(Permission.DAG_WRITE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_DAG_CONFIG.UPDATE_DAG", {
                "p_otg_dag_id":     dag_id,
                "p_dag_group":      payload.dag_group,
                "p_dag_url":        payload.dag_url,
                "p_dag_type":       payload.dag_type,
                "p_schedule":       payload.schedule_interval,
                "p_max_active_runs":payload.max_active_runs,
                "p_concurrency":    payload.concurrency,
                "p_auto_trigger":   payload.auto_trigger,
                "p_auto_skip":      payload.auto_skip,
                "p_tags":           payload.tags,
                "p_active":         payload.active,
                "p_updatedby":      user.username,
            })
            rows = call_func_cursor(conn, "PKG_DAG_CONFIG.GET_DAG", {"p_otg_dag_id": dag_id})
    except HTTPException:
        raise
    except Exception as e:
        _raise_oracle(e, "update_dag")

    return serialise_row(rows[0])


@router.delete("/{dag_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dag(dag_id: int, user: TokenPayload = Depends(require_perm(Permission.DAG_DELETE))):
    try:
        with get_oracle_conn() as conn:
            call_proc(conn, "PKG_DAG_CONFIG.DEACTIVATE_DAG", {
                "p_otg_dag_id": dag_id,
                "p_updatedby":  user.username,
            })
    except Exception as e:
        _raise_oracle(e, "delete_dag")
