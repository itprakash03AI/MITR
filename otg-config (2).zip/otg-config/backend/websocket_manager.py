"""
WebSocket Manager - Real-time notification broadcasting
Supports per-client and broadcast notifications
"""
import logging
import json
from datetime import datetime
from typing import Dict
from fastapi import WebSocket

logger = logging.getLogger("otg.websocket")


class ConnectionManager:
    """Manages active WebSocket connections and message broadcasting."""

    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info(f"Client connected: {client_id} | Total: {len(self.active_connections)}")
        await self.send_personal_message(
            json.dumps({
                "type": "info",
                "title": "Connected",
                "message": "Real-time notifications active",
                "timestamp": datetime.utcnow().isoformat()
            }),
            client_id
        )

    def disconnect(self, client_id: str):
        self.active_connections.pop(client_id, None)
        logger.info(f"Client disconnected: {client_id} | Remaining: {len(self.active_connections)}")

    async def send_personal_message(self, message: str, client_id: str):
        """Send message to a specific client."""
        websocket = self.active_connections.get(client_id)
        if websocket:
            try:
                await websocket.send_text(message)
            except Exception as e:
                logger.error(f"Failed to send to {client_id}: {e}")
                self.disconnect(client_id)

    async def broadcast(self, message: str):
        """Broadcast message to ALL connected clients."""
        disconnected = []
        for client_id, websocket in self.active_connections.items():
            try:
                await websocket.send_text(message)
            except Exception as e:
                logger.error(f"Broadcast failed for {client_id}: {e}")
                disconnected.append(client_id)
        for client_id in disconnected:
            self.disconnect(client_id)

    async def notify(
        self,
        notification_type: str,
        title: str,
        message: str,
        entity_type: str = None,
        entity_id: int = None,
        broadcast: bool = True,
        client_id: str = None,
    ):
        """High-level notification helper."""
        payload = json.dumps({
            "type": notification_type,
            "title": title,
            "message": message,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "timestamp": datetime.utcnow().isoformat(),
        })
        if broadcast:
            await self.broadcast(payload)
        elif client_id:
            await self.send_personal_message(payload, client_id)

    @property
    def connected_count(self) -> int:
        return len(self.active_connections)


# Singleton instance
manager = ConnectionManager()
