"""
rbac.py — Generic Permission-Based Access Control
==================================================
Replaces the old 3-tier (ADMIN/SUPPORT/READONLY) system with a
component × action matrix loaded from Oracle on every login.

Core concepts:
  Component  — a section of the platform (APP_CONFIG, DAG_CONFIG, USER_MGMT …)
  Action     — what you do (READ, WRITE, DELETE, EXECUTE, EXPORT)
  Permission — Component:Action pair e.g. "APP_CONFIG:WRITE"
  Role       — named set of permissions (CONFIG_MANAGER, DAG_OPERATOR …)
  User       — has roles; roles resolved from AD groups + manual assignments

Usage in routes:
    from rbac import Permission, require_perm

    @router.post("/")
    async def create_app(
        payload: AppConfigCreate,
        user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_WRITE)),
    ):
        ...
"""
from __future__ import annotations
import logging
from enum import Enum
from typing import Set, Optional, List
from functools import lru_cache

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

from config import get_settings
from oracle_utils import get_oracle_conn, call_func_cursor, call_proc, serialise_row
import oracledb

logger     = logging.getLogger("otg.rbac")
settings   = get_settings()
bearer     = HTTPBearer(auto_error=False)


# ── Permission Keys ────────────────────────────────────────────────────────────

class Permission(str, Enum):
    """All platform permissions as Component:Action strings.
    Must match the PERMISSION_KEY values seeded in OTG_PERMISSIONS.
    """
    # Dashboard
    DASHBOARD_READ    = "DASHBOARD:READ"

    # App Config
    APP_CONFIG_READ   = "APP_CONFIG:READ"
    APP_CONFIG_WRITE  = "APP_CONFIG:WRITE"
    APP_CONFIG_DELETE = "APP_CONFIG:DELETE"
    APP_CONFIG_EXPORT = "APP_CONFIG:EXPORT"

    # Report Config
    REPORT_READ       = "REPORT_CONFIG:READ"
    REPORT_WRITE      = "REPORT_CONFIG:WRITE"
    REPORT_DELETE     = "REPORT_CONFIG:DELETE"
    REPORT_EXPORT     = "REPORT_CONFIG:EXPORT"

    # DAG Config
    DAG_READ          = "DAG_CONFIG:READ"
    DAG_WRITE         = "DAG_CONFIG:WRITE"
    DAG_DELETE        = "DAG_CONFIG:DELETE"
    DAG_EXECUTE       = "DAG_CONFIG:EXECUTE"
    DAG_EXPORT        = "DAG_CONFIG:EXPORT"

    # Bulk Upload
    BULK_READ         = "BULK_UPLOAD:READ"
    BULK_EXECUTE      = "BULK_UPLOAD:EXECUTE"

    # Admin DML
    ADMIN_DML_READ    = "ADMIN_DML:READ"
    ADMIN_DML_WRITE   = "ADMIN_DML:WRITE"
    ADMIN_DML_EXECUTE = "ADMIN_DML:EXECUTE"

    # Audit Log
    AUDIT_READ        = "AUDIT_LOG:READ"

    # User Management
    USER_MGMT_READ    = "USER_MGMT:READ"
    USER_MGMT_WRITE   = "USER_MGMT:WRITE"
    USER_MGMT_DELETE  = "USER_MGMT:DELETE"


# ── Token Payload ──────────────────────────────────────────────────────────────

class TokenPayload:
    """Decoded JWT claim. Contains the user's resolved permission set."""

    def __init__(
        self,
        username:     str,
        display_name: str,
        email:        str,
        roles:        List[str],
        permissions:  Set[str],
        user_id:      Optional[int] = None,
    ):
        self.username     = username
        self.display_name = display_name
        self.email        = email
        self.roles        = roles
        self.permissions  = permissions   # set of "COMPONENT:ACTION" strings
        self.user_id      = user_id

    def has(self, *perms: Permission) -> bool:
        """True if user has ANY of the listed permissions."""
        return any(p.value in self.permissions for p in perms)

    def has_all(self, *perms: Permission) -> bool:
        """True if user has ALL of the listed permissions."""
        return all(p.value in self.permissions for p in perms)

    def can_read(self,   component: str) -> bool: return f"{component}:READ"    in self.permissions
    def can_write(self,  component: str) -> bool: return f"{component}:WRITE"   in self.permissions
    def can_delete(self, component: str) -> bool: return f"{component}:DELETE"  in self.permissions
    def can_exec(self,   component: str) -> bool: return f"{component}:EXECUTE" in self.permissions


# ── JWT helpers ────────────────────────────────────────────────────────────────

def create_token(payload: TokenPayload, expires_minutes: int | None = None) -> str:
    from datetime import datetime, timedelta, timezone
    mins = expires_minutes or settings.TOKEN_EXPIRE_MINUTES
    now  = datetime.now(timezone.utc)
    claims = {
        "sub":         payload.username,
        "name":        payload.display_name,
        "email":       payload.email,
        "roles":       payload.roles,
        "permissions": list(payload.permissions),
        "user_id":     payload.user_id,
        "iat":         now,
        "exp":         now + timedelta(minutes=mins),
        "iss":         settings.APP_NAME,
    }
    return jwt.encode(claims, settings.SECRET_KEY, algorithm="HS256")


def decode_token(token: str) -> TokenPayload:
    try:
        claims = jwt.decode(
            token, settings.SECRET_KEY, algorithms=["HS256"],
            options={"require": ["sub", "exp"]},
        )
        return TokenPayload(
            username=     claims["sub"],
            display_name= claims.get("name", claims["sub"]),
            email=        claims.get("email", ""),
            roles=        claims.get("roles", []),
            permissions=  set(claims.get("permissions", [])),
            user_id=      claims.get("user_id"),
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, detail="Token expired — please log in again")
    except jwt.InvalidTokenError as e:
        raise HTTPException(401, detail=f"Invalid token: {e}")


# ── Oracle RBAC sync ───────────────────────────────────────────────────────────

def sync_user_and_build_token(
    username: str,
    display_name: str,
    email: str,
    ad_groups: List[str],
) -> str:
    """
    Called on successful AD login:
      1. Calls PKG_RBAC.SYNC_USER_ON_LOGIN (upserts user, syncs AD-group roles)
      2. Loads full permission set via PKG_RBAC.GET_USER_PERMISSIONS
      3. Loads user's roles via PKG_RBAC.GET_USER_ROLES
      4. Issues JWT containing permissions + roles
    """
    ad_groups_str = "|".join(ad_groups)

    with get_oracle_conn() as conn:
        # 1. Sync
        out = call_proc(conn, "PKG_RBAC.SYNC_USER_ON_LOGIN", {
            "p_username":     username.lower(),
            "p_display_name": display_name,
            "p_email":        email,
            "p_ad_groups":    ad_groups_str,
            "p_user_id":      oracledb.NUMBER,  # OUT
        })
        user_id = int(out.get("p_user_id", 0) or 0)

        # 2. Permissions
        perm_rows  = call_func_cursor(conn, "PKG_RBAC.GET_USER_PERMISSIONS",
                                      {"p_username": username.lower()})
        permissions = {r["permission_key"] for r in perm_rows}

        # 3. Roles
        role_rows = call_func_cursor(conn, "PKG_RBAC.GET_USER_ROLES",
                                     {"p_username": username.lower()})
        roles = [r["role_key"] for r in role_rows]

    if not permissions:
        raise HTTPException(403,
            detail="No permissions assigned — contact your administrator to be assigned a role")

    payload = TokenPayload(
        username=username.lower(),
        display_name=display_name,
        email=email,
        roles=roles,
        permissions=permissions,
        user_id=user_id,
    )
    logger.info(f"Login: {username} | roles={roles} | perms={len(permissions)}")
    return create_token(payload)


def _dev_bypass_token(username: str) -> str:
    """Dev bypass: maps username to built-in roles when AD_SERVER is not set."""
    from auth import _dev_bypass_auth
    ad_user = _dev_bypass_auth(username)

    # Map old-style OTG groups to new role keys
    group_to_role = {
        "OTG_ADMIN":    "PLATFORM_ADMIN",
        "OTG_SUPPORT":  "SUPPORT_ENGINEER",
        "OTG_READONLY": "PLATFORM_READONLY",
    }
    roles  = [group_to_role.get(g, "PLATFORM_READONLY") for g in ad_user.groups]

    # Load permissions from Oracle for those roles (or use defaults if Oracle unreachable)
    try:
        with get_oracle_conn() as conn:
            out = call_proc(conn, "PKG_RBAC.SYNC_USER_ON_LOGIN", {
                "p_username":     username.lower(),
                "p_display_name": ad_user.display_name,
                "p_email":        ad_user.email,
                "p_ad_groups":    "",
                "p_user_id":      oracledb.NUMBER,
            })
            user_id = int(out.get("p_user_id", 0) or 0)

            # Manually assign roles for dev bypass
            for role in roles:
                try:
                    call_proc(conn, "PKG_RBAC.ASSIGN_ROLE", {
                        "p_username":    username.lower(),
                        "p_role_key":    role,
                        "p_assigned_by": "DEV_BYPASS",
                        "p_expires_on":  None,
                    })
                except Exception:
                    pass

            perm_rows   = call_func_cursor(conn, "PKG_RBAC.GET_USER_PERMISSIONS",
                                           {"p_username": username.lower()})
            permissions = {r["permission_key"] for r in perm_rows}
    except Exception as e:
        logger.warning(f"Dev bypass: Oracle unreachable ({e}), using hardcoded permissions")
        # Fallback: give PLATFORM_ADMIN all known permissions
        permissions = {p.value for p in Permission}
        user_id = 0

    payload = TokenPayload(
        username=username.lower(),
        display_name=ad_user.display_name,
        email=ad_user.email,
        roles=roles,
        permissions=permissions,
        user_id=user_id,
    )
    return create_token(payload)


# ── FastAPI dependencies ───────────────────────────────────────────────────────

async def require_auth(
    request:     Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
) -> TokenPayload:
    """Base dependency — valid JWT required."""
    if not credentials:
        raise HTTPException(401, detail="Missing Authorization header")
    token = decode_token(credentials.credentials)
    request.state.user = token
    return token


def require_perm(*perms: Permission):
    """
    Route dependency factory — user must have AT LEAST ONE of the listed permissions.

    Usage:
        @router.get("/", dependencies=[Depends(require_perm(Permission.APP_CONFIG_READ))])

        # Or with user access:
        async def route(user: TokenPayload = Depends(require_perm(Permission.APP_CONFIG_WRITE))):
    """
    async def _check(
        request: Request,
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
    ) -> TokenPayload:
        if not credentials:
            raise HTTPException(401, detail="Missing Authorization header")
        user = decode_token(credentials.credentials)
        request.state.user = user
        if not user.has(*perms):
            needed = " | ".join(p.value for p in perms)
            _log_denial(user.username, needed, request)
            raise HTTPException(
                403,
                detail=f"Access denied — requires permission: {needed}"
            )
        return user
    return _check


def _log_denial(username: str, perms: str, request: Request):
    """Fire-and-forget denial log."""
    logger.warning(f"PERMISSION DENIED | {username} | {perms} | {request.url.path}")


def get_client_ip(request: Request) -> str:
    fwd = request.headers.get("X-Forwarded-For")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
