"""
OTG Config Platform - Centralized Configuration (Pydantic Settings)
All settings load from env vars or .env file.
In OpenShift: ConfigMap (non-sensitive) + Secret (sensitive).
"""
from functools import lru_cache
from typing import Optional, List
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8",
        case_sensitive=False, extra="ignore",
    )

    # ── APP ──────────────────────────────────────────────────────────────────
    APP_NAME:    str  = Field("OTG Config Platform")
    APP_VERSION: str  = Field("1.0.0")
    APP_ENV:     str  = Field("development")
    DEBUG:       bool = Field(False)
    LOG_LEVEL:   str  = Field("INFO")

    # ── SERVER ───────────────────────────────────────────────────────────────
    HOST:    str  = Field("0.0.0.0")
    PORT:    int  = Field(8000)
    WORKERS: int  = Field(1)
    RELOAD:  bool = Field(False)

    # ── ORACLE ───────────────────────────────────────────────────────────────
    ORACLE_USER:        str           = Field(...)
    ORACLE_PASSWORD:    str           = Field(...)
    ORACLE_HOST:        str           = Field(...)
    ORACLE_PORT:        int           = Field(1521)
    ORACLE_SERVICE:     str           = Field(...)
    ORACLE_SCHEMA:      Optional[str] = Field(None)
    DB_POOL_SIZE:       int           = Field(10)
    DB_MAX_OVERFLOW:    int           = Field(20)
    DB_POOL_TIMEOUT:    int           = Field(30)
    DB_POOL_RECYCLE:    int           = Field(3600)
    DB_ECHO:            bool          = Field(False)
    ORACLE_THIN_MODE:   bool          = Field(True)
    ORACLE_CLIENT_LIB_DIR: Optional[str] = Field(None)

    # ── CORS ─────────────────────────────────────────────────────────────────
    CORS_ORIGINS: str = Field("http://localhost:5173,http://localhost:3000")

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    # ── SECURITY / JWT ────────────────────────────────────────────────────────
    SECRET_KEY:            str = Field("change-me-in-production-use-openshift-secret")
    TOKEN_EXPIRE_MINUTES:  int = Field(480)

    # ── ACTIVE DIRECTORY ─────────────────────────────────────────────────────
    AD_SERVER:           str = Field("", description="ldap://ad.company.com or ldaps://")
    AD_DOMAIN:           str = Field("", description="COMPANY or company.com")
    AD_BASE_DN:          str = Field("", description="DC=company,DC=com")
    AD_AUTH_METHOD:      str = Field("NTLM", description="NTLM | SIMPLE")
    AD_GROUP_ADMIN:      str = Field("OTG-Platform-Admin")
    AD_GROUP_SUPPORT:    str = Field("OTG-Platform-Support")
    AD_GROUP_READONLY:   str = Field("OTG-Platform-ReadOnly")
    AD_BIND_TIMEOUT_SEC: int = Field(5)

    # ── UPLOAD ───────────────────────────────────────────────────────────────
    MAX_UPLOAD_SIZE_MB: int = Field(10)

    @property
    def max_upload_bytes(self) -> int:
        return self.MAX_UPLOAD_SIZE_MB * 1024 * 1024

    # ── WEBSOCKET ─────────────────────────────────────────────────────────────
    WS_PING_INTERVAL:  int = Field(30)
    WS_MAX_CONNECTIONS:int = Field(200)

    # ── OPENSHIFT POD METADATA (auto-injected) ────────────────────────────────
    POD_NAME:      Optional[str] = Field(None)
    POD_NAMESPACE: Optional[str] = Field(None)
    POD_IP:        Optional[str] = Field(None)

    # ── VALIDATORS ────────────────────────────────────────────────────────────
    @field_validator("APP_ENV")
    @classmethod
    def validate_env(cls, v: str) -> str:
        allowed = {"development", "staging", "production"}
        if v.lower() not in allowed:
            raise ValueError(f"APP_ENV must be one of {allowed}")
        return v.lower()

    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if v.upper() not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {allowed}")
        return v.upper()

    # ── DERIVED ───────────────────────────────────────────────────────────────
    @property
    def database_url(self) -> str:
        return (f"oracle+oracledb://{self.ORACLE_USER}:{self.ORACLE_PASSWORD}"
                f"@{self.ORACLE_HOST}:{self.ORACLE_PORT}/?service_name={self.ORACLE_SERVICE}")

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def docs_url(self) -> Optional[str]:
        return None if self.is_production else "/api/docs"

    @property
    def redoc_url(self) -> Optional[str]:
        return None if self.is_production else "/api/redoc"

    def safe_dict(self) -> dict:
        d = self.model_dump()
        for key in ("ORACLE_PASSWORD", "SECRET_KEY"):
            if key in d:
                d[key] = "***MASKED***"
        return d


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
