# ============================================================
# app/core/query_executor.py — Concurrency-safe DuckDB executor
# ============================================================
"""
HOW 100+ CONCURRENT REQUESTS ARE HANDLED
═════════════════════════════════════════

Request arrives
    │
    ▼
Cache check (instant, no DuckDB)
    │ hit → return immediately
    │ miss
    ▼
Queue depth guard
    │ queue full (>MAX_QUEUE_DEPTH) → 503 immediately
    │ space available
    ▼
Request coalescing
    │ identical SQL already in-flight? → await same Future (0 extra DuckDB calls)
    │ new SQL
    ▼
Semaphore acquire (async wait — no CPU burn)
    │ slot available → proceed
    │ full → async wait until slot frees or timeout
    ▼
ThreadPoolExecutor.run_in_executor
    │ Runs DuckDB in a thread (releases GIL)
    ▼
DuckDB executes (uses duckdb_threads internally)
    ▼
Result stored in cache + returned to all waiting coalescers

TUNING FOR 100+ CONCURRENT REQUESTS:
─────────────────────────────────────
The key insight: you don't want 100 simultaneous DuckDB queries.
You want a small number of DuckDB queries running efficiently,
with the rest waiting cheaply (async, no threads, no CPU).

  max_concurrent_queries = 4   # DuckDB queries actually running
  thread_pool_size = 8         # threads available for DuckDB
  duckdb_threads = 4           # threads each DuckDB query uses
  max_queue_depth = 200        # max requests waiting before 503

  4 queries × 4 threads = 16 CPU threads doing real work
  96 requests waiting async = near-zero overhead
  Cache hit rate 80%+ in practice = most never touch DuckDB

MULTIPLE PROCESSES (Gunicorn):
───────────────────────────────
Each worker process is independent:
  4 workers × 4 concurrent queries = 16 true parallel DuckDB queries
  4 workers × 200 queue depth = 800 requests handled without 503

Start with Gunicorn (not uvicorn alone):
  gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
"""
from __future__ import annotations

import asyncio
import functools
import hashlib
import time
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

import duckdb
import structlog

from app.core.database import DuckDBPool
from app.core.settings import settings

logger = structlog.get_logger()


# ═══════════════════════════════════════════════════════════════════════════
# TTL Cache — thread-safe, per-entry TTL
# ═══════════════════════════════════════════════════════════════════════════

class TTLCache:
    def __init__(self):
        self._store: Dict[str, Tuple[Any, float]] = {}
        self._lock = Lock()
        self._hits   = 0
        self._misses = 0

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            value, expires_at = entry
            if time.monotonic() > expires_at:
                del self._store[key]
                self._misses += 1
                return None
            self._hits += 1
            return value

    def set(self, key: str, value: Any, ttl: int) -> None:
        with self._lock:
            self._store[key] = (value, time.monotonic() + ttl)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    @property
    def size(self) -> int:
        return len(self._store)

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return round(self._hits / total, 4) if total > 0 else 0.0

    def stats(self) -> Dict:
        return {
            "entries":  self.size,
            "hits":     self._hits,
            "misses":   self._misses,
            "hit_rate": self.hit_rate,
        }


result_cache = TTLCache()


# ═══════════════════════════════════════════════════════════════════════════
# Concurrency primitives  (module-level singletons — one per process)
# ═══════════════════════════════════════════════════════════════════════════

# Thread pool — runs blocking DuckDB calls outside the event loop
_thread_pool = ThreadPoolExecutor(
    max_workers=settings.thread_pool_size,
    thread_name_prefix="duckdb-worker",
)

# Semaphore — limits simultaneous DuckDB queries
# Created lazily inside the running event loop
_semaphore: Optional[asyncio.Semaphore] = None

def _get_semaphore() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(settings.max_concurrent_queries)
    return _semaphore


# Request coalescing — tracks in-flight queries so identical concurrent
# requests share one DuckDB execution instead of N identical ones
_in_flight: Dict[str, asyncio.Future] = {}
_in_flight_lock: Optional[asyncio.Lock] = None

def _get_in_flight_lock() -> asyncio.Lock:
    global _in_flight_lock
    if _in_flight_lock is None:
        _in_flight_lock = asyncio.Lock()
    return _in_flight_lock


# Live metrics (per-process)
class _Metrics:
    def __init__(self):
        self._lock = Lock()
        self.total_requests  = 0
        self.total_executed  = 0   # actual DuckDB queries run
        self.total_coalesced = 0   # requests served from in-flight dedup
        self.total_cached    = 0   # requests served from TTL cache
        self.total_rejected  = 0   # 503s due to queue full
        self.total_timeouts  = 0
        self.total_errors    = 0
        self.current_waiting = 0   # requests waiting for semaphore
        self.current_running = 0   # requests inside DuckDB right now

    def snapshot(self) -> Dict:
        with self._lock:
            return {
                "total_requests":   self.total_requests,
                "total_executed":   self.total_executed,
                "total_coalesced":  self.total_coalesced,
                "total_cached":     self.total_cached,
                "total_rejected":   self.total_rejected,
                "total_timeouts":   self.total_timeouts,
                "total_errors":     self.total_errors,
                "current_waiting":  self.current_waiting,
                "current_running":  self.current_running,
                "cache":            result_cache.stats(),
            }

metrics = _Metrics()


# ═══════════════════════════════════════════════════════════════════════════
# Query result
# ═══════════════════════════════════════════════════════════════════════════

class QueryResult:
    __slots__ = ("columns", "rows", "total_rows", "page", "page_size",
                 "execution_ms", "cached", "coalesced", "query_id")

    def __init__(
        self,
        columns: List[str],
        rows: List[Dict],
        total_rows: int,
        page: int,
        page_size: int,
        execution_ms: float,
        cached: bool = False,
        coalesced: bool = False,
        query_id: str = "",
    ):
        self.columns      = columns
        self.rows         = rows
        self.total_rows   = total_rows
        self.page         = page
        self.page_size    = page_size
        self.execution_ms = execution_ms
        self.cached       = cached
        self.coalesced    = coalesced
        self.query_id     = query_id

    def to_dict(self) -> Dict:
        return {
            "meta": {
                "query_id":    self.query_id,
                "columns":     self.columns,
                "total_rows":  self.total_rows,
                "page":        self.page,
                "page_size":   self.page_size,
                "total_pages": max(1, (self.total_rows + self.page_size - 1) // self.page_size),
                "execution_ms": round(self.execution_ms, 2),
                "cached":      self.cached,
                "coalesced":   self.coalesced,   # true = served from in-flight dedup
            },
            "data": self.rows,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Core executor
# ═══════════════════════════════════════════════════════════════════════════

class QueryExecutor:

    def __init__(self, pool: DuckDBPool):
        self._pool = pool

    # ─────────────────────────────────────────────────────────────────────
    # Main entry point
    # ─────────────────────────────────────────────────────────────────────

    async def execute(
        self,
        sql: str,
        page: int = 1,
        page_size: int = settings.default_page_size,
        cache: bool = True,
        cache_ttl: int = settings.cache_ttl_seconds,
    ) -> QueryResult:
        page_size = min(page_size, settings.max_page_size)
        cache_key = _make_key(sql, page, page_size)

        with metrics._lock:
            metrics.total_requests += 1

        # ── 1. TTL Cache — cheapest path, no DuckDB ───────────────────────
        if cache and settings.cache_enabled:
            cached_result = result_cache.get(cache_key)
            if cached_result is not None:
                with metrics._lock:
                    metrics.total_cached += 1
                cached_result.cached = True
                logger.debug("cache_hit", key=cache_key[:12])
                return cached_result

        # ── 2. Queue depth guard — reject fast if overloaded ──────────────
        sem = _get_semaphore()
        waiting = metrics.current_waiting
        if waiting >= settings.max_queue_depth:
            with metrics._lock:
                metrics.total_rejected += 1
            raise OverflowError(
                f"Server is at capacity ({waiting} requests queued). "
                f"Retry after a moment or increase MAX_QUEUE_DEPTH."
            )

        # ── 3. Request coalescing — identical in-flight queries share one Future
        lock = _get_in_flight_lock()
        async with lock:
            if cache_key in _in_flight:
                # Another request is already running the exact same query.
                # Await its future instead of launching a new DuckDB query.
                future = _in_flight[cache_key]
                coalesce = True
            else:
                # First request for this key — create the future, others will latch on
                future = asyncio.get_event_loop().create_future()
                _in_flight[cache_key] = future
                coalesce = False

        if coalesce:
            with metrics._lock:
                metrics.total_coalesced += 1
            logger.debug("request_coalesced", key=cache_key[:12])
            try:
                result = await asyncio.wait_for(
                    asyncio.shield(future),
                    timeout=settings.query_timeout_seconds,
                )
                result.coalesced = True
                return result
            except asyncio.TimeoutError:
                raise TimeoutError("Coalesced query timed out")

        # ── 4. Semaphore — async wait for a DuckDB slot ───────────────────
        with metrics._lock:
            metrics.current_waiting += 1

        try:
            try:
                await asyncio.wait_for(
                    sem.acquire(),
                    timeout=settings.query_timeout_seconds,
                )
            except asyncio.TimeoutError:
                with metrics._lock:
                    metrics.total_timeouts += 1
                    metrics.current_waiting -= 1
                _in_flight.pop(cache_key, None)
                future.set_exception(TimeoutError("Timed out waiting for a query slot"))
                raise TimeoutError(
                    f"Timed out after {settings.query_timeout_seconds}s waiting "
                    f"for a free query slot. Current concurrent queries: "
                    f"{settings.max_concurrent_queries}. "
                    f"Increase MAX_CONCURRENT_QUERIES or reduce query duration."
                )

            with metrics._lock:
                metrics.current_waiting -= 1
                metrics.current_running += 1

            # ── 5. Run DuckDB in thread pool ──────────────────────────────
            try:
                loop = asyncio.get_event_loop()
                result = await asyncio.wait_for(
                    loop.run_in_executor(
                        _thread_pool,
                        functools.partial(self._run_sync, sql, page, page_size),
                    ),
                    timeout=settings.query_timeout_seconds,
                )
            except asyncio.TimeoutError:
                with metrics._lock:
                    metrics.total_timeouts += 1
                    metrics.current_running -= 1
                _in_flight.pop(cache_key, None)
                future.set_exception(TimeoutError(f"Query exceeded {settings.query_timeout_seconds}s"))
                sem.release()
                raise TimeoutError(f"Query exceeded {settings.query_timeout_seconds}s timeout")
            except Exception as exc:
                with metrics._lock:
                    metrics.total_errors += 1
                    metrics.current_running -= 1
                _in_flight.pop(cache_key, None)
                future.set_exception(exc)
                sem.release()
                raise

            with metrics._lock:
                metrics.total_executed += 1
                metrics.current_running -= 1

            sem.release()

        except (TimeoutError, OverflowError):
            raise
        except Exception:
            raise

        # ── 6. Cache + resolve future ──────────────────────────────────────
        if cache and settings.cache_enabled:
            result_cache.set(cache_key, result, cache_ttl)

        _in_flight.pop(cache_key, None)
        if not future.done():
            future.set_result(result)

        return result

    # ─────────────────────────────────────────────────────────────────────
    # Streaming (bypasses semaphore — has its own flow control via queue)
    # ─────────────────────────────────────────────────────────────────────

    async def stream(
        self,
        sql: str,
        chunk_size: int = 5000,
    ) -> AsyncGenerator[List[Dict], None]:
        """Stream results as chunks. Uses a bounded async queue for backpressure."""
        loop   = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue(maxsize=4)   # backpressure: at most 4 chunks buffered

        def _producer():
            try:
                with self._pool.get_connection() as conn:
                    rel  = conn.execute(sql)
                    cols = [d[0] for d in rel.description]
                    while True:
                        batch = rel.fetchmany(chunk_size)
                        if not batch:
                            break
                        rows = [dict(zip(cols, row)) for row in batch]
                        asyncio.run_coroutine_threadsafe(queue.put(rows), loop).result()
            except Exception as exc:
                asyncio.run_coroutine_threadsafe(queue.put(exc), loop).result()
            finally:
                asyncio.run_coroutine_threadsafe(queue.put(None), loop).result()

        loop.run_in_executor(_thread_pool, _producer)

        while True:
            item = await queue.get()
            if item is None:
                break
            if isinstance(item, Exception):
                raise item
            yield item

    async def explain(self, sql: str) -> str:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            _thread_pool,
            functools.partial(self._explain_sync, sql),
        )

    # ─────────────────────────────────────────────────────────────────────
    # Sync internals — run inside thread pool, never in the event loop
    # ─────────────────────────────────────────────────────────────────────

    def _run_sync(self, sql: str, page: int, page_size: int) -> QueryResult:
        t0        = time.perf_counter()
        offset    = (page - 1) * page_size
        query_id  = _make_key(sql, 0, 0)[:12]
        count_sql = f"SELECT COUNT(*) FROM ({sql}) __count__"
        paged_sql = f"SELECT * FROM ({sql}) __paged__ LIMIT {page_size} OFFSET {offset}"

        with self._pool.get_connection() as conn:
            try:
                total_rows = conn.execute(count_sql).fetchone()[0]
                rel        = conn.execute(paged_sql)
                cols       = [d[0] for d in rel.description]
                rows       = [dict(zip(cols, row)) for row in rel.fetchall()]
            except duckdb.Error as exc:
                logger.error("duckdb_error", query_id=query_id, error=str(exc))
                raise

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "query_executed",
            query_id=query_id,
            total_rows=total_rows,
            returned=len(rows),
            execution_ms=round(elapsed_ms, 2),
        )
        return QueryResult(
            columns=cols, rows=rows, total_rows=total_rows,
            page=page, page_size=page_size,
            execution_ms=elapsed_ms, query_id=query_id,
        )

    def _explain_sync(self, sql: str) -> str:
        with self._pool.get_connection() as conn:
            rows = conn.execute(f"EXPLAIN {sql}").fetchall()
            return "\n".join(r[1] for r in rows)


def _make_key(sql: str, page: int, page_size: int) -> str:
    return hashlib.sha256(f"{sql}:{page}:{page_size}".encode()).hexdigest()
