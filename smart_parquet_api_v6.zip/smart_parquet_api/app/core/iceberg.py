# ============================================================
# app/core/iceberg.py — Apache Iceberg on AWS S3  (full detail)
# ============================================================
"""
HOW ICEBERG ON S3 WORKS — END TO END
══════════════════════════════════════════════════════════════

S3 stores two things for every Iceberg table:

  1. METADATA FILES  (under <warehouse>/<namespace>/<table>/metadata/)
     ┌──────────────────────────────────────────────────────────┐
     │  v1.metadata.json   ← current schema + snapshot pointers│
     │  v2.metadata.json   ← updated after every write         │
     │  snap-<id>.avro     ← manifest list (list of manifests) │
     │  manifest-<id>.avro ← manifest (list of data files)     │
     └──────────────────────────────────────────────────────────┘

  2. DATA FILES  (under <warehouse>/<namespace>/<table>/data/)
     ┌──────────────────────────────────────────────────────────┐
     │  part-00000-<uuid>.parquet                               │
     │  part-00001-<uuid>.parquet                               │
     └──────────────────────────────────────────────────────────┘

QUERY FLOW (what happens when you call /api/iceberg/query):

  1. PyIceberg reads v*.metadata.json from S3
     → finds current snapshot ID

  2. PyIceberg reads snap-<id>.avro (manifest list)
     → gets list of manifest files

  3. PyIceberg reads each manifest-<id>.avro
     → collects Parquet file s3:// paths (only live files)

  4. We pass those paths to DuckDB:
     read_parquet(['s3://bucket/data/p1.parquet',
                   's3://bucket/data/p2.parquet'], union_by_name=true)

  5. DuckDB reads them directly from S3 via httpfs
     Full vectorised execution — no Spark, no JVM

CATALOG TYPES ON AWS:

  hadoop  — Read metadata directly from S3. No catalog service needed.
            Best for: read-only access to tables Spark/Glue already wrote.
            Needs: ICEBERG_HADOOP_WAREHOUSE + S3 creds

  glue    — AWS Glue stores table registry (name → S3 location).
            Best for: tables written by Glue ETL, EMR, or Athena.
            Needs: Glue IAM permissions + S3 creds

  rest    — HTTP catalog service (Polaris, Nessie, Tabular, etc.)
            Best for: managed catalog services.
            Needs: catalog URL + auth token

IAM PERMISSIONS:

  S3 (all catalog types):
    s3:GetObject          on arn:aws:s3:::your-bucket/*
    s3:ListBucket         on arn:aws:s3:::your-bucket
    s3:GetBucketLocation  on arn:aws:s3:::your-bucket

  Glue (catalog type = glue only):
    glue:GetDatabase, glue:GetDatabases
    glue:GetTable, glue:GetTables, glue:GetPartitions

  On EC2/ECS/Lambda with IAM Role:
    Leave AWS_ACCESS_KEY_ID blank — role credentials apply automatically.
    This is the recommended production approach.
"""
from __future__ import annotations

import json
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple

import structlog

from app.core.settings import settings

logger = structlog.get_logger()


# ═══════════════════════════════════════════════════════════════════════════
# Catalog property builder
# ═══════════════════════════════════════════════════════════════════════════

def _build_catalog_properties() -> Dict[str, str]:
    """
    Build PyIceberg catalog properties dict from application settings.
    These are PyIceberg-specific property names, not env var names.
    Reference: https://py.iceberg.apache.org/configuration/
    """
    props: Dict[str, str] = {}
    ct = settings.iceberg_catalog_type.lower()

    # ── HADOOP (filesystem catalog — reads metadata directly from S3) ──────
    if ct == "hadoop":
        if not settings.iceberg_hadoop_warehouse:
            raise ValueError(
                "ICEBERG_HADOOP_WAREHOUSE is required for catalog type 'hadoop'.\n"
                "Example: ICEBERG_HADOOP_WAREHOUSE=s3://my-bucket/warehouse"
            )
        props["warehouse"] = settings.iceberg_hadoop_warehouse
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["s3.session-token"] = settings.aws_session_token
        if settings.s3_region:
            props["s3.region"] = settings.s3_region
        if settings.s3_endpoint_url:
            props["s3.endpoint"] = settings.s3_endpoint_url

    # ── AWS GLUE ────────────────────────────────────────────────────────────
    elif ct == "glue":
        region = settings.iceberg_glue_region or settings.s3_region
        if not region:
            raise ValueError(
                "ICEBERG_GLUE_REGION (or S3_REGION) is required for catalog type 'glue'."
            )
        props["client.region"] = region
        if settings.aws_access_key_id:
            props["client.access-key-id"]     = settings.aws_access_key_id
            props["client.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["client.session-token"] = settings.aws_session_token
        # S3 creds for reading actual data files
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["s3.session-token"] = settings.aws_session_token
        if settings.s3_region:
            props["s3.region"] = settings.s3_region

    # ── REST CATALOG ────────────────────────────────────────────────────────
    elif ct == "rest":
        if not settings.iceberg_rest_uri:
            raise ValueError(
                "ICEBERG_REST_URI is required for catalog type 'rest'.\n"
                "Example: ICEBERG_REST_URI=https://my-catalog.example.com"
            )
        props["uri"] = settings.iceberg_rest_uri
        if settings.iceberg_rest_token:
            props["token"] = settings.iceberg_rest_token
        elif settings.iceberg_rest_credential:
            props["credential"] = settings.iceberg_rest_credential
        if settings.iceberg_rest_warehouse:
            props["warehouse"] = settings.iceberg_rest_warehouse
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["s3.session-token"] = settings.aws_session_token
        if settings.s3_region:
            props["s3.region"] = settings.s3_region

    # ── HIVE METASTORE ──────────────────────────────────────────────────────
    elif ct == "hive":
        if not settings.iceberg_hive_uri:
            raise ValueError(
                "ICEBERG_HIVE_URI is required for catalog type 'hive'.\n"
                "Example: ICEBERG_HIVE_URI=thrift://hive-metastore.internal:9083"
            )
        props["uri"] = settings.iceberg_hive_uri
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.s3_region:
            props["s3.region"] = settings.s3_region

    # ── NESSIE ──────────────────────────────────────────────────────────────
    elif ct == "nessie":
        if not settings.iceberg_nessie_uri:
            raise ValueError(
                "ICEBERG_NESSIE_URI is required for catalog type 'nessie'.\n"
                "Example: ICEBERG_NESSIE_URI=http://nessie:19120/api/v1"
            )
        props["uri"] = settings.iceberg_nessie_uri
        props["ref"] = settings.iceberg_nessie_ref
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.s3_region:
            props["s3.region"] = settings.s3_region
    else:
        raise ValueError(
            f"Unknown ICEBERG_CATALOG_TYPE: '{ct}'. "
            "Supported: hadoop | glue | rest | hive | nessie"
        )

    # Extra custom properties
    if settings.iceberg_extra_properties:
        for pair in settings.iceberg_extra_properties.split(","):
            pair = pair.strip()
            if "=" in pair:
                k, v = pair.split("=", 1)
                props[k.strip()] = v.strip()

    return props


# ═══════════════════════════════════════════════════════════════════════════
# Catalog singleton
# ═══════════════════════════════════════════════════════════════════════════

@lru_cache(maxsize=1)
def get_iceberg_catalog():
    """Returns a cached PyIceberg catalog. Raises clearly if not installed."""
    try:
        from pyiceberg.catalog import load_catalog
    except ImportError:
        raise RuntimeError(
            "PyIceberg is not installed. Install the right extras for your catalog:\n"
            "  Hadoop/S3:  pip install 'pyiceberg[s3fs]'\n"
            "  AWS Glue:   pip install 'pyiceberg[s3fs,glue]'\n"
            "  Hive:       pip install 'pyiceberg[s3fs,hive]'\n"
            "  REST:       pip install 'pyiceberg[s3fs]'\n"
        )

    catalog_type = settings.iceberg_catalog_type.lower()
    try:
        props = _build_catalog_properties()
    except ValueError as exc:
        raise RuntimeError(f"Iceberg configuration error: {exc}")

    logger.info(
        "iceberg_catalog_connecting",
        type=catalog_type,
        name=settings.iceberg_catalog_name,
        warehouse=props.get("warehouse", props.get("uri", "—")),
    )

    catalog = load_catalog(
        settings.iceberg_catalog_name,
        **{"type": catalog_type, **props},
    )

    logger.info("iceberg_catalog_ready", type=catalog_type)
    return catalog


# ═══════════════════════════════════════════════════════════════════════════
# Iceberg → DuckDB bridge
# ═══════════════════════════════════════════════════════════════════════════

class IcebergTableResolver:
    """
    Resolves Iceberg table → Parquet file list → DuckDB read_parquet() expression.

    For every resolve() call:
      1. Load table → reads metadata JSON from S3
      2. Get snapshot → reads snapshot manifest list (avro) from S3
      3. Walk manifests → reads manifest entries (avro) from S3
      4. Collect live Parquet file s3:// paths
      5. Return read_parquet([...], union_by_name=true)
    """

    @staticmethod
    def get_data_files(
        namespace: str,
        table_name: str,
        snapshot_id: Optional[int] = None,
    ) -> Tuple[List[str], Dict[str, Any]]:
        """Returns (list of s3:// Parquet paths, schema dict)."""
        catalog   = get_iceberg_catalog()
        full_name = f"{namespace}.{table_name}"

        logger.debug("iceberg_resolve_start", table=full_name)
        table = catalog.load_table(full_name)

        if snapshot_id:
            snap = table.snapshot_by_id(snapshot_id)
            if snap is None:
                raise ValueError(
                    f"Snapshot {snapshot_id} not found in '{full_name}'. "
                    f"Check /api/iceberg/namespaces/{namespace}/tables/{table_name}/snapshots"
                )
        else:
            snap = table.current_snapshot()
            if snap is None:
                raise ValueError(
                    f"Table '{full_name}' has no snapshots — it may be empty."
                )

        data_files: List[str] = []
        for manifest in snap.manifests(table.io):
            for entry in manifest.fetch_manifest_entry(table.io, discard_deleted=True):
                data_files.append(entry.data_file.file_path)

        if not data_files:
            raise ValueError(
                f"Snapshot {snap.snapshot_id} of '{full_name}' has no live data files."
            )

        schema = {
            field.name: str(field.field_type)
            for field in table.schema().fields
        }

        logger.info(
            "iceberg_resolved",
            table=full_name,
            snapshot_id=snap.snapshot_id,
            data_files=len(data_files),
            columns=len(schema),
        )
        return data_files, schema

    @staticmethod
    def build_duckdb_sql(
        namespace: str,
        table_name: str,
        alias: str,
        snapshot_id: Optional[int] = None,
    ) -> str:
        """
        Builds the DuckDB FROM-clause expression for this Iceberg snapshot.

        union_by_name=true is critical — Iceberg tables can accumulate files
        written with different column orderings after schema evolution.
        DuckDB aligns columns by name, not position.

        Example output:
          read_parquet([
            's3://bucket/warehouse/finance/tb_txn/data/part-00000.parquet',
            's3://bucket/warehouse/finance/tb_txn/data/part-00001.parquet'
          ], union_by_name=true)
        """
        paths, _ = IcebergTableResolver.get_data_files(namespace, table_name, snapshot_id)
        paths_sql = ",\n    ".join(f"'{p}'" for p in paths)
        return f"read_parquet([\n    {paths_sql}\n  ], union_by_name=true)"


# ═══════════════════════════════════════════════════════════════════════════
# Catalog explorer helpers
# ═══════════════════════════════════════════════════════════════════════════

def list_iceberg_namespaces() -> List[str]:
    catalog = get_iceberg_catalog()
    return [".".join(ns) for ns in catalog.list_namespaces()]


def list_iceberg_tables(namespace: str) -> List[str]:
    catalog = get_iceberg_catalog()
    ns_tuple = tuple(namespace.split("."))
    return [t[-1] for t in catalog.list_tables(ns_tuple)]


def describe_iceberg_table(namespace: str, table_name: str) -> Dict[str, Any]:
    catalog = get_iceberg_catalog()
    table   = catalog.load_table(f"{namespace}.{table_name}")
    snap    = table.current_snapshot()

    data_files, schema = IcebergTableResolver.get_data_files(namespace, table_name)

    spec       = table.spec()
    partitions = [
        {"field": f.name, "transform": str(f.transform)}
        for f in spec.fields
    ] if spec.fields else []

    return {
        "full_name":       f"{namespace}.{table_name}",
        "location":        table.location(),
        "format":          "ICEBERG",
        "schema":          schema,
        "column_count":    len(schema),
        "data_file_count": len(data_files),
        "sample_files":    data_files[:5],
        "partitions":      partitions,
        "properties":      dict(table.properties),
        "current_snapshot": {
            "id":           snap.snapshot_id,
            "timestamp_ms": snap.timestamp_ms,
            "operation":    snap.summary.operation if snap.summary else None,
            "summary":      dict(snap.summary) if snap.summary else {},
        } if snap else None,
    }


def list_snapshots(namespace: str, table_name: str) -> List[Dict[str, Any]]:
    catalog = get_iceberg_catalog()
    table   = catalog.load_table(f"{namespace}.{table_name}")
    current = table.current_snapshot()
    snaps   = []
    for snap in (table.metadata.snapshots or []):
        snaps.append({
            "snapshot_id":     snap.snapshot_id,
            "parent_id":       snap.parent_snapshot_id,
            "timestamp_ms":    snap.timestamp_ms,
            "is_current":      snap.snapshot_id == (current.snapshot_id if current else None),
            "operation":       snap.summary.operation if snap.summary else None,
            "added_files":     snap.summary.get("added-data-files")  if snap.summary else None,
            "deleted_files":   snap.summary.get("deleted-data-files") if snap.summary else None,
            "added_records":   snap.summary.get("added-records")     if snap.summary else None,
            "deleted_records": snap.summary.get("deleted-records")   if snap.summary else None,
        })
    return sorted(snaps, key=lambda s: s["timestamp_ms"], reverse=True)


# ═══════════════════════════════════════════════════════════════════════════
# Connection tester — run standalone to diagnose config problems
# ═══════════════════════════════════════════════════════════════════════════

def test_connection() -> Dict[str, Any]:
    """
    Runs a step-by-step connection test and returns structured results.

    Run from command line:
      python -c "
        import json
        from app.core.iceberg import test_connection
        print(json.dumps(test_connection(), indent=2))
      "

    Or call via API:
      GET /api/iceberg/test-connection
    """
    results: Dict[str, Any] = {
        "catalog_type": settings.iceberg_catalog_type,
        "catalog_name": settings.iceberg_catalog_name,
        "steps":        [],
    }

    def step(name: str, ok: bool, detail: str = ""):
        icon = "✅" if ok else "❌"
        results["steps"].append({"step": name, "ok": ok, "detail": detail})
        print(f"  {icon}  {name}: {detail}")

    print(f"\nTesting Iceberg connection [{settings.iceberg_catalog_type}]...\n")

    # 1. pyiceberg installed?
    try:
        import pyiceberg
        step("pyiceberg_installed", True, f"v{pyiceberg.__version__}")
    except ImportError as e:
        step("pyiceberg_installed", False, str(e))
        results["success"] = False
        results["fix"] = "pip install 'pyiceberg[s3fs,glue]'"
        return results

    # 2. Config is valid?
    try:
        props = _build_catalog_properties()
        # Mask secrets
        safe = {k: ("***" if any(s in k for s in ["secret", "token", "password"]) else v)
                for k, v in props.items()}
        step("config_valid", True, json.dumps(safe, indent=2))
    except ValueError as e:
        step("config_valid", False, str(e))
        results["success"] = False
        return results

    # 3. Catalog reachable?
    try:
        get_iceberg_catalog.cache_clear()   # force fresh attempt
        catalog = get_iceberg_catalog()
        step("catalog_connect", True, f"type={settings.iceberg_catalog_type}")
    except Exception as e:
        step("catalog_connect", False, str(e))
        results["success"] = False
        results["fix"] = _diagnose_error(str(e))
        return results

    # 4. List namespaces
    try:
        namespaces = list_iceberg_namespaces()
        step("list_namespaces", True, str(namespaces))
        results["namespaces"] = namespaces
    except Exception as e:
        step("list_namespaces", False, str(e))
        results["success"] = False
        results["fix"] = _diagnose_error(str(e))
        return results

    # 5. List tables in first namespace
    results["tables"] = {}
    for ns in namespaces[:3]:
        try:
            tables = list_iceberg_tables(ns)
            results["tables"][ns] = tables
            step(f"list_tables({ns})", True, str(tables))
        except Exception as e:
            step(f"list_tables({ns})", False, str(e))

    results["success"] = True
    print(f"\n✅ Connection successful!\n")
    return results


def _diagnose_error(error: str) -> str:
    """Map common errors to actionable fixes."""
    e = error.lower()
    if "accessdenied" in e or "403" in e:
        return (
            "IAM permission denied.\n"
            "S3 needs: s3:GetObject, s3:ListBucket, s3:GetBucketLocation\n"
            "Glue needs: glue:GetTable, glue:GetDatabase, glue:GetPartitions\n"
            "Attach these permissions to your IAM user or role."
        )
    if "nosuchbucket" in e:
        return "S3 bucket not found. Check ICEBERG_HADOOP_WAREHOUSE bucket name."
    if "invalidaccesskeyid" in e or "signaturedoesnotmatch" in e:
        return "Invalid AWS credentials. Check AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY."
    if "could not connect" in e or "connection refused" in e:
        return "Cannot reach endpoint. Check S3_REGION and network/VPC configuration."
    if "nosuchkey" in e:
        return (
            "Metadata file not found in S3. The warehouse path may be wrong, "
            "or the table was not written in Iceberg format at that location."
        )
    if "entitynotfound" in e or "table not found" in e:
        return "Table not found. Check namespace and table name with /api/iceberg/namespaces."
    return f"Unknown error — check logs for full stack trace."
