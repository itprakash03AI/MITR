# ============================================================
# app/core/settings.py — Enterprise configuration via env vars
# ============================================================
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
from pathlib import Path
import os


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────
    app_name: str = "Smart Parquet Query API"
    app_version: str = "1.0.0"
    debug: bool = False
    log_level: str = "INFO"

    # ── Server ───────────────────────────────────────────────
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4

    # ── DuckDB ───────────────────────────────────────────────
    duckdb_threads: int = 4          # threads PER query (lower = more concurrency)
    duckdb_memory_limit: str = "4GB"
    duckdb_temp_dir: str = "/tmp/duckdb"
    query_timeout_seconds: int = 300

    # ── Concurrency ──────────────────────────────────────────
    # Max simultaneous DuckDB queries per worker process.
    # Others wait async — no CPU burn.
    # Rule of thumb: cpu_cores / duckdb_threads
    # e.g. 16-core machine, duckdb_threads=4 → max_concurrent_queries=4
    max_concurrent_queries: int = 4

    # Thread pool size for blocking DuckDB calls.
    # Must be >= max_concurrent_queries.
    thread_pool_size: int = 8

    # Max requests waiting in queue before returning 503.
    # Prevents unbounded queue growth under spike load.
    max_queue_depth: int = 200

    # ── Storage: Local ───────────────────────────────────────
    local_data_dir: str = str(Path(__file__).parent.parent.parent / "data")

    # ── Storage: S3 ──────────────────────────────────────────
    s3_enabled: bool = False
    s3_bucket: str = ""
    s3_region: str = "us-east-1"
    s3_endpoint_url: Optional[str] = None   # for MinIO / LocalStack
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None

    # ── Config paths ─────────────────────────────────────────
    queries_config_path: str = str(Path(__file__).parent.parent.parent / "config" / "queries.yaml")

    # ── Pagination ───────────────────────────────────────────
    default_page_size: int = 1000
    max_page_size: int = 50_000

    # ── Cache ────────────────────────────────────────────────
    cache_enabled: bool = True
    cache_ttl_seconds: int = 300

    # ── Apache Iceberg ───────────────────────────────────────
    iceberg_enabled: bool = False

    # Catalog type: rest | glue | hive | hadoop | nessie
    iceberg_catalog_type: str = "rest"
    iceberg_catalog_name: str = "default"

    # REST catalog (Polaris, Nessie, Tabular, etc.)
    iceberg_rest_uri: Optional[str] = None          # e.g. http://localhost:8181
    iceberg_rest_credential: Optional[str] = None   # client_id:client_secret
    iceberg_rest_token: Optional[str] = None        # bearer token
    iceberg_rest_warehouse: Optional[str] = None    # warehouse path / name

    # Hive Metastore
    iceberg_hive_uri: Optional[str] = None          # thrift://host:9083

    # AWS Glue (uses same AWS creds as S3)
    iceberg_glue_region: Optional[str] = None

    # Hadoop / local filesystem catalog
    iceberg_hadoop_warehouse: Optional[str] = None  # s3://bucket/warehouse OR /local/path

    # Nessie
    iceberg_nessie_uri: Optional[str] = None
    iceberg_nessie_ref: str = "main"

    # Generic catalog properties (key=value pairs, comma separated)
    # e.g. "token=abc123,scope=PRINCIPAL_ROLE:ALL"
    iceberg_extra_properties: Optional[str] = None

    # ── Generic endpoint security ────────────────────────────
    # Allowlist of SQL prefixes allowed in the generic endpoint
    # Comma-separated, e.g. "SELECT,WITH,EXPLAIN"
    generic_endpoint_enabled: bool = True
    generic_endpoint_allowed_prefixes: str = "SELECT,WITH,EXPLAIN"
    generic_endpoint_max_rows: int = 10_000

    # ── Auth (optional) ──────────────────────────────────────
    api_key_enabled: bool = False
    api_key: Optional[str] = None

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
