# ============================================================
# app/core/database.py — DuckDB engine with S3 + local support
# ============================================================
"""
Thread-safe DuckDB connection pool.

DuckDB supports multiple reader connections but only one writer.
For a read-heavy query API we use a pool of read-only connections
plus one dedicated write connection for schema/setup operations.
"""
import os
import threading
import queue
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional
import duckdb
import structlog

from app.core.settings import settings

logger = structlog.get_logger()


# ── DuckDB Pool ──────────────────────────────────────────────────────────────

class DuckDBPool:
    """
    Simple round-robin pool of DuckDB read-only connections.
    Each connection is pre-configured with S3 credentials and
    performance settings pulled from `settings`.
    """

    def __init__(self, pool_size: int = settings.duckdb_threads):
        self._pool: queue.Queue[duckdb.DuckDBPyConnection] = queue.Queue()
        self._pool_size = pool_size
        self._lock = threading.Lock()
        self._initialized = False

    def initialize(self) -> None:
        """Call once at startup."""
        if self._initialized:
            return
        with self._lock:
            if self._initialized:
                return
            os.makedirs(settings.duckdb_temp_dir, exist_ok=True)
            for _ in range(self._pool_size):
                conn = self._create_connection()
                self._pool.put(conn)
            self._initialized = True
            logger.info("duckdb_pool_ready", pool_size=self._pool_size)

    def _create_connection(self) -> duckdb.DuckDBPyConnection:
        conn = duckdb.connect(":memory:")

        # Performance tuning
        conn.execute(f"SET threads TO {settings.duckdb_threads}")
        conn.execute(f"SET memory_limit='{settings.duckdb_memory_limit}'")
        conn.execute(f"SET temp_directory='{settings.duckdb_temp_dir}'")
        conn.execute("SET enable_progress_bar=false")

        # Load S3 extension and configure credentials
        if settings.s3_enabled:
            conn.execute("INSTALL httpfs")
            conn.execute("LOAD httpfs")
            conn.execute(f"SET s3_region='{settings.s3_region}'")
            if settings.aws_access_key_id:
                conn.execute(f"SET s3_access_key_id='{settings.aws_access_key_id}'")
            if settings.aws_secret_access_key:
                conn.execute(f"SET s3_secret_access_key='{settings.aws_secret_access_key}'")
            if settings.aws_session_token:
                conn.execute(f"SET s3_session_token='{settings.aws_session_token}'")
            if settings.s3_endpoint_url:
                # MinIO / LocalStack
                conn.execute(f"SET s3_endpoint='{settings.s3_endpoint_url}'")
                conn.execute("SET s3_use_ssl=false")
                conn.execute("SET s3_url_style='path'")
            logger.debug("duckdb_s3_configured", region=settings.s3_region)

        return conn

    @contextmanager
    def get_connection(self) -> Generator[duckdb.DuckDBPyConnection, None, None]:
        """Acquire a connection from the pool (blocks until available)."""
        conn = self._pool.get(timeout=30)
        try:
            yield conn
        except Exception:
            # Replace broken connection
            try:
                conn.close()
            except Exception:
                pass
            conn = self._create_connection()
            raise
        finally:
            self._pool.put(conn)

    def shutdown(self) -> None:
        while not self._pool.empty():
            try:
                conn = self._pool.get_nowait()
                conn.close()
            except Exception:
                pass
        logger.info("duckdb_pool_shutdown")


# Global pool instance
db_pool = DuckDBPool()


def get_db_pool() -> DuckDBPool:
    """FastAPI dependency that returns the pool."""
    return db_pool
