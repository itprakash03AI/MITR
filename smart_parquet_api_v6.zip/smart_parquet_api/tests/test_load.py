#!/usr/bin/env python3
# ============================================================
# tests/test_load.py — Concurrency load test
# ============================================================
"""
Proves the API handles 100+ concurrent requests correctly.

Run against a live server:
  # Terminal 1: start the API
  python -m app.main

  # Terminal 2: run load test
  python tests/test_load.py

Or run DuckDB concurrency test standalone (no API needed):
  python tests/test_load.py --local

What this tests:
  1. 100 simultaneous requests — all get a valid response
  2. Cache effectiveness — 2nd wave is near-instant
  3. Request coalescing — identical concurrent requests deduplicated
  4. Graceful degradation — overload returns 503, not crash
  5. DuckDB direct concurrency — semaphore behaviour without HTTP
"""
import argparse
import asyncio
import statistics
import sys
import time
from pathlib import Path
from typing import Dict, List

# ── Config ────────────────────────────────────────────────────────────────────
BASE_URL     = "http://localhost:8000"
CONCURRENCY  = 100    # simultaneous requests
TOTAL        = 300    # total requests in full test

DATA_DIR = Path(__file__).parent.parent / "data"


# ═══════════════════════════════════════════════════════════════════════════
# PART 1: DuckDB direct concurrency test (no HTTP, no API needed)
# ═══════════════════════════════════════════════════════════════════════════

def test_duckdb_concurrency_local():
    """
    Tests the semaphore + executor directly without HTTP overhead.
    Runs inside the same process — proves the concurrency logic works.
    """
    import asyncio
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    # Check sample data exists
    for f in ["tb_accounts.parquet", "tb_transactions.parquet", "tb_balances.parquet"]:
        if not (DATA_DIR / f).exists():
            print(f"ERROR: Missing {DATA_DIR / f}")
            print("Run: python scripts/generate_sample_data.py")
            sys.exit(1)

    from app.core.settings import settings
    # Patch settings for the test
    settings.max_concurrent_queries = 4
    settings.thread_pool_size       = 8
    settings.duckdb_threads         = 2
    settings.max_queue_depth        = 200
    settings.cache_enabled          = True
    settings.cache_ttl_seconds      = 60

    from app.core.database import db_pool
    from app.core.query_executor import QueryExecutor, metrics, result_cache

    db_pool.initialize()
    executor = QueryExecutor(db_pool)

    queries = [
        ("Simple COUNT", f"SELECT COUNT(*) AS cnt FROM read_parquet('{DATA_DIR}/tb_accounts.parquet')"),
        ("Grouped aggregation", f"SELECT account_type, COUNT(*), SUM(opening_balance) FROM read_parquet('{DATA_DIR}/tb_balances.parquet') GROUP BY account_type"),
        ("3-way JOIN",
         f"SELECT a.account_type, COUNT(*) AS txn_count, SUM(t.debit_amount) AS total "
         f"FROM read_parquet('{DATA_DIR}/tb_accounts.parquet') a "
         f"JOIN read_parquet('{DATA_DIR}/tb_transactions.parquet') t ON a.account_id = t.account_id "
         f"JOIN read_parquet('{DATA_DIR}/tb_balances.parquet') b ON a.account_id = b.account_id "
         f"AND t.fiscal_year = b.fiscal_year AND t.period = b.period "
         f"WHERE t.fiscal_year = 2024 GROUP BY a.account_type"),
        ("Window function",
         f"SELECT account_id, fiscal_year, period, closing_balance, "
         f"RANK() OVER (PARTITION BY fiscal_year ORDER BY closing_balance DESC) AS rnk "
         f"FROM read_parquet('{DATA_DIR}/tb_balances.parquet') "
         f"WHERE fiscal_year = 2024 QUALIFY rnk <= 3"),
    ]

    async def run_all():
        print("\n" + "=" * 65)
        print("  DuckDB Direct Concurrency Test")
        print(f"  max_concurrent_queries = {settings.max_concurrent_queries}")
        print(f"  thread_pool_size       = {settings.thread_pool_size}")
        print(f"  duckdb_threads/query   = {settings.duckdb_threads}")
        print("=" * 65)

        # ── Test 1: 100 concurrent requests (mix of queries) ─────────────
        print(f"\n[1] Firing {CONCURRENCY} concurrent requests...")
        result_cache.clear()

        async def one_request(i: int) -> Dict:
            name, sql = queries[i % len(queries)]
            t0 = time.perf_counter()
            try:
                result = await executor.execute(sql, page=1, page_size=100, cache=True)
                elapsed = (time.perf_counter() - t0) * 1000
                return {"ok": True, "name": name, "ms": elapsed,
                        "cached": result.cached, "coalesced": result.coalesced}
            except Exception as e:
                elapsed = (time.perf_counter() - t0) * 1000
                return {"ok": False, "name": name, "ms": elapsed, "error": str(e)[:60]}

        t_start = time.perf_counter()
        results = await asyncio.gather(*[one_request(i) for i in range(CONCURRENCY)])
        total_elapsed = (time.perf_counter() - t_start) * 1000

        ok       = [r for r in results if r["ok"]]
        failed   = [r for r in results if not r["ok"]]
        cached   = [r for r in ok if r.get("cached")]
        coalesced = [r for r in ok if r.get("coalesced")]
        latencies = [r["ms"] for r in ok]

        print(f"\n  Results ({CONCURRENCY} requests):")
        print(f"    ✅ Succeeded:  {len(ok)}")
        print(f"    ❌ Failed:     {len(failed)}")
        print(f"    💾 Cache hits: {len(cached)}")
        print(f"    🔀 Coalesced:  {len(coalesced)}")
        print(f"\n  Latency (ms):")
        print(f"    Min:    {min(latencies):.1f}")
        print(f"    Median: {statistics.median(latencies):.1f}")
        print(f"    p95:    {sorted(latencies)[int(len(latencies)*0.95)]:.1f}")
        print(f"    Max:    {max(latencies):.1f}")
        print(f"    Total wall time: {total_elapsed:.0f}ms")
        if failed:
            print(f"\n  Failed requests:")
            for f in failed[:5]:
                print(f"    [{f['name']}] {f.get('error', '?')}")

        # ── Test 2: Cache effectiveness — same requests again ─────────────
        print(f"\n[2] Repeating same {CONCURRENCY} requests (should hit cache)...")
        t_start = time.perf_counter()
        results2 = await asyncio.gather(*[one_request(i) for i in range(CONCURRENCY)])
        total2 = (time.perf_counter() - t_start) * 1000

        ok2      = [r for r in results2 if r["ok"]]
        cached2  = [r for r in ok2 if r.get("cached")]
        lat2     = [r["ms"] for r in ok2]
        print(f"    Cache hits: {len(cached2)}/{len(ok2)}  ({100*len(cached2)//max(len(ok2),1)}%)")
        print(f"    Total wall time: {total2:.0f}ms  (vs {total_elapsed:.0f}ms first wave)")
        print(f"    Speedup: {total_elapsed/max(total2,1):.1f}×")

        # ── Test 3: Overload — queue beyond max_queue_depth ───────────────
        print(f"\n[3] Overload test — {settings.max_queue_depth + 50} concurrent (expect 503s)...")
        settings.cache_enabled = False  # disable cache so they all hit DuckDB
        overload = settings.max_queue_depth + 50

        results3 = await asyncio.gather(
            *[one_request(i) for i in range(overload)],
            return_exceptions=True,
        )
        errors503 = [r for r in results3 if isinstance(r, dict) and not r["ok"]
                     and "capacity" in r.get("error", "")]
        ok3       = [r for r in results3 if isinstance(r, dict) and r["ok"]]
        print(f"    Succeeded: {len(ok3)}")
        print(f"    Rejected (503): {len(errors503)}")
        print(f"    ✅ Graceful degradation — server did not crash")

        settings.cache_enabled = True

        # ── Final metrics snapshot ─────────────────────────────────────────
        print(f"\n  Final metrics snapshot:")
        snap = metrics.snapshot()
        for k, v in snap.items():
            if k != "cache":
                print(f"    {k}: {v}")
        print(f"    cache: {snap['cache']}")

        return len(failed) == 0

    ok = asyncio.run(run_all())
    print(f"\n{'✅ PASSED' if ok else '⚠️  SOME FAILURES (expected under overload)'}\n")
    return ok


# ═══════════════════════════════════════════════════════════════════════════
# PART 2: HTTP load test against live API
# ═══════════════════════════════════════════════════════════════════════════

async def http_load_test():
    try:
        import httpx
    except ImportError:
        print("ERROR: httpx not installed. Run: pip install httpx")
        sys.exit(1)

    endpoints = [
        ("GET", f"{BASE_URL}/api/query/trial-balance/summary"),
        ("GET", f"{BASE_URL}/api/query/trial-balance/summary?fiscal_year=2024"),
        ("POST", f"{BASE_URL}/api/execute/sql"),
    ]

    sql_body = "SELECT account_type, COUNT(*) AS cnt FROM read_parquet('data/tb_accounts.parquet') GROUP BY account_type"

    async def one_http_request(client: httpx.AsyncClient, i: int) -> Dict:
        method, url = endpoints[i % len(endpoints)]
        t0 = time.perf_counter()
        try:
            if method == "POST":
                resp = await client.post(url, content=sql_body,
                                         headers={"Content-Type": "text/plain"})
            else:
                resp = await client.get(url)
            elapsed = (time.perf_counter() - t0) * 1000
            return {
                "ok": resp.status_code in (200, 503),   # 503 = graceful overload
                "status": resp.status_code,
                "ms": elapsed,
                "cached": resp.json().get("meta", {}).get("cached", False)
                          if resp.status_code == 200 else False,
            }
        except Exception as e:
            return {"ok": False, "status": 0, "ms": (time.perf_counter() - t0) * 1000,
                    "error": str(e)[:80]}

    print("\n" + "=" * 65)
    print(f"  HTTP Load Test → {BASE_URL}")
    print(f"  Concurrency: {CONCURRENCY}   Total: {TOTAL}")
    print("=" * 65)

    limits  = httpx.Limits(max_connections=CONCURRENCY + 10, max_keepalive_connections=CONCURRENCY)
    timeout = httpx.Timeout(60.0)

    async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
        # ── Warm up ───────────────────────────────────────────────────────
        print("\n[0] Warmup (10 requests)...")
        await asyncio.gather(*[one_http_request(client, i) for i in range(10)])

        # ── Wave 1: 100 concurrent ────────────────────────────────────────
        print(f"\n[1] {CONCURRENCY} concurrent HTTP requests...")
        t0      = time.perf_counter()
        results = await asyncio.gather(*[one_http_request(client, i) for i in range(CONCURRENCY)])
        elapsed = (time.perf_counter() - t0) * 1000

        ok       = [r for r in results if r["status"] == 200]
        rejected = [r for r in results if r["status"] == 503]
        errors   = [r for r in results if r["status"] not in (200, 503)]
        cached   = [r for r in ok if r.get("cached")]
        latencies = [r["ms"] for r in ok]

        print(f"\n  200 OK:       {len(ok)}")
        print(f"  503 (queued): {len(rejected)}")
        print(f"  Errors:       {len(errors)}")
        print(f"  Cache hits:   {len(cached)}")
        if latencies:
            print(f"\n  Latency (ms):")
            print(f"    p50: {statistics.median(latencies):.0f}")
            print(f"    p95: {sorted(latencies)[int(len(latencies)*0.95)]:.0f}")
            print(f"    max: {max(latencies):.0f}")
        print(f"  Wall time: {elapsed:.0f}ms")

        # ── Wave 2: cache check ───────────────────────────────────────────
        print(f"\n[2] Same {CONCURRENCY} requests (cache check)...")
        t0       = time.perf_counter()
        results2 = await asyncio.gather(*[one_http_request(client, i) for i in range(CONCURRENCY)])
        elapsed2 = (time.perf_counter() - t0) * 1000
        ok2      = [r for r in results2 if r["status"] == 200]
        cached2  = [r for r in ok2 if r.get("cached")]
        print(f"  Cache hits: {len(cached2)}/{len(ok2)}")
        print(f"  Wall time: {elapsed2:.0f}ms  (speedup: {elapsed/max(elapsed2,1):.1f}×)")

        # ── Metrics ───────────────────────────────────────────────────────
        print(f"\n[3] Server metrics:")
        resp = await client.get(f"{BASE_URL}/api/admin/metrics")
        if resp.status_code == 200:
            for k, v in resp.json().items():
                print(f"  {k}: {v}")

    print("\n✅ HTTP load test complete\n")


# ═══════════════════════════════════════════════════════════════════════════
# Throughput benchmark — measures sustained RPS
# ═══════════════════════════════════════════════════════════════════════════

async def rps_benchmark(duration_sec: int = 30):
    try:
        import httpx
    except ImportError:
        print("httpx not installed")
        return

    print(f"\n  RPS Benchmark ({duration_sec}s sustained load, {CONCURRENCY} concurrent)...")
    url     = f"{BASE_URL}/api/query/trial-balance/summary?fiscal_year=2024"
    counts  = {"ok": 0, "err": 0}
    latencies = []
    stop    = asyncio.Event()

    async def worker():
        limits  = httpx.Limits(max_connections=10)
        timeout = httpx.Timeout(30.0)
        async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
            while not stop.is_set():
                t0 = time.perf_counter()
                try:
                    r = await client.get(url)
                    latencies.append((time.perf_counter() - t0) * 1000)
                    if r.status_code in (200, 503):
                        counts["ok"] += 1
                    else:
                        counts["err"] += 1
                except Exception:
                    counts["err"] += 1

    workers = [asyncio.create_task(worker()) for _ in range(CONCURRENCY)]

    await asyncio.sleep(duration_sec)
    stop.set()
    await asyncio.gather(*workers, return_exceptions=True)

    total = counts["ok"] + counts["err"]
    rps   = total / duration_sec
    print(f"  Total requests: {total}")
    print(f"  Throughput:     {rps:.1f} req/s")
    if latencies:
        print(f"  p50 latency:    {statistics.median(latencies):.0f}ms")
        print(f"  p95 latency:    {sorted(latencies)[int(len(latencies)*0.95)]:.0f}ms")


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--local",  action="store_true", help="DuckDB direct test (no API)")
    parser.add_argument("--http",   action="store_true", help="HTTP load test (needs running API)")
    parser.add_argument("--rps",    action="store_true", help="RPS benchmark (needs running API)")
    parser.add_argument("--all",    action="store_true", help="Run all tests")
    parser.add_argument("--url",    default=BASE_URL, help=f"API base URL (default: {BASE_URL})")
    parser.add_argument("--concurrency", type=int, default=CONCURRENCY)
    args = parser.parse_args()

    CONCURRENCY = args.concurrency
    BASE_URL    = args.url

    if args.local or args.all or not any([args.http, args.rps, args.local]):
        test_duckdb_concurrency_local()

    if args.http or args.all:
        asyncio.run(http_load_test())

    if args.rps or args.all:
        asyncio.run(rps_benchmark())
