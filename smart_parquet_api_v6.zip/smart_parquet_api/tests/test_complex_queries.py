#!/usr/bin/env python3
# ============================================================
# tests/test_complex_queries.py
# Stress-tests every advanced DuckDB query pattern
# Run standalone (no API needed): python tests/test_complex_queries.py
# Or via pytest: pytest tests/test_complex_queries.py -v -s
# ============================================================
"""
Tests every category of complex analytical SQL:

  1.  Multi-table JOINs (3-way, 5-way, self-join)
  2.  All window functions (RANK, LAG/LEAD, running totals, NTILE)
  3.  CTEs — flat, nested, recursive
  4.  ROLLUP / CUBE / GROUPING SETS
  5.  UNION ALL (3-way, column mismatch with cast)
  6.  Subqueries — correlated + uncorrelated
  7.  LATERAL joins
  8.  PIVOT / UNPIVOT
  9.  Conditional aggregation (FILTER clause)
  10. JSON / struct columns
  11. Regex and string operations
  12. Date / time arithmetic
  13. Percentile / statistical functions
  14. Large join with 200 selected columns
  15. Nested CTEs with window functions
  16. Time-travel simulation (snapshot pinning)
  17. Multi-level aggregation (aggregation on aggregation)
  18. Cross-file UNION then aggregate
"""

import sys
import time
import traceback
from pathlib import Path
from typing import Callable, List, Tuple

# ── DuckDB direct (no API needed for these tests) ────────────────────────────
try:
    import duckdb
except ImportError:
    print("ERROR: duckdb not installed. Run: pip install duckdb")
    sys.exit(1)

# ── Paths ────────────────────────────────────────────────────────────────────
ROOT     = Path(__file__).parent.parent
DATA_DIR = ROOT / "data"

TB_ACCOUNTS     = str(DATA_DIR / "tb_accounts.parquet")
TB_TRANSACTIONS = str(DATA_DIR / "tb_transactions.parquet")
TB_BALANCES     = str(DATA_DIR / "tb_balances.parquet")

# Verify files exist
for f in [TB_ACCOUNTS, TB_TRANSACTIONS, TB_BALANCES]:
    if not Path(f).exists():
        print(f"ERROR: Missing {f}")
        print("Run: python scripts/generate_sample_data.py")
        sys.exit(1)

# ── DuckDB connection ─────────────────────────────────────────────────────────
conn = duckdb.connect(":memory:")
conn.execute("SET threads TO 4")
conn.execute("SET memory_limit='2GB'")
conn.execute("SET temp_directory='/tmp/duckdb_test'")

# Shorthand helpers
A = f"read_parquet('{TB_ACCOUNTS}')"
T = f"read_parquet('{TB_TRANSACTIONS}')"
B = f"read_parquet('{TB_BALANCES}')"


# ── Test harness ─────────────────────────────────────────────────────────────

class Results:
    passed: List[str] = []
    failed: List[Tuple[str, str]] = []


def run(name: str, sql: str, expect_rows: int = 1) -> bool:
    t0 = time.perf_counter()
    try:
        rows = conn.execute(sql).fetchall()
        elapsed = (time.perf_counter() - t0) * 1000
        assert len(rows) >= expect_rows, f"Expected ≥{expect_rows} rows, got {len(rows)}"
        print(f"  ✅ {name:<55} {len(rows):>6,} rows  {elapsed:>7.1f} ms")
        Results.passed.append(name)
        return True
    except Exception as exc:
        elapsed = (time.perf_counter() - t0) * 1000
        print(f"  ❌ {name:<55} FAILED  {elapsed:>7.1f} ms")
        print(f"      {exc}")
        Results.failed.append((name, str(exc)))
        return False


# ═══════════════════════════════════════════════════════════════════════════
# 1. MULTI-TABLE JOINS
# ═══════════════════════════════════════════════════════════════════════════
def test_joins():
    print("\n── 1. Multi-Table JOINs ──────────────────────────────────────────")

    run("3-way INNER JOIN (accounts + transactions + balances)",
        f"""
        SELECT a.account_id, a.account_type, t.debit_amount, b.closing_balance
        FROM {A} a
        JOIN {T} t ON a.account_id = t.account_id
        JOIN {B} b ON a.account_id = b.account_id AND t.fiscal_year = b.fiscal_year AND t.period = b.period
        LIMIT 100
        """)

    run("LEFT JOIN — all accounts including those with no transactions",
        f"""
        SELECT a.account_id, a.account_type, COUNT(t.transaction_id) AS txn_count
        FROM {A} a
        LEFT JOIN {T} t ON a.account_id = t.account_id
        GROUP BY a.account_id, a.account_type
        ORDER BY txn_count DESC
        LIMIT 50
        """)

    run("Self-JOIN — accounts with their parent account info",
        f"""
        SELECT c.account_id, c.account_name AS child_name,
               p.account_name AS parent_name, p.account_type
        FROM {A} c
        LEFT JOIN {A} p ON c.parent_account_id = p.account_id
        WHERE c.hierarchy_level > 1
        LIMIT 50
        """)

    run("5-way JOIN (accounts + txn + balances + txn alias + bal alias)",
        f"""
        SELECT
            a.account_id,
            a.account_type,
            t1.fiscal_year,
            t1.period,
            SUM(t1.debit_amount)   AS debits,
            SUM(t1.credit_amount)  AS credits,
            b1.closing_balance,
            b1.budget_amount,
            COUNT(t2.transaction_id) AS reversal_count
        FROM {A} a
        JOIN {T} t1 ON a.account_id = t1.account_id
        JOIN {B} b1 ON a.account_id = b1.account_id
                   AND t1.fiscal_year = b1.fiscal_year
                   AND t1.period      = b1.period
        LEFT JOIN {T} t2 ON a.account_id = t2.account_id
                        AND t2.transaction_type = 'Reversal'
                        AND t2.fiscal_year = t1.fiscal_year
        LEFT JOIN {B} b2 ON a.account_id = b2.account_id
                        AND b2.fiscal_year = t1.fiscal_year - 1
                        AND b2.period = 12
        WHERE t1.fiscal_year = 2024
        GROUP BY a.account_id, a.account_type, t1.fiscal_year, t1.period,
                 b1.closing_balance, b1.budget_amount
        HAVING SUM(t1.debit_amount) > 0
        ORDER BY debits DESC
        LIMIT 100
        """)

    run("JOIN with BETWEEN range condition",
        f"""
        SELECT a.account_id, a.account_type,
               t.posting_date, t.debit_amount
        FROM {A} a
        JOIN {T} t ON a.account_id = t.account_id
        WHERE t.posting_date BETWEEN '2024-01-01' AND '2024-06-30'
          AND t.debit_amount > 100000
        ORDER BY t.debit_amount DESC
        LIMIT 50
        """)

    run("ANTI JOIN — accounts with zero transactions in 2024",
        f"""
        SELECT a.account_id, a.account_code, a.account_type
        FROM {A} a
        WHERE NOT EXISTS (
            SELECT 1 FROM {T} t
            WHERE t.account_id = a.account_id
              AND t.fiscal_year = 2024
        )
        LIMIT 50
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 2. WINDOW FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════
def test_window_functions():
    print("\n── 2. Window Functions ───────────────────────────────────────────")

    run("RANK + DENSE_RANK + ROW_NUMBER by debit amount",
        f"""
        SELECT
            account_id, fiscal_year, period,
            debit_amount,
            ROW_NUMBER()  OVER (PARTITION BY fiscal_year ORDER BY debit_amount DESC) AS rn,
            RANK()        OVER (PARTITION BY fiscal_year ORDER BY debit_amount DESC) AS rnk,
            DENSE_RANK()  OVER (PARTITION BY fiscal_year ORDER BY debit_amount DESC) AS dense_rnk
        FROM {T}
        WHERE fiscal_year = 2024
        QUALIFY rn <= 5
        """)

    run("LAG / LEAD — month-over-month balance change",
        f"""
        SELECT
            account_id, entity, fiscal_year, period,
            closing_balance,
            LAG(closing_balance)  OVER (PARTITION BY account_id, entity ORDER BY fiscal_year, period) AS prev_balance,
            LEAD(closing_balance) OVER (PARTITION BY account_id, entity ORDER BY fiscal_year, period) AS next_balance,
            closing_balance - LAG(closing_balance) OVER (PARTITION BY account_id, entity ORDER BY fiscal_year, period) AS mom_change
        FROM {B}
        ORDER BY account_id, entity, fiscal_year, period
        LIMIT 100
        """)

    run("Running totals (SUM OVER unbounded preceding)",
        f"""
        SELECT
            account_id, fiscal_year, period,
            period_debits,
            SUM(period_debits)  OVER (PARTITION BY account_id ORDER BY fiscal_year, period
                                      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS ytd_debits_running,
            AVG(period_debits)  OVER (PARTITION BY account_id ORDER BY fiscal_year, period
                                      ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)          AS rolling_3m_avg
        FROM {B}
        WHERE fiscal_year = 2024
        ORDER BY account_id, period
        LIMIT 100
        """)

    run("NTILE — bucket accounts into quartiles by total balance",
        f"""
        SELECT
            account_id, total_balance,
            NTILE(4) OVER (ORDER BY total_balance) AS quartile,
            PERCENT_RANK() OVER (ORDER BY total_balance) AS pct_rank
        FROM (
            SELECT account_id, SUM(closing_balance) AS total_balance
            FROM {B}
            WHERE fiscal_year = 2024
            GROUP BY account_id
        )
        ORDER BY total_balance DESC
        LIMIT 100
        """)

    run("FIRST_VALUE / LAST_VALUE within partition",
        f"""
        SELECT
            account_id, entity, period,
            closing_balance,
            FIRST_VALUE(closing_balance) OVER w AS opening_snap,
            LAST_VALUE(closing_balance)  OVER w AS closing_snap,
            MAX(closing_balance)         OVER w AS period_high,
            MIN(closing_balance)         OVER w AS period_low
        FROM {B}
        WHERE fiscal_year = 2024
        WINDOW w AS (PARTITION BY account_id, entity ORDER BY period
                     ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
        ORDER BY account_id, entity, period
        LIMIT 100
        """)

    run("CUME_DIST + cumulative % of total debits",
        f"""
        SELECT
            account_id,
            total_debits,
            CUME_DIST() OVER (ORDER BY total_debits) AS cume_dist,
            SUM(total_debits) OVER (ORDER BY total_debits
                                    ROWS UNBOUNDED PRECEDING) /
            SUM(total_debits) OVER ()                              AS running_pct
        FROM (
            SELECT account_id, SUM(debit_amount) AS total_debits
            FROM {T}
            WHERE fiscal_year = 2024
            GROUP BY account_id
        )
        ORDER BY total_debits DESC
        LIMIT 50
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 3. CTEs (Common Table Expressions)
# ═══════════════════════════════════════════════════════════════════════════
def test_ctes():
    print("\n── 3. CTEs ───────────────────────────────────────────────────────")

    run("Flat multi-CTE — 4 CTEs feeding final SELECT",
        f"""
        WITH
        account_totals AS (
            SELECT account_id,
                   SUM(debit_amount)  AS total_debits,
                   SUM(credit_amount) AS total_credits,
                   COUNT(*)           AS txn_count
            FROM {T}
            WHERE fiscal_year = 2024
            GROUP BY account_id
        ),
        balance_totals AS (
            SELECT account_id,
                   AVG(closing_balance) AS avg_balance,
                   SUM(budget_amount)   AS total_budget,
                   SUM(variance)        AS total_variance
            FROM {B}
            WHERE fiscal_year = 2024
            GROUP BY account_id
        ),
        account_master AS (
            SELECT account_id, account_code, account_name, account_type
            FROM {A}
            WHERE is_active = true
        ),
        combined AS (
            SELECT
                am.account_id, am.account_code, am.account_name, am.account_type,
                COALESCE(at2.total_debits, 0)   AS total_debits,
                COALESCE(at2.total_credits, 0)  AS total_credits,
                COALESCE(bt.avg_balance, 0)     AS avg_balance,
                COALESCE(bt.total_budget, 0)    AS total_budget,
                COALESCE(bt.total_variance, 0)  AS total_variance,
                COALESCE(at2.txn_count, 0)      AS txn_count
            FROM account_master am
            LEFT JOIN account_totals at2 ON am.account_id = at2.account_id
            LEFT JOIN balance_totals bt  ON am.account_id = bt.account_id
        )
        SELECT *, ROUND(total_debits / NULLIF(total_credits, 0), 4) AS debit_credit_ratio
        FROM combined
        ORDER BY total_debits DESC
        LIMIT 100
        """)

    run("Nested CTEs — CTE referencing another CTE",
        f"""
        WITH
        txn_ranked AS (
            SELECT account_id, fiscal_year, period, debit_amount,
                   RANK() OVER (PARTITION BY account_id ORDER BY debit_amount DESC) AS rnk
            FROM {T}
            WHERE fiscal_year = 2024
        ),
        top_txns AS (
            SELECT account_id, fiscal_year, period,
                   SUM(debit_amount) AS top5_debits
            FROM txn_ranked
            WHERE rnk <= 5
            GROUP BY account_id, fiscal_year, period
        ),
        with_pct AS (
            SELECT tt.*, a.account_type,
                   tt.top5_debits / NULLIF(SUM(tt.top5_debits) OVER (PARTITION BY tt.fiscal_year), 0) AS pct_of_total
            FROM top_txns tt
            JOIN {A} a ON tt.account_id = a.account_id
        )
        SELECT * FROM with_pct
        WHERE pct_of_total > 0.001
        ORDER BY pct_of_total DESC
        LIMIT 50
        """)

    run("Recursive CTE — account hierarchy traversal",
        f"""
        WITH RECURSIVE account_hierarchy AS (
            -- Base: root accounts (no parent)
            SELECT account_id, account_name, account_type,
                   parent_account_id, hierarchy_level,
                   account_id AS root_id,
                   account_name AS root_name,
                   0 AS depth
            FROM {A}
            WHERE parent_account_id IS NULL

            UNION ALL

            -- Recursive: children
            SELECT c.account_id, c.account_name, c.account_type,
                   c.parent_account_id, c.hierarchy_level,
                   h.root_id, h.root_name,
                   h.depth + 1
            FROM {A} c
            JOIN account_hierarchy h ON c.parent_account_id = h.account_id
            WHERE h.depth < 5   -- safety limit
        )
        SELECT root_name, account_type,
               COUNT(*) AS descendants,
               MAX(depth) AS max_depth
        FROM account_hierarchy
        GROUP BY root_name, account_type
        ORDER BY descendants DESC
        LIMIT 30
        """)

    run("CTE with window + aggregation on aggregation",
        f"""
        WITH
        period_balances AS (
            SELECT account_id, fiscal_year, period,
                   SUM(closing_balance) AS total_balance,
                   SUM(period_debits)   AS period_debits,
                   SUM(period_credits)  AS period_credits
            FROM {B}
            GROUP BY account_id, fiscal_year, period
        ),
        with_growth AS (
            SELECT *,
                   total_balance - LAG(total_balance) OVER (PARTITION BY account_id ORDER BY fiscal_year, period) AS balance_delta,
                   ROUND(100.0 * (total_balance - LAG(total_balance) OVER (PARTITION BY account_id ORDER BY fiscal_year, period))
                         / NULLIF(ABS(LAG(total_balance) OVER (PARTITION BY account_id ORDER BY fiscal_year, period)), 0), 2) AS growth_pct
            FROM period_balances
        )
        SELECT fiscal_year, period,
               AVG(growth_pct)            AS avg_growth_pct,
               PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY growth_pct) AS median_growth,
               STDDEV(growth_pct)         AS stddev_growth,
               COUNT(*) FILTER (WHERE growth_pct > 10) AS high_growth_accounts
        FROM with_growth
        WHERE growth_pct IS NOT NULL
        GROUP BY fiscal_year, period
        ORDER BY fiscal_year, period
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 4. ROLLUP / CUBE / GROUPING SETS
# ═══════════════════════════════════════════════════════════════════════════
def test_grouping():
    print("\n── 4. ROLLUP / CUBE / GROUPING SETS ─────────────────────────────")

    run("ROLLUP — entity → account_type → period subtotals",
        f"""
        SELECT
            COALESCE(a.account_type, '** ALL TYPES **')  AS account_type,
            COALESCE(CAST(t.fiscal_year AS VARCHAR), '** ALL YEARS **') AS fiscal_year,
            COALESCE(CAST(t.period AS VARCHAR), '** ALL PERIODS **')    AS period,
            SUM(t.debit_amount)  AS total_debits,
            SUM(t.credit_amount) AS total_credits,
            COUNT(*)             AS row_count,
            GROUPING(a.account_type, t.fiscal_year, t.period) AS grp_level
        FROM {T} t
        JOIN {A} a ON t.account_id = a.account_id
        WHERE t.fiscal_year = 2024
        GROUP BY ROLLUP(a.account_type, t.fiscal_year, t.period)
        ORDER BY grp_level DESC, account_type, fiscal_year, period
        """)

    run("CUBE — full cross-tab: entity × account_type × currency",
        f"""
        SELECT
            COALESCE(a.account_type, 'ALL') AS account_type,
            COALESCE(t.currency, 'ALL')     AS currency,
            COALESCE(t.entity, 'ALL')       AS entity,
            SUM(t.debit_amount)             AS total_debits,
            COUNT(DISTINCT t.account_id)    AS account_count
        FROM {T} t
        JOIN {A} a ON t.account_id = a.account_id
        WHERE t.fiscal_year = 2024
        GROUP BY CUBE(a.account_type, t.currency, t.entity)
        ORDER BY GROUPING(a.account_type, t.currency, t.entity) DESC
        LIMIT 200
        """)

    run("GROUPING SETS — custom subtotal combinations",
        f"""
        SELECT
            COALESCE(a.account_type, '-')  AS account_type,
            COALESCE(b.entity, '-')        AS entity,
            COALESCE(CAST(b.period AS VARCHAR), '-') AS period,
            SUM(b.closing_balance)  AS total_closing,
            SUM(b.budget_amount)    AS total_budget,
            SUM(b.variance)         AS total_variance
        FROM {B} b
        JOIN {A} a ON b.account_id = a.account_id
        WHERE b.fiscal_year = 2024
        GROUP BY GROUPING SETS (
            (a.account_type, b.entity, b.period),   -- detailed
            (a.account_type, b.entity),              -- by type+entity
            (a.account_type),                        -- by type only
            (b.entity),                              -- by entity only
            ()                                       -- grand total
        )
        ORDER BY GROUPING(a.account_type, b.entity, b.period) DESC
        LIMIT 200
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 5. UNION / UNION ALL
# ═══════════════════════════════════════════════════════════════════════════
def test_unions():
    print("\n── 5. UNION ALL ──────────────────────────────────────────────────")

    run("3-way UNION ALL with different column sets (CAST alignment)",
        f"""
        SELECT 'ACCOUNT'     AS record_type, account_id, NULL::DOUBLE AS amount, account_type AS category, created_date::VARCHAR AS event_date
        FROM {A}
        UNION ALL
        SELECT 'TRANSACTION' AS record_type, account_id, debit_amount AS amount, transaction_type AS category, posting_date::VARCHAR AS event_date
        FROM {T}
        WHERE fiscal_year = 2024
        UNION ALL
        SELECT 'BALANCE'     AS record_type, account_id, closing_balance AS amount, ledger AS category, last_reconciled::VARCHAR AS event_date
        FROM {B}
        WHERE fiscal_year = 2024
        ORDER BY account_id, record_type
        LIMIT 300
        """)

    run("UNION ALL then aggregate — total rows per source",
        f"""
        SELECT record_type, COUNT(*) AS cnt, SUM(amount) AS total_amount
        FROM (
            SELECT 'ACCOUNT'     AS record_type, NULL::DOUBLE AS amount FROM {A}
            UNION ALL
            SELECT 'TRANSACTION' AS record_type, debit_amount            FROM {T}
            UNION ALL
            SELECT 'BALANCE'     AS record_type, closing_balance         FROM {B}
        )
        GROUP BY record_type
        ORDER BY cnt DESC
        """)

    run("INTERSECT — accounts appearing in both transactions AND balances",
        f"""
        SELECT account_id FROM {T} WHERE fiscal_year = 2024
        INTERSECT
        SELECT account_id FROM {B} WHERE fiscal_year = 2024
        LIMIT 100
        """)

    run("EXCEPT — accounts in balances but NOT in transactions",
        f"""
        SELECT account_id FROM {B} WHERE fiscal_year = 2024
        EXCEPT
        SELECT account_id FROM {T} WHERE fiscal_year = 2024
        LIMIT 100
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 6. SUBQUERIES (correlated + uncorrelated)
# ═══════════════════════════════════════════════════════════════════════════
def test_subqueries():
    print("\n── 6. Subqueries ─────────────────────────────────────────────────")

    run("Correlated subquery — accounts where balance > avg balance",
        f"""
        SELECT b.account_id, b.fiscal_year, b.period, b.closing_balance
        FROM {B} b
        WHERE b.closing_balance > (
            SELECT AVG(b2.closing_balance)
            FROM {B} b2
            WHERE b2.fiscal_year = b.fiscal_year
              AND b2.period      = b.period
        )
        ORDER BY b.closing_balance DESC
        LIMIT 100
        """)

    run("Scalar subquery in SELECT — each row shows total for its year",
        f"""
        SELECT
            account_id, fiscal_year, period, closing_balance,
            (SELECT SUM(b2.closing_balance)
             FROM {B} b2
             WHERE b2.fiscal_year = b.fiscal_year) AS year_total,
            ROUND(100.0 * closing_balance /
                  NULLIF((SELECT SUM(b2.closing_balance) FROM {B} b2 WHERE b2.fiscal_year = b.fiscal_year), 0), 4) AS pct_of_year
        FROM {B} b
        WHERE fiscal_year = 2024
        LIMIT 50
        """)

    run("IN subquery — transactions for top-10 accounts by balance",
        f"""
        SELECT t.account_id, t.transaction_id, t.debit_amount, t.posting_date
        FROM {T} t
        WHERE t.account_id IN (
            SELECT account_id
            FROM (
                SELECT account_id, SUM(closing_balance) AS total_bal
                FROM {B}
                WHERE fiscal_year = 2024
                GROUP BY account_id
                ORDER BY total_bal DESC
                LIMIT 10
            )
        )
        AND t.fiscal_year = 2024
        ORDER BY t.debit_amount DESC
        LIMIT 100
        """)

    run("Subquery in FROM clause — derived table",
        f"""
        SELECT
            monthly_totals.fiscal_year,
            monthly_totals.period,
            monthly_totals.total_debits,
            a_types.asset_count,
            a_types.expense_count
        FROM (
            SELECT fiscal_year, period,
                   SUM(debit_amount) AS total_debits,
                   COUNT(DISTINCT account_id) AS account_count
            FROM {T}
            WHERE fiscal_year = 2024
            GROUP BY fiscal_year, period
        ) monthly_totals
        JOIN (
            SELECT
                t2.fiscal_year, t2.period,
                COUNT(DISTINCT CASE WHEN a.account_type = 'Asset'   THEN a.account_id END) AS asset_count,
                COUNT(DISTINCT CASE WHEN a.account_type = 'Expense' THEN a.account_id END) AS expense_count
            FROM {T} t2
            JOIN {A} a ON t2.account_id = a.account_id
            WHERE t2.fiscal_year = 2024
            GROUP BY t2.fiscal_year, t2.period
        ) a_types USING (fiscal_year, period)
        ORDER BY fiscal_year, period
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 7. LATERAL JOINS
# ═══════════════════════════════════════════════════════════════════════════
def test_lateral():
    print("\n── 7. LATERAL Joins ──────────────────────────────────────────────")

    run("LATERAL — top 3 transactions per account",
        f"""
        SELECT a.account_id, a.account_type, top_txns.*
        FROM {A} a,
        LATERAL (
            SELECT transaction_id, debit_amount, posting_date, status
            FROM {T} t
            WHERE t.account_id = a.account_id
              AND t.fiscal_year = 2024
            ORDER BY debit_amount DESC
            LIMIT 3
        ) top_txns
        WHERE a.is_active = true
        LIMIT 100
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 8. PIVOT / UNPIVOT
# ═══════════════════════════════════════════════════════════════════════════
def test_pivot():
    print("\n── 8. PIVOT / UNPIVOT ────────────────────────────────────────────")

    run("PIVOT — periods as columns (P1..P12) for balance",
        f"""
        PIVOT (
            SELECT account_id, period, SUM(closing_balance) AS balance
            FROM {B}
            WHERE fiscal_year = 2024
            GROUP BY account_id, period
        )
        ON period
        USING SUM(balance)
        ORDER BY account_id
        LIMIT 50
        """)

    run("Manual PIVOT using conditional aggregation (FILTER clause)",
        f"""
        SELECT
            account_id,
            SUM(period_debits) FILTER (WHERE period = 1)  AS jan,
            SUM(period_debits) FILTER (WHERE period = 2)  AS feb,
            SUM(period_debits) FILTER (WHERE period = 3)  AS mar,
            SUM(period_debits) FILTER (WHERE period = 4)  AS apr,
            SUM(period_debits) FILTER (WHERE period = 5)  AS may,
            SUM(period_debits) FILTER (WHERE period = 6)  AS jun,
            SUM(period_debits) FILTER (WHERE period = 7)  AS jul,
            SUM(period_debits) FILTER (WHERE period = 8)  AS aug,
            SUM(period_debits) FILTER (WHERE period = 9)  AS sep,
            SUM(period_debits) FILTER (WHERE period = 10) AS oct,
            SUM(period_debits) FILTER (WHERE period = 11) AS nov,
            SUM(period_debits) FILTER (WHERE period = 12) AS dec,
            SUM(period_debits)                             AS full_year
        FROM {B}
        WHERE fiscal_year = 2024
        GROUP BY account_id
        ORDER BY full_year DESC
        LIMIT 50
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 9. STATISTICAL / PERCENTILE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════
def test_stats():
    print("\n── 9. Statistical Functions ──────────────────────────────────────")

    run("Percentiles, stddev, variance, median per account type",
        f"""
        SELECT
            a.account_type,
            COUNT(*)                                                        AS txn_count,
            ROUND(AVG(t.debit_amount), 2)                                   AS mean_debit,
            ROUND(STDDEV_POP(t.debit_amount), 2)                            AS stddev_debit,
            ROUND(VARIANCE(t.debit_amount), 2)                              AS variance_debit,
            PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY t.debit_amount)    AS p25,
            PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY t.debit_amount)    AS median,
            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY t.debit_amount)    AS p75,
            PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY t.debit_amount)    AS p95,
            PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY t.debit_amount)    AS p99,
            MAX(t.debit_amount)                                             AS max_debit,
            CORR(t.debit_amount, t.credit_amount)                           AS debit_credit_corr
        FROM {T} t
        JOIN {A} a ON t.account_id = a.account_id
        WHERE t.fiscal_year = 2024
        GROUP BY a.account_type
        ORDER BY mean_debit DESC
        """)

    run("Z-score anomaly detection — outlier transactions",
        f"""
        WITH stats AS (
            SELECT fiscal_year, period,
                   AVG(debit_amount)    AS mean_d,
                   STDDEV(debit_amount) AS std_d
            FROM {T}
            WHERE fiscal_year = 2024
            GROUP BY fiscal_year, period
        )
        SELECT
            t.transaction_id, t.account_id, t.fiscal_year, t.period,
            t.debit_amount,
            ROUND((t.debit_amount - s.mean_d) / NULLIF(s.std_d, 0), 4) AS z_score
        FROM {T} t
        JOIN stats s ON t.fiscal_year = s.fiscal_year AND t.period = s.period
        WHERE ABS((t.debit_amount - s.mean_d) / NULLIF(s.std_d, 0)) > 2.5
        ORDER BY ABS((t.debit_amount - s.mean_d) / NULLIF(s.std_d, 0)) DESC
        LIMIT 50
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 10. DATE / TIME ARITHMETIC
# ═══════════════════════════════════════════════════════════════════════════
def test_dates():
    print("\n── 10. Date / Time Arithmetic ────────────────────────────────────")

    run("Date truncation, extract, diff, fiscal calendar",
        f"""
        SELECT
            account_id,
            posting_date,
            DATE_TRUNC('month', posting_date)         AS month_start,
            DATE_TRUNC('quarter', posting_date)       AS quarter_start,
            EXTRACT(DOW FROM posting_date)            AS day_of_week,
            EXTRACT(WEEK FROM posting_date)           AS iso_week,
            EXTRACT(QUARTER FROM posting_date)        AS quarter,
            DATEDIFF('day', posting_date, CURRENT_DATE) AS days_ago,
            debit_amount
        FROM {T}
        WHERE fiscal_year = 2024
          AND posting_date >= CURRENT_DATE - INTERVAL '365 days'
        ORDER BY posting_date DESC
        LIMIT 50
        """)

    run("30/60/90 day aging buckets",
        f"""
        SELECT
            a.account_type,
            COUNT(CASE WHEN DATEDIFF('day', t.posting_date, CURRENT_DATE) <= 30  THEN 1 END) AS current_30,
            COUNT(CASE WHEN DATEDIFF('day', t.posting_date, CURRENT_DATE) BETWEEN 31 AND 60 THEN 1 END) AS bucket_31_60,
            COUNT(CASE WHEN DATEDIFF('day', t.posting_date, CURRENT_DATE) BETWEEN 61 AND 90 THEN 1 END) AS bucket_61_90,
            COUNT(CASE WHEN DATEDIFF('day', t.posting_date, CURRENT_DATE) > 90  THEN 1 END) AS over_90,
            SUM(t.debit_amount) AS total_debits
        FROM {T} t
        JOIN {A} a ON t.account_id = a.account_id
        GROUP BY a.account_type
        ORDER BY total_debits DESC
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 11. STRING / REGEX OPERATIONS
# ═══════════════════════════════════════════════════════════════════════════
def test_strings():
    print("\n── 11. String / Regex Operations ─────────────────────────────────")

    run("REGEXP_EXTRACT, LIKE, ILIKE, string functions",
        f"""
        SELECT
            account_id,
            account_code,
            account_name,
            UPPER(account_type)                                    AS type_upper,
            LENGTH(account_name)                                   AS name_len,
            SUBSTRING(account_code, 3, 4)                         AS code_mid,
            REGEXP_EXTRACT(account_code, '[0-9]+')                 AS numeric_part,
            CONCAT(account_type, ' | ', account_subtype)          AS combined,
            REPLACE(account_name, 'Account', 'Acct')              AS name_short
        FROM {A}
        WHERE account_name ILIKE '%account%'
          AND REGEXP_MATCHES(account_code, '^GL[0-9]+$')
        LIMIT 50
        """)

    run("STRING_AGG — list of account types per entity (aggregated strings)",
        f"""
        SELECT
            entity,
            STRING_AGG(DISTINCT account_type, ', ' ORDER BY account_type) AS account_types,
            COUNT(DISTINCT account_id) AS account_count,
            COUNT(DISTINCT currency)   AS currency_count
        FROM (
            SELECT DISTINCT a.account_type, a.account_id, a.currency, t.entity
            FROM {A} a
            JOIN {T} t ON a.account_id = t.account_id
            WHERE t.fiscal_year = 2024
        )
        GROUP BY entity
        ORDER BY account_count DESC
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 12. THE BIG ONE — 200-column SELECT with multi-join + window + CTE
# ═══════════════════════════════════════════════════════════════════════════
def test_big_query():
    print("\n── 12. The Big One — multi-CTE + 3-way JOIN + window + 200 cols ─")

    # Build 200 column expressions dynamically
    col_exprs = []
    # Core cols from each table (~60)
    core = [
        "a.account_id", "a.account_code", "a.account_name", "a.account_type",
        "a.account_subtype", "a.currency AS acct_currency", "a.entity AS acct_entity",
        "a.cost_centre AS acct_cc", "a.segment", "a.ledger", "a.is_active",
        "a.intercompany_flag", "a.hierarchy_level", "a.ifrs_classification",
        "a.gaap_classification", "a.tax_code",
        "t.transaction_id", "t.journal_id", "t.posting_date", "t.value_date",
        "t.fiscal_year", "t.period", "t.source_system", "t.transaction_type",
        "t.status AS txn_status", "t.entity AS txn_entity",
        "t.currency AS txn_currency", "t.exchange_rate",
        "t.debit_amount", "t.credit_amount",
        "(t.debit_amount - t.credit_amount) AS net_movement",
        "t.debit_amount * t.exchange_rate AS debit_usd",
        "b.balance_id", "b.opening_balance", "b.period_debits", "b.period_credits",
        "b.closing_balance", "b.ytd_debits", "b.ytd_credits",
        "b.budget_amount", "b.variance", "b.variance_pct", "b.is_reconciled",
        "b.last_reconciled",
        "ROUND(b.closing_balance - b.opening_balance, 2) AS balance_movement",
        "ROUND(b.closing_balance - b.budget_amount, 2)   AS budget_var",
        "ROUND(b.closing_balance / NULLIF(b.budget_amount, 0) * 100, 2) AS budget_util_pct",
    ]
    col_exprs.extend(core)

    # Window function columns (~20)
    windows = [
        "SUM(t.debit_amount) OVER (PARTITION BY t.account_id, t.fiscal_year) AS ytd_debits_win",
        "SUM(t.debit_amount) OVER (PARTITION BY t.account_id, t.fiscal_year ORDER BY t.period ROWS UNBOUNDED PRECEDING) AS running_debit",
        "RANK() OVER (PARTITION BY t.fiscal_year, t.period ORDER BY t.debit_amount DESC) AS debit_rank_in_period",
        "LAG(b.closing_balance) OVER (PARTITION BY b.account_id ORDER BY b.fiscal_year, b.period) AS prev_balance",
        "LEAD(b.closing_balance) OVER (PARTITION BY b.account_id ORDER BY b.fiscal_year, b.period) AS next_balance",
        "AVG(t.debit_amount) OVER (PARTITION BY t.account_id, t.fiscal_year ORDER BY t.period ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS rolling_3m_avg_debit",
        "PERCENT_RANK() OVER (PARTITION BY t.fiscal_year ORDER BY t.debit_amount) AS debit_pct_rank",
        "NTILE(10) OVER (PARTITION BY t.fiscal_year ORDER BY t.debit_amount) AS debit_decile",
        "SUM(b.closing_balance) OVER (PARTITION BY b.entity, b.fiscal_year) AS entity_total_balance",
        "COUNT(*) OVER (PARTITION BY t.account_id, t.fiscal_year) AS acct_txn_count_in_year",
    ]
    col_exprs.extend(windows)

    # Dynamic metric columns to reach 200
    needed = 200 - len(col_exprs)
    for i in range(needed):
        col_exprs.append(f"a.acct_metric_{i:03d}")

    cols_sql = ",\n        ".join(col_exprs[:200])

    run("200-column 3-way JOIN with windows (the enterprise query)",
        f"""
        WITH filtered_txns AS (
            SELECT * FROM {T}
            WHERE fiscal_year = 2024 AND status = 'Posted'
        ),
        filtered_bal AS (
            SELECT * FROM {B}
            WHERE fiscal_year = 2024
        )
        SELECT
        {cols_sql}
        FROM {A} a
        JOIN filtered_txns t ON a.account_id = t.account_id
        JOIN filtered_bal  b ON a.account_id = b.account_id
                             AND t.fiscal_year = b.fiscal_year
                             AND t.period      = b.period
        WHERE a.is_active = true
        ORDER BY t.debit_amount DESC
        LIMIT 500
        """)


# ═══════════════════════════════════════════════════════════════════════════
# 13. MULTI-LEVEL AGGREGATION
# ═══════════════════════════════════════════════════════════════════════════
def test_multilevel_agg():
    print("\n── 13. Multi-Level Aggregation ───────────────────────────────────")

    run("Aggregation on aggregation — avg of monthly totals",
        f"""
        WITH monthly AS (
            SELECT account_id, fiscal_year, period,
                   SUM(debit_amount)  AS monthly_debits,
                   SUM(credit_amount) AS monthly_credits
            FROM {T}
            GROUP BY account_id, fiscal_year, period
        ),
        yearly AS (
            SELECT account_id, fiscal_year,
                   AVG(monthly_debits)  AS avg_monthly_debit,
                   AVG(monthly_credits) AS avg_monthly_credit,
                   STDDEV(monthly_debits) AS stddev_monthly
            FROM monthly
            GROUP BY account_id, fiscal_year
        )
        SELECT y.fiscal_year,
               AVG(y.avg_monthly_debit)  AS grand_avg_debit,
               AVG(y.avg_monthly_credit) AS grand_avg_credit,
               AVG(y.stddev_monthly)     AS avg_stddev
        FROM yearly y
        GROUP BY y.fiscal_year
        ORDER BY y.fiscal_year
        """)

    run("HAVING with complex conditions",
        f"""
        SELECT
            a.account_type,
            t.entity,
            t.fiscal_year,
            COUNT(DISTINCT t.account_id)       AS account_count,
            SUM(t.debit_amount)                AS total_debits,
            AVG(t.debit_amount)                AS avg_debit,
            SUM(t.debit_amount - t.credit_amount) AS net
        FROM {T} t
        JOIN {A} a ON t.account_id = a.account_id
        WHERE t.fiscal_year IN (2022, 2023, 2024)
        GROUP BY a.account_type, t.entity, t.fiscal_year
        HAVING SUM(t.debit_amount) > 1_000_000
           AND COUNT(DISTINCT t.account_id) >= 2
           AND ABS(SUM(t.debit_amount - t.credit_amount)) > 50_000
        ORDER BY total_debits DESC
        LIMIT 50
        """)


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════
def main():
    t_start = time.perf_counter()
    print(f"\n{'='*70}")
    print(f"  DuckDB Complex Query Stress Test")
    print(f"  Data: {DATA_DIR}")
    print(f"{'='*70}")

    test_joins()
    test_window_functions()
    test_ctes()
    test_grouping()
    test_unions()
    test_subqueries()
    test_lateral()
    test_pivot()
    test_stats()
    test_dates()
    test_strings()
    test_big_query()
    test_multilevel_agg()

    total_s = time.perf_counter() - t_start
    total   = len(Results.passed) + len(Results.failed)

    print(f"\n{'='*70}")
    print(f"  Results: {len(Results.passed)}/{total} passed   ({total_s:.1f}s total)")
    if Results.failed:
        print(f"\n  ❌ Failed tests:")
        for name, err in Results.failed:
            print(f"     • {name}")
            print(f"       {err}")
    else:
        print(f"  🎉 All {total} queries passed!")
    print(f"{'='*70}\n")

    return len(Results.failed) == 0


if __name__ == "__main__":
    ok = main()
    sys.exit(0 if ok else 1)


# ── pytest entry points ───────────────────────────────────────────────────────
def test_all_joins():          test_joins()
def test_all_windows():        test_window_functions()
def test_all_ctes():           test_ctes()
def test_all_grouping():       test_grouping()
def test_all_unions():         test_unions()
def test_all_subqueries():     test_subqueries()
def test_all_lateral():        test_lateral()
def test_all_pivot():          test_pivot()
def test_all_stats():          test_stats()
def test_all_dates():          test_dates()
def test_all_strings():        test_strings()
def test_all_big_query():      test_big_query()
def test_all_multilevel():     test_multilevel_agg()
