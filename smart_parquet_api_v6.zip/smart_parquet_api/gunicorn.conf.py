# ============================================================
# gunicorn.conf.py — Production server configuration
# ============================================================
"""
Start the server:
  gunicorn -c gunicorn.conf.py app.main:app

Or explicitly:
  gunicorn app.main:app \
    -w 4 \
    -k uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:8000 \
    --timeout 300 \
    --graceful-timeout 30 \
    --keep-alive 5 \
    --access-logfile -

WORKER CALCULATION:
  workers = (2 × cpu_cores) + 1  is the classic formula for I/O-bound apps.
  For DuckDB (CPU-bound queries), use cpu_cores or cpu_cores/2.
  Each worker gets its own DuckDB pool and semaphore.

  Example: 8-core machine
    workers = 4
    max_concurrent_queries = 4   (per worker)
    Total parallel DuckDB queries = 4 × 4 = 16
    Queue depth per worker = 200
    Total requests handled before 503 = 4 × 200 + 16 = 816
"""
import multiprocessing
import os

# ── Workers ─────────────────────────────────────────────────
# Override with GUNICORN_WORKERS env var
workers = int(os.getenv("GUNICORN_WORKERS", max(2, multiprocessing.cpu_count())))

# Use uvicorn's ASGI worker (required for FastAPI)
worker_class = "uvicorn.workers.UvicornWorker"

# ── Network ──────────────────────────────────────────────────
bind    = os.getenv("BIND", "0.0.0.0:8000")
backlog = 2048   # OS-level connection queue

# ── Timeouts ─────────────────────────────────────────────────
timeout          = int(os.getenv("QUERY_TIMEOUT_SECONDS", 300))
graceful_timeout = 30
keepalive        = 5

# ── Logging ──────────────────────────────────────────────────
accesslog  = "-"    # stdout
errorlog   = "-"    # stderr
loglevel   = os.getenv("LOG_LEVEL", "info").lower()
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s %(D)sµs'

# ── Worker recycling (prevent memory leaks) ───────────────────
max_requests      = 10_000   # recycle worker after N requests
max_requests_jitter = 1_000  # add jitter to avoid all workers restarting at once

# ── Process title ────────────────────────────────────────────
proc_name = "smart-parquet-api"
