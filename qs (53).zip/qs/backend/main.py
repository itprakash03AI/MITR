"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

import json
import time as _time
import uuid
import logging
import traceback
from pathlib import Path
import asyncio
import os
import sys

# Note: faulthandler intentionally NOT enabled.
# DuckDB uses Structured Exception Handlers (SEH) on Windows; faulthandler's
# Vectored Exception Handler intercepts those and causes fatal crashes.
# Python-level crashes are caught by sys.excepthook / threading.excepthook.
# C-level crashes (segfaults) are isolated via subprocess execution (duckdb_subprocess.py).

# ══════════════════════════════════════════════════════════════════════════════
# FIRST: Set up logging + crash handler BEFORE any app imports.
# This ensures every error — including import failures — is captured.
# ══════════════════════════════════════════════════════════════════════════════
def _configure_logging():
    try:
        # Try to read log_format from config — but config may not be loadable yet
        from core.config import server as _srv
        use_json = _srv.log_format == "json"
    except Exception:
        use_json = True  # default to JSON if config not available

    if use_json:
        try:
            from pythonjsonlogger import jsonlogger
            handler = logging.StreamHandler()
            handler.setFormatter(jsonlogger.JsonFormatter(
                fmt="%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)d %(funcName)s",
                rename_fields={
                    "asctime": "timestamp", "levelname": "level", "name": "logger",
                    "pathname": "file", "lineno": "line", "funcName": "func",
                },
            ))
            logging.root.handlers = [handler]
            logging.root.setLevel(logging.INFO)
            return
        except ImportError:
            pass  # fall through to text format
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s [%(pathname)s:%(lineno)d]',
    )

_configure_logging()
logger = logging.getLogger(__name__)

# Global unhandled exception hook — log with full traceback before exit
def _global_exception_hook(exc_type, exc_value, exc_tb):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    logger.critical("Unhandled exception — backend crash", exc_info=(exc_type, exc_value, exc_tb))
    # Also print to stderr as fallback in case logger is broken
    traceback.print_exception(exc_type, exc_value, exc_tb, file=sys.stderr)

sys.excepthook = _global_exception_hook

# Thread exception hook — catches unhandled exceptions in thread-pool threads
def _thread_exception_hook(args):
    logger.critical("Unhandled exception in thread '%s'", args.thread.name if args.thread else "?", exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback, file=sys.stderr)

import threading
threading.excepthook = _thread_exception_hook

# Unraisable exception hook — catches errors Python can't propagate (GC, __del__, etc.)
def _unraisable_hook(unraisable):
    logger.critical("Unraisable exception in %s: %s", unraisable.object, unraisable.exc_value,
                    exc_info=(type(unraisable.exc_value), unraisable.exc_value, unraisable.exc_value.__traceback__) if unraisable.exc_value else True)

sys.unraisablehook = _unraisable_hook

# ══════════════════════════════════════════════════════════════════════════════
# Now safe to import app modules — any error will be logged with full traceback
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# Startup with step-by-step tracing — print() always works, even if logging is broken
# ══════════════════════════════════════════════════════════════════════════════
def _startup_step(label):
    """Print + log a startup step — print goes to stdout even if logger is broken."""
    print(f"[STARTUP] {label}", flush=True)
    logger.info("[STARTUP] %s", label)

try:
    _startup_step("1/12 Importing FastAPI + stdlib...")
    from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends, Header
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.gzip import GZipMiddleware
    from fastapi.responses import FileResponse
    from pydantic import BaseModel, Field
    from typing import List, Dict, Any, Optional, Tuple, Union
    from datetime import datetime, timedelta, timezone
    from concurrent.futures import ThreadPoolExecutor
    from dotenv import load_dotenv

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    _startup_step("2/12 Importing API routers...")
    from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
    from api.sql_query_api import router as sql_router, set_sql_dependencies
    from api.reports_api import router as reports_router, set_report_dependencies, set_reports_auth
    from api.schedules_api import router as schedules_router, set_schedule_dependencies, set_schedules_auth
    from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
    load_dotenv()

    _startup_step("3/12 Importing parquet_engine_v2...")
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType, AggregationConfig

    _startup_step("4/12 Importing s3_storage...")
    from core.s3_storage import S3Config, build_s3_config, TokenExpiredError

    _startup_step("5/12 Importing database...")
    from core.database import DatabaseManager

    _startup_step("6/12 Importing websocket + connection manager...")
    from core.websocket_manager import WebSocketManager
    from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES

    _startup_step("7/12 Loading config...")
    from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg

    _startup_step("8/12 Creating data directories...")
    _paths.data_dir.mkdir(parents=True, exist_ok=True)
    _paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _paths.upload_dir.mkdir(parents=True, exist_ok=True)

    _startup_step("9/12 Creating FastAPI app...")
    _DATA_DIR = _paths.data_dir
    _DB_URL   = _db_cfg.db_url

    _startup_step("10/12 Importing slowapi (rate limiter)...")
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded

    _startup_step("11/12 Importing prometheus_client...")
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

    _startup_step("12/12 All imports OK")

except Exception:
    print("[STARTUP] FATAL ERROR during startup:", flush=True)
    traceback.print_exc()
    traceback.print_exc(file=sys.stderr)
    logger.critical("FATAL: Startup failed", exc_info=True)
    sys.exit(1)

import re as _re
import atexit as _atexit

# Register atexit handler — catches silent process exits (e.g. DLL load failure, C-level crash)
def _atexit_handler():
    print("[ATEXIT] Backend process exiting", flush=True)
    logger.warning("[ATEXIT] Backend process exiting — check above for errors")
_atexit.register(_atexit_handler)

# Initialize FastAPI app
app = FastAPI(
    title="QueryStudio API",
    description="Enterprise-grade query engine — S3, Iceberg, Snowflake, Trino, Databricks",
    version="2.0.0"
)

# GZip compression (~70% payload reduction for JSON responses)
app.add_middleware(GZipMiddleware, minimum_size=1024)

# CORS middleware — origins/methods/headers driven by config.json / env vars
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_cfg.allow_origins,
    allow_credentials=True,
    allow_methods=_cors_cfg.allow_methods,
    allow_headers=_cors_cfg.allow_headers,
)

# Rate limiter setup
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

_prom_requests_total = Counter(
    "http_requests_total", "Total HTTP requests",
    ["method", "path_template", "status"],
)
_prom_request_duration = Histogram(
    "http_request_duration_seconds", "Request latency",
    ["method", "path_template"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30],
)
_prom_pool_active = Gauge("worker_pool_active_tasks", "Active tasks by type", ["work_type"])
_prom_pool_queued = Gauge("worker_pool_queued_tasks", "Queued tasks by type", ["work_type"])
_prom_websockets = Gauge("active_websocket_connections", "Active WebSocket connections")

# Collapse UUIDs / numeric IDs in paths to prevent metric cardinality explosion
_UUID_RE = _re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", _re.I)
_NUMERIC_ID_RE = _re.compile(r"/\d+(?=/|$)")

def _normalize_metric_path(path: str) -> str:
    """Collapse /api/queries/abc-123-... → /api/queries/{id}"""
    path = _UUID_RE.sub("{id}", path)
    path = _NUMERIC_ID_RE.sub("/{id}", path)
    return path


# ── Middleware: security headers + request logging + Prometheus + origin check ─
@app.middleware("http")
async def _enterprise_middleware(request: Request, call_next):
    start = _time.time()
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])

    # ── Origin check (CSRF defense-in-depth) ──
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        origin = request.headers.get("origin") or request.headers.get("referer", "")
        allowed = _cors_cfg.allow_origins
        if allowed != ["*"] and origin:
            from urllib.parse import urlparse
            origin_host = urlparse(origin).netloc
            if origin_host and not any(origin_host in ao for ao in allowed):
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=403, content={"detail": "Origin not allowed"})

    try:
        response = await call_next(request)
    except BaseException as exc:
        # GLOBAL SAFETY NET — no endpoint crash should ever kill the backend.
        # Log the full traceback and return 500 instead of letting it propagate.
        duration_s = _time.time() - start
        logger.critical("Unhandled crash in %s %s: %s", request.method, request.url.path, exc, exc_info=True)
        from starlette.responses import JSONResponse as _JSONResp
        return _JSONResp(status_code=500, content={"detail": f"Internal server error: {type(exc).__name__}"})
    duration_s = _time.time() - start

    # ── Security headers ──
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "connect-src 'self' ws: wss:; "
        "font-src 'self' data:; "
        "object-src 'none'; "
        "frame-ancestors 'self'"
    )
    response.headers["X-Request-ID"] = request_id

    # ── Request logging (structured JSON or text) ──
    path = request.url.path
    if path not in ("/health", "/metrics"):  # skip noisy health/metric polls
        logger.info("request", extra={
            "request_id": request_id,
            "method": request.method,
            "path": path,
            "status": response.status_code,
            "duration_ms": round(duration_s * 1000, 1),
            "client": request.client.host if request.client else None,
        })

    # ── Prometheus metrics ──
    path_tmpl = _normalize_metric_path(path)
    _prom_requests_total.labels(
        method=request.method, path_template=path_tmpl, status=response.status_code,
    ).inc()
    _prom_request_duration.labels(
        method=request.method, path_template=path_tmpl,
    ).observe(duration_s)

    return response


# Thread pool for CPU-bound query execution
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)
app.include_router(data_grid_router)
app.include_router(sql_router)
app.include_router(reports_router)
app.include_router(schedules_router)
app.include_router(dashboards_router)

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        auth_mode=os.getenv('S3_AUTH_MODE', 'keys'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        aws_profile=os.getenv('AWS_PROFILE'),
        role_arn=os.getenv('AWS_ROLE_ARN'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL'),
        ssl_verify=os.getenv('S3_SSL_VERIFY', 'true').lower() != 'false',
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# Per-execution cancellation registry
import threading as _threading
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency tracking
_user_query_counts: dict = {}    # username → int (active query count)
_user_query_lock = _threading.Lock()

# Global concurrency gate — asyncio.Semaphore limits system-wide active queries.
# Queries exceeding the semaphore wait in a FIFO queue (up to max_queue_size).
import asyncio as _asyncio
_global_query_sem: _asyncio.Semaphore | None = None   # initialised at startup
_global_queue_count = 0
_global_queue_lock = _threading.Lock()

def _init_query_semaphore():
    global _global_query_sem
    _global_query_sem = _asyncio.Semaphore(_qe_cfg.max_concurrent_global)

@app.on_event("startup")
async def _startup_init_semaphore():
    _init_query_semaphore()


# ── Active Directory / Auth helpers ───────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    password: str


# ── Server-side session store (in-memory, TTL-based) ─────────────────────────
# Stores opaque tokens → user info so that AD/LDAP passwords are NEVER persisted
# or sent after the initial login.

import secrets as _secrets
import time as _time

_SESSION_TTL = 8 * 60 * 60  # 8 hours (matches frontend SESSION_TTL_MS)
_sessions: dict[str, dict] = {}  # token → {"user": dict, "expires": float}


def _create_session(user_info: dict) -> str:
    """Create a session token and store user info server-side."""
    _prune_sessions()
    token = _secrets.token_urlsafe(48)
    _sessions[token] = {"user": user_info, "expires": _time.time() + _SESSION_TTL}
    return token


def _get_session(token: str) -> Optional[dict]:
    """Look up a session token. Returns user info or None if expired/missing."""
    entry = _sessions.get(token)
    if not entry:
        return None
    if _time.time() > entry["expires"]:
        _sessions.pop(token, None)
        return None
    return entry["user"]


def _destroy_session(token: str):
    """Remove a session token (logout)."""
    _sessions.pop(token, None)


def _prune_sessions():
    """Remove expired sessions (called on each new login to prevent memory leak)."""
    now = _time.time()
    expired = [t for t, e in _sessions.items() if now > e["expires"]]
    for t in expired:
        del _sessions[t]


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none"  → always returns a guest admin (no login required)
    - "Bearer <session_token>" → look up server-side session (preferred)
    - "Basic <base64>" → authenticate directly (fallback / backward compat)
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True,
                "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Prefer session tokens — no password stored or transmitted after login
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        user = _get_session(token)
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Fallback: Basic auth (used by legacy clients / API testing)
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _require_admin(user: dict = Depends(_get_current_user)) -> dict:
    """FastAPI dependency that enforces admin access on admin endpoints."""
    if _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def _require_role(*allowed_roles: str):
    """Factory: returns a FastAPI dependency that checks user role."""
    def dep(user: dict = Depends(_get_current_user)) -> dict:
        if _auth_cfg.type == "none":
            return user  # dev mode — no restriction
        role = (user or {}).get("role", "viewer")
        if role not in allowed_roles:
            raise HTTPException(403, f"Requires role: {', '.join(allowed_roles)}")
        return user
    return dep


def _require_execute_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    _user: Optional[dict] = Depends(_get_current_user),
) -> dict:
    """Dependency for execute_query: allows access via normal auth OR a valid share token.

    Used on /api/queries/execute so that shared-URL pages can execute queries
    without requiring the viewer to be logged in.
    """
    if _auth_cfg.type == "none":
        return _user or {"username": "guest", "role": "admin", "is_admin": True}
    # Authenticated user with proper role
    if _user and _user.get("role") in ("admin", "analyst"):
        return _user
    # Share-token alternative — lets SharedQueryPage & SharedDashboardPage execute
    if x_share_token:
        try:
            # Check query share token first, then dashboard share token
            share = db_manager.get_share_by_token(x_share_token)
            if not share:
                share = db_manager.get_dashboard_share_by_token(x_share_token)
            if share and share.get("is_active"):
                return {
                    "username": f"shared:{x_share_token[:8]}",
                    "role": "analyst",
                    "is_admin": False,
                }
        except Exception:
            pass
    raise HTTPException(status_code=403, detail="Authorization header required")


def _is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if the user owns this item or it's marked as shared."""
    if not user or user.get("is_admin"):
        return True  # admins see everything
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )


@app.post("/auth/login")
@limiter.limit("10/minute")
async def login(request: Request, req: _LoginRequest):
    """
    Authenticate and return a session token + user info.
    Password is verified once, then discarded — only the opaque token is stored.
    """
    from core.ad_auth import authenticate_user
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = _create_session(user)
    return {**user, "session_token": token}


@app.post("/auth/logout")
@limiter.limit("10/minute")
async def logout_endpoint(request: Request):
    """Destroy the server-side session."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        _destroy_session(auth_header[7:])
    return {"message": "Logged out"}


@app.get("/auth/me")
async def whoami(request: Request):
    """Return the current user's identity (or guest when auth is disabled)."""
    return _get_current_user(request)


@app.get("/auth/config")
async def auth_config():
    """Return auth configuration visible to the frontend (type only — no secrets)."""
    return {"type": _auth_cfg.type, "domain": _auth_cfg.ad_domain}


# Pydantic Models
class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None


_ALL_CONN_TYPES = "^(s3|local|trino|starburst|snowflake|databricks|oracle)$"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# Helper functions
# build_s3_config is imported from core.s3_storage — single source of truth


def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how,
                right_column_aliases=j.right_column_aliases or {},
            )
            for j in config.joins
        ]
    
    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]
    
    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]
    
    aggregations = None
    if config.aggregations:
        aggregations = [
            AggregationConfig(column=a.column, function=a.function.upper(),
                              alias=a.alias, distinct=a.distinct)
            for a in config.aggregations
        ]

    having = None
    if config.having:
        having = [{"column": h.column, "function": h.function.upper(),
                   "operator": h.operator, "value": h.value}
                  for h in config.having]

    computed_columns = None
    if config.computed_columns:
        computed_columns = [{"expression": c.expression, "alias": c.alias}
                           for c in config.computed_columns]

    case_expressions = None
    if config.case_expressions:
        case_expressions = [
            {"when_clauses": [{"when_column": w.when_column, "when_operator": w.when_operator,
                               "when_value": w.when_value, "then_value": w.then_value}
                              for w in ce.when_clauses],
             "else_value": ce.else_value, "alias": ce.alias}
            for ce in config.case_expressions
        ]

    window_functions = None
    if config.window_functions:
        window_functions = [
            {"function": wf.function.upper(), "alias": wf.alias,
             "column": wf.column,
             "partition_by": wf.partition_by,
             "order_by": [{"column": o.column, "direction": o.direction}
                          for o in wf.order_by] if wf.order_by else None,
             "offset": wf.offset, "default_value": wf.default_value}
            for wf in config.window_functions
        ]

    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by,
        group_by=config.group_by,
        aggregations=aggregations,
        distinct=config.distinct,
        having=having,
        filter_logic=config.filter_logic.upper(),
        computed_columns=computed_columns,
        case_expressions=case_expressions,
        column_aliases=config.column_aliases,
        window_functions=window_functions,
    )


# ── Iceberg data-file cache ──────────────────────────────────────────────────
# Avoids re-scanning manifests when the same table + partition filters are
# queried multiple times within a short window.
# Key: (connection_id, table_name, filters_hash)  →  (active_files, metadata, ts)
_ICE_FILE_CACHE: Dict[tuple, dict] = {}
_ICE_FILE_CACHE_TTL = 300  # 5 minutes

def _ice_cache_key(connection_id, tname, partition_filters):
    import json as _json
    pf_str = _json.dumps(partition_filters, sort_keys=True, default=str) if partition_filters else ""
    return (connection_id, tname, pf_str)

def _ice_cache_get(key):
    entry = _ICE_FILE_CACHE.get(key)
    if entry and (_time.monotonic() - entry["ts"]) < _ICE_FILE_CACHE_TTL:
        return entry
    if entry:
        del _ICE_FILE_CACHE[key]
    return None

def _ice_cache_set(key, active_files, metadata):
    _ICE_FILE_CACHE[key] = {"files": active_files, "metadata": metadata, "ts": _time.monotonic()}
    # Evict stale entries (max 200)
    if len(_ICE_FILE_CACHE) > 200:
        now = _time.monotonic()
        stale = [k for k, v in _ICE_FILE_CACHE.items() if now - v["ts"] > _ICE_FILE_CACHE_TTL]
        for k in stale:
            _ICE_FILE_CACHE.pop(k, None)


class _SQLCollector:
    """Fake DuckDB connection that records SQL instead of executing it.

    Used by _setup_registered_views(con=collector) to capture CREATE VIEW
    statements so they can be replayed in a crash-isolated subprocess.
    """
    def __init__(self):
        self.statements: list[str] = []

    def execute(self, sql: str):
        self.statements.append(sql)

    def close(self):
        pass


def _setup_registered_views(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
    con=None,
):
    """Set up DuckDB views for registered S3 tables and build query SQL.

    If *con* is provided (e.g. a _SQLCollector), it is used instead of
    creating a real DuckDB connection — this lets callers capture the
    generated SQL without touching DuckDB.

    Resolves __registered__:table_name → DuckDB views backed by:
      - Iceberg: read Iceberg manifests → read_parquet([active files])
      - Parquet: read_parquet('s3://bucket/prefix/**/*.parquet')
      - CSV: read_csv_auto('s3://bucket/prefix/**/*.csv')

    Returns (con, sql, auto_partition_info).
    Caller MUST close con in a finally block.
    """
    import duckdb as _ddb
    from api.data_grid_api import _duckdb_con_with_s3

    # Resolve table names from files
    table_map = {}  # name → table_def
    for t in registered_tables:
        table_map[t["name"]] = t

    # Collect ALL table references: primary files + join right_files
    _all_refs = list(query_config.files)
    if query_config.joins:
        for jc in query_config.joins:
            rf = jc.right_file if isinstance(jc.right_file, str) else jc.right_file.path
            if rf not in _all_refs:
                _all_refs.append(rf)

    resolved_names = []
    for f in _all_refs:
        fstr = f if isinstance(f, str) else f.path
        if fstr.startswith("__registered__:"):
            resolved_names.append(fstr.replace("__registered__:", ""))
        else:
            resolved_names.append(fstr)

    _step_t0 = _time.monotonic()

    def _log(msg: str, reset_timer: bool = True):
        nonlocal _step_t0
        elapsed = _time.monotonic() - _step_t0
        timed_msg = f"{msg} [{elapsed:.1f}s]" if elapsed > 0.1 else msg
        if progress_fn:
            progress_fn({"status": "processing", "log": timed_msg})
        logger.info(timed_msg)
        if reset_timer:
            _step_t0 = _time.monotonic()

    # Create DuckDB connection with S3 creds and register views
    _con_provided = con is not None
    if not _con_provided:
        _log("Connecting to S3 with DuckDB...")
        con = _duckdb_con_with_s3(conn_config, connection_id=connection_id)

    _auto_partition_applied = None

    for tname in resolved_names:
        tdef = table_map.get(tname)
        if not tdef:
            raise ValueError(
                f"Registered table '{tname}' not found. "
                f"Available tables: {', '.join(table_map.keys()) or '(none)'}"
            )
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        safe_name = tname.replace('"', '""')

        def _esc_sql(v: str) -> str:
            return v.replace("'", "''")

        if fmt == "iceberg":
            from core.iceberg_reader import (
                get_iceberg_data_files, get_latest_partition_value,
                _extract_partition_spec, _latest_metadata_key, _read_s3_json,
            )
            s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})

            # Convert query filters → Iceberg partition filters for manifest pruning
            partition_filters = None
            if query_config.filters:
                _OP_MAP = {
                    "equals": "equals", "eq": "equals", "=": "equals",
                    "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
                    "greater_than": "greater_than", "gt": "greater_than", ">": "greater_than",
                    "less_than": "less_than", "lt": "less_than", "<": "less_than",
                    "greater_equals": "greater_equals", "gte": "greater_equals", ">=": "greater_equals",
                    "less_equals": "less_equals", "lte": "less_equals", "<=": "less_equals",
                }
                partition_filters = []
                for flt in query_config.filters:
                    f_op = flt["operator"] if isinstance(flt, dict) else flt.operator
                    f_col = flt["column"] if isinstance(flt, dict) else flt.column
                    f_val = flt["value"] if isinstance(flt, dict) else flt.value
                    if f_op == "in" and isinstance(f_val, list) and len(f_val) > 0:
                        partition_filters.append({"col": f_col, "op": "in", "val": f_val})
                        continue
                    mapped_op = _OP_MAP.get(f_op)
                    if mapped_op and f_val is not None:
                        partition_filters.append({"col": f_col, "op": mapped_op, "val": f_val})
                if not partition_filters:
                    partition_filters = None

            # ── Check data-file cache BEFORE reading metadata ─────────
            _cache_key = _ice_cache_key(connection_id, tname, partition_filters)
            _cached = _ice_cache_get(_cache_key)
            if _cached:
                active_files = _cached["files"]
                _metadata = _cached["metadata"]
                _log(f"'{tname}': using cached file list ({len(active_files)} files, cache hit)")
            else:
                _log(f"Reading Iceberg metadata for '{tname}'...")

                # ── Read metadata ONCE — reused for partition spec, auto-partition, and data files
                _meta_prefix = tdef["s3_prefix"].rstrip("/") + "/metadata/"
                _meta_key = _latest_metadata_key(s3_client, bucket, _meta_prefix)
                _metadata = _read_s3_json(s3_client, bucket, _meta_key)

                # ── Auto-select latest partition when none specified ──────
                # Read partition spec to get column types
                _partition_col_types: Dict[str, str] = {}
                try:
                    _partition_col_types = _extract_partition_spec(_metadata)
                    _schemas = _metadata.get("schemas") or ([_metadata["schema"]] if "schema" in _metadata else [])
                    _field_id_to_name = {}
                    for _sch in _schemas:
                        for _sf in _sch.get("fields", []):
                            _fid = _sf.get("id") or _sf.get("field-id")
                            if _fid is not None:
                                _field_id_to_name[_fid] = _sf.get("name", "")
                    _specs = _metadata.get("partition-specs") or ([_metadata["partition-spec"]] if "partition-spec" in _metadata else [])
                    _def_spec_id = _metadata.get("default-spec-id", 0)
                    _active_spec = next((s for s in _specs if s.get("spec-id") == _def_spec_id), _specs[0] if _specs else {})
                    for _pf in _active_spec.get("fields", []):
                        _src_id = _pf.get("source-id") or _pf.get("source_id")
                        _src_name = _field_id_to_name.get(_src_id, "")
                        _pname = _pf.get("name", "")
                        if _pname in _partition_col_types and _src_name:
                            _partition_col_types[_src_name] = _partition_col_types[_pname]
                except Exception as _pe:
                    logger.warning("Could not read partition spec for type casting: %s", _pe)

                _has_partition_filter = False
                if query_config.filters:
                    _all_partition_names = set(_partition_col_types.keys())
                    _all_partition_names_lower = {n.lower() for n in _all_partition_names}
                    for _flt in query_config.filters:
                        _fc = _flt["column"] if isinstance(_flt, dict) else _flt.column
                        if _fc in _all_partition_names or _fc.lower() in _all_partition_names_lower:
                            _has_partition_filter = True
                            break

                if not _has_partition_filter and _partition_col_types:
                    try:
                        _latest = get_latest_partition_value(
                            s3_client, bucket, tdef["s3_prefix"], metadata=_metadata)
                        if _latest:
                            if partition_filters is None:
                                partition_filters = []
                            if query_config.filters is None:
                                query_config.filters = []
                            for _lp_col, _lp_val in _latest.items():
                                partition_filters.append({
                                    "col": _lp_col, "op": "equals", "val": _lp_val,
                                })
                                query_config.filters.append({
                                    "column": _lp_col, "operator": "eq", "value": _lp_val,
                                })
                            _auto_partition_applied = _latest
                            _log(f"Auto-selected latest partition: {', '.join(f'{k}={v}' for k, v in _latest.items())}")
                            # Recompute cache key with auto-partition filters
                            _cache_key = _ice_cache_key(connection_id, tname, partition_filters)
                            _cached = _ice_cache_get(_cache_key)
                            if _cached:
                                active_files = _cached["files"]
                                _log(f"'{tname}': using cached file list ({len(active_files)} files, cache hit after auto-partition)")
                    except Exception as _lpe:
                        logger.warning("Could not determine latest partition for '%s': %s", tname, _lpe)

                # Only scan manifests if we didn't get a cache hit
                if not _cached:
                    if partition_filters:
                        _pf_desc = ", ".join(f"{pf['col']}={pf['val']}" if pf['op'] == 'equals'
                                             else f"{pf['col']} {pf['op']} {pf['val']}"
                                             for pf in partition_filters)
                        _log(f"Scanning manifests for '{tname}' (filters: {_pf_desc})...")
                    else:
                        _log(f"Scanning manifests for '{tname}' (no partition filter — full scan)...")
                    data_file_entries = get_iceberg_data_files(
                        s3_client, bucket, tdef["s3_prefix"],
                        partition_filters=partition_filters,
                        keys_only=True,
                        metadata=_metadata,
                    )
                    active_files = [f"s3://{bucket}/{df['key']}" for df in data_file_entries]
                    # Cache the result for subsequent queries
                    _ice_cache_set(_cache_key, active_files, _metadata)
            if not active_files:
                # No files match the partition combination — create an empty view
                # so the query returns 0 rows instead of raising an error.
                _log(f"'{tname}': 0 data files match the selected partition combination — query will return empty result")
                # Use the first parquet file from a full scan to get the schema,
                # then add WHERE FALSE to produce 0 rows.
                _all_files = get_iceberg_data_files(
                    s3_client, bucket, tdef["s3_prefix"],
                    partition_filters=None, keys_only=True, max_files=1,
                    metadata=_metadata,
                )
                if _all_files:
                    _schema_file = f"s3://{bucket}/{_all_files[0]['key']}"
                    con.execute(
                        f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet(\'{_esc_sql(_schema_file)}\', '
                        f'hive_partitioning=true) WHERE FALSE'
                    )
                else:
                    raise ValueError(f"No active data files found for Iceberg table '{tname}'")
            else:
                paths_sql = ", ".join(f"'{_esc_sql(p)}'" for p in active_files)
                _log(f"'{tname}': scanning {len(active_files)} data files")
                _view_sql = (
                    f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet([{paths_sql}], '
                    f'hive_partitioning=true, union_by_name=true)'
                )
                con.execute(_view_sql)

        elif fmt == "csv":
            uri = f"s3://{_esc_sql(bucket)}/{_esc_sql(prefix)}/**/*.csv"
            con.execute(f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_csv_auto(\'{uri}\')')
        else:  # parquet
            uri = f"s3://{_esc_sql(bucket)}/{_esc_sql(prefix)}/**/*.parquet"
            con.execute(
                f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet(\'{uri}\', '
                f'hive_partitioning=true)'
            )
        _log(f"Registered DuckDB view '{tname}' (format={fmt})")

    # ── Cast date/timestamp filter values for SQL (AFTER all views are registered
    #    so partition pruning uses raw values, not SQL-cast literals) ──────────
    import re as _re
    _DATE_RE = _re.compile(r"^\d{4}-\d{2}-\d{2}$")
    _TS_RE   = _re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}")
    _ALREADY_CAST = _re.compile(
        r"^(DATE|TIMESTAMP|TIME|INTERVAL)\s+'", _re.IGNORECASE)

    def _auto_cast(v: str) -> str:
        if _ALREADY_CAST.match(v):
            return v
        if _DATE_RE.match(v):
            return f"DATE '{v}'"
        if _TS_RE.match(v):
            return f"TIMESTAMP '{v}'"
        return v

    if query_config.filters:
        for flt in query_config.filters:
            if isinstance(flt, dict):
                val = flt.get("value")
            else:
                val = flt.value
            if val is None:
                continue
            if isinstance(val, str):
                new_val = _auto_cast(val)
                if new_val != val:
                    if isinstance(flt, dict): flt["value"] = new_val
                    else: flt.value = new_val
                    f_col = flt["column"] if isinstance(flt, dict) else flt.column
                    logger.info("Cast filter: %s  %s → %s", f_col, val, new_val)
            elif isinstance(val, list):
                cast_vals = [_auto_cast(v) if isinstance(v, str) else v for v in val]
                if cast_vals != list(val):
                    if isinstance(flt, dict): flt["value"] = cast_vals
                    else: flt.value = cast_vals

    # ── Deduplicate filters (joins can cause same partition filter from both tables) ─
    if query_config.filters:
        _seen_filters = set()
        _deduped = []
        for flt in query_config.filters:
            f_col = flt["column"] if isinstance(flt, dict) else flt.column
            f_op  = flt["operator"] if isinstance(flt, dict) else flt.operator
            f_val = flt.get("value") if isinstance(flt, dict) else flt.value
            _fkey = (f_col, f_op, str(f_val))
            if _fkey not in _seen_filters:
                _seen_filters.add(_fkey)
                _deduped.append(flt)
        if len(_deduped) < len(query_config.filters):
            logger.info("Deduplicated filters: %d → %d", len(query_config.filters), len(_deduped))
            query_config.filters = _deduped

    # Build FROM clause using view names
    def _q(n):
        return f'"{n}"'

    primary = resolved_names[0]
    if len(resolved_names) > 1 and not query_config.joins:
        union_parts = " UNION ALL ".join(f"SELECT * FROM {_q(n)}" for n in resolved_names)
        from_clause = f"({union_parts}) AS t0"
    else:
        from_clause = f"{_q(primary)} AS t0"

    if query_config.joins:
        for idx, jc in enumerate(query_config.joins, start=1):
            rt = jc.right_file if isinstance(jc.right_file, str) else jc.right_file.path
            if rt.startswith("__registered__:"):
                rt = rt.replace("__registered__:", "")
            alias = f"t{idx}"
            join_type = jc.how.upper()
            if join_type not in ("INNER", "LEFT", "RIGHT"):
                join_type = "FULL OUTER"
            on_parts = [
                f"t0.{_q(l)} = {alias}.{_q(r)}"
                for l, r in zip(jc.left_on, jc.right_on)
            ]
            from_clause += f"\n  {join_type} JOIN {_q(rt)} AS {alias} ON {' AND '.join(on_parts)}"

    # Build SQL using existing engine method
    sql = engine.build_query_sql(query_config, from_clause)
    _log("SQL built")
    logger.info("Registered table SQL:\n%s", sql)

    return con, sql, _auto_partition_applied


def _execute_registered_table_query(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
):
    """Execute a query against registered S3 tables, streaming results as Arrow tables."""
    import pyarrow as _pa

    con, sql, auto_part = _setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn)

    if auto_part:
        query_config._auto_partition = auto_part

    try:
        if progress_fn:
            progress_fn({"status": "processing", "log": "Executing SQL query on S3 data..."})

        _t0 = _time.monotonic()
        result = con.execute(sql)
        reader = result.fetch_record_batch(rows_per_batch=engine.chunk_size)
        total = 0
        for batch in reader:
            if len(batch) == 0:
                continue
            total += len(batch)
            elapsed = _time.monotonic() - _t0
            if progress_fn:
                progress_fn({"status": "processing",
                             "log": f"Streaming: {total:,} rows [{elapsed:.1f}s]"})
            yield _pa.Table.from_batches([batch])

        elapsed = _time.monotonic() - _t0
        if progress_fn:
            progress_fn({"status": "processing",
                         "log": f"Query returned {total:,} rows [{elapsed:.1f}s]"})
    finally:
        con.close()


def _execute_registered_table_copy_to(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    output_path: str,
    connection_id: int = None,
    progress_fn=None,
    cancel_event=None,
):
    """Execute registered table query using DuckDB COPY TO (fast path).

    Runs DuckDB in a **subprocess** for crash isolation — a C-level crash
    (access violation / segfault) in DuckDB only kills the child process,
    not the main backend.

    Falls back to in-process execution if subprocess mode fails for a
    non-crash reason (import error, etc.).
    """
    import pyarrow.parquet as _pq

    # ── Phase 1: Resolve files + build SQL (no DuckDB, safe) ──────────────
    collector = _SQLCollector()
    _, sql, auto_part = _setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn, con=collector)

    # Build COPY TO SQL
    kv_meta = {}
    if auto_part:
        kv_meta["auto_partition"] = json.dumps(auto_part)
    kv_clause = ""
    if kv_meta:
        kv_pairs = ", ".join(f"'{k}': '{v}'" for k, v in kv_meta.items())
        kv_clause = f", KV_METADATA {{{kv_pairs}}}"

    safe_path = output_path.replace("\\", "/")
    copy_sql = (
        f"COPY ({sql}) TO '{safe_path}' "
        f"(FORMAT PARQUET, COMPRESSION ZSTD{kv_clause})"
    )

    setup_sql = ";\n".join(collector.statements)
    logger.info("COPY TO setup SQL (%d statements):\n%s", len(collector.statements), setup_sql[:2000])
    logger.info("COPY TO SQL:\n%s", copy_sql)

    # ── Execute in subprocess (crash-isolated) ────────────────────────────
    from core.duckdb_subprocess import run_duckdb_copy_to
    if progress_fn:
        progress_fn({"status": "processing", "log": "Querying S3 via subprocess (crash-isolated)…"})
    result = run_duckdb_copy_to(
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql,
        copy_sql=copy_sql,
        output_path=output_path,
        connection_id=connection_id,
        timeout=600,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]

    # Write auto_partition to Parquet KV metadata (subprocess may not support KV_METADATA)
    if auto_part and os.path.exists(output_path):
        try:
            meta = _pq.read_metadata(output_path)
            if not meta.metadata or b"auto_partition" not in (meta.metadata or {}):
                # Re-read, add metadata, re-write header
                tbl = _pq.read_table(output_path)
                existing = tbl.schema.metadata or {}
                existing[b"auto_partition"] = json.dumps(auto_part).encode()
                tbl = tbl.replace_schema_metadata(existing)
                _pq.write_table(tbl, output_path, compression="ZSTD")
                total_rows = len(tbl)
                file_size = os.path.getsize(output_path)
        except Exception as _meta_exc:
            logger.warning("Could not embed auto_partition metadata: %s", _meta_exc)

    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"COPY TO complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "status": "completed",
        "chunks_processed": 1,
    }



async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest",
                                  raw_sql: Optional[str] = None):
    """Background task for query execution"""
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    _pool = get_pool()
    run_engine = active_engine or engine

    try:
        
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            if is_terminal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0

            # Registered table path: resolve __registered__: → DuckDB views
            def _any_reg(flist):
                return any(
                    (f if isinstance(f, str) else f.path).startswith("__registered__:")
                    for f in (flist or [])
                )
            _join_right = [j.right_file for j in (query_config.joins or [])] if query_config.joins else []
            _has_reg = (run_engine._registered_tables and run_engine._s3_conn_config) and (
                _any_reg(query_config.files) or _any_reg(_join_right)
            )

            # ── COPY TO fast path — bypass Python/pandas entirely ──────────
            # DuckDB streams from S3 directly to local Parquet (3-10x faster).
            # Skip for UNC paths (DuckDB can't handle \\server\share\...).
            if _has_reg and not str(output_file).startswith("\\\\"):
                try:
                    stats = _execute_registered_table_copy_to(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        str(output_file),
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        cancel_event=cancel_event,
                    )
                    _sync_progress({"status": "completed",
                                    "total_rows": stats["total_rows"],
                                    "file_size_bytes": stats["file_size_bytes"]})
                    return stats
                except Exception as _copy_err:
                    # Don't fall back to in-process DuckDB — same crash risk.
                    # Let the error propagate so the execution fails cleanly.
                    raise RuntimeError(f"S3 query failed: {_copy_err}") from _copy_err

            # ── Streaming path (fallback for registered tables, default for others)
            pq_writer = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                if _has_reg:
                    _query_gen = _execute_registered_table_query(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                    )
                elif raw_sql:
                    if run_engine._s3_conn_config:
                        # ── Raw SQL + S3: subprocess-isolated COPY TO ──
                        fh.close()  # close file handle — subprocess writes directly
                        _setup_stmts = []
                        if run_engine._registered_tables:
                            _esc = lambda v: v.replace("'", "''")
                            _rt_bucket = run_engine._s3_bucket
                            for _rt in run_engine._registered_tables:
                                _rt_name = _rt["name"].replace('"', '""')
                                _rt_fmt = _rt.get("format", "parquet")
                                _rt_prefix = _rt["s3_prefix"].rstrip("/")
                                if _rt_fmt == "iceberg":
                                    try:
                                        from core.iceberg_reader import get_iceberg_data_files
                                        _rt_s3 = _make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                        _rt_files = get_iceberg_data_files(_rt_s3, _rt_bucket, _rt["s3_prefix"], keys_only=True)
                                        if _rt_files:
                                            _rt_paths = ", ".join(f"'s3://{_esc(_rt_bucket)}/{_esc(f['key'])}'" for f in _rt_files)
                                            _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet([{_rt_paths}], hive_partitioning=true, union_by_name=true)')
                                    except Exception as _rte:
                                        logger.warning("Could not register Iceberg view '%s' for raw SQL: %s", _rt_name, _rte, exc_info=True)
                                elif _rt_fmt == "parquet":
                                    _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true)')
                                elif _rt_fmt == "csv":
                                    _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.csv\')')
                        _safe_out = str(output_file).replace("'", "''").replace("\\", "/")
                        from core.duckdb_subprocess import run_duckdb_copy_to
                        _sync_progress({"status": "processing", "log": "Executing raw SQL via subprocess (crash-isolated)…"})
                        _sub_result = run_duckdb_copy_to(
                            conn_config=run_engine._s3_conn_config,
                            registered_tables=run_engine._registered_tables or [],
                            bucket=run_engine._s3_bucket or "",
                            setup_sql=";\n".join(_setup_stmts),
                            copy_sql=f"COPY ({raw_sql}) TO '{_safe_out}' (FORMAT PARQUET, COMPRESSION ZSTD)",
                            output_path=str(output_file),
                            connection_id=getattr(run_engine, '_s3_conn_id', None),
                            timeout=600,
                        )
                        total_rows = _sub_result["total_rows"]
                        file_size = _sub_result["file_size_bytes"]
                        _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                        return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                    else:
                        _query_gen = run_engine.execute_raw_duckdb_sql(raw_sql)
                elif run_engine._s3_conn_config:
                    # ── S3 non-registered files: subprocess-isolated COPY TO ──
                    fh.close()  # close file handle — subprocess writes directly
                    _s3_sql = run_engine.get_duckdb_sql(query_config)
                    _sync_progress({"status": "processing", "log": "Querying S3 via subprocess (crash-isolated)…"})
                    _safe_out = str(output_file).replace("'", "''").replace("\\", "/")
                    from core.duckdb_subprocess import run_duckdb_copy_to
                    _sub_result = run_duckdb_copy_to(
                        conn_config=run_engine._s3_conn_config,
                        registered_tables=[],
                        bucket=getattr(run_engine, '_s3_bucket', "") or "",
                        setup_sql="",
                        copy_sql=f"COPY ({_s3_sql}) TO '{_safe_out}' (FORMAT PARQUET, COMPRESSION ZSTD)",
                        output_path=str(output_file),
                        connection_id=getattr(run_engine, '_s3_conn_id', None),
                        timeout=600,
                    )
                    total_rows = _sub_result["total_rows"]
                    file_size = _sub_result["file_size_bytes"]
                    _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                    return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                elif run_engine._needs_duckdb(query_config):
                    _query_gen = run_engine.execute_duckdb_query(query_config)
                else:
                    _query_gen = run_engine.execute_query(query_config)
                # Detect wide-table auto-projection: when engine projected a
                # subset of columns, store the full list so the grid can offer
                # "Showing 50 of 937 columns — choose columns" UX.
                _all_source_cols = None
                if (not query_config.columns
                        and not query_config.aggregations
                        and query_config.files):
                    try:
                        _first = query_config.files[0]
                        _fp = _first if isinstance(_first, str) else _first.path
                        if not _fp.startswith("__registered__:") and hasattr(run_engine, 'get_file_schema'):
                            _sch = run_engine.get_file_schema(_fp)
                            _src_cols = [c["name"] for c in _sch.get("columns", [])]
                            if len(_src_cols) > 50:
                                _all_source_cols = _src_cols
                    except Exception as exc:
                        logger.warning("Recoverable error: %s", exc, exc_info=True)

                for chunk in _query_gen:
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    # Accept both pa.Table (from DuckDB streaming) and pd.DataFrame
                    if isinstance(chunk, _pa.Table):
                        table = chunk
                    else:
                        table = _pa.Table.from_pandas(chunk, preserve_index=False)
                    if pq_writer is None:
                        _sync_progress({"status": "processing", "log": f"Writing results ({len(table)} rows)..."})
                        # Embed all_columns metadata in Parquet file so the
                        # paginator can return it without extra lookups.
                        _pq_meta = table.schema.metadata or {}
                        if _all_source_cols is not None:
                            _pq_meta[b"all_columns"] = json.dumps(_all_source_cols).encode()
                        # Embed auto-partition info so frontend can show indicator
                        _auto_part = getattr(query_config, '_auto_partition', None)
                        if _auto_part:
                            _pq_meta[b"auto_partition"] = json.dumps(_auto_part).encode()
                        # Use replace_schema_metadata on the table itself so
                        # writer schema and table schema are identical.
                        table = table.replace_schema_metadata(_pq_meta)
                        _writer_schema = table.schema
                        pq_writer = _pq.ParquetWriter(fh, _writer_schema, compression="zstd")
                    else:
                        # Subsequent chunks may have a different schema (e.g.
                        # multi-file streaming with schema evolution).  Cast
                        # to the writer's schema so the write doesn't fail.
                        if table.schema != _writer_schema:
                            try:
                                table = table.cast(_writer_schema)
                            except Exception:
                                # If cast fails, unify: add missing cols as null,
                                # drop extra cols, reorder to match writer.
                                for field in _writer_schema:
                                    if field.name not in table.column_names:
                                        table = table.append_column(
                                            field, _pa.nulls(len(table), type=field.type))
                                table = table.select([f.name for f in _writer_schema])
                    pq_writer.write_table(table)
                    total_rows += len(table)
                    chunks_processed += 1
            finally:
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # Ensure an empty file exists for 0-row results so downstream
                # readers don't get a FileNotFoundError.
                if total_rows == 0 and not output_file.exists():
                    output_file.touch()
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_to_parquet,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({
                "type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — no file copy, cache points to same parquet
        try:
            from core.query_cache import make_cache_key, store_result
            _ck = make_cache_key(query_config.__dict__ if hasattr(query_config, '__dict__') else {})
            if output_file.exists():
                store_result(_ck, output_file, {}, row_count=stats.get("total_rows", 0), copy=False)
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        logger.info(f"Query execution completed: {execution_id}")
        
    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}", exc_info=True)

        _err_code = "TOKEN_EXPIRED" if isinstance(e, TokenExpiredError) else None
        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass

        ws_msg = {
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if _err_code:
            ws_msg["error_code"] = _err_code
        await ws_manager.broadcast(ws_msg)

    finally:
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_sql_connector_background(
    execution_id: str,
    connector,          # SqlConnector instance (already constructed)
    sql: str,           # complete SQL built by engine.build_query_sql()
    query_id: Optional[int] = None,
    executed_by: str = "guest",
):
    """Execute a query against a SQL connector (Trino/Starburst/Snowflake/Databricks/Oracle).
    Mirrors the structure of execute_query_background so the frontend receives
    the same WebSocket messages and can download results the same way.
    """
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        def _exec_sql(cancel_event=None):
            try:
                logger.info(f"SQL connector query [{execution_id}]:\n{sql}")
                result = connector.execute_query(sql)
                # result = {"columns": [{"name":..,"type":..}], "rows": [...], "total_rows": int}
                rows    = result.get("rows", [])
                col_defs = result.get("columns", [])
                col_names = [c["name"] for c in col_defs]
                df = _pd.DataFrame(rows, columns=col_names) if rows else _pd.DataFrame(columns=col_names)
                total_rows = len(df)
                output_file.parent.mkdir(parents=True, exist_ok=True)
                if total_rows > 0:
                    table = _pa.Table.from_pandas(df, preserve_index=False)
                    with open(str(output_file), "wb") as fh:
                        _pq.ParquetWriter(fh, table.schema, compression="zstd").write_table(table)
                else:
                    output_file.touch()
                file_size = output_file.stat().st_size
                return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
            finally:
                try:
                    connector.close()
                except Exception as exc:
                    logger.warning("Recoverable error: %s", exc, exc_info=True)

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_sql,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )
        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        if query_id:
            db_manager.increment_execution_count(query_id)
        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"SQL connector query completed: {execution_id} ({stats.get('total_rows',0)} rows)")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"SQL connector query cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled", error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({"type": "execution_cancelled", "execution_id": execution_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat()})
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"SQL connector query failed {execution_id}: {e}", exc_info=True)
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                                    "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()})
    finally:
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_cross_query_background(
    execution_id: str,
    primary_engine,
    primary_config: QueryConfig,
    secondary_engine,
    secondary_config: QueryConfig,
    combine_mode: str,
    join_config: Optional[dict],
    query_id: Optional[int] = None,
    executed_by: str = "guest",
):
    """Background task for cross-connection (multi-source) query execution."""
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        async def _progress(data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            if data.get("status") in ("completed", "failed"):
                db_manager.update_execution(
                    execution_id,
                    status=data["status"],
                    total_rows=data.get("total_rows", 0),
                    chunks_processed=data.get("chunks_processed", 0),
                    output_file=str(output_file) if data.get("status") == "completed" else None,
                    file_size_bytes=data.get("file_size_bytes", 0),
                    error_message=data.get("error"),
                )

        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            if data.get("status") in ("completed", "failed") or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(_progress(data), loop)

        import pyarrow as _pa
        import pyarrow.parquet as _pq

        def _exec_cross(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)

            # ── Primary source ────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "primary",
                            "message": "Executing primary source query"})
            chunks_a = []
            for chunk in primary_engine.execute_query(primary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_a.append(chunk)
            df_a = _pd.concat(chunks_a, ignore_index=True) if chunks_a else _pd.DataFrame()

            # ── Secondary source ──────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "secondary",
                            "message": "Executing secondary source query"})
            chunks_b = []
            for chunk in secondary_engine.execute_query(secondary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_b.append(chunk)
            df_b = _pd.concat(chunks_b, ignore_index=True) if chunks_b else _pd.DataFrame()

            # ── Combine ───────────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "combining",
                            "message": f"Combining via {combine_mode.upper()}"})
            if combine_mode == "union":
                df_result = _pd.concat([df_a, df_b], ignore_index=True, sort=False)
            elif combine_mode == "join":
                if not join_config:
                    raise ValueError("join_config required for join mode")
                how = join_config.get("how", "inner")
                left_on = join_config.get("left_on")
                right_on = join_config.get("right_on")
                suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
                if isinstance(left_on, str): left_on = [left_on]
                if isinstance(right_on, str): right_on = [right_on]
                if not left_on or not right_on:
                    raise ValueError("join_config must specify left_on and right_on")
                df_result = _pd.merge(df_a, df_b, how=how,
                                      left_on=left_on, right_on=right_on,
                                      suffixes=suffixes)
            else:
                raise ValueError(f"Unknown combine_mode '{combine_mode}'")

            # ── Save parquet ──────────────────────────────────────────────────
            fh = open(str(output_file), "wb")
            try:
                table = _pa.Table.from_pandas(df_result, preserve_index=False)
                writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                writer.write_table(table)
                writer.close()
            finally:
                fh.close()
            if df_result.empty and not output_file.exists():
                output_file.touch()

            total_rows = len(df_result)
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows,
                            "file_size_bytes": file_size, "chunks_processed": 2})
            return {"total_rows": total_rows, "chunks_processed": 2,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_cross,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"cross_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        if query_id:
            db_manager.increment_execution_count(query_id)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "combine_mode": combine_mode,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"Cross-connection query completed: {execution_id} ({combine_mode})")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"Cross-connection query cancelled: {execution_id}")
        cur = db_manager.get_execution(execution_id)
        if cur and cur.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"Error in cross-connection query {execution_id}: {e}", exc_info=True)
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


# ── Audit helper ──────────────────────────────────────────────────────────────

def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        db_manager.audit(username, action, resource_type=resource_type,
                         resource_id=resource_id, ip_address=ip,
                         user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


# ── SPA static file serving ───────────────────────────────────────────────────
# Serve the built React frontend when the static/ dir exists next to main.py.
# In Docker: built by Dockerfile into ./static
# In local dev: build frontend with `npm run build` → output to ./static or ../frontend/build
# Falls back to a JSON root response when no built frontend is present.
_STATIC_CANDIDATES = [
    Path(__file__).resolve().parent / "static",          # Docker / production
    Path(__file__).resolve().parent.parent / "frontend" / "build",  # local dev
    Path(__file__).resolve().parent.parent / "frontend" / "dist",   # legacy Vite
]
_STATIC_DIR: Optional[Path] = next((p for p in _STATIC_CANDIDATES if p.is_dir()), None)

if _STATIC_DIR:
    from fastapi.staticfiles import StaticFiles
    # Mount /assets (hashed JS/CSS bundles) — short cache for CDN
    _assets = _STATIC_DIR / "assets"
    if _assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")
    logger.info("Serving built frontend from %s", _STATIC_DIR)
else:
    logger.info("No built frontend found — API-only mode")


# ── Prometheus /metrics endpoint ──────────────────────────────────────────────
@app.get("/metrics", include_in_schema=False)
async def _prometheus_metrics():
    """Prometheus scrape endpoint — no auth required (standard practice)."""
    from starlette.responses import Response as _StarletteResponse
    # Update worker pool gauges before scrape
    try:
        from core.worker_pool import get_pool
        pool = get_pool()
        if pool:
            stats = pool.get_stats()
            for wtype, info in stats.get("by_type", {}).items():
                _prom_pool_active.labels(work_type=wtype).set(info.get("running", 0))
                _prom_pool_queued.labels(work_type=wtype).set(info.get("queued", 0))
    except Exception:
        pass  # metrics must never crash
    return _StarletteResponse(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/health")
async def health_check():
    """Health check — DB connectivity, disk space, active queries."""
    import shutil as _shutil

    # Database ping
    db_ok = False
    try:
        db_manager.get_execution("__health_probe__")   # returns None, never raises
        db_ok = True
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Disk usage for data directory
    try:
        _du = _shutil.disk_usage(str(_paths.data_dir))
        disk_free_gb  = round(_du.free  / (1024 ** 3), 2)
        disk_used_pct = round(_du.used  / _du.total * 100, 1)
        disk_warn     = disk_free_gb < 5.0
    except Exception:
        disk_free_gb = disk_used_pct = -1
        disk_warn = False

    # S3 connectivity (non-blocking, best-effort)
    s3_status = "not_configured"
    if engine.s3_handler:
        try:
            s3_status = "connected" if engine.s3_handler.test_connection().get("connected") else "error"
        except Exception:
            s3_status = "error"

    # Pool-aware query stats
    try:
        from core.worker_pool import get_pool
        _pool_stats = get_pool().get_stats()
        active_queries = _pool_stats.get("active_total", 0)
        queue_waiting = _pool_stats.get("queued_total", 0)
    except RuntimeError:
        active_queries = len([t for t in _running_tasks.values() if not t.done()])
        queue_waiting = _global_queue_count

    overall = "healthy" if db_ok and not disk_warn else "degraded"

    return {
        "status":    overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database":  {"ok": db_ok},
        "disk":      {"free_gb": disk_free_gb, "used_pct": disk_used_pct, "warning": disk_warn},
        "queries":   {"active": active_queries, "max_workers": _qe_cfg.max_workers,
                      "per_user_limit": _qe_cfg.max_concurrent_per_user,
                      "max_concurrent_global": _qe_cfg.max_concurrent_global,
                      "queue_waiting": queue_waiting,
                      "max_queue_size": _qe_cfg.max_queue_size},
        "s3":        {"status": s3_status},
    }


# ── Storage management endpoints ──────────────────────────────────────────────

def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest: oldest = mt
                    if newest is None or mt > newest: newest = mt
                except OSError as exc:
                    logger.debug("Recoverable error: %s", exc, exc_info=True)
    return {
        "path": str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb": round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


@app.get("/api/admin/storage")
async def get_storage_summary(_user: dict = Depends(_require_admin)):
    """Return per-directory disk usage and configured retention settings."""
    import shutil as _shutil
    dirs = {
        "downloads": _paths.downloads_dir,
        "cache":     _paths.data_dir / "cache",
        "parquet":   _paths.parquet_dir,
        "uploads":   _paths.data_dir / "uploads",
    }
    breakdown = {name: _dir_stats(Path(p)) for name, p in dirs.items()}

    try:
        du = _shutil.disk_usage(str(_paths.data_dir))
        disk = {
            "total_gb":   round(du.total / (1024 ** 3), 2),
            "used_gb":    round(du.used  / (1024 ** 3), 2),
            "free_gb":    round(du.free  / (1024 ** 3), 2),
            "used_pct":   round(du.used  / du.total * 100, 1),
        }
    except Exception:
        disk = {}

    from core.config import storage as _stg_cfg, scheduler as _sched_cfg
    return {
        "disk": disk,
        "directories": breakdown,
        "settings": {
            "downloads_expiry_days":    _stg_cfg.downloads_expiry_days,
            "execution_retention_days": _sched_cfg.execution_retention_days,
            "max_cache_size_mb":        _stg_cfg.max_cache_size_mb,
            "max_downloads_size_mb":    _stg_cfg.max_downloads_size_mb,
        },
        "tracked_downloads": db_manager.get_downloads_size_bytes() // (1024 * 1024),
    }


@app.post("/api/admin/storage/cleanup")
async def trigger_cleanup(_user: dict = Depends(_require_admin)):
    """Manually trigger all cleanup jobs immediately (admin action)."""
    from core.scheduler import _cleanup_temp_files, _enforce_storage_quotas, _cleanup_execution_history
    import concurrent.futures as _cf
    results = {}
    for name, fn in [
        ("temp_files",         _cleanup_temp_files),
        ("storage_quotas",     _enforce_storage_quotas),
        ("execution_history",  _cleanup_execution_history),
    ]:
        try:
            fn()
            results[name] = "ok"
        except Exception as exc:
            results[name] = str(exc)
    _audit(_user, "manual_storage_cleanup", None, details=results)
    logger.info("Manual storage cleanup triggered by %s: %s", (_user or {}).get("username", "guest"), results)
    return {"status": "completed", "results": results}


@app.get("/api/admin/active-queries")
async def get_active_queries(_user: dict = Depends(_require_admin)):
    """Return all currently running/pending executions with live duration and connection info.

    Source of truth is _running_tasks (in-memory), not DB status — the DB record
    may still show 'pending' while the background task is already executing.
    """
    from datetime import datetime, timezone as _tz
    now = datetime.now(_tz.utc)

    # 1. Live execution IDs — from pool + legacy globals.
    try:
        from core.worker_pool import get_pool
        _pool_tasks = get_pool().get_active_tasks()
        live_ids = {t["execution_id"] for t in _pool_tasks if t.get("execution_id")}
    except RuntimeError:
        live_ids = set()
    # Also check legacy globals (for anything not yet migrated)
    live_ids |= (
        {eid for eid, task in _running_tasks.items() if not task.done()} |
        set(_cancellation_flags.keys())
    )

    # 2. DB rows for pending/processing (catches tasks not yet in _running_tasks)
    db_rows: dict = {}
    for status in ("processing", "pending"):
        for r in db_manager.list_executions(limit=500, status=status):
            db_rows[r["execution_id"]] = r

    # 3. Fetch DB records for any live task not already captured above
    for eid in live_ids:
        if eid not in db_rows:
            r = db_manager.get_execution(eid)
            if r:
                db_rows[r["execution_id"]] = r
            else:
                # Task exists in memory but no DB record yet — synthesise a minimal row
                db_rows[eid] = {
                    "execution_id": eid,
                    "status": "processing",
                    "started_at": now.isoformat(),
                    "executed_by": None,
                    "chunks_processed": 0,
                    "query_config": {},
                }

    conn_cache: dict = {}
    def _conn_name(cid):
        if cid is None:
            return None
        if cid not in conn_cache:
            try:
                c = db_manager.get_connection_raw(cid)
                conn_cache[cid] = c.get("name", f"#{cid}") if c else f"#{cid}"
            except Exception:
                conn_cache[cid] = f"#{cid}"
        return conn_cache[cid]

    enriched = []
    for r in db_rows.values():
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_tz.utc)
                duration_s = int((now - dt).total_seconds())
            except Exception:
                duration_s = 0
        else:
            duration_s = 0

        qcfg    = r.get("query_config") or {}
        conn_id = qcfg.get("connection_id") or r.get("connection_id")

        enriched.append({
            **r,
            "duration_seconds": duration_s,
            "connection_name":  _conn_name(conn_id),
            "task_alive":       r["execution_id"] in live_ids,
        })

    enriched.sort(key=lambda x: x["duration_seconds"], reverse=True)
    return enriched


@app.get("/api/admin/user-stats")
async def get_user_stats(_user: dict = Depends(_require_admin)):
    """Per-user query activity: active now, completed today, last seen."""
    from datetime import datetime, timezone as _tz, timedelta
    today_start = datetime.now(_tz.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    # All executions from today
    all_today = db_manager.list_executions(limit=2000)
    user_map: dict = {}

    for r in all_today:
        u = r.get("executed_by") or "guest"
        if u not in user_map:
            user_map[u] = {"username": u, "queries_today": 0, "last_seen": None,
                           "active_now": 0, "failed_today": 0}
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_tz.utc)
                if dt >= today_start:
                    user_map[u]["queries_today"] += 1
                    if r.get("status") == "failed":
                        user_map[u]["failed_today"] += 1
                if user_map[u]["last_seen"] is None or started > user_map[u]["last_seen"]:
                    user_map[u]["last_seen"] = started
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Overlay live active counts
    with _user_query_lock:
        for uname, cnt in _user_query_counts.items():
            if uname not in user_map:
                user_map[uname] = {"username": uname, "queries_today": 0, "last_seen": None,
                                   "active_now": cnt, "failed_today": 0}
            else:
                user_map[uname]["active_now"] = cnt

    return sorted(user_map.values(), key=lambda x: x["active_now"], reverse=True)


@app.get("/api/admin/query-eta")
async def get_query_eta(connection_id: Optional[int] = None,
                        _user: dict = Depends(_get_current_user)):
    """Return estimated execution time (seconds) based on recent completed executions.
    Optionally scoped to a specific connection_id for a more accurate estimate.
    """
    try:
        from datetime import datetime, timezone as _tz
        recent = db_manager.list_executions(limit=200, status="completed")
        durations = []
        for r in recent:
            s = r.get("started_at")
            c = r.get("completed_at")
            if not s or not c:
                continue
            # Filter by connection if requested
            if connection_id is not None:
                qcfg = r.get("query_config") or {}
                if isinstance(qcfg, str):
                    try:
                        qcfg = json.loads(qcfg)
                    except Exception:
                        qcfg = {}
                if not isinstance(qcfg, dict):
                    continue
                # Compare as int — stored value may be str or int
                try:
                    if int(qcfg.get("connection_id", -1)) != int(connection_id):
                        continue
                except (ValueError, TypeError):
                    continue
            try:
                dt_s = datetime.fromisoformat(s)
                dt_c = datetime.fromisoformat(c)
                if dt_s.tzinfo is None: dt_s = dt_s.replace(tzinfo=_tz.utc)
                if dt_c.tzinfo is None: dt_c = dt_c.replace(tzinfo=_tz.utc)
                secs = (dt_c - dt_s).total_seconds()
                if 0 < secs < 3600:  # ignore outliers > 1hr
                    durations.append(secs)
            except Exception:
                continue
        if not durations:
            return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}
        durations.sort()
        p75_idx = int(len(durations) * 0.75)
        avg = sum(durations) / len(durations)
        p75 = durations[min(p75_idx, len(durations) - 1)]
        return {
            "avg_seconds":  round(avg, 1),
            "p75_seconds":  round(p75, 1),
            "min_seconds":  round(min(durations), 1),
            "max_seconds":  round(max(durations), 1),
            "sample_count": len(durations),
            "connection_id": connection_id,
        }
    except Exception as exc:
        logger.error("query-eta failed: %s", exc, exc_info=True)
        return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}


@app.delete("/api/admin/queries/{execution_id}")
async def admin_cancel_execution(execution_id: str, _user: dict = Depends(_require_admin)):
    """Admin-level cancel — no ownership check. Uses same cancel machinery."""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution.get("status") not in ("pending", "processing"):
            return {"execution_id": execution_id,
                    "message": f"Already {execution.get('status')}"}

        from core.worker_pool import get_pool
        try:
            get_pool().cancel_by_execution_id(execution_id)
        except RuntimeError:
            cancel_event = _cancellation_flags.get(execution_id)
            if cancel_event:
                cancel_event.set()
            task = _running_tasks.get(execution_id)
            if task and not task.done():
                task.cancel()

        cancelled_by = (_user or {}).get("username", "admin")
        db_manager.update_execution(execution_id, status="cancelled",
                                    error_message=f"Cancelled by admin: {cancelled_by}")
        await ws_manager.broadcast({
            "type":         "execution_cancelled",
            "execution_id": execution_id,
            "cancelled_by": cancelled_by,
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
        _audit(_user, "admin_cancel_query", None, "execution", execution_id,
               {"cancelled_user": execution.get("executed_by")})
        return {"execution_id": execution_id, "message": "Cancelled by admin"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Worker Pool admin endpoints ───────────────────────────────────────────

@app.get("/api/admin/worker-pool")
async def admin_worker_pool_stats(_user: dict = Depends(_require_admin)):
    """Pool stats: by-type counts, queue depth, avg wait/run times."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_stats()
    except RuntimeError:
        return {"error": "Worker pool not initialised"}


@app.get("/api/admin/worker-pool/tasks")
async def admin_worker_pool_tasks(
    work_type: Optional[str] = None,
    _user: dict = Depends(_require_admin),
):
    """All active tasks, optionally filtered by work type."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_active_tasks(wt)


@app.get("/api/admin/worker-pool/history")
async def admin_worker_pool_history(
    limit: int = 100,
    work_type: Optional[str] = None,
    _user: dict = Depends(_require_admin),
):
    """Recent completed/failed/cancelled tasks (newest first)."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_task_history(limit=min(limit, 500), work_type=wt)


@app.post("/api/admin/worker-pool/tasks/{task_id}/cancel")
async def admin_worker_pool_cancel(task_id: str, _user: dict = Depends(_require_admin)):
    """Cancel any task by its internal task_id."""
    from core.worker_pool import get_pool
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")
    if not pool.cancel(task_id):
        raise HTTPException(status_code=404, detail="Task not found or already completed")
    cancelled_by = (_user or {}).get("username", "admin")
    db_manager.audit(cancelled_by, "cancel_pool_task", resource_type="task", resource_id=task_id)
    return {"task_id": task_id, "message": "Cancelled"}


@app.get("/api/admin/worker-pool/config")
async def admin_worker_pool_config(_user: dict = Depends(_require_admin)):
    """Return current worker pool configuration."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_config()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")


class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent: Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue: Optional[int] = None
    report_max_concurrent: Optional[int] = None
    report_default_timeout: Optional[int] = None
    report_max_queue: Optional[int] = None
    scheduled_max_concurrent: Optional[int] = None
    scheduled_default_timeout: Optional[int] = None
    scheduled_max_queue: Optional[int] = None
    export_max_concurrent: Optional[int] = None
    export_default_timeout: Optional[int] = None
    export_max_queue: Optional[int] = None
    system_max_concurrent: Optional[int] = None
    system_default_timeout: Optional[int] = None
    system_max_queue: Optional[int] = None


@app.put("/api/admin/worker-pool/config")
async def admin_worker_pool_reconfigure(req: WorkerPoolConfigUpdate, _user: dict = Depends(_require_admin)):
    """Hot-reconfigure worker pool limits. Running tasks are NOT affected."""
    from core.worker_pool import get_pool, WorkType, TypeConfig
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")

    current = pool.get_config()["types"]
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes", "changes": {}}

    # Build new TypeConfig for each type that has changes
    _TYPE_MAP = {
        "interactive": WorkType.INTERACTIVE, "report": WorkType.REPORT,
        "scheduled": WorkType.SCHEDULED, "export": WorkType.EXPORT,
        "system": WorkType.SYSTEM,
    }
    new_cfgs: dict = {}
    for prefix, wt in _TYPE_MAP.items():
        cur = current[wt.name]
        mc = updates.get(f"{prefix}_max_concurrent", cur["max_concurrent"])
        dt = updates.get(f"{prefix}_default_timeout", cur["default_timeout"])
        mq = updates.get(f"{prefix}_max_queue", cur["max_queue"])
        if mc != cur["max_concurrent"] or dt != cur["default_timeout"] or mq != cur["max_queue"]:
            if mc < 1:
                raise HTTPException(400, f"{prefix}_max_concurrent must be >= 1")
            if dt < 10:
                raise HTTPException(400, f"{prefix}_default_timeout must be >= 10")
            if mq < 1:
                raise HTTPException(400, f"{prefix}_max_queue must be >= 1")
            new_cfgs[wt] = TypeConfig(mc, dt, mq)

    changes = pool.reconfigure(new_cfgs)

    # Persist to config.json so changes survive restart
    try:
        from core import config as _cfg
        import json as _json
        cfg_path = _cfg._CONFIG_FILE
        existing = {}
        if cfg_path.exists():
            with open(cfg_path, "r") as f:
                existing = _json.load(f)
        wp = existing.setdefault("worker_pool", {})
        for k, v in updates.items():
            wp[k] = v
        with open(cfg_path, "w") as f:
            _json.dump(existing, f, indent=2)
    except Exception as e:
        logger.warning("Could not persist worker pool config: %s", e)

    changed_by = (_user or {}).get("username", "admin")
    db_manager.audit(changed_by, "reconfigure_worker_pool", resource_type="worker_pool",
                     details={"changes": changes, "updates": updates})
    return {"message": "Reconfigured", "changes": changes}


# S3 Configuration Endpoints

@app.post("/api/s3/configure")
async def configure_s3(config: S3ConfigModel):
    """Configure or update S3 connection"""
    try:
        s3_config = build_s3_config(config.model_dump())
        
        engine.set_s3_config(s3_config)
        
        # Test connection
        test_result = engine.s3_handler.test_connection()
        
        return {
            "message": "S3 configured successfully",
            "connection_test": test_result
        }
    except Exception as e:
        logger.error(f"Error configuring S3: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/test")
async def test_s3_connection():
    """Test S3 connection"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        result = engine.s3_handler.test_connection()
        return result
    except Exception as e:
        logger.error(f"Error testing S3 connection: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/folders")
async def list_s3_folders(prefix: str = ""):
    """List folders in S3 bucket"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        folders = engine.list_s3_folders(prefix)
        return folders
    except Exception as e:
        logger.error(f"Error listing S3 folders: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/files")
async def list_s3_files(folder: str = ""):
    """List parquet files in S3 folder"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        files = engine.list_s3_files(folder)
        return files
    except Exception as e:
        logger.error(f"Error listing S3 files: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# File Management Endpoints

@app.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = ""):
    """List all available parquet files from local and/or S3"""
    try:
        files = engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str):
    """Get schema information for a specific file"""
    if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
        raise HTTPException(status_code=400, detail="Use /api/connections/{id}/tables/{name}/schema for registered tables")
    try:
        schema = engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error("Error getting file schema: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...), _user: dict = Depends(_get_current_user)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")
        
        file_path = Path(engine.base_path) / file.filename
        
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"File uploaded: {file.filename}")
        
        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# Query Management Endpoints (same as before)
@app.post("/api/queries")
async def create_query(req: Request, request: SaveQueryRequest, _user: dict = Depends(_require_role("admin", "analyst"))):
    """Save a new query"""
    try:
        # Do NOT validate file existence here — files may be on S3 or remote paths
        # that aren't accessible from the server at save time. Validation runs at
        # execution time when the engine actually needs the files.
        query = db_manager.create_query(
            name=request.name,
            description=request.description,
            query_config=request.query_config.model_dump(),
            created_by=(_user or {}).get("username") or request.created_by or "guest"
        )
        _audit(_user, "save_query", req, "query", query["id"], {"name": request.name})
        logger.info(f"Query saved: {query['id']}")
        return query
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0,
                       request: Request = None):
    """List saved queries — filtered by owner/shared when auth is enabled."""
    try:
        queries = db_manager.list_queries(active_only=active_only, limit=limit, offset=offset)
        # Row-level security: non-admin users only see own + shared queries
        if _auth_cfg.type != "none" and request:
            user = _get_current_user(request)
            queries = [q for q in queries if _is_owner_or_shared(q, user)]
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"


@app.post("/api/joins/preview")
async def join_preview(request: JoinPreviewRequest, _user: dict = Depends(_get_current_user)):
    """Return match statistics for a proposed join: row counts + sample rows.
    Runs lightweight DuckDB COUNT(*) queries — no execution record created."""
    import duckdb as _ddb

    def _make_read_fn(file_path: str, conn=None) -> str:
        """Return a DuckDB read expression for the given file path."""
        if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
            raise ValueError(f"Registered/Iceberg tables cannot be used in join preview: {file_path}")
        if file_path.startswith("s3://"):
            return f"read_parquet('{file_path}')"
        if file_path.lower().endswith(".csv"):
            return f"read_csv_auto('{file_path}')"
        return f"read_parquet('{file_path}')"

    try:
        # Resolve S3 credentials if needed
        _join_conn_config: dict = {}
        if request.connection_id:
            try:
                conn_cfg = db_manager.get_connection_raw(request.connection_id)
                if conn_cfg:
                    _join_conn_config = conn_cfg.get("config", {})
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        from api.data_grid_api import _duckdb_con_with_s3 as _s3_con_fn2
        con = _s3_con_fn2(_join_conn_config, request.connection_id) if _join_conn_config else _ddb.connect()
        try:

            left_read  = _make_read_fn(request.left_file)
            right_read = _make_read_fn(request.right_file)

            on_clause = " AND ".join(
                f't0."{l}" = t1."{r}"'
                for l, r in zip(request.left_on, request.right_on)
            )
            join_type = request.how.upper()
            if join_type not in ("INNER", "LEFT", "RIGHT"):
                join_type = "FULL OUTER"

            left_count  = con.execute(f"SELECT COUNT(*) FROM {left_read} AS t0").fetchone()[0]
            right_count = con.execute(f"SELECT COUNT(*) FROM {right_read} AS t1").fetchone()[0]
            matched_count = con.execute(
                f"SELECT COUNT(*) FROM {left_read} AS t0"
                f" INNER JOIN {right_read} AS t1 ON {on_clause}"
            ).fetchone()[0]

            # Sample rows from the configured join type
            sample_df = con.execute(
                f"SELECT * FROM {left_read} AS t0"
                f" {join_type} JOIN {right_read} AS t1 ON {on_clause} LIMIT 5"
            ).fetchdf()
            columns = list(sample_df.columns)
            sample_rows = sample_df.to_dict(orient="records")

        finally:
            con.close()

        match_rate = round(matched_count / left_count, 4) if left_count > 0 else 0.0
        return {
            "left_count": left_count,
            "right_count": right_count,
            "matched_count": matched_count,
            "match_rate": match_rate,
            "columns": columns,
            "sample_rows": sample_rows,
        }
    except Exception as exc:
        logger.error("join_preview error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/execute/preview-sql")
async def preview_sql(request: PreviewSqlRequest, _user: dict = Depends(_get_current_user)):
    """Generate the actual SQL that would be executed for a given query config.
    Returns DuckDB read_parquet SQL for parquet connections, or native SQL for SQL connectors."""
    try:
        engine_config = convert_query_config_to_engine(request.query_config)
        if request.connection_id:
            conn = db_manager.get_connection_raw(request.connection_id)
            if conn:
                conn_type = conn.get('connection_type')
                cfg = conn.get('config', {})
                if conn_type in SQL_CONNECTOR_TYPES:
                    table_ref = request.query_config.files[0] if request.query_config.files else ""
                    sql = engine.build_query_sql(engine_config, table_ref)
                    return {"sql": sql, "dialect": conn_type}
                elif conn_type == 'local':
                    local_path = str(_normalize_path(cfg.get('base_path', './data/parquet')))
                    local_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
                    sql = local_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
                elif conn_type == 's3':
                    s3_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(cfg),
                    )
                    sql = s3_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
        sql = engine.get_duckdb_sql(engine_config)
        return {"sql": sql, "dialect": "duckdb"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/execute/estimate  — lightweight row / file count before execution
# ─────────────────────────────────────────────────────────────────────────────
class EstimateRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None

@app.post("/api/execute/estimate")
async def estimate_query(request: EstimateRequest, _user: dict = Depends(_get_current_user)):
    """Return estimated row count and file count without executing the full query."""
    try:
        query_config_model = request.query_config
        _effective_conn_id = request.connection_id or query_config_model.connection_id

        if not query_config_model.files:
            return {"estimated_rows": 0, "estimated_files": 0}

        # ── Registered tables — return file count only (can't COUNT without views) ──
        _has_registered = any(
            (f if isinstance(f, str) else (f.path if hasattr(f, 'path') else '')).startswith("__registered__:")
            for f in query_config_model.files
        )
        if _has_registered:
            return {
                "estimated_rows": -1,
                "estimated_files": len(query_config_model.files),
                "note": "Row estimation not available for registered tables",
            }

        # Resolve connection
        conn_record = None
        _conn_type = None
        _cfg = {}
        if _effective_conn_id:
            conn_record = db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})

        # ── SQL connector path (Trino, Snowflake, Databricks, Oracle) ──
        if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
            table_ref = query_config_model.files[0] if query_config_model.files else None
            if not table_ref:
                return {"estimated_rows": -1, "estimated_files": 0}

            # Build filter-only query, then wrap with COUNT(*)
            estimate_model = query_config_model.model_copy(update={
                "limit": None, "offset": 0, "aggregations": None,
                "group_by": None, "order_by": None, "columns": None,
            })
            try:
                from core.date_resolver import resolve_filter_dates
                if estimate_model.filters:
                    resolved = resolve_filter_dates(estimate_model.filters)
                    estimate_model = estimate_model.model_copy(update={"filters": resolved})
            except Exception:
                pass

            engine_config = convert_query_config_to_engine(estimate_model)
            full_sql = engine.build_query_sql(engine_config, table_ref)

            # Replace SELECT ... FROM with SELECT COUNT(*) FROM
            from_idx = full_sql.upper().find("\nFROM ")
            if from_idx == -1:
                from_idx = full_sql.upper().find(" FROM ")
            if from_idx == -1:
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:]

            # Execute via connector (runs on the actual database)
            try:
                sql_connector = get_connector(_conn_type, _cfg)
                result = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: sql_connector.execute_query(count_sql, limit=None)
                )
                rows = result.get("rows", [])
                if rows:
                    # Column name may be 'cnt', 'CNT', etc. depending on DB dialect
                    row = {k.lower(): v for k, v in rows[0].items()}
                    estimated_rows = row.get("cnt", 0)
                else:
                    estimated_rows = 0
            except Exception as exc:
                logger.warning("SQL connector estimate failed (%s): %s", _conn_type, exc)
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            return {
                "estimated_rows": estimated_rows,
                "estimated_files": len(query_config_model.files),
            }

        # ── Parquet path (local / S3) ──
        active_engine = engine
        if _conn_type == 'local':
            local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
            active_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
        elif _conn_type == 's3':
            active_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir), chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(_cfg),
            )

        # Build filter-only query
        estimate_model = query_config_model.model_copy(update={
            "limit": None, "offset": 0, "aggregations": None,
            "group_by": None, "order_by": None, "columns": None,
        })
        try:
            from core.date_resolver import resolve_filter_dates
            if estimate_model.filters:
                resolved = resolve_filter_dates(estimate_model.filters)
                estimate_model = estimate_model.model_copy(update={"filters": resolved})
        except Exception:
            pass

        engine_config = convert_query_config_to_engine(estimate_model)
        from_clause = active_engine._build_duckdb_from_clause(engine_config)
        full_sql = active_engine.build_query_sql(engine_config, from_clause)

        from_idx = full_sql.upper().find("\nFROM ")
        if from_idx == -1:
            from_idx = full_sql.upper().find(" FROM ")
        count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:] if from_idx != -1 else None

        estimated_rows = 0
        if count_sql:
            from api.data_grid_api import _duckdb_con_with_s3
            if _conn_type == 's3':
                con = _duckdb_con_with_s3(_cfg, connection_id=_effective_conn_id)
            else:
                import duckdb
                con = duckdb.connect(database=":memory:")
            try:
                result = con.execute(count_sql).fetchone()
                estimated_rows = result[0] if result else 0
            finally:
                con.close()

        return {
            "estimated_rows": estimated_rows,
            "estimated_files": len(query_config_model.files),
        }
    except Exception as e:
        logger.error("Estimate error: %s", e, exc_info=True)
        return {"estimated_rows": -1, "estimated_files": len(request.query_config.files or []),
                "error": str(e)}


@app.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks, _user: dict = Depends(_require_execute_access)):
    """Execute a query (saved or ad-hoc)"""
    try:
        if request.query_config:
            # Client passes an explicit (possibly parameterised) query config — use it.
            # query_id may also be set for audit/tracking purposes; that is fine.
            query_config_model = request.query_config
        elif request.query_id:
            saved_query = db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.raw_sql:
            # SQL editor mode — no visual query config needed
            query_config_model = QueryConfigModel(files=[])
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id, query_config, or raw_sql must be provided"
            )

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except Exception:
            pass   # non-fatal — proceed with original filters

        # Resolve engine based on connection type
        # Explicit request.connection_id takes priority; fall back to connection_id stored in saved query
        _effective_conn_id = request.connection_id or query_config_model.connection_id
        active_engine = engine
        _uses_registered = False
        if _effective_conn_id:
            conn_record = db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})
                if _conn_type == 'local':
                    local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
                    active_engine = ParquetQueryEngine(
                        base_path=local_path,
                        chunk_size=_qe_cfg.chunk_size,
                    )
                elif _conn_type == 's3':
                    active_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(_cfg),
                    )
                    # Check if query uses registered tables (__registered__: prefix)
                    def _has_registered_prefix(paths):
                        return any(f.startswith("__registered__:") for f in (paths or []))
                    _join_files = [
                        j.right_file if isinstance(j.right_file, str) else j.right_file
                        for j in (query_config_model.joins or [])
                    ] if query_config_model.joins else []
                    _uses_registered = (
                        _has_registered_prefix(query_config_model.files or [])
                        or _has_registered_prefix(_join_files)
                    )
                    if _uses_registered:
                        active_engine._registered_tables = _cfg.get("registered_tables", [])
                        active_engine._s3_conn_config = _cfg
                        active_engine._s3_bucket = _cfg["bucket_name"]
                        active_engine._s3_conn_id = _effective_conn_id
                elif _conn_type in SQL_CONNECTOR_TYPES:
                    # ── SQL connector execution path ──────────────────────────
                    # Build SQL from the query config and dispatch to the connector.
                    # Bypass parquet validation — there are no local files to check.
                    sql_connector = get_connector(_conn_type, _cfg)
                    if request.raw_sql:
                        sql_str = request.raw_sql
                    else:
                        engine_config = convert_query_config_to_engine(query_config_model)
                        table_ref = query_config_model.files[0] if query_config_model.files else None
                        if not table_ref:
                            raise HTTPException(status_code=400, detail="No table specified in query config")
                        sql_str = engine.build_query_sql(engine_config, table_ref)

                    _username = _user.get("username", "guest") if _user else "guest"
                    with _user_query_lock:
                        _active = _user_query_counts.get(_username, 0)
                        if _active >= _qe_cfg.max_concurrent_per_user:
                            raise HTTPException(
                                status_code=429,
                                detail=f"Too many concurrent queries ({_active} running)."
                            )
                        _user_query_counts[_username] = _active + 1
                    try:
                        execution_id = str(uuid.uuid4())
                        execution = db_manager.create_execution(
                            execution_id=execution_id,
                            query_id=request.query_id,
                            query_config=query_config_model.model_dump(),
                            executed_by=request.executed_by or _username
                        )
                        _task = asyncio.create_task(
                            execute_sql_connector_background(
                                execution_id, sql_connector, sql_str,
                                query_id=request.query_id, executed_by=_username,
                            )
                        )
                        pass  # pool tracks the task
                    except Exception:
                        with _user_query_lock:
                            _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                        raise
                    _audit(_user, "execute_sql_connector_query", None, "execution", execution_id,
                           {"conn_type": _conn_type, "table": table_ref, "query_id": request.query_id})
                    logger.info(f"SQL connector query started: {execution_id} ({_conn_type}:{table_ref})")
                    return {
                        "execution_id": execution_id,
                        "status": "pending",
                        "started_at": execution["started_at"],
                        "message": f"SQL connector query started ({_conn_type})"
                    }

        engine_config = convert_query_config_to_engine(query_config_model)

        # ── Cross-connection join / union path ────────────────────────────────
        if request.secondary_connection_id and request.secondary_query_config:
            # Validate secondary connection exists
            sec_conn_record = db_manager.get_connection_raw(request.secondary_connection_id)
            if not sec_conn_record:
                raise HTTPException(
                    status_code=404,
                    detail=f"Secondary connection {request.secondary_connection_id} not found"
                )

            # Validate secondary query config is parseable
            try:
                sec_qc_model = QueryConfigModel(**request.secondary_query_config)
            except Exception as _pve:
                raise HTTPException(status_code=400,
                                    detail=f"Invalid secondary_query_config: {_pve}")

            # Validate join_config present when mode=join
            if request.combine_mode == "join":
                _jc = request.join_config or {}
                if not _jc.get("left_on") or not _jc.get("right_on"):
                    raise HTTPException(
                        status_code=400,
                        detail="join_config with left_on and right_on is required when combine_mode='join'"
                    )

            # Resolve secondary engine
            secondary_engine = engine
            _sc_type = sec_conn_record.get('connection_type')
            _sc_cfg = sec_conn_record.get('config', {})
            if _sc_type == 'local':
                _sc_path = str(_normalize_path(_sc_cfg.get('base_path', './data/parquet')))
                secondary_engine = ParquetQueryEngine(
                    base_path=_sc_path,
                    chunk_size=_qe_cfg.chunk_size,
                )
            elif _sc_type == 's3':
                secondary_engine = ParquetQueryEngine(
                    base_path=str(_paths.parquet_dir),
                    chunk_size=_qe_cfg.chunk_size,
                    s3_config=build_s3_config(_sc_cfg),
                )

            secondary_config = convert_query_config_to_engine(sec_qc_model)

            _username = _user.get("username", "guest") if _user else "guest"
            _max_per_user = _qe_cfg.max_concurrent_per_user
            with _user_query_lock:
                _active = _user_query_counts.get(_username, 0)
                if _active >= _max_per_user:
                    raise HTTPException(
                        status_code=429,
                        detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                               "Wait for one to complete or cancel it first."
                    )
                _user_query_counts[_username] = _active + 1

            # Guard: decrement counter if task setup fails after increment
            try:
                execution_id = str(uuid.uuid4())
                execution = db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by or _username
                )
                _task = asyncio.create_task(
                    execute_cross_query_background(
                        execution_id,
                        active_engine,
                        engine_config,
                        secondary_engine,
                        secondary_config,
                        combine_mode=request.combine_mode,
                        join_config=request.join_config,
                        query_id=request.query_id,
                        executed_by=_username,
                    )
                )
                pass  # pool tracks the task
            except Exception:
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                raise

            _audit(_user, "execute_cross_query", None, "execution", execution_id,
                   {"query_id": request.query_id,
                    "primary_connection_id": request.connection_id,
                    "secondary_connection_id": request.secondary_connection_id,
                    "combine_mode": request.combine_mode})
            logger.info(f"Cross-connection query started: {execution_id} ({request.combine_mode})")

            return {
                "execution_id": execution_id,
                "status": "pending",
                "started_at": execution["started_at"],
                "is_cross_connection": True,
                "combine_mode": request.combine_mode,
                "message": f"Cross-connection {request.combine_mode.upper()} query started"
            }

        # ── Single-source path (original) ─────────────────────────────────────
        # Skip file-level validation for registered tables — they use virtual
        # paths (__registered__:name) that don't exist on disk / S3.
        if not _uses_registered:
            # Run validate_query off the event loop — it reads file schemas from disk
            # and can take 100 ms – 2 s per file, which would stall all other requests.
            _loop = asyncio.get_running_loop()
            validation = await _loop.run_in_executor(
                query_executor, active_engine.validate_query, engine_config
            )
            if not validation["valid"]:
                raise HTTPException(
                    status_code=400,
                    detail={"message": "Invalid query configuration", "errors": validation["errors"]}
                )

        # ── Query result cache check ──────────────────────────────────────────
        # Only cache ad-hoc / saved_query executions (not custom connection queries)
        if not _effective_conn_id:
            from core.query_cache import make_cache_key, get_cached_result
            _cache_key = make_cache_key(query_config_model.model_dump())
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                db_manager.update_execution(execution_id, status="completed",
                                            output_file=str(_cached_path))
                db_manager.create_download_file(
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_path.stat().st_size,
                    expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                )
                await ws_manager.broadcast({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # Per-user concurrent query limit
        _username = _user.get("username", "guest") if _user else "guest"
        _max_per_user = _qe_cfg.max_concurrent_per_user
        with _user_query_lock:
            _active = _user_query_counts.get(_username, 0)
            if _active >= _max_per_user:
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                           "Wait for one to complete or cancel it first."
                )
            _user_query_counts[_username] = _active + 1

        # Guard: decrement counter if task setup fails after increment
        try:
            execution_id = str(uuid.uuid4())
            execution = db_manager.create_execution(
                execution_id=execution_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username
            )
            # Use create_task (not background_tasks) so queries run truly concurrently.
            _task = asyncio.create_task(
                execute_query_background(
                    execution_id,
                    engine_config,
                    request.query_id,
                    active_engine,
                    executed_by=_username,
                    raw_sql=request.raw_sql,
                )
            )
            pass  # pool tracks the task
        except Exception:
            with _user_query_lock:
                _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
            raise

        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started"
        }
        
    except HTTPException:
        raise
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED"})
    except Exception as e:
        logger.error(f"Error executing query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0):
    """List available downloads"""
    try:
        downloads = db_manager.list_download_files(status=status, limit=limit, offset=offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads/{file_id}")
async def download_file(file_id: str):
    """Download a file"""
    try:
        download_info = db_manager.get_download_file(file_id)
        
        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")
        
        file_path = Path(download_info["file_path"])
        
        if not file_path.exists():
            # File deleted from disk — purge the stale record so it stops showing in history
            db_manager.update_download_file(file_id, status="deleted")
            raise HTTPException(status_code=410, detail="File has been deleted")

        db_manager.increment_download_count(file_id)
        
        logger.info(f"File downloaded: {file_id}")
        
        _media_map = {
            ".csv":   "text/csv",
            ".xlsx":  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".json":  "application/json",
            ".parquet": "application/octet-stream",
        }
        _media_type = _media_map.get(file_path.suffix.lower(), "application/octet-stream")
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type=_media_type,
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 1. GET /api/queries/{query_id}
#    ReportPage calls api.getSavedQuery(id) to load a report by ID
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}")
async def get_query(query_id: int):
    """Get a single saved query by ID"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 2. DELETE /api/queries/{query_id}
#    SavedQueries page delete button
#    Uses db_manager.delete_query() — soft delete, sets is_active=False
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, req: Request, _user: dict = Depends(_get_current_user)):
    """Soft-delete a saved query (sets is_active=False)"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only delete their own queries
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if query.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        db_manager.delete_query(query_id, soft_delete=True)
        _audit(_user, "delete_query", req, "query", query_id, {"name": query.get("name")})
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/queries/{query_id}/favorite  — toggle favorite
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/api/queries/{query_id}/favorite")
async def toggle_query_favorite(query_id: int, req: Request, _user: dict = Depends(_get_current_user)):
    """Toggle the is_favorite flag on a saved query."""
    try:
        result = db_manager.toggle_favorite(query_id)
        if not result:
            raise HTTPException(status_code=404, detail="Query not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error toggling favorite for query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# PUT /api/queries/{query_id}  — update + version snapshot
# ─────────────────────────────────────────────────────────────────────────────
class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None


@app.put("/api/queries/{query_id}")
async def update_query(query_id: int, request: UpdateQueryRequest,
                       _user: dict = Depends(_get_current_user)):
    """Update a saved query — auto-saves a version snapshot before changes."""
    try:
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only update their own queries
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if existing.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        # Snapshot before change
        db_manager.create_query_version(
            query_id=query_id,
            name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"],
            changed_by=_user.get("username"), change_note=request.change_note,
        )
        updates = {}
        if request.name is not None:        updates["name"] = request.name
        if request.description is not None: updates["description"] = request.description
        if request.query_config is not None:
            updates["query_config"] = request.query_config.model_dump()
        result = db_manager.update_query(query_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Version History endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}/versions")
async def list_query_versions(query_id: int, _user: dict = Depends(_get_current_user)):
    try:
        return db_manager.list_query_versions(query_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/queries/{query_id}/versions/{version_id}/restore")
async def restore_query_version(query_id: int, version_id: int,
                                _user: dict = Depends(_get_current_user)):
    try:
        v = db_manager.get_query_version(version_id)
        if not v or v["query_id"] != query_id:
            raise HTTPException(status_code=404, detail="Version not found")
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # Save current state as a version before restoring
        db_manager.create_query_version(
            query_id=query_id, name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"], changed_by=_user.get("username"),
            change_note=f"Auto-saved before restore to v{v['version_number']}",
        )
        db_manager.update_query(query_id, name=v["name"], description=v["description"],
                                query_config=v["query_config"])
        return {"message": f"Restored to version {v['version_number']}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Query Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/queries/{query_id}/share")
async def share_query(query_id: int, request: ShareQueryRequest,
                      _user: dict = Depends(_get_current_user)):
    q = db_manager.get_query(query_id)
    if not q:
        raise HTTPException(status_code=404, detail="Query not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_share(query_id, _user.get("username"), expires_at)
    return share


@app.get("/api/queries/{query_id}/shares")
async def list_query_shares(query_id: int, _user: dict = Depends(_get_current_user)):
    return db_manager.list_shares(query_id)


@app.delete("/api/queries/{query_id}/shares/{token}")
async def revoke_share(query_id: int, token: str, _user: dict = Depends(_get_current_user)):
    db_manager.deactivate_share(token)
    return {"message": "Share revoked"}


# PUBLIC endpoint — NO auth (accessible by anyone with the link)
@app.get("/api/shared/{token}")
async def get_shared_query(token: str):
    share = db_manager.get_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)
    db_manager.increment_share_access(token)
    q = db_manager.get_query(share["query_id"])
    if not q:
        raise HTTPException(status_code=404, detail="Query no longer exists")
    return {"query": q, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/dashboards/{dashboard_id}/share")
async def share_dashboard(dashboard_id: int, request: ShareDashboardRequest,
                          _user: dict = Depends(_get_current_user)):
    d = db_manager.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_dashboard_share(dashboard_id, _user.get("username"), expires_at)
    return share


@app.get("/api/shared-dashboard/{token}")
async def get_shared_dashboard(token: str):
    """Public endpoint — no auth required."""
    share = db_manager.get_dashboard_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)
    db_manager.increment_dashboard_share_access(token)
    d = db_manager.get_dashboard(share["dashboard_id"])
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard no longer exists")
    widgets = db_manager.list_widgets(share["dashboard_id"])
    return {"dashboard": d, "widgets": widgets, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Admin — Audit log endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/admin/audit-log")
async def get_audit_log(
    username: Optional[str] = None,
    action:   Optional[str] = None,
    limit:    int = 200,
    offset:   int = 0,
    _user: dict = Depends(_require_admin),
):
    """Return audit log entries (admin only). Filterable by username and action."""
    return db_manager.list_audit_log(username=username, action=action,
                                     limit=min(limit, 1000), offset=offset)


# ─────────────────────────────────────────────────────────────────────────────
# Admin — User management endpoints (local auth mode)
# ─────────────────────────────────────────────────────────────────────────────

class _UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"

@app.get("/api/admin/users")
async def list_users(_user: dict = Depends(_require_admin)):
    """List all configured users (local or AD auth)."""
    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        user_roles = _auth_cfg.user_roles
        return [
            {"username": u, "role": user_roles.get(u.lower(), "viewer")}
            for u in local_users
        ]
    if _auth_cfg.type == "ad":
        # AD mode: return users from the role mapping
        user_roles = _auth_cfg.user_roles
        return [
            {"username": u, "role": r}
            for u, r in user_roles.items()
        ]
    return {"auth_type": _auth_cfg.type, "message": "User management not available when auth is disabled"}


@app.get("/api/admin/users/lookup/{username}")
async def lookup_user_ad(username: str, _user: dict = Depends(_require_admin)):
    """Look up a user in Active Directory by Windows ID (sAMAccountName)."""
    if _auth_cfg.type != "ad":
        raise HTTPException(400, "AD lookup only available when auth.type = 'ad'")
    from core.ad_auth import lookup_ad_user
    result = lookup_ad_user(username)
    if not result:
        raise HTTPException(404, f"User '{username}' not found in Active Directory")
    return result


@app.post("/api/admin/users", status_code=201)
async def add_user(req: _UserPayload, _user: dict = Depends(_require_admin)):
    """Add a new user (local: with password, AD: role mapping only)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if req.role not in ("admin", "analyst", "viewer"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        if not req.password:
            raise HTTPException(400, "Password is required for local users")
        local_users = _auth_cfg.local_users
        if req.username in local_users:
            raise HTTPException(409, f"User '{req.username}' already exists")
        _update_config_users(req.username, req.password, req.role, action="add")
    else:
        # AD mode: just save the role mapping (no password needed)
        user_roles = _auth_cfg.user_roles
        if req.username.lower() in user_roles:
            raise HTTPException(409, f"User '{req.username}' already exists")
        _update_config_users(req.username, None, req.role, action="add_role")

    return {"username": req.username, "role": req.role}


@app.put("/api/admin/users/{username}")
async def update_user(username: str, req: _UserPayload, _user: dict = Depends(_require_admin)):
    """Update a user's role (and optionally password for local auth)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if req.role not in ("admin", "analyst", "viewer"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        _update_config_users(username, req.password, req.role, action="update")
    else:
        # AD mode: update role mapping only
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        _update_config_users(username, None, req.role, action="update_role")

    return {"username": username, "role": req.role}


@app.delete("/api/admin/users/{username}")
async def remove_user(username: str, req: Request, _user: dict = Depends(_require_admin)):
    """Remove a user (local: delete entirely, AD: remove role mapping)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if username.lower() == (_user or {}).get("username", "").lower():
        raise HTTPException(400, "Cannot delete your own account")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        _update_config_users(username, None, None, action="remove")
    else:
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        _update_config_users(username, None, None, action="remove_role")

    _audit(_user, "remove_user", req, "user", 0, {"username": username})
    return {"message": f"User '{username}' removed"}


def _update_config_users(username: str, password: Optional[str], role: Optional[str], action: str):
    """Persist user change to config.json and reload config in-memory.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    import json as _json
    config_file = Path(__file__).resolve().parent / "config.json"
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = _json.load(f)

    auth_section = cfg.setdefault("auth", {})

    # Parse current local_users and user_roles
    raw_users = auth_section.get("local_users", "")
    users_dict = {}
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            users_dict[u.strip()] = p.strip()

    raw_roles = auth_section.get("user_roles", "")
    roles_dict = {}
    for pair in raw_roles.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, r = pair.split(":", 1)
            roles_dict[u.strip().lower()] = r.strip().lower()

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    auth_section["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
    auth_section["user_roles"] = ",".join(f"{u}:{r}" for u, r in roles_dict.items())

    with open(config_file, "w", encoding="utf-8") as f:
        _json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Reload in-memory config
    from core import config as _config_mod
    _config_mod._file_cfg = _config_mod._load_file()
    _config_mod._merged = _config_mod._deep_merge(_config_mod._DEFAULTS, _config_mod._file_cfg)
    _config_mod._cfg = _config_mod._apply_env(_config_mod._merged)
    logger.info("Config reloaded after user %s: %s", action, username)


# ─────────────────────────────────────────────────────────────────────────────
# Cache management endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/cache/stats")
async def get_cache_stats(_user: dict = Depends(_get_current_user)):
    from core.query_cache import get_stats
    return get_stats()


@app.delete("/api/cache")
async def clear_cache(_user: dict = Depends(_require_admin)):
    from core.query_cache import cleanup_expired
    count = cleanup_expired()
    return {"message": f"Removed {count} expired cache entries"}


@app.post("/api/webhooks/test")
async def test_webhook_url(body: dict, _user: dict = Depends(_get_current_user)):
    """Test a webhook URL by sending a sample notification."""
    url = body.get("url", "")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    from core.webhook_service import test_webhook
    return test_webhook(url)


# ─────────────────────────────────────────────────────────────────────────────
# 3. DELETE /api/downloads/{file_id}
#    Downloads page delete button
#    Uses update_download_file() to set status='deleted', removes file from disk
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str, _user: dict = Depends(_get_current_user)):
    """Mark a download as deleted and remove from disk"""
    try:
        download = db_manager.get_download_file(file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")
        # RLS: non-admins can only delete their own downloads
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if download.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")

        # Remove file from disk if it exists
        file_path = Path(download["file_path"])
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        db_manager.update_download_file(file_id, status="deleted")

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 4. GET /api/executions
#    ExecutionHistory component — list recent executions
#    Uses list_executions(limit, offset, status) — all params optional
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions")
async def list_executions(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = None
):
    """List recent query executions"""
    try:
        executions = db_manager.list_executions(
            limit=limit,
            offset=offset,
            status=status if status else None
        )
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 5. GET /api/executions/{execution_id}
#    Single execution detail — used by ExecutionHistory detail view
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str):
    """Get a single execution record by ID"""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 6. GET /api/executions/{execution_id}/status
#    ReportPage polls this every 2 seconds to know when query finishes
#    Uses get_execution() — already tracked by execute_query_background()
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str):
    """
    Get status of an execution — polled by ReportPage.
    Returns: { execution_id, status, total_rows, started_at, completed_at, error_message }
    status values: pending | processing | completed | failed
    """
    try:
        execution = db_manager.get_execution(execution_id)

        if not execution:
            # Not in DB yet (just started) — check downloads as fallback
            downloads = db_manager.list_download_files(status="available", limit=500, offset=0)
            match = next(
                (d for d in downloads if d.get("execution_id") == execution_id),
                None
            )
            if match:
                return {
                    "execution_id": execution_id,
                    "status": "completed",
                    "file_id": match["file_id"],
                    "filename": match["filename"],
                    "total_rows": None,
                }
            return {"execution_id": execution_id, "status": "pending"}

        return {
            "execution_id": execution_id,
            "status": execution.get("status", "unknown"),
            "total_rows": execution.get("total_rows"),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "error_message": execution.get("error_message"),
        }

    except Exception as e:
        logger.error(f"Error getting execution status {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: The data_grid_api router already adds these routes via include_router:
#   GET /api/executions/{execution_id}/results  (pagination)
#   GET /api/executions/{execution_id}/export   (csv/excel/json)
#   GET /api/executions/{execution_id}/stats    (column stats)
# ─────────────────────────────────────────────────────────────────────────────


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """
    Cancel a running execution.
    Works by:
      1. Setting the threading.Event — stops the worker thread after the current chunk.
      2. Cancelling the asyncio.Task — stops the coroutine waiting on run_in_executor.
      3. Marking the DB record as cancelled immediately.
    """
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # 1. Signal the worker pool to cancel (sets cancel_event + cancels future)
        from core.worker_pool import get_pool
        try:
            get_pool().cancel_by_execution_id(execution_id)
        except RuntimeError:
            # Pool not initialised — fall back to legacy globals
            cancel_event = _cancellation_flags.get(execution_id)
            if cancel_event:
                cancel_event.set()
            task = _running_tasks.get(execution_id)
            if task and not task.done():
                task.cancel()

        # 2. Mark as cancelled in DB immediately (don't wait for thread to stop)
        db_manager.update_execution(
            execution_id,
            status="cancelled",
            error_message="Cancelled by user"
        )

        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        db_manager.audit("system", "cancel_query", resource_type="execution",
                         resource_id=execution_id)
        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 8. FIX: Downloads page shows EVERY query execution
#
# ROOT CAUSE: execute_query_background() calls db_manager.create_download_file()
# after every execution, so ALL results appear in the Downloads page.
#
# Downloads should only show EXPLICIT exports (xlsx/json/csv the user requested).
#
# SOLUTION: In execute_query_background(), change create_download_file to use
# status="internal" instead of status="available":
#
#   db_manager.create_download_file(
#       file_id=file_id,
#       execution_id=execution_id,
#       filename=f"query_result_{execution_id}.csv",
#       file_path=str(output_file),
#       file_size_bytes=stats["file_size_bytes"],
#       expires_at=datetime.now(timezone.utc) + timedelta(days=7),
#       # ADD THIS:
#       created_by="internal"       # ← use created_by field to tag internal files
#   )
#
# Then in list_download_files, the Downloads page already filters by status="available"
# by default — internal results use status="available" but we mark created_by="internal".
#
# SIMPLEST FIX (no DB schema change needed):
# Change the Downloads page list_downloads route filter to exclude internal records:
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/exports")
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').
    """
    try:
        all_files = db_manager.list_download_files(status=status, limit=limit*3, offset=0)
        # Exclude internal auto-generated results
        exports = [f for f in all_files if f.get("created_by") != "internal"]
        return exports[:limit]
    except Exception as e:
        logger.error(f"Error listing exports: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    
# ─────────────────────────────────────────────────────────────────────────────
# Connection Manager Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/connections")
async def list_connections(active_only: bool = True, request: Request = None):
    """List connections — users see their own + shared; admins see all."""
    try:
        all_conns = db_manager.list_connections(active_only=active_only)
        # Apply RLS: non-admins see only their own + shared connections
        if _auth_cfg.type != "none":
            user = _get_current_user(request)
            if user and not user.get("is_admin"):
                username = user.get("username", "")
                all_conns = [
                    c for c in all_conns
                    if c.get("created_by") == username
                    or c.get("is_shared")
                    or not c.get("created_by")   # legacy connections (no owner) visible to all
                ]
        return all_conns
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections")
async def create_connection(request: ConnectionConfigModel, _user: dict = Depends(_require_role("admin", "analyst"))):
    """Create a new connection — auto-sets created_by from auth user."""
    try:
        conn = db_manager.create_connection(
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        # Set created_by and is_shared on the new connection
        username = (_user or {}).get("username", "guest")
        is_shared = request.is_shared or False
        db_manager.update_connection(conn["id"], created_by=username, is_shared=bool(is_shared))
        conn["created_by"] = username
        conn["is_shared"] = bool(is_shared)
        # Return masked config — never send encrypted credentials to browser
        from core.crypto import decrypt_config, mask_config
        if conn and "config" in conn:
            conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@app.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest):
    """Test a connection configuration without saving — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_type = request.connection_type
    conn_cfg  = dict(request.config)

    # When editing a saved connection the browser sends "***" for any sensitive
    # field the user did not change.  Substitute those placeholders with the
    # real (decrypted) values from the DB so the test uses valid credentials.
    if request.connection_id is not None:
        raw = db_manager.get_connection_raw(request.connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            for k, v in conn_cfg.items():
                if v == "***" and k in raw_cfg:
                    conn_cfg[k] = raw_cfg[k]

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_cfg)
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_cfg)
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int):
    """Get a specific connection"""
    conn = db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@app.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel, _user: dict = Depends(_require_role("admin", "analyst"))):
    """Update an existing connection"""
    try:
        # The frontend sends "***" for masked sensitive fields the user didn't change.
        # Replace those placeholders with the real (decrypted) values from the DB
        # so we don't accidentally store "***" as the actual credential.
        updated_config = dict(request.config)
        raw = db_manager.get_connection_raw(connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            from core.crypto import SENSITIVE_FIELDS
            for field in SENSITIVE_FIELDS:
                if updated_config.get(field) == "***" and field in raw_cfg:
                    real_val = raw_cfg[field]
                    if real_val:
                        updated_config[field] = real_val
                    else:
                        logger.warning(
                            "Credential field '%s' decrypted to empty for connection %d — "
                            "user must re-enter it.", field, connection_id
                        )
                        updated_config[field] = ""

        update_kwargs = dict(
            name=request.name,
            connection_type=request.connection_type,
            config=updated_config,
        )
        # Allow toggling is_shared
        if hasattr(request, "is_shared") and request.is_shared is not None:
            update_kwargs["is_shared"] = bool(request.is_shared)

        conn = db_manager.update_connection(connection_id, **update_kwargs)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        # Return masked config — never send encrypted or plaintext credentials to browser
        from core.crypto import decrypt_config, mask_config
        conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int, _user: dict = Depends(_require_role("admin", "analyst"))):
    """Delete a connection"""
    try:
        success = db_manager.delete_connection(connection_id, soft_delete=False)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection and persist the result — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    # Fetch raw creds synchronously (fast SQLite read) before entering executor
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw['connection_type']

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_raw['config'])
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_raw['config'])

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(query_executor, _do)
        db_manager.update_connection(
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result.get('message', '')
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = ""):
    """List tables/files for a connection.
    - S3 / local  → parquet file listing via ConnectionManager
    - SQL connectors → list tables from the configured catalog.schema
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _list_sql_tables():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                catalog = cfg.get("catalog") or cfg.get("database") or ""
                schema  = cfg.get("schema") or "public"
                tables  = connector.list_tables(catalog, schema)
                # Normalise to the same shape the frontend expects for file items
                result = []
                for t in tables:
                    tname = t["name"]
                    full_path = f"{catalog}.{schema}.{tname}" if catalog else f"{schema}.{tname}"
                    result.append({
                        "name":       tname,
                        "path":       full_path,
                        "folder":     f"{catalog}/{schema}" if catalog else schema,
                        "num_rows":   None,
                        "num_columns": None,
                        "size_bytes": None,
                        "table_type": t.get("type", "TABLE"),
                    })
                return result
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(query_executor, _list_sql_tables)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.list_files, connection_id, folder
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str):
    """Get schema for a file or SQL table.
    - S3 / local  → parquet metadata via ConnectionManager
    - SQL connectors → list_columns(catalog, schema, table)
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _sql_schema():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                # file_path is "catalog.schema.table" or "schema.table"
                parts = file_path.split(".")
                if len(parts) == 3:
                    catalog, schema, table = parts
                elif len(parts) == 2:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema, table = parts
                else:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema  = cfg.get("schema") or "public"
                    table   = file_path
                cols = connector.list_columns(catalog, schema, table)
                return {"columns": cols}
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(query_executor, _sql_schema)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.get_schema, connection_id, file_path
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Iceberg S3 Endpoints
# ─────────────────────────────────────────────────────────────────────────────

def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # Try the cached handler first — same client the file browser uses
    if conn_id is not None:
        try:
            handler = conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise


# ── Registered Tables (Enterprise S3 Table Registry) ─────────────────────

class RegisteredTableModel(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""


@app.get("/api/connections/{connection_id}/tables")
async def list_registered_tables(connection_id: int):
    """List all registered tables for an S3 connection."""
    try:
        tables = conn_manager.get_registered_tables(connection_id)
        return {"tables": tables}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.post("/api/connections/{connection_id}/tables")
async def register_table_endpoint(connection_id: int, table: RegisteredTableModel):
    """Register a named table pointing to an S3 prefix.

    For iceberg format: validates that the prefix has a metadata/ subfolder
    with valid Iceberg metadata files before accepting.
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")

    # Validate Iceberg prefix before registering
    if table.format == "iceberg":
        try:
            from core.iceberg_reader import is_iceberg_table
            s3 = _make_s3_client_for_conn(conn_raw)
            bucket = conn_raw["config"]["bucket_name"]
            if not is_iceberg_table(s3, bucket, table.s3_prefix):
                raise HTTPException(
                    status_code=400,
                    detail=f"'{table.s3_prefix}' is not a valid Iceberg table. "
                           f"No metadata/ folder with *.metadata.json found. "
                           f"Make sure you register at the table root level "
                           f"(the folder that contains both data/ and metadata/ subfolders)."
                )
        except HTTPException:
            raise
        except Exception as e:
            logger.warning("Iceberg validation failed for %s: %s", table.s3_prefix, e)

    try:
        result = conn_manager.register_table(connection_id, table.model_dump())
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.delete("/api/connections/{connection_id}/tables/{table_name}")
async def unregister_table_endpoint(connection_id: int, table_name: str):
    """Remove a registered table."""
    try:
        conn_manager.unregister_table(connection_id, table_name)
        return {"message": f"Table '{table_name}' removed"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/connections/{connection_id}/tables/{table_name}/schema")
async def get_registered_table_schema(connection_id: int, table_name: str):
    """Get schema for a registered table.

    - Iceberg tables: uses PyIceberg (reads latest snapshot metadata)
    - Parquet/CSV tables: uses DuckDB DESCRIBE with S3 glob
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")

    bucket = config["bucket_name"]
    fmt = table_def["format"]
    prefix = table_def["s3_prefix"].rstrip("/")

    def _do():
        try:
            return _do_inner()
        except BaseException as exc:
            # Catch absolutely everything — including SystemExit, KeyboardInterrupt,
            # and any C-extension crash that surfaces as a Python exception.
            logger.critical("CRASH in Iceberg schema _do() for '%s': %s", table_name, exc, exc_info=True)
            raise

    def _do_inner():
        logger.info("Loading schema for table '%s' (format=%s, bucket=%s)", table_name, fmt, bucket)
        if fmt == "iceberg":
            # Use the cached S3 client + iceberg_reader to read metadata directly
            # (avoids PyIceberg env-var credential issues with assume_role/profile)
            from core.iceberg_reader import get_iceberg_data_files, _latest_metadata_key, _read_s3_json
            logger.info("Creating S3 client for connection %d...", connection_id)
            s3 = _make_s3_client_for_conn(conn_raw)
            logger.info("S3 client created OK for connection %d", connection_id)
            meta_prefix = table_def["s3_prefix"].rstrip("/") + "/metadata/"
            try:
                logger.info("Reading Iceberg metadata from s3://%s/%s", bucket, meta_prefix)
                meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
                logger.info("Found metadata key: %s", meta_key)
                metadata = _read_s3_json(s3, bucket, meta_key)
                logger.info("Metadata loaded: format-version=%s, schemas=%d",
                            metadata.get("format-version"), len(metadata.get("schemas", [])))
            except Exception as e:
                logger.error("Failed to read Iceberg metadata for %s: %s", table_name, e, exc_info=True)
                raise ValueError(f"Cannot read Iceberg metadata: {e}")

            # Extract schema from metadata JSON
            schemas_list = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
            current_schema_id = metadata.get("current-schema-id", 0)
            schema_obj = next((s for s in schemas_list if s.get("schema-id") == current_schema_id), schemas_list[0] if schemas_list else {})
            columns = []
            for field in schema_obj.get("fields", []):
                ftype = field.get("type", "string")
                if isinstance(ftype, dict):
                    ftype = ftype.get("type", "struct")
                columns.append({
                    "name": field.get("name", ""),
                    "type": str(ftype),
                    "nullable": not field.get("required", False),
                    "field_id": field.get("id") or field.get("field-id"),
                })

            # Extract partition spec
            specs = metadata.get("partition-specs") or ([metadata["partition-spec"]] if "partition-spec" in metadata else [])
            default_spec_id = metadata.get("default-spec-id", 0)
            active_spec = next((s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {})
            field_names = {f.get("id") or f.get("field-id"): f.get("name", "") for f in schema_obj.get("fields", [])}
            partition_spec = []
            for pf in active_spec.get("fields", []):
                src_id = pf.get("source-id") or pf.get("source_id")
                partition_spec.append({
                    "name": pf.get("name", ""),
                    "transform": pf.get("transform", "identity"),
                    "source_column": field_names.get(src_id, str(src_id)),
                })

            # Snapshot info
            current_snap_id = metadata.get("current-snapshot-id")
            snapshots = metadata.get("snapshots", [])
            snap = next((s for s in snapshots if s.get("snapshot-id") == current_snap_id), None) if current_snap_id else None

            # Get data file count from manifests (keys_only=True to skip expensive metadata)
            logger.info("Reading Iceberg data files for %s (keys_only=True)...", table_name)
            try:
                data_files = get_iceberg_data_files(s3, bucket, table_def["s3_prefix"], keys_only=True)
                data_file_count = len(data_files)
                logger.info("Found %d data files for %s", data_file_count, table_name)
            except Exception as e:
                logger.error("Failed to read Iceberg data files for %s: %s", table_name, e, exc_info=True)
                data_files = []
                data_file_count = 0

            return {
                "table_name": table_name,
                "format": "iceberg",
                "s3_prefix": table_def["s3_prefix"],
                "columns": columns,
                "num_rows": data_file_count,  # file count (true row count requires scanning)
                "data_file_count": data_file_count,
                "partition_spec": partition_spec,
                "snapshot_id": current_snap_id,
                "format_version": metadata.get("format-version", 1),
            }
        else:
            # Parquet or CSV — use DuckDB DESCRIBE with S3 glob
            from api.data_grid_api import _duckdb_con_with_s3
            con = _duckdb_con_with_s3(config, connection_id=connection_id)
            try:
                if fmt == "csv":
                    src = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
                else:
                    src = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
                cols_raw = con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()
                row_count = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
                return {
                    "table_name": table_name,
                    "format": fmt,
                    "s3_prefix": table_def["s3_prefix"],
                    "columns": [
                        {"name": c[0], "type": c[1], "nullable": True}
                        for c in cols_raw
                    ],
                    "num_rows": row_count,
                }
            finally:
                con.close()

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error getting registered table schema: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Partition cache: L1 in-memory (5 min) + L2 SQLite (5 hours) ──────────────
import threading as _threading
_partition_cache: Dict[str, Tuple[float, dict]] = {}
_partition_cache_lock = _threading.Lock()
_PARTITION_L1_TTL = 300      # 5 minutes — hot in-memory cache
_PARTITION_L2_TTL = 18000    # 5 hours — persistent SQLite cache
_PARTITION_CACHE_MAX = 100   # max L1 entries


def _partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns (hit, result)."""
    import time as _time
    with _partition_cache_lock:
        if cache_key in _partition_cache:
            ts, result = _partition_cache[cache_key]
            if _time.time() - ts < _PARTITION_L1_TTL:
                return True, result
    return False, None


def _partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    import time as _time
    with _partition_cache_lock:
        if len(_partition_cache) >= _PARTITION_CACHE_MAX:
            oldest = min(_partition_cache, key=lambda k: _partition_cache[k][0])
            del _partition_cache[oldest]
        _partition_cache[cache_key] = (_time.time(), result)


def _partition_l2_get(connection_id: int, table_name: str, scan_type: str):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = db_manager.get_partition_cache(connection_id, table_name, scan_type)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _PARTITION_L2_TTL:
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def _partition_store(connection_id: int, table_name: str, scan_type: str,
                     cache_key: str, result: dict):
    """Store in both L1 + L2.  Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    _partition_l1_set(cache_key, stamped)
    db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped)


@app.get("/api/connections/{connection_id}/tables/{table_name}/partitions")
async def get_registered_table_partitions(
    connection_id: int, table_name: str, refresh: bool = False, full_scan: bool = False,
):
    """Get available partition values for a registered Iceberg table.

    Two-tier cache:
      L1 in-memory (5 min) — instant response for repeated requests
      L2 SQLite (5 hours) — survives server restarts, avoids S3 re-scans
    Pass ?refresh=true to force re-scan from S3.
    Pass ?full_scan=true to read individual manifest files for exact combos.
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    if table_def.get("format") != "iceberg":
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    bucket = config["bucket_name"]
    scan_type = "full" if full_scan else "fast"
    cache_key = f"{connection_id}:{table_name}::{scan_type}"

    if not refresh:
        # L1 check
        hit, cached = _partition_l1_get(cache_key)
        if hit:
            logger.debug("Partition L1 hit for %s", cache_key)
            return cached
        # L2 check
        hit, cached, _ts = _partition_l2_get(connection_id, table_name, scan_type)
        if hit:
            logger.debug("Partition L2 hit for %s", cache_key)
            _partition_l1_set(cache_key, cached)
            return cached

    def _do():
        from core.iceberg_reader import get_iceberg_partition_values
        s3 = _make_s3_client_for_conn(conn_raw)
        result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=full_scan)
        _partition_store(connection_id, table_name, scan_type, cache_key, result)
        return {**result, "cached_at": datetime.now(timezone.utc).isoformat()}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error getting partition values for %s: %s", table_name, e)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/tables/{table_name}/partitions/refresh")
async def refresh_partition_cache(connection_id: int, table_name: str):
    """Force re-scan partition metadata from S3 and update both caches.

    Runs a full_scan to get exact partition combos.
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    if table_def.get("format") != "iceberg":
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    bucket = config["bucket_name"]

    def _do():
        from core.iceberg_reader import get_iceberg_partition_values
        s3 = _make_s3_client_for_conn(conn_raw)
        # Run full scan for exact combos
        result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=True)
        # Store both fast + full in caches (full result is a superset)
        now_iso = datetime.now(timezone.utc).isoformat()
        for stype in ("fast", "full"):
            ck = f"{connection_id}:{table_name}::{stype}"
            _partition_store(connection_id, table_name, stype, ck, result)
        return {**result, "cached_at": now_iso}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error refreshing partition cache for %s: %s", table_name, e)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/discover-tables")
async def discover_tables(connection_id: int, prefix: str = "", max_depth: int = 4):
    """Discover tables by scanning S3 — prioritizes Iceberg metadata.

    Strategy:
      1. If iceberg_warehouse_path is set, scan that path for Iceberg tables first.
      2. Then scan from root_prefix (or given prefix) recursively up to max_depth.
      3. For Iceberg tables, read metadata to get row count + file count.
      4. For parquet/csv folders, report format detection.
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support table discovery")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    iceberg_warehouse = (config.get("iceberg_warehouse_path") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )
    existing_names = {t["name"] for t in config.get("registered_tables", [])}

    def _do():
        from core.iceberg_reader import is_iceberg_table
        s3 = _make_s3_client_for_conn(conn_raw)

        candidates = []
        seen_prefixes = set()  # avoid duplicates between iceberg scan and general scan

        def _build_table_name(folder_prefix: str) -> str:
            """Build a qualified table name from the S3 prefix path.

            Strips root_prefix and iceberg_warehouse_path, then joins
            remaining path segments with dots.
            E.g. root='', warehouse='', prefix='catalog/schema1/'
              → 'catalog.schema1'
            E.g. root='data/', warehouse='data/catalog/', prefix='data/catalog/schema1/'
              → 'schema1'
            """
            path = folder_prefix.rstrip("/")
            # Strip root prefix
            if root_prefix and path.startswith(root_prefix):
                path = path[len(root_prefix):].lstrip("/")
            # Strip iceberg warehouse prefix
            if iceberg_warehouse and path.startswith(iceberg_warehouse):
                path = path[len(iceberg_warehouse):].lstrip("/")
            parts = [p for p in path.split("/") if p]
            if len(parts) <= 1:
                return parts[0] if parts else folder_prefix.rstrip("/").split("/")[-1]
            # Use dot-separated qualified name (e.g. catalog.schema)
            return ".".join(parts)

        def _add_iceberg_candidate(folder_prefix: str):
            """Add an Iceberg table candidate with metadata enrichment."""
            if folder_prefix in seen_prefixes:
                return
            name = _build_table_name(folder_prefix)
            if name in existing_names:
                return
            seen_prefixes.add(folder_prefix)

            desc = ""
            try:
                from core.iceberg_reader import get_iceberg_data_files, _latest_metadata_key, _read_s3_json
                data_files = get_iceberg_data_files(s3, bucket, folder_prefix)
                # Read format version from metadata
                meta_prefix = folder_prefix.rstrip("/") + "/metadata/"
                meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
                metadata = _read_s3_json(s3, bucket, meta_key)
                fmt_ver = metadata.get("format-version", 1)
                desc = f"{len(data_files)} files · v{fmt_ver}"
            except Exception as e:
                logger.error("Iceberg metadata enrichment failed for %s: %s", folder_prefix, e, exc_info=True)
                desc = f"Iceberg table (metadata read failed: {str(e)[:60]})"

            candidates.append({
                "name": name,
                "s3_prefix": folder_prefix,
                "format": "iceberg",
                "description": desc,
            })

        # ── Phase 1: Scan iceberg_warehouse_path for Iceberg tables ────────
        if iceberg_warehouse:
            wh_prefix = f"{iceberg_warehouse}/"
            logger.info("Discover: scanning Iceberg warehouse at %s", wh_prefix)

            def _scan_iceberg_warehouse(scan_prefix: str, depth: int):
                if depth > max_depth or len(candidates) >= 50:
                    return
                paginator = s3.get_paginator("list_objects_v2")
                for page in paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/"):
                    for cp in page.get("CommonPrefixes", []):
                        if len(candidates) >= 50:
                            return
                        fp = cp["Prefix"]
                        name = fp.rstrip("/").split("/")[-1]
                        if name.startswith(".") or name.startswith("_") or name == "metadata":
                            continue
                        if is_iceberg_table(s3, bucket, fp):
                            _add_iceberg_candidate(fp)
                        else:
                            # Might be a database/schema level — recurse
                            _scan_iceberg_warehouse(fp, depth + 1)

            _scan_iceberg_warehouse(wh_prefix, 1)

        # ── Phase 2: General scan from root_prefix ─────────────────────────
        def _scan_level(scan_prefix: str, depth: int):
            if depth > max_depth or len(candidates) >= 50:
                return
            if scan_prefix in seen_prefixes:
                return

            paginator = s3.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/")

            for page in pages:
                for cp in page.get("CommonPrefixes", []):
                    if len(candidates) >= 50:
                        return
                    folder_prefix = cp["Prefix"]
                    name = folder_prefix.rstrip("/").split("/")[-1]

                    # Skip hidden/internal folders, but NOT "data" — it's a common
                    # top-level folder name.  "metadata" is only Iceberg internals.
                    if name.startswith(".") or name.startswith("_") or name == "metadata":
                        continue
                    if folder_prefix in seen_prefixes:
                        continue

                    # Skip date-partition folders (e.g. dt=2024-01-01, year=2024)
                    if "=" in name:
                        continue

                    if is_iceberg_table(s3, bucket, folder_prefix):
                        _add_iceberg_candidate(folder_prefix)
                        continue

                    # Check for DIRECT data files at this level only (use Delimiter)
                    try:
                        peek = s3.list_objects_v2(
                            Bucket=bucket, Prefix=folder_prefix, Delimiter="/", MaxKeys=50
                        )
                    except Exception as peek_err:
                        logger.warning("Discover: failed to peek %s: %s", folder_prefix, peek_err)
                        continue

                    has_subfolders = len(peek.get("CommonPrefixes", [])) > 0
                    fmt = "unknown"
                    for obj in peek.get("Contents", []):
                        key = obj["Key"].lower()
                        if key.endswith(".parquet"):
                            fmt = "parquet"
                            break
                        if key.endswith(".csv"):
                            fmt = "csv"
                            break

                    if has_subfolders and fmt == "unknown":
                        # Has subfolders but no direct data files → container, recurse
                        _scan_level(folder_prefix, depth + 1)
                    elif fmt != "unknown" and not has_subfolders:
                        # Leaf folder with data files → register as table
                        qual_name = _build_table_name(folder_prefix)
                        if qual_name in existing_names:
                            continue
                        seen_prefixes.add(folder_prefix)
                        candidates.append({
                            "name": qual_name,
                            "s3_prefix": folder_prefix,
                            "format": fmt,
                            "description": f"{fmt.title()} files at {folder_prefix}",
                        })
                    elif has_subfolders:
                        # Has both subfolders and data files → recurse deeper
                        # (the data files might be in a partition structure)
                        _scan_level(folder_prefix, depth + 1)
                    else:
                        # No data, no subfolders → skip
                        pass

        _scan_level(effective_prefix, 1)
        return {"candidates": candidates, "prefix": effective_prefix}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error discovering tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/browse-folders")
async def browse_s3_folders(connection_id: int, prefix: str = ""):
    """Browse S3 folders one level at a time. Returns subfolders and file counts.

    Used by the frontend to let users visually pick an S3 prefix for table registration.
    """
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support folder browsing")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(
            Bucket=bucket, Prefix=effective_prefix, Delimiter="/"
        )

        folders = []
        file_summary = {"parquet": 0, "csv": 0, "other": 0}

        for page in pages:
            for cp in page.get("CommonPrefixes", []):
                fp = cp["Prefix"]
                name = fp.rstrip("/").split("/")[-1]
                if not name.startswith("."):
                    # Strip root_prefix for display
                    display_path = fp
                    if root_prefix and display_path.startswith(root_prefix):
                        display_path = display_path[len(root_prefix):].lstrip("/")
                    folders.append({"name": name, "prefix": fp, "display_path": display_path})

            for obj in page.get("Contents", []):
                key = obj["Key"].lower()
                if key.endswith(".parquet"):
                    file_summary["parquet"] += 1
                elif key.endswith(".csv"):
                    file_summary["csv"] += 1
                else:
                    file_summary["other"] += 1

        # Detect if current prefix looks like an iceberg table
        is_iceberg = False
        try:
            from core.iceberg_reader import is_iceberg_table
            is_iceberg = is_iceberg_table(s3, bucket, effective_prefix)
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

        return {
            "prefix": effective_prefix,
            "folders": folders,
            "file_summary": file_summary,
            "is_iceberg": is_iceberg,
        }

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error browsing S3 folders: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/iceberg/tables")
async def list_iceberg_tables(connection_id: int, prefix: str = ""):
    """
    Scan an S3 prefix for Iceberg table directories — runs in thread (S3 listing is blocking).
    Returns list of {name, prefix, type='iceberg_table', path} dicts.
    """
    from core.iceberg_reader import list_iceberg_tables as _list_iceberg_tables
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']
    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        tables = _list_iceberg_tables(s3, bucket, prefix)
        return {"tables": tables, "bucket": bucket, "prefix": prefix}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error listing Iceberg tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/iceberg/files")
async def list_iceberg_files(
    connection_id: int,
    table_prefix: str,
    partition_filter: Optional[str] = None,   # JSON: [{"col":"business_date","op":"equals","val":"${today}"}]
):
    """
    Read an Iceberg table's metadata chain — runs in thread (Avro + S3 reads are blocking).
    Returns list of {key, name, path, size_bytes, last_modified, folder, type='parquet'}.

    Optional partition_filter (JSON array) enables server-side manifest pruning so only
    files for the relevant partition(s) are returned.  Date expressions (${today}, etc.)
    in filter values are resolved at request time.
    """
    from core.iceberg_reader import get_iceberg_data_files
    from core.date_resolver import resolve_filter_dates
    import json as _json

    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']

    pfilters = None
    if partition_filter:
        try:
            pfilters = resolve_filter_dates(_json.loads(partition_filter))
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        files = get_iceberg_data_files(s3, bucket, table_prefix, partition_filters=pfilters)
        return {"files": files, "bucket": bucket, "table_prefix": table_prefix, "count": len(files)}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error reading Iceberg data files: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=_auth_cfg)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_reports_auth(_auth_cfg)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_schedules_auth(_auth_cfg)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Initialise unified worker pool
    from core.config import worker_pool as _wp_cfg
    from core.worker_pool import init_pool
    init_pool(
        total_workers=_wp_cfg.total_workers,
        type_configs=_wp_cfg.build_type_configs(),
        drain_timeout=_wp_cfg.drain_timeout_seconds,
    )

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # Start APScheduler (non-fatal — server starts regardless)
    from core.scheduler import init_scheduler
    import threading as _threading

    def _start_scheduler():
        try:
            init_scheduler(db_manager, ws_manager, loop,
                           db_url=_DB_URL)
        except Exception as exc:
            logger.error("APScheduler startup failed (non-fatal): %s", exc, exc_info=True)

    _threading.Thread(target=_start_scheduler, daemon=True).start()

    # Mark any executions stuck in "running" state as failed.
    # These are orphaned by a previous server crash or forced restart.
    try:
        stuck = db_manager.list_executions(status="running", limit=1000, offset=0)
        for ex in stuck:
            db_manager.update_execution(
                ex["execution_id"],
                status="failed",
                error_message="Server restarted while execution was in progress",
            )
        if stuck:
            logger.warning(
                "Startup: marked %d orphaned 'running' execution(s) as failed", len(stuck)
            )
    except Exception as _e:
        logger.warning("Startup: orphan execution cleanup failed: %s", _e)

    # Auto-migrate plain-text passwords → PBKDF2 hashes
    if _auth_cfg.type == "local":
        _migrate_plaintext_passwords()


def _migrate_plaintext_passwords():
    """One-time migration: hash any plain-text passwords found in config.json."""
    import json as _json
    from core.ad_auth import hash_password as _hash_pw, _PBKDF2_PREFIX

    config_file = Path(__file__).resolve().parent / "config.json"
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = _json.load(f)
    except Exception:
        return

    raw_users = cfg.get("auth", {}).get("local_users", "")
    if not raw_users:
        return

    users_dict = {}
    migrated_count = 0
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            u, p = u.strip(), p.strip()
            if not p.startswith(_PBKDF2_PREFIX):
                users_dict[u] = _hash_pw(p)
                migrated_count += 1
            else:
                users_dict[u] = p

    if migrated_count > 0:
        cfg["auth"]["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
        with open(config_file, "w", encoding="utf-8") as f:
            _json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Reload in-memory config
        from core import config as _config_mod
        _config_mod._file_cfg = _config_mod._load_file()
        _config_mod._merged = _config_mod._deep_merge(_config_mod._DEFAULTS, _config_mod._file_cfg)
        _config_mod._cfg = _config_mod._apply_env(_config_mod._merged)
        logger.info("Migrated %d plain-text password(s) to PBKDF2 hashes", migrated_count)


@app.on_event("shutdown")
async def _shutdown():
    logger.info("Shutdown: draining %d in-flight queries (10 s grace)…", len(_running_tasks))
    # Signal all threads to stop at next chunk boundary
    for _ev in list(_cancellation_flags.values()):
        _ev.set()
    # Cancel all asyncio tasks
    _pending = [t for t in _running_tasks.values() if not t.done()]
    for t in _pending:
        t.cancel()
    if _pending:
        await asyncio.gather(*_pending, return_exceptions=True)

    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()
    query_executor.shutdown(wait=True, cancel_futures=True)

    # Shut down the unified worker pool
    from core.worker_pool import get_pool
    try:
        await get_pool().shutdown()
    except RuntimeError:
        pass  # pool not initialised (tests, etc.)


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        logger.warning("WebSocket connection closed unexpectedly: %s", e)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    await _handle_ws(websocket)


# ── SPA catch-all — MUST be the last HTTP route registered ───────────────────
# Serves index.html for all browser navigation routes that don't match any API
# endpoint.  WebSocket routes (/ws) are unaffected (different protocol).
if _STATIC_DIR:
    @app.get("/", include_in_schema=False)
    async def _spa_root():
        return FileResponse(str(_STATIC_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def _spa_catch_all(full_path: str):
        return FileResponse(str(_STATIC_DIR / "index.html"))
else:
    @app.get("/")
    async def _api_root():
        return {
            "name": "QueryStudio API",
            "version": "2.0.0",
            "status": "operational",
            "note": "Build the frontend (`npm run build` in frontend/) to enable SPA serving.",
        }


if __name__ == "__main__":
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    uvicorn.run(
        app,
        host=_server_cfg.host,
        port=_server_cfg.port,
        log_level=_server_cfg.log_level,
        workers=_server_cfg.workers,
    )
