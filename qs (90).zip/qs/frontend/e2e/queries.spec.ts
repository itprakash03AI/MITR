/**
 * Phase 71A — Query builder E2E workflow tests.
 * Tests: create connection → save query → list queries → delete.
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Query Workflow', () => {
  let connId: number | null = null;
  let queryId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (queryId) {
      await page.request.delete(`${BASE}/api/queries/saved/${queryId}`).catch(() => {});
      queryId = null;
    }
    if (connId) {
      await page.request.delete(`${BASE}/api/connections/${connId}`).catch(() => {});
      connId = null;
    }
  });

  test('should create a connection and save a query', async ({ page }) => {
    // Step 1: Create connection
    const connResp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E Query Conn',
        connection_type: 'local',
        config: { base_path: './data/parquet' },
      },
    });
    expect(connResp.ok()).toBeTruthy();
    const conn = await connResp.json();
    connId = conn.id;

    // Step 2: Save a query
    const saveResp = await page.request.post(`${BASE}/api/queries/saved`, {
      data: {
        name: 'E2E Test Query',
        description: 'Automated test query',
        connection_id: connId,
        query_config: { tables: [], columns: [], filters: [] },
      },
    });
    expect(saveResp.ok()).toBeTruthy();
    const saved = await saveResp.json();
    expect(saved.id).toBeTruthy();
    queryId = saved.id;
  });

  test('should list saved queries', async ({ page }) => {
    // Create connection + query
    const connResp = await page.request.post(`${BASE}/api/connections`, {
      data: { name: 'E2E List Queries', connection_type: 'local', config: { base_path: './data/parquet' } },
    });
    const conn = await connResp.json();
    connId = conn.id;

    const saveResp = await page.request.post(`${BASE}/api/queries/saved`, {
      data: { name: 'E2E Query List Test', connection_id: connId, query_config: {} },
    });
    const saved = await saveResp.json();
    queryId = saved.id;

    // List queries
    const listResp = await page.request.get(`${BASE}/api/queries/saved`);
    expect(listResp.ok()).toBeTruthy();
    const queries = await listResp.json();
    const found = queries.find((q: any) => q.id === queryId);
    expect(found).toBeTruthy();
    expect(found.name).toBe('E2E Query List Test');
  });

  test('should update a saved query', async ({ page }) => {
    const connResp = await page.request.post(`${BASE}/api/connections`, {
      data: { name: 'E2E Update Query', connection_type: 'local', config: { base_path: './data/parquet' } },
    });
    const conn = await connResp.json();
    connId = conn.id;

    const saveResp = await page.request.post(`${BASE}/api/queries/saved`, {
      data: { name: 'Original Name', connection_id: connId, query_config: {} },
    });
    const saved = await saveResp.json();
    queryId = saved.id;

    // Update
    const updateResp = await page.request.put(`${BASE}/api/queries/saved/${queryId}`, {
      data: { name: 'Updated Name', connection_id: connId, query_config: { updated: true } },
    });
    expect(updateResp.ok()).toBeTruthy();

    // Verify
    const getResp = await page.request.get(`${BASE}/api/queries/saved/${queryId}`);
    const updated = await getResp.json();
    expect(updated.name).toBe('Updated Name');
  });

  test('should delete a saved query', async ({ page }) => {
    const connResp = await page.request.post(`${BASE}/api/connections`, {
      data: { name: 'E2E Delete Query', connection_type: 'local', config: { base_path: './data/parquet' } },
    });
    const conn = await connResp.json();
    connId = conn.id;

    const saveResp = await page.request.post(`${BASE}/api/queries/saved`, {
      data: { name: 'To Delete', connection_id: connId, query_config: {} },
    });
    const saved = await saveResp.json();

    const delResp = await page.request.delete(`${BASE}/api/queries/saved/${saved.id}`);
    expect(delResp.ok()).toBeTruthy();
    queryId = null; // already deleted
  });
});
