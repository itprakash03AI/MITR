/**
 * Phase 71F — Business Portal + Settings E2E workflow tests.
 * Tests: portal summary, app settings, circuit breakers, cache management.
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Business Portal API', () => {
  test('should return portal summary', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/portal/summary`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body).toHaveProperty('total_reports');
    expect(body).toHaveProperty('recent_reports');
    expect(body).toHaveProperty('executions_today');
  });

  test('portal page should load', async ({ page }) => {
    await page.goto('/');
    // Business Portal should be the home page
    await page.waitForTimeout(2000);
    const content = page.locator('body');
    await expect(content).toBeVisible();
  });
});

test.describe('App Settings API', () => {
  test('should return app settings', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/app-settings`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body).toHaveProperty('auth_type');
    expect(body).toHaveProperty('component_visibility');
  });

  test('should return version info', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/version`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body).toHaveProperty('version');
  });
});

test.describe('Admin Config APIs', () => {
  test('should return circuit breaker states', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/circuit-breakers`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(Array.isArray(body)).toBe(true);
  });

  test('should return cache stats', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/cache/stats`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body).toHaveProperty('total_entries');
  });

  test('should return connection pool stats', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/connection-pools`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(Array.isArray(body)).toBe(true);
  });

  test('should return storage stats', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/storage`);
    expect(resp.ok()).toBeTruthy();
  });

  test('should return UI visibility config', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/admin/ui-visibility`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(Array.isArray(body)).toBe(true);
  });
});
