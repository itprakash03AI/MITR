/**
 * Phase 71D — Dataset management E2E workflow tests.
 * Tests: create dataset → list → get → auto-detect preview → delete.
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Dataset Workflow', () => {
  let datasetId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (datasetId) {
      await page.request.delete(`${BASE}/api/datasets/${datasetId}`).catch(() => {});
      datasetId = null;
    }
  });

  test('should create a dataset', async ({ page }) => {
    const resp = await page.request.post(`${BASE}/api/datasets`, {
      data: {
        name: 'E2E Test Dataset',
        subject_area: 'Testing',
        description: 'Created by E2E test',
      },
    });
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.id).toBeTruthy();
    expect(body.name).toBe('E2E Test Dataset');
    datasetId = body.id;
  });

  test('should list datasets including created one', async ({ page }) => {
    // Create
    const createResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E List Dataset', subject_area: 'Testing' },
    });
    const created = await createResp.json();
    datasetId = created.id;

    // List
    const listResp = await page.request.get(`${BASE}/api/datasets`);
    expect(listResp.ok()).toBeTruthy();
    const datasets = await listResp.json();
    const found = datasets.find((d: any) => d.id === datasetId);
    expect(found).toBeTruthy();
  });

  test('should get dataset by id', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Get Dataset', subject_area: 'Testing' },
    });
    const created = await createResp.json();
    datasetId = created.id;

    const getResp = await page.request.get(`${BASE}/api/datasets/${datasetId}`);
    expect(getResp.ok()).toBeTruthy();
    const body = await getResp.json();
    expect(body.name).toBe('E2E Get Dataset');
  });

  test('should add a column to a dataset', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Column Dataset', subject_area: 'Testing' },
    });
    const created = await createResp.json();
    datasetId = created.id;

    const colResp = await page.request.post(`${BASE}/api/datasets/${datasetId}/columns`, {
      data: {
        physical_name: 'amount',
        friendly_name: 'Amount',
        column_type: 'measure',
        data_type: 'numeric',
        aggregation: 'SUM',
      },
    });
    expect(colResp.ok()).toBeTruthy();
    const col = await colResp.json();
    expect(col.physical_name).toBe('amount');
  });

  test('should delete a dataset', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Delete Dataset', subject_area: 'Testing' },
    });
    const created = await createResp.json();

    const delResp = await page.request.delete(`${BASE}/api/datasets/${created.id}`);
    expect(delResp.ok()).toBeTruthy();
    datasetId = null;
  });
});
