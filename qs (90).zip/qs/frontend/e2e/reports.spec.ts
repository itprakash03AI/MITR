/**
 * Phase 71C — Report management E2E workflow tests.
 * Tests: create dataset + business report → list → update → delete.
 */
import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Business Report Workflow', () => {
  let datasetId: number | null = null;
  let reportId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (reportId) {
      await page.request.delete(`${BASE}/api/business-reports/${reportId}`).catch(() => {});
      reportId = null;
    }
    if (datasetId) {
      await page.request.delete(`${BASE}/api/datasets/${datasetId}`).catch(() => {});
      datasetId = null;
    }
  });

  test('should create a business report with a dataset', async ({ page }) => {
    // Create dataset first
    const dsResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Report Dataset', subject_area: 'Testing' },
    });
    expect(dsResp.ok()).toBeTruthy();
    const ds = await dsResp.json();
    datasetId = ds.id;

    // Create business report
    const resp = await page.request.post(`${BASE}/api/business-reports`, {
      data: {
        name: 'E2E Test Report',
        dataset_id: datasetId,
        description: 'Created by E2E test',
      },
    });
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.id).toBeTruthy();
    expect(body.name).toBe('E2E Test Report');
    reportId = body.id;
  });

  test('should list business reports', async ({ page }) => {
    const dsResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E List Report DS', subject_area: 'Testing' },
    });
    const ds = await dsResp.json();
    datasetId = ds.id;

    const createResp = await page.request.post(`${BASE}/api/business-reports`, {
      data: { name: 'E2E List Report', dataset_id: datasetId },
    });
    const created = await createResp.json();
    reportId = created.id;

    const listResp = await page.request.get(`${BASE}/api/business-reports`);
    expect(listResp.ok()).toBeTruthy();
    const reports = await listResp.json();
    const found = reports.find((r: any) => r.id === reportId);
    expect(found).toBeTruthy();
  });

  test('should update a business report', async ({ page }) => {
    const dsResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Update Report DS', subject_area: 'Testing' },
    });
    const ds = await dsResp.json();
    datasetId = ds.id;

    const createResp = await page.request.post(`${BASE}/api/business-reports`, {
      data: { name: 'Original Report', dataset_id: datasetId },
    });
    const created = await createResp.json();
    reportId = created.id;

    const updateResp = await page.request.put(`${BASE}/api/business-reports/${reportId}`, {
      data: { name: 'Renamed Report', description: 'Updated by E2E' },
    });
    expect(updateResp.ok()).toBeTruthy();

    const getResp = await page.request.get(`${BASE}/api/business-reports/${reportId}`);
    const updated = await getResp.json();
    expect(updated.name).toBe('Renamed Report');
  });

  test('should delete a business report', async ({ page }) => {
    const dsResp = await page.request.post(`${BASE}/api/datasets`, {
      data: { name: 'E2E Delete Report DS', subject_area: 'Testing' },
    });
    const ds = await dsResp.json();
    datasetId = ds.id;

    const createResp = await page.request.post(`${BASE}/api/business-reports`, {
      data: { name: 'To Delete Report', dataset_id: datasetId },
    });
    const created = await createResp.json();

    const delResp = await page.request.delete(`${BASE}/api/business-reports/${created.id}`);
    expect(delResp.ok()).toBeTruthy();
    reportId = null;
  });
});

test.describe('Report Catalog API', () => {
  test('should list report catalog folders', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/catalog/folders`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(Array.isArray(body)).toBe(true);
  });

  test('should list report catalog tags', async ({ page }) => {
    const resp = await page.request.get(`${BASE}/api/catalog/tags`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(Array.isArray(body)).toBe(true);
  });
});
