import React from 'react';
import {
  Box, Typography, Button, Card, CardContent, Dialog, DialogTitle,
  DialogContent, DialogActions, Checkbox, Chip, Stack,
} from '@mui/material';
import {
  TableChart as TableIcon, Warning as WarningIcon,
} from '@mui/icons-material';

interface TableSelectorModalProps {
  open: boolean;
  files: any[];
  selectedTables: any[];
  onUpdate: (tables: any[]) => void;
  onClose: () => void;
}

const TableSelectorModal = ({ open, files, selectedTables, onUpdate, onClose }: TableSelectorModalProps) => {
  const toggleTable = (file: any) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      onUpdate(selectedTables.filter(t => t.path !== file.path));
    } else {
      onUpdate([...selectedTables, file]);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TableIcon />
          <span>Select Tables</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={1}>
          {files.length === 0 && (
            <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
              No parquet files found in this data source.
            </Typography>
          )}
          {files.map(file => {
            const isSelected = selectedTables.find(t => t.path === file.path);
            return (
              <Card
                key={file.path}
                variant="outlined"
                sx={{
                  cursor: 'pointer',
                  bgcolor: isSelected ? 'action.selected' : 'background.paper',
                  borderColor: isSelected ? 'primary.main' : 'divider',
                  '&:hover': { bgcolor: 'action.hover' },
                }}
                onClick={() => toggleTable(file)}
              >
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 1.5, py: 1.5, '&:last-child': { pb: 1.5 } }}>
                  <Checkbox checked={!!isSelected} readOnly />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium' }}>
                      {file.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                      {file.folder && (
                        <Typography variant="body2" color="text.disabled" sx={{ fontSize: 11 }}>
                          {file.folder}/
                        </Typography>
                      )}
                      <Typography variant="body2" color="text.secondary">
                        {file.num_rows?.toLocaleString()} rows &middot; {file.num_columns} cols
                      </Typography>
                      {file.num_rows > 1000000 && (
                        <Chip
                          icon={<WarningIcon />}
                          label="Large"
                          size="small"
                          color="warning"
                          variant="outlined"
                        />
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            );
          })}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedTables.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default TableSelectorModal;
