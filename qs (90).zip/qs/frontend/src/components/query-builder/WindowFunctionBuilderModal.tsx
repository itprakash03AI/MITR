import React from 'react';
import {
  Box, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Chip, IconButton, Stack,
  Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Close as CloseIcon,
  AccountTree as WindowIcon,
} from '@mui/icons-material';
import { WINDOW_FNS, WINDOW_NO_COL } from './types';

interface WindowFunctionBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  windowFunctions: any[];
  onUpdate: (fns: any[]) => void;
  onClose: () => void;
}

const WindowFunctionBuilderModal = ({ open, tables, schemas, windowFunctions, onUpdate, onClose }: WindowFunctionBuilderModalProps) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(windowFunctions.length > 0 ? windowFunctions.map(wf => ({ ...wf })) : []); }, [open]); // eslint-disable-line

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => setLocal(prev => [...prev, {
    function: 'ROW_NUMBER', alias: '', column: '', partition_by: [], order_by: [{ column: allCols[0] || '', direction: 'ASC' }],
    offset: 1, default_value: '',
  }]);
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: any) => setLocal(prev => prev.map((wf, idx) => idx === i ? { ...wf, [field]: val } : wf));

  const addOrderBy = (i: number) => {
    const updated = [...local];
    updated[i] = { ...updated[i], order_by: [...(updated[i].order_by || []), { column: allCols[0] || '', direction: 'ASC' }] };
    setLocal(updated);
  };
  const removeOrderBy = (wi: number, oi: number) => {
    const updated = [...local];
    updated[wi] = { ...updated[wi], order_by: updated[wi].order_by.filter((_: any, j: number) => j !== oi) };
    setLocal(updated);
  };
  const updateOrderBy = (wi: number, oi: number, field: string, val: string) => {
    const updated = [...local];
    updated[wi] = { ...updated[wi], order_by: updated[wi].order_by.map((o: any, j: number) => j === oi ? { ...o, [field]: val } : o) };
    setLocal(updated);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><WindowIcon color="info" /> Window Functions</Box></DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          {local.map((wf, wi) => (
            <Paper key={wi} variant="outlined" sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', gap: 1, mb: 1.5, alignItems: 'center', flexWrap: 'wrap' }}>
                <TextField select size="small" label="Function" value={wf.function} sx={{ minWidth: 130 }}
                  onChange={e => update(wi, 'function', e.target.value)}>
                  {WINDOW_FNS.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
                </TextField>
                {!WINDOW_NO_COL.has(wf.function) && (
                  <TextField select size="small" label="Column" value={wf.column || ''} sx={{ minWidth: 140 }}
                    onChange={e => update(wi, 'column', e.target.value)}>
                    <MenuItem value="">-- select --</MenuItem>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                )}
                {['LAG', 'LEAD'].includes(wf.function) && (
                  <>
                    <TextField size="small" label="Offset" type="number" value={wf.offset || 1} sx={{ width: 80 }}
                      onChange={e => update(wi, 'offset', parseInt(e.target.value) || 1)} />
                    <TextField size="small" label="Default" value={wf.default_value || ''} sx={{ width: 100 }}
                      onChange={e => update(wi, 'default_value', e.target.value)} />
                  </>
                )}
                <Typography variant="body2" color="text.secondary">AS</Typography>
                <TextField size="small" label="Alias" value={wf.alias} sx={{ minWidth: 130 }}
                  placeholder="e.g. row_num" onChange={e => update(wi, 'alias', e.target.value)} />
                <Box sx={{ flex: 1 }} />
                <IconButton size="small" color="error" onClick={() => remove(wi)}><DeleteIcon fontSize="small" /></IconButton>
              </Box>
              {/* PARTITION BY */}
              <Box sx={{ mb: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 700 }}>PARTITION BY</Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.5 }}>
                  {allCols.map(c => (
                    <Chip key={c} label={c} size="small" variant={(wf.partition_by || []).includes(c) ? 'filled' : 'outlined'}
                      color={(wf.partition_by || []).includes(c) ? 'primary' : 'default'}
                      onClick={() => {
                        const pb = wf.partition_by || [];
                        update(wi, 'partition_by', pb.includes(c) ? pb.filter((x: string) => x !== c) : [...pb, c]);
                      }}
                      sx={{ cursor: 'pointer' }} />
                  ))}
                </Box>
              </Box>
              {/* ORDER BY */}
              <Typography variant="caption" sx={{ fontWeight: 700 }}>ORDER BY</Typography>
              {(wf.order_by || []).map((o: any, oi: number) => (
                <Box key={oi} sx={{ display: 'flex', gap: 0.75, alignItems: 'center', mt: 0.5 }}>
                  <TextField select size="small" value={o.column} sx={{ minWidth: 120 }}
                    onChange={e => updateOrderBy(wi, oi, 'column', e.target.value)}>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" value={o.direction} sx={{ minWidth: 80 }}
                    onChange={e => updateOrderBy(wi, oi, 'direction', e.target.value)}>
                    <MenuItem value="ASC">ASC</MenuItem>
                    <MenuItem value="DESC">DESC</MenuItem>
                  </TextField>
                  <IconButton size="small" onClick={() => removeOrderBy(wi, oi)}><CloseIcon sx={{ fontSize: 14 }} /></IconButton>
                </Box>
              ))}
              <Button size="small" onClick={() => addOrderBy(wi)} sx={{ mt: 0.5 }}>+ Order By</Button>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add Window Function
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(wf => wf.alias)); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

export default WindowFunctionBuilderModal;
