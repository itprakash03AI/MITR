import React, { useState } from 'react';
import {
  Box, Typography, Button, ButtonGroup, Paper, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, MenuItem, IconButton, Stack,
  Autocomplete,
} from '@mui/material';
import {
  FilterAlt as FilterIcon, Save as SaveIcon, Add as AddIcon,
  Delete as DeleteIcon, Edit as EditIcon,
} from '@mui/icons-material';
import { FILTER_OPS, NO_VALUE_OPS, LIST_OPS } from './types';

interface FilterBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  filters: any[];
  filterLogic: string;
  onFilterLogicChange: (logic: string) => void;
  onUpdate: (filters: any[]) => void;
  onClose: () => void;
}

const FilterBuilderModal = ({ open, tables, schemas, filters, filterLogic, onFilterLogicChange, onUpdate, onClose }: FilterBuilderModalProps) => {
  const [editingFilter, setEditingFilter] = useState<number | null>(null);
  const [newFilter, setNewFilter] = useState<any>({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' });

  const allColumns = tables.flatMap(t =>
    (schemas[t.path] || []).map(c => ({ table: t.name, column: c.name, type: c.type }))
  ).sort((a, b) => a.column.localeCompare(b.column));

  const addFilter = () => {
    const noValue = NO_VALUE_OPS.has(newFilter.operator);
    if (!newFilter.column || (!noValue && newFilter.operator !== 'between' && !newFilter.value)) {
      alert('Please fill all required fields');
      return;
    }
    if (newFilter.operator === 'between' && (!newFilter.value_low || !newFilter.value_high)) {
      alert('BETWEEN requires both low and high values');
      return;
    }
    if (editingFilter !== null) {
      const updated = [...filters];
      updated[editingFilter] = { ...newFilter, id: filters[editingFilter].id };
      onUpdate(updated);
      setEditingFilter(null);
    } else {
      onUpdate([...filters, { ...newFilter, id: Date.now() }]);
    }
    setNewFilter({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' });
  };

  const editFilter = (index: number) => { setEditingFilter(index); setNewFilter({ ...filters[index] }); };
  const deleteFilter = (index: number) => {
    if (window.confirm('Delete this filter?')) onUpdate(filters.filter((_, i) => i !== index));
  };

  const fmtFilter = (f: any) => {
    const opLabel: Record<string, string> = { eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=',
      in: 'IN', not_in: 'NOT IN', contains: 'LIKE', not_contains: 'NOT LIKE',
      between: 'BETWEEN', is_null: 'IS NULL', is_not_null: 'IS NOT NULL' };
    const op = opLabel[f.operator] || f.operator;
    if (NO_VALUE_OPS.has(f.operator)) return `${f.column} ${op}`;
    if (f.operator === 'between') return `${f.column} ${op} ${f.value_low} AND ${f.value_high}`;
    return `${f.column} ${op} ${f.value}`;
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <FilterIcon />
          <span>Filters (WHERE)</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Typography variant="subtitle2">Combine filters with:</Typography>
          <ButtonGroup size="small">
            <Button variant={filterLogic === 'AND' ? 'contained' : 'outlined'}
              onClick={() => onFilterLogicChange('AND')}>AND</Button>
            <Button variant={filterLogic === 'OR' ? 'contained' : 'outlined'}
              color="warning" onClick={() => onFilterLogicChange('OR')}>OR</Button>
          </ButtonGroup>
        </Box>

        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
            {editingFilter !== null ? 'Edit Filter' : 'Add Filter'}
          </Typography>
          <Stack spacing={1.5}>
            <Autocomplete
              options={allColumns}
              getOptionLabel={col => `${col.table}.${col.column}`}
              value={allColumns.find(c => `${c.table}.${c.column}` === newFilter.column) || null}
              onChange={(_, val) => setNewFilter({ ...newFilter, column: val ? `${val.table}.${val.column}` : '' })}
              renderOption={(props, col) => (
                <li {...props} key={`${col.table}.${col.column}`}>
                  <Typography variant="body2">{col.table}.{col.column}</Typography>
                  <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>({col.type})</Typography>
                </li>
              )}
              renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search columns..." />}
              size="small"
              fullWidth
            />
            <TextField select label="Operator" fullWidth size="small"
              value={newFilter.operator} onChange={e => setNewFilter({ ...newFilter, operator: e.target.value })}>
              {FILTER_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
            </TextField>
            {!NO_VALUE_OPS.has(newFilter.operator) && (
              newFilter.operator === 'between' ? (
                <Stack direction="row" spacing={1}>
                  <TextField label="Low value" size="small" fullWidth value={newFilter.value_low || ''}
                    onChange={e => setNewFilter({ ...newFilter, value_low: e.target.value })} />
                  <TextField label="High value" size="small" fullWidth value={newFilter.value_high || ''}
                    onChange={e => setNewFilter({ ...newFilter, value_high: e.target.value })} />
                </Stack>
              ) : (
                <TextField label="Value" fullWidth size="small" value={newFilter.value}
                  onChange={e => setNewFilter({ ...newFilter, value: e.target.value })}
                  placeholder={LIST_OPS.has(newFilter.operator) ? 'val1, val2, val3' : 'value'} />
              )
            )}
          </Stack>
          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 1.5 }}>
            {editingFilter !== null && (
              <Button variant="outlined" size="small"
                onClick={() => { setEditingFilter(null); setNewFilter({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' }); }}>
                Cancel
              </Button>
            )}
            <Button variant="contained" size="small" onClick={addFilter}
              startIcon={editingFilter !== null ? <SaveIcon /> : <AddIcon />}>
              {editingFilter !== null ? 'Update' : 'Add'}
            </Button>
          </Stack>
        </Paper>

        {filters.length > 0 && (
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Active Filters ({filters.length})</Typography>
            <Stack spacing={0.5}>
              {filters.map((filter, index) => (
                <React.Fragment key={filter.id}>
                  {index > 0 && (
                    <Typography variant="caption" color="primary" sx={{ textAlign: 'center', fontWeight: 700 }}>
                      {filterLogic}
                    </Typography>
                  )}
                  <Paper variant="outlined" sx={{ p: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                      {fmtFilter(filter)}
                    </Typography>
                    <Box>
                      <IconButton size="small" onClick={() => editFilter(index)} color="primary"><EditIcon sx={{ fontSize: 16 }} /></IconButton>
                      <IconButton size="small" onClick={() => deleteFilter(index)} color="error"><DeleteIcon sx={{ fontSize: 16 }} /></IconButton>
                    </Box>
                  </Paper>
                </React.Fragment>
              ))}
            </Stack>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

export default FilterBuilderModal;
