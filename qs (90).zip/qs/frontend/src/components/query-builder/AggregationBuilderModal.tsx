import React from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Checkbox, FormControlLabel, Chip,
  IconButton, Alert, Stack, Divider, Autocomplete,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Functions as AggIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { suggestAggFunction } from '../../services/columnIntelligence';
import { isNumericCol, AGG_FUNCS_NUMERIC, AGG_FUNCS_ANY } from './types';

interface AggregationBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  selectedColumns: any[];
  aggregations: any[];
  onUpdate: (aggs: any[]) => void;
  onClose: () => void;
}

const AggregationBuilderModal = ({ open, tables, schemas, selectedColumns, aggregations, onUpdate, onClose }: AggregationBuilderModalProps) => {
  const [localAggs, setLocalAggs] = React.useState<any[]>([]);
  const [aggCorrections, setAggCorrections] = React.useState<Map<string, { fn: string; distinct?: boolean }>>(new Map());

  React.useEffect(() => {
    if (open) setLocalAggs(aggregations.length > 0 ? [...aggregations] : []);
  }, [open]); // eslint-disable-line

  React.useEffect(() => {
    if (!open) return;
    (api as any).getAggCorrections().then((res: any) => {
      const map = new Map<string, { fn: string; distinct?: boolean }>();
      for (const c of (res?.corrections || [])) {
        const val = c.corrected_value;
        if (val === 'COUNT_DISTINCT') {
          map.set(c.context_key.toLowerCase(), { fn: 'COUNT', distinct: true });
        } else {
          map.set(c.context_key.toLowerCase(), { fn: val });
        }
      }
      setAggCorrections(map);
    }).catch(() => { /* ignore — use pattern fallback */ });
  }, [open]);

  const allCols = React.useMemo(() => {
    const cols: { table: string; name: string; type: string }[] = [];
    tables.forEach(t => {
      (schemas[t.path] || []).forEach(c => {
        cols.push({ table: t.name, name: c.name, type: c.type || '' });
      });
    });
    return cols;
  }, [tables, schemas]);

  const numericCols = allCols.filter(c => isNumericCol(c.type));

  const addAgg = () => {
    const first = numericCols[0] || allCols[0];
    if (!first) return;
    const suggestion = suggestAggFunction(first.name, first.type, aggCorrections);
    setLocalAggs(prev => [...prev, {
      column: first.name,
      function: suggestion.fn,
      alias: '',
      distinct: suggestion.distinct || false,
      _suggestedFn: suggestion.fn,
      _suggestedDistinct: suggestion.distinct || false,
      _source: suggestion.source,
    }]);
  };

  const removeAgg = (idx: number) => setLocalAggs(prev => prev.filter((_, i) => i !== idx));
  const updateAgg = (idx: number, field: string, val: string | boolean) => {
    setLocalAggs(prev => prev.map((a, i) => {
      if (i !== idx) return a;
      const updated = { ...a, [field]: val };
      if (field === 'column') {
        const col = allCols.find(c => c.name === val);
        if (col) {
          const suggestion = suggestAggFunction(col.name, col.type, aggCorrections);
          if (!isNumericCol(col.type) && suggestion.fn !== 'COUNT' && suggestion.fn !== 'MAX') {
            updated.function = 'COUNT';
            updated.distinct = false;
          } else {
            updated.function = suggestion.fn;
            updated.distinct = suggestion.distinct || false;
          }
          updated._suggestedFn = suggestion.fn;
          updated._suggestedDistinct = suggestion.distinct || false;
          updated._source = suggestion.source;
        }
      }
      if ((field === 'function' || field === 'distinct') && updated._suggestedFn) {
        const currentKey = updated.function + (updated.distinct ? '_DISTINCT' : '');
        const suggestedKey = updated._suggestedFn + (updated._suggestedDistinct ? '_DISTINCT' : '');
        if (currentKey !== suggestedKey) {
          const corrVal = updated.distinct && updated.function === 'COUNT'
            ? 'COUNT_DISTINCT' : updated.function;
          (api as any).saveSuggestionCorrection({
            correction_type: 'agg',
            context_key: updated.column.toLowerCase(),
            corrected_value: corrVal,
            original_value: suggestedKey,
            context_extra: allCols.find(c => c.name === updated.column)?.type || '',
          }).catch(() => {});
        }
      }
      return updated;
    }));
  };

  const handleDone = () => { onUpdate(localAggs); onClose(); };
  const handleClear = () => { setLocalAggs([]); onUpdate([]); onClose(); };

  const aggColSet = new Set(localAggs.map(a => a.column));
  const groupByCols = selectedColumns.filter(c => !aggColSet.has(c.columnName));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <AggIcon color="secondary" />
          <span>Aggregation — GROUP BY</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        {selectedColumns.length === 0 && (
          <Alert severity="info" sx={{ mb: 2 }}>Select columns first (via the Columns button), then define aggregations here.</Alert>
        )}

        <Typography variant="subtitle2" sx={{ mb: 1 }}>Aggregations</Typography>
        <Stack spacing={1.5} sx={{ mb: 3 }}>
          {localAggs.length === 0 && (
            <Typography variant="body2" color="text.secondary">No aggregations defined — click "Add Aggregation" below.</Typography>
          )}
          {localAggs.map((agg, idx) => {
            const col = allCols.find(c => c.name === agg.column);
            const isNum = col ? isNumericCol(col.type) : false;
            const funcs = isNum ? AGG_FUNCS_NUMERIC : AGG_FUNCS_ANY;
            return (
              <Paper key={idx} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
                <TextField
                  select size="small" label="Function" value={agg.function}
                  onChange={e => updateAgg(idx, 'function', e.target.value)}
                  sx={{ minWidth: 100 }}>
                  {funcs.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
                </TextField>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>(</Typography>
                <Autocomplete
                  options={allCols}
                  getOptionLabel={c => c.name}
                  getOptionDisabled={c => !isNumericCol(c.type) && agg.function !== 'COUNT'}
                  value={allCols.find(c => c.name === agg.column) || null}
                  onChange={(_, val) => updateAgg(idx, 'column', val?.name || '')}
                  renderOption={(props, c) => (
                    <li {...props} key={`${c.table}.${c.name}`}>
                      <Typography variant="body2">{c.name}</Typography>
                      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>{c.type}</Typography>
                    </li>
                  )}
                  renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search..." />}
                  size="small"
                  sx={{ minWidth: 180 }}
                />
                <Typography variant="body2" sx={{ fontWeight: 600 }}>)</Typography>
                {agg.function === 'COUNT' && (
                  <FormControlLabel
                    control={<Checkbox checked={agg.distinct || false} size="small"
                      onChange={e => updateAgg(idx, 'distinct', e.target.checked)} />}
                    label={<Typography variant="caption">DISTINCT</Typography>}
                    sx={{ ml: 0, mr: 0 }}
                  />
                )}
                <Typography variant="body2" color="text.secondary">AS</Typography>
                <TextField
                  size="small" label="Alias" value={agg.alias}
                  placeholder={`${agg.function.toLowerCase()}_${agg.column}`}
                  onChange={e => updateAgg(idx, 'alias', e.target.value)}
                  sx={{ minWidth: 150 }}
                />
                {agg._source && (
                  <Chip
                    size="small"
                    label={agg._source === 'correction' ? 'learned' : agg._source === 'pattern' ? 'suggested' : 'default'}
                    sx={{
                      fontSize: 9, height: 18,
                      bgcolor: agg._source === 'correction' ? '#dbeafe' : agg._source === 'pattern' ? '#f0fdf4' : '#f1f5f9',
                      color: agg._source === 'correction' ? '#1d4ed8' : agg._source === 'pattern' ? '#15803d' : '#64748b',
                      border: `1px solid ${agg._source === 'correction' ? '#bfdbfe' : agg._source === 'pattern' ? '#bbf7d0' : '#e2e8f0'}`,
                    }}
                  />
                )}
                <IconButton size="small" color="error" onClick={() => removeAgg(idx)}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Paper>
            );
          })}
          <Button size="small" startIcon={<AddIcon />} onClick={addAgg} variant="outlined"
            disabled={allCols.length === 0}
            sx={{ alignSelf: 'flex-start' }}>
            Add Aggregation
          </Button>
        </Stack>

        {localAggs.length > 0 && (
          <>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle2" sx={{ mb: 1 }}>GROUP BY (auto-derived)</Typography>
            {groupByCols.length > 0 ? (
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                {groupByCols.map(c => (
                  <Chip key={c.columnName} label={c.columnName} size="small" variant="outlined" />
                ))}
              </Box>
            ) : (
              <Alert severity="warning" sx={{ py: 0 }}>
                No GROUP BY columns — the query will return a single aggregated row.
                Select non-aggregated columns to group by.
              </Alert>
            )}
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              All selected columns that are <strong>not</strong> being aggregated automatically become GROUP BY columns.
            </Typography>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClear} color="warning" disabled={localAggs.length === 0}>Clear All</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" color="secondary" onClick={handleDone}>
          Done ({localAggs.length} aggregation{localAggs.length !== 1 ? 's' : ''})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AggregationBuilderModal;
