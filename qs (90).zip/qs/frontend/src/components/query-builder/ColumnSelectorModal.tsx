import React from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Checkbox, FormControlLabel, Stack, InputAdornment,
} from '@mui/material';
import {
  ViewColumn as ColumnIcon, Search as SearchIcon,
} from '@mui/icons-material';

interface ColumnSelectorModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  selectedColumns: any[];
  onUpdate: (cols: any[]) => void;
  onClose: () => void;
}

const ColumnSelectorModal = ({ open, tables, schemas, selectedColumns, onUpdate, onClose }: ColumnSelectorModalProps) => {
  const [colSearch, setColSearch] = React.useState('');

  const toggleColumn = (table: any, column: any) => {
    const exists = selectedColumns.find(c => c.tableName === table.name && c.columnName === column.name);
    if (exists) {
      onUpdate(selectedColumns.filter(c => !(c.tableName === table.name && c.columnName === column.name)));
    } else {
      onUpdate([...selectedColumns, { tableName: table.name, columnName: column.name, type: column.type }]);
    }
  };

  const selectAll = (table: any) => {
    const cols = schemas[table.path] || [];
    const newCols = cols.map(c => ({ tableName: table.name, columnName: c.name, type: c.type }));
    onUpdate([...selectedColumns.filter(c => c.tableName !== table.name), ...newCols]);
  };

  const deselectAll = (table: any) => {
    onUpdate(selectedColumns.filter(c => c.tableName !== table.name));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <ColumnIcon />
          <span>Select Columns</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <TextField
          size="small" fullWidth placeholder="Search columns..."
          value={colSearch} onChange={e => setColSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ mb: 2 }}
        />
        <Stack spacing={2}>
          {tables.map(table => {
            const allCols = schemas[table.path] || [];
            const cols = colSearch ? allCols.filter(c => c.name.toLowerCase().includes(colSearch.toLowerCase())) : allCols;
            return (
              <Paper key={table.path} variant="outlined" sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {table.name}
                    <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      ({cols.length}{colSearch ? ` / ${allCols.length}` : ''} columns)
                    </Typography>
                  </Typography>
                  <Stack direction="row" spacing={1}>
                    <Button size="small" onClick={() => selectAll(table)}>Select All</Button>
                    <Button size="small" onClick={() => deselectAll(table)}>Clear</Button>
                  </Stack>
                </Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 0.5 }}>
                  {cols.map(col => {
                    const isSelected = selectedColumns.find(c => c.tableName === table.name && c.columnName === col.name);
                    return (
                      <FormControlLabel
                        key={col.name}
                        control={<Checkbox checked={!!isSelected} onChange={() => toggleColumn(table, col)} size="small" />}
                        label={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Typography variant="body2">{col.name}</Typography>
                            <Typography variant="caption" color="text.secondary">({col.type})</Typography>
                          </Box>
                        }
                      />
                    );
                  })}
                </Box>
              </Paper>
            );
          })}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedColumns.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ColumnSelectorModal;
