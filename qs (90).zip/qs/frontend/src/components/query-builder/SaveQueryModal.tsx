import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Chip, Stack,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';
import api from '../../services/api';
import { useNotifications } from '../../context/NotificationContext';

interface SaveQueryModalProps {
  open: boolean;
  queryConfig: any;
  sqlPreview: string;
  editingQueryId: number | null;
  editingQueryName: string;
  onClose: () => void;
  onSaved: (id: number, name: string) => void;
}

const SaveQueryModal = ({ open, queryConfig, sqlPreview, editingQueryId, editingQueryName, onClose, onSaved }: SaveQueryModalProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    if (open) {
      setName(editingQueryName || '');
      setDescription('');
    }
  }, [open, editingQueryName]);

  const handleSave = async () => {
    if (!name.trim()) { alert('Please enter a query name'); return; }
    try {
      const payload = { name: name.trim(), description: description || null, query_config: queryConfig };
      let result;
      if (editingQueryId) {
        result = await api.updateQuery(editingQueryId, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated successfully` });
      } else {
        result = await api.saveQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved successfully` });
      }
      if (onSaved && result) onSaved(result.id || editingQueryId, name.trim());
      onClose();
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Save Error', message: error.message });
    }
  };

  const isEditing = !!editingQueryId;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <SaveIcon />
          <span>{isEditing ? 'Update Query' : 'Save Query'}</span>
          {isEditing && <Chip label="Editing" size="small" color="warning" sx={{ ml: 1 }} />}
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Query Name" required fullWidth
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g., Monthly Sales Report"
            onKeyDown={e => e.key === 'Enter' && handleSave()}
          />
          <TextField
            label="Description" fullWidth multiline rows={2}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Optional description"
          />
          <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
              SQL Preview
            </Typography>
            <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 12, m: 0, whiteSpace: 'pre-wrap', color: 'text.primary', maxHeight: 120, overflowY: 'auto' }}>
              {sqlPreview}
            </Box>
          </Paper>
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {isEditing ? 'Update Query' : 'Save Query'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SaveQueryModal;
