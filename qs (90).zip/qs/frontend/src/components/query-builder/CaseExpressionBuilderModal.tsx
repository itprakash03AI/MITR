import React from 'react';
import {
  Box, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, IconButton, Stack, Typography,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Close as CloseIcon,
  CallSplit as CaseIcon,
} from '@mui/icons-material';
import { CASE_OPS, NO_VALUE_OPS } from './types';

interface CaseExpressionBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  caseExpressions: any[];
  onUpdate: (exprs: any[]) => void;
  onClose: () => void;
}

const CaseExpressionBuilderModal = ({ open, tables, schemas, caseExpressions, onUpdate, onClose }: CaseExpressionBuilderModalProps) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(caseExpressions.length > 0 ? caseExpressions.map(ce => ({ ...ce })) : []); }, [open]); // eslint-disable-line

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const addCase = () => setLocal(prev => [...prev, {
    alias: '', else_value: '',
    when_clauses: [{ when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }],
  }]);
  const removeCase = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const updateCase = (i: number, field: string, val: any) => setLocal(prev => prev.map((ce, idx) => idx === i ? { ...ce, [field]: val } : ce));

  const addWhen = (i: number) => {
    const updated = [...local];
    updated[i] = { ...updated[i], when_clauses: [...updated[i].when_clauses, { when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }] };
    setLocal(updated);
  };
  const removeWhen = (ci: number, wi: number) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.filter((_: any, j: number) => j !== wi) };
    setLocal(updated);
  };
  const updateWhen = (ci: number, wi: number, field: string, val: string) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.map((w: any, j: number) => j === wi ? { ...w, [field]: val } : w) };
    setLocal(updated);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CaseIcon color="info" /> CASE WHEN Expressions</Box></DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          {local.map((ce, ci) => (
            <Paper key={ci} variant="outlined" sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', gap: 1, mb: 1.5, alignItems: 'center' }}>
                <TextField size="small" label="Result Alias" value={ce.alias} sx={{ minWidth: 160 }}
                  placeholder="e.g. category_label" onChange={e => updateCase(ci, 'alias', e.target.value)} />
                <Box sx={{ flex: 1 }} />
                <IconButton size="small" color="error" onClick={() => removeCase(ci)}><DeleteIcon fontSize="small" /></IconButton>
              </Box>
              {ce.when_clauses.map((w: any, wi: number) => (
                <Box key={wi} sx={{ display: 'flex', gap: 0.75, alignItems: 'center', mb: 1, flexWrap: 'wrap' }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, minWidth: 40 }}>WHEN</Typography>
                  <TextField select size="small" label="Column" value={w.when_column} sx={{ minWidth: 120 }}
                    onChange={e => updateWhen(ci, wi, 'when_column', e.target.value)}>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" label="Op" value={w.when_operator} sx={{ minWidth: 80 }}
                    onChange={e => updateWhen(ci, wi, 'when_operator', e.target.value)}>
                    {CASE_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
                  </TextField>
                  {!NO_VALUE_OPS.has(w.when_operator) && (
                    <TextField size="small" label="Value" value={w.when_value} sx={{ minWidth: 80 }}
                      onChange={e => updateWhen(ci, wi, 'when_value', e.target.value)} />
                  )}
                  <Typography variant="caption" sx={{ fontWeight: 700 }}>THEN</Typography>
                  <TextField size="small" label="Result" value={w.then_value} sx={{ minWidth: 80 }}
                    onChange={e => updateWhen(ci, wi, 'then_value', e.target.value)} />
                  <IconButton size="small" onClick={() => removeWhen(ci, wi)} disabled={ce.when_clauses.length <= 1}>
                    <CloseIcon sx={{ fontSize: 14 }} />
                  </IconButton>
                </Box>
              ))}
              <Button size="small" onClick={() => addWhen(ci)} sx={{ mb: 1 }}>+ Add WHEN</Button>
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                <Typography variant="caption" sx={{ fontWeight: 700, minWidth: 40 }}>ELSE</Typography>
                <TextField size="small" label="Default value" value={ce.else_value || ''} fullWidth
                  onChange={e => updateCase(ci, 'else_value', e.target.value)} />
              </Box>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={addCase} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add CASE Expression
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(ce => ce.alias && ce.when_clauses.length > 0)); onClose(); }}>
          Done ({local.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CaseExpressionBuilderModal;
