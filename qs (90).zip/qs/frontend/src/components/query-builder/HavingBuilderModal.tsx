import React from 'react';
import {
  Box, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, IconButton, Alert, Stack,
  Typography, Autocomplete,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { HAVING_OPS, AGG_FNS } from './types';

interface HavingBuilderModalProps {
  open: boolean;
  aggregations: any[];
  tables: any[];
  schemas: Record<string, any[]>;
  having: any[];
  onUpdate: (having: any[]) => void;
  onClose: () => void;
}

const HavingBuilderModal = ({ open, aggregations, tables, schemas, having, onUpdate, onClose }: HavingBuilderModalProps) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(having.length > 0 ? [...having] : []); }, [open]); // eslint-disable-line

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => {
    const col = allCols[0] || '';
    setLocal(prev => [...prev, { column: col, function: 'SUM', operator: 'gt', value: '' }]);
  };
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: any) => setLocal(prev => prev.map((h, idx) => idx === i ? { ...h, [field]: val } : h));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>HAVING — Filter Aggregated Results</DialogTitle>
      <DialogContent dividers>
        {aggregations.length === 0 && <Alert severity="info">Add aggregations first to use HAVING.</Alert>}
        <Stack spacing={1.5}>
          {local.map((h, i) => (
            <Paper key={i} variant="outlined" sx={{ p: 1.5, display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
              <TextField select size="small" label="Function" value={h.function} sx={{ minWidth: 90 }}
                onChange={e => update(i, 'function', e.target.value)}>
                {AGG_FNS.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
              </TextField>
              <Typography variant="body2">(</Typography>
              <Autocomplete
                options={allCols}
                value={h.column || null}
                onChange={(_, val) => update(i, 'column', val || '')}
                renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search..." />}
                size="small"
                sx={{ minWidth: 160 }}
                disableClearable
              />
              <Typography variant="body2">)</Typography>
              <TextField select size="small" label="Op" value={h.operator} sx={{ minWidth: 70 }}
                onChange={e => update(i, 'operator', e.target.value)}>
                {HAVING_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
              </TextField>
              <TextField size="small" label="Value" value={h.value} sx={{ minWidth: 100 }}
                onChange={e => update(i, 'value', e.target.value)} />
              <IconButton size="small" color="error" onClick={() => remove(i)}><DeleteIcon fontSize="small" /></IconButton>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add HAVING Condition
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

export default HavingBuilderModal;
