import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, Paper, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Chip, IconButton, Tooltip, Stack,
  CircularProgress, Autocomplete,
} from '@mui/material';
import {
  Link as JoinIcon, Save as SaveIcon, Close as CloseIcon,
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Search as SearchIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { suggestJoins } from '../../services/columnIntelligence';
import { JOIN_TYPE_COLORS } from './types';

// Normalize a join object from old format (leftColumn/rightColumn) or new format (conditions[])
export const _normalizeJoin = (j: any) => ({
  ...j,
  conditions: j.conditions && j.conditions.length > 0
    ? j.conditions
    : [{ leftColumn: j.leftColumn || '', rightColumn: j.rightColumn || '' }],
  rightSuffix: j.rightSuffix || '',
  rightColumnAliases: j.rightColumnAliases || {},
});

export const _emptyJoin = (tables: any[]) => ({
  leftTable: tables[0]?.path || '',
  rightTable: tables[1]?.path || tables[0]?.path || '',
  conditions: [{ leftColumn: '', rightColumn: '' }],
  joinType: 'inner',
  rightSuffix: '',
  rightColumnAliases: {} as Record<string, string>,
});

interface JoinBuilderModalProps {
  open: boolean;
  tables: any[];
  schemas: Record<string, any[]>;
  joins: any[];
  onUpdate: (joins: any[]) => void;
  onClose: () => void;
  connectionId: number | null;
}

const JoinBuilderModal = ({ open, tables, schemas, joins, onUpdate, onClose, connectionId }: JoinBuilderModalProps) => {
  const [editingJoin, setEditingJoin] = useState<number | null>(null);
  const [newJoin, setNewJoin] = useState<any>(_emptyJoin(tables));
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewResult, setPreviewResult] = useState<any>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [joinCorrections, setJoinCorrections] = useState<Map<string, any[]>>(new Map());

  useEffect(() => {
    if (open) { setNewJoin(_emptyJoin(tables)); setEditingJoin(null); setPreviewResult(null); setPreviewError(null); }
  }, [open, tables]);

  useEffect(() => {
    if (!open) return;
    (api as any).getJoinCorrections().then((res: any) => {
      const map = new Map<string, any[]>();
      for (const c of (res?.corrections || [])) {
        try {
          map.set(c.context_key, JSON.parse(c.corrected_value));
        } catch { /* skip malformed entries */ }
      }
      setJoinCorrections(map);
    }).catch(() => {});
  }, [open]);

  useEffect(() => { setPreviewResult(null); setPreviewError(null); }, [
    newJoin.leftTable, newJoin.rightTable, JSON.stringify(newJoin.conditions), // eslint-disable-line
  ]);

  const getAllColumns = (tablePath: string): any[] => schemas[tablePath] || [];

  const conflicts = React.useMemo(() => {
    if (!newJoin.leftTable || !newJoin.rightTable || newJoin.leftTable === newJoin.rightTable) return [];
    const leftNames = new Set(getAllColumns(newJoin.leftTable).map((c: any) => c.name));
    const rightKeys = new Set(newJoin.conditions.map((c: any) => c.rightColumn).filter(Boolean));
    return getAllColumns(newJoin.rightTable)
      .map((c: any) => c.name)
      .filter((n: string) => leftNames.has(n) && !rightKeys.has(n));
  }, [newJoin.leftTable, newJoin.rightTable, newJoin.conditions, schemas]); // eslint-disable-line

  useEffect(() => {
    if (!newJoin.rightSuffix && newJoin.rightTable) {
      const rtName = tables.find((t: any) => t.path === newJoin.rightTable)?.name || 'right';
      const slug = rtName.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
      setNewJoin((prev: any) => ({ ...prev, rightSuffix: `_${slug}` }));
    }
  }, [newJoin.rightTable]); // eslint-disable-line

  useEffect(() => {
    if (!open) return;
    if (!newJoin.leftTable || !newJoin.rightTable || newJoin.leftTable === newJoin.rightTable) return;
    const leftCols = getAllColumns(newJoin.leftTable);
    const rightCols = getAllColumns(newJoin.rightTable);
    if (leftCols.length === 0 || rightCols.length === 0) return;
    const allEmpty = newJoin.conditions.every((c: any) => !c.leftColumn && !c.rightColumn);
    if (!allEmpty) return;
    const leftName = tables.find((t: any) => t.path === newJoin.leftTable)?.name || '';
    const rightName = tables.find((t: any) => t.path === newJoin.rightTable)?.name || '';

    const pairKey = [leftName, rightName].sort().join('||').toLowerCase();
    const corrected = joinCorrections.get(pairKey);
    if (corrected && corrected.length > 0) {
      setNewJoin((prev: any) => ({ ...prev, conditions: corrected, _joinSource: 'learned' }));
      return;
    }

    const suggestions = suggestJoins(leftCols, rightCols, leftName, rightName);
    if (suggestions.length > 0) {
      const conditions = suggestions.map(s => ({ leftColumn: s.leftColumn, rightColumn: s.rightColumn }));
      setNewJoin((prev: any) => ({ ...prev, conditions, _joinSource: 'auto-matched' }));
    }
  }, [open, newJoin.leftTable, newJoin.rightTable, schemas, joinCorrections]); // eslint-disable-line

  const derivedAliases: Record<string, string> = React.useMemo(() =>
    Object.fromEntries(conflicts.map(c => [c, `${c}${newJoin.rightSuffix || '_right'}`])),
    [conflicts, newJoin.rightSuffix]);

  const updateCondition = (idx: number, side: 'leftColumn' | 'rightColumn', val: string) => {
    const updated = newJoin.conditions.map((c: any, i: number) => i === idx ? { ...c, [side]: val } : c);
    setNewJoin({ ...newJoin, conditions: updated });
  };
  const addCondition = () => setNewJoin({ ...newJoin, conditions: [...newJoin.conditions, { leftColumn: '', rightColumn: '' }] });
  const removeCondition = (idx: number) => {
    if (newJoin.conditions.length === 1) return;
    setNewJoin({ ...newJoin, conditions: newJoin.conditions.filter((_: any, i: number) => i !== idx) });
  };

  const canPreview = newJoin.conditions.some((c: any) => c.leftColumn && c.rightColumn);

  const runPreview = async () => {
    if (!canPreview) return;
    setPreviewLoading(true); setPreviewError(null); setPreviewResult(null);
    try {
      const result = await (api as any).joinPreview({
        connection_id: connectionId || undefined,
        left_file: newJoin.leftTable,
        right_file: newJoin.rightTable,
        left_on: newJoin.conditions.map((c: any) => c.leftColumn).filter(Boolean),
        right_on: newJoin.conditions.map((c: any) => c.rightColumn).filter(Boolean),
        how: newJoin.joinType,
      });
      setPreviewResult(result);
    } catch (e: any) {
      setPreviewError(e?.message || 'Preview failed');
    } finally {
      setPreviewLoading(false);
    }
  };

  const saveJoin = () => {
    if (newJoin.conditions.some((c: any) => !c.leftColumn || !c.rightColumn)) {
      alert('All conditions need columns on both sides'); return;
    }
    if (newJoin._joinSource && newJoin.leftTable && newJoin.rightTable) {
      const leftName = tables.find((t: any) => t.path === newJoin.leftTable)?.name || '';
      const rightName = tables.find((t: any) => t.path === newJoin.rightTable)?.name || '';
      const pairKey = [leftName, rightName].sort().join('||').toLowerCase();
      (api as any).saveSuggestionCorrection({
        correction_type: 'join',
        context_key: pairKey,
        corrected_value: JSON.stringify(newJoin.conditions.map((c: any) => ({
          leftColumn: c.leftColumn, rightColumn: c.rightColumn,
        }))),
        original_value: newJoin._joinSource,
        context_extra: connectionId ? String(connectionId) : undefined,
      }).catch(() => {});
    }
    const finalJoin = { ...newJoin, rightColumnAliases: conflicts.length > 0 ? derivedAliases : {} };
    if (editingJoin !== null) {
      const updated = [...joins];
      updated[editingJoin] = { ...finalJoin, id: joins[editingJoin].id };
      onUpdate(updated); setEditingJoin(null);
    } else {
      onUpdate([...joins, { ...finalJoin, id: Date.now() }]);
    }
    setNewJoin(_emptyJoin(tables)); setPreviewResult(null);
  };

  const editJoin = (index: number) => {
    setEditingJoin(index);
    setNewJoin(_normalizeJoin(joins[index]));
    setPreviewResult(null);
  };
  const deleteJoin = (index: number) => {
    if (window.confirm('Delete this join?')) onUpdate(joins.filter((_: any, i: number) => i !== index));
  };

  const matchRateColor = (rate: number) => rate >= 0.5 ? '#15803d' : rate >= 0.1 ? '#b45309' : '#dc2626';
  const matchRateBg   = (rate: number) => rate >= 0.5 ? '#f0fdf4' : rate >= 0.1 ? '#fffbeb' : '#fef2f2';
  const matchRateBorder = (rate: number) => rate >= 0.5 ? '#bbf7d0' : rate >= 0.1 ? '#fde68a' : '#fecaca';

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth PaperProps={{ sx: { maxHeight: '92vh' } }}>
      <DialogTitle sx={{ pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <JoinIcon sx={{ color: '#2563eb' }} />
          <Typography variant="h6" sx={{ fontWeight: 700 }}>Configure Joins</Typography>
        </Box>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 2 }}>
        <Paper variant="outlined" sx={{ p: 2, mb: 2, borderColor: '#e2e8f0' }}>
          <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 700, color: '#1e293b', display: 'flex', alignItems: 'center', gap: 0.5 }}>
            {editingJoin !== null
              ? <><EditIcon sx={{ fontSize: 15 }} /> Edit Join</>
              : <><AddIcon sx={{ fontSize: 15 }} /> New Join</>}
          </Typography>

          <Stack direction="row" spacing={1.5} sx={{ mb: 2 }} alignItems="flex-start">
            <TextField select label="Type" size="small" sx={{ width: 160, flexShrink: 0 }}
              value={newJoin.joinType}
              onChange={e => setNewJoin({ ...newJoin, joinType: e.target.value })}
              SelectProps={{ renderValue: (v: any) => (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: JOIN_TYPE_COLORS[v] || '#94a3b8' }} />
                  <span>{v.toUpperCase()}</span>
                </Box>
              )}}
            >
              {[['inner','INNER JOIN'],['left','LEFT JOIN'],['right','RIGHT JOIN'],['outer','FULL OUTER']].map(([v,l]) => (
                <MenuItem key={v} value={v}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: JOIN_TYPE_COLORS[v] }} />
                    {l}
                  </Box>
                </MenuItem>
              ))}
            </TextField>
            <TextField select label="Left Table" size="small" sx={{ flex: 1 }}
              value={newJoin.leftTable}
              onChange={e => setNewJoin({ ...newJoin, leftTable: e.target.value, conditions: [{ leftColumn: '', rightColumn: '' }] })}
            >
              {tables.map((t: any) => <MenuItem key={t.path} value={t.path}>{t.name}{t.folder ? ` (${t.folder})` : ''}</MenuItem>)}
            </TextField>
            <TextField select label="Right Table" size="small" sx={{ flex: 1 }}
              value={newJoin.rightTable}
              onChange={e => setNewJoin({ ...newJoin, rightTable: e.target.value, conditions: [{ leftColumn: '', rightColumn: '' }], rightSuffix: '' })}
            >
              {tables.map((t: any) => <MenuItem key={t.path} value={t.path}>{t.name}{t.folder ? ` (${t.folder})` : ''}</MenuItem>)}
            </TextField>
          </Stack>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.75 }}>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5 }}>
              ON Conditions
            </Typography>
            {newJoin.conditions.some((c: any) => c.leftColumn && c.rightColumn) && newJoin.leftTable && newJoin.rightTable && newJoin._joinSource && (
              <Typography variant="caption" sx={{
                fontSize: 10, fontWeight: 600,
                color: newJoin._joinSource === 'learned' ? '#1d4ed8' : '#16a34a',
              }}>
                {newJoin._joinSource === 'learned' ? 'learned from corrections' : 'auto-matched'}
              </Typography>
            )}
          </Box>
          <Stack spacing={0.75} sx={{ mb: 1 }}>
            {newJoin.conditions.map((cond: any, idx: number) => (
              <Stack key={idx} direction="row" spacing={1} alignItems="center">
                <Autocomplete size="small" sx={{ flex: 1 }}
                  options={getAllColumns(newJoin.leftTable)}
                  getOptionLabel={(c: any) => `${c.name} (${c.type})`}
                  value={getAllColumns(newJoin.leftTable).find((c: any) => c.name === cond.leftColumn) || null}
                  onChange={(_, v: any) => updateCondition(idx, 'leftColumn', v?.name || '')}
                  renderInput={(p) => <TextField {...p} placeholder="Left column…" size="small"
                    InputProps={{ ...p.InputProps, sx: { fontSize: 12 } }} />}
                  noOptionsText={<Typography sx={{ fontSize: 11 }}>No columns</Typography>}
                />
                <Typography sx={{ fontSize: 13, fontWeight: 700, color: '#94a3b8', flexShrink: 0 }}>=</Typography>
                <Autocomplete size="small" sx={{ flex: 1 }}
                  options={getAllColumns(newJoin.rightTable)}
                  getOptionLabel={(c: any) => `${c.name} (${c.type})`}
                  value={getAllColumns(newJoin.rightTable).find((c: any) => c.name === cond.rightColumn) || null}
                  onChange={(_, v: any) => updateCondition(idx, 'rightColumn', v?.name || '')}
                  renderInput={(p) => <TextField {...p} placeholder="Right column…" size="small"
                    InputProps={{ ...p.InputProps, sx: { fontSize: 12 } }} />}
                  noOptionsText={<Typography sx={{ fontSize: 11 }}>No columns</Typography>}
                />
                <Tooltip title={newJoin.conditions.length > 1 ? 'Remove condition' : 'Need at least one condition'}>
                  <span>
                    <IconButton size="small" onClick={() => removeCondition(idx)} disabled={newJoin.conditions.length === 1}
                      sx={{ color: '#ef4444', '&.Mui-disabled': { color: '#cbd5e1' } }}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </span>
                </Tooltip>
              </Stack>
            ))}
          </Stack>
          <Button size="small" startIcon={<AddIcon />} onClick={addCondition}
            sx={{ fontSize: 11, color: '#2563eb', textTransform: 'none', mb: 1.5 }}>
            Add Condition
          </Button>

          {conflicts.length > 0 && (
            <Paper variant="outlined" sx={{ p: 1.25, mb: 1.5, bgcolor: '#fffbeb', borderColor: '#fde68a' }}>
              <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#92400e', mb: 0.75 }}>
                {conflicts.length} conflicting column{conflicts.length > 1 ? 's' : ''} — right table columns will be renamed
              </Typography>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.75 }}>
                <Typography sx={{ fontSize: 11, color: '#78350f', flexShrink: 0 }}>Right table suffix:</Typography>
                <TextField size="small" value={newJoin.rightSuffix}
                  onChange={e => setNewJoin({ ...newJoin, rightSuffix: e.target.value })}
                  sx={{ width: 130, '& .MuiInputBase-input': { fontSize: 11, py: 0.4, px: 0.75 } }}
                />
              </Stack>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.4 }}>
                {conflicts.slice(0, 8).map(c => (
                  <Chip key={c} size="small" label={`${c} → ${c}${newJoin.rightSuffix || '_right'}`}
                    sx={{ fontSize: 10, height: 20, bgcolor: '#fef3c7', color: '#92400e', border: '1px solid #fde68a' }} />
                ))}
                {conflicts.length > 8 && (
                  <Typography sx={{ fontSize: 10, color: '#92400e', alignSelf: 'center' }}>+{conflicts.length - 8} more</Typography>
                )}
              </Box>
            </Paper>
          )}

          {canPreview && (
            <Box sx={{ mb: 1.5 }}>
              <Button size="small" variant="outlined" startIcon={previewLoading ? <CircularProgress size={12} /> : <SearchIcon />}
                onClick={runPreview} disabled={previewLoading}
                sx={{ fontSize: 11, textTransform: 'none', borderColor: '#2563eb', color: '#2563eb',
                  '&:hover': { borderColor: '#1d4ed8', bgcolor: '#eff6ff' } }}>
                {previewLoading ? 'Running…' : 'Preview Match Stats'}
              </Button>
              {previewError && (
                <Typography sx={{ fontSize: 11, color: '#dc2626', mt: 0.5 }}>{previewError}</Typography>
              )}
              {previewResult && (() => {
                const rate = previewResult.match_rate ?? 0;
                const pct = (rate * 100).toFixed(1);
                return (
                  <Box sx={{ mt: 1 }}>
                    <Box sx={{ display: 'flex', gap: 1, mb: 0.75 }}>
                      {[
                        { label: 'Left rows', val: (previewResult.left_count ?? 0).toLocaleString(), color: '#1e40af', bg: '#eff6ff', border: '#bfdbfe' },
                        { label: 'Right rows', val: (previewResult.right_count ?? 0).toLocaleString(), color: '#065f46', bg: '#f0fdf4', border: '#bbf7d0' },
                        { label: `Matched (${pct}%)`, val: (previewResult.matched_count ?? 0).toLocaleString(), color: matchRateColor(rate), bg: matchRateBg(rate), border: matchRateBorder(rate) },
                      ].map(s => (
                        <Box key={s.label} sx={{ flex: 1, px: 1, py: 0.6, borderRadius: 1, bgcolor: s.bg, border: `1px solid ${s.border}`, textAlign: 'center' }}>
                          <Typography sx={{ fontSize: 10, color: s.color, opacity: 0.75 }}>{s.label}</Typography>
                          <Typography sx={{ fontSize: 13, fontWeight: 700, color: s.color }}>{s.val}</Typography>
                        </Box>
                      ))}
                    </Box>
                    {previewResult.sample_rows?.length > 0 && (
                      <Box sx={{ overflowX: 'auto', borderRadius: 1, border: '1px solid #e2e8f0' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                          <thead>
                            <tr style={{ background: '#f8fafc' }}>
                              {(previewResult.columns || Object.keys(previewResult.sample_rows[0])).slice(0, 8).map((col: string) => (
                                <th key={col} style={{ padding: '4px 8px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: 600, color: '#475569', whiteSpace: 'nowrap' }}>{col}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {previewResult.sample_rows.slice(0, 5).map((row: any, ri: number) => (
                              <tr key={ri} style={{ background: ri % 2 === 0 ? 'white' : '#f8fafc' }}>
                                {(previewResult.columns || Object.keys(row)).slice(0, 8).map((col: string) => (
                                  <td key={col} style={{ padding: '3px 8px', borderBottom: '1px solid #f1f5f9', color: '#334155', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                    {row[col] === null ? <em style={{ color: '#94a3b8' }}>null</em> : String(row[col])}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </Box>
                    )}
                  </Box>
                );
              })()}
            </Box>
          )}

          <Stack direction="row" spacing={1} justifyContent="flex-end">
            {editingJoin !== null && (
              <Button variant="outlined" size="small" onClick={() => { setEditingJoin(null); setNewJoin(_emptyJoin(tables)); setPreviewResult(null); }}>
                Cancel
              </Button>
            )}
            <Button variant="contained" size="small" onClick={saveJoin}
              startIcon={editingJoin !== null ? <SaveIcon /> : <AddIcon />}
              sx={{ bgcolor: '#2563eb', '&:hover': { bgcolor: '#1d4ed8' } }}>
              {editingJoin !== null ? 'Update Join' : 'Add Join'}
            </Button>
          </Stack>
        </Paper>

        {joins.length > 0 && (
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 700, color: '#1e293b' }}>
              Configured Joins ({joins.length})
            </Typography>
            <Stack spacing={0.75}>
              {joins.map((join: any, index: number) => {
                const nj = _normalizeJoin(join);
                const leftTable = tables.find((t: any) => t.path === nj.leftTable);
                const rightTable = tables.find((t: any) => t.path === nj.rightTable);
                const aliasCount = Object.keys(nj.rightColumnAliases || {}).length;
                return (
                  <Paper key={nj.id} variant="outlined" sx={{ p: 1.25, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', borderColor: '#e2e8f0' }}>
                    <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                      <Chip label={nj.joinType.toUpperCase()} size="small"
                        sx={{ height: 20, fontSize: 10, fontWeight: 700, bgcolor: JOIN_TYPE_COLORS[nj.joinType] || '#64748b', color: 'white', mt: 0.1 }} />
                      <Box>
                        {nj.conditions.map((c: any, ci: number) => (
                          <Typography key={ci} variant="body2" sx={{ fontSize: 12, lineHeight: 1.6 }}>
                            {ci > 0 && <Box component="span" sx={{ color: '#94a3b8', mr: 0.5, fontStyle: 'italic', fontSize: 10 }}>AND</Box>}
                            <strong>{leftTable?.name}</strong><Box component="span" sx={{ color: '#94a3b8' }}>.</Box>{c.leftColumn}
                            <Box component="span" sx={{ mx: 0.75, color: '#94a3b8' }}>=</Box>
                            <strong>{rightTable?.name}</strong><Box component="span" sx={{ color: '#94a3b8' }}>.</Box>{c.rightColumn}
                          </Typography>
                        ))}
                        {aliasCount > 0 && (
                          <Typography sx={{ fontSize: 10, color: '#b45309', mt: 0.25 }}>
                            {aliasCount} column alias{aliasCount > 1 ? 'es' : ''} (suffix: {nj.rightSuffix})
                          </Typography>
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', flexShrink: 0, ml: 1 }}>
                      <Tooltip title="Edit"><IconButton size="small" onClick={() => editJoin(index)} sx={{ color: '#2563eb' }}><EditIcon sx={{ fontSize: 14 }} /></IconButton></Tooltip>
                      <Tooltip title="Delete"><IconButton size="small" onClick={() => deleteJoin(index)} sx={{ color: '#ef4444' }}><DeleteIcon sx={{ fontSize: 14 }} /></IconButton></Tooltip>
                    </Box>
                  </Paper>
                );
              })}
            </Stack>
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 2, py: 1 }}>
        <Button variant="contained" onClick={onClose} sx={{ bgcolor: '#2563eb', '&:hover': { bgcolor: '#1d4ed8' } }}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

export default JoinBuilderModal;
