/**
 * Hook that manages open/close state for all query builder modal dialogs.
 * Extracted from CompleteQueryBuilder to reduce useState noise.
 */
import { useState } from 'react';

export interface QueryBuilderModals {
  showTableSelector: boolean;
  setShowTableSelector: (v: boolean) => void;
  showJoinBuilder: boolean;
  setShowJoinBuilder: (v: boolean) => void;
  showColumnSelector: boolean;
  setShowColumnSelector: (v: boolean) => void;
  showFilterBuilder: boolean;
  setShowFilterBuilder: (v: boolean) => void;
  showSaveDialog: boolean;
  setShowSaveDialog: (v: boolean) => void;
  showAggBuilder: boolean;
  setShowAggBuilder: (v: boolean) => void;
  showHavingBuilder: boolean;
  setShowHavingBuilder: (v: boolean) => void;
  showComputedBuilder: boolean;
  setShowComputedBuilder: (v: boolean) => void;
  showCaseBuilder: boolean;
  setShowCaseBuilder: (v: boolean) => void;
  showWindowBuilder: boolean;
  setShowWindowBuilder: (v: boolean) => void;
  showPreview: boolean;
  setShowPreview: (v: boolean) => void;
}

const useQueryBuilderModals = (): QueryBuilderModals => {
  const [showTableSelector, setShowTableSelector] = useState(false);
  const [showJoinBuilder, setShowJoinBuilder] = useState(false);
  const [showColumnSelector, setShowColumnSelector] = useState(false);
  const [showFilterBuilder, setShowFilterBuilder] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showAggBuilder, setShowAggBuilder] = useState(false);
  const [showHavingBuilder, setShowHavingBuilder] = useState(false);
  const [showComputedBuilder, setShowComputedBuilder] = useState(false);
  const [showCaseBuilder, setShowCaseBuilder] = useState(false);
  const [showWindowBuilder, setShowWindowBuilder] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  return {
    showTableSelector, setShowTableSelector,
    showJoinBuilder, setShowJoinBuilder,
    showColumnSelector, setShowColumnSelector,
    showFilterBuilder, setShowFilterBuilder,
    showSaveDialog, setShowSaveDialog,
    showAggBuilder, setShowAggBuilder,
    showHavingBuilder, setShowHavingBuilder,
    showComputedBuilder, setShowComputedBuilder,
    showCaseBuilder, setShowCaseBuilder,
    showWindowBuilder, setShowWindowBuilder,
    showPreview, setShowPreview,
  };
};

export default useQueryBuilderModals;
