/**
 * API — Admin, Config, Intelligence, Lineage, Misc
 */
import { safeFetch, openDownload, API_BASE_URL } from './core';
import { getAuthHeader } from '../../context/AuthContext';

const admin = {
  // ── Health ──────────────────────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: (err as Error).message })),

  // ── Files ───────────────────────────────────────────────────────────────
  listFiles: (storageType: string | null = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },
  getFileSchema: (filePath: string) =>
    safeFetch(`/api/files/${filePath}/schema`).catch(err => {
      console.warn(`Schema failed for ${filePath}:`, (err as Error).message);
      return { file: filePath, columns: [], num_rows: 0 };
    }),
  uploadFile: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    const authHeader = getAuthHeader();
    const headers: Record<string, string> = {};
    if (authHeader) headers['Authorization'] = authHeader;
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form, headers })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 ──────────────────────────────────────────────────────────────────
  configureS3: (config: object) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Schedules ───────────────────────────────────────────────────────────
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),
  createSchedule: (data: object) =>
    safeFetch('/api/schedules', { method: 'POST', body: JSON.stringify(data) }),
  getSchedule: (id: string) => safeFetch(`/api/schedules/${id}`),
  updateSchedule: (id: string, data: object) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSchedule: (id: string) => safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),
  pauseSchedule: (id: string) => safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),
  resumeSchedule: (id: string) => safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),
  runScheduleNow: (id: string) => safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),
  getSchedulerStatus: () => safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),
  getScheduleRunStats: (scheduleId: number, limit: number = 20): Promise<any> =>
    safeFetch(`/api/schedules/${scheduleId}/run-stats?limit=${limit}`),
  getAnomalies: (limit: number = 50): Promise<any> =>
    safeFetch(`/api/admin/anomalies?limit=${limit}`),

  // ── App Settings ────────────────────────────────────────────────────────
  getAppSettings: () => safeFetch('/api/app-settings'),
  getAdminAppConfig: () => safeFetch('/api/admin/app-config'),
  updateAdminAppConfig: (data: { limits?: Record<string, any>; features?: Record<string, any> }) =>
    safeFetch('/api/admin/app-config', { method: 'PUT', body: JSON.stringify(data) }),

  // ── UI Component Visibility ─────────────────────────────────────────────
  getUIVisibility: () => safeFetch('/api/admin/ui-visibility'),
  setUIVisibility: (rules: Array<{ component_key: string; role: string; enabled: boolean }>) =>
    safeFetch('/api/admin/ui-visibility', { method: 'PUT', body: JSON.stringify({ rules }) }),

  // ── Dashboards ──────────────────────────────────────────────────────────
  listDashboards: () => safeFetch('/api/dashboards').catch(() => []),
  createDashboard: (data: object) =>
    safeFetch('/api/dashboards', { method: 'POST', body: JSON.stringify(data) }),
  getDashboard: (id: string | number) => safeFetch(`/api/dashboards/${id}`),
  updateDashboard: (id: string | number, data: object) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDashboard: (id: string | number) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'DELETE' }),
  listDashboardWidgets: (dashId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`).catch(() => []),
  createWidget: (dashId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`, { method: 'POST', body: JSON.stringify(data) }),
  updateWidget: (dashId: string | number, widgetId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteWidget: (dashId: string | number, widgetId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'DELETE' }),
  updateDashboardLayout: (dashId: string | number, layouts: object[]) =>
    safeFetch(`/api/dashboards/${dashId}/layout`, { method: 'PUT', body: JSON.stringify({ layouts }) }),
  getSharedDashboard: (token: string) =>
    safeFetch(`/api/shared-dashboard/${token}`),
  createDashboardShare: (dashboardId: string | number, expiresHours?: number) =>
    safeFetch(`/api/dashboards/${dashboardId}/share`, {
      method: 'POST', body: JSON.stringify({ expires_hours: expiresHours ?? null }),
    }),

  // ── Cache ───────────────────────────────────────────────────────────────
  getCacheStats: () => safeFetch('/api/cache/stats').catch(() => ({})),
  clearCache: () => safeFetch('/api/cache', { method: 'DELETE' }),

  // ── Webhooks ────────────────────────────────────────────────────────────
  testWebhook: (url: string) =>
    safeFetch('/api/webhooks/test', { method: 'POST', body: JSON.stringify({ url }) }),

  // ── Materialized Views ─────────────────────────────────────────────────
  listMaterializedViews: (connectionId?: number) =>
    safeFetch(`/api/materialized-views${connectionId ? `?connection_id=${connectionId}` : ''}`).catch(() => []),
  getMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`),
  createMaterializedView: (data: object) =>
    safeFetch('/api/materialized-views', { method: 'POST', body: JSON.stringify(data) }),
  updateMaterializedView: (id: number, data: object) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'DELETE' }),
  refreshMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/refresh`, { method: 'POST' }),
  getMaterializedViewStatus: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/status`),
  getMaterializedViewsStorage: () =>
    safeFetch('/api/materialized-views/storage').catch(() => ({})),
  getMaterializedViewSchema: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/schema`),

  // ── Local Tables ────────────────────────────────────────────────────────
  listLocalTables: (params?: { visibility?: string; created_by?: string }) =>
    safeFetch(`/api/local-tables${params ? '?' + new URLSearchParams(params as any).toString() : ''}`),
  getLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`),
  createLocalTable: (data: object) =>
    safeFetch('/api/local-tables', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  updateLocalTable: (id: number, data: object) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  deleteLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'DELETE' }),
  promoteToLocalTable: (data: object) =>
    safeFetch('/api/local-tables/promote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  uploadLocalTable: async (formData: FormData): Promise<any> => {
    const fullUrl = `${API_BASE_URL}/api/local-tables/upload`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const response = await fetch(fullUrl, { method: 'POST', headers, body: formData });
    if (!response.ok) {
      const { detail } = await (await import('./core'))._parseError(response);
      throw new (await import('./core')).ApiError(detail);
    }
    return response.json();
  },
  appendToLocalTable: async (id: number, formData: FormData): Promise<any> => {
    const fullUrl = `${API_BASE_URL}/api/local-tables/${id}/append`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const wsId = localStorage.getItem('qs_workspace_id');
    if (wsId) headers['X-Workspace-ID'] = wsId;
    const response = await fetch(fullUrl, { method: 'POST', headers, body: formData });
    if (!response.ok) {
      const { detail } = await (await import('./core'))._parseError(response);
      throw new (await import('./core')).ApiError(detail);
    }
    return response.json();
  },
  getLocalTableSchema: (id: number) =>
    safeFetch(`/api/local-tables/${id}/schema`),
  getLocalTablesStorage: () =>
    safeFetch('/api/local-tables/storage').catch(() => ({})),

  // ── Table UX ────────────────────────────────────────────────────────────
  previewTable: (payload: { table_path: string; connection_id?: number; limit?: number }) =>
    safeFetch('/api/tables/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  profileTable: (payload: { table_path: string; connection_id?: number; columns?: string[]; sample_size?: number }) =>
    safeFetch('/api/tables/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  toggleTableFavorite: (payload: { table_path: string; table_name: string; connection_id?: number; table_type?: string }) =>
    safeFetch('/api/tables/favorite', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  listTableFavorites: (connectionId?: number) =>
    safeFetch(`/api/tables/favorites${connectionId ? `?connection_id=${connectionId}` : ''}`),

  // ── Notifications ───────────────────────────────────────────────────────
  listNotifications: (unreadOnly = false, limit = 50, offset = 0) =>
    safeFetch(`/api/notifications?unread_only=${unreadOnly}&limit=${limit}&offset=${offset}`),
  getUnreadCount: () =>
    safeFetch('/api/notifications/unread-count'),
  markNotificationRead: (id: number) =>
    safeFetch(`/api/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () =>
    safeFetch('/api/notifications/read-all', { method: 'PUT' }),

  // ── Workspaces ──────────────────────────────────────────────────────────
  listWorkspaces: () =>
    safeFetch('/api/workspaces').catch(() => ({ workspaces: [] })),
  createWorkspace: (data: object) =>
    safeFetch('/api/workspaces', { method: 'POST', body: JSON.stringify(data) }),
  updateWorkspace: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteWorkspace: (id: number) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'DELETE' }),
  listWorkspaceMembers: (id: number) =>
    safeFetch(`/api/workspaces/${id}/members`).catch(() => ({ members: [] })),
  addWorkspaceMember: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}/members`, { method: 'POST', body: JSON.stringify(data) }),
  updateWorkspaceMemberRole: (id: number, username: string, data: object) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'PUT', body: JSON.stringify(data) }),
  removeWorkspaceMember: (id: number, username: string) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'DELETE' }),

  // ── Data Lineage ────────────────────────────────────────────────────────
  getConnectionLineage: (id: number) =>
    safeFetch(`/api/lineage/connection/${id}`),
  getReportLineage: (id: number) =>
    safeFetch(`/api/lineage/report/${id}`),
  getQueryLineage: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}?type=${encodeURIComponent(type)}`),
  getFullLineageGraph: () =>
    safeFetch('/api/lineage/graph').catch(() => ({ nodes: [], edges: [] })),
  getTableLineage: (catalog: string, schema: string, table: string) =>
    safeFetch(`/api/lineage/table/${encodeURIComponent(catalog)}/${encodeURIComponent(schema)}/${encodeURIComponent(table)}`),
  searchTableLineage: (q: string, limit: number = 50) =>
    safeFetch(`/api/lineage/table/search?q=${encodeURIComponent(q)}&limit=${limit}`),
  getQueryTables: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}/tables?type=${encodeURIComponent(type)}`),
  reparseAllLineage: () =>
    safeFetch('/api/lineage/reparse', { method: 'POST' }),
  getQueryColumnLineage: (query_id: number, query_type = 'sql_query') =>
    safeFetch(`/api/lineage/query/${query_id}/columns?query_type=${query_type}`),
  getColumnImpact: (table: string, column: string) =>
    safeFetch(`/api/lineage/column/impact?table=${encodeURIComponent(table)}&column=${encodeURIComponent(column)}`),
  getLineageSnapshots: (params?: { query_type?: string; query_id?: number; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.query_type) qs.set('query_type', params.query_type);
    if (params?.query_id != null) qs.set('query_id', String(params.query_id));
    if (params?.limit != null)    qs.set('limit', String(params.limit));
    return safeFetch(`/api/lineage/snapshots?${qs}`);
  },
  getLineageSnapshot: (id: number) =>
    safeFetch(`/api/lineage/snapshots/${id}`),
  diffLineageSnapshots: (a: number, b: number) =>
    safeFetch(`/api/lineage/snapshots/diff?a=${a}&b=${b}`),
  getDataFreshness: () =>
    safeFetch('/api/lineage/freshness'),
  getStaleTables: () =>
    safeFetch('/api/lineage/freshness/stale'),
  updateFreshnessThreshold: (table_fqn: string, stale_threshold_hours: number) =>
    safeFetch('/api/lineage/freshness/threshold', {
      method: 'PUT',
      body: JSON.stringify({ table_fqn, stale_threshold_hours }),
    }),
  markTableRefreshed: (table_fqn: string) =>
    safeFetch('/api/lineage/freshness/mark-refreshed', {
      method: 'POST',
      body: JSON.stringify({ table_fqn }),
    }),
  getLineageAdminConfig: () =>
    safeFetch('/api/admin/lineage/config'),
  setLineageAdminConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/lineage/config', {
      method: 'PUT',
      body: JSON.stringify(config),
    }),

  // ── Audit & Compliance ──────────────────────────────────────────────────
  getAuditLogFiltered: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string; limit?: number; offset?: number;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    return safeFetch(`/api/admin/audit-log?${qs.toString()}`);
  },
  exportAuditLog: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    const base = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
    const a = document.createElement('a');
    a.href = `${base}/api/admin/audit-log/export?${qs.toString()}`;
    a.download = 'audit_log.csv';
    a.click();
    return Promise.resolve();
  },
  getDataAccessSummary: () =>
    safeFetch('/api/admin/audit-log/data-access-summary').catch(() => ({ summary: [] })),
  generateSubjectExport: (username: string) => {
    const base = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
    return fetch(`${base}/api/admin/compliance/subject-export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(getAuthHeader() ? { Authorization: getAuthHeader() as string } : {}) },
      body: JSON.stringify({ username }),
    }).then(async res => {
      if (!res.ok) throw new Error(await res.text());
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `subject_export_${username}.zip`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    });
  },

  // ── Intelligence & NL-to-SQL ────────────────────────────────────────────
  getSuggestedTables: (params: { prefix?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.prefix) q.set('prefix', params.prefix);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/tables?${q}`);
  },
  getSuggestedColumns: (params: { table_name?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.table_name) q.set('table_name', params.table_name);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/columns?${q}`);
  },
  getTopTables: (connection_id?: number) =>
    safeFetch(`/api/suggest/top-tables${connection_id != null ? `?connection_id=${connection_id}` : ''}`),
  analyzeQuery: (sql: string, connection_type = 'duckdb', partition_columns: string[] = []) =>
    safeFetch('/api/analyze-query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, connection_type, partition_columns }),
    }),
  nlToSql: (payload: {
    question: string;
    connection_id?: number;
    tables?: string[];
    columns?: Record<string, string[]>;
    connection_type?: string;
    default_schema?: string;
    dataset_id?: number;
    use_schema_cache?: boolean;
  }) =>
    safeFetch('/api/nl-to-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  nlToSqlSemantic: (payload: {
    question: string;
    dataset_id: number;
    connection_type?: string;
    default_schema?: string;
  }) =>
    safeFetch('/api/nl-to-sql/semantic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  getNlToSqlExamples: (dataset_id?: number) =>
    safeFetch(`/api/nl-to-sql/examples${dataset_id ? `?dataset_id=${dataset_id}` : ''}`),
  getChatbotPatterns: () => safeFetch('/api/suggest/chatbot-patterns'),
  getChatbotConfig: () => safeFetch('/api/admin/chatbot/config'),
  setChatbotConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/chatbot/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    }),
  getSuggestSchema: (q: string, connection_id?: number) =>
    safeFetch(`/api/suggest/schema?q=${encodeURIComponent(q)}${connection_id != null ? `&connection_id=${connection_id}` : ''}`),
  getLastResultInfo: () => safeFetch('/api/suggest/last-result'),
  getSuggestDocs: (q: string) => safeFetch(`/api/suggest/docs?q=${encodeURIComponent(q)}`),
  dataQuery: (question: string, columns: string[] = [], execution_id?: string, file_id?: string) =>
    safeFetch('/api/suggest/data-query', {
      method: 'POST',
      body: JSON.stringify({ question, columns, execution_id, file_id }),
    }),
  saveNlFeedback: (question: string, sql: string, rating: 1 | -1, connection_type = 'duckdb', tables_hint?: string) =>
    safeFetch('/api/suggest/feedback', {
      method: 'POST',
      body: JSON.stringify({ question, sql, rating, connection_type, tables_hint }),
    }),
  saveSuggestionCorrection: (payload: {
    correction_type: 'agg' | 'join';
    context_key: string;
    corrected_value: string;
    original_value?: string;
    context_extra?: string;
  }) =>
    safeFetch('/api/suggest/correction', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getAggCorrections: () => safeFetch('/api/suggest/corrections/agg'),
  getJoinCorrections: () => safeFetch('/api/suggest/corrections/join'),
  getChartFeedback: (connectionId?: number) =>
    safeFetch(`/api/suggest/corrections/chart${connectionId ? `?connection_id=${connectionId}` : ''}`),
  getPivotFeedback: (connectionId?: number) =>
    safeFetch(`/api/suggest/corrections/pivot${connectionId ? `?connection_id=${connectionId}` : ''}`),

  // ── Admin Configs ───────────────────────────────────────────────────────
  getSemanticLayerConfig: () =>
    safeFetch('/api/admin/semantic-layer/config'),
  setSemanticLayerConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/semantic-layer/config', { method: 'PUT', body: JSON.stringify(config) }),
  getFederationConfig: () =>
    safeFetch('/api/admin/federation/config'),
  setFederationConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/federation/config', { method: 'PUT', body: JSON.stringify(config) }),
  getAggCacheStats: () =>
    safeFetch('/api/admin/agg-cache/stats'),
  getAggCacheDatasetStats: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/stats/${datasetId}`),
  listAggCacheSuggestions: () =>
    safeFetch('/api/admin/agg-cache/suggestions'),
  triggerAggCacheAnalysis: () =>
    safeFetch('/api/admin/agg-cache/analyze', { method: 'POST' }),
  approveAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/approve`, { method: 'POST' }),
  rejectAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/reject`, { method: 'POST' }),
  getAggCacheConfig: () =>
    safeFetch('/api/admin/agg-cache/config'),
  setAggCacheConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/agg-cache/config', { method: 'PUT', body: JSON.stringify(config) }),
  triggerAggCacheCleanup: () =>
    safeFetch('/api/admin/agg-cache/cleanup', { method: 'POST' }),
  invalidateAggCache: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/invalidate/${datasetId}`, { method: 'POST' }),
  getAWSPortalConfig: () =>
    safeFetch('/api/admin/aws-portal/config'),
  setAWSPortalConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/aws-portal/config', { method: 'PUT', body: JSON.stringify(config) }),
  testAWSPortalConfig: () =>
    safeFetch('/api/admin/aws-portal/test', { method: 'POST' }),
  getAWSPortalCacheStats: () =>
    safeFetch('/api/admin/aws-portal/cache'),
  clearAWSPortalCache: (username?: string) =>
    safeFetch(`/api/admin/aws-portal/cache${username ? `?username=${username}` : ''}`, { method: 'DELETE' }),
  authenticateAWSPortal: (username: string, password: string) =>
    safeFetch('/api/aws-portal/authenticate', { method: 'POST', body: JSON.stringify({ username, password }) }),
  getAWSPortalStatus: () =>
    safeFetch('/api/aws-portal/status'),
  getBusinessReportsConfig: () =>
    safeFetch('/api/admin/reports/config'),
  setBusinessReportsConfig: (data: any) =>
    safeFetch('/api/admin/reports/config', { method: 'PUT', body: JSON.stringify(data) }),
  getReportCatalogConfig: () =>
    safeFetch('/api/admin/report-catalog/config'),
  setReportCatalogConfig: (data: any) =>
    safeFetch('/api/admin/report-catalog/config', { method: 'PUT', body: JSON.stringify(data) }),
  getBusinessPortalConfig: () =>
    safeFetch('/api/admin/business-portal/config'),
  setBusinessPortalConfig: (data: any) =>
    safeFetch('/api/admin/business-portal/config', { method: 'PUT', body: JSON.stringify(data) }),
  getDeliveryConfig: () =>
    safeFetch('/api/admin/delivery/config'),
  setDeliveryConfig: (data: any) =>
    safeFetch('/api/admin/delivery/config', { method: 'PUT', body: JSON.stringify(data) }),
};

export default admin;
