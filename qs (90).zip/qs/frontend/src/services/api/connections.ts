/**
 * API — Connections, Uploads, Iceberg, Registered Tables, REST Queries, Profiles
 */
import { safeFetch, openDownload, _parseError, ApiError, API_BASE_URL } from './core';
import { getAuthHeader } from '../../context/AuthContext';

const connections = {
  // ── Connections ───────────────────────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),
  getConnection: (id: string) => safeFetch(`/api/connections/${id}`),
  createConnection: (data: object) =>
    safeFetch('/api/connections', { method: 'POST', body: JSON.stringify(data) }),
  updateConnection: (id: string, data: object) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnection: (id: string) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),
  testConnection: (data: object) =>
    safeFetch('/api/connections/test', { method: 'POST', body: JSON.stringify(data) }),
  testSavedConnection: (id: string) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),
  refreshConnectionCredentials: (id: string) =>
    safeFetch(`/api/connections/${id}/refresh-credentials`, { method: 'POST' }),
  listConnectionFiles: (connId: string, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),
  getConnectionFileSchema: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/files/${encodeURIComponent(filePath)}/schema`),

  // ── Upload connection files ─────────────────────────────────────────────
  uploadConnectionFiles: async (connId: string, files: File[]): Promise<any> => {
    const form = new FormData();
    files.forEach(f => form.append('files', f));
    const fullUrl = `${API_BASE_URL}/api/connections/${connId}/upload-files`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const response = await fetch(fullUrl, { method: 'POST', headers, body: form });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    return response.json();
  },
  listUploadedFiles: (connId: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files`),
  deleteUploadedFile: (connId: string, filename: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files/${encodeURIComponent(filename)}`, { method: 'DELETE' }),
  getUploadConnectionsStatus: () =>
    safeFetch('/api/connections/upload-status'),

  // ── Iceberg ─────────────────────────────────────────────────────────────
  listIcebergTables: (connId: string, prefix = '') =>
    safeFetch(`/api/connections/${connId}/iceberg/tables?prefix=${encodeURIComponent(prefix)}`),
  listIcebergFiles: (connId: string, tablePrefix: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/files?table_prefix=${encodeURIComponent(tablePrefix)}`),

  // ── Registered Tables ──────────────────────────────────────────────────
  listRegisteredTables: (connId: string) =>
    safeFetch(`/api/connections/${connId}/tables`),
  registerTable: (connId: string, table: { name: string; s3_prefix: string; format: string; description?: string }) =>
    safeFetch(`/api/connections/${connId}/tables`, { method: 'POST', body: JSON.stringify(table) }),
  unregisterTable: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}`, { method: 'DELETE' }),
  getRegisteredTableSchema: (connId: string, tableName: string, refresh?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema${refresh ? '?refresh=true' : ''}`),
  refreshTableSchema: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema/refresh`, { method: 'POST' }),
  refreshAllSchemas: (connId: string) =>
    safeFetch(`/api/connections/${connId}/schema/refresh-all`, { method: 'POST' }),
  getRegisteredTablePartitions: (connId: string, tableName: string, fullScan?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions${fullScan ? '?full_scan=true' : ''}`),
  refreshPartitionCache: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions/refresh`, { method: 'POST' }),
  refreshAllPartitions: (connId?: string) =>
    safeFetch(`/api/partitions/refresh-all${connId ? `?connection_id=${connId}` : ''}`, { method: 'POST' }),
  discoverTables: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/discover-tables?prefix=${encodeURIComponent(prefix || '')}`),
  browseFolders: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/browse-folders?prefix=${encodeURIComponent(prefix || '')}`),

  // ── REST API Query Definitions ─────────────────────────────────────────
  listRestQueryDefs: (connId: string) =>
    safeFetch(`/api/connections/${connId}/rest-queries`),
  createRestQueryDef: (connId: string, data: object) =>
    safeFetch(`/api/connections/${connId}/rest-queries`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  getRestQueryDef: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`),
  updateRestQueryDef: (connId: string, qid: number, data: object) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  deleteRestQueryDef: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`, { method: 'DELETE' }),
  previewRestQuery: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}/preview`, { method: 'POST' }),

  // ── Connection Profiles ─────────────────────────────────────────────────
  listConnectionProfiles: () =>
    safeFetch('/api/connection-profiles').catch(() => ({ profiles: [] })),
  getActiveProfile: () =>
    safeFetch('/api/connection-profiles/active').catch(() => null),
  createConnectionProfile: (data: object) =>
    safeFetch('/api/connection-profiles', { method: 'POST', body: JSON.stringify(data) }),
  updateConnectionProfile: (id: number, data: object) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'DELETE' }),
  activateConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/activate`, { method: 'POST' }),
  deactivateAllProfiles: () =>
    safeFetch('/api/connection-profiles/deactivate', { method: 'POST' }),
  getProfileMappings: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`).catch(() => ({ mappings: [] })),
  setProfileMappings: (id: number, mappings: object[]) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`, { method: 'PUT', body: JSON.stringify({ mappings }) }),

  // ── Report Connectors Matrix ────────────────────────────────────────────
  getReportConnectorMatrix: () =>
    safeFetch('/api/reports/connector-matrix').catch(() => ({ reports: [] })),
  bulkSetConnectionOverride: (reportIds: number[], connectionOverrideId: number | null) =>
    safeFetch('/api/reports/bulk-set-connection-override', {
      method: 'POST',
      body: JSON.stringify({ report_ids: reportIds, connection_override_id: connectionOverrideId }),
    }),
};

export default connections;
