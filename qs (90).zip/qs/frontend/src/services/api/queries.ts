/**
 * API — Saved Queries, Versions, Sharing, Folders, Tags
 */
import { safeFetch, toBackendQueryConfig, type QueryConfig } from './core';

// Forward reference to the composed api object — set by index.ts
let _api: any = null;
export const _setApiRef = (ref: any) => { _api = ref; };

const queries = {
  // ── Saved Queries ─────────────────────────────────────────────────────
  listQueries: (activeOnly: boolean | { active_only?: boolean } = true) => {
    const active = typeof activeOnly === 'object'
      ? (activeOnly.active_only ?? true)
      : activeOnly;
    return safeFetch(`/api/queries?active_only=${active}`).catch(() => []);
  },
  getSavedQueries: (activeOnly = true) =>
    safeFetch(`/api/queries?active_only=${activeOnly}`).catch(() => []),
  getSavedQuery: (id: string) =>
    safeFetch(`/api/queries/${id}`).catch(() => null),
  saveQuery: (data: { name: string; description?: string; query_config: QueryConfig; created_by?: string }) => {
    const payload = {
      name:         data.name,
      description:  data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
      created_by:   data.created_by || null,
    };
    return safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(payload) });
  },
  updateQuery: (id: string, data: { name: string; description?: string; query_config: QueryConfig }) =>
    safeFetch(`/api/queries/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: data.name, description: data.description || null,
        query_config: toBackendQueryConfig(data.query_config),
      }),
    }),
  patchQuery: (id: string | number, data: object) =>
    safeFetch(`/api/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteQuery: (id: string) => safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),
  toggleFavorite: (id: string | number) =>
    safeFetch(`/api/queries/${id}/favorite`, { method: 'POST' }),
  listQueryFolders: () =>
    safeFetch('/api/queries/folders').catch(() => []),
  listQueryTags: () =>
    safeFetch('/api/queries/tags').catch(() => []),
  updateQueryOrganization: (id: number | string, folder: string | null, tags: string[]) =>
    safeFetch(`/api/queries/${id}`, { method: 'PUT', body: JSON.stringify({ folder, tags }) }),

  // ── Query Version History ───────────────────────────────────────────────
  listQueryVersions: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions`).catch(() => []),
  restoreQueryVersion: (queryId: string | number, versionId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions/${versionId}/restore`, { method: 'POST' }),

  // ── Query Sharing ───────────────────────────────────────────────────────
  shareQuery: (queryId: string | number, opts: { expires_hours?: number } = {}) =>
    safeFetch(`/api/queries/${queryId}/share`, { method: 'POST', body: JSON.stringify(opts) }),
  listQueryShares: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/shares`).catch(() => []),
  revokeShare: (queryId: string | number, token: string) =>
    safeFetch(`/api/queries/${queryId}/shares/${token}`, { method: 'DELETE' }),
  getSharedQuery: (token: string) =>
    safeFetch(`/api/shared/${token}`),
};

export default queries;
