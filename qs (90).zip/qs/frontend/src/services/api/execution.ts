/**
 * API — Query Execution, Streaming, Results, Downloads, SQL Connector, Joins
 */
import { safeFetch, sharedFetch, openDownload, _parseError, ApiError, API_BASE_URL, toBackendQueryConfig, type QueryConfig } from './core';
import { getAuthHeader } from '../../context/AuthContext';

// Forward reference to the composed api object — set by index.ts
let _api: any = null;
export const _setApiRef = (ref: any) => { _api = ref; };

const execution = {
  // ── Cost Estimate ──────────────────────────────────────────────────────
  estimateQuery: (queryConfig: QueryConfig, connectionId?: number) =>
    safeFetch('/api/execute/estimate', {
      method: 'POST',
      body: JSON.stringify({
        query_config: toBackendQueryConfig(queryConfig),
        connection_id: connectionId || null,
      }),
    }).catch(() => null),

  // ── Execution ───────────────────────────────────────────────────────────
  executeQuery: (payload: { query_config?: QueryConfig; query_id?: string; raw_sql?: string; connection_id?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    const idempotencyKey = crypto.randomUUID();
    return safeFetch('/api/execute', { method: 'POST', body: JSON.stringify({ ...body, idempotency_key: idempotencyKey }) });
  },
  executeSharedQuery: (shareToken: string, payload: { query_config?: any; query_id?: number }) =>
    sharedFetch(shareToken, '/api/execute', { method: 'POST', body: JSON.stringify(payload) }),
  previewSql: (payload: { query_config: any; connection_id?: number }) =>
    safeFetch('/api/execute/preview-sql', { method: 'POST', body: JSON.stringify(payload) }),
  streamQuery: (payload: { query_config?: any; raw_sql?: string; connection_id?: number; limit?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream', { method: 'POST', body: JSON.stringify(body) });
  },
  streamPaginate: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    page?: number; page_size?: number;
    sort_column?: string | null; sort_direction?: string;
    adv_filters?: string;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/paginate', { method: 'POST', body: JSON.stringify(body) });
  },
  streamSchema: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    sample_rows?: number;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/schema', { method: 'POST', body: JSON.stringify(body) });
  },

  // ── Executions ──────────────────────────────────────────────────────────
  listExecutions: (params: { limit?: number; offset?: number; status?: string } | number = {}) => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  String(p.limit  ?? 50));
    qs.append('offset', String(p.offset ?? 0));
    if (p.status) qs.append('status', p.status);
    return safeFetch(`/api/executions?${qs}`).catch(() => []);
  },
  getExecution: (executionId: string) => safeFetch(`/api/executions/${executionId}`).catch(() => null),
  cancelExecution: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),
  getExecutionStatus: async (executionId: string) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      try {
        const downloads = await (_api?.listDownloads?.('') ?? safeFetch('/api/downloads')) as { execution_id: string; file_id: string }[];
        const match = downloads.find((d: any) => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ───────────────────────────────────────────────────────────
  listDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  getDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  downloadFile: (fileId: string) => openDownload(`/api/downloads/${fileId}/download`),
  deleteDownload: (fileId: string) => safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Results ─────────────────────────────────────────────────────────────
  getExecutionResults: (
    executionId: string, page = 1, pageSize = 100,
    sortColumn: string | null = null, sortDirection = 'asc', filters: object | null = null,
  ) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },
  exportResults: (executionId: string, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),
  getExecutionStats: (executionId: string) => safeFetch(`/api/executions/${executionId}/stats`),
  releaseExecutionResults: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/results`, { method: 'DELETE' }).catch(() => {}),
  getExecutionResultsArrow: async (executionId: string, page = 0, pageSize = 10000): Promise<{
    buffer: ArrayBuffer;
    totalRows: number;
    totalColumns: number;
    page: number;
    pageSize: number;
    rowsInPage: number;
  }> => {
    const url = `${API_BASE_URL}/api/executions/${executionId}/results/arrow?page=${page}&page_size=${pageSize}`;
    const headers: Record<string, string> = { Accept: 'application/vnd.apache.arrow.stream' };
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const response = await fetch(url, { headers });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    const buffer = await response.arrayBuffer();
    return {
      buffer,
      totalRows: parseInt(response.headers.get('X-Total-Rows') || '0', 10),
      totalColumns: parseInt(response.headers.get('X-Total-Columns') || '0', 10),
      page: parseInt(response.headers.get('X-Page') || '0', 10),
      pageSize: parseInt(response.headers.get('X-Page-Size') || '0', 10),
      rowsInPage: parseInt(response.headers.get('X-Rows-In-Page') || '0', 10),
    };
  },

  // ── SQL Queries ─────────────────────────────────────────────────────────
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),
  createSqlQuery: (data: object) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: JSON.stringify(data) }),
  getSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`),
  updateSqlQuery: (id: string, data: object) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),
  executeSqlQuery: (payload: object) =>
    safeFetch('/api/sql/execute', { method: 'POST', body: JSON.stringify(payload) }),
  listSqlCatalogs: (connectionId: string) => safeFetch(`/api/sql/connections/${connectionId}/catalogs`),
  listSqlSchemas: (connectionId: string, catalog: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),
  listSqlTables: (connectionId: string, catalog: string, schema: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),
  listSqlColumns: (connectionId: string, catalog: string, schema: string, table: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),
  testSqlConnection: (connectionId: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Join Preview ────────────────────────────────────────────────────────
  joinPreview: (req: { connection_id?: number; left_file: string; right_file: string;
                        left_on: string[]; right_on: string[]; how?: string }) =>
    safeFetch('/api/joins/preview', { method: 'POST', body: JSON.stringify(req) }),
};

export default execution;
