/**
 * API barrel — composes all domain modules into a single `api` object.
 * Maintains backward compatibility: `import api from '../services/api'` still works.
 */

// Re-export shared types and utilities for direct imports
export { ApiError, safeFetch, sharedFetch, openDownload, toBackendQueryConfig, API_BASE_URL } from './core';
export type {
  QueryConfig, Connection, SavedQuery, Execution, Dataset,
  BusinessReport, DashboardItem, Widget, Schedule, Notification,
} from './core';

import connections from './connections';
import queries from './queries';
import execution from './execution';
import reports from './reports';
import datasets from './datasets';
import businessReports from './businessReports';
import admin from './admin';
import { _setApiRef as _setQueryApiRef } from './queries';
import { _setApiRef as _setExecApiRef } from './execution';

const api = {
  ...admin,
  ...connections,
  ...queries,
  ...execution,
  ...reports,
  ...datasets,
  ...businessReports,
};

// Wire up cross-references (getExecutionStatus → listDownloads, getSavedQueries → listQueries)
_setQueryApiRef(api);
_setExecApiRef(api);

export default api;
