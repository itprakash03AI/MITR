/**
 * API Core — shared infrastructure for all API domain modules.
 * Provides safeFetch, sharedFetch, openDownload, error parsing, and shared types.
 */

import { getAuthHeader } from '../../context/AuthContext';

export const API_BASE_URL = import.meta.env.VITE_API_URL || '';

export class ApiError extends Error {
  errorCode?: string;
  connectionId?: number;
  constructor(message: string, errorCode?: string, connectionId?: number) {
    super(message);
    this.name = 'ApiError';
    this.errorCode = errorCode;
    this.connectionId = connectionId;
  }
}

const RETRY_STATUSES = new Set([502, 503, 504]);
const MAX_RETRIES = 2;
const RETRY_DELAYS = [1000, 3000];

export const _parseError = async (response: Response): Promise<{ detail: string; errorCode?: string; connectionId?: number }> => {
  let detail = `HTTP ${response.status}`;
  let errorCode: string | undefined;
  let connectionId: number | undefined;
  try {
    const e = await response.json() as { detail?: any; message?: string };
    if (typeof e.detail === 'string') {
      detail = e.detail;
    } else if (Array.isArray(e.detail)) {
      detail = (e.detail as { msg?: string; loc?: any[]; input?: any }[]).map(d => {
        let s = d.msg || JSON.stringify(d);
        if (d.loc) s += ` [field: ${d.loc.join('.')}]`;
        if (d.input !== undefined) s += ` [got: ${JSON.stringify(d.input)}]`;
        return s;
      }).join('; ');
    } else if (e.detail && typeof e.detail === 'object') {
      detail = e.detail.message || JSON.stringify(e.detail);
      errorCode = e.detail.error_code;
      connectionId = e.detail.connection_id;
    } else if (e.message) {
      detail = e.message;
    }
  } catch {}
  return { detail, errorCode, connectionId };
};

export const safeFetch = async (url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string>),
  };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  const method = (options.method || 'GET').toUpperCase();
  const canRetry = method === 'GET';

  let lastError: Error | null = null;
  const attempts = canRetry ? MAX_RETRIES + 1 : 1;

  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await fetch(fullUrl, { ...options, headers });
      if (!response.ok) {
        if (response.status === 401) {
          const { detail, errorCode: ec, connectionId: cid } = await _parseError(response);
          if (ec === 'TOKEN_EXPIRED' && cid) {
            throw new ApiError(detail, ec, cid);
          }
          sessionStorage.removeItem('qs_auth');
          window.location.reload();
          return new Promise(() => {});
        }
        if (canRetry && attempt < MAX_RETRIES && RETRY_STATUSES.has(response.status)) {
          await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
          continue;
        }
        const { detail, errorCode: ec, connectionId: cid } = await _parseError(response);
        throw new ApiError(detail, ec, cid);
      }
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        return null;
      }
      return response.json();
    } catch (err) {
      lastError = err as Error;
      if (canRetry && attempt < MAX_RETRIES && err instanceof TypeError) {
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
        continue;
      }
      throw err;
    }
  }
  throw lastError || new ApiError('Request failed after retries');
};

export const openDownload = (path: string) =>
  window.open(path.startsWith('http') ? path : `${API_BASE_URL}${path}`, '_blank');

export const sharedFetch = async (shareToken: string, url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Share-Token': shareToken,
    ...(options.headers as Record<string, string>),
  };
  const response = await fetch(fullUrl, { ...options, headers });
  if (!response.ok) {
    const { detail } = await _parseError(response);
    throw new ApiError(detail);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

// ── Shared types ──────────────────────────────────────────────────────────────

export interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
}

export const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
  };
};

// ── Response interfaces ───────────────────────────────────────────────────────

export interface Connection {
  id: number;
  name: string;
  type: string;
  config: Record<string, any>;
  is_active: boolean;
  test_status?: string;
  test_message?: string;
  last_tested_at?: string;
  created_at?: string;
  updated_at?: string;
}

export interface SavedQuery {
  id: number;
  name: string;
  description?: string;
  query_config: Record<string, any>;
  connection_id?: number;
  created_by?: string;
  is_active: boolean;
  is_favorite?: boolean;
  folder?: string | null;
  tags?: string[] | null;
  created_at?: string;
  updated_at?: string;
}

export interface Execution {
  id: number;
  execution_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  query_config?: Record<string, any>;
  connection_id?: number;
  file_id?: string;
  row_count?: number;
  error_message?: string;
  duration_ms?: number;
  created_at?: string;
}

export interface Dataset {
  id: number;
  name: string;
  subject: string;
  description?: string;
  is_published: boolean;
  owner?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BusinessReport {
  id: number;
  name: string;
  description?: string;
  dataset_id: number;
  owner?: string;
  is_published: boolean;
  is_certified?: boolean;
  template_category?: string;
  config: Record<string, any>;
  created_at?: string;
  updated_at?: string;
}

export interface DashboardItem {
  id: number;
  name: string;
  description?: string;
  owner?: string;
  is_shared: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Widget {
  id: number;
  dashboard_id: number;
  title: string;
  chart_type: string;
  config: Record<string, any>;
  layout?: Record<string, any>;
}

export interface Schedule {
  id: number;
  name: string;
  cron_expression: string;
  query_id?: number;
  report_id?: number;
  is_active: boolean;
  last_run_at?: string;
  next_run_at?: string;
}

export interface Notification {
  id: number;
  type: string;
  message: string;
  is_read: boolean;
  created_at: string;
  metadata?: Record<string, any>;
}
