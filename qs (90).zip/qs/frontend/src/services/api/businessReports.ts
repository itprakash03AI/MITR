/**
 * API — Business Reports, Portal, Delivery & Subscriptions
 */
import { safeFetch, openDownload } from './core';

const businessReports = {
  // ── Business Reports ────────────────────────────────────────────────────
  listBusinessReports: (params?: { owner?: string; dataset_id?: number; published_only?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.owner) qs.set('owner', params.owner);
    if (params?.dataset_id) qs.set('dataset_id', String(params.dataset_id));
    if (params?.published_only) qs.set('published_only', 'true');
    const q = qs.toString();
    return safeFetch(`/api/business-reports${q ? '?' + q : ''}`);
  },
  createBusinessReport: (data: any) =>
    safeFetch('/api/business-reports', { method: 'POST', body: JSON.stringify(data) }),
  getBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}`),
  updateBusinessReport: (id: number, data: any) =>
    safeFetch(`/api/business-reports/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}`, { method: 'DELETE' }),
  executeBusinessReport: (id: number, body: any) =>
    safeFetch(`/api/business-reports/${id}/execute`, { method: 'POST', body: JSON.stringify(body) }),
  downloadBusinessReportPDF: (id: number) =>
    openDownload(`/api/business-reports/${id}/download-pdf`),
  downloadBusinessReportExcel: (id: number) =>
    openDownload(`/api/business-reports/${id}/download-excel`),
  duplicateBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/duplicate`, { method: 'POST' }),
  publishBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/publish`, { method: 'POST' }),

  // ── Business Report Parameters ──────────────────────────────────────────
  listBusinessReportParams: (reportId: number) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`),
  createBusinessReportParam: (reportId: number, data: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`, { method: 'POST', body: JSON.stringify(data) }),
  updateBusinessReportParam: (paramId: number, data: any) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteBusinessReportParam: (paramId: number) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'DELETE' }),
  getBusinessReportParamValues: (reportId: number, body: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameter-values`, { method: 'POST', body: JSON.stringify(body) }),

  // ── Certification & Templates ───────────────────────────────────────────
  certifyBusinessReport: (id: number, templateCategory: string) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'POST', body: JSON.stringify({ template_category: templateCategory }) }),
  uncertifyBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'DELETE' }),
  listTemplates: (category?: string, limit = 50) =>
    safeFetch(`/api/business-reports/templates?limit=${limit}${category ? `&category=${encodeURIComponent(category)}` : ''}`),
  listTemplateCategories: () =>
    safeFetch('/api/business-reports/template-categories'),
  cloneBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/clone`, { method: 'POST' }),

  // ── Share Tokens ────────────────────────────────────────────────────────
  createBusinessReportShare: (id: number, expiresHours?: number) =>
    safeFetch(`/api/business-reports/${id}/share`, { method: 'POST', body: JSON.stringify({ expires_hours: expiresHours }) }),
  listBusinessReportShares: (id: number) =>
    safeFetch(`/api/business-reports/${id}/shares`),
  revokeBusinessReportShare: (id: number, token: string) =>
    safeFetch(`/api/business-reports/${id}/shares/${token}`, { method: 'DELETE' }),
  getSharedBusinessReport: (token: string) =>
    safeFetch(`/api/shared-business-report/${token}`),
  executeSharedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/shared-business-report/${token}/execute`, { method: 'POST', body: JSON.stringify(body) }),

  // ── Embed Tokens ────────────────────────────────────────────────────────
  createBusinessReportEmbed: (id: number, expiresInDays?: number) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`, { method: 'POST', body: JSON.stringify({ expires_in_days: expiresInDays }) }),
  listBusinessReportEmbeds: (id: number) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`),
  revokeBusinessReportEmbed: (token: string) =>
    safeFetch(`/api/business-reports/embed-tokens/${token}`, { method: 'DELETE' }),
  getEmbeddedBusinessReport: (token: string) =>
    safeFetch(`/api/embedded-business-report/${token}`),
  executeEmbeddedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/embedded-business-report/${token}/execute`, { method: 'POST', body: JSON.stringify(body) }),

  // ── Business Portal ─────────────────────────────────────────────────────
  getPortalSummary: () =>
    safeFetch('/api/portal/summary'),

  // ── Delivery & Subscriptions ────────────────────────────────────────────
  createSubscription: (data: any) =>
    safeFetch('/api/subscriptions', { method: 'POST', body: JSON.stringify(data) }),
  listSubscriptions: (reportId?: number, reportType?: string) => {
    const params = new URLSearchParams();
    if (reportId != null) params.set('report_id', String(reportId));
    if (reportType) params.set('report_type', reportType);
    const qs = params.toString();
    return safeFetch(`/api/subscriptions${qs ? '?' + qs : ''}`);
  },
  getSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`),
  updateSubscription: (id: number, data: any) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'DELETE' }),
  testSendSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/test-send`, { method: 'POST' }),
  pauseSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/pause`, { method: 'POST' }),
  resumeSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/resume`, { method: 'POST' }),
  getSubscriptionHistory: (id: number, limit = 50) =>
    safeFetch(`/api/subscriptions/${id}/history?limit=${limit}`),
};

export default businessReports;
