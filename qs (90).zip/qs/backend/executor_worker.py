"""
QueryStudio Executor Worker — standalone process.

Polls the ``task_queue`` table, claims pending tasks, executes them
using the same DuckDB/parquet engine as the main process, and
updates the task status + QueryExecution record on completion.

Usage:
    python executor_worker.py
    python -m querystudio executor

The worker exposes a small internal FastAPI control API on
``executor.worker_host:executor.worker_port`` (default 127.0.0.1:8002)
for health checks, pause/resume, and status.

Only needed when ``executor.mode = "external"`` in config.json.
When ``executor.mode = "embedded"`` (default), tasks run in-process
via WorkerPool and this process is not required.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import signal
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ensure the backend directory is on sys.path so ``core.*`` imports work
_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI, HTTPException

# psutil is optional — used for heartbeat metrics and load-aware claiming
try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    psutil = None  # type: ignore[assignment]
    _HAS_PSUTIL = False

logger = logging.getLogger("executor_worker")


# ── Webhook helper ────────────────────────────────────────────────────────────

def _fire_webhook(callback_url: str, payload: dict) -> None:
    """POST task result to callback_url — non-blocking, best-effort, daemon thread."""
    import urllib.request as _urlreq
    import json as _json

    def _post():
        try:
            data = _json.dumps(payload, default=str).encode()
            req = _urlreq.Request(
                callback_url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "QueryStudio/1.0",
                },
                method="POST",
            )
            with _urlreq.urlopen(req, timeout=15):
                pass
            logger.info("Webhook delivered: %s", callback_url)
        except Exception as exc:
            logger.warning("Webhook POST failed to %s: %s", callback_url, exc)

    threading.Thread(target=_post, daemon=True).start()

# ── Globals (set during lifespan) ────────────────────────────────────────────
_db_manager = None
_db_url: str = ""
_worker_id: str = ""
_shutdown_event = threading.Event()
_executor_thread: Optional[threading.Thread] = None
_stale_thread: Optional[threading.Thread] = None
_heartbeat_thread: Optional[threading.Thread] = None
_paused = threading.Event()  # clear = paused, set = running
_paused.set()  # start running

# Stats
_stats = {
    "tasks_completed": 0,
    "tasks_failed": 0,
    "tasks_claimed": 0,
    "started_at": None,
}


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup: init DB + start executor loop. Shutdown: stop loop."""
    global _db_manager, _db_url, _worker_id, _executor_thread, _stale_thread, _heartbeat_thread

    # ── Load config ──────────────────────────────────────────────────────
    from core.config import paths as _paths, executor as _exec_cfg

    # ── Logging ──────────────────────────────────────────────────────────
    log_level = os.getenv("QUERYSTUDIO_SERVER_LOG_LEVEL", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Database ─────────────────────────────────────────────────────────
    db_file = Path(_paths.db_file).resolve()
    _db_url = f"sqlite:///{db_file.as_posix()}"

    from core.database import DatabaseManager
    _db_manager = DatabaseManager(db_url=_db_url)
    logger.info("Database: %s", _db_url)

    # ── Queue backend ──────────────────────────────────────────────────
    from core.queue_backend import init_queue_backend, get_task_queue
    init_queue_backend(_db_manager)
    _tq = get_task_queue()
    logger.info("Queue backend: %s", _tq.backend_type)

    # ── Worker identity ──────────────────────────────────────────────────
    _worker_id = f"{platform.node()}:{os.getpid()}"
    _stats["started_at"] = datetime.now(timezone.utc).isoformat()
    logger.info("Worker ID: %s", _worker_id)

    # ── Start executor loop thread ───────────────────────────────────────
    _executor_thread = threading.Thread(
        target=_executor_main_loop,
        args=(_tq, _db_manager, _worker_id, _exec_cfg.max_concurrent, _exec_cfg.poll_interval),
        daemon=True,
        name="executor-loop",
    )
    _executor_thread.start()

    # ── Start stale task reclaimer thread ────────────────────────────────
    _stale_thread = threading.Thread(
        target=_stale_reclaimer_loop,
        args=(_tq, _exec_cfg.stale_timeout_seconds),
        daemon=True,
        name="stale-reclaimer",
    )
    _stale_thread.start()

    # ── Start heartbeat loop thread (Phase 45D) ─────────────────────────
    _heartbeat_thread = threading.Thread(
        target=_heartbeat_loop,
        args=(_db_manager, _worker_id, _exec_cfg.max_concurrent),
        daemon=True,
        name="heartbeat-loop",
    )
    _heartbeat_thread.start()

    logger.info(
        "Executor worker ready on %s:%d (max_concurrent=%d, poll=%.1fs)",
        _exec_cfg.worker_host, _exec_cfg.worker_port,
        _exec_cfg.max_concurrent, _exec_cfg.poll_interval,
    )

    yield  # ── App is running ──

    # ── Shutdown ─────────────────────────────────────────────────────────
    _shutdown_event.set()
    if _executor_thread and _executor_thread.is_alive():
        _executor_thread.join(timeout=10)
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        _heartbeat_thread.join(timeout=5)
    # Safety-net deregister in case heartbeat thread did not complete cleanly
    try:
        from core.worker_registry import get_worker_registry
        get_worker_registry().deregister(_worker_id)
    except Exception:
        pass
    logger.info("Executor worker stopped")


# ── Executor main loop ───────────────────────────────────────────────────────

def _executor_main_loop(task_queue, db_manager, worker_id: str, max_concurrent: int, poll_interval: float):
    """Claim tasks from queue, execute them in a thread pool.

    Uses blocking pop (BZPOPMIN) for Redis — instant delivery.
    Uses polling (claim_next_task) for SQLite — same as before.
    """
    semaphore = threading.Semaphore(max_concurrent)
    pool = ThreadPoolExecutor(max_workers=max_concurrent, thread_name_prefix="exec")
    use_blocking = task_queue.backend_type == "redis"

    logger.info("Executor loop started (max_concurrent=%d, blocking=%s)", max_concurrent, use_blocking)

    while not _shutdown_event.is_set():
        # Check if paused
        if not _paused.is_set():
            _shutdown_event.wait(1.0)
            continue

        # Load-aware gate (Phase 45E) — skip claiming if system is overloaded
        if _should_skip_claiming():
            _shutdown_event.wait(poll_interval)
            continue

        # Try to acquire a slot (non-blocking)
        if not semaphore.acquire(timeout=0.5):
            continue

        try:
            if use_blocking:
                task = task_queue.wait_and_claim_task(worker_id, timeout=poll_interval)
            else:
                task = task_queue.claim_next_task(worker_id)
        except Exception as exc:
            semaphore.release()
            logger.error("Failed to claim task: %s", exc)
            _shutdown_event.wait(poll_interval)
            continue

        if not task:
            semaphore.release()
            if not use_blocking:
                _shutdown_event.wait(poll_interval)
            continue

        _stats["tasks_claimed"] += 1
        logger.info("Claimed task %s (type=%s, execution=%s)",
                     task["task_id"], task["task_type"], task.get("execution_id"))

        pool.submit(_run_task_safe, task_queue, db_manager, task, semaphore)

    pool.shutdown(wait=True, cancel_futures=True)
    logger.info("Executor loop stopped")


def _run_task_safe(task_queue, db_manager, task: dict, semaphore):
    """Execute a task with error handling. Always releases semaphore."""
    callback_url = (task.get("payload") or {}).get("callback_url", "")
    execution_id = task.get("execution_id", "")
    try:
        _run_task(task_queue, db_manager, task)
        _stats["tasks_completed"] += 1
        if callback_url:
            _fire_webhook(callback_url, {
                "event": "task_completed",
                "execution_id": execution_id,
                "task_id": task["task_id"],
                "status": "completed",
            })
    except InterruptedError:
        # Cooperative cancellation — not a failure
        logger.info("Task %s cancelled by user", task["task_id"])
        try:
            task_queue.fail_task(task["task_id"], "Cancelled by user")
            if execution_id:
                db_manager.update_execution(
                    execution_id,
                    status="cancelled",
                    error_message="Cancelled by user",
                )
        except Exception:
            pass
        if callback_url:
            _fire_webhook(callback_url, {
                "event": "task_cancelled",
                "execution_id": execution_id,
                "task_id": task["task_id"],
                "status": "cancelled",
            })
    except Exception as exc:
        _stats["tasks_failed"] += 1
        error_str = str(exc)
        retry_count  = int(task.get("retry_count", 0))
        max_retries  = int(task.get("max_retries", 3))

        if retry_count < max_retries:
            # ── Exponential backoff retry (22C) ──────────────────────────────
            # Delay = min(base * 2^retry, cap) with base=30s, cap=1800s
            base_delay = 30
            delay_secs = min(base_delay * (2 ** retry_count), 1800)
            logger.warning(
                "Task %s failed (attempt %d/%d), retrying in %ds: %s",
                task["task_id"], retry_count + 1, max_retries + 1, delay_secs, error_str
            )
            try:
                # Re-enqueue with future timestamp as priority score
                new_task_id = str(uuid.uuid4())
                new_payload = dict(task.get("payload") or {})
                task_queue.enqueue_task(
                    task_id=new_task_id,
                    task_type=task.get("task_type", "parquet_query"),
                    payload=new_payload,
                    execution_id=execution_id,
                    created_by=task.get("created_by", ""),
                    priority=task.get("priority", 5),
                    retry_count=retry_count + 1,
                    max_retries=max_retries,
                    delay_seconds=delay_secs,
                )
                # Update execution status to reflect retry
                if execution_id:
                    db_manager.update_execution(
                        execution_id,
                        status="pending",
                        error_message=f"Retry {retry_count + 1}/{max_retries} in {delay_secs}s: {error_str}",
                    )
            except Exception as retry_exc:
                logger.error("Failed to re-enqueue task %s for retry: %s", task["task_id"], retry_exc)
            # Mark original task as failed
            try:
                task_queue.fail_task(task["task_id"], f"[retry {retry_count+1}] {error_str}")
            except Exception:
                pass
        else:
            # ── Exhausted retries → Dead-Letter Queue (22C) ──────────────────
            logger.error(
                "Task %s permanently failed after %d attempts, moving to DLQ: %s",
                task["task_id"], max_retries + 1, error_str, exc_info=True
            )
            try:
                task_queue.fail_task(task["task_id"], f"[DLQ] {error_str}")
                if execution_id:
                    db_manager.update_execution(
                        execution_id,
                        status="failed",
                        error_message=f"Permanently failed after {max_retries + 1} attempts: {error_str}",
                    )
                # Push to DLQ table for manual review/replay
                db_manager.push_dead_letter(
                    {**task, "retry_count": retry_count},
                    error=error_str,
                )
                _stats["tasks_dead_lettered"] = _stats.get("tasks_dead_lettered", 0) + 1
            except Exception:
                logger.error("Failed to push task %s to DLQ", task["task_id"], exc_info=True)

            if callback_url:
                _fire_webhook(callback_url, {
                    "event": "task_failed",
                    "execution_id": execution_id,
                    "task_id": task["task_id"],
                    "status": "failed",
                    "error": error_str,
                    "dead_lettered": True,
                })
    finally:
        semaphore.release()


def _run_task(task_queue, db_manager, task: dict):
    """Execute a single task based on its type."""
    task_type = task["task_type"]
    payload = task["payload"]
    task_id = task["task_id"]
    execution_id = task.get("execution_id")

    # Progress callback: writes to task queue + checks cancellation
    _last_progress_t = [time.monotonic()]
    _last_cancel_check = [time.monotonic()]

    def progress_fn(data: dict):
        now = time.monotonic()

        # Check cancellation every 2 seconds
        if now - _last_cancel_check[0] >= 2.0:
            _last_cancel_check[0] = now
            try:
                if task_queue.is_task_cancelled(task_id):
                    raise InterruptedError("Cancelled by user")
            except InterruptedError:
                raise
            except Exception:
                pass

        # Throttle progress writes to 1 update/second
        is_terminal = data.get("status") in ("completed", "failed")
        if not is_terminal and now - _last_progress_t[0] < 1.0:
            return
        _last_progress_t[0] = now

        pct = data.get("progress_pct", 0)
        detail = data.get("log", "")
        try:
            task_queue.update_task_progress(task_id, pct, detail)
        except Exception:
            pass
        # Also update QueryExecution status (always in SQLite)
        if execution_id:
            try:
                db_manager.update_execution(
                    execution_id,
                    status="processing",
                    chunks_processed=data.get("chunks_processed", 0),
                    total_rows=data.get("total_rows", 0),
                )
            except Exception:
                pass

    if task_type == "parquet_query":
        result = _execute_parquet_query(db_manager, payload, progress_fn)
    elif task_type == "sql_query":
        result = _execute_sql_query(db_manager, payload, progress_fn)
    elif task_type == "export":
        result = _execute_export(db_manager, payload, progress_fn)
    elif task_type == "mv_refresh":
        result = _execute_mv_refresh(db_manager, payload, progress_fn)
    elif task_type == "lt_promote":
        result = _execute_lt_promote(db_manager, payload, progress_fn)
    elif task_type == "lt_upload":
        result = _execute_lt_upload(db_manager, payload, progress_fn)
    else:
        raise ValueError(f"Unknown task type: {task_type}")

    # Finalize: update QueryExecution + register DownloadFile
    _finalize_task(db_manager, task, result)
    task_queue.complete_task(task_id, result)
    logger.info("Task %s completed: %s", task_id, result)


def _finalize_task(db_manager, task: dict, result: dict):
    """Update QueryExecution record and register DownloadFile."""
    execution_id = task.get("execution_id")
    if not execution_id:
        return

    output_file = result.get("output_file")
    total_rows = result.get("total_rows", 0)
    file_size = result.get("file_size_bytes", 0)

    db_manager.update_execution(
        execution_id,
        status="completed",
        total_rows=total_rows,
        file_size_bytes=file_size,
        output_file=output_file,
    )

    # Register download file
    if output_file and os.path.exists(output_file):
        file_id = str(uuid.uuid4())
        filename = os.path.basename(output_file)
        try:
            from datetime import timedelta
            db_manager.create_download_file(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=output_file,
                file_size_bytes=file_size,
                created_by=task.get("created_by", "executor"),
                expires_at=datetime.now(timezone.utc) + timedelta(days=7),
            )
            result["file_id"] = file_id
        except Exception as exc:
            logger.warning("Failed to register download file: %s", exc)


# ── Task execution functions ─────────────────────────────────────────────────
# These import and reuse the same core functions from main.py.

def _resolve_connection(db_manager, connection_id) -> dict:
    """Resolve connection config with decrypted credentials."""
    if not connection_id:
        return None
    conn_record = db_manager.get_connection_raw(connection_id)
    if not conn_record:
        logger.warning("Connection %s not found", connection_id)
        return None
    return conn_record


def _setup_engine_s3(engine, conn_record, connection_id):
    """Inject S3 credentials into ParquetQueryEngine (mirrors main.py:4915-4918)."""
    cfg = conn_record.get("config", {}) if conn_record else {}
    conn_type = conn_record.get("connection_type", "") if conn_record else ""

    if conn_type == "s3" and cfg.get("bucket_name"):
        engine._s3_conn_config = cfg
        engine._registered_tables = cfg.get("registered_tables", [])
        engine._s3_bucket = cfg.get("bucket_name", "")
        engine._s3_conn_id = connection_id
        try:
            from core.s3_storage import build_s3_config
            engine.s3_config = build_s3_config(cfg)
        except Exception as exc:
            logger.warning("Failed to build S3 config: %s", exc)
    else:
        engine._s3_conn_config = {}
        engine._registered_tables = []
        engine._s3_bucket = ""
        engine._s3_conn_id = connection_id


def _apply_duckdb_env_limits():
    """Set DuckDB memory/thread limits via environment variables.

    duckdb_subprocess.py reads DUCKDB_MEMORY_LIMIT and DUCKDB_THREADS
    at lines 169-180 before executing queries.
    """
    from core.config import executor as _exec_cfg
    mem_limit_gb = _exec_cfg.max_memory_per_task_gb
    if mem_limit_gb > 0:
        os.environ["DUCKDB_MEMORY_LIMIT"] = f"{mem_limit_gb}GB"
        logger.info("DuckDB memory limit: %dGB (via env)", mem_limit_gb)
    threads = min(4, os.cpu_count() or 4)
    os.environ["DUCKDB_THREADS"] = str(threads)


def _execute_parquet_query(db_manager, payload: dict, progress_fn) -> dict:
    """Execute a parquet query using the same engine as main.py.

    Features:
    - S3 credential resolution from connection_id
    - DuckDB memory budget via environment variables
    - Per-chunk cancellation via progress_fn (checks cancel_requested in DB)
    - Streaming parquet write with zstd compression
    """
    from main import ParquetQueryEngine, QueryConfig
    from core.config import paths as _paths

    execution_id = payload["execution_id"]
    query_config = payload["query_config"]
    connection_id = payload.get("connection_id")

    # Build output path
    output_dir = Path(_paths.data_dir) / "downloads"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = str(output_dir / f"{execution_id}.parquet")

    # Resolve S3 credentials from connection
    conn_record = _resolve_connection(db_manager, connection_id)

    # Create engine + inject S3 config
    engine = ParquetQueryEngine(data_dir=_paths.data_dir)
    _setup_engine_s3(engine, conn_record, connection_id)

    # Build query config object
    qc = QueryConfig(**query_config) if isinstance(query_config, dict) else query_config

    # Set DuckDB memory/thread limits via env vars (read by duckdb_subprocess)
    _apply_duckdb_env_limits()

    progress_fn({"log": "Starting query execution...", "progress_pct": 5})

    result = engine.execute_query(qc)

    # Stream results to parquet with per-chunk cancellation
    import pyarrow.parquet as pq
    total_rows = 0
    writer = None
    try:
        for chunk in result:
            # progress_fn checks cancel_requested in DB (raises InterruptedError)
            progress_fn({
                "log": f"{total_rows:,} rows processed",
                "progress_pct": min(90, 10 + int(total_rows / 1000)),
                "total_rows": total_rows,
                "chunks_processed": total_rows,
            })
            if writer is None:
                writer = pq.ParquetWriter(output_file, chunk.schema, compression="zstd")
            writer.write_table(chunk)
            total_rows += len(chunk)
    finally:
        if writer:
            writer.close()

    file_size = os.path.getsize(output_file) if os.path.exists(output_file) else 0
    progress_fn({"log": f"Complete: {total_rows:,} rows", "progress_pct": 100, "status": "completed"})

    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "output_file": output_file,
        "status": "completed",
    }


def _execute_sql_query(db_manager, payload: dict, progress_fn) -> dict:
    """Execute a SQL connector query (Snowflake, Trino, Databricks, Oracle)."""
    from core.config import paths as _paths

    connection_id = payload["connection_id"]
    raw_sql = payload.get("raw_sql", "")
    execution_id = payload["execution_id"]

    conn_record = _resolve_connection(db_manager, connection_id)
    if not conn_record:
        raise ValueError(f"Connection {connection_id} not found")

    conn_type = conn_record["connection_type"]
    cfg = conn_record["config"]

    from core.connectors import get_connector
    connector = get_connector(conn_type, cfg)

    progress_fn({"log": f"Connecting to {conn_type}...", "progress_pct": 10})
    con = connector.get_connection()

    try:
        progress_fn({"log": "Executing SQL...", "progress_pct": 20})
        cursor = con.cursor()
        cursor.execute(raw_sql)
        columns = [desc[0] for desc in cursor.description]

        # Stream to parquet
        output_dir = Path(_paths.data_dir) / "downloads"
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = str(output_dir / f"{execution_id}.parquet")

        import pyarrow as pa
        import pyarrow.parquet as pq

        total_rows = 0
        writer = None
        try:
            while True:
                batch = cursor.fetchmany(50000)
                if not batch:
                    break
                progress_fn({
                    "log": f"{total_rows:,} rows fetched from {conn_type}",
                    "progress_pct": min(85, 30 + total_rows // 1000),
                })
                # Build pyarrow table from rows
                col_data = {col: [row[i] for row in batch] for i, col in enumerate(columns)}
                table = pa.table(col_data)
                if writer is None:
                    writer = pq.ParquetWriter(output_file, table.schema, compression="zstd")
                writer.write_table(table)
                total_rows += len(batch)
        finally:
            if writer:
                writer.close()
            cursor.close()
    finally:
        try:
            con.close()
        except Exception:
            pass

    file_size = os.path.getsize(output_file) if os.path.exists(output_file) else 0
    progress_fn({"log": f"Complete: {total_rows:,} rows from {conn_type}", "progress_pct": 100, "status": "completed"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "output_file": output_file,
        "status": "completed",
    }


def _execute_export(db_manager, payload: dict, progress_fn) -> dict:
    """Convert a parquet result file to CSV/XLSX/JSON."""
    from core.config import paths as _paths

    source_file = payload["source_file"]
    output_format = payload.get("format", "csv")
    execution_id = payload.get("execution_id", str(uuid.uuid4()))

    output_dir = Path(_paths.data_dir) / "downloads"
    output_dir.mkdir(parents=True, exist_ok=True)

    progress_fn({"log": f"Exporting to {output_format.upper()}...", "progress_pct": 20})

    import duckdb
    src = source_file.replace("\\", "/")
    con = duckdb.connect()
    out_path = None
    try:
        if output_format == "csv":
            out_path = str(output_dir / f"{execution_id}.csv")
            dest = out_path.replace("\\", "/")
            con.execute(f"COPY (SELECT * FROM read_parquet('{src}')) TO '{dest}' (HEADER, DELIMITER ',')")
        elif output_format == "xlsx":
            import pandas as pd
            df = con.execute(f"SELECT * FROM read_parquet('{src}')").fetchdf()
            out_path = str(output_dir / f"{execution_id}.xlsx")
            df.to_excel(out_path, index=False)
        elif output_format == "json":
            out_path = str(output_dir / f"{execution_id}.json")
            dest = out_path.replace("\\", "/")
            con.execute(f"COPY (SELECT * FROM read_parquet('{src}')) TO '{dest}' (FORMAT JSON)")
        else:
            raise ValueError(f"Unsupported export format: {output_format}")
    finally:
        con.close()

    file_size = os.path.getsize(out_path) if out_path and os.path.exists(out_path) else 0
    progress_fn({"log": f"Export complete: {output_format.upper()}", "progress_pct": 100, "status": "completed"})
    return {
        "output_file": out_path,
        "file_size_bytes": file_size,
        "format": output_format,
        "status": "completed",
    }


def _execute_mv_refresh(db_manager, payload: dict, progress_fn) -> dict:
    """Refresh a materialized view — reuses main.py's sync function."""
    mv_id = payload["mv_id"]
    progress_fn({"log": f"Starting MV refresh (id={mv_id})...", "progress_pct": 10})

    from core.mv_manager import refresh_materialized_view_sync as _refresh_materialized_view_sync
    _refresh_materialized_view_sync(mv_id)

    mv = db_manager.get_materialized_view(mv_id)
    row_count = mv.get("row_count", 0) if mv else 0
    progress_fn({"log": f"MV refresh complete: {row_count:,} rows", "progress_pct": 100, "status": "completed"})
    return {"mv_id": mv_id, "row_count": row_count, "status": "completed"}


def _execute_lt_promote(db_manager, payload: dict, progress_fn) -> dict:
    """Promote a download file to a local table — reuses main.py's sync function."""
    lt_id = payload["lt_id"]
    source_path = payload["source_path"]
    progress_fn({"log": f"Promoting local table {lt_id}...", "progress_pct": 20})

    from core.mv_manager import promote_download_sync as _promote_download_sync
    _promote_download_sync(lt_id, source_path)

    progress_fn({"log": "Promotion complete", "progress_pct": 100, "status": "completed"})
    return {"lt_id": lt_id, "status": "completed"}


def _execute_lt_upload(db_manager, payload: dict, progress_fn) -> dict:
    """Convert an uploaded file to parquet local table — reuses main.py's sync function."""
    lt_id = payload["lt_id"]
    temp_path = payload["temp_path"]
    original_filename = payload["original_filename"]
    progress_fn({"log": f"Converting {original_filename}...", "progress_pct": 20})

    from core.mv_manager import upload_file_to_local_table_sync as _upload_file_to_local_table_sync
    _upload_file_to_local_table_sync(lt_id, temp_path, original_filename)

    progress_fn({"log": "Upload complete", "progress_pct": 100, "status": "completed"})
    return {"lt_id": lt_id, "status": "completed"}


# ── Heartbeat loop (Phase 45D) ────────────────────────────────────────────────

def _heartbeat_loop(db_manager, worker_id: str, max_concurrent: int):
    """Periodically send heartbeats to the worker registry with system metrics.

    Registers on first call, then loops sending heartbeats every
    ``horizontal_workers.heartbeat_interval_seconds``.  Deregisters on exit.
    """
    from core.worker_registry import init_worker_registry, get_worker_registry, WorkerInfo
    from core.config import horizontal_workers as _hw_cfg

    interval = _hw_cfg.heartbeat_interval_seconds

    # Initialise the registry (idempotent — uses the module singleton)
    try:
        init_worker_registry(db_manager)
    except Exception as exc:
        logger.error("Failed to initialise worker registry: %s", exc)
        return

    registry = get_worker_registry()

    # Build initial WorkerInfo
    now_iso = datetime.now(timezone.utc).isoformat()
    info = WorkerInfo(
        worker_id=worker_id,
        hostname=platform.node(),
        pid=os.getpid(),
        status="active",
        worker_type="executor",
        started_at=_stats.get("started_at", now_iso),
        last_heartbeat=now_iso,
        active_tasks=0,
        max_concurrent=max_concurrent,
        cpu_pct=0.0,
        memory_pct=0.0,
        memory_mb=0,
        tasks_completed=_stats.get("tasks_completed", 0),
        tasks_failed=_stats.get("tasks_failed", 0),
        version="1.0",
    )

    # Register on startup
    try:
        registry.register(info)
        logger.info("Heartbeat loop registered worker %s (interval=%ds)", worker_id, interval)
    except Exception as exc:
        logger.error("Failed to register worker %s: %s", worker_id, exc)

    # Heartbeat loop
    while not _shutdown_event.is_set():
        _shutdown_event.wait(interval)
        if _shutdown_event.is_set():
            break

        # Collect system metrics
        cpu_pct = 0.0
        memory_pct = 0.0
        memory_mb = 0
        if _HAS_PSUTIL:
            try:
                cpu_pct = psutil.cpu_percent(interval=0)
                mem = psutil.virtual_memory()
                memory_pct = mem.percent
                memory_mb = int(mem.used / (1024 * 1024))
            except Exception:
                pass

        # Determine status
        status = "paused" if not _paused.is_set() else "active"

        now_iso = datetime.now(timezone.utc).isoformat()
        info = WorkerInfo(
            worker_id=worker_id,
            hostname=platform.node(),
            pid=os.getpid(),
            status=status,
            worker_type="executor",
            started_at=_stats.get("started_at", now_iso),
            last_heartbeat=now_iso,
            active_tasks=_stats.get("tasks_claimed", 0) - _stats.get("tasks_completed", 0) - _stats.get("tasks_failed", 0),
            max_concurrent=max_concurrent,
            cpu_pct=cpu_pct,
            memory_pct=memory_pct,
            memory_mb=memory_mb,
            tasks_completed=_stats.get("tasks_completed", 0),
            tasks_failed=_stats.get("tasks_failed", 0),
            version="1.0",
        )

        try:
            registry.heartbeat(worker_id, info)
        except Exception as exc:
            logger.warning("Heartbeat failed for %s: %s", worker_id, exc)

    # Deregister on exit
    try:
        registry.deregister(worker_id)
        logger.info("Heartbeat loop deregistered worker %s", worker_id)
    except Exception as exc:
        logger.warning("Failed to deregister worker %s: %s", worker_id, exc)


# ── Load-aware claiming (Phase 45E) ──────────────────────────────────────────

def _should_skip_claiming() -> bool:
    """Return True if this worker should skip claiming due to high resource usage.

    Reads thresholds from ``horizontal_workers`` config.  Uses psutil if
    available; if psutil is not installed, always returns False (never skips).
    """
    from core.config import horizontal_workers as _hw_cfg

    if not _hw_cfg.enable_load_aware_claiming:
        return False

    if not _HAS_PSUTIL:
        return False

    try:
        mem = psutil.virtual_memory()
        if mem.percent > _hw_cfg.memory_threshold_pct:
            logger.warning(
                "Load-aware skip: memory usage %.1f%% exceeds threshold %d%%",
                mem.percent, _hw_cfg.memory_threshold_pct,
            )
            return True
    except Exception:
        pass

    try:
        cpu = psutil.cpu_percent(interval=0.1)
        if cpu > _hw_cfg.cpu_threshold_pct:
            logger.warning(
                "Load-aware skip: CPU usage %.1f%% exceeds threshold %d%%",
                cpu, _hw_cfg.cpu_threshold_pct,
            )
            return True
    except Exception:
        pass

    return False


# ── Stale task reclaimer ─────────────────────────────────────────────────────

def _stale_reclaimer_loop(task_queue, stale_timeout: int):
    """Periodically re-claim tasks stuck in claimed/processing state."""
    while not _shutdown_event.is_set():
        try:
            count = task_queue.reclaim_stale_tasks(stale_seconds=stale_timeout)
            if count:
                logger.info("Reclaimed %d stale task(s)", count)
        except Exception as exc:
            logger.warning("Stale reclaimer error: %s", exc)
        _shutdown_event.wait(60)  # Check every 60 seconds


# ── FastAPI control app ──────────────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio Executor Worker",
    docs_url=None,
    redoc_url=None,
    lifespan=_lifespan,
)


@control_app.get("/health")
async def health():
    """Liveness probe — always 200 if process is up."""
    return {
        "status": "ok",
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        **_stats,
    }


@control_app.get("/control/status")
async def executor_status():
    """Full executor state: active tasks, queue depth, stats."""
    pending = []
    active = []
    try:
        from core.queue_backend import get_task_queue
        tq = get_task_queue()
        pending = tq.list_tasks(status="pending", limit=20)
        active = tq.list_tasks(status="processing", limit=20)
    except Exception:
        pass
    return {
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        "pending_count": len(pending),
        "active_count": len(active),
        "pending_tasks": pending,
        "active_tasks": active,
        **_stats,
    }


@control_app.post("/control/pause")
async def pause():
    """Pause claiming new tasks. Running tasks finish normally."""
    _paused.clear()
    logger.info("Executor paused")
    return {"message": "Executor paused"}


@control_app.post("/control/resume")
async def resume():
    """Resume claiming tasks."""
    _paused.set()
    logger.info("Executor resumed")
    return {"message": "Executor resumed"}


@control_app.post("/control/shutdown")
async def shutdown():
    """Graceful shutdown — stop executor and exit."""
    logger.info("Shutdown requested via control API")
    def _delayed_exit():
        time.sleep(1)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return {"message": "Shutting down"}


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    import uvicorn
    from core.config import executor as _exec_cfg

    host = _exec_cfg.worker_host
    port = _exec_cfg.worker_port

    print(f"[executor_worker] Starting on {host}:{port}")

    # Windows Ctrl+C handling
    if sys.platform == "win32":
        def _sigint_handler(signum, frame):
            print("\n[executor_worker] Ctrl+C — stopping...")
            _shutdown_event.set()
            os._exit(0)
        signal.signal(signal.SIGINT, _sigint_handler)
        try:
            signal.signal(signal.SIGBREAK, _sigint_handler)
        except (AttributeError, OSError):
            pass

    uvicorn.run(
        control_app,
        host=host,
        port=port,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
