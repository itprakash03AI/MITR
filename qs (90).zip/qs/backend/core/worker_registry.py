"""
Worker Registration & Discovery for Phase 45 — Horizontal Scaling.

Provides a registry where executor/scheduler workers advertise themselves
via heartbeats.  Other components (load-aware task claiming, admin UI) use
the registry to discover live workers and aggregate fleet metrics.

Implementations:
  - RedisWorkerRegistry:  Redis hashes + sets with TTL (preferred for multi-host)
  - SqliteWorkerRegistry: DatabaseManager-backed fallback (single-host / dev)

Factory:
  - init_worker_registry(db_manager) -> WorkerRegistryBackend
  - get_worker_registry()            -> WorkerRegistryBackend

Config (config.json → ``horizontal_workers`` section):
  registry_backend:         "auto" | "redis" | "sqlite"
  heartbeat_ttl_seconds:    45
  worker_eviction_seconds:  120
"""

from __future__ import annotations

import abc
import json
import logging
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# WorkerInfo — serialisable snapshot of a single worker node
# ---------------------------------------------------------------------------

@dataclass
class WorkerInfo:
    """Immutable snapshot of a worker's state, exchanged on register/heartbeat."""

    worker_id: str            # hostname:pid
    hostname: str
    pid: int
    status: str               # "active" | "draining" | "paused"
    worker_type: str           # "executor" | "scheduler"
    started_at: str            # ISO-8601 timestamp
    last_heartbeat: str        # ISO-8601 timestamp
    active_tasks: int
    max_concurrent: int
    cpu_pct: float
    memory_pct: float
    memory_mb: int
    tasks_completed: int
    tasks_failed: int
    version: str               # application version string

    # -- helpers --

    def to_dict(self) -> Dict[str, Any]:
        """Return a plain dict suitable for JSON serialisation."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkerInfo":
        """Construct from a dict, coercing types defensively."""
        return cls(
            worker_id=str(data.get("worker_id", "")),
            hostname=str(data.get("hostname", "")),
            pid=int(data.get("pid", 0)),
            status=str(data.get("status", "active")),
            worker_type=str(data.get("worker_type", "executor")),
            started_at=str(data.get("started_at", "")),
            last_heartbeat=str(data.get("last_heartbeat", "")),
            active_tasks=int(data.get("active_tasks", 0)),
            max_concurrent=int(data.get("max_concurrent", 0)),
            cpu_pct=float(data.get("cpu_pct", 0.0)),
            memory_pct=float(data.get("memory_pct", 0.0)),
            memory_mb=int(data.get("memory_mb", 0)),
            tasks_completed=int(data.get("tasks_completed", 0)),
            tasks_failed=int(data.get("tasks_failed", 0)),
            version=str(data.get("version", "")),
        )


# ---------------------------------------------------------------------------
# Abstract Backend
# ---------------------------------------------------------------------------

class WorkerRegistryBackend(abc.ABC):
    """Abstract interface for worker registration and discovery."""

    @abc.abstractmethod
    def register(self, info: WorkerInfo) -> None:
        """Register (or re-register) a worker.  Idempotent by ``worker_id``."""

    @abc.abstractmethod
    def heartbeat(self, worker_id: str, info: WorkerInfo) -> None:
        """Update a worker's metrics and refresh its TTL."""

    @abc.abstractmethod
    def deregister(self, worker_id: str) -> None:
        """Remove a worker from the registry (graceful shutdown)."""

    @abc.abstractmethod
    def list_workers(self, worker_type: Optional[str] = None) -> List[WorkerInfo]:
        """Return all live (non-expired) workers, optionally filtered by type."""

    @abc.abstractmethod
    def get_worker(self, worker_id: str) -> Optional[WorkerInfo]:
        """Return a single worker's info, or ``None`` if not found / expired."""

    @abc.abstractmethod
    def get_fleet_metrics(self) -> Dict[str, Any]:
        """Aggregate metrics across all live workers."""

    @property
    def backend_type(self) -> str:
        return "unknown"


# ---------------------------------------------------------------------------
# Redis Implementation
# ---------------------------------------------------------------------------

class RedisWorkerRegistry(WorkerRegistryBackend):
    """Redis-backed worker registry using hashes with TTL.

    Data model:
      - Hash  ``{prefix}:worker:{worker_id}``  — JSON-encoded WorkerInfo + EXPIRE
      - Set   ``{prefix}:workers:all``          — set of known worker_ids
    """

    def __init__(self, redis_client, key_prefix: str = "qs",
                 heartbeat_ttl_seconds: int = 45):
        self._r = redis_client
        self._prefix = key_prefix
        self._ttl = heartbeat_ttl_seconds
        logger.info(
            "RedisWorkerRegistry initialised (prefix=%s, ttl=%ds)",
            key_prefix, heartbeat_ttl_seconds,
        )

    @property
    def backend_type(self) -> str:
        return "redis"

    # -- key helpers --

    def _key(self, *parts: str) -> str:
        return ":".join([self._prefix] + list(parts))

    def _worker_key(self, worker_id: str) -> str:
        return self._key("worker", worker_id)

    def _all_set_key(self) -> str:
        return self._key("workers", "all")

    # -- public API --

    def register(self, info: WorkerInfo) -> None:
        worker_key = self._worker_key(info.worker_id)
        payload = json.dumps(info.to_dict())

        pipe = self._r.pipeline()
        pipe.set(worker_key, payload, ex=self._ttl)
        pipe.sadd(self._all_set_key(), info.worker_id)
        pipe.execute()

        logger.info(
            "Worker registered: %s (type=%s, host=%s, pid=%d)",
            info.worker_id, info.worker_type, info.hostname, info.pid,
        )

    def heartbeat(self, worker_id: str, info: WorkerInfo) -> None:
        worker_key = self._worker_key(worker_id)
        payload = json.dumps(info.to_dict())

        pipe = self._r.pipeline()
        pipe.set(worker_key, payload, ex=self._ttl)
        # Ensure membership in the set (idempotent)
        pipe.sadd(self._all_set_key(), worker_id)
        pipe.execute()

        logger.debug(
            "Heartbeat from %s: cpu=%.1f%%, mem=%.1f%%, tasks=%d",
            worker_id, info.cpu_pct, info.memory_pct, info.active_tasks,
        )

    def deregister(self, worker_id: str) -> None:
        pipe = self._r.pipeline()
        pipe.delete(self._worker_key(worker_id))
        pipe.srem(self._all_set_key(), worker_id)
        pipe.execute()

        logger.info("Worker deregistered: %s", worker_id)

    def list_workers(self, worker_type: Optional[str] = None) -> List[WorkerInfo]:
        member_ids = self._r.smembers(self._all_set_key())
        if not member_ids:
            return []

        # Pipeline HGETALL for all known IDs
        pipe = self._r.pipeline()
        ordered_ids: List[str] = []
        for wid in member_ids:
            wid_str = wid if isinstance(wid, str) else wid.decode("utf-8")
            pipe.get(self._worker_key(wid_str))
            ordered_ids.append(wid_str)
        results = pipe.execute()

        workers: List[WorkerInfo] = []
        expired_ids: List[str] = []

        for wid, raw in zip(ordered_ids, results):
            if raw is None:
                # Key expired (missed heartbeats) — clean from the set
                expired_ids.append(wid)
                continue
            try:
                data = json.loads(raw if isinstance(raw, str) else raw.decode("utf-8"))
                w = WorkerInfo.from_dict(data)
                if worker_type is not None and w.worker_type != worker_type:
                    continue
                workers.append(w)
            except (json.JSONDecodeError, ValueError, TypeError) as exc:
                logger.warning("Corrupt worker data for %s: %s", wid, exc)
                expired_ids.append(wid)

        # Lazy cleanup of stale set entries
        if expired_ids:
            pipe = self._r.pipeline()
            for wid in expired_ids:
                pipe.srem(self._all_set_key(), wid)
            pipe.execute()
            logger.debug("Cleaned %d expired workers from set", len(expired_ids))

        return workers

    def get_worker(self, worker_id: str) -> Optional[WorkerInfo]:
        raw = self._r.get(self._worker_key(worker_id))
        if raw is None:
            return None
        try:
            data = json.loads(raw if isinstance(raw, str) else raw.decode("utf-8"))
            return WorkerInfo.from_dict(data)
        except (json.JSONDecodeError, ValueError, TypeError) as exc:
            logger.warning("Corrupt worker data for %s: %s", worker_id, exc)
            return None

    def get_fleet_metrics(self) -> Dict[str, Any]:
        workers = self.list_workers()
        if not workers:
            return _empty_fleet_metrics()

        total_cpu = 0.0
        total_memory_pct = 0.0
        total_memory_mb = 0
        total_active = 0
        total_capacity = 0
        total_completed = 0
        total_failed = 0
        by_type: Dict[str, int] = {}
        by_status: Dict[str, int] = {}

        for w in workers:
            total_cpu += w.cpu_pct
            total_memory_pct += w.memory_pct
            total_memory_mb += w.memory_mb
            total_active += w.active_tasks
            total_capacity += w.max_concurrent
            total_completed += w.tasks_completed
            total_failed += w.tasks_failed
            by_type[w.worker_type] = by_type.get(w.worker_type, 0) + 1
            by_status[w.status] = by_status.get(w.status, 0) + 1

        count = len(workers)
        # Queue depth from the task queue (best-effort)
        queue_depth = self._get_queue_depth()

        return {
            "worker_count": count,
            "by_type": by_type,
            "by_status": by_status,
            "avg_cpu_pct": round(total_cpu / count, 1),
            "avg_memory_pct": round(total_memory_pct / count, 1),
            "total_memory_mb": total_memory_mb,
            "total_active_tasks": total_active,
            "total_capacity": total_capacity,
            "utilization_pct": round((total_active / total_capacity * 100), 1) if total_capacity > 0 else 0.0,
            "total_tasks_completed": total_completed,
            "total_tasks_failed": total_failed,
            "queue_depth": queue_depth,
        }

    def _get_queue_depth(self) -> int:
        """Best-effort read of pending task count from the shared Redis queue."""
        try:
            return self._r.zcard(self._key("pending")) or 0
        except Exception:
            return -1


# ---------------------------------------------------------------------------
# SQLite Implementation
# ---------------------------------------------------------------------------

class SqliteWorkerRegistry(WorkerRegistryBackend):
    """SQLite/PostgreSQL-backed worker registry using the ``WorkerRegistration`` model.

    Suitable for single-host or development deployments.  Expired rows are
    cleaned lazily on every ``list_workers`` call.
    """

    def __init__(self, db_manager, heartbeat_ttl_seconds: int = 45):
        self._db = db_manager
        self._ttl = heartbeat_ttl_seconds
        logger.info(
            "SqliteWorkerRegistry initialised (ttl=%ds)", heartbeat_ttl_seconds,
        )

    @property
    def backend_type(self) -> str:
        return "sqlite"

    def register(self, info: WorkerInfo) -> None:
        from core.db.models import WorkerRegistration

        now = datetime.now(timezone.utc)
        expires = now + timedelta(seconds=self._ttl)

        with self._db.get_session() as session:
            existing = session.query(WorkerRegistration).filter_by(
                worker_id=info.worker_id,
            ).first()

            if existing:
                existing.worker_type = info.worker_type
                existing.hostname = info.hostname
                existing.info = info.to_dict()
                existing.last_heartbeat = now
                existing.expires_at = expires
            else:
                row = WorkerRegistration(
                    worker_id=info.worker_id,
                    worker_type=info.worker_type,
                    hostname=info.hostname,
                    info=info.to_dict(),
                    last_heartbeat=now,
                    expires_at=expires,
                )
                session.add(row)

        logger.info(
            "Worker registered: %s (type=%s, host=%s, pid=%d)",
            info.worker_id, info.worker_type, info.hostname, info.pid,
        )

    def heartbeat(self, worker_id: str, info: WorkerInfo) -> None:
        from core.db.models import WorkerRegistration

        now = datetime.now(timezone.utc)
        expires = now + timedelta(seconds=self._ttl)

        with self._db.get_session() as session:
            row = session.query(WorkerRegistration).filter_by(
                worker_id=worker_id,
            ).first()

            if row is None:
                # Worker not found — treat heartbeat as a register
                row = WorkerRegistration(
                    worker_id=worker_id,
                    worker_type=info.worker_type,
                    hostname=info.hostname,
                    info=info.to_dict(),
                    last_heartbeat=now,
                    expires_at=expires,
                )
                session.add(row)
                logger.info(
                    "Heartbeat from unknown worker %s — auto-registered", worker_id,
                )
            else:
                row.info = info.to_dict()
                row.last_heartbeat = now
                row.expires_at = expires

        logger.debug(
            "Heartbeat from %s: cpu=%.1f%%, mem=%.1f%%, tasks=%d",
            worker_id, info.cpu_pct, info.memory_pct, info.active_tasks,
        )

    def deregister(self, worker_id: str) -> None:
        from core.db.models import WorkerRegistration

        with self._db.get_session() as session:
            session.query(WorkerRegistration).filter_by(
                worker_id=worker_id,
            ).delete()

        logger.info("Worker deregistered: %s", worker_id)

    def list_workers(self, worker_type: Optional[str] = None) -> List[WorkerInfo]:
        from core.db.models import WorkerRegistration

        now = datetime.now(timezone.utc)

        with self._db.get_session() as session:
            # Cleanup expired rows
            session.query(WorkerRegistration).filter(
                WorkerRegistration.expires_at < now,
            ).delete()
            session.flush()

            query = session.query(WorkerRegistration).filter(
                WorkerRegistration.expires_at >= now,
            )
            if worker_type is not None:
                query = query.filter(WorkerRegistration.worker_type == worker_type)

            rows = query.all()
            workers = []
            for row in rows:
                try:
                    info_data = row.info if isinstance(row.info, dict) else json.loads(row.info or "{}")
                    workers.append(WorkerInfo.from_dict(info_data))
                except (json.JSONDecodeError, ValueError, TypeError) as exc:
                    logger.warning("Corrupt worker data for %s: %s", row.worker_id, exc)
            return workers

    def get_worker(self, worker_id: str) -> Optional[WorkerInfo]:
        from core.db.models import WorkerRegistration

        now = datetime.now(timezone.utc)

        with self._db.get_session(read_only=True) as session:
            row = session.query(WorkerRegistration).filter_by(
                worker_id=worker_id,
            ).first()

            if row is None:
                return None
            if row.expires_at is not None:
                # SQLite returns naive datetimes; normalise for comparison
                exp = row.expires_at if row.expires_at.tzinfo else row.expires_at.replace(tzinfo=timezone.utc)
                if exp < now:
                    return None

            try:
                info_data = row.info if isinstance(row.info, dict) else json.loads(row.info or "{}")
                return WorkerInfo.from_dict(info_data)
            except (json.JSONDecodeError, ValueError, TypeError) as exc:
                logger.warning("Corrupt worker data for %s: %s", worker_id, exc)
                return None

    def get_fleet_metrics(self) -> Dict[str, Any]:
        workers = self.list_workers()
        if not workers:
            return _empty_fleet_metrics()

        total_cpu = 0.0
        total_memory_pct = 0.0
        total_memory_mb = 0
        total_active = 0
        total_capacity = 0
        total_completed = 0
        total_failed = 0
        by_type: Dict[str, int] = {}
        by_status: Dict[str, int] = {}

        for w in workers:
            total_cpu += w.cpu_pct
            total_memory_pct += w.memory_pct
            total_memory_mb += w.memory_mb
            total_active += w.active_tasks
            total_capacity += w.max_concurrent
            total_completed += w.tasks_completed
            total_failed += w.tasks_failed
            by_type[w.worker_type] = by_type.get(w.worker_type, 0) + 1
            by_status[w.status] = by_status.get(w.status, 0) + 1

        count = len(workers)

        # Queue depth from the task queue (best-effort)
        queue_depth = self._get_queue_depth()

        return {
            "worker_count": count,
            "by_type": by_type,
            "by_status": by_status,
            "avg_cpu_pct": round(total_cpu / count, 1),
            "avg_memory_pct": round(total_memory_pct / count, 1),
            "total_memory_mb": total_memory_mb,
            "total_active_tasks": total_active,
            "total_capacity": total_capacity,
            "utilization_pct": round((total_active / total_capacity * 100), 1) if total_capacity > 0 else 0.0,
            "total_tasks_completed": total_completed,
            "total_tasks_failed": total_failed,
            "queue_depth": queue_depth,
        }

    def _get_queue_depth(self) -> int:
        """Best-effort read of pending task count from the SQLite task queue."""
        try:
            from core.queue_backend import get_task_queue
            tasks = get_task_queue().list_tasks(status="pending", limit=1000)
            return len(tasks)
        except Exception:
            return -1


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _empty_fleet_metrics() -> Dict[str, Any]:
    """Return a zeroed-out fleet metrics dict when no workers are registered."""
    return {
        "worker_count": 0,
        "by_type": {},
        "by_status": {},
        "avg_cpu_pct": 0.0,
        "avg_memory_pct": 0.0,
        "total_memory_mb": 0,
        "total_active_tasks": 0,
        "total_capacity": 0,
        "utilization_pct": 0.0,
        "total_tasks_completed": 0,
        "total_tasks_failed": 0,
        "queue_depth": 0,
    }


# ---------------------------------------------------------------------------
# Factory + module-level singleton
# ---------------------------------------------------------------------------

_registry: Optional[WorkerRegistryBackend] = None


def init_worker_registry(db_manager=None) -> WorkerRegistryBackend:
    """Initialise the worker registry singleton.

    Backend selection:
      - ``"redis"``  — always use Redis (fails hard if unavailable)
      - ``"sqlite"`` — always use SQLite / DatabaseManager
      - ``"auto"``   — try Redis (via the queue backend's client), fall back to SQLite

    Args:
        db_manager: A ``DatabaseManager`` instance, required for the SQLite backend.

    Returns:
        The initialised ``WorkerRegistryBackend``.
    """
    global _registry

    from core.config import horizontal_workers as _hw_cfg
    from core.config import queue as _q_cfg

    backend = _hw_cfg.registry_backend  # "auto" | "redis" | "sqlite"
    ttl = _hw_cfg.heartbeat_ttl_seconds
    prefix = _q_cfg.key_prefix

    if backend in ("redis", "auto"):
        redis_client = _try_get_redis_client(_q_cfg, prefix)
        if redis_client is not None:
            _registry = RedisWorkerRegistry(
                redis_client=redis_client,
                key_prefix=prefix,
                heartbeat_ttl_seconds=ttl,
            )
            logger.info("Worker registry backend: Redis (prefix=%s)", prefix)
            return _registry
        elif backend == "redis":
            raise RuntimeError(
                "Worker registry configured for Redis but no Redis connection available. "
                "Set queue.backend='redis' and provide a valid queue.redis_url."
            )
        # backend == "auto" — fall through to SQLite

    # SQLite / PostgreSQL fallback
    if db_manager is None:
        raise RuntimeError(
            "Worker registry requires a DatabaseManager for the SQLite backend. "
            "Pass db_manager to init_worker_registry()."
        )
    _registry = SqliteWorkerRegistry(db_manager=db_manager, heartbeat_ttl_seconds=ttl)
    logger.info("Worker registry backend: SQLite")
    return _registry


def get_worker_registry() -> WorkerRegistryBackend:
    """Return the initialised worker registry singleton.

    Raises:
        RuntimeError: If ``init_worker_registry()`` has not been called.
    """
    if _registry is None:
        raise RuntimeError(
            "Worker registry not initialised — call init_worker_registry() first"
        )
    return _registry


# ---------------------------------------------------------------------------
# Internal — Redis client acquisition
# ---------------------------------------------------------------------------

def _try_get_redis_client(_q_cfg, prefix: str):
    """Attempt to obtain a Redis client, reusing the queue backend's connection
    if available, otherwise creating a new one from config.

    Returns a ``redis.Redis`` instance or ``None`` on failure.
    """
    # Strategy 1: reuse the queue backend's existing Redis client
    try:
        from core.queue_backend import _task_queue as _tq
        if _tq is not None and hasattr(_tq, "_r"):
            # Verify the connection is alive
            _tq._r.ping()
            logger.debug("Reusing Redis client from queue backend")
            return _tq._r
    except Exception:
        pass

    # Strategy 2: create a new client from config
    if _q_cfg.backend == "redis" or _q_cfg.redis_url:
        try:
            import redis as redis_lib

            conn_kwargs: Dict[str, Any] = dict(
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=10,
                retry_on_timeout=True,
            )
            if _q_cfg.redis_password:
                conn_kwargs["password"] = _q_cfg.redis_password
            if _q_cfg.redis_ssl:
                conn_kwargs["ssl"] = True

            client = redis_lib.Redis.from_url(
                _q_cfg.redis_url,
                db=_q_cfg.redis_db,
                **conn_kwargs,
            )
            client.ping()
            logger.info("Created new Redis client for worker registry: %s", _q_cfg.redis_url)
            return client
        except Exception as exc:
            logger.warning(
                "Failed to connect to Redis for worker registry (%s): %s",
                _q_cfg.redis_url, exc,
            )

    return None
