"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, Float, Index, UniqueConstraint, event as sa_event, text as sa_text
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any
import json
from contextlib import contextmanager
from pathlib import Path

# Models extracted to core/db/models.py — import them here for backward compatibility
from core.db.models import *  # noqa: F401,F403

# Method mixins — extracted domain groups
from core.db.mixin_datasets import DatasetsMixin
from core.db.mixin_lineage import LineageMixin


class DatabaseManager(LineageMixin, DatasetsMixin):
    """Database manager for handling all database operations.

    Methods are organized via mixins:
    - LineageMixin: table/column lineage, snapshots, freshness, usage stats, NL, corrections, UI visibility
    - DatasetsMixin: datasets, federation, agg cache, business reports, parameters, subscriptions
    - (remaining methods still inline — will be extracted incrementally)
    """

    # Shared migration dict — used by both SQLite and PostgreSQL migration methods.
    # Extend this whenever a new column is added to an existing model.
    _MIGRATIONS: dict = {
        "audit_log": [],
        "reports": [
            ("sql_saved_query_id",     "INTEGER"),
            ("sql_override",           "TEXT"),
            ("last_executed_at",       "TIMESTAMP"),
            ("cache_ttl_minutes",      "INTEGER DEFAULT 0"),
            ("schedule_config",        "TEXT"),
            ("connection_override_id", "INTEGER"),
            ("workspace_id",           "INTEGER"),
        ],
        "schedules": [
            ("notify_emails",  "TEXT"),
            ("notify_webhook", "TEXT"),
            ("is_shared",      "BOOLEAN DEFAULT 0"),
            ("workspace_id",   "INTEGER"),
        ],
        "saved_queries": [
            ("is_favorite",  "BOOLEAN DEFAULT 0"),
            ("is_shared",    "BOOLEAN DEFAULT 0"),
            ("workspace_id", "INTEGER"),
            ("folder",       "VARCHAR(200)"),
            ("tags",         "TEXT"),
        ],
        "sql_saved_queries": [
            ("is_shared",    "BOOLEAN DEFAULT 0"),
            ("workspace_id", "INTEGER"),
        ],
        "connections": [
            ("is_shared",    "BOOLEAN DEFAULT 0"),
            ("created_by",   "VARCHAR(100)"),
            ("workspace_id", "INTEGER"),
        ],
        "dashboards": [
            ("created_by",   "VARCHAR(100)"),
            ("workspace_id", "INTEGER"),
        ],
        "materialized_views": [
            ("workspace_id", "INTEGER"),
        ],
        "local_tables": [
            ("workspace_id", "INTEGER"),
        ],
        "query_executions": [
            ("executed_by", "VARCHAR(100)"),
        ],
        "download_files": [
            ("created_by",  "VARCHAR(100)"),
        ],
        "query_shares": [
            ("created_by",  "VARCHAR(100)"),
        ],
        "dashboard_shares": [
            ("created_by",  "VARCHAR(100)"),
        ],
        "partition_cache": [
            ("s3_prefix", "VARCHAR(512) DEFAULT ''"),
        ],
        "worker_registry": [],  # fresh table, no migration columns needed
    }

    def __init__(self, db_url: str = "sqlite:///./data/parquet_query_engine.db"):
        """
        Initialize database manager.

        Supports SQLite (default), PostgreSQL, and Oracle backends.
        When type=postgresql and the PG server is unreachable, auto-falls back to SQLite.
        """
        import logging as _log
        _init_log = _log.getLogger(__name__)

        # ── Resolve backend type from config ─────────────────────────────
        try:
            from core.config import database as _db_cfg
            db_type = _db_cfg.type
        except Exception:
            db_type = "sqlite"
            _db_cfg = None

        is_sqlite = False
        is_postgresql = False

        if db_type == "postgresql" and _db_cfg and _db_cfg.postgresql_url:
            db_url = _db_cfg.postgresql_url
            is_postgresql = True
        elif db_type == "oracle":
            # Oracle path unchanged — db_url comes from _DatabaseCfg.db_url
            pass
        else:
            # SQLite (default)
            is_sqlite = True
            raw_path = db_url.replace("sqlite:///", "")
            db_path = Path(raw_path).resolve()
            db_path.parent.mkdir(parents=True, exist_ok=True)
            db_url = "sqlite:///" + db_path.as_posix()

        # ── Build engine kwargs per dialect ──────────────────────────────
        engine_kwargs: dict = {"pool_pre_ping": True}
        if is_sqlite:
            engine_kwargs["connect_args"] = {"check_same_thread": False}
            engine_kwargs["pool_size"] = 20
            engine_kwargs["max_overflow"] = 30
        elif is_postgresql and _db_cfg:
            engine_kwargs["pool_size"] = _db_cfg.postgresql_pool_size
            engine_kwargs["max_overflow"] = _db_cfg.postgresql_max_overflow
            engine_kwargs["pool_timeout"] = _db_cfg.postgresql_pool_timeout

        self.engine = create_engine(db_url, **engine_kwargs)
        self.is_sqlite = is_sqlite
        self.is_postgresql = is_postgresql

        # ── SQLite-specific setup ────────────────────────────────────────
        if is_sqlite:
            @sa_event.listens_for(self.engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _conn_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA busy_timeout=30000")
                cursor.execute("PRAGMA wal_autocheckpoint=1000")
                cursor.close()

            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("PRAGMA wal_checkpoint(TRUNCATE)"))
                    _conn.commit()
                    _ic = _conn.execute(sa_text("PRAGMA integrity_check")).fetchone()
                    if _ic and _ic[0] != "ok":
                        raise RuntimeError(f"integrity_check failed: {_ic[0]}")
            except Exception as _db_err:
                _init_log.warning(
                    "SQLite DB corrupt or unreadable (%s) — backing up and recreating.", _db_err
                )
                self.engine.dispose()
                _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                for _suffix in ("", "-wal", "-shm", "-journal"):
                    _f = Path(str(db_path) + _suffix)
                    if _f.exists():
                        _f.rename(_f.with_suffix(f".corrupt_{_ts}{_suffix}"))
                self.engine = create_engine(
                    db_url,
                    connect_args={"check_same_thread": False},
                    pool_pre_ping=True,
                    pool_size=20, max_overflow=30,
                )
                @sa_event.listens_for(self.engine, "connect")
                def _set_sqlite_pragmas_fresh(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=30000")
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                    cursor.close()

        # ── PostgreSQL-specific setup ────────────────────────────────────
        if is_postgresql:
            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("SELECT 1"))
                _init_log.info("PostgreSQL connection verified: %s",
                               db_url.split("@")[-1] if "@" in db_url else "(url masked)")
            except Exception as _pg_err:
                _init_log.error(
                    "PostgreSQL connection failed: %s — falling back to SQLite", _pg_err
                )
                # Auto-fallback to SQLite
                self.engine.dispose()
                fallback_path = Path("./data/parquet_query_engine.db").resolve()
                fallback_path.parent.mkdir(parents=True, exist_ok=True)
                db_url = "sqlite:///" + fallback_path.as_posix()
                self.engine = create_engine(
                    db_url,
                    connect_args={"check_same_thread": False},
                    pool_pre_ping=True,
                    pool_size=20, max_overflow=30,
                )
                self.is_sqlite = True
                self.is_postgresql = False
                is_sqlite = True
                is_postgresql = False
                @sa_event.listens_for(self.engine, "connect")
                def _set_sqlite_pragmas_fallback(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=30000")
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                    cursor.close()

        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

        # ── Read replica setup (Phase 43) ────────────────────────────────
        self._replica_engines: list = []
        self._replica_sessions: list = []
        self._replica_health: list = []
        self._replica_lock = __import__("threading").Lock()
        self._replica_index = 0
        self._replica_shutdown = __import__("threading").Event()

        if is_postgresql and _db_cfg:
            _rep_urls = _db_cfg.replica_urls
            for _rep_url in _rep_urls:
                try:
                    _rep_engine = create_engine(
                        _rep_url,
                        pool_pre_ping=True,
                        pool_size=_db_cfg.replica_pool_size,
                        max_overflow=_db_cfg.replica_max_overflow,
                        pool_timeout=_db_cfg.replica_pool_timeout,
                    )
                    with _rep_engine.connect() as _rc:
                        _rc.execute(sa_text("SELECT 1"))
                    self._replica_engines.append(_rep_engine)
                    self._replica_sessions.append(
                        sessionmaker(autocommit=False, autoflush=False, bind=_rep_engine)
                    )
                    self._replica_health.append(True)
                    _init_log.info("Read replica connected: %s",
                                   _rep_url.split("@")[-1] if "@" in _rep_url else "(masked)")
                except Exception as _rep_err:
                    _init_log.warning("Read replica failed to connect (%s): %s — skipping",
                                      _rep_url.split("@")[-1] if "@" in _rep_url else "(masked)", _rep_err)

            if self._replica_engines:
                self._replica_health_thread = __import__("threading").Thread(
                    target=self._replica_health_loop, daemon=True, name="replica-health"
                )
                self._replica_health_thread.start()
                _init_log.info("Read replica health checker started (%d replicas)", len(self._replica_engines))

        # Create tables (only creates tables that don't exist yet)
        Base.metadata.create_all(bind=self.engine)

        # Safe schema migration — add any columns that existing tables might
        # be missing when the schema is updated after initial creation.
        if is_sqlite:
            self._apply_sqlite_migrations()
        elif is_postgresql:
            self._apply_postgresql_migrations()

    def _apply_sqlite_migrations(self):
        """Add columns that may be missing from older DB versions (SQLite only).

        Uses a raw sqlite3 connection (bypasses SQLAlchemy version differences)
        so this works identically with SQLAlchemy 1.x and 2.x.
        """
        import sqlite3 as _sqlite3
        db_file = str(self.engine.url).replace("sqlite:///", "")
        if not db_file or db_file == ":memory:":
            return

        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        try:
            con = _sqlite3.connect(db_file)
            cur = con.cursor()
            for table, columns in self._MIGRATIONS.items():
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    existing = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue  # table doesn't exist yet — create_all will handle it
                for col_name, col_type in columns:
                    if col_name not in existing:
                        try:
                            cur.execute(
                                f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"
                            )
                            _mig_log.info("Migration: added %s.%s (%s)", table, col_name, col_type)
                        except Exception as exc:
                            _mig_log.warning("Migration: failed to add %s.%s: %s", table, col_name, exc)
            # ── Index migrations (drop old + recreate with new columns) ─────
            # partition_cache: unique index must include s3_prefix (BF-15)
            try:
                cur.execute("PRAGMA table_info(partition_cache)")
                pc_cols = {row[1] for row in cur.fetchall()}
                if "s3_prefix" in pc_cols:
                    # Check if old index exists without s3_prefix — rebuild it
                    cur.execute("PRAGMA index_list(partition_cache)")
                    for idx_row in cur.fetchall():
                        idx_name = idx_row[1]
                        if idx_name == "ix_partition_cache_lookup":
                            cur.execute(f"PRAGMA index_info({idx_name})")
                            idx_cols = {row[2] for row in cur.fetchall()}
                            if "s3_prefix" not in idx_cols:
                                cur.execute("DROP INDEX IF EXISTS ix_partition_cache_lookup")
                                cur.execute(
                                    "CREATE UNIQUE INDEX ix_partition_cache_lookup "
                                    "ON partition_cache(connection_id, table_name, s3_prefix, scan_type)"
                                )
                                _mig_log.info("Migration: rebuilt ix_partition_cache_lookup with s3_prefix")
                            break
            except Exception as _idx_exc:
                _mig_log.warning("Index migration failed for partition_cache: %s", _idx_exc)

            con.commit()
            con.close()
        except Exception as exc:
            _mig_log.error("SQLite migration failed: %s", exc, exc_info=True)

    def _apply_postgresql_migrations(self):
        """Add columns that may be missing from older DB versions (PostgreSQL).

        Uses SQLAlchemy inspect() for dialect-agnostic column introspection.
        """
        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        from sqlalchemy import inspect as sa_inspect

        # SQLite type → PostgreSQL type translation
        _PG_TYPE_MAP = {
            "BOOLEAN DEFAULT 0": "BOOLEAN DEFAULT FALSE",
            "BOOLEAN DEFAULT 1": "BOOLEAN DEFAULT TRUE",
        }

        try:
            inspector = sa_inspect(self.engine)
            existing_tables = set(inspector.get_table_names())

            with self.engine.connect() as conn:
                for table, columns in self._MIGRATIONS.items():
                    if table not in existing_tables or not columns:
                        continue
                    existing_cols = {c["name"] for c in inspector.get_columns(table)}
                    for col_name, col_type in columns:
                        if col_name not in existing_cols:
                            pg_type = _PG_TYPE_MAP.get(col_type, col_type)
                            try:
                                conn.execute(sa_text(
                                    f"ALTER TABLE {table} ADD COLUMN {col_name} {pg_type}"
                                ))
                                _mig_log.info("PG Migration: added %s.%s (%s)", table, col_name, pg_type)
                            except Exception as exc:
                                _mig_log.warning("PG Migration: failed to add %s.%s: %s", table, col_name, exc)
                # ── Index migrations ────────────────────────────────────
                # partition_cache: unique index must include s3_prefix (BF-15)
                if "partition_cache" in existing_tables:
                    pc_cols = {c["name"] for c in inspector.get_columns("partition_cache")}
                    if "s3_prefix" in pc_cols:
                        try:
                            pc_indexes = inspector.get_indexes("partition_cache")
                            for idx in pc_indexes:
                                if idx["name"] == "ix_partition_cache_lookup":
                                    if "s3_prefix" not in idx.get("column_names", []):
                                        conn.execute(sa_text("DROP INDEX IF EXISTS ix_partition_cache_lookup"))
                                        conn.execute(sa_text(
                                            "CREATE UNIQUE INDEX ix_partition_cache_lookup "
                                            "ON partition_cache(connection_id, table_name, s3_prefix, scan_type)"
                                        ))
                                        _mig_log.info("PG Migration: rebuilt ix_partition_cache_lookup with s3_prefix")
                                    break
                        except Exception as _idx_exc:
                            _mig_log.warning("PG index migration failed for partition_cache: %s", _idx_exc)

                conn.commit()
        except Exception as exc:
            _mig_log.error("PostgreSQL migration failed: %s", exc, exc_info=True)

    # ── Replica health & routing (Phase 43) ─────────────────────────────

    def _replica_health_loop(self):
        """Background thread: periodically check replica health + replication lag."""
        import logging as _rlog
        _rhl = _rlog.getLogger(__name__)
        try:
            from core.config import database as _db_cfg
            interval = _db_cfg.replica_health_interval_seconds
            max_lag = _db_cfg.replica_max_lag_seconds
        except Exception:
            interval, max_lag = 30, 5

        while not self._replica_shutdown.is_set():
            for idx, eng in enumerate(self._replica_engines):
                try:
                    with eng.connect() as conn:
                        row = conn.execute(sa_text(
                            "SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))"
                        )).fetchone()
                        lag = float(row[0]) if row and row[0] is not None else 0.0
                        healthy = lag <= max_lag
                        if not healthy and self._replica_health[idx]:
                            _rhl.warning("Replica %d lag %.1fs exceeds max %ds — marking unhealthy", idx, lag, max_lag)
                        elif healthy and not self._replica_health[idx]:
                            _rhl.info("Replica %d recovered (lag %.1fs) — marking healthy", idx, lag)
                        self._replica_health[idx] = healthy
                except Exception as e:
                    if self._replica_health[idx]:
                        _rhl.warning("Replica %d health check failed: %s — marking unhealthy", idx, e)
                    self._replica_health[idx] = False
            self._replica_shutdown.wait(interval)

    def _next_read_session(self):
        """Pick next healthy replica session via round-robin. Returns None if none available."""
        if not self._replica_engines:
            return None
        with self._replica_lock:
            n = len(self._replica_engines)
            for _ in range(n):
                idx = self._replica_index % n
                self._replica_index += 1
                if self._replica_health[idx]:
                    return self._replica_sessions[idx]()
        return None  # all unhealthy

    def get_replica_status(self) -> list:
        """Return health status of all replicas (for admin API)."""
        result = []
        for idx, eng in enumerate(self._replica_engines):
            info = {"index": idx, "healthy": self._replica_health[idx], "url": "(masked)"}
            try:
                url_str = str(eng.url)
                info["url"] = url_str.split("@")[-1] if "@" in url_str else url_str
            except Exception:
                pass
            try:
                with eng.connect() as conn:
                    row = conn.execute(sa_text(
                        "SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))"
                    )).fetchone()
                    info["lag_seconds"] = round(float(row[0]), 2) if row and row[0] is not None else 0.0
                    pool = eng.pool
                    info["pool_size"] = pool.size() if hasattr(pool, 'size') else -1
                    info["pool_checked_out"] = pool.checkedout() if hasattr(pool, 'checkedout') else -1
            except Exception as e:
                info["error"] = str(e)
            result.append(info)
        return result

    @contextmanager
    def get_session(self, read_only: bool = False) -> Session:
        """
        Context manager for database sessions.

        Args:
            read_only: If True and replicas are configured, route to a read replica.
                       Falls back to primary if no healthy replicas available.
        Yields:
            Database session
        """
        session = None
        _is_replica = False

        if read_only:
            try:
                from core.config import database as _db_cfg
                pref = _db_cfg.read_preference
            except Exception:
                pref = "primary"

            if pref != "primary" and self._replica_engines:
                session = self._next_read_session()
                if session is not None:
                    _is_replica = True

            # SQLite read optimization: set query_only pragma
            if session is None and self.is_sqlite:
                session = self.SessionLocal()
                try:
                    session.execute(sa_text("PRAGMA query_only=ON"))
                except Exception:
                    pass  # older SQLite may not support

        if session is None:
            session = self.SessionLocal()

        try:
            yield session
            if not read_only:
                session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            if read_only and self.is_sqlite:
                try:
                    session.execute(sa_text("PRAGMA query_only=OFF"))
                except Exception:
                    pass
            session.close()
    
    # SavedQuery operations
    def create_query(self, name: str, query_config: Dict[str, Any],
                    description: Optional[str] = None,
                    created_by: Optional[str] = None,
                    workspace_id: Optional[int] = None,
                    folder: Optional[str] = None,
                    tags: Optional[list] = None) -> SavedQuery:
        """Create a new saved query"""
        with self.get_session() as session:
            query = SavedQuery(
                name=name,
                description=description,
                query_config=query_config,
                created_by=created_by,
                workspace_id=workspace_id,
                folder=folder,
                tags=tags,
            )
            session.add(query)
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def get_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a saved query by ID"""
        with self.get_session(read_only=True) as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            return query.to_dict() if query else None
    
    def list_queries(self, active_only: bool = True,
                    limit: int = 100, offset: int = 0,
                    workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List all saved queries"""
        with self.get_session(read_only=True) as session:
            query = session.query(SavedQuery)
            if active_only:
                query = query.filter(SavedQuery.is_active == True)
            if workspace_id is not None:
                query = query.filter(
                    (SavedQuery.workspace_id == workspace_id) | (SavedQuery.workspace_id == None)
                )
            query = query.order_by(SavedQuery.created_at.desc())
            query = query.limit(limit).offset(offset)
            return [q.to_dict() for q in query.all()]
    
    def update_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return None
            
            for key, value in kwargs.items():
                if hasattr(query, key):
                    setattr(query, key, value)
            
            query.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def toggle_favorite(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Toggle is_favorite flag on a saved query."""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not query:
                return None
            query.is_favorite = not query.is_favorite
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def delete_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return False
            
            if soft_delete:
                query.is_active = False
                query.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(query)
            
            return True
    
    def increment_execution_count(self, query_id: int) -> None:
        """Increment execution count for a query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if query:
                query.execution_count += 1
                query.last_executed_at = datetime.now(timezone.utc)
    
    # QueryExecution operations
    def create_execution(self, execution_id: str, query_config: Dict[str, Any],
                        query_id: Optional[int] = None,
                        executed_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a new query execution record"""
        with self.get_session() as session:
            execution = QueryExecution(
                execution_id=execution_id,
                query_id=query_id,
                query_config=query_config,
                executed_by=executed_by
            )
            session.add(execution)
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def update_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a query execution"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            
            if not execution:
                return None
            
            for key, value in kwargs.items():
                if hasattr(execution, key):
                    setattr(execution, key, value)
            
            if kwargs.get("status") in ["completed", "failed"]:
                execution.completed_at = datetime.now(timezone.utc)
            
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution by ID"""
        with self.get_session(read_only=True) as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            return execution.to_dict() if execution else None
    
    def get_last_successful_output_file(self, query_id: int) -> Optional[Dict]:
        """Return the most recent completed execution's output_file for a query_id.
        Only returns if the file still exists on disk (for stale-fallback use).
        """
        import os as _os
        with self.get_session(read_only=True) as session:
            row = (session.query(QueryExecution)
                   .filter(
                       QueryExecution.query_id == query_id,
                       QueryExecution.status == "completed",
                       QueryExecution.output_file.isnot(None),
                   )
                   .order_by(QueryExecution.completed_at.desc())
                   .first())
            if not row or not row.output_file:
                return None
            if not _os.path.exists(row.output_file):
                return None
            return {
                "output_file": row.output_file,
                "completed_at": row.completed_at.isoformat() if row.completed_at else None,
                "total_rows": row.total_rows or 0,
                "file_size_bytes": row.file_size_bytes or 0,
            }

    def list_executions(self, limit: int = 100, offset: int = 0,
                       status: Optional[str] = None) -> List[Dict[str, Any]]:
        """List query executions"""
        with self.get_session(read_only=True) as session:
            query = session.query(QueryExecution)
            
            if status:
                query = query.filter(QueryExecution.status == status)
            
            query = query.order_by(QueryExecution.started_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [e.to_dict() for e in query.all()]
    
    # DownloadFile operations
    def create_download_file(self, file_id: str, filename: str, file_path: str,
                           file_size_bytes: int, execution_id: Optional[str] = None,
                           expires_at: Optional[datetime] = None,
                           created_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a download file record"""
        with self.get_session() as session:
            download_file = DownloadFile(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=file_path,
                file_size_bytes=file_size_bytes,
                expires_at=expires_at,
                created_by=created_by
            )
            session.add(download_file)
            session.flush()
            session.refresh(download_file)
            return download_file.to_dict()
    
    def get_download_file(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get download file by ID"""
        with self.get_session(read_only=True) as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            return file.to_dict() if file else None
    
    def list_download_files(self, status: Optional[str] = "available",
                          limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List download files"""
        with self.get_session(read_only=True) as session:
            query = session.query(DownloadFile)
            
            if status:
                query = query.filter(DownloadFile.status == status)
            
            query = query.order_by(DownloadFile.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [f.to_dict() for f in query.all()]
    
    def update_download_file(self, file_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update download file"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            
            if not file:
                return None
            
            for key, value in kwargs.items():
                if hasattr(file, key):
                    setattr(file, key, value)
            
            session.flush()
            session.refresh(file)
            return file.to_dict()
    
    def increment_download_count(self, file_id: str) -> None:
        """Increment download count"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            if file:
                file.download_count += 1
                file.last_downloaded_at = datetime.now(timezone.utc)

    # ── Connection operations ──────────────────────────────────────────────────

    def create_connection(self, name: str, connection_type: str,
                         config: Dict[str, Any],
                         workspace_id: Optional[int] = None) -> Dict[str, Any]:
        """Create a new connection — encrypts sensitive config fields at rest."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = Connection(
                name=name,
                connection_type=connection_type,
                config=encrypt_config(config),
                workspace_id=workspace_id,
            )
            session.add(connection)
            session.flush()
            session.refresh(connection)
            d = connection.to_dict()
            d["config"] = mask_config(config)   # return masked to caller
            return d

    def get_connection(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials MASKED — safe for API responses to the browser."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session(read_only=True) as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = mask_config(decrypt_config(d["config"]))
            return d

    def get_connection_raw(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials DECRYPTED — for internal engine/connector use only.
        Never return this directly to API clients."""
        from core.crypto import decrypt_config
        with self.get_session(read_only=True) as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = decrypt_config(d["config"])
            return d

    def list_connections(self, active_only: bool = True,
                        limit: int = 100, offset: int = 0,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List connections with credentials masked."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session(read_only=True) as session:
            q = session.query(Connection)
            if active_only:
                q = q.filter(Connection.is_active == True)
            if workspace_id is not None:
                q = q.filter(
                    (Connection.workspace_id == workspace_id) | (Connection.workspace_id == None)
                )
            q = q.order_by(Connection.created_at.desc()).limit(limit).offset(offset)
            result = []
            for c in q.all():
                d = c.to_dict()
                d["config"] = mask_config(decrypt_config(d["config"]))
                result.append(d)
            return result

    def update_connection(self, connection_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a connection — re-encrypts config if provided."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return None
            # Encrypt config before persisting
            if "config" in kwargs and isinstance(kwargs["config"], dict):
                kwargs["config"] = encrypt_config(kwargs["config"])
            for key, value in kwargs.items():
                if hasattr(connection, key):
                    setattr(connection, key, value)
            connection.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(connection)
            return connection.to_dict()

    def delete_connection(self, connection_id: int, soft_delete: bool = True) -> bool:
        """Delete a connection."""
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return False
            if soft_delete:
                connection.is_active = False
                connection.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(connection)
            return True

    # ── Report operations ──────────────────────────────────────────────────────

    def create_report(self, **kwargs) -> Dict[str, Any]:
        """Create a new parametric report."""
        with self.get_session() as session:
            report = Report(**kwargs)
            session.add(report)
            session.flush()
            session.refresh(report)
            return report.to_dict()

    def get_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            return r.to_dict() if r else None

    def list_reports(self, active_only: bool = True,
                     limit: int = 200, offset: int = 0,
                     workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(Report)
            if active_only:
                q = q.filter(Report.is_active == True)
            if workspace_id is not None:
                q = q.filter(
                    (Report.workspace_id == workspace_id) | (Report.workspace_id == None)
                )
            rows = q.order_by(Report.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def update_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(r, key):
                    setattr(r, key, value)
            r.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def delete_report(self, report_id: int, soft_delete: bool = True) -> bool:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return False
            if soft_delete:
                r.is_active = False
            else:
                session.delete(r)
            return True

    def increment_report_execution(self, report_id: int):
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if r:
                r.execution_count = (r.execution_count or 0) + 1
                r.last_executed_at = datetime.now(timezone.utc)

    # ── Connection Profile operations (Phase 24B) ──────────────────────────────

    def list_connection_profiles(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ConnectionProfile).order_by(ConnectionProfile.name).all()
            return [r.to_dict() for r in rows]

    def get_active_profile(self) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            r = session.query(ConnectionProfile).filter(ConnectionProfile.is_active == True).first()
            return r.to_dict() if r else None

    def get_profile_mappings(self, profile_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_connection_profile(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ConnectionProfile(**kwargs)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def update_connection_profile(self, profile_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            p.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def activate_connection_profile(self, profile_id: int) -> bool:
        """Set one profile as active; deactivate all others (exclusive)."""
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            p.is_active = True
            return True

    def deactivate_all_profiles(self) -> None:
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})

    def delete_connection_profile(self, profile_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            session.delete(p)
            return True

    def set_profile_mappings(self, profile_id: int, mappings: List[Dict]) -> List[Dict[str, Any]]:
        """Replace ALL mappings for a profile atomically."""
        with self.get_session() as session:
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            created = []
            for m in mappings:
                obj = ConnectionProfileMapping(
                    profile_id=profile_id,
                    source_connection_id=m["source_connection_id"],
                    target_connection_id=m["target_connection_id"],
                    description=m.get("description"),
                )
                session.add(obj)
                session.flush()
                session.refresh(obj)
                created.append(obj.to_dict())
            return created

    def resolve_connection_via_profile(self, connection_id: int) -> int:
        """Return the mapped connection_id if active profile has a rule; else original.

        Returns connection_id unchanged when no profile is active or no mapping exists.
        """
        active = self.get_active_profile()
        if not active:
            return connection_id
        with self.get_session(read_only=True) as session:
            mapping = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == active["id"],
                ConnectionProfileMapping.source_connection_id == connection_id,
            ).first()
            return mapping.target_connection_id if mapping else connection_id

    # ── Schedule operations ────────────────────────────────────────────────────

    def create_schedule(self, **kwargs) -> Dict[str, Any]:
        """Create a new schedule record."""
        with self.get_session() as session:
            s = Schedule(**kwargs)
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_schedule(self, schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            return s.to_dict() if s else None

    def list_schedules(self, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(Schedule)
            if active_only:
                q = q.filter(Schedule.is_active == True)
            rows = q.order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def list_all_schedules(self, limit: int = 500, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(Schedule).order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def update_schedule(self, schedule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            s.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    def increment_schedule_run_count(self, schedule_id: int):
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if s:
                s.run_count = (s.run_count or 0) + 1

    def list_downloads_enriched(
        self,
        status: Optional[str] = "available",
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Returns download files enriched with linked execution metadata.

        Single LEFT JOIN query — no N+1 lookups.
        Extra fields added to each record:
          - duration_seconds  (execution completed_at - started_at)
          - total_rows        (rows written by the query engine)
          - format            ('csv' | 'excel' | 'json' derived from filename)
        """
        with self.get_session() as session:
            query = (
                session.query(DownloadFile, QueryExecution)
                .outerjoin(
                    QueryExecution,
                    DownloadFile.execution_id == QueryExecution.execution_id,
                )
            )
            if status:
                query = query.filter(DownloadFile.status == status)

            query = (
                query.order_by(DownloadFile.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = []
            for dl, ex in query.all():
                d = dl.to_dict()

                # Execution metadata
                if ex:
                    if ex.started_at and ex.completed_at:
                        d["duration_seconds"] = round(
                            (ex.completed_at - ex.started_at).total_seconds(), 2
                        )
                    else:
                        d["duration_seconds"] = None
                    d["total_rows"] = ex.total_rows or 0
                else:
                    d["duration_seconds"] = None
                    d["total_rows"] = None

                # Derive format from filename extension
                fname = (d.get("filename") or "").lower()
                if fname.endswith(".xlsx"):
                    d["format"] = "excel"
                elif fname.endswith(".json"):
                    d["format"] = "json"
                else:
                    d["format"] = "csv"

                result.append(d)

            return result

    # ── SQL Saved Queries (Trino / Snowflake / Databricks) ────────────────────

    def create_sql_query(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlSavedQuery record."""
        with self.get_session() as session:
            q = SqlSavedQuery(**kwargs)
            session.add(q)
            session.flush()
            return q.to_dict()

    def list_sql_queries(self, active_only: bool = True, limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL saved queries, newest first."""
        with self.get_session(read_only=True) as session:
            query = session.query(SqlSavedQuery)
            if active_only:
                query = query.filter(SqlSavedQuery.is_active == True)
            rows = query.order_by(SqlSavedQuery.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def get_sql_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL saved query by ID."""
        with self.get_session(read_only=True) as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            return q.to_dict() if q else None

    def update_sql_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(q, key):
                    setattr(q, key, value)
            q.updated_at = datetime.now(timezone.utc)
            session.flush()
            return q.to_dict()

    def delete_sql_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return False
            if soft_delete:
                q.is_active = False
            else:
                session.delete(q)
            return True

    def increment_sql_query_execution(self, query_id: int):
        """Bump execution counter and last_executed_at timestamp."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if q:
                q.execution_count = (q.execution_count or 0) + 1
                q.last_executed_at = datetime.now(timezone.utc)

    # ── Query Cache operations ─────────────────────────────────────────────────

    def get_cache_entry(self, cache_key: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            return e.to_dict() if e else None

    def set_cache_entry(self, cache_key: str, file_path: str,
                        row_count: int = 0, file_size_bytes: int = 0,
                        expires_at: Optional[datetime] = None,
                        query_config: Optional[dict] = None,
                        connection_id: Optional[int] = None) -> Dict[str, Any]:
        """Upsert a cache entry — safe for concurrent writers on the same key."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            # Try insert first; on PK conflict, update in place.
            try:
                e = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                # PK conflict — another thread inserted first; update instead.
                existing = session.query(QueryCacheEntry).filter(
                    QueryCacheEntry.cache_key == cache_key
                ).first()
                if existing:
                    existing.file_path = file_path
                    existing.row_count = row_count
                    existing.file_size_bytes = file_size_bytes
                    existing.expires_at = expires_at
                    existing.created_at = now
                    existing.query_config = query_config
                    existing.connection_id = connection_id
                    session.flush()
                    return existing.to_dict()
                # Extremely unlikely: another thread deleted between our
                # failed insert and this query — just retry the insert.
                e2 = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_cache_entry(self, cache_key: str) -> bool:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            if not e:
                return False
            session.delete(e)
            return True

    def delete_expired_cache_entries(self) -> int:
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            expired = session.query(QueryCacheEntry).filter(
                QueryCacheEntry.expires_at != None,
                QueryCacheEntry.expires_at < now,
            ).all()
            count = len(expired)
            for e in expired:
                session.delete(e)
            return count

    def list_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(QueryCacheEntry).order_by(QueryCacheEntry.created_at.desc()).all()
            return [e.to_dict() for e in rows]

    def increment_cache_hit(self, cache_key: str) -> None:
        """Increment the hit counter for a cache entry."""
        with self.get_session() as session:
            entry = session.query(QueryCacheEntry).filter_by(cache_key=cache_key).first()
            if entry:
                entry.hit_count = (entry.hit_count or 0) + 1
                session.flush()

    # ── Partition Cache operations ────────────────────────────────────────────

    def get_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str = "fast",
                            s3_prefix: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(PartitionCache).filter(
                PartitionCache.connection_id == connection_id,
                PartitionCache.table_name == table_name,
                PartitionCache.s3_prefix == s3_prefix,
                PartitionCache.scan_type == scan_type,
            ).first()
            return e.to_dict() if e else None

    def set_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str, partition_data: dict,
                            s3_prefix: str = "") -> Dict[str, Any]:
        """Upsert partition cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    s3_prefix=s3_prefix, scan_type=scan_type,
                    partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(PartitionCache).filter(
                    PartitionCache.connection_id == connection_id,
                    PartitionCache.table_name == table_name,
                    PartitionCache.s3_prefix == s3_prefix,
                    PartitionCache.scan_type == scan_type,
                ).first()
                if existing:
                    existing.partition_data = partition_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    s3_prefix=s3_prefix, scan_type=scan_type,
                    partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_partition_cache(self, connection_id: Optional[int] = None,
                               table_name: Optional[str] = None,
                               s3_prefix: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(PartitionCache)
            if connection_id is not None:
                q = q.filter(PartitionCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(PartitionCache.table_name == table_name)
            if s3_prefix is not None:
                q = q.filter(PartitionCache.s3_prefix == s3_prefix)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_partition_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(PartitionCache).order_by(
                PartitionCache.updated_at.desc()
            ).all()
            return [e.to_dict() for e in rows]

    # ── Iceberg File Cache operations ────────────────────────────────────────

    def get_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(IcebergFileCache).filter(
                IcebergFileCache.connection_id == connection_id,
                IcebergFileCache.table_name == table_name,
                IcebergFileCache.filters_hash == filters_hash,
            ).first()
            return e.to_dict() if e else None

    def set_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str, file_list: list) -> Dict[str, Any]:
        """Upsert Iceberg file cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(IcebergFileCache).filter(
                    IcebergFileCache.connection_id == connection_id,
                    IcebergFileCache.table_name == table_name,
                    IcebergFileCache.filters_hash == filters_hash,
                ).first()
                if existing:
                    existing.file_list = file_list
                    existing.file_count = len(file_list)
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def list_iceberg_file_cache(self, connection_id: Optional[int] = None) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            return [e.to_dict() for e in q.all()]

    def delete_iceberg_file_cache(self, connection_id: Optional[int] = None,
                                   table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergFileCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    # ── Schema cache ────────────────────────────────────────────────────────────

    def find_schema_cache_by_name(self, table_name: str) -> Optional[Dict[str, Any]]:
        """Find any cached schema matching table_name, regardless of connection."""
        with self.get_session(read_only=True) as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.table_name == table_name
            ).order_by(SchemaCache.updated_at.desc()).first()
            return e.to_dict() if e else None

    def get_schema_cache(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.connection_id == connection_id,
                SchemaCache.table_name == table_name,
            ).first()
            return e.to_dict() if e else None

    def set_schema_cache(self, connection_id: int, table_name: str,
                         table_format: str, schema_data: dict) -> Dict[str, Any]:
        """Upsert schema cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(SchemaCache).filter(
                    SchemaCache.connection_id == connection_id,
                    SchemaCache.table_name == table_name,
                ).first()
                if existing:
                    existing.table_format = table_format
                    existing.schema_data = schema_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_schema_cache(self, connection_id: Optional[int] = None,
                            table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(SchemaCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_schema_cache_entries(self, connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            return [e.to_dict() for e in q.order_by(SchemaCache.updated_at.desc()).all()]

    # ── Execution history cleanup ──────────────────────────────────────────────

    def cleanup_old_executions(self, retention_days: int = 30):
        """Delete QueryExecution records older than retention_days.

        Only removes records whose status is terminal (completed / failed /
        cancelled) and whose started_at is older than the retention window.
        Pending / processing rows are never touched (they may still be running).

        Returns (count, [output_file_paths]) so the caller can delete the files.
        """
        import datetime as _dt
        cutoff = datetime.now(timezone.utc) - _dt.timedelta(days=retention_days)
        with self.get_session() as session:
            terminal = ("completed", "failed", "cancelled")
            expired_rows = (
                session.query(QueryExecution)
                .filter(
                    QueryExecution.status.in_(terminal),
                    QueryExecution.started_at < cutoff,
                )
                .all()
            )
            # Collect file paths BEFORE deleting rows (so we can unlink them)
            file_paths = [r.output_file for r in expired_rows if r.output_file]
            count = len(expired_rows)
            for row in expired_rows:
                session.delete(row)
            return count, file_paths

    def get_downloads_size_bytes(self) -> int:
        """Return total file_size_bytes of available download records."""
        with self.get_session(read_only=True) as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .all()
            )
            return sum(r.file_size_bytes or 0 for r in rows)

    # ── Audit log ─────────────────────────────────────────────────────────────

    def audit(self, username: str, action: str,
              resource_type: str = None, resource_id: str = None,
              ip_address: str = None, user_agent: str = None,
              details: dict = None) -> None:
        """Append an immutable audit entry (fire-and-forget, never raises)."""
        try:
            with self.get_session() as session:
                session.add(AuditLog(
                    username=username or "unknown",
                    action=action,
                    resource_type=resource_type,
                    resource_id=str(resource_id) if resource_id is not None else None,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    details=details,
                ))
        except Exception:
            pass  # audit must never break the main flow

    def list_audit_log(self, username: str = None, action: str = None,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries newest-first, with optional filters."""
        with self.get_session(read_only=True) as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def mark_expired_downloads(self) -> int:
        """Mark download records as 'expired' where expires_at < now.

        Returns number of records marked expired.
        """
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(
                    DownloadFile.status == "available",
                    DownloadFile.expires_at != None,
                    DownloadFile.expires_at < now,
                )
                .all()
            )
            for row in rows:
                row.status = "expired"
            return len(rows)

    def expire_oldest_downloads(self, keep_count: int) -> int:
        """Mark oldest download records as expired until only keep_count remain.

        Returns number of records expired.
        """
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .order_by(DownloadFile.created_at.asc())
                .all()
            )
            to_expire = max(0, len(rows) - keep_count)
            for row in rows[:to_expire]:
                row.status = "expired"
            return to_expire

    # ── Query Version operations ───────────────────────────────────────────────

    def create_query_version(self, query_id: int, name: str = None, description: str = None,
                              query_config: dict = None, changed_by: str = None,
                              change_note: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Get next version number
            last = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .first())
            next_ver = (last.version_number + 1) if last else 1
            v = QueryVersion(
                query_id=query_id, version_number=next_ver,
                name=name, description=description, query_config=query_config,
                changed_by=changed_by, change_note=change_note,
            )
            session.add(v)
            session.flush()
            session.refresh(v)
            return v.to_dict()

    def list_query_versions(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .all())
            return [v.to_dict() for v in rows]

    def get_query_version(self, version_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(QueryVersion).filter(QueryVersion.id == version_id).first()
            return v.to_dict() if v else None

    # ── Query Share operations ─────────────────────────────────────────────────

    def create_share(self, query_id: int, created_by: str = None,
                     expires_at: Optional[datetime] = None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = QueryShare(
                token=_uuid.uuid4().hex,
                query_id=query_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            return s.to_dict() if s else None

    def increment_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    def list_shares(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(QueryShare)
                    .filter(QueryShare.query_id == query_id, QueryShare.is_active == True)
                    .order_by(QueryShare.created_at.desc())
                    .all())
            return [s.to_dict() for s in rows]

    def deactivate_share(self, token: str) -> bool:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if not s:
                return False
            s.is_active = False
            return True

    # ── Dashboard share operations ─────────────────────────────────────────────

    def create_dashboard_share(self, dashboard_id: int, created_by: str = None,
                               expires_at=None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = DashboardShare(
                token=_uuid.uuid4().hex,
                dashboard_id=dashboard_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_dashboard_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            return s.to_dict() if s else None

    def increment_dashboard_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    # ── Dashboard operations ───────────────────────────────────────────────────

    def create_dashboard(self, name: str, description: str = None,
                         created_by: str = None,
                         workspace_id: Optional[int] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = Dashboard(name=name, description=description, created_by=created_by,
                          workspace_id=workspace_id)
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def get_dashboard(self, dashboard_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id, Dashboard.is_active == True).first()
            return d.to_dict() if d else None

    def list_dashboards(self, created_by: str = None, is_admin: bool = True,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(Dashboard).filter(Dashboard.is_active == True)
            if not is_admin and created_by:
                q = q.filter(Dashboard.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (Dashboard.workspace_id == workspace_id) | (Dashboard.workspace_id == None)
                )
            rows = q.order_by(Dashboard.updated_at.desc()).all()
            return [d.to_dict() for d in rows]

    def update_dashboard(self, dashboard_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return None
            for k, v in kwargs.items():
                if hasattr(d, k):
                    setattr(d, k, v)
            d.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def delete_dashboard(self, dashboard_id: int) -> bool:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return False
            d.is_active = False
            return True

    # ── Dashboard Widget operations ────────────────────────────────────────────

    def create_widget(self, dashboard_id: int, widget_type: str, source_id: int,
                      title: str = None, layout: dict = None, chart_type: str = "grid",
                      chart_config: dict = None, param_values: dict = None) -> Dict[str, Any]:
        with self.get_session() as session:
            w = DashboardWidget(
                dashboard_id=dashboard_id, widget_type=widget_type, source_id=source_id,
                title=title, layout=layout or {"x": 0, "y": 0, "w": 6, "h": 4},
                chart_type=chart_type, chart_config=chart_config, param_values=param_values,
            )
            session.add(w)
            session.flush()
            session.refresh(w)
            # Touch parent dashboard updated_at
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)
            return w.to_dict()

    def list_widgets(self, dashboard_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(DashboardWidget)
                    .filter(DashboardWidget.dashboard_id == dashboard_id)
                    .order_by(DashboardWidget.id)
                    .all())
            return [w.to_dict() for w in rows]

    def update_widget(self, widget_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return None
            for k, v in kwargs.items():
                if hasattr(w, k):
                    setattr(w, k, v)
            w.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(w)
            return w.to_dict()

    def delete_widget(self, widget_id: int) -> bool:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return False
            session.delete(w)
            return True

    def update_widget_layouts(self, dashboard_id: int, layouts: list) -> None:
        """Bulk update widget positions from react-grid-layout onChange."""
        with self.get_session() as session:
            layout_map = {str(item["i"]): item for item in layouts}
            widgets = (session.query(DashboardWidget)
                       .filter(DashboardWidget.dashboard_id == dashboard_id)
                       .all())
            for w in widgets:
                if str(w.id) in layout_map:
                    item = layout_map[str(w.id)]
                    w.layout = {"x": item.get("x", 0), "y": item.get("y", 0),
                                "w": item.get("w", 6), "h": item.get("h", 4)}
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)

    # ── Materialized Views ─────────────────────────────────────────────────

    def create_materialized_view(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            mv = MaterializedView(**kwargs)
            session.add(mv)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def get_materialized_view(self, mv_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            return mv.to_dict() if mv else None

    def get_materialized_view_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            mv = session.query(MaterializedView).filter(MaterializedView.name == name).first()
            return mv.to_dict() if mv else None

    def list_materialized_views(self, connection_id: int = None,
                                 active_only: bool = True,
                                 workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(MaterializedView)
            if active_only:
                q = q.filter(MaterializedView.is_active == True)
            if connection_id is not None:
                q = q.filter(MaterializedView.connection_id == connection_id)
            if workspace_id is not None:
                q = q.filter(
                    (MaterializedView.workspace_id == workspace_id) | (MaterializedView.workspace_id == None)
                )
            rows = q.order_by(MaterializedView.name).all()
            return [mv.to_dict() for mv in rows]

    def update_materialized_view(self, mv_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(mv, key):
                    setattr(mv, key, value)
            mv.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def delete_materialized_view(self, mv_id: int) -> bool:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return False
            session.delete(mv)
            return True

    # ── Local Tables ──────────────────────────────────────────────────────────

    def create_local_table(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            lt = LocalTable(**kwargs)
            session.add(lt)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def get_local_table(self, lt_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            return lt.to_dict() if lt else None

    def get_local_table_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            lt = session.query(LocalTable).filter(LocalTable.name == name).first()
            return lt.to_dict() if lt else None

    def list_local_tables(self, visibility: str = None,
                          created_by: str = None,
                          active_only: bool = True,
                          workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(LocalTable)
            if active_only:
                q = q.filter(LocalTable.is_active == True)
            if visibility:
                q = q.filter(LocalTable.visibility == visibility)
            if created_by:
                q = q.filter(LocalTable.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (LocalTable.workspace_id == workspace_id) | (LocalTable.workspace_id == None)
                )
            rows = q.order_by(LocalTable.name).all()
            return [lt.to_dict() for lt in rows]

    def update_local_table(self, lt_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(lt, key):
                    setattr(lt, key, value)
            lt.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def delete_local_table(self, lt_id: int) -> bool:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return False
            session.delete(lt)
            return True

    def touch_local_table(self, lt_id: int) -> None:
        """Update last_accessed_at to now."""
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if lt:
                lt.last_accessed_at = datetime.now(timezone.utc)

    def list_expired_local_tables(self) -> List[Dict[str, Any]]:
        """Return public local tables that have not been accessed within their auto_discard_days."""
        with self.get_session(read_only=True) as session:
            now = datetime.now(timezone.utc)
            rows = (session.query(LocalTable)
                    .filter(LocalTable.is_active == True,
                            LocalTable.visibility == "public",
                            LocalTable.auto_discard_days > 0,
                            LocalTable.last_accessed_at != None)
                    .all())
            expired = []
            for lt in rows:
                cutoff = now - timedelta(days=lt.auto_discard_days)
                if lt.last_accessed_at and lt.last_accessed_at < cutoff:
                    expired.append(lt.to_dict())
            return expired

    # ── TaskQueue operations ──────────────────────────────────────────────

    def enqueue_task(self, task_id: str, task_type: str, payload: dict,
                     execution_id: str = None, created_by: str = None,
                     priority: int = 5, timeout_seconds: int = 1800,
                     retry_count: int = 0, max_retries: int = 3,
                     delay_seconds: int = 0) -> Dict[str, Any]:
        """Enqueue a new task. Called by FastAPI when executor.mode='external'."""
        with self.get_session() as session:
            next_retry_at = None
            if delay_seconds > 0:
                next_retry_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
            task = TaskQueue(
                task_id=task_id, task_type=task_type,
                payload=payload, execution_id=execution_id,
                created_by=created_by, priority=priority,
                timeout_seconds=timeout_seconds,
                retry_count=retry_count, max_retries=max_retries,
                next_retry_at=next_retry_at,
            )
            session.add(task)
            session.flush()
            session.refresh(task)
            return task.to_dict()

    def claim_next_task(self, worker_id: str, task_types: list = None) -> Optional[Dict[str, Any]]:
        """Atomic claim: grab the highest-priority pending task.

        Uses raw SQL UPDATE ... WHERE for true atomicity — only one worker
        can claim a given task even under concurrent access.
        """
        with self.get_session() as session:
            from sqlalchemy import text as _text, or_ as _or
            now = datetime.now(timezone.utc)
            # Step 1: Find best candidate (skip tasks not yet eligible due to backoff delay)
            q = (session.query(TaskQueue)
                 .filter(TaskQueue.status == "pending")
                 .filter(_or(TaskQueue.next_retry_at.is_(None),
                             TaskQueue.next_retry_at <= now))
                 .order_by(TaskQueue.priority, TaskQueue.created_at))
            if task_types:
                q = q.filter(TaskQueue.task_type.in_(task_types))
            task = q.first()
            if not task:
                return None
            # Step 2: Atomic claim — UPDATE only if still pending (race-safe)
            result = session.execute(
                _text("""UPDATE task_queue
                         SET status = 'claimed', claimed_by = :worker, claimed_at = :now
                         WHERE id = :tid AND status = 'pending'"""),
                {"worker": worker_id, "now": now, "tid": task.id}
            )
            if result.rowcount == 0:
                return None  # Another worker got it first
            session.expire(task)
            session.refresh(task)
            return task.to_dict()

    def update_task_progress(self, task_id: str, progress_pct: int,
                             progress_detail: str = None) -> None:
        """Called by executor thread to report progress."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.progress_pct = progress_pct
                if progress_detail is not None:
                    task.progress_detail = progress_detail
                if task.status == "claimed":
                    task.status = "processing"
                    task.started_at = datetime.now(timezone.utc)

    def complete_task(self, task_id: str, result: dict = None) -> None:
        """Mark task as completed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "completed"
                task.progress_pct = 100
                task.result = result
                task.completed_at = datetime.now(timezone.utc)

    def fail_task(self, task_id: str, error_message: str) -> None:
        """Mark task as failed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "failed"
                task.error_message = error_message
                task.completed_at = datetime.now(timezone.utc)

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get a single task by task_id."""
        with self.get_session(read_only=True) as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return task.to_dict() if task else None

    def list_tasks(self, status: str = None, limit: int = 50) -> List[Dict[str, Any]]:
        """List tasks, optionally filtered by status."""
        with self.get_session(read_only=True) as session:
            q = session.query(TaskQueue).order_by(TaskQueue.created_at.desc())
            if status:
                q = q.filter(TaskQueue.status == status)
            return [t.to_dict() for t in q.limit(limit).all()]

    def poll_active_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks that are processing or recently completed/failed (for WS broadcast)."""
        with self.get_session() as session:
            return [t.to_dict() for t in
                    session.query(TaskQueue)
                    .filter(TaskQueue.status.in_(["processing", "completed", "failed"]))
                    .order_by(TaskQueue.created_at.desc())
                    .limit(100)
                    .all()]

    def reclaim_stale_tasks(self, stale_seconds: int = 600) -> int:
        """Re-set claimed/processing tasks that exceeded timeout back to pending.

        Called periodically by the executor for graceful degradation when
        a worker dies mid-task.
        """
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(seconds=stale_seconds)
            stale = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["claimed", "processing"]),
                             TaskQueue.claimed_at < cutoff)
                     .all())
            count = 0
            for t in stale:
                if t.retry_count < t.max_retries:
                    t.status = "pending"
                    t.claimed_by = None
                    t.claimed_at = None
                    t.retry_count += 1
                else:
                    t.status = "failed"
                    t.error_message = "Executor timed out — max retries exceeded"
                    t.completed_at = datetime.now(timezone.utc)
                count += 1
            return count

    def cleanup_old_tasks(self, max_age_hours: int = 24) -> int:
        """Delete completed/failed tasks older than max_age_hours."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
            count = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["completed", "failed"]),
                             TaskQueue.completed_at < cutoff)
                     .delete(synchronize_session=False))
            return count

    # ── Dead-Letter Queue operations (Phase 22C) ──────────────────────────────

    def push_dead_letter(self, task: Dict[str, Any], error: str) -> None:
        """Move a permanently failed task to the DLQ."""
        with self.get_session() as session:
            dlq = DeadLetterQueue(
                task_id=task.get("task_id", ""),
                task_type=task.get("task_type", "unknown"),
                payload=task.get("payload", {}),
                execution_id=task.get("execution_id"),
                created_by=task.get("created_by") or (task.get("payload") or {}).get("executed_by"),
                original_error=error,
                retry_count=task.get("retry_count", 0),
                first_failed_at=datetime.now(timezone.utc),
            )
            session.merge(dlq)

    def list_dead_letter(self, resolved: Optional[bool] = False,
                         limit: int = 100) -> List[Dict[str, Any]]:
        """List DLQ entries. resolved=None returns all."""
        with self.get_session(read_only=True) as session:
            q = session.query(DeadLetterQueue)
            if resolved is not None:
                q = q.filter(DeadLetterQueue.resolved == int(resolved))
            q = q.order_by(DeadLetterQueue.dead_at.desc()).limit(limit)
            return [r.to_dict() for r in q.all()]

    def resolve_dead_letter(self, task_id: str, resolved_by: str) -> bool:
        """Mark a DLQ entry as resolved."""
        with self.get_session() as session:
            dlq = session.query(DeadLetterQueue).filter(
                DeadLetterQueue.task_id == task_id
            ).first()
            if not dlq:
                return False
            dlq.resolved = 1
            dlq.resolved_at = datetime.now(timezone.utc)
            dlq.resolved_by = resolved_by
            return True

    def request_task_cancel(self, execution_id: str) -> bool:
        """Request cancellation of a task by execution_id.

        Sets cancel_requested=1 so the executor worker picks it up.
        Returns True if a running task was found and flagged.
        """
        with self.get_session() as session:
            task = (session.query(TaskQueue)
                    .filter(TaskQueue.execution_id == execution_id,
                            TaskQueue.status.in_(["pending", "claimed", "processing"]))
                    .first())
            if not task:
                return False
            task.cancel_requested = 1
            if task.status == "pending":
                task.status = "cancelled"
                task.error_message = "Cancelled by user"
                task.completed_at = datetime.now(timezone.utc)
            return True

    def is_task_cancelled(self, task_id: str) -> bool:
        """Quick check — has cancellation been requested for this task?

        Called by executor worker between chunks for cooperative cancellation.
        """
        with self.get_session(read_only=True) as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return bool(task and task.cancel_requested)

    # ── TableFavorite operations ──────────────────────────────────────────

    def toggle_table_favorite(self, username: str, table_path: str,
                              table_name: str, connection_id: int = None,
                              table_type: str = None) -> bool:
        """Toggle favorite. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = (session.query(TableFavorite)
                        .filter(TableFavorite.username == username,
                                TableFavorite.table_path == table_path,
                                TableFavorite.connection_id == connection_id)
                        .first())
            if existing:
                session.delete(existing)
                return False
            fav = TableFavorite(
                username=username, table_path=table_path,
                table_name=table_name, connection_id=connection_id,
                table_type=table_type,
            )
            session.add(fav)
            return True

    def list_table_favorites(self, username: str,
                             connection_id: int = None) -> List[Dict[str, Any]]:
        """List user's favorited tables."""
        with self.get_session(read_only=True) as session:
            q = session.query(TableFavorite).filter(TableFavorite.username == username)
            if connection_id is not None:
                q = q.filter(TableFavorite.connection_id == connection_id)
            return [f.to_dict() for f in q.order_by(TableFavorite.created_at.desc()).all()]

    # ── Notification Log ────────────────────────────────────────────────────

    def log_notification(self, event_type: str, channel: str, recipient: str,
                         status: str = "sent", title: str = None, message: str = None,
                         payload: dict = None, execution_id: str = None,
                         schedule_id: int = None, attempt_count: int = 1,
                         error_message: str = None) -> Dict[str, Any]:
        """Record a notification delivery attempt."""
        with self.get_session() as session:
            row = NotificationLog(
                event_type=event_type, channel=channel, recipient=recipient,
                status=status, title=title, message=message, payload=payload,
                error_message=error_message, attempt_count=attempt_count,
                execution_id=execution_id, schedule_id=schedule_id,
                delivered_at=datetime.now(timezone.utc) if status == "sent" else None,
            )
            session.add(row)
            session.commit()
            session.refresh(row)
            return row.to_dict()

    def update_notification_status(self, notif_id: int, status: str,
                                   error_message: str = None) -> None:
        """Update delivery status of a notification."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row:
                row.status = status
                if error_message:
                    row.error_message = error_message
                if status == "sent":
                    row.delivered_at = datetime.now(timezone.utc)
                session.commit()

    def list_notifications(self, username: str, unread_only: bool = False,
                           limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """List notifications for a user (websocket channel, matched by recipient)."""
        with self.get_session(read_only=True) as session:
            q = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
            )
            if unread_only:
                q = q.filter(NotificationLog.is_read == 0)
            rows = q.order_by(NotificationLog.created_at.desc()).offset(offset).limit(limit).all()
            return [r.to_dict() for r in rows]

    def count_unread_notifications(self, username: str) -> int:
        """Count unread websocket notifications for a user."""
        with self.get_session(read_only=True) as session:
            return session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).count()

    def mark_notification_read(self, notif_id: int) -> None:
        """Mark a single notification as read."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row and not row.is_read:
                row.is_read = 1
                row.read_at = datetime.now(timezone.utc)
                session.commit()

    def mark_all_notifications_read(self, username: str) -> int:
        """Mark all unread notifications as read for a user. Returns count."""
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            count = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).update({"is_read": 1, "read_at": now}, synchronize_session=False)
            session.commit()
            return count

    def cleanup_old_notifications(self, max_age_days: int = 30) -> int:
        """Delete notifications older than max_age_days. Returns count deleted."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
            count = session.query(NotificationLog).filter(
                NotificationLog.created_at < cutoff,
            ).delete(synchronize_session=False)
            session.commit()
            return count

    # ── Phase 23A: Report Catalog ─────────────────────────────────────────────

    def create_folder(self, name: str, description: str = None, parent_id: int = None,
                      created_by: str = None, icon: str = "folder",
                      color: str = "#1976d2") -> Dict[str, Any]:
        with self.get_session() as session:
            folder = ReportFolder(name=name, description=description, parent_id=parent_id,
                                  created_by=created_by, icon=icon, color=color)
            session.add(folder)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def list_folders(self, parent_id: Optional[int] = None,
                     all_folders: bool = False) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReportFolder)
            if not all_folders:
                if parent_id is None:
                    q = q.filter(ReportFolder.parent_id.is_(None))
                else:
                    q = q.filter(ReportFolder.parent_id == parent_id)
            return [f.to_dict() for f in q.order_by(ReportFolder.name).all()]

    def update_folder(self, folder_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return None
            for k, v in kwargs.items():
                if hasattr(folder, k):
                    setattr(folder, k, v)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def delete_folder(self, folder_id: int) -> bool:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return False
            # Un-assign any reports in this folder
            session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.folder_id == folder_id
            ).delete(synchronize_session=False)
            # Re-parent child folders to this folder's parent
            session.query(ReportFolder).filter(
                ReportFolder.parent_id == folder_id
            ).update({"parent_id": folder.parent_id}, synchronize_session=False)
            session.delete(folder)
            return True

    def set_report_folder(self, report_id: int, folder_id: Optional[int],
                          report_type: str = "parametric") -> None:
        with self.get_session() as session:
            existing = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id,
                ReportFolderAssignment.report_type == report_type,
            ).first()
            if folder_id is None:
                if existing:
                    session.delete(existing)
            else:
                if existing:
                    existing.folder_id = folder_id
                else:
                    session.add(ReportFolderAssignment(
                        report_id=report_id, report_type=report_type, folder_id=folder_id))

    def get_report_folder(self, report_id: int,
                          report_type: str = "parametric") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            assignment = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id,
                ReportFolderAssignment.report_type == report_type,
            ).first()
            if not assignment:
                return None
            folder = session.query(ReportFolder).filter(
                ReportFolder.id == assignment.folder_id
            ).first()
            return folder.to_dict() if folder else None

    def create_tag(self, name: str, color: str = "#666666",
                   created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            tag = ReportTag(name=name, color=color, created_by=created_by)
            session.merge(tag)  # merge handles unique constraint gracefully
            session.flush()
            existing = session.query(ReportTag).filter(ReportTag.name == name).first()
            return existing.to_dict() if existing else tag.to_dict()

    def list_tags(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [t.to_dict() for t in session.query(ReportTag).order_by(ReportTag.name).all()]

    def delete_tag(self, tag_id: int) -> bool:
        with self.get_session() as session:
            tag = session.query(ReportTag).filter(ReportTag.id == tag_id).first()
            if not tag:
                return False
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.tag_id == tag_id
            ).delete(synchronize_session=False)
            session.delete(tag)
            return True

    def assign_report_tags(self, report_id: int, tag_ids: List[int],
                           report_type: str = "parametric") -> None:
        with self.get_session() as session:
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id,
                ReportTagAssignment.report_type == report_type,
            ).delete(synchronize_session=False)
            for tid in tag_ids:
                session.add(ReportTagAssignment(
                    report_id=report_id, report_type=report_type, tag_id=tid))

    def get_report_tags(self, report_id: int,
                        report_type: str = "parametric") -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            assignments = session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id,
                ReportTagAssignment.report_type == report_type,
            ).all()
            tag_ids = [a.tag_id for a in assignments]
            if not tag_ids:
                return []
            tags = session.query(ReportTag).filter(ReportTag.id.in_(tag_ids)).all()
            return [t.to_dict() for t in tags]

    def toggle_report_favorite(self, report_id: int, username: str,
                               report_type: str = "parametric") -> bool:
        """Toggle. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = session.query(ReportFavorite).filter(
                ReportFavorite.report_id == report_id,
                ReportFavorite.report_type == report_type,
                ReportFavorite.username == username,
            ).first()
            if existing:
                session.delete(existing)
                return False
            session.add(ReportFavorite(
                report_id=report_id, report_type=report_type, username=username))
            return True

    def get_user_favorites(self, username: str,
                           report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return list of favorited {report_id, report_type} for a user."""
        with self.get_session(read_only=True) as session:
            q = session.query(ReportFavorite).filter(
                ReportFavorite.username == username)
            if report_type:
                q = q.filter(ReportFavorite.report_type == report_type)
            rows = q.all()
            return [{"report_id": r.report_id, "report_type": r.report_type or "parametric"}
                    for r in rows]

    def record_report_view(self, report_id: int, username: str,
                           report_type: str = "parametric",
                           keep_last: int = 20) -> None:
        with self.get_session() as session:
            session.add(ReportView(
                report_id=report_id, report_type=report_type, username=username))
            session.flush()
            # Trim to last N views per user
            subq = (session.query(ReportView.id)
                    .filter(ReportView.username == username)
                    .order_by(ReportView.viewed_at.desc())
                    .offset(keep_last).all())
            old_ids = [r.id for r in subq]
            if old_ids:
                session.query(ReportView).filter(
                    ReportView.id.in_(old_ids)
                ).delete(synchronize_session=False)

    def get_recently_viewed(self, username: str, limit: int = 10,
                            report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return list of recently viewed {report_id, report_type} (most recent first)."""
        with self.get_session(read_only=True) as session:
            q = session.query(ReportView).filter(ReportView.username == username)
            if report_type:
                q = q.filter(ReportView.report_type == report_type)
            rows = q.order_by(ReportView.viewed_at.desc()).limit(limit * 2).all()
            seen: set = set()
            result = []
            for r in rows:
                key = (r.report_id, r.report_type or "parametric")
                if key not in seen:
                    seen.add(key)
                    result.append({"report_id": r.report_id,
                                   "report_type": r.report_type or "parametric"})
                    if len(result) >= limit:
                        break
            return result

    def search_reports(self, q: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Full-text search across report name + description (parametric only)."""
        from sqlalchemy import or_
        with self.get_session(read_only=True) as session:
            term = f"%{q}%"
            rows = (session.query(Report)
                    .filter(Report.is_active == True,
                            or_(Report.name.ilike(term),
                                Report.description.ilike(term)))
                    .order_by(Report.name)
                    .limit(limit).all())
            return [r.to_dict() for r in rows]

    # ── Portal helpers (Phase 59) ──────────────────────────────────────────────

    def count_user_reports(self, username: str, role: str) -> Dict[str, int]:
        """Count parametric + business reports accessible to a user."""
        with self.get_session(read_only=True) as session:
            param_count = session.query(Report).filter(Report.is_active == True).count()
            if role == "admin":
                biz_count = session.query(BusinessReport).count()
            else:
                own_ids = {r.id for r in session.query(BusinessReport.id)
                           .filter(BusinessReport.owner == username).all()}
                pub_ids = {r.id for r in session.query(BusinessReport.id)
                           .filter(BusinessReport.is_published == True).all()}
                biz_count = len(own_ids | pub_ids)
            return {"parametric": param_count, "business": biz_count,
                    "total": param_count + biz_count}

    def count_executions_today(self, username: str = None) -> int:
        """Count executions started today (UTC)."""
        today_start = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0)
        with self.get_session(read_only=True) as session:
            q = session.query(QueryExecution).filter(
                QueryExecution.started_at >= today_start)
            if username:
                q = q.filter(QueryExecution.executed_by == username)
            return q.count()

    def search_reports_unified(self, q: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Full-text search across both Report and BusinessReport tables (Phase 58)."""
        from sqlalchemy import or_
        with self.get_session(read_only=True) as session:
            term = f"%{q}%"
            # Parametric reports
            p_rows = (session.query(Report)
                      .filter(Report.is_active == True,
                              or_(Report.name.ilike(term),
                                  Report.description.ilike(term)))
                      .order_by(Report.name)
                      .limit(limit).all())
            results = [{"report_type": "parametric", **r.to_dict()} for r in p_rows]
            # Business reports (access control handled at API layer)
            b_rows = (session.query(BusinessReport)
                      .filter(or_(BusinessReport.name.ilike(term),
                                  BusinessReport.description.ilike(term)))
                      .order_by(BusinessReport.name)
                      .limit(limit).all())
            results.extend([{"report_type": "business", **r.to_dict()} for r in b_rows])
            results.sort(key=lambda x: x.get("name", "").lower())
            return results[:limit]

    # ── Phase 58: Certification ──────────────────────────────────────────────

    def certify_business_report(self, report_id: int, certified_by: str,
                                template_category: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            r.is_certified = True
            r.certified_by = certified_by
            r.certified_at = datetime.now(timezone.utc)
            if template_category is not None:
                r.template_category = template_category
            session.flush()
            return r.to_dict()

    def uncertify_business_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            r.is_certified = False
            r.certified_by = None
            r.certified_at = None
            r.template_category = None
            session.flush()
            return r.to_dict()

    def list_certified_templates(self, category: Optional[str] = None,
                                 limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(BusinessReport).filter(
                BusinessReport.is_certified == True,
            )
            if category:
                q = q.filter(BusinessReport.template_category == category)
            rows = q.order_by(BusinessReport.name).limit(limit).all()
            return [r.to_dict() for r in rows]

    def list_template_categories(self) -> List[str]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(BusinessReport.template_category)
                    .filter(BusinessReport.is_certified == True,
                            BusinessReport.template_category.isnot(None))
                    .distinct().all())
            return sorted([r[0] for r in rows if r[0]])

    # ── Phase 58: Business Report Share Tokens ───────────────────────────────

    def create_business_report_share(self, report_id: int, created_by: str = None,
                                     expires_at=None) -> Dict[str, Any]:
        import uuid
        with self.get_session() as session:
            tok = BusinessReportShareToken(
                token=uuid.uuid4().hex + uuid.uuid4().hex[:32],
                report_id=report_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(tok)
            session.flush()
            return tok.to_dict()

    def get_business_report_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            return t.to_dict() if t else None

    def list_business_report_shares(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.report_id == report_id,
                BusinessReportShareToken.is_active == True,
            ).order_by(BusinessReportShareToken.created_at.desc()).all()
            return [r.to_dict() for r in rows]

    def deactivate_business_report_share(self, token: str) -> bool:
        with self.get_session() as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            if not t:
                return False
            t.is_active = False
            return True

    def increment_business_report_share_access(self, token: str) -> None:
        with self.get_session() as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            if t:
                t.access_count = (t.access_count or 0) + 1

    # ── Phase 23G: Row-Level Security ─────────────────────────────────────────

    def create_rls_policy(self, report_id: int, column_name: str, operator: str,
                          value_template: str, description: str = None,
                          created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            policy = RLSPolicy(report_id=report_id, column_name=column_name,
                               operator=operator, value_template=value_template,
                               description=description, created_by=created_by)
            session.add(policy)
            session.flush()
            session.refresh(policy)
            return policy.to_dict()

    def list_rls_policies(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [p.to_dict() for p in
                    session.query(RLSPolicy).filter(RLSPolicy.report_id == report_id).all()]

    def update_rls_policy(self, policy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            policy = session.query(RLSPolicy).filter(RLSPolicy.id == policy_id).first()
            if not policy:
                return None
            for k, v in kwargs.items():
                if hasattr(policy, k):
                    setattr(policy, k, v)
            session.flush()
            session.refresh(policy)
            return policy.to_dict()

    def delete_rls_policy(self, policy_id: int) -> bool:
        with self.get_session() as session:
            policy = session.query(RLSPolicy).filter(RLSPolicy.id == policy_id).first()
            if not policy:
                return False
            session.delete(policy)
            return True

    def resolve_rls_value(self, value_template: str,
                          user_attrs: Dict[str, Any]) -> str:
        """Resolve {username}, {department}, etc. tokens from user attributes."""
        import re
        result = value_template
        for token in re.findall(r"\{(\w+)\}", value_template):
            val = user_attrs.get(token, "")
            result = result.replace(f"{{{token}}}", str(val))
        return result

    def build_rls_where_clauses(self, report_id: int,
                                user_attrs: Dict[str, Any]) -> List[str]:
        """Return list of SQL WHERE snippets for this report + user."""
        policies = self.list_rls_policies(report_id)
        clauses = []
        for p in policies:
            if not p.get("is_enabled"):
                continue
            col = p["column_name"]
            op  = p["operator"]
            val = self.resolve_rls_value(p["value_template"], user_attrs)
            if op.upper() in ("IN", "NOT IN"):
                vals = ", ".join(f"'{v.strip()}'" for v in val.split(","))
                clauses.append(f"{col} {op} ({vals})")
            else:
                clauses.append(f"{col} {op} '{val}'")
        return clauses

    # ── Phase 23B: Report Bookmarks ───────────────────────────────────────────

    def save_bookmark(self, report_id: int, username: str, name: str,
                      param_values: dict) -> Dict[str, Any]:
        with self.get_session() as session:
            bm = ReportBookmark(report_id=report_id, username=username,
                                name=name, param_values=param_values)
            session.add(bm)
            session.flush()
            session.refresh(bm)
            return bm.to_dict()

    def list_bookmarks(self, report_id: int,
                       username: str) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [b.to_dict() for b in
                    session.query(ReportBookmark)
                    .filter(ReportBookmark.report_id == report_id,
                            ReportBookmark.username == username)
                    .order_by(ReportBookmark.name).all()]

    def delete_bookmark(self, bookmark_id: int, username: str) -> bool:
        with self.get_session() as session:
            bm = session.query(ReportBookmark).filter(
                ReportBookmark.id == bookmark_id,
                ReportBookmark.username == username,
            ).first()
            if not bm:
                return False
            session.delete(bm)
            return True

    # ── Phase 23D: PDF Config ─────────────────────────────────────────────────

    def get_pdf_config(self, report_id: int) -> Dict[str, Any]:
        with self.get_session(read_only=True) as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id
            ).first()
            if not cfg:
                return ReportPDFConfig(report_id=report_id).to_dict()
            return cfg.to_dict()

    def save_pdf_config(self, report_id: int, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id
            ).first()
            if not cfg:
                cfg = ReportPDFConfig(report_id=report_id)
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            cfg.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    # ── Phase 23E: Report Bursting ────────────────────────────────────────────

    def create_burst_job(self, report_id: int, burst_column: str,
                         output_format: str = "pdf", delivery_type: str = "email",
                         base_params: dict = None, recipient_map: dict = None,
                         default_recipient: str = None, s3_prefix: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            job = BurstJob(report_id=report_id, burst_column=burst_column,
                           output_format=output_format, delivery_type=delivery_type,
                           base_params=base_params or {}, recipient_map=recipient_map,
                           default_recipient=default_recipient, s3_prefix=s3_prefix,
                           created_by=created_by)
            session.add(job)
            session.flush()
            session.refresh(job)
            return job.to_dict()

    def get_burst_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            job = session.query(BurstJob).filter(BurstJob.id == job_id).first()
            return job.to_dict() if job else None

    def list_burst_jobs(self, report_id: int,
                        limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [j.to_dict() for j in
                    session.query(BurstJob)
                    .filter(BurstJob.report_id == report_id)
                    .order_by(BurstJob.created_at.desc())
                    .limit(limit).all()]

    def update_burst_job(self, job_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstJob).filter(BurstJob.id == job_id).update(
                kwargs, synchronize_session=False
            )

    def create_burst_tasks(self, job_id: int,
                           tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            created = []
            for t in tasks:
                bt = BurstTask(burst_job_id=job_id,
                               dimension_value=t["dimension_value"],
                               recipient=t.get("recipient"))
                session.add(bt)
                session.flush()
                session.refresh(bt)
                created.append(bt.to_dict())
            return created

    def list_burst_tasks(self, job_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [t.to_dict() for t in
                    session.query(BurstTask)
                    .filter(BurstTask.burst_job_id == job_id)
                    .order_by(BurstTask.dimension_value).all()]

    def update_burst_task(self, task_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstTask).filter(BurstTask.id == task_id).update(
                kwargs, synchronize_session=False
            )

    # ── Phase 23F: Alert Rules ────────────────────────────────────────────────

    def create_alert_rule(self, report_id: int, name: str, column_name: str,
                          operator: str, threshold_value: float,
                          aggregation: str = "last", channels: list = None,
                          recipients: str = None, slack_webhook: str = None,
                          cooldown_minutes: int = 60,
                          created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            rule = AlertRule(
                report_id=report_id, name=name, column_name=column_name,
                operator=operator, threshold_value=threshold_value,
                aggregation=aggregation, channels=channels or [],
                recipients=recipients, slack_webhook=slack_webhook,
                cooldown_minutes=cooldown_minutes, created_by=created_by,
            )
            session.add(rule)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def list_alert_rules(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in
                    session.query(AlertRule)
                    .filter(AlertRule.report_id == report_id)
                    .order_by(AlertRule.name).all()]

    def update_alert_rule(self, rule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return None
            for k, v in kwargs.items():
                if hasattr(rule, k):
                    setattr(rule, k, v)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def delete_alert_rule(self, rule_id: int) -> bool:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return False
            session.delete(rule)
            return True

    def record_alert(self, rule_id: int, actual_value: float,
                     threshold_value: float, channel: str, sent_to: str,
                     suppressed: bool = False) -> None:
        with self.get_session() as session:
            session.add(AlertHistory(
                rule_id=rule_id, actual_value=actual_value,
                threshold_value=threshold_value, channel=channel,
                sent_to=sent_to, was_suppressed=suppressed,
            ))
            if not suppressed:
                session.query(AlertRule).filter(AlertRule.id == rule_id).update(
                    {"last_triggered_at": datetime.now(timezone.utc)},
                    synchronize_session=False,
                )

    def list_alert_history(self, rule_id: int,
                           limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [h.to_dict() for h in
                    session.query(AlertHistory)
                    .filter(AlertHistory.rule_id == rule_id)
                    .order_by(AlertHistory.triggered_at.desc())
                    .limit(limit).all()]

    def evaluate_alert_rules(self, report_id: int,
                             result_df_dict: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Evaluate all enabled alert rules for a report against result rows.
        Returns list of triggered rule dicts (caller handles notification)."""
        rules = [r for r in self.list_alert_rules(report_id) if r.get("is_enabled")]
        triggered = []
        now = datetime.now(timezone.utc)

        for rule in rules:
            # Check cooldown
            last = rule.get("last_triggered_at")
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt.tzinfo is None:
                        last_dt = last_dt.replace(tzinfo=timezone.utc)
                    elapsed_min = (now - last_dt).total_seconds() / 60
                    if elapsed_min < rule["cooldown_minutes"]:
                        continue  # Still in cooldown
                except Exception:
                    pass

            col = rule["column_name"]
            agg = rule.get("aggregation", "last")
            try:
                values = [float(r[col]) for r in result_df_dict
                          if r.get(col) is not None]
                if not values:
                    continue
                if agg == "last":
                    actual = values[-1]
                elif agg == "sum":
                    actual = sum(values)
                elif agg == "avg":
                    actual = sum(values) / len(values)
                elif agg == "max":
                    actual = max(values)
                elif agg == "min":
                    actual = min(values)
                elif agg == "count":
                    actual = float(len(values))
                else:
                    actual = values[-1]
            except (KeyError, ValueError, TypeError):
                continue

            op = rule["operator"]
            th = rule["threshold_value"]
            fired = (
                (op == ">"  and actual >  th) or
                (op == "<"  and actual <  th) or
                (op == ">=" and actual >= th) or
                (op == "<=" and actual <= th) or
                (op == "="  and actual == th) or
                (op == "!=" and actual != th)
            )
            if fired:
                triggered.append({**rule, "actual_value": actual})

        return triggered

    # ── Phase 23C: Conditional Formatting ────────────────────────────────────

    def save_conditional_formats(self, report_id: int,
                                 rules: List[Dict[str, Any]]) -> None:
        """Replace all conditional format rules for a report."""
        with self.get_session() as session:
            session.query(ConditionalFormatRule).filter(
                ConditionalFormatRule.report_id == report_id
            ).delete(synchronize_session=False)
            for i, r in enumerate(rules):
                session.add(ConditionalFormatRule(
                    report_id=report_id,
                    column_name=r.get("column_name", ""),
                    rule_order=r.get("rule_order", i),
                    condition_type=r.get("condition_type", "value_range"),
                    condition_value=r.get("condition_value"),
                    bg_color=r.get("bg_color"),
                    text_color=r.get("text_color"),
                    icon=r.get("icon", "none"),
                    bold=r.get("bold", False),
                    is_enabled=r.get("is_enabled", True),
                ))

    def get_conditional_formats(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in
                    session.query(ConditionalFormatRule)
                    .filter(ConditionalFormatRule.report_id == report_id)
                    .order_by(ConditionalFormatRule.column_name,
                               ConditionalFormatRule.rule_order)
                    .all()]

    # ── Phase 23H: Cloud Delivery ─────────────────────────────────────────────

    def save_cloud_delivery_config(self, schedule_id: int,
                                   **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            if not cfg:
                cfg = CloudDeliveryConfig(schedule_id=schedule_id,
                                          provider=kwargs.pop("provider", "s3"))
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    def get_cloud_delivery_config(self,
                                  schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            return cfg.to_dict() if cfg else None

    def record_delivery(self, delivery_type: str, destination: str,
                        status: str, schedule_id: int = None,
                        burst_task_id: int = None, execution_id: str = None,
                        file_format: str = None, file_size_bytes: int = None,
                        error_message: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = DeliveryHistory(
                schedule_id=schedule_id, burst_task_id=burst_task_id,
                execution_id=execution_id, delivery_type=delivery_type,
                destination=destination, file_format=file_format,
                file_size_bytes=file_size_bytes, status=status,
                error_message=error_message,
                delivered_at=datetime.now(timezone.utc) if status == "delivered" else None,
            )
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def list_delivery_history(self, schedule_id: int = None,
                              burst_task_id: int = None,
                              limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(DeliveryHistory)
            if schedule_id is not None:
                q = q.filter(DeliveryHistory.schedule_id == schedule_id)
            if burst_task_id is not None:
                q = q.filter(DeliveryHistory.burst_task_id == burst_task_id)
            return [d.to_dict() for d in
                    q.order_by(DeliveryHistory.attempted_at.desc()).limit(limit).all()]

    # ── Workspaces (Phase 25) ─────────────────────────────────────────────────

    def ensure_default_workspace(self) -> Dict[str, Any]:
        """Create the Global workspace on first startup if none exist."""
        with self.get_session() as session:
            existing = session.query(Workspace).filter(Workspace.is_active == True).first()
            if existing:
                return existing.to_dict()
            ws = Workspace(name="Global", slug="global",
                           description="Default workspace", created_by="system")
            session.add(ws)
            session.flush()
            session.refresh(ws)
            return ws.to_dict()

    def list_workspaces(self, username: str = None) -> List[Dict[str, Any]]:
        """Return workspaces the user is a member of, or all if username is None."""
        with self.get_session(read_only=True) as session:
            if username is None:
                wss = session.query(Workspace).filter(
                    Workspace.is_active == True
                ).order_by(Workspace.name).all()
                return [w.to_dict() for w in wss]
            # Workspaces where user is a member
            member_wids = [
                m.workspace_id for m in
                session.query(WorkspaceMember).filter(
                    WorkspaceMember.username == username
                ).all()
            ]
            wss = session.query(Workspace).filter(
                Workspace.id.in_(member_wids),
                Workspace.is_active == True,
            ).order_by(Workspace.name).all()
            return [w.to_dict() for w in wss]

    def get_workspace(self, workspace_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            return ws.to_dict() if ws else None

    def create_workspace(self, name: str, slug: str,
                         description: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            ws = Workspace(name=name, slug=slug, description=description,
                           created_by=created_by)
            session.add(ws)
            session.flush()
            session.refresh(ws)
            # Auto-add creator as owner
            if created_by:
                m = WorkspaceMember(workspace_id=ws.id, username=created_by,
                                    role="owner", added_by=created_by)
                session.add(m)
                session.flush()
            return ws.to_dict()

    def update_workspace(self, workspace_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return None
            for k, v in kwargs.items():
                if hasattr(ws, k):
                    setattr(ws, k, v)
            ws.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(ws)
            return ws.to_dict()

    def delete_workspace(self, workspace_id: int) -> bool:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return False
            ws.is_active = False
            ws.updated_at = datetime.now(timezone.utc)
            return True

    def list_workspace_members(self, workspace_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            members = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id
            ).order_by(WorkspaceMember.added_at).all()
            return [m.to_dict() for m in members]

    def add_workspace_member(self, workspace_id: int, username: str,
                             role: str = "member",
                             added_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Upsert: update role if already member
            existing = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if existing:
                existing.role = role
                session.flush()
                session.refresh(existing)
                return existing.to_dict()
            m = WorkspaceMember(workspace_id=workspace_id, username=username,
                                role=role, added_by=added_by)
            session.add(m)
            session.flush()
            session.refresh(m)
            return m.to_dict()

    def update_workspace_member_role(self, workspace_id: int,
                                     username: str, role: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            m.role = role
            return True

    def remove_workspace_member(self, workspace_id: int,
                                username: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            session.delete(m)
            return True

    # ── Report Embed Tokens (27) ──────────────────────────────────────────────

    def create_report_embed_token(self, report_id: int, created_by: str = None,
                                  expires_at=None, allowed_params=None,
                                  report_type: str = "parametric") -> Dict[str, Any]:
        import uuid, json as _json
        with self.get_session() as session:
            tok = ReportEmbedToken(
                token=uuid.uuid4().hex,
                report_id=report_id,
                report_type=report_type,
                created_by=created_by,
                expires_at=expires_at,
                is_active=True,
                access_count=0,
                allowed_params=_json.dumps(allowed_params) if allowed_params else None,
            )
            session.add(tok)
            session.flush()
            return tok.to_dict()

    def get_embed_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            return t.to_dict() if t else None

    def list_embed_tokens(self, report_id: int,
                          report_type: str = "parametric") -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.report_id == report_id,
                ReportEmbedToken.report_type == report_type,
            ).order_by(ReportEmbedToken.created_at.desc()).all()
            return [r.to_dict() for r in rows]

    def revoke_embed_token(self, token: str) -> bool:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if not t:
                return False
            t.is_active = False
            return True

    def increment_embed_token_access(self, token: str) -> None:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if t:
                t.access_count = (t.access_count or 0) + 1

    # ── Audit & Compliance (28) ───────────────────────────────────────────────

    def get_audit_log_filtered(self, username: str = None, action: str = None,
                               resource_type: str = None, date_from: str = None,
                               date_to: str = None, limit: int = 200,
                               offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries with extended filters."""
        with self.get_session(read_only=True) as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            if resource_type:
                q = q.filter(AuditLog.resource_type == resource_type)
            if date_from:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp >= _parse(date_from))
                except Exception:
                    pass
            if date_to:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp <= _parse(date_to))
                except Exception:
                    pass
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def get_data_access_summary(self) -> List[Dict[str, Any]]:
        """Return per-user aggregate data access statistics."""
        with self.get_session(read_only=True) as session:
            from sqlalchemy import func, distinct
            # Aggregate from query_executions
            exec_rows = session.query(
                QueryExecution.executed_by,
                func.count(QueryExecution.id).label("total_executions"),
                func.max(QueryExecution.started_at).label("last_active"),
                func.sum(QueryExecution.total_rows).label("total_rows"),
            ).filter(QueryExecution.executed_by.isnot(None)).group_by(
                QueryExecution.executed_by
            ).all()
            # Aggregate download count from audit_log
            download_rows = session.query(
                AuditLog.username,
                func.count(AuditLog.id).label("export_count"),
            ).filter(AuditLog.action.in_(["download_file", "export_csv"])).group_by(
                AuditLog.username
            ).all()
            dl_map = {r.username: r.export_count for r in download_rows}
            result = []
            for r in exec_rows:
                result.append({
                    "username": r.executed_by,
                    "total_executions": r.total_executions or 0,
                    "last_active": r.last_active.isoformat() if r.last_active else None,
                    "total_rows": r.total_rows or 0,
                    "export_count": dl_map.get(r.executed_by, 0),
                })
            return result

    # -- Schedule run stats (Phase 38 anomaly detection) -------------------------

    def create_schedule_run_stats(self, schedule_id: int, row_count: int = 0,
                                  execution_seconds: float = 0.0,
                                  file_size_bytes: int = 0,
                                  anomaly_type: str = None,
                                  anomaly_details: dict = None) -> dict:
        with self.get_session() as session:
            entry = ScheduleRunStats(
                schedule_id=schedule_id,
                row_count=row_count,
                execution_seconds=execution_seconds,
                file_size_bytes=file_size_bytes,
                anomaly_type=anomaly_type,
                anomaly_details=anomaly_details,
            )
            session.add(entry)
            session.commit()
            session.refresh(entry)
            return entry.to_dict()

    def get_schedule_run_stats(self, schedule_id: int, limit: int = 20) -> list:
        with self.get_session(read_only=True) as session:
            entries = (session.query(ScheduleRunStats)
                       .filter_by(schedule_id=schedule_id)
                       .order_by(ScheduleRunStats.run_at.desc())
                       .limit(limit)
                       .all())
            return [e.to_dict() for e in entries]

    def list_anomalies(self, schedule_id: int = None, limit: int = 50) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(ScheduleRunStats).filter(
                ScheduleRunStats.anomaly_type.isnot(None)
            )
            if schedule_id:
                q = q.filter_by(schedule_id=schedule_id)
            entries = q.order_by(ScheduleRunStats.run_at.desc()).limit(limit).all()
            return [e.to_dict() for e in entries]

    # ── Checkpoint methods (Phase 41) ────────────────────────────────────

    def set_checkpoint(self, execution_id: str, state: str, query_config: dict,
                       executed_by: str = "", query_id: int = None,
                       timestamp: float = 0) -> None:
        """Insert or update a checkpoint record for an execution."""
        import time as _time
        with self.get_session() as session:
            cp = ExecutionCheckpoint(
                execution_id=execution_id, state=state,
                query_config=query_config, executed_by=executed_by,
                query_id=query_id, timestamp=timestamp or _time.time(),
            )
            session.merge(cp)

    def update_checkpoint(self, execution_id: str, state: str, timestamp: float = 0) -> None:
        """Update the state of an existing checkpoint."""
        import time as _time
        with self.get_session() as session:
            cp = session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).first()
            if cp:
                cp.state = state
                cp.timestamp = timestamp or _time.time()

    def delete_checkpoint(self, execution_id: str) -> None:
        """Remove a checkpoint record (execution finished)."""
        with self.get_session() as session:
            session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).delete()

    def get_all_checkpoints(self) -> list:
        """Return all checkpoint records (used during recovery on startup)."""
        with self.get_session(read_only=True) as session:
            rows = session.query(ExecutionCheckpoint).all()
            return [{"execution_id": r.execution_id, "state": r.state,
                     "query_config": r.query_config, "executed_by": r.executed_by,
                     "query_id": r.query_id, "timestamp": r.timestamp} for r in rows]

    def get_user_data_export(self, username: str) -> Dict[str, Any]:
        """Return all data related to a user for GDPR subject export."""
        with self.get_session(read_only=True) as session:
            saved_queries = session.query(SavedQuery).filter(
                SavedQuery.created_by == username
            ).all()
            sql_queries = session.query(SqlSavedQuery).filter(
                SqlSavedQuery.created_by == username
            ).all()
            executions = session.query(QueryExecution).filter(
                QueryExecution.executed_by == username
            ).order_by(QueryExecution.started_at.desc()).limit(10000).all()
            downloads = session.query(DownloadFile).filter(
                DownloadFile.created_by == username
            ).order_by(DownloadFile.created_at.desc()).limit(10000).all()
            schedules = session.query(Schedule).filter(
                Schedule.created_by == username
            ).all()
            audit = session.query(AuditLog).filter(
                AuditLog.username == username
            ).order_by(AuditLog.timestamp.desc()).limit(50000).all()
            return {
                "username": username,
                "saved_queries": [q.to_dict() for q in saved_queries],
                "sql_queries": [q.to_dict() for q in sql_queries],
                "executions": [e.to_dict() for e in executions],
                "downloads": [d.to_dict() for d in downloads],
                "schedules": [s.to_dict() for s in schedules],
                "audit_log": [a.to_dict() for a in audit],
            }


    # ── Lineage + Intelligence methods → core/db/mixin_lineage.py ──────
    # ── Datasets + Federation + Business Reports → core/db/mixin_datasets.py


    # ── REST Query Definitions (Phase 61) ────────────────────────────────────

    def create_rest_query_def(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            rqd = RestQueryDef(**kwargs)
            session.add(rqd)
            session.flush()
            session.refresh(rqd)
            return rqd.to_dict()

    def get_rest_query_def(self, rqd_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            return rqd.to_dict() if rqd else None

    def list_rest_query_defs(self, connection_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rqds = session.query(RestQueryDef).filter(
                RestQueryDef.connection_id == connection_id,
                RestQueryDef.is_active == True,
            ).order_by(RestQueryDef.name).all()
            return [r.to_dict() for r in rqds]

    def update_rest_query_def(self, rqd_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            if not rqd:
                return None
            for k, v in kwargs.items():
                if hasattr(rqd, k):
                    setattr(rqd, k, v)
            session.flush()
            session.refresh(rqd)
            return rqd.to_dict()

    def delete_rest_query_def(self, rqd_id: int) -> bool:
        with self.get_session() as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            if not rqd:
                return False
            session.delete(rqd)
            return True
