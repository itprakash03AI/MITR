"""
Mixin — Table Lineage, Column Lineage, Snapshots, Freshness, Usage Stats,
NL Feedback, Suggestion Corrections, UI Visibility.
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

from core.db.models import (
    TableLineageEntry, ColumnLineageEntry, LineageSnapshot, DataFreshness,
    QueryUsageStat, NLFeedback, SuggestionCorrection, UIComponentVisibility,
)


class LineageMixin:
    """Database methods for lineage, intelligence, and UI visibility."""


    def upsert_table_lineage(self, query_type: str, query_id: int, entries: List[Dict[str, Any]]) -> None:
        """Replace all lineage entries for a query with new ones."""
        with self.get_session() as session:
            session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).delete()
            for e in entries:
                session.add(TableLineageEntry(
                    query_type=e["query_type"],
                    query_id=e["query_id"],
                    connection_id=e.get("connection_id"),
                    table_catalog=e.get("table_catalog"),
                    table_schema=e.get("table_schema"),
                    table_name=e["table_name"],
                    access_type=e.get("access_type", "read"),
                    extraction_method=e.get("extraction_method", "sqlglot"),
                ))

    def get_table_lineage_for_query(self, query_type: str, query_id: int) -> List[Dict[str, Any]]:
        """All physical tables a query touches."""
        with self.get_session() as session:
            rows = session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).all()
            return [r.to_dict() for r in rows]

    def get_queries_for_table(self, table_catalog: Optional[str], table_schema: Optional[str],
                              table_name: str) -> List[Dict[str, Any]]:
        """Reverse lookup: all queries that reference a physical table (impact analysis)."""
        with self.get_session() as session:
            q = session.query(TableLineageEntry).filter(TableLineageEntry.table_name == table_name)
            if table_schema:
                q = q.filter(TableLineageEntry.table_schema == table_schema)
            if table_catalog:
                q = q.filter(TableLineageEntry.table_catalog == table_catalog)
            return [r.to_dict() for r in q.all()]

    def get_all_table_lineage_entries(self) -> List[Dict[str, Any]]:
        """All table lineage entries — for graph building."""
        with self.get_session() as session:
            rows = session.query(TableLineageEntry).all()
            return [r.to_dict() for r in rows]

    def delete_table_lineage(self, query_type: str, query_id: int) -> None:
        """Remove lineage entries when a query is deleted."""
        with self.get_session() as session:
            session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).delete()

    def search_table_lineage(self, search_term: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Full-text search across table catalog/schema/name."""
        with self.get_session() as session:
            pattern = f"%{search_term}%"
            from sqlalchemy import or_
            rows = session.query(TableLineageEntry).filter(
                or_(
                    TableLineageEntry.table_name.ilike(pattern),
                    TableLineageEntry.table_schema.ilike(pattern),
                    TableLineageEntry.table_catalog.ilike(pattern),
                )
            ).limit(limit).all()
            # Deduplicate by (catalog, schema, table)
            seen = set()
            results = []
            for r in rows:
                key = (r.table_catalog, r.table_schema, r.table_name)
                if key not in seen:
                    seen.add(key)
                    results.append({
                        "table_catalog": r.table_catalog,
                        "table_schema": r.table_schema,
                        "table_name": r.table_name,
                        "connection_id": r.connection_id,
                        "query_count": session.query(TableLineageEntry).filter(
                            TableLineageEntry.table_name == r.table_name,
                            TableLineageEntry.table_schema == r.table_schema,
                            TableLineageEntry.table_catalog == r.table_catalog,
                        ).count(),
                    })
            return results

    # ── Phase 46: Query Usage Stats (auto-suggest) ────────────────────────────

    def record_usage(self, object_type: str, object_name: str,
                     connection_id: Optional[int] = None,
                     table_name: Optional[str] = None,
                     schema_name: Optional[str] = None,
                     catalog_name: Optional[str] = None) -> None:
        """Increment use_count for table/column or create new entry."""
        with self.get_session() as session:
            row = session.query(QueryUsageStat).filter(
                QueryUsageStat.object_type == object_type,
                QueryUsageStat.object_name == object_name,
                QueryUsageStat.connection_id == connection_id,
            ).first()
            if row:
                row.use_count += 1
                row.last_used_at = datetime.now(timezone.utc)
            else:
                session.add(QueryUsageStat(
                    object_type=object_type,
                    object_name=object_name,
                    table_name=table_name,
                    schema_name=schema_name,
                    catalog_name=catalog_name,
                    connection_id=connection_id,
                    use_count=1,
                ))

    def get_table_suggestions(self, prefix: str = "",
                               connection_id: Optional[int] = None,
                               limit: int = 20) -> List[Dict[str, Any]]:
        """Return tables ranked by use_count descending, optionally filtered by prefix."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "table")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            if prefix:
                q = q.filter(QueryUsageStat.object_name.ilike(f"{prefix}%"))
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_column_suggestions(self, table_name: str = "",
                                connection_id: Optional[int] = None,
                                limit: int = 30) -> List[Dict[str, Any]]:
        """Return columns for a table ranked by use_count."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "column")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            if table_name:
                q = q.filter(QueryUsageStat.table_name == table_name)
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_top_tables(self, connection_id: Optional[int] = None,
                       limit: int = 50) -> List[Dict[str, Any]]:
        """Top tables by usage across all connections."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "table")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    # ── Phase 51: Column Lineage ──────────────────────────────────────────────

    def upsert_column_lineage(self, query_type: str, query_id: int,
                               entries: List[Dict[str, Any]]) -> None:
        """Replace all column lineage entries for a query."""
        with self.get_session() as session:
            session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.query_type == query_type,
                ColumnLineageEntry.query_id == query_id,
            ).delete()
            for e in entries:
                session.add(ColumnLineageEntry(
                    query_type=query_type,
                    query_id=query_id,
                    source_table=e.get("source_table"),
                    source_column=e.get("source_column"),
                    target_column=e["target_column"],
                    transform_type=e.get("transform_type", "direct"),
                    transform_expr=e.get("transform_expr"),
                ))

    def get_column_lineage_for_query(self, query_type: str, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.query_type == query_type,
                ColumnLineageEntry.query_id == query_id,
            ).all()
            return [r.to_dict() for r in rows]

    def get_column_impact(self, table_name: str, column_name: str) -> List[Dict[str, Any]]:
        """All queries that consume a specific source table.column."""
        with self.get_session() as session:
            rows = session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.source_table == table_name,
                ColumnLineageEntry.source_column == column_name,
            ).order_by(ColumnLineageEntry.query_id).all()
            return [r.to_dict() for r in rows]

    # ── NL Feedback / Learning ────────────────────────────────────────────────

    def save_nl_feedback(self, question: str, sql: str,
                          connection_type: str = "duckdb",
                          tables_hint: str = "",
                          rating: int = 1) -> Dict[str, Any]:
        """Upsert a user-rated NL→SQL pair (by question text)."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            existing = session.query(NLFeedback).filter(
                NLFeedback.question == question[:500]
            ).first()
            if existing:
                existing.sql          = sql
                existing.rating       = rating
                existing.use_count    = (existing.use_count or 0) + 1
                existing.updated_at   = now
                session.flush()
                return existing.to_dict()
            row = NLFeedback(
                question=question[:500], sql=sql,
                connection_type=connection_type,
                tables_hint=tables_hint[:500] if tables_hint else "",
                rating=rating, use_count=1,
                created_at=now, updated_at=now,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_nl_feedback(self, limit: int = 200, rating: int = 1) -> List[Dict[str, Any]]:
        """Return all positively-rated NL→SQL pairs, sorted by use_count desc."""
        with self.get_session() as session:
            rows = session.query(NLFeedback).filter(
                NLFeedback.rating >= rating
            ).order_by(NLFeedback.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def delete_nl_feedback(self, feedback_id: int) -> bool:
        """Remove a learned pattern by ID."""
        with self.get_session() as session:
            row = session.query(NLFeedback).filter(NLFeedback.id == feedback_id).first()
            if row:
                session.delete(row)
                return True
            return False

    # ------------------------------------------------------------------ #
    #  Suggestion Corrections (Smart Agg + Join Feedback)                  #
    # ------------------------------------------------------------------ #

    def save_suggestion_correction(
        self,
        correction_type: str,
        context_key: str,
        corrected_value: str,
        original_value: Optional[str] = None,
        context_extra: Optional[str] = None,
        username: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upsert a user correction for aggregation or join suggestion."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            existing = session.query(SuggestionCorrection).filter(
                SuggestionCorrection.correction_type == correction_type,
                SuggestionCorrection.context_key == context_key[:500],
            ).first()
            if existing:
                existing.corrected_value = corrected_value
                existing.original_value = original_value
                existing.context_extra = context_extra
                existing.use_count = (existing.use_count or 0) + 1
                existing.updated_at = now
                existing.username = username or existing.username
                session.flush()
                return existing.to_dict()
            row = SuggestionCorrection(
                correction_type=correction_type,
                context_key=context_key[:500],
                original_value=original_value,
                corrected_value=corrected_value,
                context_extra=context_extra,
                username=username,
                use_count=1,
                created_at=now,
                updated_at=now,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_suggestion_corrections(
        self,
        correction_type: str,
        context_keys: Optional[List[str]] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """Return corrections, optionally filtered by context_keys list."""
        with self.get_session() as session:
            q = session.query(SuggestionCorrection).filter(
                SuggestionCorrection.correction_type == correction_type,
            )
            if context_keys:
                q = q.filter(SuggestionCorrection.context_key.in_(context_keys))
            rows = q.order_by(SuggestionCorrection.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_all_agg_corrections(self, limit: int = 500) -> List[Dict[str, Any]]:
        """Return all aggregation corrections, sorted by use_count desc."""
        return self.get_suggestion_corrections("agg", limit=limit)

    def get_all_join_corrections(self, limit: int = 200) -> List[Dict[str, Any]]:
        """Return all join corrections, sorted by use_count desc."""
        return self.get_suggestion_corrections("join", limit=limit)

    def get_chart_feedback(self, connection_id: int = None, limit: int = 500) -> List[Dict[str, Any]]:
        """Return all chart preset feedback, optionally filtered by connection prefix."""
        with self.get_session() as session:
            q = session.query(SuggestionCorrection).filter(
                SuggestionCorrection.correction_type == "chart",
            )
            if connection_id is not None:
                q = q.filter(SuggestionCorrection.context_key.like(f"conn:{connection_id}|%"))
            rows = q.order_by(SuggestionCorrection.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_pivot_feedback(self, connection_id: int = None, limit: int = 500) -> List[Dict[str, Any]]:
        """Return all pivot preset feedback, optionally filtered by connection prefix."""
        with self.get_session() as session:
            q = session.query(SuggestionCorrection).filter(
                SuggestionCorrection.correction_type == "pivot",
            )
            if connection_id is not None:
                q = q.filter(SuggestionCorrection.context_key.like(f"conn:{connection_id}|%"))
            rows = q.order_by(SuggestionCorrection.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def search_nl_feedback(self, question: str, min_similarity: float = 0.6, limit: int = 10) -> List[Dict[str, Any]]:
        """Search NL feedback for similar questions using Jaccard token overlap.

        Returns matches sorted by similarity (desc), including both liked and disliked.
        No LLM needed — pure token-set similarity.
        """
        with self.get_session() as session:
            rows = session.query(NLFeedback).order_by(
                NLFeedback.use_count.desc()
            ).limit(500).all()

            question_tokens = set(question.lower().split())
            if not question_tokens:
                return []

            results = []
            for r in rows:
                stored_tokens = set(r.question.lower().split())
                if not stored_tokens:
                    continue
                overlap = len(question_tokens & stored_tokens)
                union = len(question_tokens | stored_tokens)
                similarity = overlap / union if union > 0 else 0.0
                if similarity >= min_similarity:
                    d = r.to_dict()
                    d["_similarity"] = round(similarity, 3)
                    results.append(d)

            results.sort(key=lambda x: (-x["_similarity"], -x.get("use_count", 0)))
            return results[:limit]

    def delete_suggestion_correction(self, correction_id: int) -> bool:
        """Remove a single correction by ID (admin)."""
        with self.get_session() as session:
            row = session.query(SuggestionCorrection).filter(
                SuggestionCorrection.id == correction_id
            ).first()
            if row:
                session.delete(row)
                return True
            return False

    # ------------------------------------------------------------------ #
    #  UI Component Visibility                                             #
    # ------------------------------------------------------------------ #

    def get_ui_visibility(self) -> List[Dict[str, Any]]:
        """Return all stored visibility rows (only explicit overrides)."""
        with self.get_session() as session:
            rows = session.query(UIComponentVisibility).order_by(
                UIComponentVisibility.component_key,
                UIComponentVisibility.role,
            ).all()
            return [r.to_dict() for r in rows]

    def get_ui_visibility_for_role(self, role: str) -> Dict[str, bool]:
        """Return {component_key: enabled} map for a given role."""
        with self.get_session() as session:
            rows = session.query(UIComponentVisibility).filter(
                UIComponentVisibility.role == role
            ).all()
            return {r.component_key: r.enabled for r in rows}

    def set_ui_visibility(self, component_key: str, role: str, enabled: bool) -> Dict[str, Any]:
        """Upsert a single visibility rule."""
        with self.get_session() as session:
            row = session.query(UIComponentVisibility).filter(
                UIComponentVisibility.component_key == component_key,
                UIComponentVisibility.role == role,
            ).first()
            if row:
                row.enabled = enabled
            else:
                row = UIComponentVisibility(
                    component_key=component_key, role=role, enabled=enabled
                )
                session.add(row)
            session.flush()
            return row.to_dict()

    def bulk_set_ui_visibility(self, rules: List[Dict[str, Any]]) -> int:
        """Upsert many rules at once.  rules = [{component_key, role, enabled}]"""
        count = 0
        for r in rules:
            self.set_ui_visibility(r["component_key"], r["role"], bool(r["enabled"]))
            count += 1
        return count

    # ── Lineage Snapshots (Phase 52) ─────────────────────────────────────────

    def save_lineage_snapshot(self, execution_id: str, query_type: str,
                               query_id: int, snapshot_data: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            row = LineageSnapshot(
                execution_id=execution_id,
                query_type=query_type,
                query_id=query_id,
                snapshot_data=json.dumps(snapshot_data),
                captured_at=datetime.now(timezone.utc),
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_lineage_snapshots(self, query_type: str = None, query_id: int = None,
                               limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(LineageSnapshot)
            if query_type:
                q = q.filter(LineageSnapshot.query_type == query_type)
            if query_id is not None:
                q = q.filter(LineageSnapshot.query_id == query_id)
            rows = q.order_by(LineageSnapshot.captured_at.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_lineage_snapshot(self, snapshot_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(LineageSnapshot).filter(LineageSnapshot.id == snapshot_id).first()
            return row.to_dict() if row else None

    def delete_old_lineage_snapshots(self, older_than_days: int) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(days=older_than_days)
        with self.get_session() as session:
            deleted = session.query(LineageSnapshot).filter(
                LineageSnapshot.captured_at < cutoff
            ).delete()
            return deleted

    # ── Data Freshness (Phase 52) ─────────────────────────────────────────────

    def upsert_data_freshness(self, table_fqn: str, connection_id: Optional[int],
                               stale_threshold_hours: int = 24) -> Dict[str, Any]:
        """Record a table as observed now (freshness heartbeat)."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            q = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            )
            if connection_id is not None:
                q = q.filter(DataFreshness.connection_id == connection_id)
            row = q.first()
            if row:
                row.last_observed_at = now
                row.freshness_status = "fresh"
                if connection_id is not None:
                    row.connection_id = connection_id
            else:
                row = DataFreshness(
                    table_fqn=table_fqn,
                    connection_id=connection_id,
                    last_observed_at=now,
                    freshness_status="fresh",
                    stale_threshold_hours=stale_threshold_hours,
                )
                session.add(row)
            session.flush()
            return row.to_dict()

    def get_data_freshness(self, table_fqn: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DataFreshness)
            if table_fqn:
                q = q.filter(DataFreshness.table_fqn == table_fqn)
            return [r.to_dict() for r in q.order_by(DataFreshness.table_fqn).all()]

    def update_freshness_threshold(self, table_fqn: str, hours: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            ).first()
            if not row:
                return None
            row.stale_threshold_hours = hours
            session.flush()
            return row.to_dict()

    def mark_table_refreshed(self, table_fqn: str) -> Optional[Dict[str, Any]]:
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            ).first()
            if not row:
                return None
            row.last_refresh_at = now
            row.last_observed_at = now
            row.freshness_status = "fresh"
            session.flush()
            return row.to_dict()
