"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, Float, Index, UniqueConstraint, event as sa_event, text as sa_text
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any
import json
from contextlib import contextmanager
from pathlib import Path

Base = declarative_base()


class SavedQuery(Base):
    """Model for saved queries"""
    __tablename__ = "saved_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    query_config = Column(JSON, nullable=False)  # Stores QueryConfig as JSON
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)
    is_favorite = Column(Boolean, default=False)
    is_shared = Column(Boolean, default=False)
    execution_count = Column(Integer, default=0)
    last_executed_at = Column(DateTime, nullable=True)
    workspace_id = Column(Integer, nullable=True, index=True)
    folder = Column(String(200), nullable=True, index=True)   # Phase 65: folder path
    tags = Column(JSON, nullable=True)                         # Phase 65: ["tag1", "tag2"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "query_config": self.query_config,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
            "is_favorite": self.is_favorite or False,
            "is_shared": self.is_shared or False,
            "execution_count": self.execution_count,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id": self.workspace_id,
            "folder": self.folder,
            "tags": self.tags or [],
        }


class QueryExecution(Base):
    """Model for tracking query executions"""
    __tablename__ = "query_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, nullable=True)  # Reference to SavedQuery if applicable
    execution_id = Column(String(100), unique=True, nullable=False, index=True)
    query_config = Column(JSON, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    total_rows = Column(Integer, default=0)
    chunks_processed = Column(Integer, default=0)
    output_file = Column(String(500), nullable=True)
    file_size_bytes = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    executed_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "query_id": self.query_id,
            "execution_id": self.execution_id,
            "query_config": self.query_config,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "total_rows": self.total_rows,
            "chunks_processed": self.chunks_processed,
            "output_file": self.output_file,
            "file_size_bytes": self.file_size_bytes,
            "error_message": self.error_message,
            "executed_by": self.executed_by
        }


class AuditLog(Base):
    """Immutable audit trail — who did what, when, from where."""
    __tablename__ = "audit_log"

    id            = Column(Integer, primary_key=True, index=True)
    timestamp     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    username      = Column(String(100), nullable=False, index=True)
    action        = Column(String(100), nullable=False, index=True)  # execute_query, cancel_query, save_query…
    resource_type = Column(String(50),  nullable=True)               # query, execution, dashboard, connection
    resource_id   = Column(String(200), nullable=True)
    ip_address    = Column(String(50),  nullable=True)
    user_agent    = Column(String(500), nullable=True)
    details       = Column(JSON, nullable=True)                      # arbitrary extra context

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "timestamp":     self.timestamp.isoformat() if self.timestamp else None,
            "username":      self.username,
            "action":        self.action,
            "resource_type": self.resource_type,
            "resource_id":   self.resource_id,
            "ip_address":    self.ip_address,
            "details":       self.details,
        }


class DownloadFile(Base):
    """Model for tracking downloadable files"""
    __tablename__ = "download_files"
    
    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String(100), unique=True, nullable=False, index=True)
    execution_id = Column(String(100), nullable=True, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, default=0)
    status = Column(String(50), default="available")  # available, downloaded, expired, deleted
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at = Column(DateTime, nullable=True)
    download_count = Column(Integer, default=0)
    last_downloaded_at = Column(DateTime, nullable=True)
    created_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "execution_id": self.execution_id,
            "filename": self.filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "download_count": self.download_count,
            "last_downloaded_at": self.last_downloaded_at.isoformat() if self.last_downloaded_at else None,
            "created_by": self.created_by
        }


class SqlSavedQuery(Base):
    """Model for SQL queries executed against SQL connectors (Trino, Snowflake, Databricks)."""
    __tablename__ = "sql_saved_queries"

    id                     = Column(Integer,     primary_key=True, index=True)
    name                   = Column(String(255), nullable=False,   index=True)
    description            = Column(Text,        nullable=True)
    # Primary source
    primary_connection_id  = Column(Integer,     nullable=False)
    primary_sql            = Column(Text,        nullable=False)
    # Optional secondary source for cross-source joins
    secondary_connection_id = Column(Integer,    nullable=True)
    secondary_sql          = Column(Text,        nullable=True)
    # Join config: { how, left_on, right_on, suffixes }
    join_config            = Column(JSON,        nullable=True)
    # Metadata
    created_by             = Column(String(100), nullable=True)
    created_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active              = Column(Boolean,     default=True)
    is_shared              = Column(Boolean,     default=False)
    execution_count        = Column(Integer,     default=0)
    last_executed_at       = Column(DateTime,    nullable=True)
    workspace_id           = Column(Integer,     nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "primary_connection_id":   self.primary_connection_id,
            "primary_sql":             self.primary_sql,
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_sql":           self.secondary_sql,
            "join_config":             self.join_config,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "is_active":               self.is_active,
            "is_shared":               self.is_shared or False,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id":            self.workspace_id,
        }


class Connection(Base):
    """Model for data source connections"""
    __tablename__ = "connections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    connection_type = Column(String(50), nullable=False)
    config = Column(JSON, nullable=False)   # sensitive fields stored encrypted
    is_active = Column(Boolean, default=True)
    is_shared = Column(Boolean, default=False)  # shared with all users
    created_by = Column(String(100), nullable=True)
    last_tested_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(50), nullable=True)  # 'success' or 'failed'
    last_test_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary (config may contain encrypted values)."""
        return {
            "id": self.id,
            "name": self.name,
            "connection_type": self.connection_type,
            "config": self.config,
            "is_active": self.is_active,
            "is_shared": self.is_shared or False,
            "created_by": self.created_by,
            "last_tested_at": self.last_tested_at.isoformat() if self.last_tested_at else None,
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id": self.workspace_id,
        }


class Report(Base):
    """Named parametric report — wraps a saved query or SQL query with a parameter schema."""
    __tablename__ = "reports"

    id                 = Column(Integer,     primary_key=True, index=True)
    name               = Column(String(255), nullable=False,   index=True)
    description        = Column(Text,        nullable=True)

    # Exactly one source is set
    saved_query_id     = Column(Integer, nullable=True)        # → SavedQuery (parquet)
    sql_saved_query_id = Column(Integer, nullable=True)        # → SqlSavedQuery

    # Parameter schema: [{ name, label, type, required, default_value, description }]
    # type: string | number | date | boolean | select
    # If type == select, include options: ["val1", "val2", ...]
    parameters         = Column(JSON, nullable=False, default=list)

    # Optional SQL override (replaces source query's SQL at execution time)
    sql_override       = Column(Text, nullable=True)

    is_active          = Column(Boolean,     default=True)
    is_public          = Column(Boolean,     default=True)
    created_by         = Column(String(100), nullable=True)
    created_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    execution_count    = Column(Integer,     default=0)
    last_executed_at   = Column(DateTime,    nullable=True)

    # Enterprise features
    cache_ttl_minutes      = Column(Integer,  default=0)          # 0 = no caching
    schedule_config        = Column(JSON,     nullable=True)      # { cron, recipients, format, enabled }

    # Phase 24A — optional direct connection override (SQL reports only)
    connection_override_id = Column(Integer,  nullable=True)      # → Connection.id; NULL = use query's default
    workspace_id           = Column(Integer,  nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "saved_query_id":          self.saved_query_id,
            "sql_saved_query_id":      self.sql_saved_query_id,
            "parameters":              self.parameters or [],
            "sql_override":            self.sql_override,
            "is_active":               self.is_active,
            "is_public":               self.is_public,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "cache_ttl_minutes":       self.cache_ttl_minutes or 0,
            "schedule_config":         self.schedule_config,
            "connection_override_id":  self.connection_override_id,
            "workspace_id":            self.workspace_id,
        }


class Schedule(Base):
    """Scheduled automatic query/report execution → downloads directory."""
    __tablename__ = "schedules"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    is_active       = Column(Boolean,     default=True)
    is_shared       = Column(Boolean,     default=False)

    # Source type: "saved_query" | "sql_query" | "report"
    source_type     = Column(String(50),  nullable=False)
    source_id       = Column(Integer,     nullable=False)

    # Parameter values to pass to the source at run time
    param_values    = Column(JSON, nullable=True)

    # Trigger config:
    #   { "type": "cron",     "cron_expr": "0 8 * * 1-5" }
    #   { "type": "interval", "minutes": 60 }
    trigger_config  = Column(JSON, nullable=False)

    # Output filename template — {date} is replaced with YYYYMMDD_HHMMSS
    output_filename_template = Column(String(255), nullable=True)

    # APScheduler job ID (stored so we can pause/remove specific jobs)
    apscheduler_job_id = Column(String(100), nullable=True, unique=True)

    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Run tracking
    last_run_at     = Column(DateTime, nullable=True)
    last_run_status = Column(String(50), nullable=True)   # success | failed
    last_run_file_id= Column(String(100), nullable=True)
    last_error      = Column(Text, nullable=True)
    run_count       = Column(Integer, default=0)
    next_run_at     = Column(DateTime, nullable=True)

    # Email notifications — comma-separated list of addresses to notify on completion/failure
    notify_emails   = Column(Text, nullable=True)   # e.g. "alice@corp.com,bob@corp.com"
    # Webhook URL for Slack/Teams/generic HTTP POST notifications
    notify_webhook  = Column(Text, nullable=True)
    # Phase 60: Auto-evaluate alert rules after scheduled execution
    auto_evaluate_alerts = Column(Boolean, default=False, nullable=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "description":      self.description,
            "is_active":        self.is_active,
            "is_shared":        self.is_shared or False,
            "source_type":      self.source_type,
            "source_id":        self.source_id,
            "param_values":     self.param_values,
            "trigger_config":   self.trigger_config,
            "output_filename_template": self.output_filename_template,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
            "last_run_at":      self.last_run_at.isoformat() if self.last_run_at else None,
            "last_run_status":  self.last_run_status,
            "last_run_file_id": self.last_run_file_id,
            "last_error":       self.last_error,
            "run_count":        self.run_count,
            "next_run_at":      self.next_run_at.isoformat() if self.next_run_at else None,
            "notify_emails":    self.notify_emails,
            "notify_webhook":   self.notify_webhook,
            "auto_evaluate_alerts": self.auto_evaluate_alerts or False,
        }


# ── New enterprise models ─────────────────────────────────────────────────────

class QueryCacheEntry(Base):
    """Disk-backed parquet cache keyed by sha256 of canonical query_config JSON."""
    __tablename__ = "query_result_cache"

    cache_key       = Column(String(64), primary_key=True)
    file_path       = Column(String(500), nullable=False)
    row_count       = Column(Integer, default=0)
    file_size_bytes = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at      = Column(DateTime, nullable=True)
    query_config    = Column(JSON, nullable=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    hit_count       = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cache_key":       self.cache_key,
            "file_path":       self.file_path,
            "row_count":       self.row_count,
            "file_size_bytes": self.file_size_bytes,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "expires_at":      self.expires_at.isoformat() if self.expires_at else None,
            "connection_id":   self.connection_id,
            "hit_count":       self.hit_count or 0,
            "query_config":    self.query_config,
        }


class PartitionCache(Base):
    """Persistent cache for Iceberg partition metadata — survives restarts."""
    __tablename__ = "partition_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    s3_prefix       = Column(String(512), nullable=False, default="")
    scan_type       = Column(String(10), default="fast")   # "fast" or "full"
    partition_data  = Column(JSON, nullable=False)          # full response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_partition_cache_lookup', 'connection_id', 'table_name', 's3_prefix', 'scan_type', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "s3_prefix":      self.s3_prefix or "",
            "scan_type":      self.scan_type,
            "partition_data": self.partition_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergFileCache(Base):
    """Persistent L2 cache for Iceberg data-file lists — avoids re-scanning S3 manifests."""
    __tablename__ = "iceberg_file_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    filters_hash    = Column(String(512), nullable=False, default="")
    file_list       = Column(JSON, nullable=False)          # list of S3 file paths
    file_count      = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_file_cache_lookup', 'connection_id', 'table_name', 'filters_hash', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "filters_hash":   self.filters_hash,
            "file_list":      self.file_list,
            "file_count":     self.file_count,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class SchemaCache(Base):
    """Persistent cache for registered table schemas — avoids repeated S3 metadata reads."""
    __tablename__ = "schema_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    table_format    = Column(String(20), default="iceberg")     # iceberg, parquet, csv
    schema_data     = Column(JSON, nullable=False)              # full schema response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_schema_cache_lookup', 'connection_id', 'table_name', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "table_format":   self.table_format,
            "schema_data":    self.schema_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class QueryVersion(Base):
    """Immutable snapshot of a SavedQuery before each update."""
    __tablename__ = "query_versions"

    id             = Column(Integer, primary_key=True, index=True)
    query_id       = Column(Integer, nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    name           = Column(String(255), nullable=True)
    description    = Column(Text, nullable=True)
    query_config   = Column(JSON, nullable=True)
    changed_by     = Column(String(100), nullable=True)
    changed_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    change_note    = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "query_id":       self.query_id,
            "version_number": self.version_number,
            "name":           self.name,
            "description":    self.description,
            "query_config":   self.query_config,
            "changed_by":     self.changed_by,
            "changed_at":     self.changed_at.isoformat() if self.changed_at else None,
            "change_note":    self.change_note,
        }


class QueryShare(Base):
    """Share token for a saved query — allows public access via /api/shared/{token}."""
    __tablename__ = "query_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    query_id     = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "query_id":     self.query_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class DashboardShare(Base):
    """Share token for a dashboard — allows public access via /api/shared-dashboard/{token}."""
    __tablename__ = "dashboard_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "dashboard_id": self.dashboard_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class BusinessReportShareToken(Base):
    """Share token for a business report — public view link (Phase 58)."""
    __tablename__ = "business_report_share_tokens"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    report_id    = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "report_id":    self.report_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class ReportEmbedToken(Base):
    """Embed token for a report — allows iframe embedding in external portals without login (27/58)."""
    __tablename__ = "report_embed_tokens"

    id             = Column(Integer, primary_key=True, index=True)
    token          = Column(String(64), unique=True, nullable=False, index=True)
    report_id      = Column(Integer, nullable=False, index=True)
    report_type    = Column(String(20), nullable=False, default="parametric")  # "parametric" | "business"
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at     = Column(DateTime, nullable=True)
    is_active      = Column(Boolean, default=True)
    access_count   = Column(Integer, default=0)
    allowed_params = Column(Text, nullable=True)  # JSON string

    def to_dict(self) -> Dict[str, Any]:
        import json as _json
        return {
            "id":             self.id,
            "token":          self.token,
            "report_id":      self.report_id,
            "report_type":    self.report_type or "parametric",
            "created_by":     self.created_by,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "expires_at":     self.expires_at.isoformat() if self.expires_at else None,
            "is_active":      self.is_active,
            "access_count":   self.access_count,
            "allowed_params": _json.loads(self.allowed_params) if self.allowed_params else None,
        }


class Dashboard(Base):
    """Named canvas that holds multiple report widgets."""
    __tablename__ = "dashboards"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active   = Column(Boolean, default=True)
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "is_active":   self.is_active,
            "workspace_id": self.workspace_id,
        }


class DashboardWidget(Base):
    """Single widget on a dashboard canvas — references a saved query / SQL query / report."""
    __tablename__ = "dashboard_widgets"

    id           = Column(Integer, primary_key=True, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    # "saved_query" | "sql_query" | "report"
    widget_type  = Column(String(50), nullable=False)
    source_id    = Column(Integer, nullable=False)
    title        = Column(String(255), nullable=True)
    # react-grid-layout position: {x, y, w, h}
    layout       = Column(JSON, nullable=True)
    # "grid" | "bar" | "line" | "area" | "pie" | "scatter" | "metric"
    chart_type   = Column(String(50), default="grid")
    # chart config: axis fields, colors, aggregation
    chart_config = Column(JSON, nullable=True)
    # parameter overrides for report widgets
    param_values = Column(JSON, nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "dashboard_id": self.dashboard_id,
            "widget_type":  self.widget_type,
            "source_id":    self.source_id,
            "title":        self.title,
            "layout":       self.layout or {"x": 0, "y": 0, "w": 6, "h": 4},
            "chart_type":   self.chart_type or "grid",
            "chart_config": self.chart_config or {},
            "param_values": self.param_values or {},
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class MaterializedView(Base):
    """Pre-downloaded S3 data for instant local DuckDB queries."""
    __tablename__ = "materialized_views"

    id                    = Column(Integer, primary_key=True, index=True)
    name                  = Column(String(255), nullable=False, unique=True, index=True)
    description           = Column(Text, nullable=True)
    connection_id         = Column(Integer, nullable=False)
    table_name            = Column(String(255), nullable=False)
    table_format          = Column(String(50), default="parquet")      # iceberg/parquet/csv
    partition_filter      = Column(JSON, nullable=True)                # {"date_col":"dt","from":"2025-01-01","to":"2025-12-31"}
    query_filter          = Column(Text, nullable=True)                # optional WHERE clause

    # Refresh state
    status                = Column(String(50), default="pending")      # pending/refreshing/ready/failed
    last_refresh_at       = Column(DateTime, nullable=True)
    last_refresh_duration = Column(Float, nullable=True)               # seconds
    row_count             = Column(Integer, default=0)
    file_count            = Column(Integer, default=0)
    size_bytes            = Column(Integer, default=0)
    last_error            = Column(Text, nullable=True)

    # Schedule (optional auto-refresh)
    schedule_config       = Column(JSON, nullable=True)                # {"type":"cron","cron_expr":"..."} or {"type":"interval","hours":N}
    apscheduler_job_id    = Column(String(100), nullable=True, unique=True)
    next_refresh_at       = Column(DateTime, nullable=True)

    # Metadata
    created_by            = Column(String(100), nullable=True)
    created_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active             = Column(Boolean, default=True)
    workspace_id          = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "name":                  self.name,
            "description":           self.description,
            "connection_id":         self.connection_id,
            "table_name":            self.table_name,
            "table_format":          self.table_format,
            "partition_filter":      self.partition_filter,
            "query_filter":          self.query_filter,
            "status":                self.status,
            "last_refresh_at":       self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "last_refresh_duration": self.last_refresh_duration,
            "row_count":             self.row_count,
            "file_count":            self.file_count,
            "size_bytes":            self.size_bytes,
            "last_error":            self.last_error,
            "schedule_config":       self.schedule_config,
            "apscheduler_job_id":    self.apscheduler_job_id,
            "next_refresh_at":       self.next_refresh_at.isoformat() if self.next_refresh_at else None,
            "created_by":            self.created_by,
            "created_at":            self.created_at.isoformat() if self.created_at else None,
            "updated_at":            self.updated_at.isoformat() if self.updated_at else None,
            "is_active":             self.is_active,
            "workspace_id":          self.workspace_id,
        }


class LocalTable(Base):
    """User-created local tables from downloads or file uploads, stored as parquet."""
    __tablename__ = "local_tables"

    id                = Column(Integer, primary_key=True, index=True)
    name              = Column(String(255), nullable=False, unique=True, index=True)
    description       = Column(Text, nullable=True)
    source_type       = Column(String(50), nullable=False)       # "download_promote" | "file_upload"
    source_file_id    = Column(String(100), nullable=True)       # DownloadFile.file_id if promoted
    original_filename = Column(String(500), nullable=True)

    # Storage
    storage_path      = Column(String(500), nullable=False)      # data/local_tables/{id}
    file_format       = Column(String(50), default="parquet")
    row_count         = Column(Integer, default=0)
    file_count        = Column(Integer, default=0)
    size_bytes        = Column(Integer, default=0)
    schema_json       = Column(JSON, nullable=True)              # cached column names/types

    # Visibility & lifecycle
    visibility        = Column(String(20), default="public")     # "public" | "private"
    is_active         = Column(Boolean, default=True)
    last_accessed_at  = Column(DateTime, nullable=True)
    auto_discard_days = Column(Integer, default=10)              # 0 = never discard

    # Status
    status            = Column(String(50), default="pending")    # pending/processing/ready/failed
    last_error        = Column(Text, nullable=True)

    # Metadata
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id      = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "name":              self.name,
            "description":       self.description,
            "source_type":       self.source_type,
            "source_file_id":    self.source_file_id,
            "original_filename": self.original_filename,
            "storage_path":      self.storage_path,
            "file_format":       self.file_format,
            "row_count":         self.row_count,
            "file_count":        self.file_count,
            "size_bytes":        self.size_bytes,
            "schema_json":       self.schema_json,
            "visibility":        self.visibility,
            "is_active":         self.is_active,
            "last_accessed_at":  self.last_accessed_at.isoformat() if self.last_accessed_at else None,
            "auto_discard_days": self.auto_discard_days,
            "status":            self.status,
            "last_error":        self.last_error,
            "created_by":        self.created_by,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id":      self.workspace_id,
        }


class PendingNotification(Base):
    """Cross-process notification queue.

    The scheduler worker writes notifications here (scheduled job started/completed/failed).
    The FastAPI process polls undelivered rows and broadcasts them via WebSocket,
    then marks them as delivered.  Used when scheduler.mode = "external".
    """
    __tablename__ = "pending_notifications"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    payload      = Column(JSON, nullable=False)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered    = Column(Boolean, default=False, index=True)
    delivered_at = Column(DateTime, nullable=True)


class TaskQueue(Base):
    """Cross-process task queue for executor service.

    FastAPI enqueues tasks here (status='pending').
    Executor worker claims them (status='claimed'), runs them,
    and updates status to 'completed' or 'failed'.
    FastAPI polls for completed tasks and broadcasts WS notifications.
    Only used when executor.mode = "external".
    """
    __tablename__ = "task_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False, index=True)
    status          = Column(String(20), default="pending", nullable=False, index=True)
    priority        = Column(Integer, default=5)
    payload         = Column(JSON, nullable=False)
    result          = Column(JSON, nullable=True)
    error_message   = Column(Text, nullable=True)
    progress_pct    = Column(Integer, default=0)
    progress_detail = Column(Text, nullable=True)
    execution_id    = Column(String(100), nullable=True, index=True)
    claimed_by      = Column(String(100), nullable=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    claimed_at      = Column(DateTime, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)
    timeout_seconds = Column(Integer, default=1800)
    retry_count      = Column(Integer, default=0)
    max_retries      = Column(Integer, default=3)
    next_retry_at    = Column(DateTime, nullable=True, index=True)  # for backoff scheduling
    cancel_requested = Column(Integer, default=0)  # 0=no, 1=cancel requested

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "task_id": self.task_id,
            "task_type": self.task_type, "status": self.status,
            "priority": self.priority,
            "payload": self.payload, "result": self.result,
            "error_message": self.error_message,
            "progress_pct": self.progress_pct,
            "progress_detail": self.progress_detail,
            "execution_id": self.execution_id,
            "claimed_by": self.claimed_by,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "timeout_seconds": self.timeout_seconds,
            "retry_count": self.retry_count, "max_retries": self.max_retries,
            "next_retry_at": self.next_retry_at.isoformat() if self.next_retry_at else None,
            "cancel_requested": bool(self.cancel_requested),
        }


class DeadLetterQueue(Base):
    """Permanently failed tasks that exhausted all retries (Phase 22C)."""
    __tablename__ = "dead_letter_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False)
    payload         = Column(JSON, nullable=False)
    execution_id    = Column(String(100), nullable=True, index=True)
    created_by      = Column(String(100), nullable=True)
    original_error  = Column(Text, nullable=True)
    retry_count     = Column(Integer, default=0)
    first_failed_at = Column(DateTime, nullable=True)
    dead_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    resolved        = Column(Integer, default=0)   # 0=open, 1=resolved/requeued
    resolved_at     = Column(DateTime, nullable=True)
    resolved_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "task_id": self.task_id,
            "task_type": self.task_type,
            "payload": self.payload,
            "execution_id": self.execution_id,
            "created_by": self.created_by,
            "original_error": self.original_error,
            "retry_count": self.retry_count,
            "first_failed_at": self.first_failed_at.isoformat() if self.first_failed_at else None,
            "dead_at": self.dead_at.isoformat() if self.dead_at else None,
            "resolved": bool(self.resolved),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }


class TableFavorite(Base):
    """User's favorited tables (any type: registered, MV, local, file)."""
    __tablename__ = "table_favorites"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_path    = Column(String(500), nullable=False)
    table_name    = Column(String(255), nullable=False)
    table_type    = Column(String(50), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "username": self.username,
            "connection_id": self.connection_id,
            "table_path": self.table_path, "table_name": self.table_name,
            "table_type": self.table_type,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class NotificationLog(Base):
    """Persistent notification history with delivery tracking."""
    __tablename__ = "notification_log"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    event_type     = Column(String(50), nullable=False, index=True)    # execution_completed, schedule_failed, etc.
    channel        = Column(String(20), nullable=False, index=True)    # websocket, email, webhook
    recipient      = Column(String(200), nullable=False, index=True)   # username, email addr, or webhook URL
    status         = Column(String(20), default="pending", index=True) # pending, sent, failed, delivered
    title          = Column(String(300), nullable=True)
    message        = Column(Text, nullable=True)
    payload        = Column(JSON, nullable=True)
    error_message  = Column(Text, nullable=True)
    attempt_count  = Column(Integer, default=0)
    max_attempts   = Column(Integer, default=3)
    execution_id   = Column(String(100), nullable=True, index=True)
    schedule_id    = Column(Integer, nullable=True)
    is_read        = Column(Integer, default=0)   # 0=unread, 1=read
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at   = Column(DateTime, nullable=True)
    read_at        = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "event_type": self.event_type,
            "channel": self.channel,
            "recipient": self.recipient,
            "status": self.status,
            "title": self.title,
            "message": self.message,
            "payload": self.payload,
            "error_message": self.error_message,
            "attempt_count": self.attempt_count,
            "execution_id": self.execution_id,
            "schedule_id": self.schedule_id,
            "is_read": bool(self.is_read),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
            "read_at": self.read_at.isoformat() if self.read_at else None,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 23: Enterprise Reporting Models (additive — existing models unchanged)
# ═══════════════════════════════════════════════════════════════════════════════


class ReportFolder(Base):
    """Folder for organizing reports into a hierarchy (23A)."""
    __tablename__ = "report_folders"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    parent_id   = Column(Integer, nullable=True, index=True)   # None = root folder
    icon        = Column(String(50),  nullable=True, default="folder")
    color       = Column(String(20),  nullable=True, default="#1976d2")
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "parent_id": self.parent_id, "icon": self.icon or "folder",
            "color": self.color or "#1976d2", "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportFolderAssignment(Base):
    """Maps a report to a folder. report_type discriminates parametric vs business (23A/58)."""
    __tablename__ = "report_folder_assignments"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="parametric")  # "parametric" | "business"
    folder_id   = Column(Integer, nullable=False, index=True)
    assigned_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("report_id", "report_type", name="uq_folder_assign_report"),
    )


class ReportTag(Base):
    """Tag label for reports (23A)."""
    __tablename__ = "report_tags"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    name       = Column(String(100), nullable=False, unique=True, index=True)
    color      = Column(String(20),  nullable=True, default="#666666")
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "name": self.name, "color": self.color or "#666666",
                "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None}


class ReportTagAssignment(Base):
    """Many-to-many: report ↔ tag (23A/58)."""
    __tablename__ = "report_tag_assignments"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="parametric")
    tag_id      = Column(Integer, nullable=False, index=True)


class ReportFavorite(Base):
    """User-level report favorite (23A/58)."""
    __tablename__ = "report_favorites"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="parametric")
    username    = Column(String(100), nullable=False, index=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class ReportView(Base):
    """Recently-viewed tracker per user (23A/58). Kept at last N entries per user."""
    __tablename__ = "report_views"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="parametric")
    username    = Column(String(100), nullable=False, index=True)
    viewed_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)


class RLSPolicy(Base):
    """Row-Level Security policy — injected as extra WHERE at execution time (23G)."""
    __tablename__ = "rls_policies"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    report_id      = Column(Integer, nullable=False, index=True)
    column_name    = Column(String(255), nullable=False)   # DB/Parquet column to filter
    # operator: = | != | IN | NOT IN | LIKE | >  < (for numeric ranges)
    operator       = Column(String(10),  nullable=False, default="=")
    # value_template: literal "sales" | token "{username}" | "{department}"
    value_template = Column(String(500), nullable=False)
    is_enabled     = Column(Boolean, default=True)
    description    = Column(String(500), nullable=True)
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "column_name": self.column_name, "operator": self.operator,
            "value_template": self.value_template, "is_enabled": self.is_enabled,
            "description": self.description, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportBookmark(Base):
    """Named saved parameter set for a report, per user (23B)."""
    __tablename__ = "report_bookmarks"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    report_id    = Column(Integer, nullable=False, index=True)
    username     = Column(String(100), nullable=False, index=True)
    name         = Column(String(255), nullable=False)
    param_values = Column(JSON, nullable=False, default=dict)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "username": self.username,
            "name": self.name, "param_values": self.param_values or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportPDFConfig(Base):
    """PDF export layout configuration per report (23D)."""
    __tablename__ = "report_pdf_configs"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, unique=True, index=True)
    orientation   = Column(String(20), default="landscape")   # landscape | portrait
    paper_size    = Column(String(10), default="A4")          # A4 | Letter | Legal
    include_cover = Column(Boolean, default=False)
    include_header = Column(Boolean, default=True)
    include_footer = Column(Boolean, default=True)
    logo_url      = Column(String(500), nullable=True)
    header_text   = Column(String(500), nullable=True)
    footer_text   = Column(String(500), nullable=True,
                           default="Generated by QueryStudio | Page {page} of {total}")
    font_size     = Column(Integer, default=11)
    max_rows      = Column(Integer, default=10000)
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                           onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "report_id": self.report_id, "orientation": self.orientation,
            "paper_size": self.paper_size, "include_cover": self.include_cover,
            "include_header": self.include_header, "include_footer": self.include_footer,
            "logo_url": self.logo_url, "header_text": self.header_text,
            "footer_text": self.footer_text, "font_size": self.font_size,
            "max_rows": self.max_rows,
        }


class BurstJob(Base):
    """Report burst job — distributes one report run per dimension value (23E)."""
    __tablename__ = "burst_jobs"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    burst_column      = Column(String(255), nullable=False)      # column to split on
    base_params       = Column(JSON, nullable=True)              # shared params for all tasks
    output_format     = Column(String(10), default="pdf")        # pdf | excel | csv
    delivery_type     = Column(String(10), default="email")      # email | s3
    s3_prefix         = Column(String(500), nullable=True)       # "reports/{value}/"
    recipient_map     = Column(JSON, nullable=True)              # {"APAC": "apac@co.com", ...}
    default_recipient = Column(String(500), nullable=True)
    status            = Column(String(20), default="pending", index=True)
    total_tasks       = Column(Integer, default=0)
    done_tasks        = Column(Integer, default=0)
    failed_tasks      = Column(Integer, default=0)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    started_at        = Column(DateTime, nullable=True)
    completed_at      = Column(DateTime, nullable=True)
    error_message     = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "burst_column": self.burst_column, "base_params": self.base_params,
            "output_format": self.output_format, "delivery_type": self.delivery_type,
            "s3_prefix": self.s3_prefix, "recipient_map": self.recipient_map,
            "default_recipient": self.default_recipient, "status": self.status,
            "total_tasks": self.total_tasks, "done_tasks": self.done_tasks,
            "failed_tasks": self.failed_tasks, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error_message": self.error_message,
        }


class BurstTask(Base):
    """One task in a burst job — one row per distinct dimension value (23E)."""
    __tablename__ = "burst_tasks"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    burst_job_id    = Column(Integer, nullable=False, index=True)
    dimension_value = Column(String(500), nullable=False)   # e.g. "APAC", "Finance"
    recipient       = Column(String(500), nullable=True)    # email or S3 path
    output_file     = Column(String(500), nullable=True)
    status          = Column(String(20), default="pending", index=True)
    execution_id    = Column(String(100), nullable=True)
    error_message   = Column(Text, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "burst_job_id": self.burst_job_id,
            "dimension_value": self.dimension_value, "recipient": self.recipient,
            "output_file": self.output_file, "status": self.status,
            "execution_id": self.execution_id, "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class AlertRule(Base):
    """Threshold alert rule on a report metric (23F)."""
    __tablename__ = "alert_rules"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    name              = Column(String(255), nullable=False)
    column_name       = Column(String(255), nullable=False)
    aggregation       = Column(String(20), default="last")    # last | sum | avg | max | min | count
    operator          = Column(String(5),  nullable=False)    # > | < | >= | <= | = | !=
    threshold_value   = Column(Float, nullable=False)
    channels          = Column(JSON, nullable=False, default=list)  # ["email","slack"]
    recipients        = Column(Text, nullable=True)           # comma-separated emails
    slack_webhook     = Column(String(500), nullable=True)
    cooldown_minutes  = Column(Integer, default=60)
    is_enabled        = Column(Boolean, default=True)
    last_triggered_at = Column(DateTime, nullable=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "name": self.name,
            "column_name": self.column_name, "aggregation": self.aggregation,
            "operator": self.operator, "threshold_value": self.threshold_value,
            "channels": self.channels or [], "recipients": self.recipients,
            "slack_webhook": self.slack_webhook, "cooldown_minutes": self.cooldown_minutes,
            "is_enabled": self.is_enabled,
            "last_triggered_at": self.last_triggered_at.isoformat() if self.last_triggered_at else None,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AlertHistory(Base):
    """Record of each alert trigger event (23F)."""
    __tablename__ = "alert_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    rule_id         = Column(Integer, nullable=False, index=True)
    triggered_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    actual_value    = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    channel         = Column(String(20), nullable=True)
    sent_to         = Column(String(500), nullable=True)
    was_suppressed  = Column(Boolean, default=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "rule_id": self.rule_id,
            "triggered_at": self.triggered_at.isoformat() if self.triggered_at else None,
            "actual_value": self.actual_value, "threshold_value": self.threshold_value,
            "channel": self.channel, "sent_to": self.sent_to,
            "was_suppressed": self.was_suppressed,
        }


class ConditionalFormatRule(Base):
    """Cell/row formatting rule per column on a report (23C)."""
    __tablename__ = "conditional_format_rules"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    report_id       = Column(Integer, nullable=False, index=True)
    column_name     = Column(String(255), nullable=False)
    rule_order      = Column(Integer, default=0)          # ascending priority
    # condition_type: value_range | equals | contains | not_null | is_null | top_n | bottom_n
    condition_type  = Column(String(30), nullable=False)
    condition_value = Column(JSON, nullable=True)         # {"min":0,"max":50} / {"text":"err"}
    bg_color        = Column(String(20), nullable=True)   # "#ff4444"
    text_color      = Column(String(20), nullable=True)   # "#ffffff"
    # icon: none | arrow_up | arrow_down | check | warning | danger | info
    icon            = Column(String(30), nullable=True, default="none")
    bold            = Column(Boolean, default=False)
    is_enabled      = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "column_name": self.column_name,
            "rule_order": self.rule_order, "condition_type": self.condition_type,
            "condition_value": self.condition_value, "bg_color": self.bg_color,
            "text_color": self.text_color, "icon": self.icon or "none",
            "bold": self.bold, "is_enabled": self.is_enabled,
        }


class CloudDeliveryConfig(Base):
    """Cloud storage delivery config per schedule (23H)."""
    __tablename__ = "cloud_delivery_configs"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=False, unique=True, index=True)
    provider        = Column(String(20), nullable=False)          # s3 | azure | gcs
    bucket          = Column(String(255), nullable=True)
    prefix_template = Column(String(500), nullable=True)          # "reports/{report_name}/{date}/"
    formats         = Column(JSON, nullable=False, default=list)  # ["pdf","excel","csv"]
    zip_bundle      = Column(Boolean, default=False)
    connection_id   = Column(Integer, nullable=True)              # reuse existing S3 connection creds
    is_enabled      = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id, "provider": self.provider,
            "bucket": self.bucket, "prefix_template": self.prefix_template,
            "formats": self.formats or [], "zip_bundle": self.zip_bundle,
            "connection_id": self.connection_id, "is_enabled": self.is_enabled,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DeliveryHistory(Base):
    """Log of every report delivery attempt (23H)."""
    __tablename__ = "delivery_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=True, index=True)
    burst_task_id   = Column(Integer, nullable=True, index=True)
    execution_id    = Column(String(100), nullable=True)
    delivery_type   = Column(String(20), nullable=False)   # email | s3 | azure | gcs | slack
    destination     = Column(String(500), nullable=True)
    file_format     = Column(String(10), nullable=True)    # pdf | excel | csv | zip
    file_size_bytes = Column(Integer, nullable=True)
    status          = Column(String(20), default="pending", index=True)
    error_message   = Column(Text, nullable=True)
    attempted_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id,
            "burst_task_id": self.burst_task_id, "execution_id": self.execution_id,
            "delivery_type": self.delivery_type, "destination": self.destination,
            "file_format": self.file_format, "file_size_bytes": self.file_size_bytes,
            "status": self.status, "error_message": self.error_message,
            "attempted_at": self.attempted_at.isoformat() if self.attempted_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
        }


class ConnectionProfile(Base):
    """Named environment profile for connection substitution (Phase 24B).

    One profile is active at a time. When active, its mappings redirect any
    matching connection to its target equivalent (e.g. dev_snowflake → prod_snowflake).
    """
    __tablename__ = "connection_profiles"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=False)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class ConnectionProfileMapping(Base):
    """One source→target connection substitution rule within a ConnectionProfile (Phase 24B)."""
    __tablename__ = "connection_profile_mappings"

    id                   = Column(Integer, primary_key=True, autoincrement=True)
    profile_id           = Column(Integer, nullable=False, index=True)  # → ConnectionProfile.id
    source_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. dev)
    target_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. prod)
    description          = Column(String(500), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                   self.id,
            "profile_id":           self.profile_id,
            "source_connection_id": self.source_connection_id,
            "target_connection_id": self.target_connection_id,
            "description":          self.description,
        }


class Workspace(Base):
    """Named workspace / project for isolating team assets (Phase 25)."""
    __tablename__ = "workspaces"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    slug        = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "slug":        self.slug,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class WorkspaceMember(Base):
    """Member of a workspace with a role (Phase 25)."""
    __tablename__ = "workspace_members"

    id           = Column(Integer,     primary_key=True, autoincrement=True)
    workspace_id = Column(Integer,     nullable=False, index=True)  # → Workspace.id
    username     = Column(String(100), nullable=False, index=True)
    role         = Column(String(20),  nullable=False, default="member")  # owner/admin/member
    added_by     = Column(String(100), nullable=True)
    added_at     = Column(DateTime,    default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "workspace_id": self.workspace_id,
            "username":     self.username,
            "role":         self.role,
            "added_by":     self.added_by,
            "added_at":     self.added_at.isoformat() if self.added_at else None,
        }


class ScheduleRunStats(Base):
    """Per-run statistics for scheduled report anomaly detection (Phase 38)."""
    __tablename__ = "schedule_run_stats"

    id                = Column(Integer, primary_key=True, index=True)
    schedule_id       = Column(Integer, nullable=False, index=True)
    run_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    row_count         = Column(Integer, default=0)
    execution_seconds = Column(Float, default=0.0)
    file_size_bytes   = Column(Integer, default=0)
    anomaly_type      = Column(String(50), nullable=True)    # null = normal
    anomaly_details   = Column(JSON, nullable=True)          # z_score, message, etc.

    def to_dict(self):
        return {
            "id": self.id,
            "schedule_id": self.schedule_id,
            "run_at": self.run_at.isoformat() if self.run_at else None,
            "row_count": self.row_count,
            "execution_seconds": self.execution_seconds,
            "file_size_bytes": self.file_size_bytes,
            "anomaly_type": self.anomaly_type,
            "anomaly_details": self.anomaly_details,
        }


class ExecutionCheckpoint(Base):
    """Checkpoint for in-progress query executions — survives server restarts (Phase 41)."""
    __tablename__ = "execution_checkpoints"
    execution_id = Column(String(36), primary_key=True)
    state = Column(String(20), nullable=False)  # "intent" | "running"
    query_config = Column(JSON, nullable=True)
    executed_by = Column(String(200), nullable=True)
    query_id = Column(Integer, nullable=True)
    timestamp = Column(Float, nullable=False)


class TableLineageEntry(Base):
    """Physical table referenced by a query — extracted via SQL parsing (Phase 49)."""
    __tablename__ = "table_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)  # "sql_query" | "parquet_query" | "report"
    query_id = Column(Integer, nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_catalog = Column(String(255), nullable=True)
    table_schema = Column(String(255), nullable=True)
    table_name = Column(String(255), nullable=False, index=True)
    access_type = Column(String(10), default="read")  # "read" | "write"
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    extraction_method = Column(String(20), default="sqlglot")  # "sqlglot" | "regex_fallback"

    __table_args__ = (
        Index('ix_table_lineage_query', 'query_type', 'query_id'),
        Index('ix_table_lineage_table', 'table_catalog', 'table_schema', 'table_name'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "connection_id": self.connection_id,
            "table_catalog": self.table_catalog,
            "table_schema": self.table_schema,
            "table_name": self.table_name,
            "access_type": self.access_type,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
            "extraction_method": self.extraction_method,
        }


class LineageSnapshot(Base):
    """Snapshot of lineage at query execution time (Phase 52)."""
    __tablename__ = "lineage_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String(36), nullable=False, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query" | "parquet_query"
    query_id = Column(Integer, nullable=False, index=True)
    snapshot_data = Column(Text, nullable=False)   # JSON blob of {tables, columns}
    captured_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    __table_args__ = (
        Index('ix_lineage_snapshot_query', 'query_type', 'query_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.snapshot_data) if self.snapshot_data else {}
        except Exception:
            data = {}
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "snapshot_data": data,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
        }


class DataFreshness(Base):
    """Per-table data freshness tracking (Phase 52)."""
    __tablename__ = "data_freshness"

    id = Column(Integer, primary_key=True, index=True)
    table_fqn = Column(String(512), nullable=False, index=True)  # catalog.schema.table or schema.table
    connection_id = Column(Integer, nullable=True)
    last_observed_at = Column(DateTime, nullable=True)   # last time a query read this table
    last_refresh_at = Column(DateTime, nullable=True)    # manually marked as refreshed
    freshness_status = Column(String(20), default="unknown")  # fresh | stale | unknown
    stale_threshold_hours = Column(Integer, default=24)

    __table_args__ = (
        Index('ix_data_freshness_lookup', 'table_fqn', 'connection_id', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "table_fqn": self.table_fqn,
            "connection_id": self.connection_id,
            "last_observed_at": self.last_observed_at.isoformat() if self.last_observed_at else None,
            "last_refresh_at": self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "freshness_status": self.freshness_status,
            "stale_threshold_hours": self.stale_threshold_hours,
        }


class RestQueryDef(Base):
    """Saved REST API query definitions — each is a 'virtual table' for a REST connection (Phase 61)."""
    __tablename__ = "rest_query_defs"

    id = Column(Integer, primary_key=True, index=True)
    connection_id = Column(Integer, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    http_method = Column(String(10), default="GET")
    endpoint_path = Column(String(1000), nullable=False)
    query_params = Column(JSON, nullable=True)
    request_body = Column(JSON, nullable=True)
    response_json_path = Column(String(500), default="")
    pagination_type = Column(String(20), default="none")
    pagination_config = Column(JSON, nullable=True)
    column_mapping = Column(JSON, nullable=True)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "name": self.name,
            "description": self.description,
            "http_method": self.http_method,
            "endpoint_path": self.endpoint_path,
            "query_params": self.query_params,
            "request_body": self.request_body,
            "response_json_path": self.response_json_path,
            "pagination_type": self.pagination_type,
            "pagination_config": self.pagination_config,
            "column_mapping": self.column_mapping,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
        }


class QueryUsageStat(Base):
    """Tracks table/column usage frequency for auto-suggest (Phase 46)."""
    __tablename__ = "query_usage_stats"

    id = Column(Integer, primary_key=True, index=True)
    object_type = Column(String(10), nullable=False, index=True)  # "table" | "column"
    object_name = Column(String(255), nullable=False, index=True)  # table name or "schema.table.column"
    table_name = Column(String(255), nullable=True, index=True)   # parent table (for columns)
    schema_name = Column(String(255), nullable=True)
    catalog_name = Column(String(255), nullable=True)
    connection_id = Column(Integer, nullable=True, index=True)
    use_count = Column(Integer, default=1)
    last_used_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_usage_stat_lookup', 'object_type', 'object_name', 'connection_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "object_type": self.object_type,
            "object_name": self.object_name,
            "table_name": self.table_name,
            "schema_name": self.schema_name,
            "catalog_name": self.catalog_name,
            "connection_id": self.connection_id,
            "use_count": self.use_count,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
        }


class ColumnLineageEntry(Base):
    """Column-to-column lineage extracted from SQL (Phase 51)."""
    __tablename__ = "column_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query"
    query_id = Column(Integer, nullable=False, index=True)
    source_table = Column(String(255), nullable=True)
    source_column = Column(String(255), nullable=True)
    target_column = Column(String(255), nullable=False)
    transform_type = Column(String(20), default="direct")  # direct|renamed|computed|aggregated|casted|star_expansion
    transform_expr = Column(Text, nullable=True)
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_col_lineage_query', 'query_type', 'query_id'),
        Index('ix_col_lineage_source', 'source_table', 'source_column'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_column": self.target_column,
            "transform_type": self.transform_type,
            "transform_expr": self.transform_expr,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
        }


class NLFeedback(Base):
    """
    Stores user-confirmed NL→SQL pairs (thumbs-up feedback).
    The NL-to-SQL engine uses these as learned custom patterns.
    """
    __tablename__ = "nl_feedback"
    id           = Column(Integer, primary_key=True, autoincrement=True)
    question     = Column(String(500), nullable=False)
    sql          = Column(Text, nullable=False)
    connection_type = Column(String(50), default="duckdb")
    tables_hint  = Column(String(500), nullable=True)   # comma-separated table names used
    rating       = Column(Integer, default=1)            # 1 = thumbs-up, -1 = thumbs-down
    use_count    = Column(Integer, default=1)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "sql": self.sql,
            "connection_type": self.connection_type,
            "tables_hint": self.tables_hint,
            "rating": self.rating,
            "use_count": self.use_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class SuggestionCorrection(Base):
    """
    Stores user corrections to auto-suggested aggregation functions and join columns.

    correction_type = "agg":
      context_key   = column name (e.g. "trade_amount")
      original_value = originally suggested function (e.g. "SUM")
      corrected_value = user's chosen function (e.g. "AVG" or "COUNT_DISTINCT")
      context_extra = column DuckDB type

    correction_type = "join":
      context_key   = canonical sorted "left_table||right_table"
      original_value = "auto-matched" | "learned"
      corrected_value = JSON array of [{leftColumn, rightColumn}, ...]
      context_extra = connection_id as string
    """
    __tablename__ = "suggestion_corrections"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    correction_type  = Column(String(10), nullable=False, index=True)
    context_key      = Column(String(500), nullable=False, index=True)
    original_value   = Column(Text, nullable=True)
    corrected_value  = Column(Text, nullable=False)
    context_extra    = Column(String(255), nullable=True)
    use_count        = Column(Integer, default=1)
    username         = Column(String(100), nullable=True)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_sugg_corr_lookup', 'correction_type', 'context_key'),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "correction_type": self.correction_type,
            "context_key": self.context_key,
            "original_value": self.original_value,
            "corrected_value": self.corrected_value,
            "context_extra": self.context_extra,
            "use_count": self.use_count,
            "username": self.username,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class UIComponentVisibility(Base):
    """
    Controls which UI pages/components are enabled per role.
    Defaults to all enabled; only explicit False rows disable a component.
    """
    __tablename__ = "ui_component_visibility"
    id             = Column(Integer, primary_key=True, autoincrement=True)
    component_key  = Column(String(100), nullable=False)   # e.g. "sql_editor"
    role           = Column(String(50),  nullable=False)   # admin / analyst / viewer
    enabled        = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("component_key", "role", name="uq_ucv_key_role"),)

    def to_dict(self):
        return {
            "component_key": self.component_key,
            "role":          self.role,
            "enabled":       self.enabled,
        }


###############################################################################
# Phase 53 — Semantic Layer Models (BO Universe Equivalent)
###############################################################################

class BusinessDataset(Base):
    """A curated business subject (e.g. 'Sales', 'Orders') that abstracts
    physical tables into a friendly, role-aware semantic layer."""
    __tablename__ = "business_datasets"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    name           = Column(String(200), nullable=False, unique=True)
    description    = Column(Text, default="")
    subject        = Column(String(100), nullable=False, index=True)   # Sales, HR, Finance, etc.
    owner          = Column(String(100), default="admin")              # creator username
    connection_ids = Column(JSON, nullable=False, default=list)        # list of connection IDs used
    source_tables  = Column(JSON, nullable=False, default=list)        # [{"connection_id":1, "table":"s3://bucket/file.parquet", "alias":"orders"}]
    base_query     = Column(Text, default="")                          # optional custom SQL for advanced users
    is_published   = Column(Boolean, default=False, nullable=False)    # visible to business users?
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "subject": self.subject,
            "owner": self.owner,
            "connection_ids": self.connection_ids or [],
            "source_tables": self.source_tables or [],
            "base_query": self.base_query or "",
            "is_published": self.is_published,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DatasetClass(Base):
    """Logical grouping of columns within a dataset (BO Universe Classes).
    E.g. 'Customer', 'Time', 'Product' — organises dimensions and measures."""
    __tablename__ = "dataset_classes"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)           # e.g. "Customer"
    label      = Column(String(200), default="")               # display label
    icon       = Column(String(50), default="")                # optional MUI icon name
    sort_order = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_dsclass_ds_name"),
        Index("ix_dsclass_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "icon": self.icon or "",
            "sort_order": self.sort_order,
        }


class DatasetColumn(Base):
    """A column in a business dataset — maps physical column to friendly name
    with dimension/measure/detail/kpi classification."""
    __tablename__ = "dataset_columns"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    class_id        = Column(Integer, nullable=True)             # FK to DatasetClass.id (optional)
    physical_name   = Column(String(300), nullable=False)        # actual column name in source
    friendly_name   = Column(String(300), nullable=False)        # display label for business users
    column_type     = Column(String(20), nullable=False, default="dimension")  # dimension|measure|detail|kpi
    data_type       = Column(String(50), default="string")       # string|number|date|boolean
    aggregation     = Column(String(30), default="")             # sum|avg|count|min|max|count_distinct (for measures)
    format_pattern  = Column(String(100), default="")            # e.g. "$#,##0.00", "#,##0", "YYYY-MM-DD"
    description     = Column(Text, default="")
    synonyms        = Column(JSON, default=list)                 # ["revenue", "sales_amount", "net_rev"]
    role_whitelist  = Column(JSON, default=list)                 # [] = all roles; ["admin","analyst"] = restricted
    sort_order      = Column(Integer, default=0)
    is_hidden       = Column(Boolean, default=False, nullable=False)
    __table_args__ = (
        UniqueConstraint("dataset_id", "physical_name", name="uq_dscol_ds_phys"),
        Index("ix_dscol_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "class_id": self.class_id,
            "physical_name": self.physical_name,
            "friendly_name": self.friendly_name,
            "column_type": self.column_type,
            "data_type": self.data_type,
            "aggregation": self.aggregation or "",
            "format_pattern": self.format_pattern or "",
            "description": self.description or "",
            "synonyms": self.synonyms or [],
            "role_whitelist": self.role_whitelist or [],
            "sort_order": self.sort_order,
            "is_hidden": self.is_hidden,
        }


class DatasetRelationship(Base):
    """Defines how two datasets (or source tables within a dataset) join.
    Inspired by BO Universe joins."""
    __tablename__ = "dataset_relationships"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id       = Column(Integer, nullable=False, index=True)
    left_table       = Column(String(300), nullable=False)       # alias or table ref
    right_table      = Column(String(300), nullable=False)
    join_type        = Column(String(20), default="inner")       # inner|left|right|full
    join_keys        = Column(JSON, nullable=False, default=list)  # [{"left":"order_id","right":"id"}]
    cardinality      = Column(String(20), default="many_to_one") # one_to_one|one_to_many|many_to_one|many_to_many

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "join_type": self.join_type,
            "join_keys": self.join_keys or [],
            "cardinality": self.cardinality,
        }


class DrillHierarchy(Base):
    """Drill-down hierarchy (e.g. Year → Quarter → Month → Day).
    Tableau-style click-to-expand in business reports."""
    __tablename__ = "drill_hierarchies"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)                  # "Time Hierarchy"
    levels     = Column(JSON, nullable=False, default=list)           # [{"column_id":1,"label":"Year"},{"column_id":2,"label":"Quarter"},...]
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_drill_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "levels": self.levels or [],
        }


class PreDefinedCondition(Base):
    """Reusable WHERE-clause snippets business users can drag into a report
    filter panel (BO pre-defined condition equivalent)."""
    __tablename__ = "predefined_conditions"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id  = Column(Integer, nullable=False, index=True)
    name        = Column(String(200), nullable=False)             # "This Year", "Active Customers Only"
    label       = Column(String(200), default="")
    description = Column(Text, default="")
    where_clause = Column(Text, nullable=False)                   # SQL snippet e.g. "YEAR(order_date) = YEAR(CURRENT_DATE)"
    sort_order  = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_predef_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "description": self.description or "",
            "where_clause": self.where_clause,
            "sort_order": self.sort_order,
        }


class AggregationAwareness(Base):
    """Maps a measure to a pre-aggregated table.  When the report requests
    this measure at a compatible grain, the engine uses the pre-agg table
    instead of scanning raw data."""
    __tablename__ = "aggregation_awareness"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    measure_col_id  = Column(Integer, nullable=False)            # FK to DatasetColumn.id
    agg_table       = Column(String(300), nullable=False)        # pre-aggregated table/parquet path
    agg_dimensions  = Column(JSON, nullable=False, default=list) # dimensions already rolled up in agg_table
    connection_id   = Column(Integer, nullable=True)             # connection for the agg table
    is_enabled      = Column(Boolean, default=True, nullable=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "measure_col_id": self.measure_col_id,
            "agg_table": self.agg_table,
            "agg_dimensions": self.agg_dimensions or [],
            "connection_id": self.connection_id,
            "is_enabled": self.is_enabled,
        }


class FederationExecution(Base):
    """Tracks federated dataset query executions for audit and history."""
    __tablename__ = "federation_executions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    execution_id    = Column(String(100), nullable=False, unique=True, index=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    merged_dataset_id = Column(Integer, nullable=True)          # set for merged queries
    sql_generated   = Column(Text, nullable=False, default="")
    column_ids      = Column(JSON, nullable=False, default=list)  # selected column IDs
    filters         = Column(JSON, nullable=False, default=list)
    condition_ids   = Column(JSON, nullable=False, default=list)
    output_path     = Column(String(500), nullable=True)
    total_rows      = Column(Integer, default=0)
    duration_seconds = Column(Float, default=0.0)
    status          = Column(String(20), nullable=False, default="running")  # running | completed | failed
    error_message   = Column(Text, nullable=True)
    executed_by     = Column(String(100), nullable=True)
    sources_used    = Column(JSON, nullable=False, default=list)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "dataset_id": self.dataset_id,
            "merged_dataset_id": self.merged_dataset_id,
            "sql_generated": self.sql_generated,
            "column_ids": self.column_ids or [],
            "filters": self.filters or [],
            "condition_ids": self.condition_ids or [],
            "output_path": self.output_path,
            "total_rows": self.total_rows,
            "duration_seconds": self.duration_seconds,
            "status": self.status,
            "error_message": self.error_message,
            "executed_by": self.executed_by,
            "sources_used": self.sources_used or [],
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class MergedDimension(Base):
    """Defines how two datasets are merged on shared dimensions (BO-style merge).

    When a business report uses two datasets, MergedDimension records declare
    which columns from each dataset form the merge key."""
    __tablename__ = "merged_dimensions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    primary_dataset_id  = Column(Integer, nullable=False, index=True)
    secondary_dataset_id = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    merge_keys          = Column(JSON, nullable=False, default=list)  # [{"left":"col","right":"col"}]
    merge_type          = Column(String(20), nullable=False, default="inner")  # inner|left|right|full
    is_active           = Column(Boolean, default=True, nullable=False)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("primary_dataset_id", "secondary_dataset_id", "name",
                         name="uq_merged_dimension"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "primary_dataset_id": self.primary_dataset_id,
            "secondary_dataset_id": self.secondary_dataset_id,
            "name": self.name,
            "merge_keys": self.merge_keys or [],
            "merge_type": self.merge_type,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AggCacheEntry(Base):
    """Pre-computed aggregation rollup parquet for sub-second query serving.

    Inspired by BO Aggregate Awareness (transparent routing to coarsest-grain
    pre-agg table), Power BI VertiPaq (pre-loaded compressed data), and Tableau
    Extracts (scheduled refresh with incremental option).

    Cache lifecycle:  pending → building → ready → stale → expired / failed
      - stale: past soft TTL but still serveable (serve + trigger background refresh)
      - expired: past hard expiry, must rebuild (never served)
    """
    __tablename__ = "agg_cache_entries"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    description         = Column(Text, default="")

    # What this cache covers
    dimension_col_ids   = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    measure_col_ids     = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    grain_label         = Column(String(50), default="custom")         # yearly|quarterly|monthly|weekly|daily|custom
    condition_ids       = Column(JSON, nullable=False, default=list)   # pre-defined condition IDs baked in

    # Physical storage
    file_path           = Column(String(500), nullable=True)
    file_size_bytes     = Column(Integer, default=0)
    row_count           = Column(Integer, default=0)

    # Lifecycle
    status              = Column(String(20), default="pending")        # pending|building|ready|stale|expired|failed
    last_built_at       = Column(DateTime, nullable=True)
    last_served_at      = Column(DateTime, nullable=True)
    expires_at          = Column(DateTime, nullable=True)              # hard expiry
    stale_at            = Column(DateTime, nullable=True)              # soft expiry
    error_message       = Column(Text, nullable=True)
    build_duration_seconds = Column(Float, default=0.0)

    # Scheduling
    schedule_config     = Column(JSON, nullable=True)                  # {"type":"cron","cron_expr":"0 2 * * *"}
    is_enabled          = Column(Boolean, default=True, nullable=False)

    # Incremental refresh (Tableau-style)
    incremental_enabled = Column(Boolean, default=False, nullable=False)
    incremental_column  = Column(String(200), nullable=True)
    incremental_last_value = Column(String(500), nullable=True)

    # Stats
    hit_count           = Column(Integer, default=0)
    miss_count          = Column(Integer, default=0)

    created_by          = Column(String(100), default="admin")
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                 onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_aggcache_ds_name"),
        Index("ix_aggcache_dataset_status", "dataset_id", "status"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "description": self.description or "",
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "grain_label": self.grain_label,
            "condition_ids": self.condition_ids or [],
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "row_count": self.row_count,
            "status": self.status,
            "last_built_at": self.last_built_at.isoformat() if self.last_built_at else None,
            "last_served_at": self.last_served_at.isoformat() if self.last_served_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "stale_at": self.stale_at.isoformat() if self.stale_at else None,
            "error_message": self.error_message,
            "build_duration_seconds": self.build_duration_seconds,
            "schedule_config": self.schedule_config,
            "is_enabled": self.is_enabled,
            "incremental_enabled": self.incremental_enabled,
            "incremental_column": self.incremental_column,
            "incremental_last_value": self.incremental_last_value,
            "hit_count": self.hit_count or 0,
            "miss_count": self.miss_count or 0,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class AggCacheSuggestion(Base):
    """Auto-generated suggestion for a new agg cache based on query usage patterns.

    The usage analysis engine examines FederationExecution history to find
    frequently-used dimension+measure combos and creates suggestions that an
    admin can approve (creating an AggCacheEntry) or reject."""
    __tablename__ = "agg_cache_suggestions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    dimension_col_ids   = Column(JSON, nullable=False, default=list)
    measure_col_ids     = Column(JSON, nullable=False, default=list)
    query_count         = Column(Integer, default=0)
    estimated_speedup   = Column(Float, default=0.0)
    status              = Column(String(20), default="pending")        # pending|approved|rejected|implemented
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    reviewed_by         = Column(String(100), nullable=True)
    reviewed_at         = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_aggsuggest_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "query_count": self.query_count,
            "estimated_speedup": self.estimated_speedup,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at.isoformat() if self.reviewed_at else None,
        }


class BusinessReport(Base):
    """Wizard-defined business report using semantic layer datasets.

    Stores the full report definition: selected columns, filters, conditions,
    section breaks with subtotals, running calculations (RunningSum, Rank,
    PercentOfTotal, PreviousValue), slicer columns, and drill hierarchy.
    Executed via FederationEngine; all post-query computations happen client-side.
    """
    __tablename__ = "business_reports"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    name                = Column(String(200), nullable=False)
    description         = Column(Text, default="")
    dataset_id          = Column(Integer, nullable=False, index=True)
    merged_dataset_id   = Column(Integer, nullable=True)
    merge_config        = Column(JSON, nullable=True)          # {merge_keys, merge_type}

    # Query definition
    column_ids          = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    filter_specs        = Column(JSON, nullable=False, default=list)   # [{column_id, operator, value}]
    condition_ids       = Column(JSON, nullable=False, default=list)   # [PreDefinedCondition.id, ...]
    order_by            = Column(JSON, nullable=False, default=list)   # [{column_id, direction}]
    row_limit           = Column(Integer, default=50000)

    # Report layout
    section_definitions = Column(JSON, nullable=False, default=list)   # [{name, break_column_id, subtotal_measure_ids, show_count}]
    running_calculations = Column(JSON, nullable=False, default=list)  # [{name, calc_type, measure_col_id, partition_col_id, format_pattern}]
    slicer_column_ids   = Column(JSON, nullable=False, default=list)   # [col_id, ...]
    drill_hierarchy_id  = Column(Integer, nullable=True)
    layout_config       = Column(JSON, nullable=True)                  # {chart_type, pivot_config, column_widths}

    # Access control
    is_published        = Column(Boolean, default=False, nullable=False)
    owner               = Column(String(100), nullable=False)
    role_whitelist      = Column(JSON, nullable=True)                  # ["viewer","analyst"]

    # Stats
    execution_count     = Column(Integer, default=0)
    last_executed_at    = Column(DateTime, nullable=True)

    # Phase 58: Certification & Catalog
    is_certified        = Column(Boolean, default=False, nullable=False)
    certified_by        = Column(String(100), nullable=True)
    certified_at        = Column(DateTime, nullable=True)
    template_category   = Column(String(100), nullable=True, index=True)
    cloned_from_id      = Column(Integer, nullable=True)

    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                 onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("name", "owner", name="uq_business_report_name_owner"),
        Index("ix_business_report_dataset", "dataset_id"),
        Index("ix_business_report_owner", "owner"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description or "",
            "dataset_id": self.dataset_id,
            "merged_dataset_id": self.merged_dataset_id,
            "merge_config": self.merge_config,
            "column_ids": self.column_ids or [],
            "filter_specs": self.filter_specs or [],
            "condition_ids": self.condition_ids or [],
            "order_by": self.order_by or [],
            "row_limit": self.row_limit,
            "section_definitions": self.section_definitions or [],
            "running_calculations": self.running_calculations or [],
            "slicer_column_ids": self.slicer_column_ids or [],
            "drill_hierarchy_id": self.drill_hierarchy_id,
            "layout_config": self.layout_config,
            "is_published": self.is_published,
            "owner": self.owner,
            "role_whitelist": self.role_whitelist,
            "execution_count": self.execution_count or 0,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "is_certified": self.is_certified or False,
            "certified_by": self.certified_by,
            "certified_at": self.certified_at.isoformat() if self.certified_at else None,
            "template_category": self.template_category,
            "cloned_from_id": self.cloned_from_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ReportParameter(Base):
    """Input control / cascading prompt for a business report.

    Supports dropdown (LOV from dataset column), text, date, date_range,
    numeric, and multi_select types.  Cascading chains are built via
    depends_on_param_id: when the parent param changes, the child's LOV
    is re-fetched with the parent's value as a filter.
    """
    __tablename__ = "report_parameters"

    id                       = Column(Integer, primary_key=True, autoincrement=True)
    report_id                = Column(Integer, nullable=False, index=True)
    name                     = Column(String(100), nullable=False)
    label                    = Column(String(200), nullable=False)
    parameter_type           = Column(String(20), nullable=False, default="dropdown")
    lov_column_id            = Column(Integer, nullable=True)     # DatasetColumn for dropdown values
    depends_on_param_id      = Column(Integer, nullable=True)     # parent parameter for cascade
    cascade_filter_column_id = Column(Integer, nullable=True)     # column to filter when parent changes
    default_value            = Column(String(500), nullable=True)
    is_required              = Column(Boolean, default=True, nullable=False)
    sort_order               = Column(Integer, default=0)
    created_at               = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_report_param_report_order", "report_id", "sort_order"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "name": self.name,
            "label": self.label,
            "parameter_type": self.parameter_type,
            "lov_column_id": self.lov_column_id,
            "depends_on_param_id": self.depends_on_param_id,
            "cascade_filter_column_id": self.cascade_filter_column_id,
            "default_value": self.default_value,
            "is_required": self.is_required,
            "sort_order": self.sort_order,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportSubscription(Base):
    """Scheduled report delivery subscription — PDF/Excel/CSV to email recipients."""
    __tablename__ = "report_subscriptions"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    report_id        = Column(Integer, nullable=False, index=True)
    report_type      = Column(String(50), nullable=False, default="business_report")  # business_report | parametric | query
    name             = Column(String(255), nullable=False)
    created_by       = Column(String(100), nullable=False, index=True)
    recipient_emails = Column(JSON, nullable=False, default=list)
    frequency        = Column(String(200), nullable=False)     # cron expression
    timezone         = Column(String(100), nullable=False, default="UTC")
    output_format    = Column(String(20), nullable=False, default="pdf")  # pdf | excel | csv
    param_values     = Column(JSON, nullable=True)
    is_active        = Column(Boolean, default=True, nullable=False)
    next_send_at     = Column(DateTime, nullable=True)
    last_sent_at     = Column(DateTime, nullable=True)
    unsubscribe_token = Column(String(100), nullable=True, unique=True, index=True)
    retry_count      = Column(Integer, default=0, nullable=False)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_subscription_report", "report_id", "report_type"),
        Index("ix_subscription_next_send", "is_active", "next_send_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "report_type": self.report_type,
            "name": self.name,
            "created_by": self.created_by,
            "recipient_emails": self.recipient_emails or [],
            "frequency": self.frequency,
            "timezone": self.timezone,
            "output_format": self.output_format,
            "param_values": self.param_values,
            "is_active": self.is_active,
            "next_send_at": self.next_send_at.isoformat() if self.next_send_at else None,
            "last_sent_at": self.last_sent_at.isoformat() if self.last_sent_at else None,
            "unsubscribe_token": self.unsubscribe_token,
            "retry_count": self.retry_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class SubscriptionDelivery(Base):
    """Individual delivery record for a subscription send attempt."""
    __tablename__ = "subscription_deliveries"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    subscription_id  = Column(Integer, nullable=False, index=True)
    recipient_email  = Column(String(255), nullable=False)
    sent_at          = Column(DateTime, nullable=True)
    status           = Column(String(20), nullable=False, default="pending")  # pending | sent | failed | bounced
    error_message    = Column(Text, nullable=True)
    file_size_bytes  = Column(Integer, nullable=True)
    attempted_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "subscription_id": self.subscription_id,
            "recipient_email": self.recipient_email,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "status": self.status,
            "error_message": self.error_message,
            "file_size_bytes": self.file_size_bytes,
            "attempted_at": self.attempted_at.isoformat() if self.attempted_at else None,
        }


class WorkerRegistration(Base):
    """Registry of active worker nodes for Phase 45C horizontal scaling."""
    __tablename__ = "worker_registry"

    worker_id      = Column(String(128), primary_key=True)
    worker_type    = Column(String(32), nullable=False, default="executor")
    hostname       = Column(String(256), nullable=True)
    info           = Column(JSON, nullable=True)
    last_heartbeat = Column(DateTime, nullable=True)
    expires_at     = Column(DateTime, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "worker_type": self.worker_type,
            "hostname": self.hostname,
            "info": self.info,
            "last_heartbeat": self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }


