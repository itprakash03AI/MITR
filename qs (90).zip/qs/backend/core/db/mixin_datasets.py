"""
Mixin — Datasets, Federation, Agg Cache, Business Reports, Parameters, Subscriptions.
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from core.db.models import (
    BusinessDataset, DatasetClass, DatasetColumn, DatasetRelationship,
    DrillHierarchy, PreDefinedCondition, AggregationAwareness,
    FederationExecution, MergedDimension, AggCacheEntry, AggCacheSuggestion,
    BusinessReport, ReportParameter, ReportSubscription, SubscriptionDelivery,
)


class DatasetsMixin:
    """Database methods for datasets, federation, agg cache, business reports, subscriptions."""

    def list_datasets(self, subject: str = None, published_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(BusinessDataset)
            if subject:
                q = q.filter(BusinessDataset.subject == subject)
            if published_only:
                q = q.filter(BusinessDataset.is_published == True)
            return [r.to_dict() for r in q.order_by(BusinessDataset.name).all()]

    def get_dataset(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            return row.to_dict() if row else None

    def create_dataset(self, name: str, subject: str, description: str = "",
                       owner: str = "admin", connection_ids: list = None,
                       source_tables: list = None, base_query: str = "",
                       is_published: bool = False) -> Dict[str, Any]:
        with self.get_session() as session:
            ds = BusinessDataset(
                name=name, subject=subject, description=description,
                owner=owner, connection_ids=connection_ids or [],
                source_tables=source_tables or [], base_query=base_query,
                is_published=is_published,
            )
            session.add(ds)
            session.flush()
            return ds.to_dict()

    def update_dataset(self, dataset_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return None
            allowed = {"name", "description", "subject", "owner", "connection_ids",
                       "source_tables", "base_query", "is_published"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def delete_dataset(self, dataset_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return False
            # Cascade: delete related objects
            session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id).delete()
            session.query(DatasetClass).filter(DatasetClass.dataset_id == dataset_id).delete()
            session.query(DatasetRelationship).filter(DatasetRelationship.dataset_id == dataset_id).delete()
            session.query(DrillHierarchy).filter(DrillHierarchy.dataset_id == dataset_id).delete()
            session.query(PreDefinedCondition).filter(PreDefinedCondition.dataset_id == dataset_id).delete()
            session.query(AggregationAwareness).filter(AggregationAwareness.dataset_id == dataset_id).delete()
            session.delete(row)
            return True

    # ── DatasetClass CRUD ─────────────────────────────────────────────────

    def list_dataset_classes(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetClass).filter(
                DatasetClass.dataset_id == dataset_id
            ).order_by(DatasetClass.sort_order, DatasetClass.name).all()
            return [r.to_dict() for r in rows]

    def create_dataset_class(self, dataset_id: int, name: str,
                             label: str = "", icon: str = "",
                             sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            obj = DatasetClass(dataset_id=dataset_id, name=name,
                               label=label, icon=icon, sort_order=sort_order)
            session.add(obj)
            session.flush()
            return obj.to_dict()

    def update_dataset_class(self, class_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "icon", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_class(self, class_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return False
            # Unlink columns from this class (set class_id=None)
            session.query(DatasetColumn).filter(DatasetColumn.class_id == class_id).update(
                {"class_id": None}, synchronize_session="fetch")
            session.delete(row)
            return True

    # ── DatasetColumn CRUD ────────────────────────────────────────────────

    def list_dataset_columns(self, dataset_id: int,
                             column_type: str = None,
                             include_hidden: bool = True) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id)
            if column_type:
                q = q.filter(DatasetColumn.column_type == column_type)
            if not include_hidden:
                q = q.filter(DatasetColumn.is_hidden == False)
            return [r.to_dict() for r in q.order_by(DatasetColumn.sort_order, DatasetColumn.friendly_name).all()]

    def get_dataset_column(self, column_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            return row.to_dict() if row else None

    def create_dataset_column(self, dataset_id: int, physical_name: str,
                              friendly_name: str, column_type: str = "dimension",
                              data_type: str = "string", aggregation: str = "",
                              format_pattern: str = "", description: str = "",
                              synonyms: list = None, role_whitelist: list = None,
                              class_id: int = None, sort_order: int = 0,
                              is_hidden: bool = False) -> Dict[str, Any]:
        with self.get_session() as session:
            col = DatasetColumn(
                dataset_id=dataset_id, physical_name=physical_name,
                friendly_name=friendly_name, column_type=column_type,
                data_type=data_type, aggregation=aggregation,
                format_pattern=format_pattern, description=description,
                synonyms=synonyms or [], role_whitelist=role_whitelist or [],
                class_id=class_id, sort_order=sort_order, is_hidden=is_hidden,
            )
            session.add(col)
            session.flush()
            return col.to_dict()

    def update_dataset_column(self, column_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return None
            allowed = {"physical_name", "friendly_name", "column_type", "data_type",
                       "aggregation", "format_pattern", "description", "synonyms",
                       "role_whitelist", "class_id", "sort_order", "is_hidden"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_column(self, column_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    def bulk_create_dataset_columns(self, dataset_id: int,
                                    columns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Bulk-create columns for a dataset (used by auto-detect from schema)."""
        results = []
        with self.get_session() as session:
            for c in columns:
                col = DatasetColumn(
                    dataset_id=dataset_id,
                    physical_name=c.get("physical_name", ""),
                    friendly_name=c.get("friendly_name", c.get("physical_name", "")),
                    column_type=c.get("column_type", "dimension"),
                    data_type=c.get("data_type", "string"),
                    aggregation=c.get("aggregation", ""),
                    format_pattern=c.get("format_pattern", ""),
                    description=c.get("description", ""),
                    synonyms=c.get("synonyms", []),
                    role_whitelist=c.get("role_whitelist", []),
                    class_id=c.get("class_id"),
                    sort_order=c.get("sort_order", 0),
                    is_hidden=c.get("is_hidden", False),
                )
                session.add(col)
                session.flush()
                results.append(col.to_dict())
        return results

    # ── DatasetRelationship CRUD ──────────────────────────────────────────

    def list_dataset_relationships(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetRelationship).filter(
                DatasetRelationship.dataset_id == dataset_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_dataset_relationship(self, dataset_id: int, left_table: str,
                                    right_table: str, join_keys: list,
                                    join_type: str = "inner",
                                    cardinality: str = "many_to_one") -> Dict[str, Any]:
        with self.get_session() as session:
            rel = DatasetRelationship(
                dataset_id=dataset_id, left_table=left_table,
                right_table=right_table, join_keys=join_keys,
                join_type=join_type, cardinality=cardinality,
            )
            session.add(rel)
            session.flush()
            return rel.to_dict()

    def update_dataset_relationship(self, rel_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"left_table", "right_table", "join_type", "join_keys", "cardinality"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_relationship(self, rel_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── DrillHierarchy CRUD ───────────────────────────────────────────────

    def list_drill_hierarchies(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DrillHierarchy).filter(
                DrillHierarchy.dataset_id == dataset_id
            ).order_by(DrillHierarchy.name).all()
            return [r.to_dict() for r in rows]

    def create_drill_hierarchy(self, dataset_id: int, name: str,
                               levels: list) -> Dict[str, Any]:
        with self.get_session() as session:
            h = DrillHierarchy(dataset_id=dataset_id, name=name, levels=levels)
            session.add(h)
            session.flush()
            return h.to_dict()

    def update_drill_hierarchy(self, hierarchy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "levels"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_drill_hierarchy(self, hierarchy_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── PreDefinedCondition CRUD ──────────────────────────────────────────

    def list_predefined_conditions(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(PreDefinedCondition).filter(
                PreDefinedCondition.dataset_id == dataset_id
            ).order_by(PreDefinedCondition.sort_order, PreDefinedCondition.name).all()
            return [r.to_dict() for r in rows]

    def create_predefined_condition(self, dataset_id: int, name: str,
                                    where_clause: str, label: str = "",
                                    description: str = "",
                                    sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            c = PreDefinedCondition(
                dataset_id=dataset_id, name=name, where_clause=where_clause,
                label=label, description=description, sort_order=sort_order,
            )
            session.add(c)
            session.flush()
            return c.to_dict()

    def update_predefined_condition(self, condition_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "description", "where_clause", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_predefined_condition(self, condition_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── AggregationAwareness CRUD ─────────────────────────────────────────

    def list_aggregation_awareness(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(AggregationAwareness).filter(
                AggregationAwareness.dataset_id == dataset_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_aggregation_awareness(self, dataset_id: int, measure_col_id: int,
                                     agg_table: str, agg_dimensions: list,
                                     connection_id: int = None,
                                     is_enabled: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            aa = AggregationAwareness(
                dataset_id=dataset_id, measure_col_id=measure_col_id,
                agg_table=agg_table, agg_dimensions=agg_dimensions,
                connection_id=connection_id, is_enabled=is_enabled,
            )
            session.add(aa)
            session.flush()
            return aa.to_dict()

    def delete_aggregation_awareness(self, agg_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(AggregationAwareness).filter(AggregationAwareness.id == agg_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── Full dataset with all children (single round-trip) ────────────────

    def get_dataset_full(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        """Return a dataset with all its classes, columns, relationships,
        hierarchies, conditions, and aggregation awareness rules."""
        ds = self.get_dataset(dataset_id)
        if not ds:
            return None
        ds["classes"]        = self.list_dataset_classes(dataset_id)
        ds["columns"]        = self.list_dataset_columns(dataset_id)
        ds["relationships"]  = self.list_dataset_relationships(dataset_id)
        ds["hierarchies"]    = self.list_drill_hierarchies(dataset_id)
        ds["conditions"]     = self.list_predefined_conditions(dataset_id)
        ds["agg_awareness"]  = self.list_aggregation_awareness(dataset_id)
        return ds

    # ── Federation Executions ─────────────────────────────────────────────────

    def create_federation_execution(self, *, execution_id: str, dataset_id: int,
                                    merged_dataset_id: Optional[int] = None,
                                    sql_generated: str = "", column_ids: list = None,
                                    filters: list = None, condition_ids: list = None,
                                    executed_by: str = "") -> Dict[str, Any]:
        with self.get_session() as session:
            fe = FederationExecution(
                execution_id=execution_id, dataset_id=dataset_id,
                merged_dataset_id=merged_dataset_id, sql_generated=sql_generated,
                column_ids=column_ids or [], filters=filters or [],
                condition_ids=condition_ids or [], status="running",
                executed_by=executed_by,
            )
            session.add(fe)
            session.flush()
            return fe.to_dict()

    def update_federation_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return None
            for k, v in kwargs.items():
                if hasattr(fe, k):
                    setattr(fe, k, v)
            session.flush()
            return fe.to_dict()

    def get_federation_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            return fe.to_dict() if fe else None

    def list_federation_executions(self, dataset_id: Optional[int] = None,
                                    limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(FederationExecution)
            if dataset_id is not None:
                q = q.filter(FederationExecution.dataset_id == dataset_id)
            q = q.order_by(FederationExecution.created_at.desc()).limit(limit)
            return [fe.to_dict() for fe in q.all()]

    def delete_federation_execution(self, execution_id: str) -> bool:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return False
            session.delete(fe)
            return True

    # ── Merged Dimensions ─────────────────────────────────────────────────────

    def create_merged_dimension(self, *, primary_dataset_id: int,
                                secondary_dataset_id: int, name: str,
                                merge_keys: list, merge_type: str = "inner",
                                is_active: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            md = MergedDimension(
                primary_dataset_id=primary_dataset_id,
                secondary_dataset_id=secondary_dataset_id,
                name=name, merge_keys=merge_keys, merge_type=merge_type,
                is_active=is_active,
            )
            session.add(md)
            session.flush()
            return md.to_dict()

    def list_merged_dimensions(self, dataset_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(MergedDimension)
            if dataset_id is not None:
                q = q.filter(
                    (MergedDimension.primary_dataset_id == dataset_id) |
                    (MergedDimension.secondary_dataset_id == dataset_id)
                )
            return [md.to_dict() for md in q.all()]

    def get_merged_dimension(self, md_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            return md.to_dict() if md else None

    def update_merged_dimension(self, md_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return None
            for k, v in kwargs.items():
                if hasattr(md, k):
                    setattr(md, k, v)
            session.flush()
            return md.to_dict()

    def delete_merged_dimension(self, md_id: int) -> bool:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return False
            session.delete(md)
            return True

    # ── AggCacheEntry CRUD ────────────────────────────────────────────

    def list_agg_cache_entries(self, dataset_id: int = None,
                               status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheEntry.status == status)
            return [e.to_dict() for e in q.order_by(AggCacheEntry.id).all()]

    def get_agg_cache_entry(self, entry_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            return e.to_dict() if e else None

    def create_agg_cache_entry(self, *, dataset_id: int, name: str,
                                description: str = "",
                                dimension_col_ids: list = None,
                                measure_col_ids: list = None,
                                grain_label: str = "custom",
                                condition_ids: list = None,
                                schedule_config: dict = None,
                                is_enabled: bool = True,
                                incremental_enabled: bool = False,
                                incremental_column: str = None,
                                created_by: str = "admin") -> Dict[str, Any]:
        with self.get_session() as session:
            entry = AggCacheEntry(
                dataset_id=dataset_id,
                name=name,
                description=description,
                dimension_col_ids=dimension_col_ids or [],
                measure_col_ids=measure_col_ids or [],
                grain_label=grain_label,
                condition_ids=condition_ids or [],
                schedule_config=schedule_config,
                is_enabled=is_enabled,
                incremental_enabled=incremental_enabled,
                incremental_column=incremental_column,
                created_by=created_by,
            )
            session.add(entry)
            session.flush()
            return entry.to_dict()

    def update_agg_cache_entry(self, entry_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return None
            for k, v in kwargs.items():
                if hasattr(entry, k):
                    setattr(entry, k, v)
            session.flush()
            return entry.to_dict()

    def delete_agg_cache_entry(self, entry_id: int) -> bool:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return False
            session.delete(entry)
            return True

    def increment_agg_cache_hit(self, entry_id: int) -> None:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if entry:
                entry.hit_count = (entry.hit_count or 0) + 1
                entry.last_served_at = datetime.now(timezone.utc)

    def increment_agg_cache_miss(self, entry_id: int) -> None:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if entry:
                entry.miss_count = (entry.miss_count or 0) + 1

    def get_agg_cache_stats(self, dataset_id: int = None) -> Dict[str, Any]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            entries = q.all()
            total_hits = sum(e.hit_count or 0 for e in entries)
            total_misses = sum(e.miss_count or 0 for e in entries)
            total_size = sum(e.file_size_bytes or 0 for e in entries)
            by_status: Dict[str, int] = {}
            ds_ids = set()
            for e in entries:
                by_status[e.status] = by_status.get(e.status, 0) + 1
                ds_ids.add(e.dataset_id)
            total_requests = total_hits + total_misses
            suggestions_q = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.status == "pending")
            if dataset_id is not None:
                suggestions_q = suggestions_q.filter(
                    AggCacheSuggestion.dataset_id == dataset_id)
            return {
                "total_entries": len(entries),
                "entries_by_status": by_status,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2) if total_size else 0,
                "total_hits": total_hits,
                "total_misses": total_misses,
                "hit_rate_percent": round(total_hits / total_requests * 100, 1) if total_requests else 0,
                "datasets_cached": len(ds_ids),
                "suggestions_pending": suggestions_q.count(),
            }

    # ── AggCacheSuggestion CRUD ───────────────────────────────────────

    def list_agg_cache_suggestions(self, dataset_id: int = None,
                                    status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheSuggestion)
            if dataset_id is not None:
                q = q.filter(AggCacheSuggestion.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheSuggestion.status == status)
            return [s.to_dict() for s in q.order_by(AggCacheSuggestion.id.desc()).all()]

    def create_agg_cache_suggestion(self, *, dataset_id: int,
                                     dimension_col_ids: list,
                                     measure_col_ids: list,
                                     query_count: int,
                                     estimated_speedup: float = 0.0) -> Dict[str, Any]:
        with self.get_session() as session:
            s = AggCacheSuggestion(
                dataset_id=dataset_id,
                dimension_col_ids=dimension_col_ids,
                measure_col_ids=measure_col_ids,
                query_count=query_count,
                estimated_speedup=estimated_speedup,
            )
            session.add(s)
            session.flush()
            return s.to_dict()

    def update_agg_cache_suggestion(self, suggestion_id: int,
                                     **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return None
            for k, v in kwargs.items():
                if hasattr(s, k):
                    setattr(s, k, v)
            session.flush()
            return s.to_dict()

    def delete_agg_cache_suggestion(self, suggestion_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    # ── Phase 56: Business Reports ──────────────────────────────────────────

    def list_business_reports(self, owner: str = None, dataset_id: int = None,
                              is_published: bool = None) -> list:
        with self.get_session() as session:
            q = session.query(BusinessReport)
            if owner:
                q = q.filter(BusinessReport.owner == owner)
            if dataset_id:
                q = q.filter(BusinessReport.dataset_id == dataset_id)
            if is_published is not None:
                q = q.filter(BusinessReport.is_published == is_published)
            return [r.to_dict() for r in q.order_by(BusinessReport.updated_at.desc()).all()]

    def get_business_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            return r.to_dict() if r else None

    def create_business_report(self, *, name: str, owner: str, dataset_id: int,
                                **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            r = BusinessReport(name=name, owner=owner, dataset_id=dataset_id, **kwargs)
            session.add(r)
            session.flush()
            return r.to_dict()

    def update_business_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            for k, v in kwargs.items():
                if hasattr(r, k):
                    setattr(r, k, v)
            session.flush()
            return r.to_dict()

    def delete_business_report(self, report_id: int) -> bool:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return False
            # Also delete associated parameters
            session.query(ReportParameter).filter(ReportParameter.report_id == report_id).delete()
            session.delete(r)
            return True

    def increment_business_report_execution(self, report_id: int) -> None:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if r:
                r.execution_count = (r.execution_count or 0) + 1
                r.last_executed_at = datetime.now(timezone.utc)

    def list_report_parameters(self, report_id: int) -> list:
        with self.get_session() as session:
            return [p.to_dict() for p in session.query(ReportParameter).filter(
                ReportParameter.report_id == report_id
            ).order_by(ReportParameter.sort_order).all()]

    def create_report_parameter(self, *, report_id: int, name: str, label: str,
                                 parameter_type: str = "dropdown", **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ReportParameter(report_id=report_id, name=name, label=label,
                                parameter_type=parameter_type, **kwargs)
            session.add(p)
            session.flush()
            return p.to_dict()

    def update_report_parameter(self, param_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ReportParameter).filter(ReportParameter.id == param_id).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            session.flush()
            return p.to_dict()

    def delete_report_parameter(self, param_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ReportParameter).filter(ReportParameter.id == param_id).first()
            if not p:
                return False
            session.delete(p)
            return True

    # ── Report Subscription methods (Phase 60) ──────────────────────────

    def create_subscription(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            sub = ReportSubscription(**kwargs)
            session.add(sub)
            session.flush()
            return sub.to_dict()

    def get_subscription(self, sub_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            return sub.to_dict() if sub else None

    def list_subscriptions(self, created_by: Optional[str] = None,
                           report_id: Optional[int] = None,
                           report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(ReportSubscription)
            if created_by:
                q = q.filter(ReportSubscription.created_by == created_by)
            if report_id is not None:
                q = q.filter(ReportSubscription.report_id == report_id)
            if report_type:
                q = q.filter(ReportSubscription.report_type == report_type)
            return [s.to_dict() for s in q.order_by(ReportSubscription.created_at.desc()).all()]

    def update_subscription(self, sub_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            if not sub:
                return None
            for k, v in kwargs.items():
                if hasattr(sub, k):
                    setattr(sub, k, v)
            session.flush()
            return sub.to_dict()

    def delete_subscription(self, sub_id: int) -> bool:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            if not sub:
                return False
            session.delete(sub)
            return True

    def get_subscription_by_unsubscribe_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(
                ReportSubscription.unsubscribe_token == token
            ).first()
            return sub.to_dict() if sub else None

    def get_pending_subscriptions(self, before: datetime) -> List[Dict[str, Any]]:
        """Return active subscriptions whose next_send_at is at or before the given time."""
        with self.get_session() as session:
            subs = session.query(ReportSubscription).filter(
                ReportSubscription.is_active == True,
                ReportSubscription.next_send_at != None,
                ReportSubscription.next_send_at <= before,
            ).order_by(ReportSubscription.next_send_at).all()
            return [s.to_dict() for s in subs]

    def record_subscription_delivery(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            rec = SubscriptionDelivery(**kwargs)
            session.add(rec)
            session.flush()
            return rec.to_dict()

    def list_subscription_deliveries(self, subscription_id: int,
                                     limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            recs = session.query(SubscriptionDelivery).filter(
                SubscriptionDelivery.subscription_id == subscription_id
            ).order_by(SubscriptionDelivery.attempted_at.desc()).limit(limit).all()
            return [r.to_dict() for r in recs]
