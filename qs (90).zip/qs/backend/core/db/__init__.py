"""
Database package — models, mixins, and DatabaseManager composition.

For backward compatibility, `from core.database import db` still works.
This package provides the decomposed structure.
"""
from core.db.models import *  # noqa: F401,F403 — re-export all models + Base
