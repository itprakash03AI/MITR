"""
Materialized view & local table management.

Extracted from main.py for maintainability.

Functions:
- refresh_materialized_view_sync — download S3 data to local parquet (MV refresh)
- setup_mv_schedule              — register APScheduler job for MV auto-refresh
- remove_mv_schedule             — remove APScheduler job for MV
- promote_download_sync          — copy download parquet into local table storage
- upload_file_to_local_table_sync — convert uploaded file to local parquet
- cleanup_expired_local_tables   — auto-discard unused local tables
- resolve_table_duckdb_sql       — resolve table_path to DuckDB FROM clause
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# ── Module-level singletons — populated by init_mv_manager() ───────────────
_db_manager = None
_ws_manager = None
_mv_cfg = None
_lt_cfg = None


def init_mv_manager(db_manager, ws_manager, mv_cfg, lt_cfg):
    """Call once from main.py _startup() after all components are initialised."""
    global _db_manager, _ws_manager, _mv_cfg, _lt_cfg
    _db_manager = db_manager
    _ws_manager = ws_manager
    _mv_cfg = mv_cfg
    _lt_cfg = lt_cfg


# ═══════════════════════════════════════════════════════════════════════════
# refresh_materialized_view_sync
# ═══════════════════════════════════════════════════════════════════════════

def refresh_materialized_view_sync(mv_id: int):
    """Core refresh logic — downloads S3 data to local parquet files."""
    import time as _t
    import shutil
    import pyarrow as pa
    import pyarrow.parquet as pq
    from core.duckdb_views import register_s3_views

    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        logger.error("MV refresh: view %d not found", mv_id)
        return

    _db_manager.update_materialized_view(mv_id, status="refreshing", last_error=None)
    _start = _t.monotonic()

    try:
        # Load connection
        conn = _db_manager.get_connection(mv["connection_id"])
        if not conn:
            raise ValueError(f"Connection {mv['connection_id']} not found")
        cfg = conn["config"]
        bucket = cfg.get("bucket_name", "")

        # Get registered tables for this connection
        registered_tables = cfg.get("registered_tables", [])
        target_table = None
        for rt in registered_tables:
            if rt["name"] == mv["table_name"]:
                target_table = rt
                break
        if not target_table:
            raise ValueError(f"Registered table '{mv['table_name']}' not found in connection")

        # Open DuckDB connection with S3 credentials
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg)

        # Register only the target table
        register_s3_views(con, [target_table], bucket, mv["connection_id"], cfg,
                          referenced_tables={mv["table_name"]})

        # Build query
        tname_safe = '"' + mv["table_name"].replace('"', '""') + '"'
        sql = f"SELECT * FROM {tname_safe}"
        where_parts = []

        # Apply partition filter
        pf = mv.get("partition_filter")
        if pf and pf.get("date_col"):
            date_col = pf["date_col"].replace('"', '""')
            if pf.get("from"):
                where_parts.append(f'"{date_col}" >= \'{pf["from"]}\'')
            if pf.get("to"):
                where_parts.append(f'"{date_col}" <= \'{pf["to"]}\'')

        # Apply query filter
        if mv.get("query_filter"):
            where_parts.append(f"({mv['query_filter']})")

        if where_parts:
            sql += " WHERE " + " AND ".join(where_parts)

        logger.info("MV refresh %d '%s': SQL = %s", mv_id, mv["name"], sql[:500])

        # Execute and write to local parquet
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
        if os.path.exists(mv_dir):
            shutil.rmtree(mv_dir)
        os.makedirs(mv_dir, exist_ok=True)

        chunk_size = _mv_cfg.chunk_size
        result = con.execute(sql)
        total_rows = 0
        file_idx = 0
        total_size = 0

        while True:
            batch = result.fetchmany(chunk_size)
            if not batch:
                break
            cols = [desc[0] for desc in result.description]
            table = pa.table({col: [row[i] for row in batch] for i, col in enumerate(cols)})
            out_path = os.path.join(mv_dir, f"part_{file_idx:04d}.parquet")
            pq.write_table(table, out_path, compression="snappy")
            total_rows += len(batch)
            total_size += os.path.getsize(out_path)
            file_idx += 1

        con.close()

        elapsed = _t.monotonic() - _start
        _db_manager.update_materialized_view(mv_id,
            status="ready",
            row_count=total_rows,
            file_count=file_idx,
            size_bytes=total_size,
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
            last_error=None,
        )
        logger.info("MV refresh %d '%s': %d rows, %d files, %.1f MB in %.1fs",
                    mv_id, mv["name"], total_rows, file_idx, total_size / 1048576, elapsed)

        try:
            _ws_manager.broadcast_sync({
                "type": "materialized_view_refreshed",
                "mv_id": mv_id,
                "name": mv["name"],
                "row_count": total_rows,
                "size_bytes": total_size,
            })
        except Exception:
            pass

    except Exception as e:
        elapsed = _t.monotonic() - _start
        logger.error("MV refresh %d failed after %.1fs: %s", mv_id, elapsed, e, exc_info=True)
        _db_manager.update_materialized_view(mv_id,
            status="failed",
            last_error=str(e),
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
        )
        try:
            _ws_manager.broadcast_sync({
                "type": "materialized_view_failed",
                "mv_id": mv_id,
                "name": mv.get("name", ""),
                "error": str(e)[:500],
            })
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════
# setup_mv_schedule / remove_mv_schedule
# ═══════════════════════════════════════════════════════════════════════════

def setup_mv_schedule(mv_id: int, schedule_config: dict, mv_name: str = ""):
    """Register or update APScheduler job for MV auto-refresh."""
    from core.scheduler import _build_trigger
    import uuid as _uuid
    try:
        from core.scheduler import _scheduler
        if not _scheduler or not _scheduler.running:
            logger.warning("Scheduler not running — MV schedule not set for %d", mv_id)
            return None
    except Exception:
        return None

    job_id = f"mv_{mv_id}_{_uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_config)
    _scheduler.add_job(
        func=refresh_materialized_view_sync,
        trigger=trigger,
        id=job_id,
        args=[mv_id],
        name=f"MV: {mv_name or mv_id}",
        replace_existing=True,
    )
    job = _scheduler.get_job(job_id)
    next_run = job.next_run_time if job else None
    _db_manager.update_materialized_view(mv_id, apscheduler_job_id=job_id,
                                         next_refresh_at=next_run)
    return job_id


def remove_mv_schedule(job_id: str):
    """Remove APScheduler job for MV."""
    try:
        from core.scheduler import _scheduler
        if _scheduler and job_id and _scheduler.get_job(job_id):
            _scheduler.remove_job(job_id)
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# promote_download_sync
# ═══════════════════════════════════════════════════════════════════════════

def promote_download_sync(lt_id: int, source_path: str):
    """Copy a download parquet file into local table storage and read metadata."""
    import shutil
    import pyarrow.parquet as _pq

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)

    try:
        dest = os.path.join(lt_dir, "data.parquet")
        shutil.copy2(source_path, dest)

        pf = _pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for i, field in enumerate(pf.schema_arrow):
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d promoted successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table promote failed for %d: %s", lt_id, e)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════
# upload_file_to_local_table_sync
# ═══════════════════════════════════════════════════════════════════════════

def upload_file_to_local_table_sync(lt_id: int, temp_path: str, original_filename: str):
    """Convert uploaded file (CSV/Excel/JSON/Parquet) to local parquet."""
    import shutil
    import duckdb as _ddb

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)
    dest = os.path.join(lt_dir, "data.parquet")
    ext = os.path.splitext(original_filename)[1].lower()

    try:
        if ext == ".parquet":
            shutil.copy2(temp_path, dest)
        else:
            con = _ddb.connect()
            try:
                temp_fixed = temp_path.replace("\\", "/")
                dest_fixed = dest.replace("\\", "/")
                if ext in (".csv", ".tsv", ".txt"):
                    con.execute(f"COPY (SELECT * FROM read_csv_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                elif ext in (".xlsx", ".xls"):
                    try:
                        con.execute("INSTALL spatial; LOAD spatial;")
                        con.execute(f"COPY (SELECT * FROM st_read('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                    except Exception:
                        import pandas as pd
                        df = pd.read_excel(temp_path)
                        df.to_parquet(dest, index=False)
                elif ext == ".json":
                    con.execute(f"COPY (SELECT * FROM read_json_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                else:
                    raise ValueError(f"Unsupported file type: {ext}")
            finally:
                con.close()

        import pyarrow.parquet as pq
        pf = pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for field in pf.schema_arrow:
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d uploaded successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table upload failed for %d: %s", lt_id, e)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass
    finally:
        try:
            os.unlink(temp_path)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════
# cleanup_expired_local_tables
# ═══════════════════════════════════════════════════════════════════════════

def cleanup_expired_local_tables():
    """Auto-discard public local tables unused beyond their auto_discard_days."""
    import shutil
    expired = _db_manager.list_expired_local_tables()
    count = 0
    for lt in expired:
        try:
            lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt["id"]))
            if os.path.isdir(lt_dir):
                shutil.rmtree(lt_dir)
            _db_manager.delete_local_table(lt["id"])
            count += 1
            logger.info("Auto-discarded local table %d (%s) — unused for %d+ days",
                        lt["id"], lt["name"], lt["auto_discard_days"])
        except Exception as e:
            logger.warning("Failed to discard local table %d: %s", lt["id"], e)
    if count > 0:
        try:
            _ws_manager.broadcast_sync({"type": "local_tables_cleanup", "discarded_count": count})
        except Exception:
            pass
        logger.info("Auto-discard cleaned up %d expired local tables", count)


# ═══════════════════════════════════════════════════════════════════════════
# resolve_table_duckdb_sql
# ═══════════════════════════════════════════════════════════════════════════

def resolve_table_duckdb_sql(table_path: str, connection_id: int = None) -> tuple:
    """Resolve a table_path to a DuckDB-compatible FROM clause + optional DuckDB connection.

    Returns (from_clause: str, con: duckdb.Connection | None, needs_close: bool).
    If con is returned, caller must close it.
    """
    import duckdb as _ddb
    from core.s3_utilities import (
        make_s3_client_for_conn as _make_s3,
        list_s3_parquet_files as _list_pq,
        s3_urls_to_presigned as _presign,
        get_s3_access_mode as _get_s3_mode,
    )

    if table_path.startswith("__materialized__:"):
        mv_name = table_path.replace("__materialized__:", "")
        mv_rec = _db_manager.get_materialized_view_by_name(mv_name)
        if not mv_rec or mv_rec["status"] != "ready":
            raise ValueError(f"Materialized view '{mv_name}' not found or not ready")
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_rec["id"]))
        import glob as _gm
        pq_files = _gm.glob(os.path.join(mv_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for MV '{mv_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__local__:"):
        lt_name = table_path.replace("__local__:", "")
        lt_rec = _db_manager.get_local_table_by_name(lt_name)
        if not lt_rec or lt_rec["status"] != "ready":
            raise ValueError(f"Local table '{lt_name}' not found or not ready")
        lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_rec["id"]))
        import glob as _gm2
        pq_files = _gm2.glob(os.path.join(lt_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for local table '{lt_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__registered__:"):
        reg_name = table_path.replace("__registered__:", "")
        if not connection_id:
            raise ValueError("connection_id required for registered table preview")
        conn_record = _db_manager.get_connection_raw(connection_id)
        if not conn_record:
            raise ValueError(f"Connection {connection_id} not found")
        cfg = conn_record.get("config", {})
        registered_tables = cfg.get("registered_tables", [])
        tdef = None
        for t in registered_tables:
            if t["name"] == reg_name:
                tdef = t
                break
        if not tdef:
            raise ValueError(f"Registered table '{reg_name}' not found in connection")
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg, connection_id=connection_id)
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        bucket = cfg["bucket_name"]
        if fmt == "iceberg":
            if _get_s3_mode(cfg) == "presigned":
                raise RuntimeError(
                    f"Iceberg format is not supported for on-prem S3 materialized views. "
                    f"Use parquet format instead (iceberg_scan requires DuckDB native S3 auth "
                    f"which conflicts with on-prem pre-signed URL flow)."
                )
            from_clause = f"iceberg_scan('s3://{bucket}/{prefix}')"
        elif fmt == "csv":
            if _get_s3_mode(cfg) == "presigned":
                from core.s3_utilities import list_s3_csv_files as _mv_list_csv, s3_urls_to_presigned as _mv_presign_csv
                _mv_s3_csv = _make_s3({"id": connection_id, "config": cfg})
                _mv_csv_files = _mv_list_csv(_mv_s3_csv, bucket, prefix)
                if not _mv_csv_files:
                    raise RuntimeError(f"No CSV files found for MV source '{reg_name}' on on-prem S3 under s3://{bucket}/{prefix}/")
                _mv_csv_files = _mv_presign_csv(_mv_s3_csv, _mv_csv_files, cfg)
                _mv_esc_csv = lambda v: v.replace("'", "''")
                _mv_csv_paths = ", ".join(f"'{_mv_esc_csv(f)}'" for f in _mv_csv_files)
                from_clause = f"read_csv_auto([{_mv_csv_paths}])"
            else:
                from_clause = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
        else:
            _esc_pq = lambda v: v.replace("'", "''")
            try:
                _pq_s3 = _make_s3({"id": connection_id, "config": cfg})
                _pq_files = _list_pq(_pq_s3, bucket, prefix)
                _pq_files = _presign(_pq_s3, _pq_files, cfg)
            except Exception as _pq_err:
                _pq_files = []
                if _get_s3_mode(cfg) == "presigned":
                    raise RuntimeError(
                        f"Failed to list parquet files for MV source '{reg_name}' on on-prem S3: {_pq_err}"
                    ) from _pq_err
            if _pq_files:
                _pq_paths = ", ".join(f"'{_esc_pq(f)}'" for f in _pq_files)
                from_clause = f"read_parquet([{_pq_paths}], hive_partitioning=true, union_by_name=true)"
            else:
                if _get_s3_mode(cfg) == "presigned":
                    raise RuntimeError(
                        f"No parquet files found for MV source '{reg_name}' on on-prem S3 under s3://{bucket}/{prefix}/"
                    )
                from_clause = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
        return from_clause, con, True

    # Raw file path — local parquet or csv
    norm = table_path.replace("\\", "/")
    if norm.lower().endswith(".csv"):
        return f"read_csv_auto('{norm}')", None, False
    return f"read_parquet('{norm}', hive_partitioning=true)", None, False
