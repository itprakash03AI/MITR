"""
DuckDB Subprocess Worker — crash-isolated DuckDB execution.

DuckDB's C++ code can crash (access violation / segfault) during httpfs
extension loading or S3 operations, especially on Windows in thread-pool
threads.  A C-level crash kills the entire Python process — no try/except
can catch it.

This module runs DuckDB operations in a **child process**.  If DuckDB
crashes, only the child dies; the main backend survives and returns an
error to the client.

Usage from main.py / worker_pool:

    from core.duckdb_subprocess import run_duckdb_copy_to
    result = run_duckdb_copy_to(conn_config, tables, bucket, sql,
                                 output_path, connection_id, timeout=600)
"""

import json
import logging
import os
import subprocess
import sys
import tempfile
import time as _time

from core.s3_utilities import get_s3_access_mode

logger = logging.getLogger(__name__)

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_duckdb_copy_to(
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str,
    copy_sql: str,
    output_path: str,
    connection_id: int = None,
    timeout: int = 600,
) -> dict:
    """Run a DuckDB COPY TO query in a child process.

    Returns dict with keys: total_rows, file_size_bytes, timing
    Raises RuntimeError on crash or timeout.
    """
    wall_start = _time.monotonic()

    args_payload = {
        "conn_config": conn_config,
        "registered_tables": registered_tables,
        "bucket": bucket,
        "setup_sql": setup_sql,
        "copy_sql": copy_sql,
        "output_path": output_path,
        "connection_id": connection_id,
    }

    # Write args to temp file (avoids command-line length limits)
    args_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", dir=_BACKEND_DIR, delete=False)
    try:
        json.dump(args_payload, args_file)
        args_file.close()

        result_path = args_file.name + ".result.json"

        proc = subprocess.Popen(
            [sys.executable, "-m", "core.duckdb_subprocess", args_file.name, result_path],
            cwd=_BACKEND_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stdout, stderr = proc.communicate(timeout=timeout)
        wall_elapsed = round(_time.monotonic() - wall_start, 2)

        if proc.returncode != 0:
            stderr_text = stderr.decode("utf-8", errors="replace")[-2000:]
            stdout_text = stdout.decode("utf-8", errors="replace")[-2000:]
            logger.error(
                "DuckDB subprocess crashed (exit %d, %.1fs):\nSTDOUT: %s\nSTDERR: %s",
                proc.returncode, wall_elapsed, stdout_text, stderr_text,
            )
            raise RuntimeError(
                f"DuckDB query execution crashed (exit code {proc.returncode}). "
                f"This is a C-level crash in DuckDB — check backend logs for details."
            )

        if not os.path.exists(result_path):
            raise RuntimeError(
                "DuckDB subprocess completed but no result file — possible silent crash"
            )

        with open(result_path, "r") as f:
            result = json.load(f)

        if result.get("error"):
            raise RuntimeError(f"DuckDB query error: {result['error']}")

        # Log timing breakdown from the child process
        timing = result.get("timing", {})
        logger.info(
            "DuckDB subprocess OK: %s rows, %.1f MB, wall=%.1fs "
            "(init=%.1fs creds=%.1fs setup=%.1fs query=%.1fs)",
            f"{result.get('total_rows', 0):,}",
            result.get("file_size_bytes", 0) / 1024 / 1024,
            wall_elapsed,
            timing.get("init_s", 0),
            timing.get("creds_s", 0),
            timing.get("setup_s", 0),
            timing.get("query_s", 0),
        )

        result["timing"]["wall_s"] = wall_elapsed
        return result

    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.communicate(timeout=10)  # wait for OS to release file handles
        except subprocess.TimeoutExpired:
            pass
        raise RuntimeError(f"DuckDB query timed out after {timeout}s")
    finally:
        # Cleanup temp files
        for p in (args_file.name, args_file.name + ".result.json"):
            try:
                os.unlink(p)
            except OSError:
                pass


# ═══════════════════════════════════════════════════════════════════════════════
# CLI entry point — runs in the CHILD process
# ═══════════════════════════════════════════════════════════════════════════════

def _child_main():
    """Entry point when invoked as: python -m core.duckdb_subprocess <args.json> <result.json>"""
    import time as _t

    _t0 = _t.monotonic()

    import duckdb

    args_path = sys.argv[1]
    result_path = sys.argv[2]

    def _write_result(data):
        with open(result_path, "w") as f:
            json.dump(data, f)

    try:
        with open(args_path, "r") as f:
            args = json.load(f)

        conn_config = args["conn_config"]
        setup_sql = args["setup_sql"]
        copy_sql = args["copy_sql"]
        output_path = args["output_path"]

        # Create DuckDB connection + load httpfs (already installed by main process)
        con = duckdb.connect(database=":memory:")

        # Resource limits — read from env vars for container/OpenShift deployments.
        # Leave unset to let DuckDB auto-detect (75% of cgroup memory, all CPUs).
        # Example: DUCKDB_MEMORY_LIMIT=12GB  DUCKDB_THREADS=4
        _mem_limit = os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip()
        _threads   = os.environ.get("DUCKDB_THREADS", "").strip()
        if _mem_limit:
            try:
                con.execute(f"SET memory_limit='{_mem_limit}';")
            except Exception as _e:
                print(f"WARNING: could not set memory_limit={_mem_limit!r}: {_e}", file=sys.stderr)
        if _threads:
            try:
                con.execute(f"SET threads={int(_threads)};")
            except Exception as _e:
                print(f"WARNING: could not set threads={_threads!r}: {_e}", file=sys.stderr)

        try:
            con.execute("LOAD 'httpfs';")
        except Exception:
            # Fallback: install if not yet available (first run)
            con.execute("INSTALL 'httpfs';")
            con.execute("LOAD 'httpfs';")

        _t_init = _t.monotonic()

        # ── S3 credentials ────────────────────────────────────────────────
        # Determine access mode: "presigned" skips S3 credential setup —
        # all reads use pre-signed HTTP URLs (boto3 handles auth).  Setting
        # s3_endpoint + credentials causes DuckDB httpfs to add S3 auth headers
        # on top of pre-signed URLs, corrupting the signature.
        # "native" falls through to normal credential setup (handles path_style
        # via s3_url_style='path').
        _access_mode = get_s3_access_mode(conn_config)
        _skip_s3_creds = (_access_mode == "presigned")
        print(f"SUBPROCESS: S3 access mode={_access_mode} (skip_creds={_skip_s3_creds})", file=sys.stderr, flush=True)
        if _skip_s3_creds:
            print("SUBPROCESS: presigned mode — skipping S3 credential setup", file=sys.stderr, flush=True)
            ssl_val = conn_config.get("ssl_verify", True)
            _ca_path = ""
            if isinstance(ssl_val, str) and ssl_val.lower() not in ("true", "false"):
                _ca_path = ssl_val
            if _ca_path:
                try:
                    con.execute(f"SET ca_cert_file='{_ca_path.replace(chr(39), chr(39)+chr(39))}';")
                except Exception:
                    pass
            else:
                for _ssl_s in ("SET enable_server_cert_verification=false;",
                               "SET enable_curl_server_cert_verification=false;"):
                    try:
                        con.execute(_ssl_s)
                    except Exception:
                        pass
            try:
                con.execute("SET http_keep_alive=true;")
                con.execute("SET http_retries=3;")
                con.execute("SET http_timeout=30000;")
                con.execute("SET enable_http_metadata_cache=true;")
                con.execute("SET enable_object_cache=true;")
            except Exception:
                pass
        else:
            # AWS S3 — set credentials as before
            pass  # fall through to credential setup below

        region = conn_config.get("region_name") or conn_config.get("region") or "us-east-1"
        ep = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")
        auth_mode = (conn_config.get("auth_mode") or "keys").lower()

        key = ""
        secret = ""
        token = ""

        if _skip_s3_creds:
            pass  # already handled above — skip to setup SQL
        elif auth_mode == "keys":
            key = conn_config.get("aws_access_key_id", "")
            secret = conn_config.get("aws_secret_access_key", "")
            token = conn_config.get("aws_session_token", "")
        elif auth_mode in ("profile", "assume_role", "iam_role"):
            try:
                import boto3
                if auth_mode == "assume_role":
                    role_arn = conn_config.get("role_arn")
                    if not role_arn:
                        raise ValueError("role_arn required for assume_role")
                    base_session = boto3.Session(
                        profile_name=conn_config.get("aws_profile") or None,
                        region_name=region,
                    )
                    ssl_val = conn_config.get("ssl_verify", True)
                    sts_verify = not (ssl_val is False or str(ssl_val).lower() == "false")
                    sts = base_session.client("sts", verify=sts_verify)
                    try:
                        assume_kw = {
                            "RoleArn": role_arn,
                            "RoleSessionName": conn_config.get("role_session_name") or "parquet-engine",
                        }
                        if conn_config.get("external_id"):
                            assume_kw["ExternalId"] = conn_config["external_id"]
                        creds = sts.assume_role(**assume_kw)["Credentials"]
                        key = creds["AccessKeyId"]
                        secret = creds["SecretAccessKey"]
                        token = creds["SessionToken"]
                    finally:
                        sts.close()
                else:
                    session = boto3.Session(
                        profile_name=conn_config.get("aws_profile") or None,
                        region_name=region,
                    )
                    resolved = session.get_credentials()
                    if resolved:
                        frozen = resolved.get_frozen_credentials()
                        key = frozen.access_key or ""
                        secret = frozen.secret_key or ""
                        token = frozen.token or ""
            except Exception as exc:
                print(f"WARNING: credential resolution failed: {exc}", file=sys.stderr, flush=True)

        def _esc(v: str) -> str:
            return v.replace("'", "''")

        if not _skip_s3_creds:
            # Native mode — set DuckDB S3 credentials + endpoint
            con.execute(f"SET s3_region='{_esc(region)}';")
            if key:
                con.execute(f"SET s3_access_key_id='{_esc(key)}';")
            if secret:
                con.execute(f"SET s3_secret_access_key='{_esc(secret)}';")
            if token:
                con.execute(f"SET s3_session_token='{_esc(token)}';")
            if ep:
                use_ssl = ep.startswith("https://")
                ep_clean = ep.replace("https://", "").replace("http://", "").rstrip("/")
                con.execute(f"SET s3_endpoint='{_esc(ep_clean)}';")
                force_path = conn_config.get("path_style", False)
                if not use_ssl:
                    con.execute("SET s3_use_ssl=false;")
                    con.execute("SET s3_url_style='path';")
                elif force_path:
                    con.execute("SET s3_url_style='path';")

            # SSL verification — DuckDB httpfs uses its own libcurl which does NOT
            # share Python/boto3's CA trust store.  Disable by default to avoid
            # corporate proxy hangs.  Set ssl_verify to a CA bundle path to override.
            ssl_val = conn_config.get("ssl_verify", True)
            _ca_path = ""
            if isinstance(ssl_val, str) and ssl_val.lower() not in ("true", "false"):
                _ca_path = ssl_val
            if _ca_path:
                try:
                    con.execute(f"SET ca_cert_file='{_esc(_ca_path)}';")
                except Exception:
                    pass
            else:
                for _ssl_setting in (
                    "SET enable_server_cert_verification=false;",
                    "SET enable_curl_server_cert_verification=false;",
                ):
                    try:
                        con.execute(_ssl_setting)
                    except Exception:
                        pass

            # S3 tuning
            try:
                con.execute("SET http_keep_alive=true;")
                con.execute("SET http_retries=3;")
                con.execute("SET http_timeout=30000;")
                con.execute("SET enable_http_metadata_cache=true;")
                con.execute("SET enable_object_cache=true;")
            except Exception:
                pass

        _t_creds = _t.monotonic()

        # ── Setup SQL (CREATE VIEW statements) ────────────────────────────
        if setup_sql:
            for stmt in setup_sql.split(";\n"):
                stmt = stmt.strip()
                if stmt:
                    con.execute(stmt)

        _t_setup = _t.monotonic()

        # ── Execute COPY TO ───────────────────────────────────────────────
        con.execute(copy_sql)

        _t_query = _t.monotonic()

        # ── Read result metadata ──────────────────────────────────────────
        import pyarrow.parquet as pq
        meta = pq.read_metadata(output_path)
        total_rows = meta.num_rows
        file_size = os.path.getsize(output_path)

        _write_result({
            "total_rows": total_rows,
            "file_size_bytes": file_size,
            "timing": {
                "init_s":  round(_t_init - _t0, 2),
                "creds_s": round(_t_creds - _t_init, 2),
                "setup_s": round(_t_setup - _t_creds, 2),
                "query_s": round(_t_query - _t_setup, 2),
                "total_child_s": round(_t_query - _t0, 2),
            },
        })
        con.close()

    except Exception as exc:
        import traceback
        traceback.print_exc(file=sys.stderr)
        _write_result({"error": f"{type(exc).__name__}: {exc}", "timing": {}})
        sys.exit(1)


if __name__ == "__main__":
    _child_main()
