"""
Phase 70B — Circuit breaker state machine tests.
Tests state transitions, thread safety, and edge cases.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from unittest.mock import patch

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))

from core.circuit_breaker import (
    CircuitBreakerRegistry,
    CircuitOpenError,
    CircuitState,
    init_circuit_breaker,
)


@pytest.fixture(autouse=True)
def _reset_circuit_breaker():
    """Reset circuit breaker module state before each test."""
    init_circuit_breaker(enabled=True, failure_threshold=3, cooldown_seconds=60)
    yield


@pytest.fixture()
def registry():
    return CircuitBreakerRegistry()


class TestClosedState:
    def test_new_connection_is_closed(self, registry):
        registry.check(1, "test_conn")
        state = registry.get_state(1)
        assert state["state"] == "closed"

    def test_failures_below_threshold_stay_closed(self, registry):
        registry.check(1, "conn")
        registry.record_failure(1, "err1", "conn")
        registry.record_failure(1, "err2", "conn")
        state = registry.get_state(1)
        assert state["state"] == "closed"
        assert state["failure_count"] == 2

    def test_success_resets_failure_count(self, registry):
        registry.check(1, "conn")
        registry.record_failure(1, "err1", "conn")
        registry.record_failure(1, "err2", "conn")
        registry.record_success(1)
        state = registry.get_state(1)
        assert state["failure_count"] == 0
        assert state["state"] == "closed"


class TestClosedToOpen:
    def test_threshold_failures_opens_circuit(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        state = registry.get_state(1)
        assert state["state"] == "open"

    def test_open_circuit_raises_error(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        with pytest.raises(CircuitOpenError) as exc_info:
            registry.check(1, "conn")
        assert exc_info.value.connection_id == 1
        assert exc_info.value.retry_after > 0


class TestOpenToHalfOpen:
    def test_cooldown_transitions_to_half_open(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        # Simulate cooldown elapsed
        cb = registry._breakers[1]
        cb.last_state_change = time.time() - 61
        # Next check should transition to half_open (not raise)
        registry.check(1, "conn")
        state = registry.get_state(1)
        assert state["state"] == "half_open"


class TestHalfOpenRecovery:
    def test_success_in_half_open_closes_circuit(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        cb = registry._breakers[1]
        cb.last_state_change = time.time() - 61
        registry.check(1, "conn")  # transitions to half_open
        registry.record_success(1)
        state = registry.get_state(1)
        assert state["state"] == "closed"
        assert state["failure_count"] == 0

    def test_failure_in_half_open_reopens_circuit(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        cb = registry._breakers[1]
        cb.last_state_change = time.time() - 61
        registry.check(1, "conn")  # transitions to half_open
        registry.record_failure(1, "probe_fail", "conn")
        state = registry.get_state(1)
        assert state["state"] == "open"

    def test_half_open_limits_probe_calls(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        cb = registry._breakers[1]
        cb.last_state_change = time.time() - 61
        registry.check(1, "conn")  # transitions OPEN→HALF_OPEN (allowed)
        registry.check(1, "conn")  # first actual probe call (allowed, increments counter)
        # Third call exceeds max probe calls
        with pytest.raises(CircuitOpenError):
            registry.check(1, "conn")


class TestManualReset:
    def test_reset_returns_to_closed(self, registry):
        registry.check(1, "conn")
        for i in range(3):
            registry.record_failure(1, f"err{i}", "conn")
        result = registry.reset(1)
        assert result["state"] == "closed"
        assert result["failure_count"] == 0

    def test_reset_unknown_connection_returns_none(self, registry):
        assert registry.reset(999) is None


class TestDisabled:
    def test_disabled_allows_all(self, registry):
        init_circuit_breaker(enabled=False)
        registry.check(1, "conn")
        for i in range(10):
            registry.record_failure(1, f"err{i}", "conn")
        # Should not raise even after many failures
        registry.check(1, "conn")

    def test_disabled_record_success_noop(self, registry):
        init_circuit_breaker(enabled=False)
        registry.record_success(999)  # no-op, no error


class TestGetStates:
    def test_get_all_states(self, registry):
        registry.check(1, "conn_a")
        registry.check(2, "conn_b")
        states = registry.get_all_states()
        assert len(states) == 2
        ids = {s["connection_id"] for s in states}
        assert ids == {1, 2}

    def test_get_unknown_state_returns_none(self, registry):
        assert registry.get_state(999) is None


class TestErrorTruncation:
    def test_long_error_truncated(self, registry):
        registry.check(1, "conn")
        long_error = "x" * 1000
        registry.record_failure(1, long_error, "conn")
        state = registry.get_state(1)
        assert len(state["last_error"]) == 500
