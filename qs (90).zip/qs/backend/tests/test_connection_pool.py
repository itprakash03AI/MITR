"""
Phase 70C — Connection pool tests.
Tests pool creation, reuse, exhaustion, eviction, and thread safety.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))

from core.connection_pool import (
    ConnectorPool,
    PoolManager,
    init_connection_pool,
)


@pytest.fixture(autouse=True)
def _reset_pool():
    init_connection_pool(enabled=True, max_size=3, idle_timeout_seconds=300)
    yield


@pytest.fixture()
def mock_connector():
    """Create a mock connector with a close method."""
    c = MagicMock()
    c.close = MagicMock()
    return c


class TestConnectorPool:
    @patch("core.connectors.get_connector")
    def test_acquire_creates_connector(self, mock_get_conn):
        mock_get_conn.return_value = MagicMock()
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")
        conn = pool.acquire()
        assert conn is not None
        mock_get_conn.assert_called_once()

    @patch("core.connectors.get_connector")
    def test_release_and_reuse(self, mock_get_conn):
        first_conn = MagicMock()
        mock_get_conn.return_value = first_conn
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        conn1 = pool.acquire()
        pool.release(conn1)

        # Second acquire should reuse the released connector
        conn2 = pool.acquire()
        assert conn2 is first_conn
        # get_connector should only be called once (not twice)
        assert mock_get_conn.call_count == 1

    @patch("core.connectors.get_connector")
    def test_discard_does_not_reuse(self, mock_get_conn):
        first_conn = MagicMock()
        second_conn = MagicMock()
        mock_get_conn.side_effect = [first_conn, second_conn]
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        conn1 = pool.acquire()
        pool.discard(conn1)
        first_conn.close.assert_called_once()

        conn2 = pool.acquire()
        assert conn2 is second_conn

    @patch("core.connectors.get_connector")
    def test_pool_exhaustion_timeout(self, mock_get_conn):
        init_connection_pool(enabled=True, max_size=1, idle_timeout_seconds=300)
        mock_get_conn.return_value = MagicMock()
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        conn1 = pool.acquire()
        # Pool is full (1 active), should timeout
        with pytest.raises(TimeoutError):
            pool.acquire(timeout=0.3)

    @patch("core.connectors.get_connector")
    def test_invalidate_closes_idle(self, mock_get_conn):
        conns = [MagicMock() for _ in range(2)]
        mock_get_conn.side_effect = conns
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        c1 = pool.acquire()
        c2 = pool.acquire()
        pool.release(c1)
        pool.release(c2)

        pool.invalidate()
        for c in conns:
            c.close.assert_called_once()
        assert pool.stats()["idle"] == 0

    @patch("core.connectors.get_connector")
    def test_stats_accuracy(self, mock_get_conn):
        mock_get_conn.return_value = MagicMock()
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        c1 = pool.acquire()
        stats = pool.stats()
        assert stats["active"] == 1
        assert stats["idle"] == 0

        pool.release(c1)
        stats = pool.stats()
        assert stats["active"] == 0
        assert stats["idle"] == 1

    @patch("core.connectors.get_connector")
    def test_idle_eviction(self, mock_get_conn):
        init_connection_pool(enabled=True, max_size=3, idle_timeout_seconds=1)
        mock_get_conn.return_value = MagicMock()
        pool = ConnectorPool(1, "snowflake", {"host": "h"}, "test")

        c = pool.acquire()
        pool.release(c)
        # Simulate time passing beyond idle timeout
        pool._idle[0].last_used = time.time() - 2
        # Next acquire should evict the expired entry and create fresh
        new_conn = MagicMock()
        mock_get_conn.return_value = new_conn
        c2 = pool.acquire()
        assert c2 is new_conn


class TestPoolManager:
    def test_get_pool_creates_and_caches(self):
        pm = PoolManager()
        pool1 = pm.get_pool(1, "snowflake", {}, "conn1")
        pool2 = pm.get_pool(1, "snowflake", {}, "conn1")
        assert pool1 is pool2

    def test_invalidate_removes_pool(self):
        pm = PoolManager()
        pm.get_pool(1, "snowflake", {}, "conn1")
        pm.invalidate_pool(1)
        stats = pm.get_all_stats()
        assert len(stats) == 0

    def test_shutdown_clears_all(self):
        pm = PoolManager()
        pm.get_pool(1, "snowflake", {}, "conn1")
        pm.get_pool(2, "trino", {}, "conn2")
        pm.shutdown()
        assert len(pm.get_all_stats()) == 0

    def test_get_all_stats(self):
        pm = PoolManager()
        pm.get_pool(1, "snowflake", {}, "conn1")
        pm.get_pool(2, "trino", {}, "conn2")
        stats = pm.get_all_stats()
        assert len(stats) == 2
