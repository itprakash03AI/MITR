"""
Phase 70E — Checkpoint system tests.
Tests intent recording, state transitions, and startup recovery.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))

from core.checkpoint import (
    init_checkpoint,
    mark_completed,
    mark_started,
    record_intent,
    recover_incomplete,
)


@pytest.fixture()
def mock_db():
    db = MagicMock()
    db.set_checkpoint = MagicMock()
    db.update_checkpoint = MagicMock()
    db.delete_checkpoint = MagicMock()
    db.get_all_checkpoints = MagicMock(return_value=[])
    db.update_execution = MagicMock()
    init_checkpoint(db)
    yield db
    init_checkpoint(None)  # cleanup


class TestRecordIntent:
    def test_records_intent_state(self, mock_db):
        record_intent("exec-1", {"sql": "SELECT 1"}, "user1")
        mock_db.set_checkpoint.assert_called_once()
        args = mock_db.set_checkpoint.call_args
        assert args[1]["execution_id"] == "exec-1"
        assert args[1]["state"] == "intent"

    def test_noop_when_no_db(self):
        init_checkpoint(None)
        record_intent("exec-1", {})  # should not raise

    def test_swallows_db_errors(self, mock_db):
        mock_db.set_checkpoint.side_effect = RuntimeError("DB error")
        record_intent("exec-1", {})  # should not raise


class TestMarkStarted:
    def test_updates_to_running(self, mock_db):
        mark_started("exec-1")
        mock_db.update_checkpoint.assert_called_once()
        args = mock_db.update_checkpoint.call_args
        assert args[0][0] == "exec-1"
        assert args[1]["state"] == "running"

    def test_noop_when_no_db(self):
        init_checkpoint(None)
        mark_started("exec-1")


class TestMarkCompleted:
    def test_deletes_checkpoint(self, mock_db):
        mark_completed("exec-1")
        mock_db.delete_checkpoint.assert_called_once_with("exec-1")

    def test_noop_when_no_db(self):
        init_checkpoint(None)
        mark_completed("exec-1")


class TestRecoverIncomplete:
    def test_recovers_orphaned_executions(self, mock_db):
        mock_db.get_all_checkpoints.return_value = [
            {"execution_id": "exec-1", "state": "running"},
            {"execution_id": "exec-2", "state": "intent"},
        ]
        count = recover_incomplete()
        assert count == 2
        # Should mark both as failed
        calls = mock_db.update_execution.call_args_list
        assert len(calls) == 2
        for c in calls:
            assert c[1]["status"] == "failed"
            assert "Server restarted" in c[1]["error_message"]
        # Should delete both checkpoints
        assert mock_db.delete_checkpoint.call_count == 2

    def test_no_orphans_returns_zero(self, mock_db):
        mock_db.get_all_checkpoints.return_value = []
        assert recover_incomplete() == 0

    def test_handles_missing_execution_record(self, mock_db):
        """If execution record doesn't exist, recovery should continue."""
        mock_db.get_all_checkpoints.return_value = [
            {"execution_id": "exec-1", "state": "running"},
        ]
        mock_db.update_execution.side_effect = RuntimeError("Not found")
        count = recover_incomplete()
        assert count == 1  # Still counts as recovered
        mock_db.delete_checkpoint.assert_called_once()

    def test_returns_zero_when_no_db(self):
        init_checkpoint(None)
        assert recover_incomplete() == 0

    def test_db_error_returns_zero(self, mock_db):
        mock_db.get_all_checkpoints.side_effect = RuntimeError("DB crashed")
        assert recover_incomplete() == 0
