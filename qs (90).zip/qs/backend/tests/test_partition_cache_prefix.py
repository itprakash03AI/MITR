"""Tests for partition cache s3_prefix fix (Bug 1 — cache key collision).

Verifies that tables at different S3 prefixes get separate cache entries
in both L1 (in-memory) and L2 (SQLite).
"""
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone


class TestPartitionCacheModel:
    """Test the PartitionCache model has s3_prefix in its unique index."""

    def test_partition_cache_has_s3_prefix_column(self):
        from core.db.models import PartitionCache
        assert hasattr(PartitionCache, "s3_prefix")

    def test_partition_cache_to_dict_includes_s3_prefix(self):
        from core.db.models import PartitionCache
        entry = PartitionCache(
            connection_id=1, table_name="t1", s3_prefix="data/sales/",
            scan_type="fast", partition_data={"cols": []},
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        d = entry.to_dict()
        assert "s3_prefix" in d
        assert d["s3_prefix"] == "data/sales/"

    def test_partition_cache_default_s3_prefix(self):
        from core.db.models import PartitionCache
        entry = PartitionCache(
            connection_id=1, table_name="t1",
            scan_type="fast", partition_data={},
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        assert entry.s3_prefix == "" or entry.s3_prefix is None  # default


class TestPartitionCacheDB:
    """Test L2 (SQLite) cache operations with s3_prefix."""

    @pytest.fixture
    def db(self, tmp_path):
        from core.database import DatabaseManager
        db_file = tmp_path / "test.db"
        mgr = DatabaseManager(f"sqlite:///{db_file}")
        return mgr

    def test_set_and_get_with_prefix(self, db):
        """Same table name + different s3_prefix → separate entries."""
        db.set_partition_cache(1, "orders", "fast", {"files": ["/a"]}, s3_prefix="warehouse1/orders/")
        db.set_partition_cache(1, "orders", "fast", {"files": ["/b"]}, s3_prefix="warehouse2/orders/")

        entry1 = db.get_partition_cache(1, "orders", "fast", s3_prefix="warehouse1/orders/")
        entry2 = db.get_partition_cache(1, "orders", "fast", s3_prefix="warehouse2/orders/")

        assert entry1 is not None
        assert entry2 is not None
        assert entry1["partition_data"]["files"] == ["/a"]
        assert entry2["partition_data"]["files"] == ["/b"]

    def test_get_without_prefix_returns_default(self, db):
        """get with default prefix returns only default-prefix entries."""
        db.set_partition_cache(1, "t1", "fast", {"data": "default"}, s3_prefix="")
        db.set_partition_cache(1, "t1", "fast", {"data": "prefixed"}, s3_prefix="some/prefix/")

        entry_default = db.get_partition_cache(1, "t1", "fast", s3_prefix="")
        entry_prefixed = db.get_partition_cache(1, "t1", "fast", s3_prefix="some/prefix/")

        assert entry_default["partition_data"]["data"] == "default"
        assert entry_prefixed["partition_data"]["data"] == "prefixed"

    def test_upsert_with_prefix(self, db):
        """Upsert updates the correct prefix entry, not a different one."""
        db.set_partition_cache(1, "t1", "fast", {"v": 1}, s3_prefix="a/")
        db.set_partition_cache(1, "t1", "fast", {"v": 2}, s3_prefix="b/")

        # Update prefix a/
        db.set_partition_cache(1, "t1", "fast", {"v": 10}, s3_prefix="a/")

        a = db.get_partition_cache(1, "t1", "fast", s3_prefix="a/")
        b = db.get_partition_cache(1, "t1", "fast", s3_prefix="b/")
        assert a["partition_data"]["v"] == 10
        assert b["partition_data"]["v"] == 2  # unchanged

    def test_delete_with_prefix_filter(self, db):
        db.set_partition_cache(1, "t1", "fast", {"v": 1}, s3_prefix="a/")
        db.set_partition_cache(1, "t1", "fast", {"v": 2}, s3_prefix="b/")

        deleted = db.delete_partition_cache(connection_id=1, table_name="t1", s3_prefix="a/")
        assert deleted == 1

        assert db.get_partition_cache(1, "t1", "fast", s3_prefix="a/") is None
        assert db.get_partition_cache(1, "t1", "fast", s3_prefix="b/") is not None

    def test_delete_without_prefix_deletes_all(self, db):
        db.set_partition_cache(1, "t1", "fast", {"v": 1}, s3_prefix="a/")
        db.set_partition_cache(1, "t1", "fast", {"v": 2}, s3_prefix="b/")

        deleted = db.delete_partition_cache(connection_id=1, table_name="t1")
        assert deleted == 2

    def test_migration_entry_exists(self):
        """The _MIGRATIONS dict should include partition_cache with s3_prefix."""
        from core.database import DatabaseManager
        migrations = DatabaseManager._MIGRATIONS.get("partition_cache", [])
        col_names = [col[0] for col in migrations]
        assert "s3_prefix" in col_names


class TestL1CacheKeyFormat:
    """Test that L1 cache keys include s3_prefix."""

    def test_cache_key_includes_prefix(self):
        """Cache key format should be connection_id:table_name:s3_prefix:scan_type."""
        conn_id, table_name, s3_prefix, scan_type = 5, "orders", "data/v2/orders/", "fast"
        cache_key = f"{conn_id}:{table_name}:{s3_prefix}:{scan_type}"
        assert cache_key == "5:orders:data/v2/orders/:fast"

    def test_different_prefixes_different_keys(self):
        """Same table at different prefixes should produce different cache keys."""
        key1 = f"1:orders:warehouse1/orders/:fast"
        key2 = f"1:orders:warehouse2/orders/:fast"
        assert key1 != key2

    def test_empty_prefix_key(self):
        """Empty prefix should still produce a valid key (not '::')."""
        key = f"1:orders::fast"  # empty s3_prefix
        assert key == "1:orders::fast"
