"""Tests for zero-file guard (Bug 2 — skip COPY TO when 0 files after pruning).

Verifies that:
- setup_registered_views() returns all_primary_empty correctly
- register_s3_views() returns all_primary_empty correctly
- execute_registered_table_copy_to() writes empty parquet when all_primary_empty
"""
import pytest
from unittest.mock import MagicMock, patch, PropertyMock
import os


class TestSetupRegisteredViewsEmptyFlag:
    """Test the all_primary_empty flag in setup_registered_views() return tuple."""

    def test_returns_4_element_tuple(self):
        """setup_registered_views() should return (con, sql, auto_part, all_primary_empty)."""
        from core.duckdb_views import setup_registered_views
        # Verify the function signature accepts the right params
        import inspect
        sig = inspect.signature(setup_registered_views)
        params = list(sig.parameters.keys())
        assert "engine" in params
        assert "query_config" in params
        assert "con" in params


class TestRegisterS3ViewsEmptyTuple:
    """Test the register_s3_views() return value is now a tuple."""

    def test_returns_tuple(self):
        """register_s3_views() should return (total_records, all_primary_empty)."""
        from core.duckdb_views import register_s3_views
        import inspect
        sig = inspect.signature(register_s3_views)
        params = list(sig.parameters.keys())
        assert "primary_tables" in params
        assert "partition_filters" in params


class TestZeroFileGuardLogic:
    """Test the zero-file guard boolean logic."""

    def test_no_primary_tables_not_empty(self):
        """When there are no primary tables, all_primary_empty should be False."""
        _primary_tables = set()
        _all_primary_empty = bool(_primary_tables)
        assert _all_primary_empty is False

    def test_primary_tables_with_data_not_empty(self):
        """When a primary table has data, all_primary_empty should be False."""
        _primary_tables = {"orders"}
        _all_primary_empty = bool(_primary_tables)
        _any_primary_with_data = True
        _all_primary_empty = _all_primary_empty and not _any_primary_with_data
        assert _all_primary_empty is False

    def test_primary_tables_all_pruned_is_empty(self):
        """When all primary tables are pruned to 0 files, all_primary_empty is True."""
        _primary_tables = {"orders"}
        _all_primary_empty = bool(_primary_tables)
        _any_primary_with_data = False
        _all_primary_empty = _all_primary_empty and not _any_primary_with_data
        assert _all_primary_empty is True

    def test_multiple_primary_one_with_data_not_empty(self):
        """If any primary table has data, all_primary_empty is False."""
        _primary_tables = {"orders", "customers"}
        _all_primary_empty = bool(_primary_tables)
        _any_primary_with_data = True  # at least one has data
        _all_primary_empty = _all_primary_empty and not _any_primary_with_data
        assert _all_primary_empty is False


class TestEmptyParquetWrite:
    """Test that empty parquet files are written correctly."""

    def test_write_empty_parquet(self, tmp_path):
        """Verify we can write and read back an empty parquet file."""
        import pyarrow as pa
        import pyarrow.parquet as pq

        output = tmp_path / "empty.parquet"
        empty_table = pa.table({"_empty": pa.array([], type=pa.int32())})
        pq.write_table(empty_table, str(output), compression="ZSTD")

        assert output.exists()
        assert output.stat().st_size > 0

        # Read it back
        read_back = pq.read_table(str(output))
        assert len(read_back) == 0
        assert "_empty" in read_back.column_names

    def test_empty_result_dict_format(self):
        """Verify the empty result dict has the expected keys."""
        result = {
            "total_rows": 0,
            "file_size_bytes": 200,
            "status": "completed",
            "chunks_processed": 0,
            "all_primary_empty": True,
        }
        assert result["total_rows"] == 0
        assert result["all_primary_empty"] is True
        assert result["status"] == "completed"


class TestStreamingEmptyResult:
    """Test that streaming endpoints return empty results when all_primary_empty."""

    def test_stream_empty_result_format(self):
        """Stream endpoint should return columns=[], rows=[] when empty."""
        result = {"columns": [], "rows": [], "all_primary_empty": True}
        assert result["columns"] == []
        assert result["rows"] == []
        assert result["all_primary_empty"] is True

    def test_chart_empty_result_format(self):
        """Chart endpoint should return matching normal-path keys when empty."""
        result = {"x_col": "region", "y_col": "revenue", "agg": "sum",
                  "multi": False, "grand_total": 0, "data": [],
                  "all_primary_empty": True}
        assert result["data"] == []
        assert result["grand_total"] == 0
        assert result["multi"] is False

    def test_schema_empty_result_format(self):
        """Schema endpoint should return total_columns=0, estimated_rows=0 when empty."""
        result = {"columns": [], "total_columns": 0, "estimated_rows": 0, "all_primary_empty": True}
        assert result["total_columns"] == 0
        assert result["estimated_rows"] == 0

    def test_paginated_empty_result_format(self):
        """Paginated endpoint should return total_rows=0 when empty."""
        result = {"columns": [], "rows": [], "total_rows": 0, "filtered_rows": 0,
                  "page": 1, "page_size": 100, "total_pages": 0, "streaming": True,
                  "elapsed_seconds": 0.0, "all_primary_empty": True}
        assert result["total_rows"] == 0
        assert result["total_pages"] == 0

    def test_pivot_empty_result_format(self):
        """Pivot endpoint should return matching normal-path keys when empty."""
        result = {"row_fields": ["region"], "col_field": None,
                  "values": [{"function": "sum", "column": "revenue"}],
                  "total_rows": 0, "rows": [], "col_values": [],
                  "grand_totals": {}, "all_primary_empty": True}
        assert result["rows"] == []
        assert result["total_rows"] == 0
        assert result["grand_totals"] == {}
