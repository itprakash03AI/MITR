"""
Phase 70F — Config validation tests.
Tests validate_config() for type checks, range checks, enum checks, unknown sections.
"""
from __future__ import annotations

import importlib
import json
import os
import sys
from pathlib import Path

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))


def _load_config_with(overrides: dict, tmp_path: Path) -> list:
    """Write a config.json with overrides, reload config module, run validate_config()."""
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(json.dumps(overrides))
    os.environ["QUERYSTUDIO_CONFIG"] = str(cfg_file)
    import core.config as cfg_mod
    cfg_mod._cfg = None
    importlib.reload(cfg_mod)
    try:
        return cfg_mod.validate_config()
    finally:
        os.environ.pop("QUERYSTUDIO_CONFIG", None)


class TestValidConfig:
    def test_default_config_has_no_issues(self, tmp_path):
        issues = _load_config_with({}, tmp_path)
        assert issues == []


class TestEnumValidation:
    def test_invalid_database_type(self, tmp_path):
        issues = _load_config_with({"database": {"type": "mysql"}}, tmp_path)
        matched = [i for i in issues if "database.type" in i]
        assert len(matched) == 1
        assert "mysql" in matched[0]

    def test_valid_database_type(self, tmp_path):
        issues = _load_config_with({"database": {"type": "postgresql"}}, tmp_path)
        matched = [i for i in issues if "database.type" in i]
        assert len(matched) == 0

    def test_invalid_auth_type(self, tmp_path):
        issues = _load_config_with({"auth": {"type": "oauth"}}, tmp_path)
        matched = [i for i in issues if "auth.type" in i]
        assert len(matched) == 1

    def test_invalid_log_level(self, tmp_path):
        issues = _load_config_with({"server": {"log_level": "verbose"}}, tmp_path)
        matched = [i for i in issues if "log_level" in i]
        assert len(matched) == 1


class TestRangeValidation:
    def test_port_too_high(self, tmp_path):
        issues = _load_config_with({"server": {"port": 99999}}, tmp_path)
        matched = [i for i in issues if "port" in i]
        assert len(matched) == 1

    def test_port_valid(self, tmp_path):
        issues = _load_config_with({"server": {"port": 8080}}, tmp_path)
        matched = [i for i in issues if "port" in i and "out of range" in i]
        assert len(matched) == 0

    def test_workers_too_high(self, tmp_path):
        issues = _load_config_with({"server": {"workers": 100}}, tmp_path)
        matched = [i for i in issues if "workers" in i]
        assert len(matched) == 1

    def test_negative_pool_size(self, tmp_path):
        issues = _load_config_with({"database": {"postgresql_pool_size": -1}}, tmp_path)
        matched = [i for i in issues if "pool_size" in i]
        assert len(matched) == 1


class TestUnknownSections:
    def test_unknown_section_detected(self, tmp_path):
        issues = _load_config_with({"typo_section": {"key": "val"}}, tmp_path)
        matched = [i for i in issues if "typo_section" in i and "unknown" in i]
        assert len(matched) == 1

    def test_known_section_not_flagged(self, tmp_path):
        issues = _load_config_with({"server": {"port": 8080}}, tmp_path)
        matched = [i for i in issues if "unknown" in i.lower()]
        assert len(matched) == 0
