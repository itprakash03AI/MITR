"""Tests for read replica separation (Phase 43)."""
import pytest
from unittest.mock import MagicMock, patch
from contextlib import contextmanager


class TestGetSessionReadOnly:
    """Test get_session(read_only=True) routing."""

    def test_read_only_false_uses_primary(self, tmp_path):
        """read_only=False always uses primary session."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        with db.get_session(read_only=False) as s:
            assert s is not None
        # No replicas configured — should work fine

    def test_read_only_true_no_replicas_uses_primary(self, tmp_path):
        """read_only=True with no replicas falls back to primary."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        assert len(db._replica_engines) == 0
        with db.get_session(read_only=True) as s:
            assert s is not None

    def test_read_only_true_sqlite_sets_query_only(self, tmp_path):
        """SQLite read_only sessions should attempt PRAGMA query_only."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        with db.get_session(read_only=True) as s:
            # Should not raise — query_only ON then OFF
            result = s.execute(__import__('sqlalchemy').text("SELECT 1")).fetchone()
            assert result[0] == 1

    def test_replica_health_initially_empty(self, tmp_path):
        """No replicas → empty health list."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        assert db._replica_health == []
        assert db._replica_engines == []

    def test_get_replica_status_empty(self, tmp_path):
        """get_replica_status() returns empty list when no replicas."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        assert db.get_replica_status() == []

    def test_next_read_session_no_replicas(self, tmp_path):
        """_next_read_session returns None when no replicas."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        assert db._next_read_session() is None

    def test_round_robin_with_mock_replicas(self, tmp_path):
        """Round-robin picks replicas in order."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        # Mock 2 healthy replicas
        mock_session1 = MagicMock()
        mock_session2 = MagicMock()
        db._replica_engines = [MagicMock(), MagicMock()]
        db._replica_sessions = [MagicMock(return_value=mock_session1), MagicMock(return_value=mock_session2)]
        db._replica_health = [True, True]

        s1 = db._next_read_session()
        s2 = db._next_read_session()
        assert s1 == mock_session1
        assert s2 == mock_session2

    def test_round_robin_skips_unhealthy(self, tmp_path):
        """Round-robin skips unhealthy replicas."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        mock_session2 = MagicMock()
        db._replica_engines = [MagicMock(), MagicMock()]
        db._replica_sessions = [MagicMock(), MagicMock(return_value=mock_session2)]
        db._replica_health = [False, True]  # first unhealthy

        s = db._next_read_session()
        assert s == mock_session2

    def test_all_unhealthy_returns_none(self, tmp_path):
        """All replicas unhealthy → returns None (falls back to primary)."""
        from core.database import DatabaseManager
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        db._replica_engines = [MagicMock(), MagicMock()]
        db._replica_sessions = [MagicMock(), MagicMock()]
        db._replica_health = [False, False]

        assert db._next_read_session() is None


class TestDatabaseConfigReplica:
    """Test replica config properties."""

    def test_replica_urls_default_empty(self):
        from core.config import database
        urls = database.replica_urls
        assert isinstance(urls, list)

    def test_read_preference_default(self):
        from core.config import database
        assert database.read_preference in ("primary", "replica", "primary_preferred")

    def test_replica_pool_defaults(self):
        from core.config import database
        assert database.replica_pool_size == 10
        assert database.replica_max_overflow == 15
        assert database.replica_pool_timeout == 20

    def test_replica_health_defaults(self):
        from core.config import database
        assert database.replica_health_interval_seconds == 30
        assert database.replica_max_lag_seconds == 5
