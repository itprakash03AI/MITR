"""
Phase 70A — Regression tests for audit bugs A1-A7.
Ensures each fix stays fixed by testing the corrected behavior directly.
"""
from __future__ import annotations

import inspect
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))


# ---------------------------------------------------------------------------
# A1: datasets_api — auto_detect uses cm.get_schema() (not get_file_schema)
# ---------------------------------------------------------------------------
class TestA1_AutoDetectMethodName:
    """The _read_connection_schema() helper must call cm.get_schema(), not cm.get_file_schema()."""

    def test_read_connection_schema_calls_get_schema(self):
        from api.datasets_api import _read_connection_schema
        src = inspect.getsource(_read_connection_schema)
        assert "get_schema" in src, "_read_connection_schema must call get_schema"
        assert "get_file_schema" not in src, "get_file_schema is the old broken name"


# ---------------------------------------------------------------------------
# A2: database.py — increment_business_report_execution is distinct
# ---------------------------------------------------------------------------
class TestA2_ReportExecutionMethods:
    """BusinessReport and parametric Report execution counters must be separate methods."""

    def test_business_report_method_exists(self, db_manager):
        assert hasattr(db_manager, "increment_business_report_execution"), \
            "DatabaseManager must have increment_business_report_execution"

    def test_parametric_report_method_exists(self, db_manager):
        assert hasattr(db_manager, "increment_report_execution"), \
            "DatabaseManager must have increment_report_execution for parametric reports"

    def test_methods_are_distinct(self, db_manager):
        biz = db_manager.increment_business_report_execution
        param = db_manager.increment_report_execution
        assert biz is not param, "The two methods must not be the same function"

    def test_business_report_increments(self, db_manager):
        """Create a BusinessReport and verify execution count increments."""
        br = db_manager.create_business_report(
            name="A2 Regression Test Report",
            dataset_id=0,
            owner="test",
        )
        assert br["execution_count"] == 0
        db_manager.increment_business_report_execution(br["id"])
        updated = db_manager.get_business_report(br["id"])
        assert updated["execution_count"] == 1


# ---------------------------------------------------------------------------
# A3: delivery_engine — record_alert() (not record_alert_history)
# ---------------------------------------------------------------------------
class TestA3_RecordAlertMethodName:
    """DatabaseManager must have record_alert(), not record_alert_history()."""

    def test_record_alert_exists(self, db_manager):
        assert hasattr(db_manager, "record_alert"), \
            "DatabaseManager must have record_alert method"

    def test_record_alert_history_does_not_exist(self, db_manager):
        assert not hasattr(db_manager, "record_alert_history"), \
            "record_alert_history should not exist — it was the old broken name"

    def test_record_alert_accepts_suppressed_param(self):
        from core.database import DatabaseManager
        sig = inspect.signature(DatabaseManager.record_alert)
        assert "suppressed" in sig.parameters, \
            "record_alert must accept 'suppressed' keyword argument"


# ---------------------------------------------------------------------------
# A4: database.py — list_alert_rules() has no enabled_only param
# ---------------------------------------------------------------------------
class TestA4_ListAlertRulesSignature:
    """list_alert_rules() must not accept enabled_only — filtering happens in Python."""

    def test_no_enabled_only_param(self):
        from core.database import DatabaseManager
        sig = inspect.signature(DatabaseManager.list_alert_rules)
        assert "enabled_only" not in sig.parameters, \
            "list_alert_rules must not have enabled_only param (A4 regression)"

    def test_accepts_report_id(self):
        from core.database import DatabaseManager
        sig = inspect.signature(DatabaseManager.list_alert_rules)
        assert "report_id" in sig.parameters


# ---------------------------------------------------------------------------
# A5: subscription_api — all endpoints have Depends() auth
# ---------------------------------------------------------------------------
class TestA5_SubscriptionAuth:
    """All subscription_api endpoints must have FastAPI Depends() auth injection."""

    # Public endpoints that intentionally skip auth (e.g. unsubscribe links)
    PUBLIC_PATHS = {"/api/unsubscribe/{token}"}

    def test_endpoints_have_auth_dependency(self):
        from api.subscription_api import router
        for route in router.routes:
            if not hasattr(route, "dependant"):
                continue
            if route.path in self.PUBLIC_PATHS:
                continue
            # Check that at least one dependency references get_current_user or require_admin
            dep_names = []
            for dep in route.dependant.dependencies:
                if hasattr(dep, "call") and hasattr(dep.call, "__name__"):
                    dep_names.append(dep.call.__name__)
            has_auth = any(n in ("get_current_user", "require_admin") for n in dep_names)
            assert has_auth, (
                f"Endpoint {route.path} ({route.methods}) is missing auth Depends() "
                f"(found deps: {dep_names})"
            )


# ---------------------------------------------------------------------------
# A6: suggest_api — last_result_info extracts SQL from query_config
# ---------------------------------------------------------------------------
class TestA6_LastResultSqlExtraction:
    """The /api/suggest/last-result endpoint must extract SQL from query_config, not row.sql."""

    def test_source_does_not_reference_row_dot_sql(self):
        from api import suggest_api
        src = inspect.getsource(suggest_api.last_result_info)
        # Ensure it doesn't naively access row.sql
        assert "row.sql" not in src.replace("query_config", ""), \
            "last_result_info must not access row.sql (A6 regression)"

    def test_source_reads_query_config(self):
        from api import suggest_api
        src = inspect.getsource(suggest_api.last_result_info)
        assert "query_config" in src, \
            "last_result_info must extract SQL from query_config dict"


# ---------------------------------------------------------------------------
# A7: execute_stream_api — stream_paginate resolves date filters
# ---------------------------------------------------------------------------
class TestA7_StreamPaginateDateResolution:
    """Stream paginate must call resolve date functions for adv_filters."""

    def test_source_resolves_dates(self):
        from api import execute_stream_api
        src = inspect.getsource(execute_stream_api)
        assert "resolve" in src.lower(), \
            "execute_stream_api must contain date resolution logic"
        # Check for the specific resolve function
        assert "resolve_filter_dates" in src or "resolve_value" in src or "resolve_adv_filters" in src, \
            "Must call a date resolution function (A7 regression)"
