"""
Phase 70C — Anomaly detector tests.
Tests z-score calculations, detection types, and edge cases.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))

from core.anomaly_detector import (
    AnomalyResult,
    _compute_stats,
    check_anomalies,
    init_anomaly_detector,
)


@pytest.fixture(autouse=True)
def _reset():
    init_anomaly_detector(enabled=True, z_score_threshold=2.5,
                          min_history_runs=5, window_size=20)
    yield


def _mock_db(history: list):
    db = MagicMock()
    db.get_schedule_run_stats.return_value = history
    return db


class TestComputeStats:
    def test_empty_list(self):
        mean, std = _compute_stats([])
        assert mean == 0.0
        assert std == 0.0

    def test_single_value(self):
        mean, std = _compute_stats([10])
        assert mean == 10.0
        assert std == 0.0

    def test_multiple_values(self):
        vals = [10, 20, 30]
        mean, std = _compute_stats(vals)
        assert mean == 20.0
        assert std == pytest.approx(10.0, rel=0.01)

    def test_sample_stddev(self):
        """Uses n-1 denominator (sample stddev)."""
        vals = [2, 4, 4, 4, 5, 5, 7, 9]
        mean, std = _compute_stats(vals)
        assert mean == 5.0
        expected_var = sum((v - 5) ** 2 for v in vals) / (len(vals) - 1)
        assert std == pytest.approx(math.sqrt(expected_var), rel=0.001)


class TestZeroRows:
    def test_zero_rows_when_historical_mean_positive(self):
        history = [{"row_count": 100, "execution_seconds": 2.0}] * 6
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=0, current_exec_seconds=2.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "zero_rows" in types
        zr = next(r for r in results if r.anomaly_type == "zero_rows")
        assert zr.severity == "critical"
        assert zr.current_value == 0

    def test_no_zero_rows_when_history_also_zero(self):
        history = [{"row_count": 0, "execution_seconds": 1.0}] * 6
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=0, current_exec_seconds=1.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "zero_rows" not in types


class TestRowCountSpike:
    def test_spike_detected(self):
        history = [{"row_count": 100, "execution_seconds": 2.0}] * 10
        db = _mock_db(history)
        # All history is 100 rows, stddev is 0 — need variance
        history2 = [{"row_count": 100 + i, "execution_seconds": 2.0} for i in range(10)]
        db2 = _mock_db(history2)
        results = check_anomalies(1, current_row_count=10000, current_exec_seconds=2.0, db_manager=db2)
        types = [r.anomaly_type for r in results]
        assert "row_count_spike" in types

    def test_no_spike_within_normal_range(self):
        history = [{"row_count": v, "execution_seconds": 2.0} for v in range(90, 111)]
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=105, current_exec_seconds=2.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "row_count_spike" not in types


class TestRowCountDrop:
    def test_drop_detected(self):
        history = [{"row_count": 1000 + i * 10, "execution_seconds": 2.0} for i in range(10)]
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=1, current_exec_seconds=2.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "row_count_drop" in types

    def test_drop_not_reported_for_zero_rows(self):
        """Zero rows is reported as 'zero_rows' not 'row_count_drop'."""
        history = [{"row_count": 1000, "execution_seconds": 2.0}] * 6
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=0, current_exec_seconds=2.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "row_count_drop" not in types


class TestSlowExecution:
    def test_slow_detected(self):
        history = [{"row_count": 100, "execution_seconds": 2.0 + i * 0.1} for i in range(10)]
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=100, current_exec_seconds=50.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "slow_execution" in types

    def test_not_slow_within_range(self):
        history = [{"row_count": 100, "execution_seconds": v} for v in range(1, 12)]
        db = _mock_db(history)
        results = check_anomalies(1, current_row_count=100, current_exec_seconds=6.0, db_manager=db)
        types = [r.anomaly_type for r in results]
        assert "slow_execution" not in types


class TestEdgeCases:
    def test_insufficient_history_returns_empty(self):
        history = [{"row_count": 100, "execution_seconds": 2.0}] * 3
        db = _mock_db(history)
        assert check_anomalies(1, 100, 2.0, db) == []

    def test_disabled_returns_empty(self):
        init_anomaly_detector(enabled=False)
        history = [{"row_count": 100, "execution_seconds": 2.0}] * 10
        db = _mock_db(history)
        assert check_anomalies(1, 0, 100.0, db) == []

    def test_db_error_returns_empty(self):
        db = MagicMock()
        db.get_schedule_run_stats.side_effect = RuntimeError("DB down")
        assert check_anomalies(1, 100, 2.0, db) == []

    def test_anomaly_result_to_dict(self):
        r = AnomalyResult(
            anomaly_type="zero_rows", severity="critical",
            current_value=0, expected_mean=100, expected_stddev=10,
            z_score=float('inf'), message="test",
        )
        d = r.to_dict()
        assert d["anomaly_type"] == "zero_rows"
        assert d["severity"] == "critical"
