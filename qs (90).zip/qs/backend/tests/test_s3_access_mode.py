"""Tests for get_s3_access_mode() — dual-mode S3 access (Bug 3).

Verifies that connections get the correct access mode (native vs presigned)
based on path_style, per-connection override, and global config.
"""
import pytest
from unittest.mock import patch


class TestGetS3AccessMode:
    """Test the get_s3_access_mode() helper."""

    def test_aws_s3_always_native(self):
        """AWS S3 (no path_style) should always return 'native'."""
        from core.s3_utilities import get_s3_access_mode
        assert get_s3_access_mode({}) == "native"
        assert get_s3_access_mode({"bucket_name": "my-bucket"}) == "native"
        assert get_s3_access_mode({"path_style": False}) == "native"

    def test_onprem_default_presigned(self):
        """On-prem S3 (path_style=True) should default to 'presigned' (safe for hive partitions)."""
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({"path_style": True})
        assert result == "presigned"

    def test_onprem_per_connection_override_presigned(self):
        """Per-connection s3_access_mode='presigned' overrides the default."""
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({
            "path_style": True,
            "s3_access_mode": "presigned",
        })
        assert result == "presigned"

    def test_onprem_per_connection_override_native(self):
        """Per-connection s3_access_mode='native' is explicit native."""
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({
            "path_style": True,
            "s3_access_mode": "native",
        })
        assert result == "native"

    def test_onprem_invalid_override_uses_global_default(self):
        """Invalid s3_access_mode value falls back to global config."""
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({
            "path_style": True,
            "s3_access_mode": "invalid",
        })
        # Should fall back to global default (native)
        assert result in ("native", "presigned")

    @patch("core.config.s3")
    def test_global_config_presigned(self, mock_s3_cfg):
        """Global config default_onprem_access_mode='presigned' applies."""
        mock_s3_cfg.default_onprem_access_mode = "presigned"
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({"path_style": True})
        assert result == "presigned"

    @patch("core.config.s3")
    def test_global_config_native(self, mock_s3_cfg):
        """Global config default_onprem_access_mode='native' applies."""
        mock_s3_cfg.default_onprem_access_mode = "native"
        from core.s3_utilities import get_s3_access_mode
        result = get_s3_access_mode({"path_style": True})
        assert result == "native"


class TestS3UrlsToPresigned:
    """Test that s3_urls_to_presigned respects access mode."""

    def test_native_mode_returns_urls_unchanged(self):
        """In explicit native mode, s3:// URLs should pass through unchanged."""
        from core.s3_utilities import s3_urls_to_presigned
        urls = ["s3://bucket/key1.parquet", "s3://bucket/key2.parquet"]
        # Explicit native mode override — URLs pass through
        result = s3_urls_to_presigned(None, urls, {"path_style": True, "s3_access_mode": "native"})
        assert result == urls

    def test_aws_returns_urls_unchanged(self):
        """AWS S3 (no path_style) should return URLs unchanged."""
        from core.s3_utilities import s3_urls_to_presigned
        urls = ["s3://bucket/key.parquet"]
        result = s3_urls_to_presigned(None, urls, {})
        assert result == urls

    def test_empty_urls_returns_empty(self):
        """Empty URL list returns empty."""
        from core.s3_utilities import s3_urls_to_presigned
        result = s3_urls_to_presigned(None, [], {"path_style": True})
        assert result == []


class TestS3ConfigProperty:
    """Test the config property for default_onprem_access_mode."""

    def test_config_defaults_exist(self):
        """s3.default_onprem_access_mode should be in defaults."""
        from core.config import get
        mode = get("s3", "default_onprem_access_mode", "native")
        assert mode in ("native", "presigned")

    def test_config_s3_class_property(self):
        """_S3Cfg should have default_onprem_access_mode property."""
        from core.config import s3
        assert hasattr(s3, "default_onprem_access_mode")
        assert s3.default_onprem_access_mode in ("native", "presigned")
