"""
Phase 70D — Error detection utility tests.
Tests JSON conversion, S3 auth detection, connection error detection, DuckDB error classification.
"""
from __future__ import annotations

import sys
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_backend = Path(__file__).resolve().parent.parent
if str(_backend) not in sys.path:
    sys.path.insert(0, str(_backend))

from core.error_detection import (
    classify_duckdb_error,
    is_connection_error,
    is_s3_auth_error,
    jsonify_rows,
    jsonify_value,
    raise_if_s3_auth_error,
)


# ---------------------------------------------------------------------------
# jsonify_value / jsonify_rows
# ---------------------------------------------------------------------------
class TestJsonifyValue:
    def test_none(self):
        assert jsonify_value(None) is None

    def test_datetime_to_isoformat(self):
        dt = datetime(2026, 3, 28, 12, 0, 0)
        assert jsonify_value(dt) == "2026-03-28T12:00:00"

    def test_date_to_isoformat(self):
        d = date(2026, 3, 28)
        assert jsonify_value(d) == "2026-03-28"

    def test_bytes_to_hex(self):
        assert jsonify_value(b"\xde\xad") == "dead"

    def test_bytearray_to_hex(self):
        assert jsonify_value(bytearray(b"\xbe\xef")) == "beef"

    def test_decimal_to_float(self):
        result = jsonify_value(Decimal("3.14"))
        assert isinstance(result, float)
        assert result == pytest.approx(3.14)

    def test_nested_list(self):
        result = jsonify_value([datetime(2026, 1, 1), Decimal("1.5"), None])
        assert result == ["2026-01-01T00:00:00", 1.5, None]

    def test_tuple_to_list(self):
        result = jsonify_value((1, 2, 3))
        assert result == [1, 2, 3]

    def test_passthrough_primitives(self):
        assert jsonify_value(42) == 42
        assert jsonify_value("hello") == "hello"
        assert jsonify_value(True) is True


class TestJsonifyRows:
    def test_in_place_conversion(self):
        rows = [
            {"ts": datetime(2026, 1, 1), "val": Decimal("1.5")},
            {"ts": None, "val": b"\xab"},
        ]
        jsonify_rows(rows)
        assert rows[0]["ts"] == "2026-01-01T00:00:00"
        assert rows[0]["val"] == 1.5
        assert rows[1]["val"] == "ab"


# ---------------------------------------------------------------------------
# S3 auth error detection
# ---------------------------------------------------------------------------
class TestIsS3AuthError:
    @patch("core.error_detection.TokenExpiredError", create=True)
    def test_token_expired_error_class(self, mock_cls):
        # Simulate TokenExpiredError subclass check
        exc = Exception("ExpiredToken: token has expired")
        assert is_s3_auth_error(exc) is True

    def test_expired_token_string(self):
        exc = RuntimeError("The security token included in the request is expired")
        assert is_s3_auth_error(exc) is True

    def test_non_auth_error(self):
        exc = RuntimeError("Column not found: abc")
        assert is_s3_auth_error(exc) is False


class TestRaiseIfS3AuthError:
    def test_raises_http_401(self):
        from fastapi import HTTPException
        exc = RuntimeError("ExpiredToken: Your security token has expired")
        with pytest.raises(HTTPException) as exc_info:
            raise_if_s3_auth_error(exc)
        assert exc_info.value.status_code == 401

    def test_noop_for_non_auth_error(self):
        exc = RuntimeError("Some other error")
        raise_if_s3_auth_error(exc)  # should not raise


# ---------------------------------------------------------------------------
# Connection error detection (stale fallback)
# ---------------------------------------------------------------------------
class TestIsConnectionError:
    @pytest.mark.parametrize("msg", [
        "connection refused",
        "Connection timed out",
        "HTTP 401 Unauthorized",
        "HTTP 403 Forbidden",
        "authentication failed for user",
        "could not resolve host",
        "SSL: CERTIFICATE_VERIFY_FAILED",
        "curl error 7",
    ])
    def test_connection_errors_detected(self, msg):
        assert is_connection_error(RuntimeError(msg)) is True

    @pytest.mark.parametrize("msg", [
        "Column 'foo' not found",
        "Syntax error at line 1",
        "Division by zero",
    ])
    def test_non_connection_errors(self, msg):
        assert is_connection_error(RuntimeError(msg)) is False


# ---------------------------------------------------------------------------
# DuckDB error classification
# ---------------------------------------------------------------------------
class TestClassifyDuckdbError:
    def test_binder_error_column_not_found(self):
        exc = RuntimeError('Binder Error: column "year" not found in table')
        result = classify_duckdb_error(exc)
        assert "year" in result
        assert "not found" in result.lower()

    def test_catalog_error_table_not_found(self):
        exc = RuntimeError("Catalog Error: Table 'sales' does not exist")
        result = classify_duckdb_error(exc)
        assert "Table or view not found" in result

    def test_io_error(self):
        exc = RuntimeError("IO Error: Failed to read file from httpfs")
        result = classify_duckdb_error(exc)
        assert "Failed to read data from S3" in result

    def test_signature_mismatch(self):
        exc = RuntimeError("SignatureDoesNotMatch: The request signature we calculated...")
        result = classify_duckdb_error(exc)
        assert "path_style" in result

    def test_unknown_error_passes_through(self):
        exc = RuntimeError("Something completely new")
        result = classify_duckdb_error(exc)
        assert result == "Something completely new"

    def test_strips_duckdb_prefix(self):
        exc = RuntimeError("RuntimeError: DuckDB query error: out of memory")
        result = classify_duckdb_error(exc)
        assert not result.startswith("RuntimeError:")

    def test_on_prem_s3_passes_through(self):
        exc = RuntimeError("on-prem S3: Failed to list parquet files")
        result = classify_duckdb_error(exc)
        assert result == str(exc)
