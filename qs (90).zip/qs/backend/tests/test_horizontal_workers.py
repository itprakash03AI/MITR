"""Tests for horizontal worker scaling (Phase 45)."""
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone, timedelta


class TestWorkerInfo:
    """Test WorkerInfo dataclass."""

    def test_create_worker_info(self):
        from core.worker_registry import WorkerInfo
        info = WorkerInfo(
            worker_id="host1:1234", hostname="host1", pid=1234,
            status="active", worker_type="executor",
            started_at="2026-01-01T00:00:00Z", last_heartbeat="2026-01-01T00:01:00Z",
            active_tasks=3, max_concurrent=10, cpu_pct=45.2, memory_pct=62.1,
            memory_mb=512, tasks_completed=100, tasks_failed=2, version="1.0"
        )
        assert info.worker_id == "host1:1234"
        assert info.status == "active"

    def test_to_dict(self):
        from core.worker_registry import WorkerInfo
        info = WorkerInfo(
            worker_id="h:1", hostname="h", pid=1, status="active",
            worker_type="executor", started_at="t0", last_heartbeat="t1",
            active_tasks=0, max_concurrent=5, cpu_pct=0, memory_pct=0,
            memory_mb=0, tasks_completed=0, tasks_failed=0, version="1.0"
        )
        d = info.to_dict()
        assert d["worker_id"] == "h:1"
        assert d["worker_type"] == "executor"
        assert isinstance(d, dict)

    def test_from_dict(self):
        from core.worker_registry import WorkerInfo
        d = {
            "worker_id": "x:2", "hostname": "x", "pid": 2, "status": "draining",
            "worker_type": "scheduler", "started_at": "t", "last_heartbeat": "t",
            "active_tasks": 1, "max_concurrent": 20, "cpu_pct": 10.5,
            "memory_pct": 30.0, "memory_mb": 256, "tasks_completed": 50,
            "tasks_failed": 1, "version": "2.0"
        }
        info = WorkerInfo.from_dict(d)
        assert info.worker_id == "x:2"
        assert info.status == "draining"
        assert info.cpu_pct == 10.5


class TestSqliteWorkerRegistry:
    """Test SQLite-backed worker registry."""

    @pytest.fixture
    def registry(self, tmp_path):
        """Create a SqliteWorkerRegistry with a temp DB."""
        from core.database import DatabaseManager
        from core.worker_registry import SqliteWorkerRegistry
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        return SqliteWorkerRegistry(db)

    def _make_info(self, worker_id="w1:100", status="active", worker_type="executor"):
        from core.worker_registry import WorkerInfo
        return WorkerInfo(
            worker_id=worker_id, hostname="test", pid=100,
            status=status, worker_type=worker_type,
            started_at=datetime.now(timezone.utc).isoformat(),
            last_heartbeat=datetime.now(timezone.utc).isoformat(),
            active_tasks=0, max_concurrent=10, cpu_pct=0, memory_pct=0,
            memory_mb=0, tasks_completed=0, tasks_failed=0, version="1.0"
        )

    def test_register_and_list(self, registry):
        info = self._make_info("w1:100")
        registry.register(info)
        workers = registry.list_workers()
        assert len(workers) == 1
        assert workers[0].worker_id == "w1:100"

    def test_register_multiple(self, registry):
        registry.register(self._make_info("w1:100"))
        registry.register(self._make_info("w2:200"))
        assert len(registry.list_workers()) == 2

    def test_heartbeat_updates(self, registry):
        info = self._make_info("w1:100")
        registry.register(info)
        info.active_tasks = 5
        info.cpu_pct = 75.0
        registry.heartbeat("w1:100", info)
        w = registry.get_worker("w1:100")
        assert w.active_tasks == 5
        assert w.cpu_pct == 75.0

    def test_deregister(self, registry):
        registry.register(self._make_info("w1:100"))
        registry.deregister("w1:100")
        assert registry.get_worker("w1:100") is None
        assert len(registry.list_workers()) == 0

    def test_list_by_type(self, registry):
        registry.register(self._make_info("e1:1", worker_type="executor"))
        registry.register(self._make_info("s1:2", worker_type="scheduler"))
        executors = registry.list_workers(worker_type="executor")
        assert len(executors) == 1
        assert executors[0].worker_type == "executor"

    def test_expired_workers_cleaned(self, registry):
        """Workers past expires_at should be cleaned from list."""
        from core.db.models import WorkerRegistration
        # Manually insert an expired worker
        with registry._db.get_session() as s:
            s.add(WorkerRegistration(
                worker_id="old:999", worker_type="executor", hostname="old",
                info=self._make_info("old:999").to_dict(),
                last_heartbeat=datetime.now(timezone.utc) - timedelta(hours=1),
                expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            ))
        workers = registry.list_workers()
        assert all(w.worker_id != "old:999" for w in workers)

    def test_get_fleet_metrics(self, registry):
        i1 = self._make_info("w1:1")
        i1.active_tasks = 3
        i1.max_concurrent = 10
        i1.cpu_pct = 50.0
        i1.memory_pct = 40.0
        registry.register(i1)

        i2 = self._make_info("w2:2")
        i2.active_tasks = 7
        i2.max_concurrent = 10
        i2.cpu_pct = 80.0
        i2.memory_pct = 60.0
        registry.register(i2)

        metrics = registry.get_fleet_metrics()
        assert metrics["worker_count"] == 2
        assert metrics["total_capacity"] == 20
        assert metrics["total_active_tasks"] == 10
        assert metrics["utilization_pct"] == 50.0


class TestHorizontalWorkersConfig:
    """Test horizontal_workers config section."""

    def test_defaults(self):
        from core.config import horizontal_workers as hw
        assert hw.heartbeat_interval_seconds == 15
        assert hw.heartbeat_ttl_seconds == 45
        assert hw.worker_eviction_seconds == 120
        assert hw.max_workers_per_host == 10
        assert hw.enable_load_aware_claiming == True
        assert hw.memory_threshold_pct == 85
        assert hw.cpu_threshold_pct == 90
        assert hw.metrics_retention_hours == 24

    def test_registry_backend_default(self):
        from core.config import horizontal_workers as hw
        assert hw.registry_backend == "auto"


class TestWorkerRegistrationModel:
    """Test the WorkerRegistration SQLAlchemy model."""

    def test_model_exists(self):
        from core.db.models import WorkerRegistration
        assert hasattr(WorkerRegistration, "worker_id")
        assert hasattr(WorkerRegistration, "worker_type")
        assert hasattr(WorkerRegistration, "hostname")
        assert hasattr(WorkerRegistration, "info")
        assert hasattr(WorkerRegistration, "expires_at")

    def test_create_in_db(self, tmp_path):
        from core.database import DatabaseManager
        from core.db.models import WorkerRegistration
        db = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
        with db.get_session() as s:
            s.add(WorkerRegistration(
                worker_id="test:1", worker_type="executor",
                hostname="test", info={"status": "active"},
                last_heartbeat=datetime.now(timezone.utc),
                expires_at=datetime.now(timezone.utc) + timedelta(seconds=45),
            ))
        with db.get_session(read_only=True) as s:
            w = s.query(WorkerRegistration).filter_by(worker_id="test:1").first()
            assert w is not None
            assert w.worker_type == "executor"
