"""
Query execution endpoints and background workers.

Endpoints:
- POST /api/execute          — submit query for background execution
- POST /api/execute/estimate — lightweight row/file count estimation

Background workers:
- execute_query_background          — S3/local parquet execution
- execute_sql_connector_background  — SQL connector (Trino/Snowflake/...) execution
- execute_cross_query_background    — cross-connection (multi-source) execution

Extracted from main.py (Round 4 A3).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
import time as _time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request

from api.deps import get_current_user, require_execute_access
from api.models.query_models import (
    ExecuteQueryRequest, EstimateRequest, QueryConfigModel,
)
from core.query_converter import convert_query_config_to_engine
from core.duckdb_views import (
    execute_registered_table_query,
    execute_registered_table_copy_to,
    s3_full_copy,
    join_inflight_query,
    run_base_data_local_query,
)
from core.s3_utilities import (
    list_s3_parquet_files,
    s3_urls_to_presigned,
    make_s3_client_for_conn,
)
from core.error_detection import is_connection_error
from core.s3_storage import build_s3_config, TokenExpiredError
from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig
from core.connection_manager import _normalize_path
from core.connectors import get_connector, SQL_CONNECTOR_TYPES

logger = logging.getLogger(__name__)

router = APIRouter()

# ── Module-level singletons — populated by set_execute_dependencies() ─────
_db_manager = None
_ws_manager = None
_engine = None           # default ParquetQueryEngine instance
_paths = None            # config paths
_qe_cfg = None           # query_engine config section
_limits_cfg = None       # limits config section
_s3_config = None        # global S3Config (may be None)
_query_executor = None   # ThreadPoolExecutor for heavy queries
_get_light_executor_fn = None  # callable returning streaming executor

# ── Shared execution state ─────────────────────────────────────────────────
_inflight_queries: dict = {}     # cache_key → (exec_id, asyncio.Event)
_user_query_counts: dict = {}    # username → int (active count)
_user_query_lock = threading.Lock()


def set_execute_dependencies(db_manager, ws_manager, engine, paths, qe_cfg,
                             limits_cfg, s3_config, query_executor,
                             get_light_executor_fn):
    """Call once from main.py _startup() after all components are initialised."""
    global _db_manager, _ws_manager, _engine, _paths, _qe_cfg
    global _limits_cfg, _s3_config, _query_executor, _get_light_executor_fn
    _db_manager = db_manager
    _ws_manager = ws_manager
    _engine = engine
    _paths = paths
    _qe_cfg = qe_cfg
    _limits_cfg = limits_cfg
    _s3_config = s3_config
    _query_executor = query_executor
    _get_light_executor_fn = get_light_executor_fn


# ── Helpers ────────────────────────────────────────────────────────────────

def _log_ws_notification(event_type: str, recipient: str, title: str,
                         message: str = "", execution_id: str = None,
                         schedule_id: int = None, payload: dict = None):
    """Persist a WebSocket notification to DB for history / bell icon."""
    try:
        _db_manager.log_notification(
            event_type=event_type,
            channel="websocket",
            recipient=recipient,
            status="sent",
            title=title,
            message=message,
            payload=payload,
            execution_id=execution_id,
            schedule_id=schedule_id,
        )
    except Exception as exc:
        logger.debug("Failed to log notification: %s", exc)


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        _db_manager.audit(username, action, resource_type=resource_type,
                          resource_id=resource_id, ip_address=ip,
                          user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


# ── Background workers ────────────────────────────────────────────────────

async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest",
                                  raw_sql: Optional[str] = None,
                                  cache_strategy: str = "auto",
                                  cache_key: Optional[str] = None,
                                  query_config_dict: Optional[dict] = None,
                                  fallback_output_file: Optional[str] = None):
    """Background task for query execution"""
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()
    run_engine = active_engine or _engine

    try:

        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await _ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                _db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            if is_terminal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0

            # Registered table path: resolve __registered__: → DuckDB views
            def _any_virtual(flist, prefixes=("__registered__:", "__materialized__:", "__local__:")):
                return any(
                    (f if isinstance(f, str) else f.path).startswith(prefixes)
                    for f in (flist or [])
                )
            _join_right = [j.right_file for j in (query_config.joins or [])] if query_config.joins else []
            _has_reg = _any_virtual(query_config.files) or _any_virtual(_join_right)
            # COPY TO fast path only for S3 registered tables (not local or MV)
            _has_s3_reg = _any_virtual(query_config.files, ("__registered__:",)) or _any_virtual(_join_right, ("__registered__:",))

            # ── COPY TO fast path — bypass Python/pandas entirely ──────────
            # DuckDB streams from S3 directly to local Parquet (3-10x faster).
            # Skip for UNC paths (DuckDB can't handle \\server\share\...).
            # Skip for local/MV tables — they are already local files.
            if _has_s3_reg and not str(output_file).startswith("\\\\"):
                try:
                    stats = execute_registered_table_copy_to(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        str(output_file),
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        cancel_event=cancel_event,
                    )
                    _sync_progress({"status": "completed",
                                    "total_rows": stats["total_rows"],
                                    "file_size_bytes": stats["file_size_bytes"]})
                    return stats
                except Exception as _copy_err:
                    # Don't fall back to in-process DuckDB — same crash risk.
                    # Let the error propagate so the execution fails cleanly.
                    raise RuntimeError(f"S3 query failed: {_copy_err}") from _copy_err

            # ── Streaming path (fallback for registered tables, default for others)
            pq_writer = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                if _has_reg:
                    _query_gen = execute_registered_table_query(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                    )
                elif raw_sql:
                    if run_engine._s3_conn_config:
                        # ── Raw SQL + S3: subprocess-isolated COPY TO ──
                        fh.close()  # close file handle — subprocess writes directly
                        _setup_stmts = []
                        if run_engine._registered_tables:
                            _esc = lambda v: v.replace("'", "''")
                            _rt_bucket = run_engine._s3_bucket
                            for _rt in run_engine._registered_tables:
                                _rt_name = _rt["name"].replace('"', '""')
                                _rt_fmt = _rt.get("format", "parquet")
                                _rt_prefix = _rt["s3_prefix"].rstrip("/")
                                if _rt_fmt == "iceberg":
                                    try:
                                        from core.iceberg_reader import get_iceberg_data_files
                                        _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                        _rt_files = get_iceberg_data_files(_rt_s3, _rt_bucket, _rt["s3_prefix"], keys_only=True)
                                        if _rt_files:
                                            _rt_urls = [f"s3://{_rt_bucket}/{f['key']}" for f in _rt_files]
                                            # On-prem S3: pre-sign to avoid DuckDB '=' URL-encoding issue
                                            _rt_urls = s3_urls_to_presigned(_rt_s3, _rt_urls, run_engine._s3_conn_config)
                                            _rt_paths = ", ".join(f"'{_esc(u)}'" for u in _rt_urls)
                                            _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet([{_rt_paths}], hive_partitioning=true, union_by_name=true)')
                                    except Exception as _rte:
                                        logger.warning("Could not register Iceberg view '%s' for raw SQL: %s", _rt_name, _rte, exc_info=True)
                                elif _rt_fmt == "parquet":
                                    try:
                                        _rt_s3_pq = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                        _rt_pq_files = list_s3_parquet_files(_rt_s3_pq, _rt_bucket, _rt_prefix)
                                        if _rt_pq_files:
                                            # On-prem S3: pre-sign to avoid DuckDB '=' URL-encoding issue
                                            _rt_pq_files = s3_urls_to_presigned(_rt_s3_pq, _rt_pq_files, run_engine._s3_conn_config)
                                            _rt_pq_paths = ", ".join(f"'{_esc(f)}'" for f in _rt_pq_files)
                                            _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet([{_rt_pq_paths}], hive_partitioning=true, union_by_name=true)')
                                        else:
                                            _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true)')
                                    except Exception:
                                        _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true)')
                                elif _rt_fmt == "csv":
                                    _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.csv\')')
                        # ── Two-phase: preview + full download ──
                        _tp_result = s3_full_copy(
                            inner_sql=raw_sql,
                            output_path=str(output_file),
                            conn_config=run_engine._s3_conn_config,
                            registered_tables=run_engine._registered_tables or [],
                            bucket=run_engine._s3_bucket or "",
                            setup_sql=";\n".join(_setup_stmts),
                            connection_id=getattr(run_engine, '_s3_conn_id', None),
                            progress_fn=_sync_progress,
                            timeout=600,
                        )
                        total_rows = _tp_result["total_rows"]
                        file_size = _tp_result["file_size_bytes"]
                        _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                        return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                    else:
                        _query_gen = run_engine.execute_raw_duckdb_sql(raw_sql)
                elif run_engine._s3_conn_config:
                    # ── S3 non-registered files: two-phase (preview + full) ──
                    fh.close()  # close file handle — subprocess writes directly
                    _s3_sql = run_engine.get_duckdb_sql(query_config)
                    _tp_result = s3_full_copy(
                        inner_sql=_s3_sql,
                        output_path=str(output_file),
                        conn_config=run_engine._s3_conn_config,
                        registered_tables=[],
                        bucket=getattr(run_engine, '_s3_bucket', "") or "",
                        setup_sql="",
                        connection_id=getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        timeout=600,
                    )
                    total_rows = _tp_result["total_rows"]
                    file_size = _tp_result["file_size_bytes"]
                    _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                    return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                elif run_engine._needs_duckdb(query_config):
                    _query_gen = run_engine.execute_duckdb_query(query_config)
                else:
                    _query_gen = run_engine.execute_query(query_config)
                # Detect wide-table auto-projection: when engine projected a
                # subset of columns, store the full list so the grid can offer
                # "Showing 50 of 937 columns — choose columns" UX.
                _all_source_cols = None
                if (not query_config.columns
                        and not query_config.aggregations
                        and query_config.files):
                    try:
                        _first = query_config.files[0]
                        _fp = _first if isinstance(_first, str) else _first.path
                        if not _fp.startswith("__registered__:") and hasattr(run_engine, 'get_file_schema'):
                            _sch = run_engine.get_file_schema(_fp)
                            _src_cols = [c["name"] for c in _sch.get("columns", [])]
                            if len(_src_cols) > 50:
                                _all_source_cols = _src_cols
                    except Exception as exc:
                        logger.warning("Recoverable error: %s", exc, exc_info=True)

                for chunk in _query_gen:
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    # Accept both pa.Table (from DuckDB streaming) and pd.DataFrame
                    if isinstance(chunk, _pa.Table):
                        table = chunk
                    else:
                        table = _pa.Table.from_pandas(chunk, preserve_index=False)
                    if pq_writer is None:
                        _sync_progress({"status": "processing", "log": f"Writing results ({len(table)} rows)..."})
                        # Embed all_columns metadata in Parquet file so the
                        # paginator can return it without extra lookups.
                        _pq_meta = table.schema.metadata or {}
                        if _all_source_cols is not None:
                            _pq_meta[b"all_columns"] = json.dumps(_all_source_cols).encode()
                        # Embed auto-partition info so frontend can show indicator
                        _auto_part = getattr(query_config, '_auto_partition', None)
                        if _auto_part:
                            _pq_meta[b"auto_partition"] = json.dumps(_auto_part).encode()
                        # Use replace_schema_metadata on the table itself so
                        # writer schema and table schema are identical.
                        table = table.replace_schema_metadata(_pq_meta)
                        _writer_schema = table.schema
                        pq_writer = _pq.ParquetWriter(fh, _writer_schema, compression="zstd")
                    else:
                        # Subsequent chunks may have a different schema (e.g.
                        # multi-file streaming with schema evolution).  Cast
                        # to the writer's schema so the write doesn't fail.
                        if table.schema != _writer_schema:
                            try:
                                table = table.cast(_writer_schema)
                            except Exception:
                                # If cast fails, unify: add missing cols as null,
                                # drop extra cols, reorder to match writer.
                                for field in _writer_schema:
                                    if field.name not in table.column_names:
                                        table = table.append_column(
                                            field, _pa.nulls(len(table), type=field.type))
                                table = table.select([f.name for f in _writer_schema])
                    pq_writer.write_table(table)
                    total_rows += len(table)
                    chunks_processed += 1
            finally:
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # Ensure an empty file exists for 0-row results so downstream
                # readers don't get a FileNotFoundError.
                if total_rows == 0 and not output_file.exists():
                    output_file.touch()
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_to_parquet,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            _db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast({
                "type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return

        _db_manager.update_execution(execution_id, status="processing")
        await _ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        _db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        _db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )

        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, _s3_config)
            if _s3_info:
                _db_manager.update_execution(execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc)

        if query_id:
            _db_manager.increment_execution_count(query_id)

        # ── Phase 52: capture lineage snapshot after successful execution ──
        try:
            from core.sql_lineage_parser import capture_execution_lineage_snapshot
            _qt = query_config.query_type if hasattr(query_config, "query_type") else "parquet_query"
            _conn_id = getattr(query_config, "connection_id", None)
            capture_execution_lineage_snapshot(
                db_manager=_db_manager,
                execution_id=execution_id,
                query_type=_qt,
                query_id=query_id or 0,
                connection_id=_conn_id,
            )
        except Exception as _snap_exc:
            logger.debug("Lineage snapshot capture skipped: %s", _snap_exc)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        # TTL = 7 days so results persist for the full download-file lifetime.
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key, store_result, make_base_data_key
                _qc_dict = query_config_dict or (query_config.__dict__ if hasattr(query_config, '__dict__') else {})
                _ck = cache_key or make_cache_key(_qc_dict)
                if output_file.exists():
                    store_result(_ck, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                 ttl_seconds=7 * 24 * 3600)
                    # Also store a base-data cache entry so future queries with
                    # different SELECT/aggregations on the same FROM/WHERE/JOIN
                    # can reuse this downloaded parquet instead of re-fetching S3.
                    try:
                        _bk = make_base_data_key(_qc_dict)
                        store_result(_bk, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                     ttl_seconds=7 * 24 * 3600)
                    except Exception:
                        pass  # non-critical
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        await _ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        _log_ws_notification(
            "execution_completed", executed_by or "guest",
            "Query Completed",
            f"{stats.get('total_rows', 0):,} rows",
            execution_id=execution_id,
        )

        logger.info(f"Query execution completed: {execution_id}")

    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = _db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            _db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}", exc_info=True)

        # ── Stale-result fallback ─────────────────────────────────────────────
        # If this is a connectivity / auth failure AND we have a previous result
        # file on disk, serve that instead of failing outright.  The frontend
        # will receive execution_completed with stale=True and show a banner.
        # Wrapped in its own try/except so any failure here falls through to the
        # normal failure path below — we never silently swallow the original error.
        _served_stale = False
        if fallback_output_file and is_connection_error(e):
            try:
                _fb = Path(fallback_output_file)
                if _fb.exists():
                    try:
                        import pyarrow.parquet as _pq_fb
                        _fb_rows = _pq_fb.ParquetFile(str(_fb)).metadata.num_rows
                    except Exception:
                        _fb_rows = 0
                    _fb_size = _fb.stat().st_size
                    _db_manager.update_execution(
                        execution_id,
                        status="completed",
                        output_file=str(_fb),
                        total_rows=_fb_rows,
                        file_size_bytes=_fb_size,
                        error_message=None,
                    )
                    _fb_file_id = str(uuid.uuid4())
                    _db_manager.create_download_file(
                        file_id=_fb_file_id,
                        execution_id=execution_id,
                        filename=f"stale_result_{execution_id}.parquet",
                        file_path=str(_fb),
                        file_size_bytes=_fb_size,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                    )
                    _stale_reason = str(e)[:300]
                    await _ws_manager.broadcast({
                        "type": "execution_completed",
                        "execution_id": execution_id,
                        "file_id": _fb_file_id,
                        "stats": {"total_rows": _fb_rows, "file_size_bytes": _fb_size},
                        "stale": True,
                        "stale_warning": (
                            "Connection unavailable — showing last cached result. "
                            f"Reconnect and re-run to refresh. ({_stale_reason})"
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    _log_ws_notification(
                        "execution_completed", executed_by or "guest",
                        "Stale Result Served",
                        f"Connection failed — last result ({_fb_rows:,} rows) served from cache.",
                        execution_id=execution_id,
                    )
                    logger.warning(
                        "Stale fallback served for %s — connection error: %s", execution_id, e
                    )
                    # Clean up orphaned new output file (the real run never completed)
                    try:
                        output_file.unlink(missing_ok=True)
                    except OSError:
                        pass
                    _served_stale = True
            except Exception as _fb_exc:
                logger.warning("Stale fallback failed for %s: %s", execution_id, _fb_exc)
        if _served_stale:
            return  # don't mark as failed
        # ─────────────────────────────────────────────────────────────────────

        _err_code = "TOKEN_EXPIRED" if isinstance(e, TokenExpiredError) else None
        _db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass

        ws_msg = {
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if _err_code:
            ws_msg["error_code"] = _err_code
        await _ws_manager.broadcast(ws_msg)
        _log_ws_notification(
            "execution_failed", executed_by or "guest",
            "Query Failed",
            str(e)[:300],
            execution_id=execution_id,
        )

    finally:
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_sql_connector_background(
    execution_id: str,
    connector,          # SqlConnector instance (already constructed)
    sql: str,           # complete SQL built by engine.build_query_sql()
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
):
    """Execute a query against a SQL connector (Trino/Starburst/Snowflake/Databricks/Oracle).
    Mirrors the structure of execute_query_background so the frontend receives
    the same WebSocket messages and can download results the same way.
    """
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        def _exec_sql(cancel_event=None):
            try:
                logger.info(f"SQL connector query [{execution_id}]:\n{sql}")
                result = connector.execute_query(sql)
                # result = {"columns": [{"name":..,"type":..}], "rows": [...], "total_rows": int}
                rows    = result.get("rows", [])
                col_defs = result.get("columns", [])
                col_names = [c["name"] for c in col_defs]
                df = _pd.DataFrame(rows, columns=col_names) if rows else _pd.DataFrame(columns=col_names)
                total_rows = len(df)
                output_file.parent.mkdir(parents=True, exist_ok=True)
                if total_rows > 0:
                    table = _pa.Table.from_pandas(df, preserve_index=False)
                    with open(str(output_file), "wb") as fh:
                        _pq.ParquetWriter(fh, table.schema, compression="zstd").write_table(table)
                else:
                    output_file.touch()
                file_size = output_file.stat().st_size
                return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
            finally:
                try:
                    connector.close()
                except Exception as exc:
                    logger.warning("Recoverable error: %s", exc, exc_info=True)

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_sql,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            _db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        _db_manager.update_execution(execution_id, status="processing")
        await _ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        _db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )
        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, _s3_config)
            if _s3_info:
                _db_manager.update_execution(execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc)

        file_id = str(uuid.uuid4())
        _db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        if query_id:
            _db_manager.increment_execution_count(query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key as _mk_ck, store_result as _store_res
                _ck = cache_key or _mk_ck(query_config_dict or {})
                if _ck and output_file.exists():
                    _store_res(_ck, output_file, query_config_dict or {},
                               row_count=stats.get("total_rows", 0), copy=False,
                               ttl_seconds=7 * 24 * 3600)
            except Exception as exc:
                logger.warning("Recoverable error caching SQL connector result: %s", exc, exc_info=True)

        await _ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"SQL connector query completed: {execution_id} ({stats.get('total_rows',0)} rows)")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"SQL connector query cancelled: {execution_id}")
        current_exec = _db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            _db_manager.update_execution(execution_id, status="cancelled", error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast({"type": "execution_cancelled", "execution_id": execution_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat()})
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"SQL connector query failed {execution_id}: {e}", exc_info=True)
        _db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                                    "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()})
    finally:
        # Clear checkpoint — execution finished (Phase 41)
        from core.checkpoint import mark_completed as _cp_done_sql
        _cp_done_sql(execution_id)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_cross_query_background(
    execution_id: str,
    primary_engine,
    primary_config: QueryConfig,
    secondary_engine,
    secondary_config: QueryConfig,
    combine_mode: str,
    join_config: Optional[dict],
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
):
    """Background task for cross-connection (multi-source) query execution."""
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        async def _progress(data):
            await _ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            if data.get("status") in ("completed", "failed"):
                _db_manager.update_execution(
                    execution_id,
                    status=data["status"],
                    total_rows=data.get("total_rows", 0),
                    chunks_processed=data.get("chunks_processed", 0),
                    output_file=str(output_file) if data.get("status") == "completed" else None,
                    file_size_bytes=data.get("file_size_bytes", 0),
                    error_message=data.get("error"),
                )

        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            if data.get("status") in ("completed", "failed") or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(_progress(data), loop)

        import pyarrow as _pa
        import pyarrow.parquet as _pq

        def _exec_cross(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)

            # ── Primary source ────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "primary",
                            "message": "Executing primary source query"})
            chunks_a = []
            for chunk in primary_engine.execute_query(primary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_a.append(chunk)
            df_a = _pd.concat(chunks_a, ignore_index=True) if chunks_a else _pd.DataFrame()

            # ── Secondary source ──────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "secondary",
                            "message": "Executing secondary source query"})
            chunks_b = []
            for chunk in secondary_engine.execute_query(secondary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_b.append(chunk)
            df_b = _pd.concat(chunks_b, ignore_index=True) if chunks_b else _pd.DataFrame()

            # ── Combine ───────────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "combining",
                            "message": f"Combining via {combine_mode.upper()}"})
            if combine_mode == "union":
                df_result = _pd.concat([df_a, df_b], ignore_index=True, sort=False)
            elif combine_mode == "join":
                if not join_config:
                    raise ValueError("join_config required for join mode")
                how = join_config.get("how", "inner")
                left_on = join_config.get("left_on")
                right_on = join_config.get("right_on")
                suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
                if isinstance(left_on, str): left_on = [left_on]
                if isinstance(right_on, str): right_on = [right_on]
                if not left_on or not right_on:
                    raise ValueError("join_config must specify left_on and right_on")
                df_result = _pd.merge(df_a, df_b, how=how,
                                      left_on=left_on, right_on=right_on,
                                      suffixes=suffixes)
            else:
                raise ValueError(f"Unknown combine_mode '{combine_mode}'")

            # ── Save parquet ──────────────────────────────────────────────────
            fh = open(str(output_file), "wb")
            try:
                table = _pa.Table.from_pandas(df_result, preserve_index=False)
                writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                writer.write_table(table)
                writer.close()
            finally:
                fh.close()
            if df_result.empty and not output_file.exists():
                output_file.touch()

            total_rows = len(df_result)
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows,
                            "file_size_bytes": file_size, "chunks_processed": 2})
            return {"total_rows": total_rows, "chunks_processed": 2,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_cross,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            _db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        _db_manager.update_execution(execution_id, status="processing")
        await _ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        _db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        _db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"cross_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        if query_id:
            _db_manager.increment_execution_count(query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key as _mk_ck_x, store_result as _store_res_x
                _ck_x = cache_key or _mk_ck_x(query_config_dict or {})
                if _ck_x and output_file.exists():
                    _store_res_x(_ck_x, output_file, query_config_dict or {},
                                 row_count=stats.get("total_rows", 0), copy=False,
                                 ttl_seconds=7 * 24 * 3600)
            except Exception as exc:
                logger.warning("Recoverable error caching cross-query result: %s", exc, exc_info=True)

        await _ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "combine_mode": combine_mode,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"Cross-connection query completed: {execution_id} ({combine_mode})")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"Cross-connection query cancelled: {execution_id}")
        cur = _db_manager.get_execution(execution_id)
        if cur and cur.get("status") not in ("cancelled",):
            _db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"Error in cross-connection query {execution_id}: {e}", exc_info=True)
        _db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        # Clear checkpoint — execution finished (Phase 41)
        from core.checkpoint import mark_completed as _cp_done_cross
        _cp_done_cross(execution_id)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def _run_query_and_signal(execution_id: str, query_config, query_id,
                                 active_engine, executed_by: str, raw_sql,
                                 cache_strategy: str, cache_key: Optional[str],
                                 query_config_dict: Optional[dict] = None,
                                 fallback_output_file: Optional[str] = None) -> None:
    """Wrapper around execute_query_background that signals _inflight_queries on completion."""
    try:
        await execute_query_background(
            execution_id, query_config, query_id, active_engine,
            executed_by=executed_by, raw_sql=raw_sql, cache_strategy=cache_strategy,
            cache_key=cache_key, query_config_dict=query_config_dict,
            fallback_output_file=fallback_output_file,
        )
    finally:
        # Clear checkpoint — execution finished regardless of outcome (Phase 41)
        from core.checkpoint import mark_completed as _cp_done
        _cp_done(execution_id)
        if cache_key and cache_key in _inflight_queries:
            _, event = _inflight_queries.pop(cache_key, (None, None))
            if event:
                event.set()


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post("/api/execute/estimate")
async def estimate_query(request: EstimateRequest, _user: dict = Depends(get_current_user)):
    """Return estimated row count and file count without executing the full query."""
    try:
        query_config_model = request.query_config
        _effective_conn_id = request.connection_id or query_config_model.connection_id

        if not query_config_model.files:
            return {"estimated_rows": 0, "estimated_files": 0}

        # ── Registered tables — return file count only (can't COUNT without views) ──
        _file_paths = [
            (f if isinstance(f, str) else (f.path if hasattr(f, 'path') else ''))
            for f in query_config_model.files
        ]
        _has_registered = any(p.startswith("__registered__:") for p in _file_paths)
        if _has_registered:
            return {
                "estimated_rows": -1,
                "estimated_files": len(query_config_model.files),
                "note": "Row estimation not available for registered tables",
            }

        # MV / local table — return stored row count directly (instant, no S3 needed)
        _has_mv = any(p.startswith("__materialized__:") for p in _file_paths)
        _has_lt = any(p.startswith("__local__:") for p in _file_paths)
        if _has_mv or _has_lt:
            total_rows = 0
            for p in _file_paths:
                if p.startswith("__materialized__:"):
                    mv_name = p.replace("__materialized__:", "")
                    mv_rec = _db_manager.get_materialized_view_by_name(mv_name)
                    if mv_rec:
                        total_rows += mv_rec.get("row_count", 0)
                elif p.startswith("__local__:"):
                    lt_name = p.replace("__local__:", "")
                    lt_rec = _db_manager.get_local_table_by_name(lt_name)
                    if lt_rec:
                        total_rows += lt_rec.get("row_count", 0)
            return {
                "estimated_rows": total_rows,
                "estimated_files": len(query_config_model.files),
            }

        # Resolve connection
        conn_record = None
        _conn_type = None
        _cfg = {}
        if _effective_conn_id:
            conn_record = _db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})

        # ── SQL connector path (Trino, Snowflake, Databricks, Oracle) ──
        if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
            table_ref = query_config_model.files[0] if query_config_model.files else None
            if not table_ref:
                return {"estimated_rows": -1, "estimated_files": 0}

            # Build filter-only query, then wrap with COUNT(*)
            estimate_model = query_config_model.model_copy(update={
                "limit": None, "offset": 0, "aggregations": None,
                "group_by": None, "order_by": None, "columns": None,
            })
            try:
                from core.date_resolver import resolve_filter_dates
                if estimate_model.filters:
                    resolved = resolve_filter_dates(estimate_model.filters)
                    estimate_model = estimate_model.model_copy(update={"filters": resolved})
            except Exception:
                pass

            engine_config = convert_query_config_to_engine(estimate_model)
            full_sql = _engine.build_query_sql(engine_config, table_ref)

            # Replace SELECT ... FROM with SELECT COUNT(*) FROM
            from_idx = full_sql.upper().find("\nFROM ")
            if from_idx == -1:
                from_idx = full_sql.upper().find(" FROM ")
            if from_idx == -1:
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:]

            # Execute via connector (runs on the actual database)
            try:
                sql_connector = get_connector(_conn_type, _cfg)
                result = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: sql_connector.execute_query(count_sql, limit=None)
                )
                rows = result.get("rows", [])
                if rows:
                    # Column name may be 'cnt', 'CNT', etc. depending on DB dialect
                    row = {k.lower(): v for k, v in rows[0].items()}
                    estimated_rows = row.get("cnt", 0)
                else:
                    estimated_rows = 0
            except Exception as exc:
                logger.warning("SQL connector estimate failed (%s): %s", _conn_type, exc)
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            return {
                "estimated_rows": estimated_rows,
                "estimated_files": len(query_config_model.files),
            }

        # ── Parquet path (local / S3) ──
        active_engine = _engine
        if _conn_type == 'local':
            local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
            active_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
        elif _conn_type == 's3':
            active_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir), chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(_cfg),
            )

        # Build filter-only query
        estimate_model = query_config_model.model_copy(update={
            "limit": None, "offset": 0, "aggregations": None,
            "group_by": None, "order_by": None, "columns": None,
        })
        try:
            from core.date_resolver import resolve_filter_dates
            if estimate_model.filters:
                resolved = resolve_filter_dates(estimate_model.filters)
                estimate_model = estimate_model.model_copy(update={"filters": resolved})
        except Exception:
            pass

        engine_config = convert_query_config_to_engine(estimate_model)
        from_clause = active_engine._build_duckdb_from_clause(engine_config)
        full_sql = active_engine.build_query_sql(engine_config, from_clause)

        from_idx = full_sql.upper().find("\nFROM ")
        if from_idx == -1:
            from_idx = full_sql.upper().find(" FROM ")
        count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:] if from_idx != -1 else None

        estimated_rows = 0
        if count_sql:
            from api.data_grid_api import _duckdb_con_with_s3
            if _conn_type == 's3':
                con = _duckdb_con_with_s3(_cfg, connection_id=_effective_conn_id)
            else:
                import duckdb
                con = duckdb.connect(database=":memory:")
            try:
                result = con.execute(count_sql).fetchone()
                estimated_rows = result[0] if result else 0
            finally:
                con.close()

        return {
            "estimated_rows": estimated_rows,
            "estimated_files": len(query_config_model.files),
        }
    except Exception as e:
        logger.error("Estimate error: %s", e, exc_info=True)
        return {"estimated_rows": -1, "estimated_files": len(request.query_config.files or []),
                "error": str(e)}


@router.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks, _user: dict = Depends(require_execute_access)):
    """Execute a query (saved or ad-hoc)"""
    # Set portal user context so _make_s3_client_for_conn auto-injects creds
    try:
        from core.aws_portal_auth import _current_portal_user
        _current_portal_user.set(_user.get("username", ""))
    except Exception:
        pass
    try:
        if request.query_config:
            # Client passes an explicit (possibly parameterised) query config — use it.
            # query_id may also be set for audit/tracking purposes; that is fine.
            query_config_model = request.query_config
        elif request.query_id:
            saved_query = _db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.raw_sql:
            # SQL editor mode — no visual query config needed
            query_config_model = QueryConfigModel(files=[])
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id, query_config, or raw_sql must be provided"
            )

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except Exception:
            pass   # non-fatal — proceed with original filters

        # ── Phase 47: Pre-execution query analysis ────────────────────────────
        _query_warnings = []
        try:
            from core.query_analyzer import analyze_query as _analyze_q, warnings_to_dicts as _wtd
            _sql_to_analyze = request.raw_sql or ""
            _pre_conn_type = "duckdb"
            _pre_conn_id = request.connection_id or query_config_model.connection_id
            if _pre_conn_id:
                _pre_conn = _db_manager.get_connection_raw(_pre_conn_id)
                if _pre_conn:
                    _pre_conn_type = _pre_conn.get('connection_type', 'duckdb')
                    # Fetch partition columns for the first queried table
                    _pre_table = (query_config_model.files or [''])[0]
                    _pre_partitions = []
                    try:
                        _pre_partitions = [
                            p.get('column', '') for p in
                            _db_manager.get_connection_partitions(_pre_conn_id, _pre_table)
                            if p.get('column')
                        ]
                    except Exception:
                        pass
            if _sql_to_analyze:
                _query_warnings = _wtd(_analyze_q(_sql_to_analyze, _pre_conn_type, _pre_partitions))
        except Exception:
            pass  # non-fatal

        # ── Phase 46: Record table/file usage for auto-suggest ────────────────
        try:
            _usage_conn_id = request.connection_id or query_config_model.connection_id
            for _f in (query_config_model.files or []):
                _fname = str(_f)
                if not _fname.startswith('__'):
                    import os as _os
                    _tname = _os.path.splitext(_os.path.basename(_fname))[0]
                    _db_manager.record_usage("table", _tname, connection_id=_usage_conn_id)
        except Exception:
            pass  # non-fatal

        # Resolve engine based on connection type
        # Explicit request.connection_id takes priority; fall back to connection_id stored in saved query
        _effective_conn_id = request.connection_id or query_config_model.connection_id
        active_engine = _engine
        _uses_registered = False
        if _effective_conn_id:
            conn_record = _db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})
                if _conn_type == 'local':
                    local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
                    active_engine = ParquetQueryEngine(
                        base_path=local_path,
                        chunk_size=_qe_cfg.chunk_size,
                    )
                elif _conn_type == 's3':
                    active_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(_cfg),
                    )
                    # Check if query uses registered/materialized/local tables (virtual path prefix)
                    def _has_virtual_prefix(paths):
                        return any(
                            f.startswith("__registered__:") or f.startswith("__materialized__:") or f.startswith("__local__:")
                            for f in (paths or [])
                        )
                    _join_files = [
                        j.right_file if isinstance(j.right_file, str) else j.right_file
                        for j in (query_config_model.joins or [])
                    ] if query_config_model.joins else []
                    _uses_registered = (
                        _has_virtual_prefix(query_config_model.files or [])
                        or _has_virtual_prefix(_join_files)
                    )
                    if _uses_registered:
                        active_engine._registered_tables = _cfg.get("registered_tables", [])
                        active_engine._s3_conn_config = _cfg
                        active_engine._s3_bucket = _cfg["bucket_name"]
                        active_engine._s3_conn_id = _effective_conn_id
                elif _conn_type in SQL_CONNECTOR_TYPES:
                    # ── SQL connector execution path ──────────────────────────
                    # Build SQL from the query config and dispatch to the connector.
                    # Bypass parquet validation — there are no local files to check.
                    sql_connector = get_connector(_conn_type, _cfg)
                    if request.raw_sql:
                        sql_str = request.raw_sql
                    else:
                        engine_config = convert_query_config_to_engine(query_config_model)
                        table_ref = query_config_model.files[0] if query_config_model.files else None
                        if not table_ref:
                            raise HTTPException(status_code=400, detail="No table specified in query config")
                        sql_str = _engine.build_query_sql(engine_config, table_ref)

                    # ── SQL connector cache check ─────────────────────────────
                    _sql_qc_dict = query_config_model.model_dump()
                    # Include raw_sql in key so manually typed SQL is keyed separately
                    if request.raw_sql:
                        _sql_qc_dict["_raw_sql"] = request.raw_sql
                    _sql_qc_dict["_conn_type"] = _conn_type
                    from core.query_cache import make_cache_key as _mk_sql_ck, get_cached_result as _get_sql_cached
                    _sql_cache_key = _mk_sql_ck(_sql_qc_dict)
                    if request.cache_strategy == "auto":
                        _sql_cached_path = _get_sql_cached(_sql_cache_key)
                        if _sql_cached_path:
                            try:
                                _sql_cached_size = _sql_cached_path.stat().st_size
                            except FileNotFoundError:
                                from core.query_cache import invalidate as _sql_cache_inv
                                _sql_cache_inv(_sql_cache_key)
                                _sql_cached_path = None
                        if _sql_cached_path:
                            _c_file_size = _sql_cached_path.stat().st_size
                            _c_stats = {}
                            try:
                                import pyarrow.parquet as _pq_c
                                _c_pf = _pq_c.ParquetFile(str(_sql_cached_path))
                                _c_stats = {"total_rows": _c_pf.metadata.num_rows,
                                            "total_columns": _c_pf.metadata.num_columns}
                            except Exception:
                                pass
                            _c_exec_id = str(uuid.uuid4())
                            _c_file_id = str(uuid.uuid4())
                            _db_manager.create_execution(
                                execution_id=_c_exec_id,
                                query_id=request.query_id,
                                query_config=_sql_qc_dict,
                                executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                            )
                            _db_manager.update_execution(_c_exec_id, status="completed",
                                                        output_file=str(_sql_cached_path),
                                                        total_rows=_c_stats.get("total_rows", 0),
                                                        file_size_bytes=_c_file_size)
                            _db_manager.create_download_file(
                                file_id=_c_file_id, execution_id=_c_exec_id,
                                filename=f"cached_result_{_c_exec_id}.parquet",
                                file_path=str(_sql_cached_path),
                                file_size_bytes=_c_file_size,
                                expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                            )
                            await _ws_manager.broadcast({
                                "type": "execution_completed", "execution_id": _c_exec_id,
                                "file_id": _c_file_id, "cache_hit": True,
                                "stats": _c_stats,
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                            })
                            return {
                                "execution_id": _c_exec_id, "status": "completed",
                                "cache_hit": True, "file_id": _c_file_id,
                                "message": "Served from cache",
                            }

                    _username = _user.get("username", "guest") if _user else "guest"
                    with _user_query_lock:
                        _active = _user_query_counts.get(_username, 0)
                        if _active >= _qe_cfg.max_concurrent_per_user:
                            raise HTTPException(
                                status_code=429,
                                detail=f"Too many concurrent queries ({_active} running)."
                            )
                        _user_query_counts[_username] = _active + 1
                    try:
                        execution_id = str(uuid.uuid4())
                        # Record checkpoint intent (Phase 41)
                        from core.checkpoint import record_intent as _record_intent_sql
                        _record_intent_sql(execution_id, query_config_model.model_dump(),
                                           executed_by=request.executed_by or _username,
                                           query_id=request.query_id)
                        execution = _db_manager.create_execution(
                            execution_id=execution_id,
                            query_id=request.query_id,
                            query_config=query_config_model.model_dump(),
                            executed_by=request.executed_by or _username
                        )
                        _task = asyncio.create_task(
                            execute_sql_connector_background(
                                execution_id, sql_connector, sql_str,
                                query_id=request.query_id, executed_by=_username,
                                cache_key=_sql_cache_key,
                                cache_strategy=request.cache_strategy or "auto",
                                query_config_dict=_sql_qc_dict,
                            )
                        )
                        pass  # pool tracks the task
                    except Exception:
                        with _user_query_lock:
                            _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                        raise
                    _audit(_user, "execute_sql_connector_query", None, "execution", execution_id,
                           {"conn_type": _conn_type, "table": table_ref, "query_id": request.query_id})
                    logger.info(f"SQL connector query started: {execution_id} ({_conn_type}:{table_ref})")
                    return {
                        "execution_id": execution_id,
                        "status": "pending",
                        "started_at": execution["started_at"],
                        "message": f"SQL connector query started ({_conn_type})"
                    }

        # Also treat MV/local table refs as "registered" (skip file validation, use _setup_registered_views)
        if not _uses_registered:
            _all_file_paths = list(query_config_model.files or [])
            if any(str(f).startswith("__materialized__:") or str(f).startswith("__local__:") for f in _all_file_paths):
                _uses_registered = True
                # Ensure engine has the required attributes for _execute_registered_table_*
                if not hasattr(active_engine, '_registered_tables') or not active_engine._registered_tables:
                    active_engine._registered_tables = []
                if not hasattr(active_engine, '_s3_conn_config') or not active_engine._s3_conn_config:
                    active_engine._s3_conn_config = {}
                if not hasattr(active_engine, '_s3_bucket'):
                    active_engine._s3_bucket = ""
                if not hasattr(active_engine, '_s3_conn_id'):
                    active_engine._s3_conn_id = _effective_conn_id

        engine_config = convert_query_config_to_engine(query_config_model)

        # ── Cross-connection join / union path ────────────────────────────────
        if request.secondary_connection_id and request.secondary_query_config:
            # Validate secondary connection exists
            sec_conn_record = _db_manager.get_connection_raw(request.secondary_connection_id)
            if not sec_conn_record:
                raise HTTPException(
                    status_code=404,
                    detail=f"Secondary connection {request.secondary_connection_id} not found"
                )

            # Validate secondary query config is parseable
            try:
                sec_qc_model = QueryConfigModel(**request.secondary_query_config)
            except Exception as _pve:
                raise HTTPException(status_code=400,
                                    detail=f"Invalid secondary_query_config: {_pve}")

            # Validate join_config present when mode=join
            if request.combine_mode == "join":
                _jc = request.join_config or {}
                if not _jc.get("left_on") or not _jc.get("right_on"):
                    raise HTTPException(
                        status_code=400,
                        detail="join_config with left_on and right_on is required when combine_mode='join'"
                    )

            # Resolve secondary engine
            secondary_engine = _engine
            _sc_type = sec_conn_record.get('connection_type')
            _sc_cfg = sec_conn_record.get('config', {})
            if _sc_type == 'local':
                _sc_path = str(_normalize_path(_sc_cfg.get('base_path', './data/parquet')))
                secondary_engine = ParquetQueryEngine(
                    base_path=_sc_path,
                    chunk_size=_qe_cfg.chunk_size,
                )
            elif _sc_type == 's3':
                secondary_engine = ParquetQueryEngine(
                    base_path=str(_paths.parquet_dir),
                    chunk_size=_qe_cfg.chunk_size,
                    s3_config=build_s3_config(_sc_cfg),
                )

            secondary_config = convert_query_config_to_engine(sec_qc_model)

            # ── Cross-query cache check ───────────────────────────────────────
            _cross_qc_dict = {
                "primary": query_config_model.model_dump(),
                "secondary": sec_qc_model.model_dump(),
                "combine_mode": request.combine_mode,
                "join_config": request.join_config,
            }
            from core.query_cache import make_cache_key as _mk_cx_ck, get_cached_result as _get_cx_cached
            _cross_cache_key = _mk_cx_ck(_cross_qc_dict)
            if request.cache_strategy == "auto":
                _cx_cached_path = _get_cx_cached(_cross_cache_key)
                if _cx_cached_path:
                    try:
                        _cx_cached_size = _cx_cached_path.stat().st_size
                    except FileNotFoundError:
                        from core.query_cache import invalidate as _cx_inv
                        _cx_inv(_cross_cache_key)
                        _cx_cached_path = None
                if _cx_cached_path:
                    _cx_file_size = _cx_cached_path.stat().st_size
                    _cx_stats = {}
                    try:
                        import pyarrow.parquet as _pq_cx
                        _cx_pf = _pq_cx.ParquetFile(str(_cx_cached_path))
                        _cx_stats = {"total_rows": _cx_pf.metadata.num_rows,
                                     "total_columns": _cx_pf.metadata.num_columns}
                    except Exception:
                        pass
                    _cx_exec_id = str(uuid.uuid4())
                    _cx_file_id = str(uuid.uuid4())
                    _db_manager.create_execution(
                        execution_id=_cx_exec_id,
                        query_id=request.query_id,
                        query_config=query_config_model.model_dump(),
                        executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                    )
                    _db_manager.update_execution(_cx_exec_id, status="completed",
                                                    output_file=str(_cx_cached_path),
                                                    total_rows=_cx_stats.get("total_rows", 0),
                                                    file_size_bytes=_cx_file_size)
                    _db_manager.create_download_file(
                        file_id=_cx_file_id, execution_id=_cx_exec_id,
                        filename=f"cached_result_{_cx_exec_id}.parquet",
                        file_path=str(_cx_cached_path),
                        file_size_bytes=_cx_file_size,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                    )
                    await _ws_manager.broadcast({
                        "type": "execution_completed", "execution_id": _cx_exec_id,
                        "file_id": _cx_file_id, "cache_hit": True,
                        "stats": _cx_stats, "combine_mode": request.combine_mode,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    return {
                        "execution_id": _cx_exec_id, "status": "completed",
                        "cache_hit": True, "file_id": _cx_file_id,
                        "message": "Served from cache",
                    }

            _username = _user.get("username", "guest") if _user else "guest"
            _max_per_user = _qe_cfg.max_concurrent_per_user
            with _user_query_lock:
                _active = _user_query_counts.get(_username, 0)
                if _active >= _max_per_user:
                    raise HTTPException(
                        status_code=429,
                        detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                               "Wait for one to complete or cancel it first."
                    )
                _user_query_counts[_username] = _active + 1

            # Guard: decrement counter if task setup fails after increment
            try:
                execution_id = str(uuid.uuid4())
                # Record checkpoint intent (Phase 41)
                from core.checkpoint import record_intent as _record_intent_cross
                _record_intent_cross(execution_id, query_config_model.model_dump(),
                                     executed_by=request.executed_by or _username,
                                     query_id=request.query_id)
                execution = _db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by or _username
                )
                _task = asyncio.create_task(
                    execute_cross_query_background(
                        execution_id,
                        active_engine,
                        engine_config,
                        secondary_engine,
                        secondary_config,
                        combine_mode=request.combine_mode,
                        join_config=request.join_config,
                        query_id=request.query_id,
                        executed_by=_username,
                        cache_key=_cross_cache_key,
                        cache_strategy=request.cache_strategy or "auto",
                        query_config_dict=_cross_qc_dict,
                    )
                )
                pass  # pool tracks the task
            except Exception:
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                raise

            _audit(_user, "execute_cross_query", None, "execution", execution_id,
                   {"query_id": request.query_id,
                    "primary_connection_id": request.connection_id,
                    "secondary_connection_id": request.secondary_connection_id,
                    "combine_mode": request.combine_mode})
            logger.info(f"Cross-connection query started: {execution_id} ({request.combine_mode})")

            return {
                "execution_id": execution_id,
                "status": "pending",
                "started_at": execution["started_at"],
                "is_cross_connection": True,
                "combine_mode": request.combine_mode,
                "message": f"Cross-connection {request.combine_mode.upper()} query started"
            }

        # ── Single-source path (original) ─────────────────────────────────────
        # Skip file-level validation for registered tables — they use virtual
        # paths (__registered__:name) that don't exist on disk / S3.
        if not _uses_registered:
            # Run validate_query off the event loop — it reads file schemas from disk
            # and can take 100 ms – 2 s per file, which would stall all other requests.
            _loop = asyncio.get_running_loop()
            validation = await _loop.run_in_executor(
                _get_light_executor_fn(), active_engine.validate_query, engine_config
            )
            if not validation["valid"]:
                raise HTTPException(
                    status_code=400,
                    detail={"message": "Invalid query configuration", "errors": validation["errors"]}
                )

        # ── Query result cache check ──────────────────────────────────────────
        # Check cache for ALL query types (including S3/connection queries).
        # Skipped when cache_strategy is 'bypass' or 'refresh'.
        if request.cache_strategy == "auto":
            from core.query_cache import make_cache_key, get_cached_result, invalidate as _cache_invalidate
            _cache_key = make_cache_key(query_config_model.model_dump())
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                try:
                    _cached_size = _cached_path.stat().st_size   # Guard: file may vanish between lookup and here
                except FileNotFoundError:
                    # File deleted externally between cache lookup and now — evict stale record, fall through
                    logger.warning("[query_cache] Cached file gone before serve: %s", _cached_path)
                    _cache_invalidate(_cache_key)
                    _cached_path = None

            if _cached_path:
                # Read stats first so we can persist total_rows in the execution record
                _cache_stats = {}
                try:
                    import pyarrow.parquet as _pq_s
                    _pf = _pq_s.ParquetFile(str(_cached_path))
                    _cache_stats = {"total_rows": _pf.metadata.num_rows, "total_columns": _pf.metadata.num_columns}
                except Exception:
                    pass
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                _db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                _db_manager.update_execution(execution_id, status="completed",
                                            output_file=str(_cached_path),
                                            total_rows=_cache_stats.get("total_rows", 0),
                                            file_size_bytes=_cached_size)
                _db_manager.create_download_file(
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_size,
                    expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                )
                await _ws_manager.broadcast({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "stats": _cache_stats,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # ── Base-data reuse: query local parquet instead of re-downloading ────
        # If the exact cache missed but the same base data (FROM/WHERE/JOIN) is
        # already on disk from a previous S3 download, run the new SELECT /
        # aggregation / ORDER BY locally via DuckDB — zero network round-trip.
        if request.cache_strategy in ("auto", "refresh"):
            try:
                from core.query_cache import make_base_data_key, get_cached_result as _get_base, store_result as _store_base
                _qcd_base = query_config_model.model_dump()
                _base_key = make_base_data_key(_qcd_base)
                _base_path = _get_base(_base_key)
                if _base_path and _base_path.exists():
                    _bd_exec_id = str(uuid.uuid4())
                    _bd_output = _paths.downloads_dir / f"{_bd_exec_id}.parquet"
                    _loop_bd = asyncio.get_running_loop()
                    _bd_result = await _loop_bd.run_in_executor(
                        _query_executor,
                        run_base_data_local_query,
                        _base_path, _qcd_base, _bd_output,
                    )
                    if _bd_result and _bd_output.exists():
                        _bd_file_id = str(uuid.uuid4())
                        _db_manager.create_execution(
                            execution_id=_bd_exec_id,
                            query_id=request.query_id,
                            query_config=_qcd_base,
                            executed_by=request.executed_by,
                        )
                        _db_manager.update_execution(
                            _bd_exec_id, status="completed",
                            output_file=str(_bd_output),
                            total_rows=_bd_result["total_rows"],
                            file_size_bytes=_bd_result["file_size_bytes"],
                        )
                        _db_manager.create_download_file(
                            file_id=_bd_file_id, execution_id=_bd_exec_id,
                            filename=f"query_result_{_bd_exec_id}.parquet",
                            file_path=str(_bd_output),
                            file_size_bytes=_bd_result["file_size_bytes"],
                            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
                        )
                        # Store exact cache entry so next identical query is an instant hit
                        try:
                            from core.query_cache import make_cache_key as _mkck_bd, store_result as _store_exact
                            _exact_key = _mkck_bd(_qcd_base)
                            _store_exact(_exact_key, _bd_output, _qcd_base,
                                         row_count=_bd_result["total_rows"], copy=False)
                        except Exception:
                            pass
                        await _ws_manager.broadcast({
                            "type": "execution_completed", "execution_id": _bd_exec_id,
                            "file_id": _bd_file_id, "cache_hit": True, "base_data_reuse": True,
                            "stats": {
                                "total_rows": _bd_result.get("total_rows"),
                                "total_columns": _bd_result.get("total_columns"),
                                "duration_seconds": _bd_result.get("duration_seconds"),
                            },
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        })
                        return {
                            "execution_id": _bd_exec_id, "status": "completed",
                            "cache_hit": True, "base_data_reuse": True,
                            "file_id": _bd_file_id,
                            "message": "Served from local base-data cache (no S3 download)",
                        }
            except Exception as _bd_exc:
                logger.debug("[base_data_reuse] Check failed, falling through: %s", _bd_exc)

        # ── In-flight deduplication ──────────────────────────────────────────────
        # If an identical query (same cache_key) is already running, create a
        # shadow execution that waits for the primary instead of starting a
        # duplicate transfer.  Each user gets their own execution record;
        # only one network transfer / query happens.
        # asyncio is single-threaded between awaits so the check+register is atomic.
        _dedup_cache_key: Optional[str] = None
        _query_config_dict = query_config_model.model_dump()
        from core.query_cache import make_cache_key as _mkck_dedup
        _dedup_cache_key = _mkck_dedup(_query_config_dict)

        if _dedup_cache_key in _inflight_queries:
            _primary_id, _inflight_event = _inflight_queries[_dedup_cache_key]
            _username_dedup = _user.get("username", "guest") if _user else "guest"
            shadow_id = str(uuid.uuid4())
            _db_manager.create_execution(
                execution_id=shadow_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username_dedup,
            )
            asyncio.create_task(
                join_inflight_query(shadow_id, _dedup_cache_key, _inflight_event, _primary_id)
            )
            logger.info("[dedup] %s joined in-flight %s (key=%s...)",
                        shadow_id[:8], _primary_id[:8], _dedup_cache_key[:8])
            return {
                "execution_id": shadow_id,
                "status": "pending",
                "message": "Query already running — result will be shared",
            }

        # Per-user rate limit (cross-process via Redis when available) — 22B
        _username = _user.get("username", "guest") if _user else "guest"
        try:
            from core.rate_limiter import check_rate_limit, RateLimitExceededError as _RLE
            check_rate_limit("execute", _username, limit=60, window_seconds=60)
        except _RLE as _rle:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: max 60 query submissions per minute. "
                       f"Retry after {_rle.retry_after}s.",
                headers={"Retry-After": str(_rle.retry_after)},
            )
        except Exception:
            pass  # rate limiter must never block queries

        # Per-user concurrent query limit
        _max_per_user = _qe_cfg.max_concurrent_per_user
        with _user_query_lock:
            _active = _user_query_counts.get(_username, 0)
            if _active >= _max_per_user:
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                           "Wait for one to complete or cancel it first."
                )
            _user_query_counts[_username] = _active + 1

        # ── Idempotency check ─────────────────────────────────────────────
        if request.idempotency_key:
            from core.execution_state import check_idempotency, register_idempotency
            _existing_exec_id = check_idempotency(request.idempotency_key)
            if _existing_exec_id:
                _existing = _db_manager.get_execution(_existing_exec_id)
                if _existing:
                    return {
                        "execution_id": _existing_exec_id,
                        "status": _existing.get("status", "pending"),
                        "started_at": _existing.get("started_at"),
                        "message": "Duplicate request — returning existing execution",
                        "idempotent": True,
                    }

        # Guard: decrement counter if task setup fails after increment
        try:
            execution_id = str(uuid.uuid4())
            if request.idempotency_key:
                from core.execution_state import register_idempotency
                register_idempotency(request.idempotency_key, execution_id)

            # Record checkpoint intent BEFORE execution starts (Phase 41)
            from core.checkpoint import record_intent as _record_intent, mark_started as _mark_started, mark_completed as _mark_completed
            _record_intent(execution_id, query_config_model.model_dump(),
                           executed_by=request.executed_by or _username,
                           query_id=request.query_id)

            execution = _db_manager.create_execution(
                execution_id=execution_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username
            )

            # ── External executor mode: enqueue and return immediately ─────
            from core.config import executor as _exec_cfg
            if _exec_cfg.mode == "external":
                from core.queue_backend import get_task_queue
                get_task_queue().enqueue_task(
                    task_id=str(uuid.uuid4()),
                    task_type="parquet_query",
                    payload={
                        "execution_id": execution_id,
                        "query_config": query_config_model.model_dump(),
                        "connection_id": _effective_conn_id,
                        "executed_by": _username,
                        "raw_sql": request.raw_sql,
                        "cache_strategy": request.cache_strategy,
                        "callback_url": request.callback_url or "",
                    },
                    execution_id=execution_id,
                    created_by=_username,
                    priority=0,
                )
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)

                # ── Wait mode: poll until done or timeout ─────────────────
                if request.wait:
                    _deadline = asyncio.get_event_loop().time() + request.wait_timeout
                    while asyncio.get_event_loop().time() < _deadline:
                        await asyncio.sleep(0.5)
                        _exec_rec = _db_manager.get_execution(execution_id)
                        if _exec_rec and _exec_rec.get("status") not in ("pending", "processing"):
                            return _exec_rec
                    # Timed out — return current state
                    _exec_rec = _db_manager.get_execution(execution_id)
                    return _exec_rec or {
                        "execution_id": execution_id,
                        "status": "pending",
                        "message": f"Still processing after {request.wait_timeout}s timeout",
                    }

                return {
                    "execution_id": execution_id,
                    "status": "pending",
                    "started_at": execution["started_at"],
                    "message": "Query enqueued for external execution",
                }

            # ── Stale-result fallback file ──────────────────────────────────
            # Resolved BEFORE launching the task so execute_query_background
            # can serve the last known-good result on connection/auth failure.
            _fallback_output_file: Optional[str] = None
            # 1) Stale cache: entry expired but physical file still on disk
            if _dedup_cache_key:
                try:
                    from core.query_cache import get_stale_cached_result as _get_stale
                    _sc = _get_stale(_dedup_cache_key)
                    if _sc:
                        _fallback_output_file = str(_sc)
                except Exception:
                    pass
            # 2) Last successful execution for this saved query
            if not _fallback_output_file and request.query_id:
                try:
                    _lx = _db_manager.get_last_successful_output_file(request.query_id)
                    if _lx:
                        _fallback_output_file = _lx["output_file"]
                except Exception:
                    pass
            # ────────────────────────────────────────────────────────────────

            # Register as primary in-flight BEFORE starting the task (no await between)
            if _dedup_cache_key:
                _inflight_queries[_dedup_cache_key] = (execution_id, asyncio.Event())

            # Use _run_query_and_signal so _inflight_queries is cleaned up on completion.
            _task = asyncio.create_task(
                _run_query_and_signal(
                    execution_id,
                    engine_config,
                    request.query_id,
                    active_engine,
                    executed_by=_username,
                    raw_sql=request.raw_sql,
                    cache_strategy=request.cache_strategy,
                    cache_key=_dedup_cache_key,
                    query_config_dict=_query_config_dict,
                    fallback_output_file=_fallback_output_file,
                )
            )
            pass  # pool tracks the task
        except Exception:
            if _dedup_cache_key:
                _inflight_queries.pop(_dedup_cache_key, None)
            with _user_query_lock:
                _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
            raise

        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started",
            "query_warnings": _query_warnings,
        }

    except HTTPException:
        raise
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED"})
    except Exception as e:
        logger.error(f"Error executing query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
