"""
Error detection utilities — S3 auth errors, connection errors, JSON-safe value conversion.

Extracted from main.py to keep the main module focused on app wiring.
"""
from __future__ import annotations

import decimal
import logging
from datetime import date as _date_type, datetime

from fastapi import HTTPException

logger = logging.getLogger(__name__)


# ── JSON-safe value conversion ───────────────────────────────────────────────

def jsonify_value(v):
    """Convert a single value to a JSON-safe type."""
    if v is None:
        return None
    if isinstance(v, (datetime, _date_type)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (list, tuple)):
        return [jsonify_value(x) for x in v]
    return v


def jsonify_rows(rows: list):
    """In-place convert non-JSON-safe values in a list of dicts."""
    for row in rows:
        for k, v in row.items():
            row[k] = jsonify_value(v)


# ── S3 auth error detection ─────────────────────────────────────────────────

S3_EXPIRED_PATTERNS = (
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired',
)


def is_s3_auth_error(exc: Exception) -> bool:
    """Detect expired / invalid AWS credentials from DuckDB httpfs or boto3 errors."""
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in S3_EXPIRED_PATTERNS)


def raise_if_s3_auth_error(exc: Exception):
    """Raise HTTP 401 with TOKEN_EXPIRED code if the exception is an AWS credential issue."""
    if is_s3_auth_error(exc):
        raise HTTPException(
            status_code=401,
            detail={
                "message": "Your AWS session credentials have expired. Please update your connection with fresh credentials.",
                "error_code": "TOKEN_EXPIRED",
            },
        )


# ── Broad connection error detection (stale-result fallback) ────────────────

CONN_ERROR_PATTERNS = (
    # AWS / S3 auth
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired', 'invalidclienttokenid',
    'accessdenied', 'access denied', 'nosuchbucket', 'invalidaccesskeyid',
    # General network
    'connection refused', 'connection timed out', 'connection reset',
    'network unreachable', 'name resolution failed', 'could not connect',
    'failed to connect', 'socket timeout', 'ssl: certificate_verify_failed',
    'no route to host', 'broken pipe',
    # HTTP auth (specific status codes only — avoid matching 404 not-found)
    'http 401', 'http 403', 'status code: 401', 'status code: 403',
    '401 unauthorized', '403 forbidden',
    # Snowflake / Databricks / Trino
    'authentication failed', 'jwt token is invalid or expired',
    'token is expired', 'login failed', 'incorrect username or password',
    # DuckDB httpfs
    'failed to download', 'could not open remote file',
    'curl error', 'could not resolve host',
)


def is_connection_error(exc: Exception) -> bool:
    """True if the exception indicates a network or auth failure (not a query/data error).
    Used to decide whether a stale cached result can be served as a fallback.
    """
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in CONN_ERROR_PATTERNS)
