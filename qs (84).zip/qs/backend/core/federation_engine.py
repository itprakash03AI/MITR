"""
Federation Engine — Cross-Source Query Execution for Semantic Layer (Phase 54)

Generates and executes SQL from semantic layer metadata, supporting:
  1. Single-dataset execution (one or more S3/SQL sources with relationships)
  2. Multi-dataset merged execution (BO-style multiple data providers)
  3. DuckDB named secrets for multi-S3-endpoint queries in a single session
  4. Smart routing: S3 → DuckDB, SQL connectors → connector SDK, mixed → hybrid

The engine translates semantic layer column selections, filters, and conditions
into physical SQL, resolves connections, and returns results as Parquet files.
"""

from __future__ import annotations

import hashlib
import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# Data classes
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class FederationResult:
    """Result of a federated dataset execution."""
    execution_id: str
    dataset_id: int
    output_path: str = ""
    total_rows: int = 0
    columns: List[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    sql_generated: str = ""
    sources_used: List[Dict[str, Any]] = field(default_factory=list)
    merged_dataset_id: Optional[int] = None
    primary_rows: int = 0
    secondary_rows: int = 0
    # Phase 55: Aggregation cache metadata
    cache_hit: bool = False
    cache_age_seconds: float = 0.0
    cache_entry_id: Optional[int] = None
    cache_grain: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "dataset_id": self.dataset_id,
            "output_path": self.output_path,
            "total_rows": self.total_rows,
            "columns": self.columns,
            "duration_seconds": self.duration_seconds,
            "sql_generated": self.sql_generated,
            "sources_used": self.sources_used,
            "merged_dataset_id": self.merged_dataset_id,
            "primary_rows": self.primary_rows,
            "secondary_rows": self.secondary_rows,
            "cache_hit": self.cache_hit,
            "cache_age_seconds": self.cache_age_seconds,
            "cache_entry_id": self.cache_entry_id,
            "cache_grain": self.cache_grain,
        }


@dataclass
class ColumnSelection:
    """A column selected by the user for query execution."""
    column_id: int
    physical_name: str
    friendly_name: str
    column_type: str          # dimension | measure | detail | kpi
    aggregation: str = ""     # sum, avg, count, min, max, count_distinct
    source_table: str = ""    # resolved source table for multi-table datasets


@dataclass
class FilterSpec:
    """A filter applied by the user."""
    column_id: int
    physical_name: str
    operator: str             # eq, neq, gt, gte, lt, lte, in, not_in, like, between, is_null, is_not_null
    value: Any = None
    value2: Any = None        # for 'between' operator
    source_table: str = ""


@dataclass
class OrderBySpec:
    """Sort specification."""
    column_id: int
    physical_name: str
    direction: str = "asc"    # asc | desc


# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

# Operators mapped to SQL fragments
_OP_MAP = {
    "eq":          "= {v}",
    "neq":         "!= {v}",
    "gt":          "> {v}",
    "gte":         ">= {v}",
    "lt":          "< {v}",
    "lte":         "<= {v}",
    "like":        "LIKE {v}",
    "not_like":    "NOT LIKE {v}",
    "is_null":     "IS NULL",
    "is_not_null": "IS NOT NULL",
}

# Whitelisted aggregation functions — only these are allowed in generated SQL
VALID_AGGREGATIONS = {"SUM", "AVG", "COUNT", "MIN", "MAX", "COUNT_DISTINCT"}

# Valid sort directions
VALID_DIRECTIONS = {"ASC", "DESC"}

# S3-type connection types that use DuckDB
S3_CONNECTION_TYPES = {"s3", "s3_minio", "s3_compatible"}

# SQL connector types
SQL_CONNECTION_TYPES = {"trino", "snowflake", "databricks", "oracle", "postgresql", "mysql"}

# Valid merge types for pd.merge
VALID_MERGE_TYPES = {"inner", "left", "right", "outer", "cross"}

# Thread lock for DuckDB extension loading (shared with data_grid_api)
_ext_lock = threading.Lock()


# ═══════════════════════════════════════════════════════════════════════════════
# Federation Engine
# ═══════════════════════════════════════════════════════════════════════════════

class FederationEngine:
    """Executes queries against semantic layer datasets.

    Resolves connections, generates SQL from semantic layer metadata,
    and uses DuckDB named secrets for multi-S3-endpoint federation.
    """

    def __init__(self, db_manager, output_dir: str = "./data/downloads"):
        self._db = db_manager
        self._output_dir = output_dir

    # ── Public API ────────────────────────────────────────────────────────────

    def execute_dataset_query(
        self,
        *,
        dataset_id: int,
        column_ids: List[int],
        filters: Optional[List[Dict[str, Any]]] = None,
        condition_ids: Optional[List[int]] = None,
        order_by: Optional[List[Dict[str, Any]]] = None,
        limit: Optional[int] = None,
        execution_id: Optional[str] = None,
        user_role: str = "viewer",
        progress_callback=None,
    ) -> FederationResult:
        """Execute a query against a single dataset using semantic layer metadata.

        Args:
            dataset_id:    Semantic layer dataset ID
            column_ids:    List of DatasetColumn.id to select
            filters:       [{column_id, operator, value, value2?}]
            condition_ids: Pre-defined condition IDs to apply
            order_by:      [{column_id, direction}]
            limit:         Max rows (falls back to config default)
            execution_id:  Execution UUID (generated if omitted)
            user_role:     Role for column visibility filtering
            progress_callback: Optional callable(dict) for progress

        Returns:
            FederationResult with output parquet path and metadata
        """
        execution_id = execution_id or str(uuid.uuid4())
        t_start = datetime.now(timezone.utc)

        def _emit(step: str, **kw):
            if progress_callback:
                try:
                    progress_callback({"step": step, "execution_id": execution_id, **kw})
                except Exception as exc:
                    logger.warning("progress_callback failed: %s", exc)

        _emit("resolving", message="Resolving dataset metadata")

        # 1. Load full dataset
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        # 2. Resolve config
        from core import config
        row_limit = limit or config.semantic_layer.default_row_limit
        # Enforce hard cap from federation config
        max_rows = config.federation.max_result_rows
        if row_limit > max_rows:
            row_limit = max_rows

        # 3. Resolve selected columns
        all_columns = ds.get("columns", [])
        col_map = {c["id"]: c for c in all_columns}
        selected = self._resolve_columns(column_ids, col_map, user_role)
        if not selected:
            raise ValueError("No valid columns selected")

        # 4. Resolve filters
        filter_specs = self._resolve_filters(filters or [], col_map)

        # 5. Resolve pre-defined conditions
        conditions = ds.get("conditions", [])
        cond_clauses = [
            c.get("where_clause", "") for c in conditions
            if c.get("id") in (condition_ids or []) and c.get("where_clause")
        ]

        # 6. Resolve order by
        order_specs = self._resolve_order_by(order_by or [], col_map)

        # 6.5  Smart routing -- check aggregation cache (BO Aggregate Awareness)
        try:
            from core.agg_cache import check_cache_hit
            dim_col_ids = [c.column_id for c in selected
                           if c.column_type in ("dimension", "detail")]
            measure_col_ids = [c.column_id for c in selected
                               if c.column_type in ("measure", "kpi") and c.aggregation]
            if dim_col_ids and measure_col_ids:
                cache_result = check_cache_hit(
                    dataset_id=dataset_id,
                    requested_dimension_col_ids=dim_col_ids,
                    requested_measure_col_ids=measure_col_ids,
                )
                if cache_result:
                    _emit("cache_hit",
                          message=f"Serving from aggregation cache ({cache_result.grain_label})")
                    df = pd.read_parquet(cache_result.file_path)
                    # Post-filter cached data
                    df = self._apply_filters_to_df(df, filter_specs)
                    # Apply order
                    if order_specs:
                        sort_cols = [o.physical_name for o in order_specs
                                     if o.physical_name in df.columns]
                        sort_asc = [o.direction.upper() == "ASC" for o in order_specs
                                    if o.physical_name in df.columns]
                        if sort_cols:
                            df = df.sort_values(sort_cols, ascending=sort_asc)
                    # Apply limit
                    if row_limit and len(df) > row_limit:
                        df = df.head(row_limit)
                    # Select only requested columns
                    req_phys = [c.physical_name for c in selected
                                if c.physical_name in df.columns]
                    if req_phys:
                        df = df[req_phys]
                    # Save result
                    out_dir = Path(self._output_dir)
                    out_dir.mkdir(parents=True, exist_ok=True)
                    output_path = str(out_dir / f"{execution_id}.parquet")
                    df.to_parquet(output_path, index=False, engine="pyarrow")
                    duration = (datetime.now(timezone.utc) - t_start).total_seconds()
                    _emit("completed",
                          message=f"Cache hit: {len(df)} rows in {duration:.3f}s",
                          total_rows=len(df))
                    logger.info("[%s] AGG CACHE HIT dataset %d: entry=%d grain=%s "
                                "rows=%d time=%.3fs",
                                execution_id, dataset_id, cache_result.entry_id,
                                cache_result.grain_label, len(df), duration)
                    return FederationResult(
                        execution_id=execution_id,
                        dataset_id=dataset_id,
                        output_path=output_path,
                        total_rows=len(df),
                        columns=df.columns.tolist(),
                        duration_seconds=round(duration, 3),
                        sql_generated=f"-- Served from aggregation cache "
                                      f"(entry={cache_result.entry_id}, "
                                      f"grain={cache_result.grain_label})",
                        sources_used=[{"type": "agg_cache",
                                       "entry_id": cache_result.entry_id,
                                       "grain": cache_result.grain_label}],
                        primary_rows=len(df),
                        cache_hit=True,
                        cache_age_seconds=cache_result.cache_age_seconds,
                        cache_entry_id=cache_result.entry_id,
                        cache_grain=cache_result.grain_label,
                    )
        except Exception as _cache_exc:
            logger.warning("[%s] Agg cache check failed (falling through to live): %s",
                           execution_id, _cache_exc)

        # 7. Resolve connections and determine execution mode
        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        relationships = ds.get("relationships", [])

        _emit("generating_sql", message="Generating SQL from semantic layer")

        # 8. Build SQL
        sql, source_info = self._build_query(
            selected=selected,
            filter_specs=filter_specs,
            cond_clauses=cond_clauses,
            order_specs=order_specs,
            limit=row_limit,
            source_tables=source_tables,
            relationships=relationships,
            connections=connections,
            base_query=ds.get("base_query", ""),
        )

        logger.info("[%s] Generated SQL for dataset %s: %s", execution_id, dataset_id, sql[:200])

        # 9. Execute
        _emit("executing", message="Executing federated query")

        df = self._execute_query(
            sql=sql,
            connections=connections,
            source_tables=source_tables,
            execution_id=execution_id,
            progress_callback=progress_callback,
        )

        # 10. Save result as parquet
        out_dir = Path(self._output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / f"{execution_id}.parquet")
        df.to_parquet(output_path, index=False, engine="pyarrow")

        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Completed: {len(df)} rows in {duration:.1f}s",
              total_rows=len(df))

        logger.info("[%s] Dataset %s executed: %d rows, %.1fs",
                    execution_id, dataset_id, len(df), duration)

        # 10.5  Write-through cache population (optional)
        try:
            from core import config as _cfg
            if _cfg.agg_cache.enabled and _cfg.agg_cache.write_through_enabled:
                from core.agg_cache import maybe_write_through
                maybe_write_through(
                    dataset_id=dataset_id,
                    column_ids=column_ids,
                    output_path=output_path,
                    total_rows=len(df),
                )
        except Exception as _wt_exc:
            logger.debug("Write-through cache population skipped: %s", _wt_exc)

        return FederationResult(
            execution_id=execution_id,
            dataset_id=dataset_id,
            output_path=output_path,
            total_rows=len(df),
            columns=df.columns.tolist(),
            duration_seconds=round(duration, 3),
            sql_generated=sql,
            sources_used=source_info,
            primary_rows=len(df),
        )

    def execute_merged_query(
        self,
        *,
        primary_dataset_id: int,
        secondary_dataset_id: int,
        primary_column_ids: List[int],
        secondary_column_ids: List[int],
        merge_keys: List[Dict[str, str]],  # [{"left": "col_name", "right": "col_name"}]
        merge_type: str = "inner",         # inner | left | right | full
        primary_filters: Optional[List[Dict[str, Any]]] = None,
        secondary_filters: Optional[List[Dict[str, Any]]] = None,
        primary_condition_ids: Optional[List[int]] = None,
        secondary_condition_ids: Optional[List[int]] = None,
        limit: Optional[int] = None,
        execution_id: Optional[str] = None,
        user_role: str = "viewer",
        progress_callback=None,
    ) -> FederationResult:
        """Execute a merged query across two datasets (BO multiple data providers).

        Each dataset is queried independently, then results are merged on
        shared dimension columns (merge keys).
        """
        execution_id = execution_id or str(uuid.uuid4())
        t_start = datetime.now(timezone.utc)

        def _emit(step: str, **kw):
            if progress_callback:
                try:
                    progress_callback({"step": step, "execution_id": execution_id, **kw})
                except Exception as exc:
                    logger.warning("progress_callback failed: %s", exc)

        from core import config
        row_limit = limit or config.semantic_layer.default_row_limit

        # Execute primary dataset
        _emit("primary_query", message="Executing primary dataset")
        primary_result = self.execute_dataset_query(
            dataset_id=primary_dataset_id,
            column_ids=primary_column_ids,
            filters=primary_filters,
            condition_ids=primary_condition_ids,
            limit=row_limit,
            execution_id=f"{execution_id}_primary",
            user_role=user_role,
            progress_callback=progress_callback,
        )

        # Execute secondary dataset
        _emit("secondary_query", message="Executing secondary dataset")
        secondary_result = self.execute_dataset_query(
            dataset_id=secondary_dataset_id,
            column_ids=secondary_column_ids,
            filters=secondary_filters,
            condition_ids=secondary_condition_ids,
            limit=row_limit,
            execution_id=f"{execution_id}_secondary",
            user_role=user_role,
            progress_callback=progress_callback,
        )

        # Load result DataFrames
        _emit("merging", message="Merging datasets on shared dimensions")
        df_primary = pd.read_parquet(primary_result.output_path)
        df_secondary = pd.read_parquet(secondary_result.output_path)

        # Build merge keys
        left_on = [mk["left"] for mk in merge_keys]
        right_on = [mk["right"] for mk in merge_keys]

        # Validate merge type
        if merge_type.lower() not in VALID_MERGE_TYPES:
            raise ValueError(f"Invalid merge type: {merge_type}")

        # Merge
        df_merged = pd.merge(
            df_primary, df_secondary,
            how=merge_type,
            left_on=left_on,
            right_on=right_on,
            suffixes=("", "_merged"),
        )

        # Apply overall row limit
        if row_limit and len(df_merged) > row_limit:
            df_merged = df_merged.head(row_limit)

        # Save merged result
        out_dir = Path(self._output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / f"{execution_id}.parquet")
        df_merged.to_parquet(output_path, index=False, engine="pyarrow")

        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Merged: {len(df_merged)} rows in {duration:.1f}s",
              total_rows=len(df_merged))

        logger.info("[%s] Merged datasets %s + %s: %d rows, %.1fs",
                    execution_id, primary_dataset_id, secondary_dataset_id,
                    len(df_merged), duration)

        return FederationResult(
            execution_id=execution_id,
            dataset_id=primary_dataset_id,
            merged_dataset_id=secondary_dataset_id,
            output_path=output_path,
            total_rows=len(df_merged),
            columns=df_merged.columns.tolist(),
            duration_seconds=round(duration, 3),
            sql_generated=f"MERGE({primary_result.sql_generated}) ON {left_on}",
            sources_used=primary_result.sources_used + secondary_result.sources_used,
            primary_rows=primary_result.total_rows,
            secondary_rows=secondary_result.total_rows,
        )

    def get_column_distinct_values(
        self,
        *,
        dataset_id: int,
        column_id: int,
        parent_filters: Optional[List[Dict[str, Any]]] = None,
        limit: int = 500,
    ) -> List[Any]:
        """Get distinct values for a column (for cascading prompts / LOV).

        When parent_filters are provided, values are filtered by parent selections
        (e.g., selecting Country=US filters Region LOV to US regions).
        """
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        col_map = {c["id"]: c for c in ds.get("columns", [])}
        col = col_map.get(column_id)
        if not col:
            raise ValueError(f"Column {column_id} not found in dataset {dataset_id}")

        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        relationships = ds.get("relationships", [])

        # Build a simple SELECT DISTINCT query
        phys = self._quote_ident(col["physical_name"])
        base_table = self._resolve_base_table(source_tables, connections)

        where_parts = []
        if parent_filters:
            filter_specs = self._resolve_filters(parent_filters, col_map)
            for f in filter_specs:
                clause = self._filter_to_sql(f)
                if clause:
                    where_parts.append(clause)

        where_sql = f" WHERE {' AND '.join(where_parts)}" if where_parts else ""
        sql = f"SELECT DISTINCT {phys} FROM {base_table}{where_sql} ORDER BY {phys} LIMIT {limit}"

        df = self._execute_query(
            sql=sql,
            connections=connections,
            source_tables=source_tables,
            execution_id=str(uuid.uuid4()),
        )

        return df.iloc[:, 0].dropna().tolist() if len(df) > 0 else []

    def preview_dataset(
        self,
        *,
        dataset_id: int,
        limit: int = 100,
        user_role: str = "viewer",
    ) -> Dict[str, Any]:
        """Quick preview of a dataset's data — first N rows of all visible columns."""
        ds = self._db.get_dataset_full(dataset_id)
        if not ds:
            raise ValueError(f"Dataset {dataset_id} not found")

        all_columns = ds.get("columns", [])
        # Filter by role
        visible = [
            c for c in all_columns
            if not c.get("is_hidden")
            and (not c.get("role_whitelist") or user_role in c["role_whitelist"])
        ]

        if not visible:
            return {"columns": [], "rows": [], "total_rows": 0}

        connections = self._resolve_connections(ds)
        source_tables = ds.get("source_tables", [])
        base_table = self._resolve_base_table(source_tables, connections)

        col_exprs = ", ".join(self._quote_ident(c["physical_name"]) for c in visible)
        sql = f"SELECT {col_exprs} FROM {base_table} LIMIT {limit}"

        df = self._execute_query(
            sql=sql,
            connections=connections,
            source_tables=source_tables,
            execution_id=str(uuid.uuid4()),
        )

        return {
            "columns": [
                {"physical_name": c["physical_name"], "friendly_name": c["friendly_name"],
                 "column_type": c["column_type"], "data_type": c.get("data_type", "string")}
                for c in visible
            ],
            "rows": df.to_dict(orient="records"),
            "total_rows": len(df),
        }

    # ── Internal: DataFrame post-filtering (for cache hits) ─────────────────

    def _apply_filters_to_df(self, df: pd.DataFrame,
                             filter_specs: list) -> pd.DataFrame:
        """Apply FilterSpec list to a pandas DataFrame (post-cache-hit filtering)."""
        for f in filter_specs:
            col = f.physical_name
            if col not in df.columns:
                continue
            op = f.operator
            if op == "eq":
                df = df[df[col] == f.value]
            elif op == "neq":
                df = df[df[col] != f.value]
            elif op == "gt":
                df = df[df[col] > f.value]
            elif op == "gte":
                df = df[df[col] >= f.value]
            elif op == "lt":
                df = df[df[col] < f.value]
            elif op == "lte":
                df = df[df[col] <= f.value]
            elif op == "like":
                pattern = str(f.value).replace("%", ".*")
                df = df[df[col].astype(str).str.contains(
                    pattern, case=False, regex=True, na=False)]
            elif op == "in":
                if isinstance(f.value, list):
                    df = df[df[col].isin(f.value)]
            elif op == "not_in":
                if isinstance(f.value, list):
                    df = df[~df[col].isin(f.value)]
            elif op == "between":
                df = df[(df[col] >= f.value) & (df[col] <= f.value2)]
            elif op == "is_null":
                df = df[df[col].isna()]
            elif op == "is_not_null":
                df = df[df[col].notna()]
        return df

    # ── Internal: Column resolution ──────────────────────────────────────────

    def _resolve_columns(
        self,
        column_ids: List[int],
        col_map: Dict[int, Dict[str, Any]],
        user_role: str,
    ) -> List[ColumnSelection]:
        """Resolve column IDs to ColumnSelection objects, respecting role visibility."""
        result = []
        for cid in column_ids:
            col = col_map.get(cid)
            if not col:
                logger.warning("Column %d not found, skipping", cid)
                continue
            # Role check
            whitelist = col.get("role_whitelist") or []
            if whitelist and user_role not in whitelist:
                logger.warning("Column %d not visible to role %s, skipping", cid, user_role)
                continue
            result.append(ColumnSelection(
                column_id=cid,
                physical_name=col["physical_name"],
                friendly_name=col.get("friendly_name", col["physical_name"]),
                column_type=col.get("column_type", "dimension"),
                aggregation=col.get("aggregation", ""),
            ))
        return result

    def _resolve_filters(
        self,
        raw_filters: List[Dict[str, Any]],
        col_map: Dict[int, Dict[str, Any]],
    ) -> List[FilterSpec]:
        result = []
        for f in raw_filters:
            cid = f.get("column_id")
            col = col_map.get(cid) if cid else None
            if not col:
                continue
            result.append(FilterSpec(
                column_id=cid,
                physical_name=col["physical_name"],
                operator=f.get("operator", "eq"),
                value=f.get("value"),
                value2=f.get("value2"),
            ))
        return result

    def _resolve_order_by(
        self,
        raw_order: List[Dict[str, Any]],
        col_map: Dict[int, Dict[str, Any]],
    ) -> List[OrderBySpec]:
        result = []
        for o in raw_order:
            cid = o.get("column_id")
            col = col_map.get(cid) if cid else None
            if not col:
                continue
            result.append(OrderBySpec(
                column_id=cid,
                physical_name=col["physical_name"],
                direction=o.get("direction", "asc"),
            ))
        return result

    # ── Internal: Connection resolution ──────────────────────────────────────

    def _resolve_connections(self, ds: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
        """Load raw (decrypted) connection configs for all connection_ids in a dataset."""
        conn_ids = ds.get("connection_ids", [])
        result = {}
        for cid in conn_ids:
            conn = self._db.get_connection_raw(cid)
            if conn:
                result[cid] = conn
            else:
                logger.warning("Connection %d not found for dataset %s", cid, ds.get("name"))
        return result

    def _get_connection_type(self, conn: Dict[str, Any]) -> str:
        """Determine if a connection is S3-based or SQL-based."""
        ct = (conn.get("connection_type") or "").lower()
        if ct in S3_CONNECTION_TYPES or ct == "s3":
            return "s3"
        return "sql"

    # ── Internal: SQL generation ─────────────────────────────────────────────

    def _build_query(
        self,
        *,
        selected: List[ColumnSelection],
        filter_specs: List[FilterSpec],
        cond_clauses: List[str],
        order_specs: List[OrderBySpec],
        limit: int,
        source_tables: List[Dict[str, Any]],
        relationships: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
        base_query: str = "",
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """Generate SQL from semantic layer metadata.

        Returns (sql_string, source_info_list).
        """
        # If dataset has a base_query (custom SQL), use it as a CTE
        if base_query.strip():
            return self._build_from_base_query(
                base_query=base_query,
                selected=selected,
                filter_specs=filter_specs,
                cond_clauses=cond_clauses,
                order_specs=order_specs,
                limit=limit,
            )

        # Determine the base table expression
        base_table = self._resolve_base_table(source_tables, connections)
        source_info = [{"table": base_table, "type": "primary"}]

        # Build JOIN clauses from relationships
        join_clauses = []
        for rel in relationships:
            join_type = (rel.get("join_type") or "inner").upper()
            right_table = rel.get("right_table", "")
            # Resolve right table to DuckDB expression
            right_expr = self._table_to_expression(right_table, source_tables, connections)
            join_keys = rel.get("join_keys", [])
            on_parts = []
            for jk in join_keys:
                left_col = self._quote_ident(jk.get("left", ""))
                right_col = self._quote_ident(jk.get("right", ""))
                left_table = rel.get("left_table", "")
                # Use table aliases
                on_parts.append(f"{self._quote_ident(left_table)}.{left_col} = {self._quote_ident(right_table)}.{right_col}")
            on_clause = " AND ".join(on_parts) if on_parts else "1=1"
            join_clauses.append(f"{join_type} JOIN {right_expr} AS {self._quote_ident(right_table)} ON {on_clause}")
            source_info.append({"table": right_table, "type": "joined"})

        # SELECT clause — dimensions as-is, measures wrapped in aggregation
        select_parts = []
        group_by_parts = []
        has_aggregation = False

        for col in selected:
            phys = self._quote_ident(col.physical_name)
            if col.column_type in ("measure", "kpi") and col.aggregation:
                agg = col.aggregation.upper()
                if agg not in VALID_AGGREGATIONS:
                    logger.warning("Invalid aggregation '%s' for column %s, treating as dimension",
                                   agg, col.physical_name)
                    select_parts.append(phys)
                    group_by_parts.append(phys)
                elif agg == "COUNT_DISTINCT":
                    select_parts.append(f"COUNT(DISTINCT {phys}) AS {phys}")
                    has_aggregation = True
                else:
                    select_parts.append(f"{agg}({phys}) AS {phys}")
                    has_aggregation = True
            else:
                select_parts.append(phys)
                group_by_parts.append(phys)

        # FROM clause
        from_clause = f"{base_table}"
        if source_tables and len(source_tables) > 0:
            first_table = source_tables[0].get("table", "")
            if first_table:
                from_clause = f"{base_table} AS {self._quote_ident(first_table)}"

        # WHERE clause
        where_parts = []
        for f in filter_specs:
            clause = self._filter_to_sql(f)
            if clause:
                where_parts.append(clause)
        for cond in cond_clauses:
            where_parts.append(f"({cond})")

        # Assemble SQL
        sql = f"SELECT {', '.join(select_parts)}"
        sql += f"\nFROM {from_clause}"
        if join_clauses:
            sql += "\n" + "\n".join(join_clauses)
        if where_parts:
            sql += f"\nWHERE {' AND '.join(where_parts)}"
        if has_aggregation and group_by_parts:
            sql += f"\nGROUP BY {', '.join(group_by_parts)}"
        if order_specs:
            order_parts = []
            for o in order_specs:
                direction = o.direction.upper() if o.direction.upper() in VALID_DIRECTIONS else "ASC"
                order_parts.append(f"{self._quote_ident(o.physical_name)} {direction}")
            sql += f"\nORDER BY {', '.join(order_parts)}"
        sql += f"\nLIMIT {int(limit)}"

        return sql, source_info

    def _build_from_base_query(
        self,
        *,
        base_query: str,
        selected: List[ColumnSelection],
        filter_specs: List[FilterSpec],
        cond_clauses: List[str],
        order_specs: List[OrderBySpec],
        limit: int,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """Build a query wrapping a user-defined base_query as a CTE."""
        select_parts = []
        group_by_parts = []
        has_agg = False

        for col in selected:
            phys = self._quote_ident(col.physical_name)
            if col.column_type in ("measure", "kpi") and col.aggregation:
                agg = col.aggregation.upper()
                if agg not in VALID_AGGREGATIONS:
                    select_parts.append(phys)
                    group_by_parts.append(phys)
                elif agg == "COUNT_DISTINCT":
                    select_parts.append(f"COUNT(DISTINCT {phys}) AS {phys}")
                    has_agg = True
                else:
                    select_parts.append(f"{agg}({phys}) AS {phys}")
                    has_agg = True
            else:
                select_parts.append(phys)
                group_by_parts.append(phys)

        where_parts = []
        for f in filter_specs:
            clause = self._filter_to_sql(f)
            if clause:
                where_parts.append(clause)
        for cond in cond_clauses:
            where_parts.append(f"({cond})")

        sql = f"WITH _base AS (\n{base_query.rstrip().rstrip(';')}\n)\n"
        sql += f"SELECT {', '.join(select_parts)}\nFROM _base"
        if where_parts:
            sql += f"\nWHERE {' AND '.join(where_parts)}"
        if has_agg and group_by_parts:
            sql += f"\nGROUP BY {', '.join(group_by_parts)}"
        if order_specs:
            parts = [
                f"{self._quote_ident(o.physical_name)} {o.direction.upper() if o.direction.upper() in VALID_DIRECTIONS else 'ASC'}"
                for o in order_specs
            ]
            sql += f"\nORDER BY {', '.join(parts)}"
        sql += f"\nLIMIT {int(limit)}"

        return sql, [{"table": "_base (custom SQL)", "type": "base_query"}]

    def _resolve_base_table(
        self,
        source_tables: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
    ) -> str:
        """Resolve the primary source table to a DuckDB-compatible expression."""
        if not source_tables:
            return "DUAL"  # fallback
        first = source_tables[0]
        return self._table_to_expression(
            first.get("table", ""),
            source_tables,
            connections,
            connection_id=first.get("connection_id"),
        )

    def _table_to_expression(
        self,
        table_name: str,
        source_tables: List[Dict[str, Any]],
        connections: Dict[int, Dict[str, Any]],
        connection_id: Optional[int] = None,
    ) -> str:
        """Convert a logical table name to a DuckDB expression.

        For S3 sources: read_parquet('s3://bucket/prefix/**/*.parquet')
        For local: read_parquet('/path/to/data/*.parquet')
        For SQL: the table name directly
        """
        # Find connection_id from source_tables if not provided
        if connection_id is None:
            for st in source_tables:
                if st.get("table") == table_name:
                    connection_id = st.get("connection_id")
                    break

        if connection_id and connection_id in connections:
            conn = connections[connection_id]
            conn_type = (conn.get("connection_type") or "").lower()
            cfg = conn.get("config", {})

            if conn_type in S3_CONNECTION_TYPES or conn_type == "s3":
                bucket = cfg.get("bucket_name", cfg.get("bucket", ""))
                prefix = table_name.strip("/")
                # Pre-list files via boto3 to avoid DuckDB glob crash on on-prem S3
                _pq_files = []
                try:
                    from core.s3_storage import S3StorageHandler, build_s3_config
                    _handler = S3StorageHandler(build_s3_config(cfg))
                    _esc = lambda v: v.replace("'", "''")
                    from core.s3_utilities import list_s3_parquet_files as _list_s3_parquet_files
                    _src_prefix = prefix if not table_name.startswith("s3://") else table_name.replace(f"s3://{bucket}/", "")
                    _pq_files = _list_s3_parquet_files(_handler.s3_client, bucket, _src_prefix)
                except Exception as _fe:
                    logger.warning("Federation: boto3 listing failed for %s/%s: %s", bucket, prefix, _fe)
                if _pq_files:
                    # On-prem S3: pre-sign to avoid DuckDB '=' URL-encoding issue
                    try:
                        from core.s3_utilities import s3_urls_to_presigned as _s3_urls_to_presigned
                        _pq_files = _s3_urls_to_presigned(_handler.s3_client, _pq_files, cfg)
                    except Exception:
                        pass
                    _paths = ", ".join(f"'{self._esc(f)}'" for f in _pq_files)
                    return f"read_parquet([{_paths}], hive_partitioning=true, union_by_name=true)"
                # Fallback to glob
                if table_name.startswith("s3://"):
                    return f"read_parquet('{table_name}/**/*.parquet', hive_partitioning=true)"
                elif bucket:
                    return f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"

        # Local path or plain table name
        if "/" in table_name or "\\" in table_name:
            return f"read_parquet('{table_name}/*.parquet', hive_partitioning=true)"

        return self._quote_ident(table_name)

    # ── Internal: SQL execution ──────────────────────────────────────────────

    def _execute_query(
        self,
        *,
        sql: str,
        connections: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        execution_id: str,
        progress_callback=None,
    ) -> pd.DataFrame:
        """Execute the generated SQL against the appropriate engine.

        For S3 sources: Creates a DuckDB connection with named secrets for
        all involved S3 endpoints, then executes the SQL directly.

        For SQL sources: Uses the existing connector SDK.
        """
        # Classify connections
        s3_conns = {}
        sql_conns = {}
        for cid, conn in connections.items():
            if self._get_connection_type(conn) == "s3":
                s3_conns[cid] = conn
            else:
                sql_conns[cid] = conn

        # Route based on connection types
        if s3_conns and not sql_conns:
            # Pure S3 — use DuckDB with named secrets
            return self._execute_duckdb_s3(sql, s3_conns, execution_id)
        elif sql_conns and not s3_conns:
            # Pure SQL — use first SQL connector
            return self._execute_sql_connector(sql, sql_conns, execution_id)
        elif s3_conns and sql_conns:
            # Hybrid — use DuckDB for S3 part, connector for SQL, merge in-memory
            return self._execute_hybrid(sql, s3_conns, sql_conns, source_tables, execution_id)
        else:
            # No connections — try DuckDB in-memory (dataset might use base_query with CTEs)
            return self._execute_duckdb_plain(sql, execution_id)

    def _execute_duckdb_s3(
        self,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
    ) -> pd.DataFrame:
        """Execute SQL in DuckDB with named secrets for each S3 connection."""
        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB not installed — required for S3 federation")

        con = duckdb.connect(database=":memory:")
        try:
            # Load httpfs extension
            with _ext_lock:
                try:
                    con.execute("INSTALL 'httpfs';")
                except Exception:
                    pass
                con.execute("LOAD 'httpfs';")

            # Create named secrets for each S3 connection
            self._setup_duckdb_secrets(con, s3_conns)

            # Configure DuckDB performance
            self._configure_duckdb_performance(con)

            # Execute query
            logger.info("[%s] DuckDB S3 federation executing: %s", execution_id, sql[:200])
            result = con.execute(sql)
            df = result.fetchdf()
            logger.info("[%s] DuckDB S3 federation: %d rows returned", execution_id, len(df))
            return df
        finally:
            try:
                con.close()
            except Exception:
                pass

    def _setup_duckdb_secrets(
        self,
        con,
        s3_conns: Dict[int, Dict[str, Any]],
    ) -> None:
        """Create DuckDB named secrets for each S3 connection.

        Uses CREATE SECRET to allow multiple S3 endpoints in a single session.
        Each secret is scoped to its bucket path so DuckDB auto-resolves
        which credentials to use for each S3 URI.
        """
        for conn_id, conn in s3_conns.items():
            cfg = conn.get("config", {})
            secret_name = f"s3_conn_{conn_id}"
            bucket = cfg.get("bucket_name", cfg.get("bucket", ""))

            # Resolve credentials
            key, secret, token = self._resolve_s3_credentials(cfg)
            region = cfg.get("region_name") or cfg.get("region") or "us-east-1"
            endpoint = cfg.get("endpoint_url") or cfg.get("endpoint", "")

            # Build CREATE SECRET statement
            params = [f"TYPE S3"]
            if key:
                params.append(f"KEY_ID '{self._esc(key)}'")
            if secret:
                params.append(f"SECRET '{self._esc(secret)}'")
            if token:
                params.append(f"SESSION_TOKEN '{self._esc(token)}'")
            params.append(f"REGION '{self._esc(region)}'")

            if endpoint:
                ep_clean = endpoint.replace("https://", "").replace("http://", "").rstrip("/")
                params.append(f"ENDPOINT '{self._esc(ep_clean)}'")
                # Path-style for on-prem S3 (MinIO, NetApp, etc.)
                force_path = cfg.get("path_style", False)
                use_ssl = endpoint.startswith("https://")
                if not use_ssl:
                    params.append("USE_SSL false")
                    params.append("URL_STYLE 'path'")
                elif force_path:
                    params.append("URL_STYLE 'path'")

            # Scope to bucket — must be inside the parameter list
            if bucket:
                params.append(f"SCOPE 's3://{self._esc(bucket)}'")

            create_sql = f"CREATE SECRET {secret_name} ({', '.join(params)});"
            try:
                con.execute(create_sql)
                logger.info("Created DuckDB secret '%s' for connection %d (bucket=%s)",
                            secret_name, conn_id, bucket)
            except Exception as exc:
                logger.warning("Failed to create DuckDB secret for conn %d: %s — "
                               "falling back to SET pragmas", conn_id, exc)
                # Fallback: use SET pragmas (works for single S3 endpoint)
                self._setup_duckdb_pragmas(con, cfg)

    def _resolve_s3_credentials(self, cfg: Dict[str, Any]) -> Tuple[str, str, str]:
        """Resolve S3 credentials from config, supporting multiple auth modes."""
        auth_mode = (cfg.get("auth_mode") or "keys").lower()

        if auth_mode == "keys":
            return (
                cfg.get("aws_access_key_id", ""),
                cfg.get("aws_secret_access_key", ""),
                cfg.get("aws_session_token", ""),
            )

        # profile / assume_role / iam_role — resolve via boto3
        try:
            import boto3
            region = cfg.get("region_name") or cfg.get("region") or "us-east-1"

            if auth_mode == "assume_role":
                role_arn = cfg.get("role_arn")
                if not role_arn:
                    raise ValueError("role_arn required for assume_role auth_mode")
                base = boto3.Session(
                    profile_name=cfg.get("aws_profile") or None,
                    region_name=region,
                )
                ssl_val = cfg.get("ssl_verify", True)
                verify = not (ssl_val is False or str(ssl_val).lower() == "false")
                sts = base.client("sts", verify=verify)
                try:
                    kw = {
                        "RoleArn": role_arn,
                        "RoleSessionName": cfg.get("role_session_name") or "federation-engine",
                    }
                    if cfg.get("external_id"):
                        kw["ExternalId"] = cfg["external_id"]
                    creds = sts.assume_role(**kw)["Credentials"]
                    return creds["AccessKeyId"], creds["SecretAccessKey"], creds["SessionToken"]
                finally:
                    sts.close()
            else:
                session = boto3.Session(
                    profile_name=cfg.get("aws_profile") or None,
                    region_name=region,
                )
                resolved = session.get_credentials()
                if resolved:
                    frozen = resolved.get_frozen_credentials()
                    return frozen.access_key or "", frozen.secret_key or "", frozen.token or ""
        except Exception as exc:
            logger.warning("Failed to resolve S3 credentials (auth_mode=%s): %s", auth_mode, exc)

        return "", "", ""

    def _setup_duckdb_pragmas(self, con, cfg: Dict[str, Any]) -> None:
        """Fallback: configure S3 via SET pragmas (single endpoint only)."""
        key, secret, token = self._resolve_s3_credentials(cfg)
        region = cfg.get("region_name") or cfg.get("region") or "us-east-1"
        endpoint = cfg.get("endpoint_url") or cfg.get("endpoint", "")

        def _esc(v):
            return v.replace("'", "''")

        con.execute(f"SET s3_region='{_esc(region)}';")
        if key:
            con.execute(f"SET s3_access_key_id='{_esc(key)}';")
        if secret:
            con.execute(f"SET s3_secret_access_key='{_esc(secret)}';")
        if token:
            con.execute(f"SET s3_session_token='{_esc(token)}';")
        if endpoint:
            ep_clean = endpoint.replace("https://", "").replace("http://", "").rstrip("/")
            con.execute(f"SET s3_endpoint='{_esc(ep_clean)}';")
            use_ssl = endpoint.startswith("https://")
            force_path = cfg.get("path_style", False)
            if not use_ssl:
                con.execute("SET s3_use_ssl=false;")
                con.execute("SET s3_url_style='path';")
            elif force_path:
                con.execute("SET s3_url_style='path';")

    def _configure_duckdb_performance(self, con) -> None:
        """Apply DuckDB performance tuning settings."""
        for stmt in (
            "SET http_keep_alive=true;",
            "SET http_retries=2;",
            "SET http_retry_wait_ms=1000;",
            "SET http_timeout=15000;",
            "SET enable_http_metadata_cache=true;",
            "SET enable_object_cache=true;",
        ):
            try:
                con.execute(stmt)
            except Exception:
                pass
        # Disable SSL verification (corporate proxies)
        for stmt in (
            "SET enable_server_cert_verification=false;",
            "SET enable_curl_server_cert_verification=false;",
        ):
            try:
                con.execute(stmt)
            except Exception:
                pass

    def _execute_sql_connector(
        self,
        sql: str,
        sql_conns: Dict[int, Dict[str, Any]],
        execution_id: str,
    ) -> pd.DataFrame:
        """Execute SQL via a SQL connector (Trino, Snowflake, etc.)."""
        from core.connectors import get_connector

        # Use the first SQL connection
        conn_id, conn = next(iter(sql_conns.items()))
        conn_type = conn.get("connection_type", "")
        conn_config = conn.get("config", {})

        connector = None
        try:
            connector = get_connector(conn_type, conn_config)
            result = connector.execute_query(sql)
            df = pd.DataFrame(result.get("rows", []))
            logger.info("[%s] SQL connector (%s) returned %d rows", execution_id, conn_type, len(df))
            return df
        finally:
            if connector:
                try:
                    connector.close()
                except Exception:
                    pass

    def _execute_hybrid(
        self,
        sql: str,
        s3_conns: Dict[int, Dict[str, Any]],
        sql_conns: Dict[int, Dict[str, Any]],
        source_tables: List[Dict[str, Any]],
        execution_id: str,
    ) -> pd.DataFrame:
        """Hybrid execution: try DuckDB first (can handle registered S3 tables + SQL).
        If DuckDB fails (e.g., external SQL tables), fall back to separate execution + merge."""
        # For hybrid, we attempt DuckDB with S3 secrets — DuckDB can natively
        # read S3 parquet. If the SQL-connector tables fail, we fall back.
        try:
            return self._execute_duckdb_s3(sql, s3_conns, execution_id)
        except Exception as exc:
            logger.info("[%s] DuckDB hybrid failed (%s), falling back to separate execution", execution_id, exc)
            # Fallback: execute S3 and SQL parts separately using cross_source_engine
            # For now, just try the SQL connector
            return self._execute_sql_connector(sql, sql_conns, execution_id)

    def _execute_duckdb_plain(
        self,
        sql: str,
        execution_id: str,
    ) -> pd.DataFrame:
        """Execute SQL in plain DuckDB (no S3, no connectors)."""
        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB not installed")

        con = duckdb.connect(database=":memory:")
        try:
            result = con.execute(sql)
            df = result.fetchdf()
            logger.info("[%s] Plain DuckDB: %d rows", execution_id, len(df))
            return df
        finally:
            try:
                con.close()
            except Exception:
                pass

    # ── Internal: SQL helpers ────────────────────────────────────────────────

    def _filter_to_sql(self, f: FilterSpec) -> str:
        """Convert a FilterSpec to a SQL WHERE clause fragment."""
        phys = self._quote_ident(f.physical_name)
        op = f.operator

        if op in ("is_null", "is_not_null"):
            return f"{phys} {_OP_MAP[op]}"

        if op == "in":
            if not isinstance(f.value, list):
                return ""
            vals = ", ".join(self._sql_literal(v) for v in f.value)
            return f"{phys} IN ({vals})"

        if op == "not_in":
            if not isinstance(f.value, list):
                return ""
            vals = ", ".join(self._sql_literal(v) for v in f.value)
            return f"{phys} NOT IN ({vals})"

        if op == "between":
            return f"{phys} BETWEEN {self._sql_literal(f.value)} AND {self._sql_literal(f.value2)}"

        template = _OP_MAP.get(op)
        if not template:
            logger.warning("Unknown filter operator: %s", op)
            return ""

        return f"{phys} {template.format(v=self._sql_literal(f.value))}"

    @staticmethod
    def _quote_ident(name: str) -> str:
        """Quote a SQL identifier (column or table name)."""
        if not name:
            return '""'
        # Don't double-quote if already quoted
        if name.startswith('"') and name.endswith('"'):
            return name
        return f'"{name.replace(chr(34), chr(34)+chr(34))}"'

    @staticmethod
    def _sql_literal(value: Any) -> str:
        """Convert a Python value to a SQL literal."""
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float)):
            return str(value)
        # String — escape single quotes
        return f"'{str(value).replace(chr(39), chr(39)+chr(39))}'"

    @staticmethod
    def _esc(v: str) -> str:
        """Escape single quotes for DuckDB SQL strings."""
        return v.replace("'", "''")
