# ============================================================
# app/core/iceberg.py — Apache Iceberg catalog + DuckDB bridge
# ============================================================
"""
Supports connecting to Iceberg tables via:

  ┌──────────────┬──────────────────────────────────────────────────────────┐
  │ Catalog Type │ Use Case                                                 │
  ├──────────────┼──────────────────────────────────────────────────────────┤
  │ rest         │ Polaris, Nessie REST, Tabular, Snowflake Open Catalog    │
  │ glue         │ AWS Glue Data Catalog                                    │
  │ hive         │ Hive Metastore (on-prem / EMR)                           │
  │ hadoop       │ Local filesystem or S3 warehouse (no external catalog)   │
  │ nessie       │ Project Nessie (multi-table transactions / branching)    │
  └──────────────┴──────────────────────────────────────────────────────────┘

How it works:
  1. PyIceberg loads the table metadata (schema, snapshots, manifest files)
  2. It hands DuckDB the Parquet data file paths from the current snapshot
  3. DuckDB executes the SQL directly on those Parquet files
     → full predicate pushdown + column pruning via DuckDB's engine

This means you get Iceberg's ACID metadata layer PLUS DuckDB's vectorised
query performance — no Spark required.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple

import structlog

from app.core.settings import settings

logger = structlog.get_logger()


# ── Catalog factory ──────────────────────────────────────────────────────────

def _build_catalog_properties() -> Dict[str, str]:
    """
    Assemble PyIceberg catalog properties from settings / env vars.
    Each catalog type needs different keys — we set only what's configured.
    """
    props: Dict[str, str] = {}
    ct = settings.iceberg_catalog_type.lower()

    if ct == "rest":
        if settings.iceberg_rest_uri:
            props["uri"] = settings.iceberg_rest_uri
        if settings.iceberg_rest_credential:
            props["credential"] = settings.iceberg_rest_credential
        if settings.iceberg_rest_token:
            props["token"] = settings.iceberg_rest_token
        if settings.iceberg_rest_warehouse:
            props["warehouse"] = settings.iceberg_rest_warehouse
        # S3 signing via SigV4 (needed for most REST catalogs on AWS)
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["s3.session-token"] = settings.aws_session_token
        if settings.s3_region:
            props["s3.region"] = settings.s3_region

    elif ct == "glue":
        if settings.aws_access_key_id:
            props["client.access-key-id"]     = settings.aws_access_key_id
            props["client.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.aws_session_token:
            props["client.session-token"] = settings.aws_session_token
        props["client.region"] = settings.iceberg_glue_region or settings.s3_region

    elif ct == "hive":
        if settings.iceberg_hive_uri:
            props["uri"] = settings.iceberg_hive_uri

    elif ct == "hadoop":
        if settings.iceberg_hadoop_warehouse:
            props["warehouse"] = settings.iceberg_hadoop_warehouse
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""
        if settings.s3_region:
            props["s3.region"] = settings.s3_region

    elif ct == "nessie":
        if settings.iceberg_nessie_uri:
            props["uri"] = settings.iceberg_nessie_uri
        props["ref"] = settings.iceberg_nessie_ref
        if settings.aws_access_key_id:
            props["s3.access-key-id"]     = settings.aws_access_key_id
            props["s3.secret-access-key"] = settings.aws_secret_access_key or ""

    # Extra arbitrary properties from env
    if settings.iceberg_extra_properties:
        for pair in settings.iceberg_extra_properties.split(","):
            if "=" in pair:
                k, v = pair.split("=", 1)
                props[k.strip()] = v.strip()

    return props


@lru_cache(maxsize=1)
def get_iceberg_catalog():
    """
    Returns a cached PyIceberg catalog instance.
    Called lazily — only when an Iceberg source is actually used.
    """
    try:
        from pyiceberg.catalog import load_catalog
    except ImportError:
        raise RuntimeError(
            "PyIceberg is not installed. Run: pip install pyiceberg[s3fs,glue,hive]"
        )

    props = _build_catalog_properties()
    catalog_type = settings.iceberg_catalog_type.lower()

    logger.info(
        "iceberg_catalog_loading",
        catalog_type=catalog_type,
        catalog_name=settings.iceberg_catalog_name,
    )

    catalog = load_catalog(
        settings.iceberg_catalog_name,
        **{"type": catalog_type, **props},
    )

    logger.info("iceberg_catalog_ready", catalog_type=catalog_type)
    return catalog


# ── Iceberg → DuckDB bridge ──────────────────────────────────────────────────

class IcebergTableResolver:
    """
    Resolves an Iceberg table reference into a list of current Parquet
    data file paths that DuckDB can read directly.

    This is the key integration point:
      Iceberg manages metadata → DuckDB reads the Parquet files
    """

    @staticmethod
    def get_data_files(
        namespace: str,
        table_name: str,
        snapshot_id: Optional[int] = None,
    ) -> Tuple[List[str], Dict[str, Any]]:
        """
        Returns (parquet_file_paths, table_schema_dict) for the given
        Iceberg table at the specified snapshot (latest if None).
        """
        catalog = get_iceberg_catalog()
        full_name = f"{namespace}.{table_name}"

        logger.debug("iceberg_table_loading", table=full_name)

        table = catalog.load_table(full_name)
        snap = (
            table.snapshot_by_id(snapshot_id)
            if snapshot_id
            else table.current_snapshot()
        )

        if snap is None:
            raise ValueError(f"Iceberg table '{full_name}' has no snapshots (empty table)")

        # Collect all data files from the manifest list
        data_files: List[str] = []
        for manifest in snap.manifests(table.io):
            for entry in manifest.fetch_manifest_entry(table.io, discard_deleted=True):
                data_files.append(entry.data_file.file_path)

        schema = {
            field.name: str(field.field_type)
            for field in table.schema().fields
        }

        logger.info(
            "iceberg_table_resolved",
            table=full_name,
            snapshot_id=snap.snapshot_id,
            data_files=len(data_files),
        )
        return data_files, schema

    @staticmethod
    def build_duckdb_sql(
        namespace: str,
        table_name: str,
        alias: str,
        snapshot_id: Optional[int] = None,
    ) -> str:
        """
        Produces a DuckDB sub-expression that reads the current Iceberg
        snapshot as a union of Parquet files.

        Example output:
          read_parquet(['s3://bucket/ns/tbl/data/0001.parquet',
                        's3://bucket/ns/tbl/data/0002.parquet'], union_by_name=true)
        """
        paths, _ = IcebergTableResolver.get_data_files(namespace, table_name, snapshot_id)

        if not paths:
            raise ValueError(f"Iceberg table '{namespace}.{table_name}' has no data files")

        paths_sql = ", ".join(f"'{p}'" for p in paths)
        return f"read_parquet([{paths_sql}], union_by_name=true)"


# ── Iceberg source spec helper ───────────────────────────────────────────────

def resolve_iceberg_source(source_cfg: Dict[str, Any]) -> str:
    """
    Called from config_loader when source type == 'iceberg'.
    Returns the DuckDB expression to use in the FROM clause.

    Config format in queries.yaml:
      sources:
        my_table:
          type: iceberg
          namespace: warehouse.finance        # dot-separated namespace
          table: trial_balance_transactions   # table name
          snapshot_id: 8736482736482736       # optional: pin to snapshot
    """
    namespace = source_cfg.get("namespace", "default")
    table     = source_cfg["table"]
    snap_id   = source_cfg.get("snapshot_id")

    return IcebergTableResolver.build_duckdb_sql(namespace, table, table, snap_id)


# ── Catalog management helpers ───────────────────────────────────────────────

def list_iceberg_namespaces() -> List[str]:
    catalog = get_iceberg_catalog()
    return [".".join(ns) for ns in catalog.list_namespaces()]


def list_iceberg_tables(namespace: str) -> List[str]:
    catalog = get_iceberg_catalog()
    ns_tuple = tuple(namespace.split("."))
    return [".".join(ident) for ident in catalog.list_tables(ns_tuple)]


def describe_iceberg_table(namespace: str, table_name: str) -> Dict[str, Any]:
    """Returns full table metadata for the explore endpoint."""
    catalog = get_iceberg_catalog()
    table = catalog.load_table(f"{namespace}.{table_name}")
    snap = table.current_snapshot()

    data_files, schema = IcebergTableResolver.get_data_files(namespace, table_name)

    return {
        "full_name":    f"{namespace}.{table_name}",
        "format":       "ICEBERG",
        "location":     table.location(),
        "schema":       schema,
        "partition_spec": str(table.spec()),
        "sort_order":   str(table.sort_order()),
        "snapshot": {
            "id":            snap.snapshot_id if snap else None,
            "timestamp_ms":  snap.timestamp_ms if snap else None,
            "operation":     snap.summary.operation if snap else None,
        } if snap else None,
        "properties":   dict(table.properties),
        "data_files":   len(data_files),
    }
