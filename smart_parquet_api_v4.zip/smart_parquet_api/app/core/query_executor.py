# ============================================================
# app/core/query_executor.py — Enterprise DuckDB query runner
# ============================================================
"""
Responsibilities
───────────────
• Execute arbitrary DuckDB SQL on Parquet (local + S3)
• Enforce query timeout
• Apply limit/offset pagination
• Result caching (in-memory LRU)
• Streaming large result sets via generator
• Metrics counters (Prometheus-ready)
"""
import asyncio
import functools
import hashlib
import json
import time
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from threading import Lock
from typing import Any, AsyncGenerator, Dict, Generator, List, Optional, Tuple

import duckdb
import structlog

from app.core.database import DuckDBPool
from app.core.settings import settings

logger = structlog.get_logger()


# ── Simple TTL cache ─────────────────────────────────────────────────────────

class TTLCache:
    """Thread-safe in-memory cache with per-entry TTL."""

    def __init__(self):
        self._store: Dict[str, Tuple[Any, float]] = {}
        self._lock = Lock()

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expires_at = entry
            if time.monotonic() > expires_at:
                del self._store[key]
                return None
            return value

    def set(self, key: str, value: Any, ttl: int) -> None:
        with self._lock:
            self._store[key] = (value, time.monotonic() + ttl)

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._store.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    @property
    def size(self) -> int:
        return len(self._store)


result_cache = TTLCache()
_executor = ThreadPoolExecutor(max_workers=settings.duckdb_threads)


# ── Query result model ───────────────────────────────────────────────────────

class QueryResult:
    __slots__ = ("columns", "rows", "total_rows", "page", "page_size",
                 "execution_ms", "cached", "query_id")

    def __init__(
        self,
        columns: List[str],
        rows: List[Dict],
        total_rows: int,
        page: int,
        page_size: int,
        execution_ms: float,
        cached: bool = False,
        query_id: str = "",
    ):
        self.columns = columns
        self.rows = rows
        self.total_rows = total_rows
        self.page = page
        self.page_size = page_size
        self.execution_ms = execution_ms
        self.cached = cached
        self.query_id = query_id

    def to_dict(self) -> Dict:
        return {
            "meta": {
                "query_id": self.query_id,
                "columns": self.columns,
                "total_rows": self.total_rows,
                "page": self.page,
                "page_size": self.page_size,
                "total_pages": max(1, (self.total_rows + self.page_size - 1) // self.page_size),
                "execution_ms": round(self.execution_ms, 2),
                "cached": self.cached,
            },
            "data": self.rows,
        }


# ── Core executor ────────────────────────────────────────────────────────────

class QueryExecutor:
    def __init__(self, pool: DuckDBPool):
        self._pool = pool

    # ── Public async interface ───────────────────────────────────────────────

    async def execute(
        self,
        sql: str,
        page: int = 1,
        page_size: int = settings.default_page_size,
        cache: bool = True,
        cache_ttl: int = settings.cache_ttl_seconds,
    ) -> QueryResult:
        """
        Execute SQL and return a paginated QueryResult.
        Runs the blocking DuckDB call in a thread-pool executor.
        """
        page_size = min(page_size, settings.max_page_size)
        cache_key = _make_cache_key(sql, page, page_size)

        if cache and settings.cache_enabled:
            cached = result_cache.get(cache_key)
            if cached is not None:
                logger.debug("cache_hit", key=cache_key[:16])
                cached.cached = True
                return cached

        loop = asyncio.get_event_loop()
        result = await asyncio.wait_for(
            loop.run_in_executor(
                _executor,
                functools.partial(self._run_sync, sql, page, page_size),
            ),
            timeout=settings.query_timeout_seconds,
        )

        if cache and settings.cache_enabled:
            result_cache.set(cache_key, result, cache_ttl)

        return result

    async def stream(
        self,
        sql: str,
        chunk_size: int = 5000,
    ) -> AsyncGenerator[List[Dict], None]:
        """
        Yield chunks of rows as an async generator — useful for
        huge result sets where we want to stream JSON line-by-line.
        """
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue(maxsize=4)

        def _producer():
            try:
                with self._pool.get_connection() as conn:
                    rel = conn.execute(sql)
                    cols = [d[0] for d in rel.description]
                    while True:
                        batch = rel.fetchmany(chunk_size)
                        if not batch:
                            break
                        rows = [dict(zip(cols, row)) for row in batch]
                        loop.call_soon_threadsafe(
                            lambda r=rows: asyncio.ensure_future(queue.put(r))
                        )
            except Exception as exc:
                loop.call_soon_threadsafe(
                    lambda e=exc: asyncio.ensure_future(queue.put(e))
                )
            finally:
                loop.call_soon_threadsafe(
                    lambda: asyncio.ensure_future(queue.put(None))
                )

        loop.run_in_executor(_executor, _producer)

        while True:
            item = await queue.get()
            if item is None:
                break
            if isinstance(item, Exception):
                raise item
            yield item

    async def explain(self, sql: str) -> str:
        """Return DuckDB EXPLAIN output for a query."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            _executor,
            functools.partial(self._explain_sync, sql),
        )

    # ── Sync internals (run inside thread pool) ──────────────────────────────

    def _run_sync(self, sql: str, page: int, page_size: int) -> QueryResult:
        t0 = time.perf_counter()
        offset = (page - 1) * page_size
        query_id = _make_cache_key(sql, 0, 0)[:12]

        # Count total rows (wrapped query)
        count_sql = f"SELECT COUNT(*) FROM ({sql}) __count__"
        paged_sql  = f"SELECT * FROM ({sql}) __paged__ LIMIT {page_size} OFFSET {offset}"

        with self._pool.get_connection() as conn:
            try:
                total_rows = conn.execute(count_sql).fetchone()[0]
                rel = conn.execute(paged_sql)
                cols = [d[0] for d in rel.description]
                rows = [dict(zip(cols, row)) for row in rel.fetchall()]
            except duckdb.Error as exc:
                logger.error("duckdb_error", query_id=query_id, error=str(exc))
                raise

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "query_executed",
            query_id=query_id,
            total_rows=total_rows,
            returned=len(rows),
            execution_ms=round(elapsed_ms, 2),
        )
        return QueryResult(
            columns=cols,
            rows=rows,
            total_rows=total_rows,
            page=page,
            page_size=page_size,
            execution_ms=elapsed_ms,
            query_id=query_id,
        )

    def _explain_sync(self, sql: str) -> str:
        with self._pool.get_connection() as conn:
            rows = conn.execute(f"EXPLAIN {sql}").fetchall()
            return "\n".join(r[1] for r in rows)


def _make_cache_key(sql: str, page: int, page_size: int) -> str:
    return hashlib.sha256(f"{sql}:{page}:{page_size}".encode()).hexdigest()
