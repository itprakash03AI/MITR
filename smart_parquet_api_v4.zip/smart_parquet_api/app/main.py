# ============================================================
# app/main.py — Application factory
# ============================================================
from contextlib import asynccontextmanager
from typing import AsyncIterator

import structlog
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.core.config_loader import registry
from app.core.database import db_pool
from app.core.logging import setup_logging
from app.core.settings import settings
from app.api.router import admin_router, query_router, generic_router, iceberg_router, register_all_endpoints

# GraphQL is optional — app starts fine without strawberry-graphql installed
try:
    from app.api.graphql_schema import graphql_router
    _graphql_available = True
except ImportError:
    graphql_router = None
    _graphql_available = False

logger = structlog.get_logger()


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    # ── Startup ──────────────────────────────────────────────
    setup_logging()
    logger.info("app_starting", name=settings.app_name, version=settings.app_version)

    # Load query config → populate registry
    registry.load()

    # Initialise DuckDB connection pool
    db_pool.initialize()

    # Mount dynamic endpoints (must happen before first request)
    register_all_endpoints(query_router)

    logger.info("app_ready", endpoints=len(registry.all()))
    yield

    # ── Shutdown ─────────────────────────────────────────────
    db_pool.shutdown()
    logger.info("app_shutdown")


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="""
## Smart Parquet Query API

Enterprise-grade, config-driven API for querying Parquet files on **local disk**
or **Amazon S3** using **DuckDB** as the embedded analytical engine.

### Features
- 🗂  **Config-driven endpoints** — all queries live in `config/queries.yaml`
- ⚡  **DuckDB** — vectorised query engine; sub-second on large Parquet files
- ☁️  **S3 + local** — transparent source routing per endpoint
- 📄  **Pagination** — `page` + `pageSize` on every endpoint
- 🗃  **Result cache** — TTL-based in-memory cache
- 🌊  **Streaming** — NDJSON streaming for huge result sets
- 🔍  **EXPLAIN** — query plan endpoint for debugging
        """,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # ── Middleware ────────────────────────────────────────────
    app.add_middleware(GZipMiddleware, minimum_size=1024)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request-ID middleware ─────────────────────────────────
    @app.middleware("http")
    async def add_request_id(request: Request, call_next):
        import uuid
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])
        structlog.contextvars.bind_contextvars(request_id=request_id)
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    # ── API Key middleware (optional) ─────────────────────────
    if settings.api_key_enabled and settings.api_key:
        @app.middleware("http")
        async def api_key_check(request: Request, call_next):
            # Skip docs and health
            if request.url.path in ("/docs", "/redoc", "/openapi.json", "/api/admin/health"):
                return await call_next(request)
            key = request.headers.get("X-API-Key") or request.query_params.get("api_key")
            if key != settings.api_key:
                return JSONResponse(status_code=401, content={"error": "Invalid or missing API key"})
            return await call_next(request)

    # ── Error handlers ────────────────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error("unhandled_exception", error=str(exc), path=request.url.path)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "detail": str(exc)},
        )

    # ── Routers ───────────────────────────────────────────────
    app.include_router(admin_router)
    app.include_router(generic_router)
    app.include_router(iceberg_router)
    app.include_router(query_router)
    if _graphql_available and graphql_router is not None:
        app.include_router(graphql_router, prefix="/graphql")
        logger.info("graphql_enabled", path="/graphql")

    # Root redirect to docs
    @app.get("/", include_in_schema=False)
    async def root():
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/docs")

    return app


# ── Entry point ───────────────────────────────────────────────────────────────
app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        workers=1,          # use 1 for dev; set workers in gunicorn for prod
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )
