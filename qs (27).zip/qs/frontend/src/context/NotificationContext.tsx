import React, { createContext, useContext, useState, useCallback, useEffect, useRef, ReactNode } from 'react';
import { useWebSocket } from './WebSocketContext';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  action?: { label: string; href: string };
  data?: unknown;
  timestamp?: string;
}

export interface ExecLogEntry {
  ts: string;        // ISO timestamp
  execId: string;    // execution ID
  message: string;
}

export type AddNotificationInput = Omit<Notification, 'id' | 'timestamp'> & { timestamp?: string };

interface NotificationContextValue {
  notifications: Notification[];
  runningCount: number;
  execLogs: ExecLogEntry[];
  unreadLogCount: number;
  markLogsRead: () => void;
  clearLogs: () => void;
  addNotification: (notification: AddNotificationInput) => void;
  removeNotification: (id: number) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextValue | null>(null);

export const useNotifications = (): NotificationContextValue => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [execLogs, setExecLogs] = useState<ExecLogEntry[]>([]);
  const [unreadLogCount, setUnreadLogCount] = useState(0);
  // Track active execution IDs so we can decrement correctly
  const runningRef = useRef<Set<string>>(new Set());
  const [runningCount, setRunningCount] = useState(0);
  // Dedup guard — prevent double-notification if multiple listeners fire for the same execution
  const notifiedRef = useRef<Set<string>>(new Set());
  const { addListener } = useWebSocket();

  const markLogsRead = useCallback(() => setUnreadLogCount(0), []);
  const clearLogs = useCallback(() => { setExecLogs([]); setUnreadLogCount(0); }, []);

  const addNotification = useCallback((notification: AddNotificationInput) => {
    const id = Date.now() + Math.random();
    const newNotification: Notification = {
      id,
      ...notification,
      timestamp: notification.timestamp || new Date().toISOString(),
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 50));

    // Errors and notifications with actions persist until manually dismissed
    if (notification.type !== 'error' && !notification.action) {
      setTimeout(() => removeNotification(id), 5000);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const removeNotification = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // ── Global execution tracker ────────────────────────────────────────────────
  // Tracks ALL executions across every page so users see results after navigation.
  useEffect(() => {
    const removeListener = addListener((message) => {
      const execId = message.execution_id as string | undefined;

      if (message.type === 'execution_started' && execId) {
        runningRef.current.add(execId);
        setRunningCount(runningRef.current.size);
        return;
      }

      if (message.type === 'execution_progress') {
        // Capture step logs from backend
        const logMsg = (message.data as any)?.log;
        if (logMsg && execId) {
          const entry: ExecLogEntry = {
            ts: new Date().toISOString(),
            execId,
            message: logMsg,
          };
          setExecLogs(prev => [...prev.slice(-99), entry]);
          setUnreadLogCount(prev => prev + 1);
        }
        return;
      }

      if (message.type === 'execution_completed' && execId) {
        const wasTracked = runningRef.current.delete(execId);
        if (wasTracked) setRunningCount(runningRef.current.size);
        // Dedup: only notify once per execution_id
        if (notifiedRef.current.has(execId)) return;
        notifiedRef.current.add(execId);
        if (notifiedRef.current.size > 200) notifiedRef.current.clear(); // prevent memory leak
        const rows = (message.stats as any)?.total_rows;
        addNotification({
          type: 'success',
          title: 'Query Completed',
          message: rows != null ? `${Number(rows).toLocaleString()} rows ready` : 'Results available',
          action: { label: 'View Results', href: '/downloads' },
          timestamp: message.timestamp as string,
        });
        return;
      }

      if (message.type === 'execution_failed' && execId) {
        const wasTracked = runningRef.current.delete(execId);
        if (wasTracked) setRunningCount(runningRef.current.size);
        const isTokenExpired = (message as any).error_code === 'TOKEN_EXPIRED';
        addNotification({
          type: 'error',
          title: isTokenExpired ? 'Session Token Expired' : 'Query Failed',
          message: (message.error as string) || 'An error occurred',
          ...(isTokenExpired ? { action: { label: 'Update Connection', href: '/connections' } } : {}),
          timestamp: message.timestamp as string,
        });
        return;
      }

      if (message.type === 'execution_cancelled' && execId) {
        runningRef.current.delete(execId);
        setRunningCount(runningRef.current.size);
        return;
      }

      // ── All other events → show as notification ────────────────────────────
      const SILENT = new Set(['pong', 'connection_established']);
      if (message.type && !SILENT.has(message.type)) {
        const getType = (t: string): Notification['type'] => {
          if (t.includes('completed')) return 'success';
          if (t.includes('failed') || t.includes('error')) return 'error';
          return 'info';
        };
        const titles: Record<string, string> = {
          download_ready: 'Download Ready',
          export_completed: 'Export Complete',
          schedule_completed: 'Schedule Completed',
          schedule_failed: 'Schedule Failed',
        };
        if (titles[message.type]) {
          addNotification({
            type: getType(message.type),
            title: titles[message.type],
            message: (message.message as string) || message.type,
            data: message,
            timestamp: (message.timestamp as string) || new Date().toISOString(),
          });
        }
      }
    });

    return () => removeListener();
  }, [addListener, addNotification]);

  return (
    <NotificationContext.Provider value={{ notifications, runningCount, execLogs, unreadLogCount, markLogsRead, clearLogs, addNotification, removeNotification, clearAll }}>
      {children}
    </NotificationContext.Provider>
  );
};
