"""
Oracle Database connector.
Uses python-oracledb (thin mode — no Oracle Client installation required).

Required config keys:
  host        – Oracle DB host
  port        – int, default 1521
  service_name – Oracle service name (preferred) OR
  sid         – Oracle SID (legacy)
  user        – DB username
  password    – DB password
  dsn         – full DSN string (overrides host/port/service_name if set)

Optional:
  wallet_location – path to Oracle wallet (for mTLS / Autonomous DB)
  wallet_password – wallet password
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector

logger = logging.getLogger(__name__)


class OracleConnector(SqlConnector):
    """Connector for Oracle Database (via python-oracledb thin mode)."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            return self._conn
        try:
            import oracledb
        except ImportError:
            raise RuntimeError(
                "python-oracledb is not installed. "
                "Run: pip install oracledb  then restart the backend."
            )

        oracledb.defaults.fetch_lobs = False  # return LOBs as strings/bytes directly

        user     = self.config["user"]
        password = self.config["password"]
        dsn      = self.config.get("dsn")

        if not dsn:
            host         = self.config["host"]
            port         = int(self.config.get("port", 1521))
            service_name = self.config.get("service_name")
            sid          = self.config.get("sid")
            if service_name:
                dsn = oracledb.makedsn(host, port, service_name=service_name)
            elif sid:
                dsn = oracledb.makedsn(host, port, sid=sid)
            else:
                raise ValueError("Oracle config must include 'service_name', 'sid', or 'dsn'.")

        connect_kwargs: Dict[str, Any] = dict(user=user, password=password, dsn=dsn)

        wallet_loc = self.config.get("wallet_location")
        if wallet_loc:
            connect_kwargs["wallet_location"] = wallet_loc
            wallet_pw = self.config.get("wallet_password")
            if wallet_pw:
                connect_kwargs["wallet_password"] = wallet_pw

        self._conn = oracledb.connect(**connect_kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    def _fetchall_as_dicts(self, cursor) -> List[Dict]:
        cols = [d[0].lower() for d in cursor.description]
        return [dict(zip(cols, row)) for row in cursor.fetchall()]

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        try:
            cur = self._cursor()
            cur.execute("SELECT 1 FROM DUAL")
            cur.fetchone()
            cur.execute("SELECT * FROM v$version WHERE ROWNUM = 1")
            row = cur.fetchone()
            version = row[0] if row else "unknown"
            return {
                "success": True,
                "message": f"Connected to Oracle: {version}",
                "details": {"version": version, "host": self.config.get("host")},
            }
        except Exception as e:
            logger.exception("Oracle test_connection failed")
            return {"success": False, "message": str(e), "details": {}}

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", ".\core\connectors\oracle_connector", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        """Oracle has no catalog concept — return the current schema owner."""
        cur = self._cursor()
        cur.execute("SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') FROM DUAL")
        row = cur.fetchone()
        return [row[0]] if row else []

    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._cursor()
        cur.execute(
            "SELECT DISTINCT OWNER FROM ALL_TABLES ORDER BY OWNER"
        )
        return [r[0] for r in cur.fetchall()]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(
            "SELECT TABLE_NAME, 'TABLE' AS TABLE_TYPE FROM ALL_TABLES WHERE OWNER = :owner "
            "UNION ALL "
            "SELECT VIEW_NAME, 'VIEW' FROM ALL_VIEWS WHERE OWNER = :owner "
            "ORDER BY 1",
            owner=schema.upper(),
        )
        return [
            {"name": r[0], "type": r[1], "catalog": catalog, "schema": schema}
            for r in cur.fetchall()
        ]

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        cur.execute(
            "SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, COLUMN_ID "
            "FROM ALL_TAB_COLUMNS "
            "WHERE OWNER = :owner AND TABLE_NAME = :tname "
            "ORDER BY COLUMN_ID",
            owner=schema.upper(), tname=table.upper(),
        )
        return [
            {
                "name": r[0],
                "type": r[1],
                "nullable": r[2] == "Y",
                "ordinal": r[3],
            }
            for r in cur.fetchall()
        ]

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        # Oracle uses FETCH FIRST n ROWS ONLY (12c+) or ROWNUM for older versions
        if limit is not None:
            stripped = sql.strip().rstrip(";")
            upper = stripped.upper()
            if "FETCH FIRST" not in upper and "ROWNUM" not in upper:
                stripped = (
                    f"SELECT * FROM ({stripped}) WHERE ROWNUM <= {limit}"
                )
            sql = stripped

        cur = self._cursor()
        cur.execute(sql)
        rows = self._fetchall_as_dicts(cur)
        cols = [{"name": d[0].lower(), "type": str(d[1])} for d in cur.description] if cur.description else []
        return {"columns": cols, "rows": rows, "total_rows": len(rows)}
