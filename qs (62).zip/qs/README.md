# QueryStudio — Enterprise Data Platform

A production-ready, enterprise-grade data query and reporting platform built on **FastAPI + DuckDB + React**. Query Parquet files, S3/Iceberg tables, and SQL warehouses (Trino, Snowflake, Databricks) with a Superset-level UI — no extra infrastructure required.

---

## Features

### Query & Analysis
| Feature | Detail |
|---|---|
| **Visual Query Builder** | No-code joins, filters, aggregations, sorting across Parquet/S3/Iceberg files |
| **SQL Editor** | Full SQL against any connected source with autocomplete |
| **Multi-File Joins** | INNER / LEFT / RIGHT / FULL OUTER across files and connectors |
| **Result Grid** | Sortable, searchable, freezable columns; inline chart toggle |
| **Charts** | Bar, Line, Area, Scatter, Pie with axis config; PNG export |
| **Export Formats** | CSV, Excel (.xlsx), JSON, Parquet |

### Enterprise Features
| Feature | Detail |
|---|---|
| **Dashboards** | Drag-and-resize widget grid (react-grid-layout); bar/line/area/pie/KPI charts per widget |
| **Query Cache** | Disk-backed Parquet cache (SHA-256 key, configurable TTL); instant re-run of identical queries |
| **Version History** | Auto-snapshot on every query edit; restore any prior version |
| **Query Sharing** | UUID share links → public `/shared/:token` page (no login required for recipient) |
| **Parametric Reports** | Template-driven reports with typed parameters; run on demand or schedule |
| **Scheduled Downloads** | APScheduler cron/interval jobs; email + Slack/Teams webhook notifications |
| **AD Authentication** | Active Directory login (username/password → LDAP); admin / user roles; row-level security |
| **Row-Level Security** | Non-admin users see only their own queries, executions, and dashboards |
| **Execution History** | Full audit trail with status, row counts, duration, error messages |
| **WebSocket Live Updates** | Real-time notifications for execution and schedule events |

### Connectors
S3 / Local · Trino / Starburst · Snowflake · Databricks / Delta · Apache Hive · Oracle

---

## System Requirements

- Python 3.9+
- Node.js 18+
- 4 GB+ RAM (8 GB recommended for large files)
- No Redis, Kafka, or other external services required

---

## Quick Start

### 1 — Backend

```bash
cd backend
python -m venv venv
source venv/Scripts/activate   # Windows: venv\Scripts\activate

pip install -r requirements.txt

# Edit config.json for your environment (paths, auth, email, etc.)
python main.py
```

API available at `http://localhost:8000` · Swagger at `http://localhost:8000/docs`

### 2 — Frontend

```bash
cd frontend
npm install
npm run dev        # development — http://localhost:5173
npm run build      # production build → build/
```

---

## Configuration

All configuration is driven by **`backend/config.json`** (no hard-coded values). Environment variables override config.json values.

```json
{
  "server":   { "host": "0.0.0.0", "port": 8000 },
  "paths":    { "data_dir": "./data", "parquet_dir": "./data/parquet", "downloads_dir": "./data/downloads" },
  "database": { "url": "sqlite:///./data/querystudio.db" },
  "auth": {
    "type": "none",
    "ad": { "server": "", "domain": "", "base_dn": "", "require_group": "" }
  },
  "cache":  { "enabled": true, "ttl_seconds": 3600, "max_size_mb": 2048 },
  "email":  { "host": "", "port": 587, "user": "", "password": "", "from_address": "", "use_tls": true },
  "output_storage": { "type": "local", "s3_bucket": "", "s3_prefix": "exports/" }
}
```

| Setting | Values | Notes |
|---|---|---|
| `auth.type` | `none` \| `ad` | `none` skips login entirely |
| `cache.ttl_seconds` | integer | Seconds until a cached result expires |
| `cache.enabled` | bool | Set `false` to disable caching globally |
| `email.host` | SMTP hostname | Leave blank to disable email notifications |

---

## Project Structure

```
outputs/
├── backend/
│   ├── main.py                    # FastAPI app — all endpoints
│   ├── config.json                # Primary configuration file
│   ├── core/
│   │   ├── database.py            # SQLAlchemy models + DatabaseManager
│   │   ├── query_cache.py         # Disk-backed Parquet result cache
│   │   ├── webhook_service.py     # Slack / Teams / generic HTTP webhooks
│   │   ├── email_service.py       # SMTP email notifications
│   │   ├── scheduler.py           # APScheduler integration
│   │   ├── websocket_manager.py   # WebSocket broadcast
│   │   ├── ad_auth.py             # Active Directory authentication
│   │   ├── config.py              # Typed config accessors
│   │   └── connectors/            # S3, Trino, Snowflake, Databricks, Oracle
│   └── api/
│       ├── data_grid_api.py       # DuckDB query execution
│       ├── dashboards_api.py      # Dashboard + widget CRUD
│       └── schedules_api.py       # Schedule management
│
└── frontend/
    ├── vite.config.ts
    └── src/
        ├── App.tsx
        ├── components/
        │   ├── QueryBuilder.tsx
        │   ├── SqlQueryPage.tsx
        │   ├── SavedQueries.tsx       # + version history + share
        │   ├── DashboardPage.tsx      # Drag-resize dashboard builder
        │   ├── QueryVersionHistory.tsx
        │   ├── SharedQueryPage.tsx    # Public share-link page
        │   ├── ReportManager.tsx
        │   ├── SchedulesPage.tsx      # + email + webhook fields
        │   ├── ExecutionHistory.tsx
        │   ├── Downloads.tsx
        │   ├── Connections.tsx
        │   ├── LoginPage.tsx
        │   └── Layout.tsx
        ├── context/
        │   ├── AuthContext.tsx
        │   ├── WebSocketContext.tsx
        │   └── NotificationContext.tsx
        └── services/
            └── api.ts                 # Typed API client
```

---

## API Reference (key endpoints)

### Files & Schema
```
GET    /api/files                        List available Parquet files
GET    /api/files/{path}/schema          Column schema for a file
POST   /api/files/upload                 Upload a Parquet file
```

### Queries
```
GET    /api/queries                      List saved queries
POST   /api/queries                      Save a new query
PUT    /api/queries/{id}                 Update query (auto-creates version snapshot)
DELETE /api/queries/{id}                 Soft-delete
GET    /api/queries/{id}/versions        List all versions
POST   /api/queries/{id}/versions/{vid}/restore  Restore a version
POST   /api/queries/{id}/share           Create a share token
GET    /api/shared/{token}              Public — fetch shared query (no auth)
```

### Execution & Cache
```
POST   /api/execute                      Execute query (checks cache first)
GET    /api/executions                   Execution history
GET    /api/executions/{id}              Execution detail + status
GET    /api/executions/{id}/results      Paginated result rows
GET    /api/cache/stats                  Cache hit/miss stats
DELETE /api/cache                        Purge all cached results
```

### Dashboards
```
GET    /api/dashboards                   List dashboards
POST   /api/dashboards                   Create dashboard
PUT    /api/dashboards/{id}              Update name/description
DELETE /api/dashboards/{id}              Delete dashboard
GET    /api/dashboards/{id}/widgets      List widgets
POST   /api/dashboards/{id}/widgets      Add widget
PUT    /api/dashboards/{id}/widgets/{wid} Update widget
DELETE /api/dashboards/{id}/widgets/{wid} Delete widget
PUT    /api/dashboards/{id}/layout       Save grid layout
```

### Schedules
```
GET    /api/schedules                    List schedules
POST   /api/schedules                    Create schedule
PUT    /api/schedules/{id}              Update schedule
DELETE /api/schedules/{id}              Delete schedule
POST   /api/schedules/{id}/pause        Pause schedule
POST   /api/schedules/{id}/resume       Resume schedule
POST   /api/schedules/{id}/run-now      Trigger immediately
```

### Auth
```
POST   /auth/login                       AD login → session token
GET    /auth/me                          Current user info
GET    /auth/config                      Auth mode (none / ad)
```

### WebSocket
```
ws://host/ws    Real-time events: execution_*, scheduled_job_*, connection_established
```

---

## Database Schema (SQLite)

| Table | Purpose |
|---|---|
| `saved_queries` | Query definitions |
| `query_executions` | Execution audit trail |
| `download_files` | Generated export files |
| `query_result_cache` | Cache metadata (path, TTL, size) |
| `query_versions` | Version history snapshots |
| `query_shares` | Share tokens |
| `dashboards` | Dashboard definitions |
| `dashboard_widgets` | Widget config + layout |
| `schedules` | Scheduled job definitions |
| `parametric_reports` | Report templates |

---

## Production Deployment (OpenShift / Kubernetes)

```bash
# Backend container
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000

# Frontend — serve build/ as static files behind the same origin
# Vite proxy in dev; nginx / OpenShift route in production
```

Mount persistent volumes for:
- `data/parquet/` — source Parquet files
- `data/downloads/` — generated exports
- `data/cache/` — query result cache
- `data/querystudio.db` — SQLite database

---

## Version History

### v2.0.0 (March 2026)
- Dashboard builder (drag/resize, 6 chart types, KPI widgets)
- Query result cache (disk-backed Parquet, configurable TTL, APScheduler cleanup)
- Query version history + restore
- Query share links (public, no-auth recipient page)
- AD authentication + row-level security
- Slack / Teams webhook notifications for schedules
- Email notifications for schedule completion / failure
- Parametric report manager
- SQL editor page
- Vite + TypeScript migration (from CRA)
- MUI v7 upgrade

### v1.0.0
- Core Parquet query engine (DuckDB)
- Visual query builder
- Multi-file joins
- CSV export
- Execution history
- WebSocket real-time notifications
