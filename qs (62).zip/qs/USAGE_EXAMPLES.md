# Usage Examples

Complete examples for using the Parquet Query Engine with S3 support.

## Example 1: Configure S3 and Query Files

### Step 1: Configure S3 via Environment

```bash
# Edit backend/.env
cat >> backend/.env << 'ENVEOF'
S3_BUCKET_NAME=my-data-bucket
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=YOUR_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_SECRET_ACCESS_KEY
ENVEOF

# Restart backend
cd backend
python main_with_s3.py
```

### Step 2: Browse S3 Folders via API

```bash
# List root folders
curl http://localhost:8000/api/s3/folders

# List files in a folder
curl "http://localhost:8000/api/s3/files?folder=sales-data/2024/"
```

### Step 3: Execute Query on S3 Files

```bash
curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type: application/json" \
  -d '{
    "query_config": {
      "files": ["s3://my-data-bucket/sales-data/2024/january.parquet"],
      "filters": [
        {"column": "amount", "operator": "gt", "value": 1000}
      ],
      "columns": ["transaction_id", "customer_id", "amount", "date"],
      "order_by": [
        {"column": "amount", "direction": "desc"}
      ],
      "limit": 100
    }
  }'
```

## Example 2: Join Local and S3 Files

```python
# Python example using requests
import requests

query_config = {
    "files": ["local_customers.parquet"],
    "joins": [{
        "left_file": "local_customers.parquet",
        "right_file": "s3://my-bucket/transactions/2024_q1.parquet",
        "left_on": ["customer_id"],
        "right_on": ["cust_id"],
        "how": "inner"
    }],
    "columns": ["name", "email", "transaction_id", "amount"],
    "filters": [
        {"column": "amount", "operator": "gt", "value": 500}
    ]
}

response = requests.post(
    'http://localhost:8000/api/execute',
    json={'query_config': query_config}
)

execution = response.json()
print(f"Execution ID: {execution['execution_id']}")
```

## Example 3: Complex Multi-File Query

```javascript
// JavaScript example
const query = {
  files: ["s3://analytics-bucket/events/2024/january.parquet"],
  joins: [
    {
      left_file: "s3://analytics-bucket/events/2024/january.parquet",
      right_file: "s3://analytics-bucket/users/active_users.parquet",
      left_on: ["user_id"],
      right_on: ["id"],
      how: "left"
    },
    {
      left_file: "s3://analytics-bucket/users/active_users.parquet",
      right_file: "local_file.parquet",
      left_on: ["segment_id"],
      right_on: ["id"],
      how: "inner"
    }
  ],
  filters: [
    {"column": "event_type", "operator": "in", "value": ["click", "purchase"]},
    {"column": "timestamp", "operator": "gte", "value": "2024-01-01"},
    {"column": "revenue", "operator": "gt", "value": 0}
  ],
  columns: [
    "event_id", "user_id", "event_type", "timestamp",
    "user_name", "user_email", "segment_name", "revenue"
  ],
  order_by: [
    {"column": "timestamp", "direction": "desc"}
  ],
  limit: 10000
};

fetch('http://localhost:8000/api/execute', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({query_config: query})
})
.then(res => res.json())
.then(data => console.log('Execution started:', data.execution_id));
```

## Example 4: Save and Reuse Query

```bash
# Save query
curl -X POST http://localhost:8000/api/queries \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Monthly Sales Report",
    "description": "Aggregated sales data from S3",
    "query_config": {
      "files": ["s3://sales-bucket/monthly/current_month.parquet"],
      "filters": [
        {"column": "status", "operator": "eq", "value": "completed"}
      ],
      "columns": ["region", "product", "revenue", "quantity"]
    },
    "created_by": "analyst@company.com"
  }'

# Execute saved query (returns query_id)
# Use query_id to execute
curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type": application/json" \
  -d '{
    "query_id": 1,
    "executed_by": "analyst@company.com"
  }'
```

## Example 5: Monitor Execution via WebSocket

```javascript
// WebSocket example
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  switch(message.type) {
    case 'execution_started':
      console.log(`Query ${message.execution_id} started`);
      break;
      
    case 'execution_progress':
      console.log(`Processed ${message.data.total_rows} rows`);
      break;
      
    case 'execution_completed':
      console.log(`Query completed! File: ${message.file_id}`);
      console.log(`Total rows: ${message.stats.total_rows}`);
      break;
      
    case 'execution_failed':
      console.error(`Query failed: ${message.error}`);
      break;
  }
};

ws.onopen = () => {
  console.log('Connected to WebSocket');
};
```

## Example 6: Download Results

```bash
# List available downloads
curl http://localhost:8000/api/downloads?status=available

# Download file
curl -o results.csv \
  http://localhost:8000/api/downloads/FILE_ID_HERE
```

## Example 7: React Component Usage

```jsx
import React, { useState } from 'react';
import S3FolderBrowser from './components/S3FolderBrowser';
import api from './services/api';

function MyComponent() {
  const [selectedFiles, setSelectedFiles] = useState([]);

  const handleFileSelect = async (files) => {
    setSelectedFiles(files);
    
    // Execute query on selected files
    const query = {
      files: files.map(f => `s3://my-bucket/${f.key}`),
      columns: ["id", "name", "value"],
      limit: 1000
    };
    
    try {
      const response = await api.executeQuery({ query_config: query });
      console.log('Execution started:', response.execution_id);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <h2>Select S3 Files</h2>
      <S3FolderBrowser 
        onFileSelect={handleFileSelect}
        multiSelect={true}
      />
      
      {selectedFiles.length > 0 && (
        <div>
          <h3>Selected Files:</h3>
          <ul>
            {selectedFiles.map(f => (
              <li key={f.key}>{f.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
```

## Example 8: Automated Daily Report

```python
#!/usr/bin/env python3
"""
Automated daily sales report from S3
Runs via cron job
"""

import requests
from datetime import datetime, timedelta

# Configuration
API_URL = "http://localhost:8000"
BUCKET = "sales-data-bucket"

# Get yesterday's date
yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
file_path = f"s3://{BUCKET}/daily-sales/{yesterday}.parquet"

# Build query
query = {
    "files": [file_path],
    "filters": [
        {"column": "status", "operator": "eq", "value": "completed"}
    ],
    "columns": ["region", "product", "revenue", "quantity"],
    "order_by": [
        {"column": "revenue", "direction": "desc"}
    ]
}

# Execute query
response = requests.post(
    f"{API_URL}/api/execute",
    json={"query_config": query, "executed_by": "automated_report"}
)

if response.ok:
    execution_id = response.json()['execution_id']
    print(f"Daily report started: {execution_id}")
    
    # Poll for completion (or use WebSocket)
    import time
    while True:
        status = requests.get(f"{API_URL}/api/executions/{execution_id}")
        exec_data = status.json()
        
        if exec_data['status'] == 'completed':
            print(f"Report ready! Rows: {exec_data['total_rows']}")
            # Send email notification here
            break
        elif exec_data['status'] == 'failed':
            print(f"Report failed: {exec_data['error_message']}")
            break
            
        time.sleep(5)
else:
    print(f"Failed to start report: {response.text}")
```

## Example 9: Partitioned Data Query

```bash
# Query specific partition in S3
# Folder structure: s3://bucket/sales/year=2024/month=01/day=15/

curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type: application/json" \
  -d '{
    "query_config": {
      "files": [
        "s3://bucket/sales/year=2024/month=01/day=15/part-00000.parquet",
        "s3://bucket/sales/year=2024/month=01/day=15/part-00001.parquet"
      ],
      "columns": ["transaction_id", "amount", "timestamp"]
    }
  }'
```

## Example 10: Large File Optimization

```python
# For very large S3 files, optimize with:

query = {
    "files": ["s3://big-data/huge_file.parquet"],
    
    # 1. Select only needed columns
    "columns": ["id", "value", "date"],
    
    # 2. Apply filters to reduce data
    "filters": [
        {"column": "date", "operator": "gte", "value": "2024-01-01"},
        {"column": "value", "operator": "gt", "value": 100}
    ],
    
    # 3. Limit results
    "limit": 100000
}

# Server-side optimization:
# - Increase PARQUET_CHUNK_SIZE for larger chunks
# - Deploy in same AWS region as S3 bucket
# - Use column statistics for filter push-down
```

## Tips and Best Practices

### 1. File Organization
- Use consistent folder structure in S3
- Partition by date/region for easy filtering
- Keep related files together

### 2. Query Optimization
- Always select specific columns
- Apply filters early in the query
- Use appropriate chunk sizes
- Test queries on small data first

### 3. Error Handling
- Monitor WebSocket for real-time errors
- Check execution history for failures
- Implement retry logic for network issues

### 4. Security
- Use IAM roles instead of credentials
- Rotate access keys regularly
- Enable S3 bucket encryption
- Use VPC endpoints for private access

### 5. Cost Management
- Query in same region as S3
- Use lifecycle policies for old data
- Monitor data transfer costs
- Cache frequently accessed files locally

## Common Patterns

### Pattern 1: ETL Pipeline
1. Upload data to S3
2. Query and transform with filters/joins
3. Export results to CSV
4. Load into data warehouse

### Pattern 2: Ad-hoc Analysis
1. Browse S3 folders in UI
2. Build query interactively
3. Execute and download results
4. Save successful queries for reuse

### Pattern 3: Scheduled Reports
1. Save query template
2. Schedule execution via cron
3. Monitor via WebSocket
4. Email results to stakeholders

### Pattern 4: Data Exploration
1. List S3 folders
2. Check file schemas
3. Sample data with filters + limit
4. Build full query incrementally
