/**
 * API Service - TypeScript version
 * Every method maps to an actual backend route.
 */

import { getAuthHeader } from '../context/AuthContext';

const API_BASE_URL = import.meta.env.VITE_API_URL || '';

export class ApiError extends Error {
  errorCode?: string;
  connectionId?: number;
  constructor(message: string, errorCode?: string, connectionId?: number) {
    super(message);
    this.name = 'ApiError';
    this.errorCode = errorCode;
    this.connectionId = connectionId;
  }
}

const RETRY_STATUSES = new Set([502, 503, 504]);
const MAX_RETRIES = 2;
const RETRY_DELAYS = [1000, 3000]; // ms backoff

const _parseError = async (response: Response): Promise<{ detail: string; errorCode?: string; connectionId?: number }> => {
  let detail = `HTTP ${response.status}`;
  let errorCode: string | undefined;
  let connectionId: number | undefined;
  try {
    const e = await response.json() as { detail?: any; message?: string };
    if (typeof e.detail === 'string') {
      detail = e.detail;
    } else if (Array.isArray(e.detail)) {
      detail = (e.detail as { msg?: string; loc?: any[]; input?: any }[]).map(d => {
        let s = d.msg || JSON.stringify(d);
        if (d.loc) s += ` [field: ${d.loc.join('.')}]`;
        if (d.input !== undefined) s += ` [got: ${JSON.stringify(d.input)}]`;
        return s;
      }).join('; ');
    } else if (e.detail && typeof e.detail === 'object') {
      detail = e.detail.message || JSON.stringify(e.detail);
      errorCode = e.detail.error_code;
      connectionId = e.detail.connection_id;
    } else if (e.message) {
      detail = e.message;
    }
  } catch {}
  return { detail, errorCode, connectionId };
};

const safeFetch = async (url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string>),
  };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const method = (options.method || 'GET').toUpperCase();
  const canRetry = method === 'GET';

  let lastError: Error | null = null;
  const attempts = canRetry ? MAX_RETRIES + 1 : 1;

  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await fetch(fullUrl, { ...options, headers });
      if (!response.ok) {
        // Retry on 502/503/504 for GET requests
        if (canRetry && attempt < MAX_RETRIES && RETRY_STATUSES.has(response.status)) {
          await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
          continue;
        }
        const { detail, errorCode, connectionId } = await _parseError(response);
        throw new ApiError(detail, errorCode, connectionId);
      }
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        return null;
      }
      return response.json();
    } catch (err) {
      lastError = err as Error;
      // Retry on network errors (TypeError: Failed to fetch) for GET requests
      if (canRetry && attempt < MAX_RETRIES && err instanceof TypeError) {
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
        continue;
      }
      throw err;
    }
  }
  throw lastError || new ApiError('Request failed after retries');
};

const openDownload = (path: string) =>
  window.open(path.startsWith('http') ? path : `${API_BASE_URL}${path}`, '_blank');

/** Fetch for shared pages — sends X-Share-Token instead of Authorization header. */
const sharedFetch = async (shareToken: string, url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Share-Token': shareToken,
    ...(options.headers as Record<string, string>),
  };
  const response = await fetch(fullUrl, { ...options, headers });
  if (!response.ok) {
    const { detail } = await _parseError(response);
    throw new ApiError(detail);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
}

export const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
  };
};

const api = {
  // ── Utility ──────────────────────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: (err as Error).message })),

  // ── Files ─────────────────────────────────────────────────────────────────
  listFiles: (storageType: string | null = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },

  getFileSchema: (filePath: string) =>
    safeFetch(`/api/files/${filePath}/schema`).catch(err => {
      console.warn(`Schema failed for ${filePath}:`, (err as Error).message);
      return { file: filePath, columns: [], num_rows: 0 };
    }),

  uploadFile: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    const authHeader = getAuthHeader();
    const headers: Record<string, string> = {};
    if (authHeader) headers['Authorization'] = authHeader;
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form, headers })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 ────────────────────────────────────────────────────────────────────
  configureS3: (config: object) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Connections ───────────────────────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),
  getConnection: (id: string) => safeFetch(`/api/connections/${id}`),
  createConnection: (data: object) =>
    safeFetch('/api/connections', { method: 'POST', body: JSON.stringify(data) }),
  updateConnection: (id: string, data: object) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnection: (id: string) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),
  testConnection: (data: object) =>
    safeFetch('/api/connections/test', { method: 'POST', body: JSON.stringify(data) }),
  testSavedConnection: (id: string) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),
  listConnectionFiles: (connId: string, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),
  getConnectionFileSchema: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/files/${encodeURIComponent(filePath)}/schema`),

  // ── Iceberg (S3 connections only) ─────────────────────────────────────────
  listIcebergTables: (connId: string, prefix = '') =>
    safeFetch(`/api/connections/${connId}/iceberg/tables?prefix=${encodeURIComponent(prefix)}`),
  listIcebergFiles: (connId: string, tablePrefix: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/files?table_prefix=${encodeURIComponent(tablePrefix)}`),

  // ── Registered Tables ────────────────────────────────────────────────────
  listRegisteredTables: (connId: string) =>
    safeFetch(`/api/connections/${connId}/tables`),
  registerTable: (connId: string, table: { name: string; s3_prefix: string; format: string; description?: string }) =>
    safeFetch(`/api/connections/${connId}/tables`, { method: 'POST', body: JSON.stringify(table) }),
  unregisterTable: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}`, { method: 'DELETE' }),
  getRegisteredTableSchema: (connId: string, tableName: string, refresh?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema${refresh ? '?refresh=true' : ''}`),
  refreshTableSchema: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema/refresh`, { method: 'POST' }),
  refreshAllSchemas: (connId: string) =>
    safeFetch(`/api/connections/${connId}/schema/refresh-all`, { method: 'POST' }),
  getRegisteredTablePartitions: (connId: string, tableName: string, fullScan?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions${fullScan ? '?full_scan=true' : ''}`),
  refreshPartitionCache: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions/refresh`, { method: 'POST' }),
  refreshAllPartitions: (connId?: string) =>
    safeFetch(`/api/partitions/refresh-all${connId ? `?connection_id=${connId}` : ''}`, { method: 'POST' }),
  discoverTables: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/discover-tables?prefix=${encodeURIComponent(prefix || '')}`),
  browseFolders: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/browse-folders?prefix=${encodeURIComponent(prefix || '')}`),

  // ── Saved Queries ─────────────────────────────────────────────────────────
  listQueries: (activeOnly: boolean | { active_only?: boolean } = true) => {
    const active = typeof activeOnly === 'object'
      ? (activeOnly.active_only ?? true)
      : activeOnly;
    return safeFetch(`/api/queries?active_only=${active}`).catch(() => []);
  },
  getSavedQueries: (activeOnly = true) => api.listQueries(activeOnly),
  getSavedQuery: (id: string) =>
    safeFetch(`/api/queries/${id}`).catch(() => null),
  saveQuery: (data: { name: string; description?: string; query_config: QueryConfig; created_by?: string }) => {
    const payload = {
      name:         data.name,
      description:  data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
      created_by:   data.created_by || null,
    };
    return safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(payload) });
  },
  updateQuery: (id: string, data: { name: string; description?: string; query_config: QueryConfig }) =>
    safeFetch(`/api/queries/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: data.name, description: data.description || null,
        query_config: toBackendQueryConfig(data.query_config),
      }),
    }),
  patchQuery: (id: string | number, data: object) =>
    safeFetch(`/api/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteQuery: (id: string) => safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),
  toggleFavorite: (id: string | number) =>
    safeFetch(`/api/queries/${id}/favorite`, { method: 'POST' }),

  // ── Cost Estimate ────────────────────────────────────────────────────────
  estimateQuery: (queryConfig: QueryConfig, connectionId?: number) =>
    safeFetch('/api/execute/estimate', {
      method: 'POST',
      body: JSON.stringify({
        query_config: toBackendQueryConfig(queryConfig),
        connection_id: connectionId || null,
      }),
    }).catch(() => null),

  // ── Execution ─────────────────────────────────────────────────────────────
  executeQuery: (payload: { query_config?: QueryConfig; query_id?: string; raw_sql?: string; connection_id?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute', { method: 'POST', body: JSON.stringify(body) });
  },
  /** Execute a query on behalf of a shared-link viewer (no auth header, uses share token). */
  executeSharedQuery: (shareToken: string, payload: { query_config?: any; query_id?: number }) =>
    sharedFetch(shareToken, '/api/execute', { method: 'POST', body: JSON.stringify(payload) }),
  previewSql: (payload: { query_config: any; connection_id?: number }) =>
    safeFetch('/api/execute/preview-sql', { method: 'POST', body: JSON.stringify(payload) }),
  /** Stream first N rows directly from S3 via DuckDB httpfs — no file download. */
  streamQuery: (payload: { query_config?: any; raw_sql?: string; connection_id?: number; limit?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream', { method: 'POST', body: JSON.stringify(body) });
  },
  /** Paginated query directly from S3 via DuckDB httpfs — same response format as getExecutionResults. */
  streamPaginate: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    page?: number; page_size?: number;
    sort_column?: string | null; sort_direction?: string;
    adv_filters?: string;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/paginate', { method: 'POST', body: JSON.stringify(body) });
  },

  // ── Executions ────────────────────────────────────────────────────────────
  listExecutions: (params: { limit?: number; offset?: number; status?: string } | number = {}) => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  String(p.limit  ?? 50));
    qs.append('offset', String(p.offset ?? 0));
    if (p.status) qs.append('status', p.status);
    return safeFetch(`/api/executions?${qs}`).catch(() => []);
  },
  getExecution: (executionId: string) => safeFetch(`/api/executions/${executionId}`).catch(() => null),
  cancelExecution: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),
  getExecutionStatus: async (executionId: string) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      try {
        const downloads = await api.listDownloads('') as { execution_id: string; file_id: string }[];
        const match = downloads.find(d => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ─────────────────────────────────────────────────────────────
  listDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  getDownloads: (status = 'available') => api.listDownloads(status),
  downloadFile: (fileId: string) => openDownload(`/api/downloads/${fileId}`),
  deleteDownload: (fileId: string) => safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Results ───────────────────────────────────────────────────────────────
  getExecutionResults: (
    executionId: string, page = 1, pageSize = 100,
    sortColumn: string | null = null, sortDirection = 'asc', filters: object | null = null,
  ) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },
  exportResults: (executionId: string, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),
  getExecutionStats: (executionId: string) => safeFetch(`/api/executions/${executionId}/stats`),
  releaseExecutionResults: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/results`, { method: 'DELETE' }).catch(() => {}),

  // ── SQL Queries ───────────────────────────────────────────────────────────
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),
  createSqlQuery: (data: object) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: JSON.stringify(data) }),
  getSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`),
  updateSqlQuery: (id: string, data: object) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),
  executeSqlQuery: (payload: object) =>
    safeFetch('/api/sql/execute', { method: 'POST', body: JSON.stringify(payload) }),
  listSqlCatalogs: (connectionId: string) => safeFetch(`/api/sql/connections/${connectionId}/catalogs`),
  listSqlSchemas: (connectionId: string, catalog: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),
  listSqlTables: (connectionId: string, catalog: string, schema: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),
  listSqlColumns: (connectionId: string, catalog: string, schema: string, table: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),
  testSqlConnection: (connectionId: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Reports ───────────────────────────────────────────────────────────────
  listReports: (activeOnly = true) =>
    safeFetch(`/api/reports?active_only=${activeOnly}`).catch(() => []),
  createReport: (data: object) => safeFetch('/api/reports', { method: 'POST', body: JSON.stringify(data) }),
  getReport: (id: string) => safeFetch(`/api/reports/${id}`),
  updateReport: (id: string, data: object) =>
    safeFetch(`/api/reports/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteReport: (id: string) => safeFetch(`/api/reports/${id}`, { method: 'DELETE' }),
  executeReport: (id: string, paramValues: object = {}, rowLimit: number | null = null, executedBy: string | null = null) =>
    safeFetch(`/api/reports/${id}/execute`, {
      method: 'POST',
      body: JSON.stringify({ param_values: paramValues, row_limit: rowLimit, executed_by: executedBy }),
    }),
  getReportSourceInfo: (id: string) => safeFetch(`/api/reports/${id}/source-info`),
  getReportColumns: (id: string) =>
    safeFetch(`/api/reports/${id}/columns`).catch(() => ({ columns: [], date_shortcuts: [] })),
  getReportParamValues: (id: string, paramName: string, limit = 1000) =>
    safeFetch(`/api/reports/${id}/param-values?param_name=${encodeURIComponent(paramName)}&limit=${limit}`)
      .catch(() => ({ values: [], total: 0, truncated: false })),
  downloadReportDirect: (id: string, paramValues: Record<string, string> = {}) => {
    const qs = new URLSearchParams(paramValues).toString();
    openDownload(`/api/reports/${id}/download${qs ? '?' + qs : ''}`);
  },
  previewDownloadFile: (fileId: string, page = 1, pageSize = 100) =>
    safeFetch(`/api/downloads/${fileId}/preview?page=${page}&page_size=${pageSize}`),

  // ── Schedules ─────────────────────────────────────────────────────────────
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),
  createSchedule: (data: object) =>
    safeFetch('/api/schedules', { method: 'POST', body: JSON.stringify(data) }),
  getSchedule: (id: string) => safeFetch(`/api/schedules/${id}`),
  updateSchedule: (id: string, data: object) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSchedule: (id: string) => safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),
  pauseSchedule: (id: string) => safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),
  resumeSchedule: (id: string) => safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),
  runScheduleNow: (id: string) => safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),
  getSchedulerStatus: () => safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),

  // ── Query Version History ─────────────────────────────────────────────────
  listQueryVersions: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions`).catch(() => []),
  restoreQueryVersion: (queryId: string | number, versionId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions/${versionId}/restore`, { method: 'POST' }),

  // ── Query Sharing ─────────────────────────────────────────────────────────
  shareQuery: (queryId: string | number, opts: { expires_hours?: number } = {}) =>
    safeFetch(`/api/queries/${queryId}/share`, { method: 'POST', body: JSON.stringify(opts) }),
  listQueryShares: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/shares`).catch(() => []),
  revokeShare: (queryId: string | number, token: string) =>
    safeFetch(`/api/queries/${queryId}/shares/${token}`, { method: 'DELETE' }),
  getSharedQuery: (token: string) =>
    safeFetch(`/api/shared/${token}`),
  getSharedDashboard: (token: string) =>
    safeFetch(`/api/shared-dashboard/${token}`),
  createDashboardShare: (dashboardId: string | number, expiresHours?: number) =>
    safeFetch(`/api/dashboards/${dashboardId}/share`, {
      method: 'POST', body: JSON.stringify({ expires_hours: expiresHours ?? null }),
    }),

  // ── Dashboards ────────────────────────────────────────────────────────────
  listDashboards: () => safeFetch('/api/dashboards').catch(() => []),
  createDashboard: (data: object) =>
    safeFetch('/api/dashboards', { method: 'POST', body: JSON.stringify(data) }),
  getDashboard: (id: string | number) => safeFetch(`/api/dashboards/${id}`),
  updateDashboard: (id: string | number, data: object) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDashboard: (id: string | number) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'DELETE' }),
  listDashboardWidgets: (dashId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`).catch(() => []),
  createWidget: (dashId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`, { method: 'POST', body: JSON.stringify(data) }),
  updateWidget: (dashId: string | number, widgetId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteWidget: (dashId: string | number, widgetId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'DELETE' }),
  updateDashboardLayout: (dashId: string | number, layouts: object[]) =>
    safeFetch(`/api/dashboards/${dashId}/layout`, { method: 'PUT', body: JSON.stringify({ layouts }) }),

  // ── Cache ─────────────────────────────────────────────────────────────────
  getCacheStats: () => safeFetch('/api/cache/stats').catch(() => ({})),
  clearCache: () => safeFetch('/api/cache', { method: 'DELETE' }),

  // ── Webhooks ──────────────────────────────────────────────────────────────
  testWebhook: (url: string) =>
    safeFetch('/api/webhooks/test', { method: 'POST', body: JSON.stringify({ url }) }),

  // ── Join preview ─────────────────────────────────────────────────────────
  joinPreview: (req: { connection_id?: number; left_file: string; right_file: string;
                        left_on: string[]; right_on: string[]; how?: string }) =>
    safeFetch('/api/joins/preview', { method: 'POST', body: JSON.stringify(req) }),
};

export default api;
