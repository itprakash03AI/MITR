import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';

interface User {
  username: string;
  display_name: string;
  email: string;
  groups: string[];
  is_admin: boolean;
  role: string;
}

interface AuthContextValue {
  user: User | null;
  authEnabled: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

// Module-level header accessed by api.ts and other components without circular imports.
// After login this is "Bearer <session_token>" — the password is NEVER stored here.
let _authHeader: string | null = null;
export const getAuthHeader = () => _authHeader;

const STORAGE_KEY = 'qs_auth';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours

// Use relative paths — proxied in dev (vite.config.ts), same origin in prod
const authFetch = (path: string, opts?: RequestInit) =>
  fetch(path, opts);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authEnabled, setAuthEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const expiryTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearSession = () => {
    _authHeader = null;
    setUser(null);
    sessionStorage.removeItem(STORAGE_KEY);
  };

  // Periodic expiry check — runs every 60s when auth is enabled
  useEffect(() => {
    if (!authEnabled || !user) return;
    expiryTimerRef.current = setInterval(() => {
      const stored = sessionStorage.getItem(STORAGE_KEY);
      if (!stored) { clearSession(); return; }
      try {
        const { expiresAt } = JSON.parse(stored) as { token: string; expiresAt: number };
        if (expiresAt && Date.now() > expiresAt) {
          clearSession();
        }
      } catch { clearSession(); }
    }, 60_000);
    return () => { if (expiryTimerRef.current) clearInterval(expiryTimerRef.current); };
  }, [authEnabled, user]);

  useEffect(() => {
    const init = async () => {
      try {
        const res = await authFetch('/auth/config');
        if (!res.ok) { setIsLoading(false); return; }
        const cfg = await res.json() as { type: string };
        const enabled = cfg.type !== 'none';
        setAuthEnabled(enabled);
        if (!enabled) {
          // No auth — grant full access as guest admin
          setUser({ username: 'guest', display_name: 'Guest', email: '', groups: [], is_admin: true, role: 'admin' });
          setIsLoading(false);
          return;
        }

        // Restore session from sessionStorage (only the opaque token is stored)
        const stored = sessionStorage.getItem(STORAGE_KEY);
        if (stored) {
          try {
            const { token, expiresAt } = JSON.parse(stored) as { token: string; expiresAt?: number };
            // Check client-side expiry before calling /auth/me
            if (expiresAt && Date.now() > expiresAt) {
              sessionStorage.removeItem(STORAGE_KEY);
            } else {
              const bearerHeader = `Bearer ${token}`;
              const meRes = await authFetch('/auth/me', {
                headers: { Authorization: bearerHeader },
              });
              if (meRes.ok) {
                _authHeader = bearerHeader;
                setUser(await meRes.json() as User);
              } else {
                sessionStorage.removeItem(STORAGE_KEY);
              }
            }
          } catch {
            sessionStorage.removeItem(STORAGE_KEY);
          }
        }
      } catch {
        // Backend unreachable — proceed without auth gate
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  const login = async (username: string, password: string) => {
    // Send credentials only once — backend returns an opaque session token
    const res = await authFetch('/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({})) as { detail?: string };
      throw new Error(err.detail || 'Login failed');
    }
    const data = await res.json() as User & { session_token: string };
    const { session_token, ...userData } = data;
    _authHeader = `Bearer ${session_token}`;
    setUser(userData);
    // Store only the opaque token — password is NEVER persisted
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
      token: session_token,
      expiresAt: Date.now() + SESSION_TTL_MS,
    }));
  };

  const logout = () => {
    // Destroy server-side session
    if (_authHeader) {
      authFetch('/auth/logout', {
        method: 'POST',
        headers: { Authorization: _authHeader },
      }).catch(() => {});
    }
    clearSession();
  };

  return (
    <AuthContext.Provider value={{ user, authEnabled, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
