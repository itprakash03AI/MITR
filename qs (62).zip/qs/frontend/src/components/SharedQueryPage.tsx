// @ts-nocheck
/**
 * SharedQueryPage — public share-link page (no auth required).
 *
 * Features:
 *  - Query info card (name, description, meta, share details)
 *  - Execute with real-time polling
 *  - Results: Table (paginated) | Bar | Line | Area | Pie chart | Pivot table
 *  - Search / filter rows client-side
 *  - Email share via mailto:
 *  - Copy link button
 *  - Export (CSV download)
 *  - Fully responsive, no auth dependency
 */
import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Alert, Box, Button, Chip, CircularProgress, Divider, IconButton,
  InputAdornment, MenuItem, Paper, Select, Tab, Tabs, TextField,
  Tooltip, Typography, TableContainer, Table, TableHead, TableRow,
  TableCell, TableBody, TablePagination,
} from '@mui/material';
import {
  BoltOutlined as BoltIcon,
  LinkOff as LinkOffIcon,
  ContentCopy as CopyIcon,
  Email as EmailIcon,
  Download as DownloadIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  BarChart as BarIcon,
  ShowChart as LineIcon,
  PieChart as PieIcon,
  TableChart as TableIcon,
  GridOn as PivotIcon,
  AreaChart as AreaIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell, Tooltip as RTooltip, Legend,
  XAxis, YAxis, CartesianGrid, ResponsiveContainer,
} from 'recharts';
import api from '../services/api';

// ─── Constants ────────────────────────────────────────────────────────────────

const CHART_COLORS = [
  '#1976d2','#2e7d32','#f57c00','#7b1fa2','#c62828',
  '#00838f','#558b2f','#ad1457','#1565c0','#4e342e',
];
const ROWS_PER_PAGE_OPTIONS = [25, 50, 100, 250];
const VIEW_MODES = [
  { id: 'table', label: 'Table',  icon: <TableIcon fontSize="small" /> },
  { id: 'bar',   label: 'Bar',   icon: <BarIcon   fontSize="small" /> },
  { id: 'line',  label: 'Line',  icon: <LineIcon   fontSize="small" /> },
  { id: 'area',  label: 'Area',  icon: <AreaIcon   fontSize="small" /> },
  { id: 'pie',   label: 'Pie',   icon: <PieIcon    fontSize="small" /> },
  { id: 'pivot', label: 'Pivot', icon: <PivotIcon  fontSize="small" /> },
];
const fmtNum = (n: number) =>
  n >= 1_000_000 ? `${(n/1_000_000).toFixed(1)}M`
  : n >= 1_000   ? `${(n/1_000).toFixed(1)}K`
  : String(n);
const fmtDate = (s: string) => s ? new Date(s).toLocaleString() : '—';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isNumericCol(rows: any[], col: string): boolean {
  const sample = rows.slice(0, 20).map(r => r[col]).filter(v => v !== null && v !== undefined);
  return sample.length > 0 && sample.every(v => !isNaN(Number(v)));
}

function exportCsv(rows: any[], cols: string[], filename: string) {
  const header = cols.join(',');
  const body = rows.map(r =>
    cols.map(c => {
      const v = r[c] === null || r[c] === undefined ? '' : String(r[c]);
      return v.includes(',') || v.includes('"') || v.includes('\n')
        ? `"${v.replace(/"/g, '""')}"` : v;
    }).join(',')
  ).join('\n');
  const blob = new Blob([header + '\n' + body], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

// ─── Chart components ─────────────────────────────────────────────────────────

function ChartView({ rows, xCol, yCol, chartType, aggFn }: {
  rows: any[]; xCol: string; yCol: string; chartType: string; aggFn: string;
}) {
  // Aggregate rows by xCol
  const agg = useMemo(() => {
    const map = new Map<string, number[]>();
    rows.forEach(r => {
      const k = String(r[xCol] ?? '(blank)');
      const v = Number(r[yCol]);
      if (!map.has(k)) map.set(k, []);
      if (!isNaN(v)) map.get(k)!.push(v);
    });
    return Array.from(map.entries()).map(([name, vals]) => {
      let value = 0;
      if (aggFn === 'sum')   value = vals.reduce((a, b) => a + b, 0);
      if (aggFn === 'avg')   value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      if (aggFn === 'count') value = vals.length;
      if (aggFn === 'max')   value = Math.max(...vals);
      if (aggFn === 'min')   value = Math.min(...vals);
      return { name, value: Math.round(value * 100) / 100 };
    }).sort((a, b) => b.value - a.value).slice(0, 50);
  }, [rows, xCol, yCol, aggFn]);

  const commonProps = {
    data: agg, margin: { top: 10, right: 20, left: 10, bottom: 60 },
  };
  const xProps = {
    dataKey: 'name', tick: { fontSize: 11 }, angle: -35, textAnchor: 'end', interval: 0,
  };
  const yProps = {
    tick: { fontSize: 11 }, tickFormatter: fmtNum, width: 55,
  };

  if (chartType === 'pie') {
    return (
      <ResponsiveContainer width="100%" height={420}>
        <PieChart>
          <Pie data={agg} dataKey="value" nameKey="name" cx="50%" cy="50%"
               outerRadius={160} label={({ name, percent }) =>
                 `${name} (${(percent * 100).toFixed(1)}%)`}
               labelLine>
            {agg.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Pie>
          <RTooltip formatter={(v: number) => fmtNum(v)} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === 'line') {
    return (
      <ResponsiveContainer width="100%" height={380}>
        <LineChart {...commonProps}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis {...xProps} />
          <YAxis {...yProps} />
          <RTooltip formatter={(v: number) => fmtNum(v)} />
          <Line type="monotone" dataKey="value" stroke={CHART_COLORS[0]} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === 'area') {
    return (
      <ResponsiveContainer width="100%" height={380}>
        <AreaChart {...commonProps}>
          <defs>
            <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={CHART_COLORS[0]} stopOpacity={0.35} />
              <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis {...xProps} />
          <YAxis {...yProps} />
          <RTooltip formatter={(v: number) => fmtNum(v)} />
          <Area type="monotone" dataKey="value" stroke={CHART_COLORS[0]} fill="url(#grad)" />
        </AreaChart>
      </ResponsiveContainer>
    );
  }

  // Default: bar
  return (
    <ResponsiveContainer width="100%" height={380}>
      <BarChart {...commonProps}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        <RTooltip formatter={(v: number) => fmtNum(v)} />
        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
          {agg.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─── Pivot table ──────────────────────────────────────────────────────────────

function PivotView({ rows, rowCol, valCol, aggFn }: {
  rows: any[]; rowCol: string; valCol: string; aggFn: string;
}) {
  const agg = useMemo(() => {
    const map = new Map<string, number[]>();
    rows.forEach(r => {
      const k = String(r[rowCol] ?? '(blank)');
      const v = Number(r[valCol]);
      if (!map.has(k)) map.set(k, []);
      if (!isNaN(v)) map.get(k)!.push(v);
    });
    const result = Array.from(map.entries()).map(([key, vals]) => {
      let agg_v = 0;
      const sum = vals.reduce((a, b) => a + b, 0);
      if (aggFn === 'sum')   agg_v = sum;
      if (aggFn === 'avg')   agg_v = vals.length ? sum / vals.length : 0;
      if (aggFn === 'count') agg_v = vals.length;
      if (aggFn === 'max')   agg_v = Math.max(...vals);
      if (aggFn === 'min')   agg_v = Math.min(...vals);
      return { key, value: Math.round(agg_v * 100) / 100, count: vals.length };
    }).sort((a, b) => b.value - a.value);
    const total = result.reduce((s, r) => s + r.value, 0);
    return { result, total };
  }, [rows, rowCol, valCol, aggFn]);

  return (
    <TableContainer sx={{ maxHeight: 520 }}>
      <Table size="small" stickyHeader>
        <TableHead>
          <TableRow>
            <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.100' }}>{rowCol}</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700, bgcolor: 'grey.100' }}>Count</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700, bgcolor: 'grey.100' }}>
              {aggFn.toUpperCase()}({valCol})
            </TableCell>
            <TableCell align="right" sx={{ fontWeight: 700, bgcolor: 'grey.100' }}>% of Total</TableCell>
            <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.100', width: 180 }}>Distribution</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {agg.result.map(r => {
            const pct = agg.total > 0 ? (r.value / agg.total) * 100 : 0;
            return (
              <TableRow key={r.key} hover>
                <TableCell sx={{ maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {r.key}
                </TableCell>
                <TableCell align="right">
                  <Chip label={r.count} size="small" variant="outlined" sx={{ fontSize: 11 }} />
                </TableCell>
                <TableCell align="right">
                  <Typography variant="body2" fontWeight={600}>{fmtNum(r.value)}</Typography>
                </TableCell>
                <TableCell align="right">
                  <Typography variant="caption" color="text.secondary">{pct.toFixed(1)}%</Typography>
                </TableCell>
                <TableCell>
                  <Box sx={{ background: '#f1f5f9', borderRadius: 1, height: 10, overflow: 'hidden' }}>
                    <Box sx={{ width: `${pct}%`, height: '100%', bgcolor: 'primary.main', borderRadius: 1 }} />
                  </Box>
                </TableCell>
              </TableRow>
            );
          })}
          {/* Total row */}
          <TableRow sx={{ bgcolor: 'grey.50' }}>
            <TableCell sx={{ fontWeight: 700 }}>Total</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>
              {agg.result.reduce((s, r) => s + r.count, 0).toLocaleString()}
            </TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>{fmtNum(agg.total)}</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>100%</TableCell>
            <TableCell />
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function SharedQueryPage() {
  const { token } = useParams<{ token: string }>();

  // Remote data
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState<string | null>(null);
  const [data,      setData]      = useState<any>(null);
  const [allRows,   setAllRows]   = useState<any[]>([]);
  const [executing, setExecuting] = useState(false);
  const [execError, setExecError] = useState<string | null>(null);

  // View state
  const [viewTab,    setViewTab]    = useState(0);          // 0=table,1=bar,2=line,3=area,4=pie,5=pivot
  const [search,     setSearch]     = useState('');
  const [page,       setPage]       = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [copied,     setCopied]     = useState(false);

  // Chart config
  const [xCol,  setXCol]  = useState('');
  const [yCol,  setYCol]  = useState('');
  const [aggFn, setAggFn] = useState('sum');

  // Load share metadata
  useEffect(() => {
    api.getSharedQuery(token!)
      .then(d => { setData(d); setLoading(false); })
      .catch(err => { setError(String(err)); setLoading(false); });
  }, [token]);

  // Auto-pick x/y columns when rows arrive
  useEffect(() => {
    if (allRows.length === 0) return;
    const cols = Object.keys(allRows[0]);
    const numCols  = cols.filter(c => isNumericCol(allRows, c));
    const strCols  = cols.filter(c => !isNumericCol(allRows, c));
    if (!xCol) setXCol(strCols[0] || cols[0] || '');
    if (!yCol) setYCol(numCols[0] || cols[1] || '');
  }, [allRows]);

  const handleExecute = async () => {
    if (!data?.query) return;
    setExecuting(true);
    setExecError(null);
    setAllRows([]);
    setPage(0);
    try {
      const resp = await api.executeSharedQuery(token!, { query_config: data.query.query_config });
      if (!resp?.execution_id) throw new Error('No execution ID returned');

      // Cache hit — fetch immediately
      if (resp.status === 'completed' || resp.cache_hit) {
        const res = await api.getExecutionResults(resp.execution_id, 1, 5000);
        setAllRows(res?.rows || res?.data || []);
        setExecuting(false);
        return;
      }

      // Poll for completion
      for (let i = 0; i < 60; i++) {
        await new Promise(r => setTimeout(r, 1500));
        const status = await api.getExecutionStatus(resp.execution_id);
        if (status?.status === 'completed') {
          const res = await api.getExecutionResults(resp.execution_id, 1, 5000);
          setAllRows(res?.rows || res?.data || []);
          break;
        }
        if (status?.status === 'failed') {
          setExecError(status.error_message || 'Query failed');
          break;
        }
      }
    } catch (e: any) {
      setExecError(e.message || 'Execution failed');
    } finally {
      setExecuting(false);
    }
  };

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent(`QueryStudio — ${data?.query?.name || 'Shared Query'}`);
    const body = encodeURIComponent(
      `I'd like to share this query with you:\n\n${data?.query?.name || 'Query'}\n\n${data?.query?.description || ''}\n\nView it here: ${window.location.href}`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`);
  };

  const handleExportCsv = () => {
    if (!filteredRows.length) return;
    const cols = Object.keys(filteredRows[0]);
    exportCsv(filteredRows, cols, `${data?.query?.name || 'query'}_results.csv`);
  };

  // Derived data
  const cols: string[] = allRows.length ? Object.keys(allRows[0]) : [];
  const numCols  = cols.filter(c => isNumericCol(allRows, c));
  const strCols  = cols.filter(c => !isNumericCol(allRows, c));

  const filteredRows = useMemo(() => {
    if (!search.trim()) return allRows;
    const q = search.toLowerCase();
    return allRows.filter(r =>
      cols.some(c => String(r[c] ?? '').toLowerCase().includes(q))
    );
  }, [allRows, search, cols]);

  const pagedRows = filteredRows.slice(page * rowsPerPage, (page + 1) * rowsPerPage);

  const viewMode = VIEW_MODES[viewTab]?.id || 'table';
  const hasResults = allRows.length > 0;

  // ── Loading / error states ─────────────────────────────────────────────────

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
                 justifyContent: 'center', minHeight: '100vh', gap: 2, p: 4,
                 background: 'linear-gradient(135deg,#f8fafc 0%,#e8f4fd 100%)' }}>
        <Box sx={{ width: 72, height: 72, borderRadius: '50%', bgcolor: '#fee2e2',
                   display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <LinkOffIcon sx={{ fontSize: 36, color: '#dc2626' }} />
        </Box>
        <Typography variant="h5" fontWeight={700}>Link Not Available</Typography>
        <Typography color="text.secondary" textAlign="center" maxWidth={400}>
          This shared query link is invalid, expired, or has been revoked.
          Please ask the owner to generate a new link.
        </Typography>
      </Box>
    );
  }

  const query = data?.query;
  const share = data?.share;

  // ── Main layout ────────────────────────────────────────────────────────────

  return (
    <Box sx={{ minHeight: '100vh', background: 'linear-gradient(135deg,#f8fafc 0%,#e8f4fd 100%)', pb: 6 }}>

      {/* ── Top bar ────────────────────────────────────────────────────────── */}
      <Box sx={{
        background: 'linear-gradient(90deg,#0d47a1 0%,#1976d2 100%)',
        px: { xs: 2, sm: 4 }, py: 1.5,
        display: 'flex', alignItems: 'center', gap: 2,
      }}>
        <BoltIcon sx={{ color: '#fff', fontSize: 26 }} />
        <Typography variant="h6" fontWeight={800} sx={{ color: '#fff', flex: 1 }}>
          QueryStudio
        </Typography>
        <Chip label="Public Share" size="small"
              sx={{ bgcolor: 'rgba(255,255,255,0.18)', color: '#fff', fontWeight: 600, fontSize: 11 }} />
        <Tooltip title={copied ? 'Copied!' : 'Copy link'}>
          <IconButton size="small" onClick={handleCopyLink} sx={{ color: 'rgba(255,255,255,0.85)' }}>
            <CopyIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Share via email">
          <IconButton size="small" onClick={handleEmailShare} sx={{ color: 'rgba(255,255,255,0.85)' }}>
            <EmailIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>

      <Box sx={{ maxWidth: 1400, mx: 'auto', px: { xs: 2, sm: 4 }, pt: 3 }}>

        {/* ── Query info card ─────────────────────────────────────────────── */}
        <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 3, borderRadius: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, flexWrap: 'wrap' }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h5" fontWeight={800} gutterBottom>{query?.name}</Typography>
              {query?.description && (
                <Typography color="text.secondary" sx={{ mb: 1.5 }}>{query.description}</Typography>
              )}
              <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
                {share?.created_by && (
                  <Chip icon={<BoltIcon sx={{ fontSize: '13px !important' }} />}
                        label={`Shared by ${share.created_by}`} size="small" variant="outlined" />
                )}
                {share?.created_at && (
                  <Typography variant="caption" color="text.secondary">
                    {fmtDate(share.created_at)}
                  </Typography>
                )}
                {share?.expires_at && (
                  <Chip label={`Expires ${new Date(share.expires_at).toLocaleDateString()}`}
                        size="small" color="warning" variant="outlined" />
                )}
                {share?.access_count > 0 && (
                  <Chip label={`${share.access_count} views`} size="small" variant="outlined" />
                )}
              </Box>
            </Box>

            {/* Action buttons */}
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
              <Button
                variant="outlined" size="small" startIcon={<CopyIcon />}
                onClick={handleCopyLink}
                color={copied ? 'success' : 'primary'}
              >
                {copied ? 'Copied!' : 'Copy Link'}
              </Button>
              <Button
                variant="outlined" size="small" startIcon={<EmailIcon />}
                onClick={handleEmailShare}
              >
                Email Link
              </Button>
              <Button
                variant="contained" size="small" startIcon={
                  executing ? <CircularProgress size={14} color="inherit" /> : <BoltIcon />
                }
                onClick={handleExecute}
                disabled={executing}
              >
                {executing ? 'Running…' : 'Run Query'}
              </Button>
            </Box>
          </Box>
        </Paper>

        {/* ── Execute error ───────────────────────────────────────────────── */}
        {execError && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setExecError(null)}>
            {execError}
          </Alert>
        )}

        {/* ── Executing spinner ───────────────────────────────────────────── */}
        {executing && (
          <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', mb: 3, borderRadius: 2 }}>
            <CircularProgress size={36} sx={{ mb: 2 }} />
            <Typography color="text.secondary">Running query…</Typography>
          </Paper>
        )}

        {/* ── Results panel ───────────────────────────────────────────────── */}
        {hasResults && (
          <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>

            {/* Toolbar */}
            <Box sx={{ px: 2, pt: 2, pb: 1, display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap',
                       borderBottom: '1px solid', borderColor: 'divider' }}>
              <Box sx={{ flex: 1, minWidth: 200 }}>
                <Typography variant="subtitle1" fontWeight={700}>
                  Results
                  <Chip label={`${filteredRows.length.toLocaleString()} rows`} size="small"
                        sx={{ ml: 1, fontWeight: 600 }} />
                  {search && filteredRows.length < allRows.length && (
                    <Chip label={`filtered from ${allRows.length.toLocaleString()}`}
                          size="small" color="warning" sx={{ ml: 0.5 }} />
                  )}
                </Typography>
              </Box>

              {/* Search */}
              <TextField
                size="small" placeholder="Search all columns…" value={search}
                onChange={e => { setSearch(e.target.value); setPage(0); }}
                sx={{ minWidth: 200 }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment>,
                  endAdornment: search
                    ? <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setSearch('')}><ClearIcon sx={{ fontSize: 14 }} /></IconButton>
                      </InputAdornment>
                    : null,
                }}
              />

              {/* Export */}
              <Tooltip title="Export as CSV">
                <IconButton size="small" onClick={handleExportCsv}>
                  <DownloadIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>

            {/* View tabs */}
            <Box sx={{ borderBottom: '1px solid', borderColor: 'divider', px: 2 }}>
              <Tabs value={viewTab} onChange={(_, v) => setViewTab(v)} variant="scrollable" scrollButtons="auto">
                {VIEW_MODES.map((m, i) => (
                  <Tab key={m.id} label={m.label} icon={m.icon} iconPosition="start"
                       sx={{ minHeight: 44, fontSize: 13 }} />
                ))}
              </Tabs>
            </Box>

            {/* Chart axis config strip (shown for non-table/non-pivot) */}
            {viewTab > 0 && viewTab < 5 && (
              <Box sx={{ px: 2, py: 1.5, display: 'flex', gap: 2, flexWrap: 'wrap',
                         borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50' }}>
                <Select size="small" value={xCol} onChange={e => setXCol(e.target.value)}
                        displayEmpty sx={{ minWidth: 160 }}>
                  <MenuItem value="" disabled>X-axis (category)</MenuItem>
                  {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </Select>
                <Select size="small" value={yCol} onChange={e => setYCol(e.target.value)}
                        displayEmpty sx={{ minWidth: 160 }}>
                  <MenuItem value="" disabled>Y-axis (value)</MenuItem>
                  {numCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </Select>
                <Select size="small" value={aggFn} onChange={e => setAggFn(e.target.value)}
                        sx={{ minWidth: 120 }}>
                  <MenuItem value="sum">Sum</MenuItem>
                  <MenuItem value="avg">Average</MenuItem>
                  <MenuItem value="count">Count</MenuItem>
                  <MenuItem value="max">Max</MenuItem>
                  <MenuItem value="min">Min</MenuItem>
                </Select>
              </Box>
            )}

            {/* Pivot axis config strip */}
            {viewTab === 5 && (
              <Box sx={{ px: 2, py: 1.5, display: 'flex', gap: 2, flexWrap: 'wrap',
                         borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50' }}>
                <Select size="small" value={xCol} onChange={e => setXCol(e.target.value)}
                        displayEmpty sx={{ minWidth: 180 }}>
                  <MenuItem value="" disabled>Group by (row)</MenuItem>
                  {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </Select>
                <Select size="small" value={yCol} onChange={e => setYCol(e.target.value)}
                        displayEmpty sx={{ minWidth: 180 }}>
                  <MenuItem value="" disabled>Aggregate column</MenuItem>
                  {numCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </Select>
                <Select size="small" value={aggFn} onChange={e => setAggFn(e.target.value)}
                        sx={{ minWidth: 120 }}>
                  <MenuItem value="sum">Sum</MenuItem>
                  <MenuItem value="avg">Average</MenuItem>
                  <MenuItem value="count">Count</MenuItem>
                  <MenuItem value="max">Max</MenuItem>
                  <MenuItem value="min">Min</MenuItem>
                </Select>
              </Box>
            )}

            {/* ── Table view ──────────────────────────────────────────────── */}
            {viewTab === 0 && (
              <>
                <TableContainer sx={{ maxHeight: 560 }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', color: 'text.secondary',
                                         fontSize: 11, width: 48 }}>#</TableCell>
                        {cols.map(c => (
                          <TableCell key={c} sx={{ fontWeight: 700, bgcolor: 'grey.50',
                                                    whiteSpace: 'nowrap', fontSize: 12 }}>
                            {c}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {pagedRows.map((row, ri) => (
                        <TableRow key={ri} hover>
                          <TableCell sx={{ color: 'text.disabled', fontSize: 11 }}>
                            {page * rowsPerPage + ri + 1}
                          </TableCell>
                          {cols.map(c => {
                            const val = row[c];
                            const isNum = typeof val === 'number' || (val !== null && !isNaN(Number(val)) && val !== '');
                            return (
                              <TableCell key={c} sx={{ maxWidth: 240, overflow: 'hidden',
                                                        textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                                                        fontSize: 13,
                                                        textAlign: isNum ? 'right' : 'left' }}>
                                {val === null || val === undefined ? (
                                  <Typography variant="caption" color="text.disabled" fontStyle="italic">null</Typography>
                                ) : isNum ? (
                                  <Typography variant="body2" fontFamily="monospace">
                                    {typeof val === 'number' ? val.toLocaleString() : val}
                                  </Typography>
                                ) : String(val)}
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  component="div"
                  count={filteredRows.length}
                  page={page}
                  onPageChange={(_, p) => setPage(p)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
                  rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
                />
              </>
            )}

            {/* ── Chart view (bar/line/area/pie) ──────────────────────────── */}
            {viewTab >= 1 && viewTab <= 4 && (
              <Box sx={{ p: 3 }}>
                {!xCol || !yCol ? (
                  <Alert severity="info">Select X-axis and Y-axis columns above to render the chart.</Alert>
                ) : (
                  <ChartView
                    rows={filteredRows}
                    xCol={xCol}
                    yCol={yCol}
                    chartType={viewMode}
                    aggFn={aggFn}
                  />
                )}
              </Box>
            )}

            {/* ── Pivot view ──────────────────────────────────────────────── */}
            {viewTab === 5 && (
              <Box sx={{ p: 2 }}>
                {!xCol || !yCol ? (
                  <Alert severity="info">Select Group-by and Aggregate columns above to render the pivot.</Alert>
                ) : (
                  <PivotView
                    rows={filteredRows}
                    rowCol={xCol}
                    valCol={yCol}
                    aggFn={aggFn}
                  />
                )}
              </Box>
            )}
          </Paper>
        )}

        {/* ── Prompt to run ────────────────────────────────────────────────── */}
        {!hasResults && !executing && !execError && (
          <Paper variant="outlined" sx={{ p: 5, textAlign: 'center', borderRadius: 2,
                                          borderStyle: 'dashed' }}>
            <BoltIcon sx={{ fontSize: 48, color: 'primary.light', mb: 1 }} />
            <Typography variant="h6" fontWeight={700} gutterBottom>Ready to Run</Typography>
            <Typography color="text.secondary" sx={{ mb: 2 }}>
              Click <strong>Run Query</strong> to execute and see results here.
            </Typography>
            <Button variant="contained" startIcon={<BoltIcon />} onClick={handleExecute}
                    disabled={executing}>
              Run Query
            </Button>
          </Paper>
        )}

      </Box>

      {/* Footer */}
      <Box sx={{ textAlign: 'center', mt: 6, color: 'text.disabled', fontSize: 13 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5 }}>
          <BoltIcon sx={{ fontSize: 14 }} />
          <span>Powered by <strong>QueryStudio</strong> — Enterprise Data Platform</span>
        </Box>
      </Box>
    </Box>
  );
}
