import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../context/NotificationContext';
import { Snackbar, Alert, AlertTitle, Box, Button, IconButton, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const SEVERITY_ICON: Record<string, React.ReactNode> = {
  success: <CheckCircleOutlineIcon sx={{ fontSize: 22 }} />,
  error:   <ErrorOutlineIcon sx={{ fontSize: 22 }} />,
  info:    <InfoOutlinedIcon sx={{ fontSize: 22 }} />,
  warning: <WarningAmberIcon sx={{ fontSize: 22 }} />,
};

const NotificationCenter = () => {
  const { notifications, removeNotification } = useNotifications();
  const navigate = useNavigate();

  return (
    <>
      {notifications.slice(-3).map((n, i) => (
        <Snackbar
          key={n.id}
          open
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          sx={{ bottom: { xs: 24 + i * 96 } }}
          autoHideDuration={n.type === 'error' || n.action ? null : 5000}
          onClose={() => removeNotification(n.id)}
        >
          <Alert
            severity={n.type === 'info' ? 'info' : n.type}
            variant="filled"
            icon={SEVERITY_ICON[n.type] || SEVERITY_ICON.info}
            sx={{
              width: '100%', minWidth: 340, maxWidth: 480,
              borderRadius: 2,
              boxShadow: '0 8px 24px rgba(0,0,0,0.18)',
              alignItems: 'flex-start',
              '& .MuiAlert-icon': { pt: 1.1 },
              '& .MuiAlert-message': { flex: 1, minWidth: 0 },
              '& .MuiAlert-action': { pt: 0.5 },
            }}
            action={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexShrink: 0 }}>
                {n.action && (
                  <Button
                    size="small"
                    color="inherit"
                    variant="outlined"
                    sx={{
                      fontWeight: 700, whiteSpace: 'nowrap', fontSize: 11,
                      borderColor: 'rgba(255,255,255,0.45)',
                      '&:hover': { borderColor: 'rgba(255,255,255,0.8)', bgcolor: 'rgba(255,255,255,0.12)' },
                    }}
                    onClick={() => { removeNotification(n.id); navigate(n.action!.href); }}
                  >
                    {n.action.label}
                  </Button>
                )}
                <IconButton size="small" color="inherit" onClick={() => removeNotification(n.id)}
                  sx={{ opacity: 0.7, '&:hover': { opacity: 1, bgcolor: 'rgba(255,255,255,0.12)' } }}>
                  <CloseIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </Box>
            }
          >
            <AlertTitle sx={{ fontWeight: 700, fontSize: '0.875rem', mb: 0.25, lineHeight: 1.4 }}>
              {n.title}
            </AlertTitle>
            {n.message && (
              <Typography variant="body2" sx={{
                opacity: 0.92, lineHeight: 1.45, fontSize: '0.8rem',
                overflow: 'hidden', textOverflow: 'ellipsis',
                display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical',
              }}>
                {n.message}
              </Typography>
            )}
            {n.timestamp && (
              <Typography variant="caption" sx={{ opacity: 0.55, fontSize: '0.65rem', mt: 0.5, display: 'block' }}>
                {new Date(n.timestamp).toLocaleTimeString()}
              </Typography>
            )}
          </Alert>
        </Snackbar>
      ))}
    </>
  );
};

export default NotificationCenter;
