import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Box, Typography, Button } from '@mui/material';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

interface Props { children: ReactNode; resetKey?: string; }
interface State { hasError: boolean; error: Error | null; }

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidUpdate(prevProps: Props) {
    // Reset error state when the route changes (resetKey = pathname)
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false, error: null });
    }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', minHeight: '60vh', gap: 2, p: 4 }}>
          <ErrorOutlineIcon sx={{ fontSize: 56, color: 'error.main' }} />
          <Typography variant="h5" fontWeight={600}>Something went wrong</Typography>
          <Typography color="text.secondary" sx={{ maxWidth: 480, textAlign: 'center' }}>
            An unexpected error occurred. Try navigating to another page, or reload.
          </Typography>
          {this.state.error && (
            <Typography variant="body2" sx={{ fontFamily: 'monospace', color: 'error.dark',
              bgcolor: 'grey.100', px: 2, py: 1, borderRadius: 1, maxWidth: 600,
              overflow: 'auto', fontSize: 12 }}>
              {this.state.error.message}
            </Typography>
          )}
          <Button variant="contained" onClick={() => this.setState({ hasError: false, error: null })}>
            Try Again
          </Button>
        </Box>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
