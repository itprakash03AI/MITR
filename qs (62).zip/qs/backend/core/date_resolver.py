"""
Dynamic date expression resolver for query filters.

Supports template expressions embedded in filter values so that saved queries
and scheduled jobs always operate on a *relative* date window without manual
editing.

Syntax  (case-insensitive, inside ${...}):
  ${today}           → today's date             2024-01-15
  ${yesterday}       → today - 1 day            2024-01-14
  ${tomorrow}        → today + 1 day            2024-01-16
  ${weekStart}       → Monday of current week   2024-01-13
  ${monthStart}      → 1st of current month     2024-01-01
  ${monthEnd}        → last day of current month 2024-01-31
  ${yearStart}       → Jan 1 of current year    2024-01-01
  ${yearEnd}         → Dec 31 of current year   2024-12-31
  ${today-7d}        → 7 days ago               2024-01-08
  ${today+30d}       → 30 days from now         2024-02-14
  ${today-1m}        → 1 calendar month ago     2023-12-15
  ${today+1m}        → 1 calendar month from now 2024-02-15
  ${today-1y}        → 1 year ago               2023-01-15
  ${now}             → current UTC datetime     2024-01-15T10:30:00
  ${now-2h}          → 2 hours ago              2024-01-15T08:30:00

All date results are ISO-8601 strings (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS).
Expressions that cannot be parsed are returned unchanged.

Usage:
    from core.date_resolver import resolve_filter_dates

    filters_json = '[{"col":"business_date","op":"equals","val":"${today}"}]'
    resolved = resolve_filter_dates(filters_json)
    # → '[{"col":"business_date","op":"equals","val":"2024-01-15"}]'

    # Or resolve a plain string value:
    from core.date_resolver import resolve_value
    resolve_value("${today-7d}")   # → "2024-01-08"
"""
from __future__ import annotations

import json
import re
import logging
from calendar import monthrange
from datetime import date, datetime, timedelta, timezone
from typing import Any, Union

logger = logging.getLogger(__name__)

# Regex that matches ${...} expressions anywhere in a string
_EXPR_RE = re.compile(r"\$\{([^}]+)\}", re.IGNORECASE)

# Relative-offset pattern: today+7d  today-1m  now-2h
_OFFSET_RE = re.compile(
    r"^(today|now)([+-])(\d+)([dDhHmMwWyY])$", re.IGNORECASE
)


def _today() -> date:
    return datetime.now(timezone.utc).date()


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def _resolve_expr(expr: str) -> str:
    """Resolve a single expression (without the surrounding ${}) to a string."""
    key = expr.strip().lower()

    # ── Absolute keywords ─────────────────────────────────────────────────────
    if key == "today":
        return str(_today())
    if key == "yesterday":
        return str(_today() - timedelta(days=1))
    if key == "tomorrow":
        return str(_today() + timedelta(days=1))
    if key == "now":
        return _now().isoformat()

    t = _today()
    if key == "weekstart":
        return str(t - timedelta(days=t.weekday()))
    if key == "monthstart":
        return str(t.replace(day=1))
    if key == "monthend":
        last_day = monthrange(t.year, t.month)[1]
        return str(t.replace(day=last_day))
    if key == "yearstart":
        return str(t.replace(month=1, day=1))
    if key == "yearend":
        return str(t.replace(month=12, day=31))

    # ── Relative offsets: today±Nd, today±Nm, today±Ny, now±Nh ───────────────
    m = _OFFSET_RE.match(expr.strip())
    if m:
        base_key, op, num_str, unit = m.group(1).lower(), m.group(2), m.group(3), m.group(4).lower()
        num = int(num_str)
        sign = 1 if op == "+" else -1

        if base_key == "now":
            base_dt = _now()
            if unit == "h":
                result_dt = base_dt + timedelta(hours=sign * num)
            elif unit == "m":
                result_dt = base_dt + timedelta(minutes=sign * num)
            elif unit == "d":
                result_dt = base_dt + timedelta(days=sign * num)
            else:
                return f"${{{expr}}}"      # unsupported unit for datetime
            return result_dt.isoformat()

        # base_key == "today"
        base_d = _today()
        if unit == "d":
            return str(base_d + timedelta(days=sign * num))
        if unit == "w":
            return str(base_d + timedelta(weeks=sign * num))
        if unit == "m":
            # Calendar-month arithmetic (clamped to last valid day)
            month = base_d.month + sign * num
            year  = base_d.year + (month - 1) // 12
            month = (month - 1) % 12 + 1
            last_day = monthrange(year, month)[1]
            return str(base_d.replace(year=year, month=month, day=min(base_d.day, last_day)))
        if unit == "y":
            try:
                return str(base_d.replace(year=base_d.year + sign * num))
            except ValueError:
                # Feb 29 → Feb 28 on non-leap years
                return str(base_d.replace(year=base_d.year + sign * num, day=28))

    # Unknown expression — return unchanged so it surfaces in logs/errors
    return f"${{{expr}}}"


def resolve_value(value: Any) -> Any:
    """Replace all ${...} tokens in *value* (string only; other types pass through)."""
    if not isinstance(value, str) or "${" not in value:
        return value
    def _replacer(m: re.Match) -> str:
        try:
            return _resolve_expr(m.group(1))
        except Exception as exc:
            logger.warning("[date_resolver] Failed to resolve '%s': %s", m.group(0), exc)
            return m.group(0)   # keep original on error
    return _EXPR_RE.sub(_replacer, value)


def resolve_filter_list(filters: list) -> list:
    """Walk a filter list (adv_filters conditions or legacy filter dicts) and
    resolve date expressions in 'val'/'value' fields in-place (returns a copy)."""
    if not filters:
        return filters
    resolved = []
    for f in filters:
        if not isinstance(f, dict):
            resolved.append(f)
            continue
        fc = dict(f)
        # adv_filters format: {"col": ..., "op": ..., "val": "..."}
        if "val" in fc:
            fc["val"] = resolve_value(fc["val"])
        # legacy format: {"column": ..., "operator": ..., "value": "..."}
        if "value" in fc:
            fc["value"] = resolve_value(fc["value"])
        resolved.append(fc)
    return resolved


def resolve_adv_filters(adv_filters_json: str | None) -> str | None:
    """Parse adv_filters JSON, resolve date expressions, re-serialise."""
    if not adv_filters_json or "${" not in adv_filters_json:
        return adv_filters_json
    try:
        af = json.loads(adv_filters_json)
        if isinstance(af, dict) and "conditions" in af:
            af["conditions"] = resolve_filter_list(af["conditions"])
        return json.dumps(af)
    except Exception as exc:
        logger.warning("[date_resolver] adv_filters parse error: %s", exc)
        return adv_filters_json


def resolve_filter_dates(obj: Any) -> Any:
    """Recursively resolve date expressions in a query_config-style dict/list.

    Handles:
      - list of legacy filter dicts  (query_config["filters"])
      - adv_filters JSON string
      - any nested dict/list
    """
    if isinstance(obj, str):
        return resolve_value(obj)
    if isinstance(obj, list):
        return [resolve_filter_dates(item) for item in obj]
    if isinstance(obj, dict):
        return {k: resolve_filter_dates(v) for k, v in obj.items()}
    return obj
