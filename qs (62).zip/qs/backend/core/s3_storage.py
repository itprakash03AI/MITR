"""
S3 Storage Handler
Manages S3 connections and file operations for Parquet files
"""

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError, NoCredentialsError
from typing import List, Dict, Any, Optional, Union, Generator
from pathlib import Path
import logging
from dataclasses import dataclass
import pyarrow.parquet as pq
import pyarrow as pa
from io import BytesIO
import tempfile
import urllib3

logger = logging.getLogger(__name__)

# Default CA bundle — place tls_bundle.pem in the certs/ folder next to main.py
_DEFAULT_CA_BUNDLE = Path(__file__).resolve().parent.parent / "certs" / "tls_bundle.pem"

_SSL_HINT = (
    "SSL certificate verification failed. This usually means a corporate proxy is intercepting HTTPS. "
    "To fix: (1) Place your organisation's CA bundle at backend/certs/tls_bundle.pem — it will be picked up automatically, "
    "or (2) set 'SSL Certificate Verification' to 'Disabled' in the connection form."
)


def _is_ssl_error(exc: Exception) -> bool:
    """Return True if the exception (or its cause chain) is an SSL verification failure."""
    msg = str(exc).lower()
    return 'certificate' in msg or 'ssl' in msg or 'cert' in msg


# AWS error codes that mean the session / token has expired
_EXPIRED_TOKEN_CODES = {'ExpiredToken', 'ExpiredTokenException', 'RequestExpired', 'TokenRefreshRequired'}

_TOKEN_EXPIRED_HINT = (
    "Your AWS session token has expired. "
    "Please update your connection credentials with a fresh token "
    "(run `aws sts get-session-token` or `aws sso login` and copy the new values)."
)


class TokenExpiredError(RuntimeError):
    """Raised when AWS temporary credentials (session token) have expired."""
    pass


def _is_expired_token(exc: Exception) -> bool:
    """Return True if a boto3 ClientError signals an expired session token."""
    if hasattr(exc, 'response'):
        code = exc.response.get('Error', {}).get('Code', '')
        if code in _EXPIRED_TOKEN_CODES:
            return True
    msg = str(exc).lower()
    return 'expired' in msg and 'token' in msg


def _check_token_expired(exc: Exception, config: "S3Config" = None):
    """Raise TokenExpiredError only when the user explicitly provided a session token
    (keys auth mode). For iam_role / profile / assume_role the token lifecycle is
    managed by AWS SDK or infra — surfacing a 'please re-enter token' prompt would
    be misleading."""
    if not _is_expired_token(exc):
        return
    if config and config.auth_mode == 'keys' and config.aws_session_token:
        raise TokenExpiredError(_TOKEN_EXPIRED_HINT) from exc
    # For other auth modes, let the original boto3 error propagate as-is


@dataclass
class S3Config:
    """S3 Configuration"""
    bucket_name: str
    region_name: str = "us-east-1"
    # auth_mode: "keys" | "iam_role" | "profile" | "assume_role"
    auth_mode: str = "keys"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None  # for temporary credentials (STS / SSO / sts get-session-token)
    aws_profile: Optional[str] = None        # for SSO / named profile
    role_arn: Optional[str] = None           # for STS AssumeRole
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # for cross-account AssumeRole
    endpoint_url: Optional[str] = None       # for S3-compatible storage (MinIO etc.)
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


def _parse_ssl_verify(val) -> Union[bool, str]:
    """Normalise ssl_verify: 'true'/'false' strings → bool, path strings kept as-is.
    If the value is True (default) and certs/tls_bundle.pem exists, use it automatically."""
    if isinstance(val, bool):
        if val and _DEFAULT_CA_BUNDLE.exists():
            logger.info(f"Using default CA bundle: {_DEFAULT_CA_BUNDLE}")
            return str(_DEFAULT_CA_BUNDLE)
        return val
    if isinstance(val, str):
        if val.lower() == 'false':
            return False
        if val.lower() == 'true':
            # treat as default True — auto-detect bundle
            if _DEFAULT_CA_BUNDLE.exists():
                logger.info(f"Using default CA bundle: {_DEFAULT_CA_BUNDLE}")
                return str(_DEFAULT_CA_BUNDLE)
            return True
        return val  # treat as explicit CA-bundle path
    return True  # safe default


def _strip(val) -> Optional[str]:
    """Strip whitespace from a credential string; return None if empty."""
    if val is None:
        return None
    s = str(val).strip()
    return s if s else None


def build_s3_config(cfg: dict) -> "S3Config":
    """Build an S3Config from a plain config dict (handles all auth modes)."""
    return S3Config(
        bucket_name=(cfg["bucket_name"] or "").strip(),
        region_name=(cfg.get("region_name") or "us-east-1").strip(),
        auth_mode=(cfg.get("auth_mode") or "keys").strip(),
        aws_access_key_id=_strip(cfg.get("aws_access_key_id")),
        aws_secret_access_key=_strip(cfg.get("aws_secret_access_key")),
        aws_session_token=_strip(cfg.get("aws_session_token")),
        aws_profile=_strip(cfg.get("aws_profile")),
        role_arn=_strip(cfg.get("role_arn")),
        role_session_name=_strip(cfg.get("role_session_name")) or "parquet-engine",
        external_id=_strip(cfg.get("external_id")),
        endpoint_url=cfg.get("endpoint_url") or None,
        ssl_verify=_parse_ssl_verify(cfg.get("ssl_verify", True)),
    )


class S3StorageHandler:
    """
    Handles S3 storage operations for Parquet files
    Supports reading from specific folders and file management
    """
    
    def __init__(self, config: S3Config):
        """
        Initialize S3 storage handler
        
        Args:
            config: S3 configuration
        """
        self.config = config
        self.s3_client = None
        self.s3_resource = None
        self._initialize_clients()
    
    def _initialize_clients(self):
        """
        Initialize S3 client using the configured auth mode:
          - 'keys'        : explicit Access Key ID + Secret (long-term credentials)
          - 'iam_role'    : no credentials — uses IAM instance profile / ECS task role /
                            environment variable chain automatically (boto3 default)
          - 'profile'     : named AWS profile from ~/.aws/config, including SSO profiles
                            created via `aws configure sso`
          - 'assume_role' : STS AssumeRole — obtains temporary credentials for a given
                            role ARN; optionally uses a named profile as the source identity
        """
        try:
            mode = (self.config.auth_mode or 'keys').lower()

            if mode == 'profile':
                # Named profile — works for SSO profiles too (after `aws sso login`)
                session = boto3.Session(
                    profile_name=self.config.aws_profile,
                    region_name=self.config.region_name,
                )

            elif mode == 'assume_role':
                # Optionally start from a named profile, then assume the target role
                if not self.config.role_arn:
                    raise ValueError("role_arn is required for auth_mode='assume_role'")
                base_session = boto3.Session(
                    profile_name=self.config.aws_profile,  # None → default chain
                    region_name=self.config.region_name,
                )
                sts = base_session.client('sts', verify=self.config.ssl_verify)
                try:
                    assume_kwargs = {
                        "RoleArn": self.config.role_arn,
                        "RoleSessionName": self.config.role_session_name or "parquet-engine",
                    }
                    if self.config.external_id:
                        assume_kwargs["ExternalId"] = self.config.external_id
                    creds = sts.assume_role(**assume_kwargs)["Credentials"]
                finally:
                    sts.close()
                session = boto3.Session(
                    aws_access_key_id=creds["AccessKeyId"],
                    aws_secret_access_key=creds["SecretAccessKey"],
                    aws_session_token=creds["SessionToken"],
                    region_name=self.config.region_name,
                )

            elif mode == 'iam_role':
                # Pure default credential chain — IAM instance profile, ECS task role,
                # environment vars (AWS_ACCESS_KEY_ID etc.), or ~/.aws/credentials default
                session = boto3.Session(region_name=self.config.region_name)

            else:  # 'keys' (default)
                session_kwargs = {"region_name": self.config.region_name}
                if self.config.aws_access_key_id and self.config.aws_secret_access_key:
                    session_kwargs["aws_access_key_id"] = self.config.aws_access_key_id
                    session_kwargs["aws_secret_access_key"] = self.config.aws_secret_access_key
                    if self.config.aws_session_token:
                        session_kwargs["aws_session_token"] = self.config.aws_session_token
                session = boto3.Session(**session_kwargs)

            client_kwargs = {}
            if self.config.endpoint_url:
                client_kwargs["endpoint_url"] = self.config.endpoint_url
            # SSL — False skips verification (useful when corporate proxy intercepts TLS)
            # or supply a path to your org's CA bundle PEM file
            client_kwargs["verify"] = self.config.ssl_verify
            if self.config.ssl_verify is False:
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Adaptive retry with exponential backoff for S3 throttling (503 SlowDown)
            boto_config = BotoConfig(
                retries={"max_attempts": 5, "mode": "adaptive"},
                connect_timeout=10,
                read_timeout=30,
                max_pool_connections=25,   # urllib3 pool per host (default 10)
            )
            self.s3_client = session.client('s3', config=boto_config, **client_kwargs)

            logger.info(f"S3 client created (mode={mode}) for bucket: {self.config.bucket_name}")

        except NoCredentialsError:
            logger.error("AWS credentials not found")
            raise
        except Exception as e:
            if _is_ssl_error(e):
                raise RuntimeError(_SSL_HINT) from e
            logger.error(f"Failed to create S3 client: {e}", exc_info=True)
            raise
    
    def list_folders(self, prefix: str = "") -> List[Dict[str, Any]]:
        """
        List all folders in the S3 bucket
        
        Args:
            prefix: Prefix to filter folders
            
        Returns:
            List of folder information
        """
        try:
            folders = []
            paginator = self.s3_client.get_paginator('list_objects_v2')
            
            # Use delimiter to get folder structure
            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=prefix,
                Delimiter='/'
            )
            
            for page in pages:
                # CommonPrefixes contains the "folders"
                for prefix_obj in page.get('CommonPrefixes', []):
                    folder_path = prefix_obj['Prefix']
                    folders.append({
                        'path': folder_path,
                        'name': folder_path.rstrip('/').split('/')[-1],
                        'type': 'folder'
                    })
            
            logger.info(f"Found {len(folders)} folders with prefix '{prefix}'")
            return folders
            
        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error listing folders: {e}", exc_info=True)
            raise
    
    def list_parquet_files(self, folder_path: str = "") -> List[Dict[str, Any]]:
        """
        List parquet files and subfolders at ONE level using Delimiter='/'.
        This avoids scanning the entire bucket recursively — only the immediate
        children of *folder_path* are returned.  Subfolders are returned as
        entries with  type='folder'  so the frontend can lazy-load them on click.
        """
        try:
            items: List[Dict[str, Any]] = []
            paginator = self.s3_client.get_paginator('list_objects_v2')

            pages = paginator.paginate(
                Bucket=self.config.bucket_name,
                Prefix=folder_path,
                Delimiter='/',
            )

            for page in pages:
                # Sub-folders at this level
                for prefix_obj in page.get('CommonPrefixes', []):
                    fp = prefix_obj['Prefix']
                    items.append({
                        'key': fp,
                        'path': fp,
                        'name': fp.rstrip('/').split('/')[-1],
                        'folder': folder_path,  # keep as-is — empty string for root
                        'type': 'folder',
                    })

                # Files at this level (.parquet, .csv, .txt)
                _QUERYABLE_EXTS = ('.parquet', '.csv', '.txt')
                for obj in page.get('Contents', []):
                    key = obj['Key']
                    # Skip the prefix itself (shows up as a 0-byte "key")
                    if key == folder_path:
                        continue
                    if any(key.lower().endswith(ext) for ext in _QUERYABLE_EXTS):
                        items.append({
                            'key': key,
                            'path': f"s3://{self.config.bucket_name}/{key}",
                            'name': key.split('/')[-1],
                            'size_bytes': obj['Size'],
                            'last_modified': obj['LastModified'].isoformat(),
                            'folder': folder_path,  # keep as-is — matches parent folder key
                            'storage_class': obj.get('StorageClass', 'STANDARD'),
                            'etag': obj.get('ETag', '').strip('"'),
                        })

            logger.info(f"Listed {len(items)} items at prefix '{folder_path}'")
            return items

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error listing files: {e}", exc_info=True)
            raise
    
    def get_file_schema(self, s3_key: str) -> Dict[str, Any]:
        """
        Get schema information for a parquet file in S3
        
        Args:
            s3_key: S3 key of the parquet file
            
        Returns:
            Schema information dictionary
        """
        try:
            # Read only the Parquet footer (last 8 bytes = magic + footer length,
            # then the actual footer) instead of downloading the entire file.
            head = self.s3_client.head_object(Bucket=self.config.bucket_name, Key=s3_key)
            file_size = head['ContentLength']

            # Read last 8 bytes to get footer length
            range_end = file_size - 1
            range_start = max(0, file_size - 8)
            tail_resp = self.s3_client.get_object(
                Bucket=self.config.bucket_name, Key=s3_key,
                Range=f"bytes={range_start}-{range_end}"
            )
            tail = tail_resp['Body'].read()
            tail_resp['Body'].close()

            import struct
            footer_len = struct.unpack('<I', tail[:4])[0]

            # Read footer + the 8-byte trailer
            footer_start = max(0, file_size - footer_len - 8)
            footer_resp = self.s3_client.get_object(
                Bucket=self.config.bucket_name, Key=s3_key,
                Range=f"bytes={footer_start}-{range_end}"
            )
            footer_bytes = footer_resp['Body'].read()
            footer_resp['Body'].close()

            # PyArrow can read metadata from footer bytes
            buffer = BytesIO(footer_bytes)
            metadata = pq.read_metadata(buffer)
            schema = pq.read_schema(BytesIO(footer_bytes))

            return {
                'file': s3_key,
                'bucket': self.config.bucket_name,
                'columns': [
                    {
                        'name': field.name,
                        'type': str(field.type),
                        'nullable': field.nullable
                    }
                    for field in schema
                ],
                'num_rows': metadata.num_rows,
                'num_row_groups': metadata.num_row_groups,
                'size_bytes': file_size,
            }

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error getting schema for {s3_key}: {e}", exc_info=True)
            raise
        except Exception:
            # Fallback: if footer-only read fails (e.g. encrypted parquet), try full download
            try:
                obj = self.s3_client.get_object(Bucket=self.config.bucket_name, Key=s3_key)
                body = obj['Body']
                try:
                    buffer = BytesIO(body.read())
                finally:
                    body.close()
                parquet_file = pq.ParquetFile(buffer)
                schema = parquet_file.schema_arrow
                metadata = parquet_file.metadata
                return {
                    'file': s3_key, 'bucket': self.config.bucket_name,
                    'columns': [{'name': f.name, 'type': str(f.type), 'nullable': f.nullable} for f in schema],
                    'num_rows': metadata.num_rows, 'num_row_groups': metadata.num_row_groups,
                    'size_bytes': obj['ContentLength'],
                }
            except ClientError as e2:
                _check_token_expired(e2, self.config)
                raise
    
    def read_parquet_chunked(self, s3_key: str, chunk_size: int = 100000,
                            columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file from S3 in chunks for memory efficiency
        
        Args:
            s3_key: S3 key of the parquet file
            chunk_size: Number of rows per chunk
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        try:
            # Download to temporary file for efficient chunked reading
            with tempfile.NamedTemporaryFile(delete=True, suffix='.parquet') as tmp_file:
                logger.info(f"Downloading {s3_key} to temporary file...")
                
                self.s3_client.download_fileobj(
                    self.config.bucket_name,
                    s3_key,
                    tmp_file
                )
                
                tmp_file.flush()
                tmp_file.seek(0)
                
                # Read in chunks
                parquet_file = pq.ParquetFile(tmp_file.name)
                
                for batch in parquet_file.iter_batches(batch_size=chunk_size, columns=columns):
                    yield pa.Table.from_batches([batch])
                    
        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error reading file {s3_key}: {e}", exc_info=True)
            raise
    
    def read_parquet(self, s3_key: str, columns: Optional[List[str]] = None) -> pa.Table:
        """
        Read entire parquet file from S3 into memory
        
        Args:
            s3_key: S3 key of the parquet file
            columns: Optional list of columns to read
            
        Returns:
            PyArrow table
        """
        try:
            obj = self.s3_client.get_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )

            body = obj['Body']
            try:
                buffer = BytesIO(body.read())
            finally:
                body.close()
            table = pq.read_table(buffer, columns=columns)

            logger.info(f"Read {len(table)} rows from {s3_key}")
            return table

        except ClientError as e:
            _check_token_expired(e, self.config)
            logger.error(f"Error reading file {s3_key}: {e}", exc_info=True)
            raise
    
    def upload_file(self, local_path: str, s3_key: str) -> Dict[str, Any]:
        """
        Upload a file to S3
        
        Args:
            local_path: Local file path
            s3_key: S3 key for the uploaded file
            
        Returns:
            Upload information
        """
        try:
            self.s3_client.upload_file(
                local_path,
                self.config.bucket_name,
                s3_key
            )
            
            # Get file info
            head = self.s3_client.head_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Uploaded file to s3://{self.config.bucket_name}/{s3_key}")
            
            return {
                'bucket': self.config.bucket_name,
                'key': s3_key,
                'size_bytes': head['ContentLength'],
                'etag': head['ETag'].strip('"')
            }
            
        except ClientError as e:
            logger.error(f"Error uploading file: {e}", exc_info=True)
            raise
    
    def delete_file(self, s3_key: str) -> bool:
        """
        Delete a file from S3
        
        Args:
            s3_key: S3 key of the file to delete
            
        Returns:
            True if successful
        """
        try:
            self.s3_client.delete_object(
                Bucket=self.config.bucket_name,
                Key=s3_key
            )
            
            logger.info(f"Deleted file: s3://{self.config.bucket_name}/{s3_key}")
            return True
            
        except ClientError as e:
            logger.error(f"Error deleting file: {e}", exc_info=True)
            raise
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test S3 connection and return bucket info.
        Tries head_bucket first; falls back to list_objects_v2 if 403
        (common when IAM policy lacks s3:HeadBucket but grants s3:ListBucket).
        Returns actionable error messages for common credential/bucket problems.
        """
        bucket = self.config.bucket_name

        def _parse_error(e: ClientError) -> Dict[str, Any]:
            code = e.response.get('Error', {}).get('Code', '')
            msg = e.response.get('Error', {}).get('Message', str(e))
            # Only surface the "update your token" prompt when the user explicitly
            # provided a session token via keys auth mode.
            if _is_expired_token(e) and self.config.auth_mode == 'keys' and self.config.aws_session_token:
                return {'connected': False, 'error': _TOKEN_EXPIRED_HINT, 'error_code': 'TOKEN_EXPIRED'}
            if code == 'InvalidAccessKeyId':
                return {'connected': False, 'error': 'Invalid Access Key ID. Common causes: (1) extra whitespace when copy-pasting — try re-entering the key manually, (2) key was deleted or deactivated in AWS IAM, (3) wrong AWS partition (e.g., GovCloud key used against standard endpoint). If using temporary credentials (SSO/STS), ensure the session token is also provided and has not expired.'}
            if code == 'SignatureDoesNotMatch':
                return {'connected': False, 'error': 'Invalid Secret Access Key. The signature does not match — verify the secret key.'}
            if code in ('NoSuchBucket', '404'):
                return {'connected': False, 'error': f"Bucket '{bucket}' does not exist. Check the bucket name and region."}
            if code == 'PermanentRedirect':
                return {'connected': False, 'error': f"Bucket '{bucket}' is in a different region. Update the region field to match the bucket's actual region."}
            if code == 'AuthorizationHeaderMalformed':
                return {'connected': False, 'error': f"Wrong region specified. Update the region field to the bucket's actual region."}
            if code in ('403', 'AccessDenied'):
                return None  # caller will try fallback
            return {'connected': False, 'error': f"[{code}] {msg}"}

        # --- Attempt 1: head_bucket ---
        try:
            self.s3_client.head_bucket(Bucket=bucket)
            # If head_bucket succeeds we know bucket exists and creds are valid.
            # Get region via get_bucket_location (best-effort).
            try:
                loc = self.s3_client.get_bucket_location(Bucket=bucket)
                region = loc.get('LocationConstraint') or 'us-east-1'
            except ClientError:
                region = self.config.region_name or 'us-east-1'
            logger.info(f"S3 connection OK (head_bucket) — bucket={bucket} region={region}")
            return {'connected': True, 'bucket': bucket, 'region': region, 'accessible': True}

        except ClientError as e:
            parsed = _parse_error(e)
            if parsed is not None:
                logger.error(f"S3 connection test failed: {parsed['error']}")
                return parsed
            # 403 / AccessDenied — credentials may still be valid, try list fallback

        except Exception as e:
            if _is_ssl_error(e):
                logger.error(f"S3 SSL error: {e}", exc_info=True)
                return {'connected': False, 'error': _SSL_HINT}
            logger.error(f"S3 connection test error: {e}", exc_info=True)
            return {'connected': False, 'error': str(e)}

        # --- Attempt 2: list_objects_v2 fallback (covers restricted IAM policies) ---
        try:
            self.s3_client.list_objects_v2(Bucket=bucket, MaxKeys=1)
            try:
                loc = self.s3_client.get_bucket_location(Bucket=bucket)
                region = loc.get('LocationConstraint') or 'us-east-1'
            except ClientError:
                region = self.config.region_name or 'us-east-1'
            logger.info(f"S3 connection OK (list fallback) — bucket={bucket} region={region}")
            return {'connected': True, 'bucket': bucket, 'region': region, 'accessible': True,
                    'note': 'Connected (limited permissions — HeadBucket not allowed)'}

        except ClientError as e:
            parsed = _parse_error(e)
            if parsed is not None:
                logger.error(f"S3 connection test failed: {parsed['error']}")
                return parsed
            # Still 403 after both attempts — bucket exists but no list permission
            logger.warning(f"S3 bucket '{bucket}' accessible but no list permission")
            return {
                'connected': True,
                'bucket': bucket,
                'region': self.config.region_name or 'us-east-1',
                'accessible': True,
                'note': 'Credentials valid but s3:ListBucket permission not granted. Object-level operations may still work.'
            }

        except Exception as e:
            if _is_ssl_error(e):
                logger.error(f"S3 SSL error (fallback): {e}", exc_info=True)
                return {'connected': False, 'error': _SSL_HINT}
            logger.error(f"S3 connection test error (fallback): {e}", exc_info=True)
            return {'connected': False, 'error': str(e)}
    
    def get_folder_tree(self, max_depth: int = 3) -> List[Dict[str, Any]]:
        """
        Get hierarchical folder structure
        
        Args:
            max_depth: Maximum depth to traverse
            
        Returns:
            Hierarchical folder structure
        """
        def get_subfolders(prefix: str, depth: int) -> List[Dict[str, Any]]:
            if depth >= max_depth:
                return []
            
            folders = self.list_folders(prefix)
            result = []
            
            for folder in folders:
                folder_data = {
                    'path': folder['path'],
                    'name': folder['name'],
                    'type': 'folder',
                    'children': get_subfolders(folder['path'], depth + 1)
                }
                result.append(folder_data)
            
            return result
        
        return get_subfolders('', 0)
