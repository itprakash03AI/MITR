import threading
import time
from typing import Any, Optional


class TTLCache:
    """Thread-safe TTL cache with maximum entry limit and proactive eviction."""

    def __init__(self, ttl_seconds: int = 300, max_entries: int = 1000):
        self._cache = {}
        self._lock = threading.Lock()
        self._ttl = ttl_seconds
        self._max_entries = max_entries

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._cache.get(key)
            if entry and time.time() - entry['time'] < self._ttl:
                return entry['value']
            elif entry:
                del self._cache[key]
            return None

    def set(self, key: str, value: Any):
        with self._lock:
            now = time.time()
            # Evict expired entries if approaching limit
            if len(self._cache) >= self._max_entries:
                expired = [k for k, v in self._cache.items() if now - v['time'] >= self._ttl]
                for k in expired:
                    del self._cache[k]
            # If still at limit, evict oldest entry
            if len(self._cache) >= self._max_entries:
                oldest_key = min(self._cache, key=lambda k: self._cache[k]['time'])
                del self._cache[oldest_key]
            self._cache[key] = {'value': value, 'time': now}

    def invalidate(self, key: str = None):
        with self._lock:
            if key:
                self._cache.pop(key, None)
            else:
                self._cache.clear()

    def cleanup_expired(self):
        """Remove all expired entries. Call periodically (e.g. via scheduler)."""
        with self._lock:
            now = time.time()
            expired = [k for k, v in self._cache.items() if now - v['time'] >= self._ttl]
            for k in expired:
                del self._cache[k]
            return len(expired)

    @property
    def size(self) -> int:
        return len(self._cache)


# Global caches
schema_cache = TTLCache(ttl_seconds=300, max_entries=500)     # 5 min for schemas
file_list_cache = TTLCache(ttl_seconds=120, max_entries=200)  # 2 min for file listings
