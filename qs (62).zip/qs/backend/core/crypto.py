"""
Credential encryption for Query Studio connection configs.

Sensitive fields (passwords, tokens, private keys) are encrypted at rest using
Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).

Key resolution order:
  1. QUERY_STUDIO_SECRET_KEY environment variable (base64url-encoded Fernet key)
  2. Auto-generated ephemeral key (for development — not persistent across restarts)

For production / OpenShift deployments, set QUERY_STUDIO_SECRET_KEY as a secret env var.
To generate a valid key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict

logger = logging.getLogger(__name__)

# Prefix that marks an already-encrypted value — allows idempotent encrypt/decrypt
_ENC_PREFIX = "enc::"

# Config field names that contain credentials and must be encrypted at rest
SENSITIVE_FIELDS: frozenset[str] = frozenset([
    "password",
    "token",
    "access_token",
    "aws_secret_access_key",
    "private_key",
    "private_key_passphrase",
    "wallet_password",       # Oracle Autonomous DB wallet password
])

_fernet = None        # module-level singleton, initialized lazily
_CRYPTO_AVAILABLE = None  # tri-state: None=unknown, True/False after first check


def _check_crypto() -> bool:
    global _CRYPTO_AVAILABLE
    if _CRYPTO_AVAILABLE is None:
        try:
            import cryptography  # noqa: F401
            _CRYPTO_AVAILABLE = True
        except ImportError:
            _CRYPTO_AVAILABLE = False
            logger.warning(
                "cryptography package is not installed — credential encryption is disabled. "
                "Install it with: pip install cryptography>=42.0.0"
            )
    return _CRYPTO_AVAILABLE


def _build_fernet():
    if not _check_crypto():
        return None

    from cryptography.fernet import Fernet
    from pathlib import Path

    # ── 1. Explicit env var (highest priority) ────────────────────────────────
    key = os.environ.get("QUERY_STUDIO_SECRET_KEY", "").strip()
    if key:
        try:
            return Fernet(key.encode() if isinstance(key, str) else key)
        except Exception as e:
            logger.error("QUERY_STUDIO_SECRET_KEY is invalid: %s. Falling back to key file.", e)

    # ── 2. Persistent key file — survives restarts without env var config ─────
    # Path driven by config.json (paths.secret_key_file), defaults to data/secret.key
    try:
        from core.config import paths as _cfg_paths
        _key_file = _cfg_paths.secret_key_file
    except Exception:
        _key_file = Path(__file__).resolve().parent.parent / "data" / "secret.key"
    try:
        _key_file.parent.mkdir(parents=True, exist_ok=True)
        if _key_file.exists():
            stored = _key_file.read_text().strip()
            try:
                f = Fernet(stored.encode())
                logger.info("Loaded persistent encryption key from %s", _key_file)
                return f
            except Exception:
                logger.warning("Key file %s is invalid — regenerating.", _key_file)

        # Generate and persist a new key
        new_key = Fernet.generate_key().decode()
        _key_file.write_text(new_key)
        logger.warning(
            "QUERY_STUDIO_SECRET_KEY not set — generated a persistent encryption key at %s. "
            "Credentials are encrypted at rest and will survive restarts. "
            "For multi-server deployments set QUERY_STUDIO_SECRET_KEY instead.",
            _key_file,
        )
        return Fernet(new_key.encode())
    except Exception as e:
        # Filesystem issue (e.g. read-only share) — fall back to ephemeral key
        logger.error(
            "Could not read/write key file %s (%s) — using ephemeral key. "
            "Credentials will NOT survive a restart. Set QUERY_STUDIO_SECRET_KEY to fix this.",
            _key_file, e,
        )
        new_key = Fernet.generate_key().decode()
        os.environ["QUERY_STUDIO_SECRET_KEY"] = new_key
        return Fernet(new_key.encode())


def _get_fernet():
    global _fernet
    if _fernet is None:
        _fernet = _build_fernet()
    return _fernet


# ── Public API ─────────────────────────────────────────────────────────────────

def encrypt_value(plaintext: str) -> str:
    """Encrypt a single string value.  Returns ``enc::<base64token>``.
    If cryptography is not installed, returns the plaintext unchanged (with a log warning)."""
    if not plaintext:
        return plaintext
    if plaintext.startswith(_ENC_PREFIX):
        return plaintext  # already encrypted — idempotent
    fernet = _get_fernet()
    if fernet is None:
        return plaintext  # cryptography unavailable — store as plaintext
    token = fernet.encrypt(plaintext.encode()).decode()
    return f"{_ENC_PREFIX}{token}"


def decrypt_value(value: str) -> str:
    """Decrypt a single encrypted value.  Pass-through for unencrypted strings."""
    if not value or not value.startswith(_ENC_PREFIX):
        return value
    fernet = _get_fernet()
    if fernet is None:
        logger.warning("Cannot decrypt enc:: value — cryptography package not installed.")
        return value  # return as-is; connection will fail at connect time
    token = value[len(_ENC_PREFIX):]
    try:
        return fernet.decrypt(token.encode()).decode()
    except Exception:
        logger.error(
            "Credential decryption failed — key mismatch or corrupted value. "
            "Check QUERY_STUDIO_SECRET_KEY."
        )
        return ""  # return empty rather than crash; callers will fail at connect time


def encrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields encrypted."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        val = result.get(field)
        if val and isinstance(val, str):
            result[field] = encrypt_value(val)
    return result


def decrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields decrypted."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        val = result.get(field)
        if val and isinstance(val, str):
            result[field] = decrypt_value(val)
    return result


def mask_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with sensitive fields replaced by ``"***"``.
    Safe to return to API clients / browser."""
    if not config:
        return config
    result = dict(config)
    for field in SENSITIVE_FIELDS:
        if result.get(field):
            result[field] = "***"
    return result
