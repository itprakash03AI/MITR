"""
Unified Priority Worker Pool for QueryStudio.

Replaces 7 separate thread pools with a single shared pool,
per-type concurrency limits, timeout enforcement, cancellation,
and unified monitoring.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import threading
import time
import uuid
from collections import deque
from concurrent.futures import ThreadPoolExecutor, Future
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Work types (lower value = higher priority) ────────────────────────────

class WorkType(IntEnum):
    INTERACTIVE = 0   # User queries (parquet, SQL, cross-source)
    REPORT      = 1   # Manual report executions
    SCHEDULED   = 2   # APScheduler-triggered jobs
    EXPORT      = 3   # CSV/XLSX/JSON format conversions
    SYSTEM      = 4   # Schema reads, file listing, cleanup, validation


# ── Task record ───────────────────────────────────────────────────────────

@dataclass
class TaskRecord:
    """Tracks a single unit of work through its lifecycle."""
    task_id: str
    work_type: WorkType
    execution_id: Optional[str]
    username: str
    status: str                    # queued | running | completed | failed | cancelled | timeout
    cancel_event: threading.Event
    future: Optional[Future] = None
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    _timeout_timer: Optional[threading.Timer] = field(default=None, repr=False)

    @property
    def wait_ms(self) -> Optional[float]:
        if self.started_at is not None:
            return (self.started_at - self.created_at) * 1000
        return None

    @property
    def run_ms(self) -> Optional[float]:
        if self.completed_at is not None and self.started_at is not None:
            return (self.completed_at - self.started_at) * 1000
        return None

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "work_type": self.work_type.name,
            "execution_id": self.execution_id,
            "username": self.username,
            "status": self.status,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "wait_ms": self.wait_ms,
            "run_ms": self.run_ms,
            "error": self.error,
            "metadata": self.metadata,
        }


class QueueFullError(Exception):
    """Raised when the per-type queue is at capacity."""
    pass


# ── Per-type configuration ────────────────────────────────────────────────

@dataclass
class TypeConfig:
    max_concurrent: int
    default_timeout: int   # seconds
    max_queue: int


DEFAULT_TYPE_CONFIGS: Dict[WorkType, TypeConfig] = {
    WorkType.INTERACTIVE: TypeConfig(30, 1800, 100),
    WorkType.REPORT:      TypeConfig(10, 3600,  20),
    WorkType.SCHEDULED:   TypeConfig(5,  7200,  50),
    WorkType.EXPORT:      TypeConfig(8,   900,  30),
    WorkType.SYSTEM:      TypeConfig(10,  300,  50),
}


# ── Worker Pool ───────────────────────────────────────────────────────────

class WorkerPool:
    """
    Unified thread pool with per-type concurrency control, timeout
    enforcement, cancellation, and monitoring.

    Usage (async — FastAPI handlers):
        record = await pool.submit(WorkType.INTERACTIVE, blocking_fn, arg1,
                                   execution_id="abc", username="user1")
        result = await asyncio.wrap_future(record.future)

    Usage (sync — APScheduler threads):
        record = pool.submit_sync(WorkType.SCHEDULED, blocking_fn, arg1)
        result = record.future.result(timeout=7200)
    """

    def __init__(
        self,
        total_workers: int = 40,
        type_configs: Optional[Dict[WorkType, TypeConfig]] = None,
        drain_timeout: float = 15.0,
        history_size: int = 500,
    ):
        self._total_workers = total_workers
        self._drain_timeout = drain_timeout
        self._executor = ThreadPoolExecutor(
            max_workers=total_workers,
            thread_name_prefix="wp",
        )
        self._type_cfgs = type_configs or dict(DEFAULT_TYPE_CONFIGS)

        # Concurrency control: counter + Condition (hot-resizable, unlike Semaphore)
        self._slot_lock = threading.Condition(threading.Lock())
        self._running_counts: Dict[WorkType, int] = {wt: 0 for wt in WorkType}

        # Task tracking
        self._lock = threading.Lock()
        self._tasks: Dict[str, TaskRecord] = {}        # task_id  → record
        self._exec_index: Dict[str, str] = {}           # execution_id → task_id
        self._queue_counts: Dict[WorkType, int] = {wt: 0 for wt in WorkType}

        # History ring buffer
        self._history: deque = deque(maxlen=history_size)

        # Stats accumulators (per work type)
        self._stats: Dict[WorkType, Dict[str, Any]] = {
            wt: {
                "submitted": 0, "completed": 0, "failed": 0,
                "cancelled": 0, "timeout": 0,
                "total_wait_ms": 0.0, "total_run_ms": 0.0,
            }
            for wt in WorkType
        }
        self._shutting_down = False

        logger.info(
            "WorkerPool started: %d workers, limits=%s",
            total_workers,
            {wt.name: cfg.max_concurrent for wt, cfg in self._type_cfgs.items()},
        )

    # ── Public properties ─────────────────────────────────────────────────

    @property
    def executor(self) -> ThreadPoolExecutor:
        """Expose the underlying executor for direct run_in_executor() calls."""
        return self._executor

    # ── Async submission (FastAPI handlers) ───────────────────────────────

    async def submit(
        self,
        work_type: WorkType,
        fn: Callable,
        *args,
        execution_id: Optional[str] = None,
        username: str = "system",
        timeout_seconds: Optional[int] = None,
        metadata: Optional[dict] = None,
        **kwargs,
    ) -> TaskRecord:
        """
        Submit work from an async context.

        Waits for a per-type semaphore slot (non-blocking to event loop),
        then submits the blocking function to the shared executor.

        If the function accepts a ``cancel_event`` keyword argument, the
        pool injects the task's cancel event automatically.

        Raises QueueFullError if the per-type queue is at capacity.
        """
        if self._shutting_down:
            raise RuntimeError("WorkerPool is shutting down")

        record = self._create_record(work_type, execution_id, username, metadata)
        cfg = self._type_cfgs[work_type]

        # Queue limit check — release lock before calling _fail_record to avoid deadlock
        with self._lock:
            if self._queue_counts[work_type] >= cfg.max_queue:
                _queue_full = True
            else:
                _queue_full = False
                self._queue_counts[work_type] += 1

        if _queue_full:
            self._fail_record(record, f"{work_type.name} queue full ({cfg.max_queue})")
            raise QueueFullError(record.error)

        # Wait for a concurrency slot (run blocking wait in default executor)
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, self._acquire_slot, work_type)
        except Exception:
            with self._lock:
                self._queue_counts[work_type] = max(0, self._queue_counts[work_type] - 1)
                self._remove_record(record)
            raise

        # Slot acquired — task is moving from queued to running
        with self._lock:
            self._queue_counts[work_type] = max(0, self._queue_counts[work_type] - 1)

        # Submit to executor
        timeout = timeout_seconds if timeout_seconds is not None else cfg.default_timeout
        self._start_task(record, fn, args, kwargs, timeout)
        return record

    # ── Sync submission (APScheduler threads) ─────────────────────────────

    def submit_sync(
        self,
        work_type: WorkType,
        fn: Callable,
        *args,
        execution_id: Optional[str] = None,
        username: str = "system",
        timeout_seconds: Optional[int] = None,
        metadata: Optional[dict] = None,
        **kwargs,
    ) -> TaskRecord:
        """
        Submit work from a synchronous context.
        Blocks until a per-type semaphore slot is available.
        """
        if self._shutting_down:
            raise RuntimeError("WorkerPool is shutting down")

        record = self._create_record(work_type, execution_id, username, metadata)
        cfg = self._type_cfgs[work_type]

        with self._lock:
            if self._queue_counts[work_type] >= cfg.max_queue:
                _queue_full = True
            else:
                _queue_full = False
                self._queue_counts[work_type] += 1

        if _queue_full:
            self._fail_record(record, f"{work_type.name} queue full ({cfg.max_queue})")
            raise QueueFullError(record.error)

        try:
            self._acquire_slot(work_type)
        except Exception:
            with self._lock:
                self._queue_counts[work_type] -= 1
                self._remove_record(record)
            raise

        with self._lock:
            self._queue_counts[work_type] = max(0, self._queue_counts[work_type] - 1)

        timeout = timeout_seconds if timeout_seconds is not None else cfg.default_timeout
        self._start_task(record, fn, args, kwargs, timeout)
        return record

    # ── Slot management (counter-based, hot-resizable) ─────────────────

    def _acquire_slot(self, work_type: WorkType):
        """Block until a concurrency slot is available for this work type."""
        with self._slot_lock:
            while self._running_counts[work_type] >= self._type_cfgs[work_type].max_concurrent:
                self._slot_lock.wait()
            self._running_counts[work_type] += 1

    def _release_slot(self, work_type: WorkType):
        """Release a concurrency slot, waking any queued waiters."""
        with self._slot_lock:
            self._running_counts[work_type] = max(0, self._running_counts[work_type] - 1)
            self._slot_lock.notify_all()

    # ── Hot reconfiguration ──────────────────────────────────────────

    def reconfigure(self, type_configs: Dict[WorkType, TypeConfig]) -> dict:
        """
        Update per-type limits at runtime. Running tasks are NOT affected —
        new limits apply to the next submission.

        Returns a summary of what changed.
        """
        changes = {}
        with self._slot_lock:
            for wt, new_cfg in type_configs.items():
                old_cfg = self._type_cfgs.get(wt)
                if not old_cfg:
                    continue
                diffs = {}
                if new_cfg.max_concurrent != old_cfg.max_concurrent:
                    diffs["max_concurrent"] = {"old": old_cfg.max_concurrent, "new": new_cfg.max_concurrent}
                if new_cfg.default_timeout != old_cfg.default_timeout:
                    diffs["default_timeout"] = {"old": old_cfg.default_timeout, "new": new_cfg.default_timeout}
                if new_cfg.max_queue != old_cfg.max_queue:
                    diffs["max_queue"] = {"old": old_cfg.max_queue, "new": new_cfg.max_queue}
                if diffs:
                    self._type_cfgs[wt] = new_cfg
                    changes[wt.name] = diffs
            # Wake all waiters so they re-check against new limits
            self._slot_lock.notify_all()

        if changes:
            logger.info("WorkerPool reconfigured: %s", changes)
        return changes

    def get_config(self) -> dict:
        """Return current per-type configuration."""
        return {
            "total_workers": self._total_workers,
            "drain_timeout_seconds": self._drain_timeout,
            "types": {
                wt.name: {
                    "max_concurrent": cfg.max_concurrent,
                    "default_timeout": cfg.default_timeout,
                    "max_queue": cfg.max_queue,
                }
                for wt, cfg in self._type_cfgs.items()
            },
        }

    # ── Internal helpers ──────────────────────────────────────────────────

    def _create_record(
        self, work_type: WorkType, execution_id: Optional[str],
        username: str, metadata: Optional[dict],
    ) -> TaskRecord:
        record = TaskRecord(
            task_id=str(uuid.uuid4()),
            work_type=work_type,
            execution_id=execution_id,
            username=username,
            status="queued",
            cancel_event=threading.Event(),
            metadata=metadata or {},
        )
        with self._lock:
            self._tasks[record.task_id] = record
            if execution_id:
                self._exec_index[execution_id] = record.task_id
            self._stats[work_type]["submitted"] += 1
        return record

    def _fail_record(self, record: TaskRecord, error: str):
        """Mark a record as failed before it even runs (e.g. queue full)."""
        record.status = "failed"
        record.error = error
        record.completed_at = time.time()
        with self._lock:
            self._stats[record.work_type]["failed"] += 1
            self._remove_record(record)
            self._history.append(record)

    def _remove_record(self, record: TaskRecord):
        """Remove record from active tracking (caller must hold self._lock)."""
        self._tasks.pop(record.task_id, None)
        if record.execution_id:
            self._exec_index.pop(record.execution_id, None)

    def _start_task(
        self, record: TaskRecord, fn: Callable,
        args: tuple, kwargs: dict, timeout_seconds: int,
    ):
        record.status = "running"
        record.started_at = time.time()

        # Check if fn accepts cancel_event kwarg
        _inject_cancel = _accepts_kwarg(fn, "cancel_event")

        def _wrapped():
            try:
                if record.cancel_event.is_set():
                    raise InterruptedError("Cancelled before start")
                if _inject_cancel:
                    return fn(*args, cancel_event=record.cancel_event, **kwargs)
                return fn(*args, **kwargs)
            except BaseException as _exc:
                logger.error(
                    "Worker task %s (%s, exec=%s) failed: %s",
                    record.task_id, record.work_type.name,
                    record.execution_id, _exc, exc_info=True,
                )
                raise
            finally:
                record.completed_at = time.time()

        # Set up timeout watchdog BEFORE submitting so _on_complete can cancel it
        # even if the task completes instantly during add_done_callback.
        if timeout_seconds and timeout_seconds > 0:
            timer = threading.Timer(timeout_seconds, self._on_timeout, args=(record,))
            timer.daemon = True
            timer.start()
            record._timeout_timer = timer

        record.future = self._executor.submit(_wrapped)
        record.future.add_done_callback(lambda _: self._on_complete(record))

    def _on_complete(self, record: TaskRecord):
        """Called (in the worker thread) when the future finishes."""
        with self._lock:
            # Cancel timeout timer
            if record._timeout_timer:
                record._timeout_timer.cancel()
                record._timeout_timer = None

            # Determine final status (don't overwrite if already set by cancel/timeout)
            if record.status not in ("cancelled", "timeout"):
                if record.future and record.future.cancelled():
                    record.status = "cancelled"
                elif record.future:
                    exc = record.future.exception()
                    if exc:
                        if isinstance(exc, InterruptedError) or record.cancel_event.is_set():
                            record.status = "cancelled"
                        else:
                            record.status = "failed"
                            record.error = str(exc)
                            logger.error(
                                "Task %s (%s, exec=%s) completed with error: %s",
                                record.task_id, record.work_type.name,
                                record.execution_id, exc,
                            )
                    else:
                        record.status = "completed"

            if not record.completed_at:
                record.completed_at = time.time()

        # Release concurrency slot (uses its own _slot_lock, not _lock)
        self._release_slot(record.work_type)

        # Update stats and move to history
        with self._lock:
            st = self._stats[record.work_type]
            status_key = record.status if record.status in st else "failed"
            st[status_key] += 1
            if record.wait_ms is not None:
                st["total_wait_ms"] += record.wait_ms
            if record.run_ms is not None:
                st["total_run_ms"] += record.run_ms
            self._remove_record(record)
            self._history.append(record)

    def _on_timeout(self, record: TaskRecord):
        """Called by the watchdog timer when a task exceeds its timeout."""
        with self._lock:
            if record.status == "running":
                logger.warning(
                    "Task %s (%s, exec=%s) timed out",
                    record.task_id, record.work_type.name, record.execution_id,
                )
                record.cancel_event.set()
                record.status = "timeout"
                record.error = "Execution timed out"

    # ── Cancellation ──────────────────────────────────────────────────────

    def cancel(self, task_id: str) -> bool:
        """Cancel a task by its internal task_id."""
        with self._lock:
            record = self._tasks.get(task_id)
        if not record:
            return False
        return self._cancel_record(record)

    def cancel_by_execution_id(self, execution_id: str) -> bool:
        """Cancel a task by its execution_id (backward compat)."""
        with self._lock:
            tid = self._exec_index.get(execution_id)
            record = self._tasks.get(tid) if tid else None
        if not record:
            return False
        return self._cancel_record(record)

    def get_cancel_event(self, execution_id: str) -> Optional[threading.Event]:
        """Get the cancel_event for a running task (backward compat)."""
        with self._lock:
            tid = self._exec_index.get(execution_id)
            if tid:
                rec = self._tasks.get(tid)
                return rec.cancel_event if rec else None
        return None

    def _cancel_record(self, record: TaskRecord) -> bool:
        with self._lock:
            record.cancel_event.set()
            if record.future and not record.future.done():
                record.future.cancel()
            if record.status in ("queued", "running"):
                record.status = "cancelled"
        logger.info("Cancelled task %s (exec=%s)", record.task_id, record.execution_id)
        return True

    # ── Monitoring ────────────────────────────────────────────────────────

    def get_active_tasks(self, work_type: Optional[WorkType] = None) -> List[dict]:
        """Return all active (queued + running) tasks."""
        with self._lock:
            tasks = list(self._tasks.values())
        if work_type is not None:
            tasks = [t for t in tasks if t.work_type == work_type]
        return [t.to_dict() for t in tasks]

    def get_task_history(
        self, limit: int = 100, work_type: Optional[WorkType] = None,
    ) -> List[dict]:
        """Return recent completed/failed/cancelled tasks (newest first)."""
        with self._lock:
            items = list(self._history)
        if work_type is not None:
            items = [t for t in items if t.work_type == work_type]
        return [t.to_dict() for t in reversed(items)][:limit]

    def get_stats(self) -> dict:
        """Return per-type stats for the admin dashboard."""
        with self._lock:
            running_by_type: Dict[WorkType, int] = {}
            for wt in WorkType:
                running_by_type[wt] = sum(
                    1 for t in self._tasks.values()
                    if t.work_type == wt and t.status == "running"
                )

            result: dict = {
                "total_workers": self._total_workers,
                "active_total": sum(
                    1 for t in self._tasks.values() if t.status == "running"
                ),
                "queued_total": sum(self._queue_counts.values()),
                "by_type": {},
            }

            for wt in WorkType:
                cfg = self._type_cfgs[wt]
                st = self._stats[wt]
                done = st["completed"] + st["failed"] + st["cancelled"] + st["timeout"]
                result["by_type"][wt.name] = {
                    "running": running_by_type[wt],
                    "queued": self._queue_counts[wt],
                    "max_concurrent": cfg.max_concurrent,
                    "max_queue": cfg.max_queue,
                    "default_timeout_s": cfg.default_timeout,
                    "submitted": st["submitted"],
                    "completed": st["completed"],
                    "failed": st["failed"],
                    "cancelled": st["cancelled"],
                    "timeout": st["timeout"],
                    "avg_wait_ms": round(st["total_wait_ms"] / done, 1) if done else 0,
                    "avg_run_ms": round(st["total_run_ms"] / done, 1) if done else 0,
                }

        return result

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def shutdown(self, timeout: Optional[float] = None):
        """Graceful shutdown: signal all tasks, wait, then kill executor."""
        self._shutting_down = True
        timeout = timeout or self._drain_timeout
        logger.info(
            "WorkerPool shutting down: %d active tasks, %.0fs grace",
            len(self._tasks), timeout,
        )

        # Signal all running tasks to stop
        with self._lock:
            for rec in list(self._tasks.values()):
                rec.cancel_event.set()

        # Wait for executor to drain
        loop = asyncio.get_running_loop()
        try:
            await asyncio.wait_for(
                loop.run_in_executor(
                    None, lambda: self._executor.shutdown(wait=True)
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("WorkerPool drain timed out — forcing shutdown")
            self._executor.shutdown(wait=False, cancel_futures=True)

        logger.info("WorkerPool shut down")

    def shutdown_sync(self):
        """Synchronous shutdown for non-async contexts."""
        self._shutting_down = True
        with self._lock:
            for rec in list(self._tasks.values()):
                rec.cancel_event.set()
        self._executor.shutdown(wait=True)


# ── Helper ────────────────────────────────────────────────────────────────

def _accepts_kwarg(fn: Callable, name: str) -> bool:
    """Check if a callable accepts a given keyword argument."""
    try:
        sig = inspect.signature(fn)
        for p in sig.parameters.values():
            if p.name == name:
                return True
            if p.kind == inspect.Parameter.VAR_KEYWORD:
                return True
        return False
    except (ValueError, TypeError):
        return False


# ── Module-level singleton ────────────────────────────────────────────────

_pool: Optional[WorkerPool] = None


def init_pool(
    total_workers: int = 40,
    type_configs: Optional[Dict[WorkType, TypeConfig]] = None,
    drain_timeout: float = 15.0,
) -> WorkerPool:
    """Initialise the global WorkerPool singleton. Called once at startup."""
    global _pool
    _pool = WorkerPool(total_workers, type_configs, drain_timeout)
    return _pool


def get_pool() -> WorkerPool:
    """Return the global WorkerPool. Raises if not initialised."""
    if _pool is None:
        raise RuntimeError("WorkerPool not initialised — call init_pool() first")
    return _pool
