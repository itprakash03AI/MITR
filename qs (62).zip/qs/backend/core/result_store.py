"""
In-memory result store for SQL query executions.

Holds DataFrames in memory with a configurable TTL (default 2 hours).
This avoids writing a CSV file for every report run — files are only
written when the user explicitly requests an export.

Thread-safe via RLock.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

logger = logging.getLogger(__name__)

_TTL_HOURS = 2


class ResultStore:
    """Thread-safe in-memory DataFrame store with TTL eviction."""

    def __init__(self, ttl_hours: int = _TTL_HOURS):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._lock  = threading.RLock()
        self._ttl   = timedelta(hours=ttl_hours)

    def put(self, execution_id: str, df: pd.DataFrame) -> None:
        """Store a DataFrame result. Overwrites any existing entry."""
        entry = {
            "df":         df,
            "columns":    df.columns.tolist(),
            "total_rows": len(df),
            "created":    datetime.now(timezone.utc),
        }
        with self._lock:
            self._store[execution_id] = entry
        logger.debug(f"ResultStore: stored {len(df)} rows for {execution_id}")

    def get(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """
        Return the stored entry, or None if not found / expired.
        Expired entries are removed on access.
        """
        with self._lock:
            entry = self._store.get(execution_id)
            if entry is None:
                return None
            age = datetime.now(timezone.utc) - entry["created"]
            if age > self._ttl:
                del self._store[execution_id]
                logger.debug(f"ResultStore: expired entry for {execution_id}")
                return None
            return entry

    def delete(self, execution_id: str) -> None:
        with self._lock:
            self._store.pop(execution_id, None)

    def cleanup_expired(self) -> int:
        """Remove all expired entries. Returns count removed."""
        cutoff = datetime.now(timezone.utc) - self._ttl
        with self._lock:
            expired = [k for k, v in self._store.items() if v["created"] < cutoff]
            for k in expired:
                del self._store[k]
        if expired:
            logger.info(f"ResultStore: cleaned up {len(expired)} expired entries")
        return len(expired)

    def size(self) -> int:
        with self._lock:
            return len(self._store)


# Module-level singleton — shared across the whole process
_store = ResultStore()


def get_store() -> ResultStore:
    return _store
