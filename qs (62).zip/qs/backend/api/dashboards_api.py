"""
Dashboard API Router — CRUD for dashboards + widgets.

Endpoints:
  GET    /api/dashboards
  POST   /api/dashboards
  GET    /api/dashboards/{id}
  PUT    /api/dashboards/{id}
  DELETE /api/dashboards/{id}
  GET    /api/dashboards/{id}/widgets
  POST   /api/dashboards/{id}/widgets
  PUT    /api/dashboards/{id}/widgets/{widget_id}
  DELETE /api/dashboards/{id}/widgets/{widget_id}
  PUT    /api/dashboards/{id}/layout   (bulk layout update from react-grid-layout)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

# Injected from main.py _startup()
_db_manager = None
_get_user   = None   # reference to main.py's _get_current_user


def set_dashboard_dependencies(db_manager, get_current_user_fn) -> None:
    global _db_manager, _get_user
    _db_manager = db_manager
    _get_user   = get_current_user_fn


def _db():
    if _db_manager is None:
        raise RuntimeError("Dashboard dependencies not initialised")
    return _db_manager


def _user(request: Request) -> dict:
    if _get_user is None:
        return {"username": "guest", "is_admin": True}
    return _get_user(request)


# ── Pydantic models ────────────────────────────────────────────────────────────

class CreateDashboardRequest(BaseModel):
    name:        str
    description: Optional[str] = None


class UpdateDashboardRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None


class CreateWidgetRequest(BaseModel):
    widget_type:  str                       # "saved_query" | "sql_query" | "report"
    source_id:    int
    title:        Optional[str] = None
    layout:       Optional[Dict[str, Any]] = None   # {x, y, w, h}
    chart_type:   str = "grid"              # "grid"|"bar"|"line"|"area"|"pie"|"scatter"|"metric"
    chart_config: Optional[Dict[str, Any]] = None
    param_values: Optional[Dict[str, Any]] = None


class UpdateWidgetRequest(BaseModel):
    title:        Optional[str] = None
    layout:       Optional[Dict[str, Any]] = None
    chart_type:   Optional[str] = None
    chart_config: Optional[Dict[str, Any]] = None
    param_values: Optional[Dict[str, Any]] = None


class LayoutUpdateRequest(BaseModel):
    layouts: List[Dict[str, Any]]   # [{i: "42", x, y, w, h}, ...]


# ── Dashboard endpoints ────────────────────────────────────────────────────────

@router.get("/api/dashboards")
async def list_dashboards(request: Request):
    user = _user(request)
    db   = _db()
    return db.list_dashboards(
        created_by=user.get("username"),
        is_admin=user.get("is_admin", True),
    )


@router.post("/api/dashboards", status_code=201)
async def create_dashboard(body: CreateDashboardRequest, request: Request):
    user = _user(request)
    return _db().create_dashboard(
        name=body.name,
        description=body.description,
        created_by=user.get("username"),
    )


@router.get("/api/dashboards/{dashboard_id}")
async def get_dashboard(dashboard_id: int, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    widgets = db.list_widgets(dashboard_id)
    return {**d, "widgets": widgets}


@router.put("/api/dashboards/{dashboard_id}")
async def update_dashboard(dashboard_id: int, body: UpdateDashboardRequest, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    return db.update_dashboard(dashboard_id, **updates)


@router.delete("/api/dashboards/{dashboard_id}")
async def delete_dashboard(dashboard_id: int, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    db.delete_dashboard(dashboard_id)
    return {"message": "Dashboard deleted"}


# ── Widget endpoints ───────────────────────────────────────────────────────────

@router.get("/api/dashboards/{dashboard_id}/widgets")
async def list_widgets(dashboard_id: int, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    return db.list_widgets(dashboard_id)


@router.post("/api/dashboards/{dashboard_id}/widgets", status_code=201)
async def create_widget(dashboard_id: int, body: CreateWidgetRequest, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    return db.create_widget(
        dashboard_id=dashboard_id,
        widget_type=body.widget_type,
        source_id=body.source_id,
        title=body.title,
        layout=body.layout,
        chart_type=body.chart_type,
        chart_config=body.chart_config,
        param_values=body.param_values,
    )


@router.put("/api/dashboards/{dashboard_id}/widgets/{widget_id}")
async def update_widget(dashboard_id: int, widget_id: int,
                        body: UpdateWidgetRequest, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    w = db.update_widget(widget_id, **updates)
    if not w:
        raise HTTPException(status_code=404, detail="Widget not found")
    return w


@router.delete("/api/dashboards/{dashboard_id}/widgets/{widget_id}")
async def delete_widget(dashboard_id: int, widget_id: int, request: Request):
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    if not db.delete_widget(widget_id):
        raise HTTPException(status_code=404, detail="Widget not found")
    return {"message": "Widget deleted"}


@router.put("/api/dashboards/{dashboard_id}/layout")
async def update_layout(dashboard_id: int, body: LayoutUpdateRequest, request: Request):
    """Bulk update widget positions — called by react-grid-layout onLayoutChange."""
    user = _user(request)
    db   = _db()
    d    = db.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    db.update_widget_layouts(dashboard_id, body.layouts)
    return {"message": "Layout saved"}


# ── Access control helper ──────────────────────────────────────────────────────

def _check_dashboard_access(dashboard: dict, user: dict) -> None:
    """Non-admins can only access their own dashboards."""
    from core.config import auth as _auth_cfg
    if _auth_cfg.type != "ad":
        return
    if user.get("is_admin"):
        return
    if dashboard.get("created_by") != user.get("username"):
        raise HTTPException(status_code=403, detail="Access denied")
