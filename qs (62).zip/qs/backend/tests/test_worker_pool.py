"""Tests for core.worker_pool — thread safety, queue management, cancellation, timeout."""

import asyncio
import threading
import time
import pytest
from unittest.mock import MagicMock

from core.worker_pool import (
    WorkerPool, WorkType, TypeConfig, TaskRecord,
    QueueFullError, _accepts_kwarg,
)


# ── Helpers ──────────────────────────────────────────────────────────────

def _blocking_sleep(duration: float = 0.1, cancel_event: threading.Event = None):
    """Simulate a blocking task; respects cancel_event."""
    end = time.monotonic() + duration
    while time.monotonic() < end:
        if cancel_event and cancel_event.is_set():
            raise InterruptedError("Cancelled")
        time.sleep(0.01)
    return "done"


def _failing_task():
    raise ValueError("boom")


def _instant_task():
    return 42


# ── Fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture
def pool():
    """Create a small pool for testing."""
    cfgs = {
        WorkType.INTERACTIVE: TypeConfig(max_concurrent=2, default_timeout=5, max_queue=3),
        WorkType.REPORT:      TypeConfig(max_concurrent=1, default_timeout=5, max_queue=2),
        WorkType.SCHEDULED:   TypeConfig(max_concurrent=1, default_timeout=5, max_queue=2),
        WorkType.EXPORT:      TypeConfig(max_concurrent=1, default_timeout=5, max_queue=2),
        WorkType.SYSTEM:      TypeConfig(max_concurrent=1, default_timeout=5, max_queue=2),
    }
    p = WorkerPool(total_workers=4, type_configs=cfgs, history_size=50)
    yield p
    p.shutdown_sync()


# ── Tests ────────────────────────────────────────────────────────────────

class TestSubmitAndComplete:
    """Basic submit → run → complete flow."""

    @pytest.mark.asyncio
    async def test_submit_returns_record(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _instant_task, username="alice")
        assert record.task_id
        assert record.work_type == WorkType.INTERACTIVE
        assert record.username == "alice"

    @pytest.mark.asyncio
    async def test_task_completes_successfully(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _instant_task)
        result = await asyncio.wrap_future(record.future)
        assert result == 42
        # Give the done callback a moment to fire
        await asyncio.sleep(0.1)
        assert record.status == "completed"

    @pytest.mark.asyncio
    async def test_task_failure_sets_status(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _failing_task)
        with pytest.raises(ValueError, match="boom"):
            await asyncio.wrap_future(record.future)
        await asyncio.sleep(0.1)
        assert record.status == "failed"
        assert "boom" in record.error

    def test_submit_sync(self, pool):
        record = pool.submit_sync(WorkType.SYSTEM, _instant_task, username="sys")
        result = record.future.result(timeout=5)
        assert result == 42
        time.sleep(0.1)
        assert record.status == "completed"


class TestQueueCount:
    """Verify queue counts don't double-decrement."""

    @pytest.mark.asyncio
    async def test_queue_count_zero_after_completion(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _instant_task)
        await asyncio.wrap_future(record.future)
        await asyncio.sleep(0.1)
        stats = pool.get_stats()
        assert stats["by_type"]["INTERACTIVE"]["queued"] == 0

    @pytest.mark.asyncio
    async def test_queue_count_zero_after_failure(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _failing_task)
        try:
            await asyncio.wrap_future(record.future)
        except ValueError:
            pass
        await asyncio.sleep(0.1)
        stats = pool.get_stats()
        assert stats["by_type"]["INTERACTIVE"]["queued"] == 0

    @pytest.mark.asyncio
    async def test_queue_full_raises(self, pool):
        """Fill the REPORT queue (max_queue=2) and verify QueueFullError.

        REPORT config: max_concurrent=1, max_queue=2.
        submit() awaits slot acquisition, so we use create_task for
        concurrent submissions that will block waiting for slots.
        """
        evt1 = threading.Event()
        evt2 = threading.Event()
        evt3 = threading.Event()

        # Task 1 — acquires the sole slot, runs
        rec1 = await pool.submit(WorkType.REPORT, lambda: evt1.wait(30))

        # Tasks 2 & 3 — will block on slot acquisition (don't await)
        t2 = asyncio.create_task(pool.submit(WorkType.REPORT, lambda: evt2.wait(30)))
        t3 = asyncio.create_task(pool.submit(WorkType.REPORT, lambda: evt3.wait(30)))

        # Give event loop time for both submissions to increment queue_count
        await asyncio.sleep(0.3)

        # Queue is now at 2 (max) — next submit should fail
        with pytest.raises(QueueFullError):
            await pool.submit(WorkType.REPORT, _instant_task)

        # Cleanup: release task 1 so queued tasks can drain through
        evt1.set()
        evt2.set()
        evt3.set()
        # Wait for tasks 2 & 3 to acquire slots, run, and complete
        try:
            await asyncio.wait_for(t2, timeout=5)
        except Exception:
            pass
        try:
            await asyncio.wait_for(t3, timeout=5)
        except Exception:
            pass


class TestCancellation:
    """Verify cancel sets event and updates status under lock."""

    @pytest.mark.asyncio
    async def test_cancel_running_task(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE,
            _blocking_sleep, 10.0,  # long sleep
        )
        await asyncio.sleep(0.05)  # let it start
        assert record.status == "running"

        result = pool.cancel(record.task_id)
        assert result is True
        assert record.cancel_event.is_set()
        assert record.status == "cancelled"

    @pytest.mark.asyncio
    async def test_cancel_by_execution_id(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE,
            _blocking_sleep, 10.0,
            execution_id="exec-123",
        )
        await asyncio.sleep(0.05)
        result = pool.cancel_by_execution_id("exec-123")
        assert result is True
        assert record.status == "cancelled"

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_returns_false(self, pool):
        assert pool.cancel("nonexistent-id") is False
        assert pool.cancel_by_execution_id("nonexistent-exec") is False

    @pytest.mark.asyncio
    async def test_get_cancel_event(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE,
            _blocking_sleep, 10.0,
            execution_id="exec-456",
        )
        evt = pool.get_cancel_event("exec-456")
        assert evt is record.cancel_event
        # Cleanup
        record.cancel_event.set()


class TestTimeout:
    """Verify timeout fires and sets status correctly."""

    @pytest.mark.asyncio
    async def test_timeout_sets_status(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE,
            _blocking_sleep, 10.0,
            timeout_seconds=1,
        )
        # Wait for timeout to fire
        await asyncio.sleep(1.5)
        assert record.status == "timeout"
        assert record.cancel_event.is_set()
        assert "timed out" in record.error

    @pytest.mark.asyncio
    async def test_completed_task_cancels_timer(self, pool):
        """Timer should be cancelled when task completes before timeout."""
        record = await pool.submit(
            WorkType.INTERACTIVE,
            _instant_task,
            timeout_seconds=60,
        )
        await asyncio.wrap_future(record.future)
        # Wait for the done callback to fire (runs in executor thread)
        await asyncio.sleep(0.5)
        assert record.status == "completed"
        assert record._timeout_timer is None


class TestThreadSafety:
    """Concurrent operations should not corrupt state."""

    @pytest.mark.asyncio
    async def test_concurrent_submit_and_cancel(self, pool):
        """Submit many tasks and cancel them concurrently."""
        records = []
        for i in range(6):
            rec = await pool.submit(
                WorkType.INTERACTIVE,
                _blocking_sleep, 5.0,
                execution_id=f"conc-{i}",
            )
            records.append(rec)

        # Cancel all from multiple threads
        threads = []
        for rec in records:
            t = threading.Thread(target=pool.cancel, args=(rec.task_id,))
            threads.append(t)
            t.start()
        for t in threads:
            t.join(timeout=5)

        await asyncio.sleep(0.5)
        for rec in records:
            assert rec.status in ("cancelled", "completed", "failed", "timeout")

    @pytest.mark.asyncio
    async def test_stats_consistency(self, pool):
        """Stats should reflect actual task outcomes."""
        # Submit a mix of success and failure
        r1 = await pool.submit(WorkType.INTERACTIVE, _instant_task)
        r2 = await pool.submit(WorkType.INTERACTIVE, _failing_task)
        r3 = await pool.submit(WorkType.INTERACTIVE, _instant_task)

        for r in (r1, r2, r3):
            try:
                await asyncio.wrap_future(r.future)
            except Exception:
                pass

        await asyncio.sleep(0.2)
        stats = pool.get_stats()
        by_type = stats["by_type"]["INTERACTIVE"]
        assert by_type["submitted"] == 3
        assert by_type["completed"] == 2
        assert by_type["failed"] == 1


class TestMonitoring:
    """Test get_active_tasks, get_task_history, get_stats."""

    @pytest.mark.asyncio
    async def test_active_tasks_shows_running(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE, _blocking_sleep, 5.0,
        )
        await asyncio.sleep(0.05)
        active = pool.get_active_tasks(WorkType.INTERACTIVE)
        assert any(t["task_id"] == record.task_id for t in active)
        record.cancel_event.set()

    @pytest.mark.asyncio
    async def test_history_populated_after_completion(self, pool):
        record = await pool.submit(WorkType.INTERACTIVE, _instant_task)
        await asyncio.wrap_future(record.future)
        await asyncio.sleep(0.1)
        history = pool.get_task_history(limit=10)
        assert any(h["task_id"] == record.task_id for h in history)


class TestReconfiguration:
    """Hot reconfiguration of limits."""

    def test_reconfigure_updates_limits(self, pool):
        new_cfgs = {
            WorkType.INTERACTIVE: TypeConfig(max_concurrent=5, default_timeout=10, max_queue=10),
        }
        changes = pool.reconfigure(new_cfgs)
        assert "INTERACTIVE" in changes
        cfg = pool.get_config()
        assert cfg["types"]["INTERACTIVE"]["max_concurrent"] == 5

    def test_reconfigure_no_change(self, pool):
        same_cfgs = {
            WorkType.INTERACTIVE: TypeConfig(max_concurrent=2, default_timeout=5, max_queue=3),
        }
        changes = pool.reconfigure(same_cfgs)
        assert changes == {}


class TestShutdown:
    """Shutdown behavior."""

    @pytest.mark.asyncio
    async def test_shutdown_rejects_new_submissions(self, pool):
        await pool.shutdown(timeout=2)
        with pytest.raises(RuntimeError, match="shutting down"):
            await pool.submit(WorkType.INTERACTIVE, _instant_task)

    @pytest.mark.asyncio
    async def test_shutdown_signals_running_tasks(self, pool):
        record = await pool.submit(
            WorkType.INTERACTIVE, _blocking_sleep, 10.0,
        )
        await asyncio.sleep(0.05)
        await pool.shutdown(timeout=2)
        assert record.cancel_event.is_set()


class TestHelpers:
    """Test _accepts_kwarg helper."""

    def test_accepts_kwarg_explicit(self):
        def fn(a, cancel_event=None):
            pass
        assert _accepts_kwarg(fn, "cancel_event") is True

    def test_accepts_kwarg_var_keyword(self):
        def fn(a, **kwargs):
            pass
        assert _accepts_kwarg(fn, "cancel_event") is True

    def test_does_not_accept_kwarg(self):
        def fn(a, b):
            pass
        assert _accepts_kwarg(fn, "cancel_event") is False


class TestTaskRecord:
    """TaskRecord dataclass behavior."""

    def test_wait_ms(self):
        rec = TaskRecord(
            task_id="t1", work_type=WorkType.INTERACTIVE,
            execution_id=None, username="u",
            status="completed", cancel_event=threading.Event(),
        )
        rec.created_at = 100.0
        rec.started_at = 100.5
        assert rec.wait_ms == pytest.approx(500.0)

    def test_run_ms(self):
        rec = TaskRecord(
            task_id="t1", work_type=WorkType.INTERACTIVE,
            execution_id=None, username="u",
            status="completed", cancel_event=threading.Event(),
        )
        rec.started_at = 100.0
        rec.completed_at = 100.25
        assert rec.run_ms == pytest.approx(250.0)

    def test_to_dict(self):
        rec = TaskRecord(
            task_id="t1", work_type=WorkType.EXPORT,
            execution_id="exec-1", username="bob",
            status="queued", cancel_event=threading.Event(),
        )
        d = rec.to_dict()
        assert d["task_id"] == "t1"
        assert d["work_type"] == "EXPORT"
        assert d["execution_id"] == "exec-1"
