"""Tests for DatabaseManager download file operations — especially mark_expired_downloads."""

import os
import tempfile
import uuid
from datetime import datetime, timedelta, timezone

import pytest

from core.database import DatabaseManager


@pytest.fixture
def db_manager(tmp_path):
    """Create a DatabaseManager with a temporary SQLite DB."""
    db_path = str(tmp_path / "test.db")
    dm = DatabaseManager(f"sqlite:///{db_path}")
    return dm


class TestMarkExpiredDownloads:
    """Verify that mark_expired_downloads transitions available→expired."""

    def test_expires_past_records(self, db_manager):
        """Records with expires_at in the past should be marked expired."""
        fid = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=fid,
            filename="test.parquet",
            file_path="/tmp/test.parquet",
            file_size_bytes=1024,
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        count = db_manager.mark_expired_downloads()
        assert count == 1

        rec = db_manager.get_download_file(fid)
        assert rec["status"] == "expired"

    def test_future_records_not_expired(self, db_manager):
        """Records with expires_at in the future should remain available."""
        fid = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=fid,
            filename="test.parquet",
            file_path="/tmp/test.parquet",
            file_size_bytes=1024,
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        count = db_manager.mark_expired_downloads()
        assert count == 0

        rec = db_manager.get_download_file(fid)
        assert rec["status"] == "available"

    def test_null_expires_at_not_expired(self, db_manager):
        """Records with no expires_at should never be marked expired."""
        fid = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=fid,
            filename="test.parquet",
            file_path="/tmp/test.parquet",
            file_size_bytes=1024,
            expires_at=None,
        )
        count = db_manager.mark_expired_downloads()
        assert count == 0

        rec = db_manager.get_download_file(fid)
        assert rec["status"] == "available"

    def test_already_expired_not_double_counted(self, db_manager):
        """Records already in 'expired' status should not be counted again."""
        fid = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=fid,
            filename="test.parquet",
            file_path="/tmp/test.parquet",
            file_size_bytes=1024,
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        # First call marks it
        assert db_manager.mark_expired_downloads() == 1
        # Second call should find nothing new
        assert db_manager.mark_expired_downloads() == 0

    def test_mixed_records(self, db_manager):
        """Only past-expiry records should be marked; others untouched."""
        past_fid = str(uuid.uuid4())
        future_fid = str(uuid.uuid4())
        null_fid = str(uuid.uuid4())

        for fid, exp in [
            (past_fid, datetime.now(timezone.utc) - timedelta(hours=2)),
            (future_fid, datetime.now(timezone.utc) + timedelta(days=1)),
            (null_fid, None),
        ]:
            db_manager.create_download_file(
                file_id=fid,
                filename="test.parquet",
                file_path=f"/tmp/{fid}.parquet",
                file_size_bytes=512,
                expires_at=exp,
            )

        count = db_manager.mark_expired_downloads()
        assert count == 1
        assert db_manager.get_download_file(past_fid)["status"] == "expired"
        assert db_manager.get_download_file(future_fid)["status"] == "available"
        assert db_manager.get_download_file(null_fid)["status"] == "available"


class TestExpireOldestDownloads:
    """Verify count-based expiry works correctly."""

    def test_expire_oldest(self, db_manager):
        fids = []
        for i in range(5):
            fid = str(uuid.uuid4())
            fids.append(fid)
            db_manager.create_download_file(
                file_id=fid,
                filename=f"file_{i}.parquet",
                file_path=f"/tmp/{fid}.parquet",
                file_size_bytes=100,
            )

        expired = db_manager.expire_oldest_downloads(keep_count=3)
        assert expired == 2

        available = db_manager.list_download_files(status="available")
        assert len(available) == 3
