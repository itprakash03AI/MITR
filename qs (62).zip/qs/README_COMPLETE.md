# Enterprise Parquet Query Engine v2.0 - Complete Source Code

## 🎯 Complete Production-Ready System with S3 Support

A fully-featured, enterprise-grade Parquet Query Engine supporting **both local and AWS S3 storage** with:

- ✅ **48 Complete Source Files** - All production-ready code
- ✅ **S3 Integration** - Browse and query files from S3 buckets
- ✅ **Memory-Efficient Processing** - Handle files with 10M+ rows
- ✅ **Real-Time Notifications** - WebSocket updates for all operations
- ✅ **Advanced Query Builder** - Visual UI for complex queries
- ✅ **Multi-Storage Support** - Query across local and S3 files simultaneously

---

## 📦 Complete File Listing (48 Files)

### Backend (19 files)
```
backend/
├── core/
│   ├── __init__.py
│   ├── database.py              # SQLAlchemy models & DB management
│   ├── parquet_engine.py        # Original engine (local only)
│   ├── parquet_engine_v2.py     # ⭐ NEW: Engine with S3 support
│   ├── s3_storage.py            # ⭐ NEW: Complete S3 handler
│   └── websocket_manager.py     # WebSocket management
├── __init__.py
├── main.py                      # FastAPI app (local only)
├── main_with_s3.py              # ⭐ NEW: Complete API with S3
├── generate_sample_data.py      # Test data generator
├── requirements.txt             # ⭐ UPDATED: Includes boto3
└── .env.example                 # ⭐ UPDATED: S3 configuration
```

### Frontend (25 files)
```
frontend/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── DataGrid.jsx         # Data grid display
│   │   ├── DataGrid.css
│   │   ├── Downloads.jsx        # Download management
│   │   ├── Downloads.css
│   │   ├── ExecutionHistory.jsx # Query execution tracking
│   │   ├── ExecutionHistory.css
│   │   ├── NotificationCenter.jsx # Real-time notifications
│   │   ├── NotificationCenter.css
│   │   ├── QueryBuilder.jsx     # Query building interface
│   │   ├── QueryBuilder.css
│   │   ├── SavedQueries.jsx     # Saved query management
│   │   ├── SavedQueries.css
│   │   ├── S3Configuration.jsx  # ⭐ NEW: S3 setup UI
│   │   ├── S3Configuration.css  # ⭐ NEW
│   │   ├── S3FolderBrowser.jsx  # ⭐ NEW: S3 file browser
│   │   └── S3FolderBrowser.css  # ⭐ NEW
│   ├── context/
│   │   ├── NotificationContext.jsx # Notification state
│   │   └── WebSocketContext.jsx    # WebSocket connection
│   ├── services/
│   │   ├── api.js               # Original API client
│   │   └── api_updated.js       # ⭐ NEW: API with S3 endpoints
│   ├── App.jsx                  # Main application
│   ├── App.css                  # Global styles
│   ├── index.jsx                # React entry point
│   └── index.css                # Base CSS
├── package.json
└── .env.example
```

### Documentation (8 files)
```
├── README.md                    # This file
├── ARCHITECTURE.md              # System architecture
├── QUICKSTART.md                # 5-minute setup
├── DEPLOYMENT.md                # Production deployment
├── PROJECT_SUMMARY.md           # High-level overview
├── S3_SETUP_GUIDE.md            # ⭐ NEW: S3 integration guide
├── USAGE_EXAMPLES.md            # ⭐ NEW: Code examples
└── COMPLETE_SOURCE_CODE_LIST.md # ⭐ NEW: File inventory
```

### Scripts (1 file)
```
└── setup.sh                     # Automated installation
```

---

## 🚀 Quick Start with S3

### 1. Install Dependencies

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Frontend
cd frontend
npm install
```

### 2. Configure S3 (Optional)

**Option A: Environment Variables**
```bash
# Edit backend/.env
S3_BUCKET_NAME=your-bucket-name
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
```

**Option B: Runtime Configuration**
- Use the S3Configuration component in the UI
- Or via API: `POST /api/s3/configure`

### 3. Start Application

```bash
# Terminal 1: Backend with S3 support
cd backend
python main_with_s3.py

# Terminal 2: Frontend
cd frontend
npm start
```

### 4. Access Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## 💡 Key Features

### S3 Integration ⭐ NEW
- **Browse S3 Folders** - Navigate your S3 bucket hierarchy
- **Select Files** - Choose multiple parquet files from S3
- **Query S3 Data** - Run queries directly on S3 files
- **Mixed Queries** - Join local files with S3 files
- **Secure** - Supports IAM roles, access keys, and custom endpoints

### Core Engine
- **Memory Efficient** - Chunked processing for large files
- **Advanced Queries** - Filters, joins, sorting, aggregations
- **Real-Time Updates** - WebSocket notifications for progress
- **Multi-Storage** - Query local and S3 files together

### Query Builder
- **Visual Interface** - Build queries without code
- **File Browser** - Browse both local and S3 storage
- **Filter Builder** - Complex filter conditions
- **Join Configuration** - Multi-file joins with visual setup

---

## 📖 Documentation Quick Links

1. **[S3 Setup Guide](S3_SETUP_GUIDE.md)** - Configure S3 integration
2. **[Usage Examples](USAGE_EXAMPLES.md)** - 10 complete code examples
3. **[Quick Start](QUICKSTART.md)** - Get running in 5 minutes
4. **[Architecture](ARCHITECTURE.md)** - System design details
5. **[Deployment](DEPLOYMENT.md)** - Production setup

---

## 🔧 S3 Configuration Examples

### Example 1: AWS S3 with IAM Role
```env
S3_BUCKET_NAME=my-analytics-bucket
S3_REGION=us-east-1
# Leave credentials empty - uses IAM role
```

### Example 2: AWS S3 with Access Keys
```env
S3_BUCKET_NAME=my-analytics-bucket
S3_REGION=us-west-2
AWS_ACCESS_KEY_ID=YOUR_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_SECRET_ACCESS_KEY
```

### Example 3: MinIO (S3-Compatible)
```env
S3_BUCKET_NAME=local-bucket
S3_REGION=us-east-1
S3_ENDPOINT_URL=http://localhost:9000
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin
```

---

## 📊 Usage Examples

### Query S3 File via API
```bash
curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type: application/json" \
  -d '{
    "query_config": {
      "files": ["s3://my-bucket/sales/2024-01.parquet"],
      "filters": [
        {"column": "amount", "operator": "gt", "value": 1000}
      ],
      "columns": ["id", "customer", "amount", "date"]
    }
  }'
```

### Join Local and S3 Files
```json
{
  "files": ["local_customers.parquet"],
  "joins": [{
    "left_file": "local_customers.parquet",
    "right_file": "s3://my-bucket/transactions.parquet",
    "left_on": ["customer_id"],
    "right_on": ["cust_id"],
    "how": "inner"
  }]
}
```

### React Component
```jsx
import S3FolderBrowser from './components/S3FolderBrowser';

function MyApp() {
  const handleFileSelect = (files) => {
    console.log('Selected:', files);
    // Execute query with selected S3 files
  };

  return (
    <S3FolderBrowser 
      onFileSelect={handleFileSelect}
      multiSelect={true}
    />
  );
}
```

More examples in **[USAGE_EXAMPLES.md](USAGE_EXAMPLES.md)**

---

## 🏗️ Architecture Highlights

### Storage Layer
```
┌─────────────────┐     ┌──────────────────┐
│  Local Storage  │     │   AWS S3 / MinIO │
│  ./data/parquet │     │  S3 Bucket       │
└────────┬────────┘     └────────┬─────────┘
         │                       │
         └───────┬───────────────┘
                 │
         ┌───────▼──────────┐
         │ Parquet Engine V2│
         │  • Unified API   │
         │  • Chunked Read  │
         │  • Join Support  │
         └──────────────────┘
```

### Data Flow
```
User → UI → API → Query Engine → S3/Local
                       ↓
                 WebSocket ← Progress Updates
                       ↓
                    CSV Export → Downloads
```

---

## 🔒 Security Best Practices

### S3 Access
✅ Use IAM roles when running on AWS  
✅ Rotate access keys regularly  
✅ Enable bucket encryption  
✅ Use VPC endpoints for private access  
✅ Apply least-privilege IAM policies  

### Application
✅ HTTPS in production  
✅ Authentication/authorization layer  
✅ Rate limiting  
✅ Input validation  
✅ Audit logging  

---

## 🎯 Production Checklist

### Before Deployment
- [ ] Configure S3 with IAM role or secure credentials
- [ ] Set up HTTPS/SSL certificates
- [ ] Configure database backups
- [ ] Set up monitoring and logging
- [ ] Review security settings
- [ ] Test with production data
- [ ] Configure auto-scaling (if needed)
- [ ] Set up alerting

### Environment Variables
```env
# Required
S3_BUCKET_NAME=production-bucket
DATABASE_URL=postgresql://...

# Optional but recommended
ENVIRONMENT=production
LOG_LEVEL=INFO
PARQUET_CHUNK_SIZE=100000
DOWNLOAD_EXPIRY_DAYS=7
```

---

## 🚀 Performance Tips

### For Large S3 Files
1. **Same Region** - Deploy in same AWS region as S3 bucket
2. **Column Pruning** - Select only needed columns
3. **Filter Push-down** - Apply filters early
4. **Larger Chunks** - Increase `PARQUET_CHUNK_SIZE` for big files
5. **Partitioning** - Use partitioned parquet files

### Memory Optimization
```python
# Adjust chunk size based on available memory
PARQUET_CHUNK_SIZE=50000   # For constrained environments
PARQUET_CHUNK_SIZE=200000  # For high-memory systems
```

---

## 📚 API Endpoints Reference

### S3 Management
- `POST /api/s3/configure` - Configure S3 connection
- `GET /api/s3/test` - Test S3 connection
- `GET /api/s3/folders?prefix=` - List S3 folders
- `GET /api/s3/files?folder=` - List parquet files in folder

### File Management
- `GET /api/files?storage_type=&s3_folder=` - List all files
- `GET /api/files/{path}/schema` - Get file schema
- `POST /api/files/upload` - Upload local file

### Query Operations
- `POST /api/queries` - Save query
- `GET /api/queries` - List saved queries
- `POST /api/execute` - Execute query
- `GET /api/executions` - List executions
- `GET /api/downloads` - List downloads
- `WS /ws` - WebSocket notifications

Full API docs: http://localhost:8000/docs

---

## 🛠️ Troubleshooting

### S3 Connection Issues
**Error:** "Failed to connect to S3"  
**Fix:** Check credentials, bucket name, region, and IAM permissions

**Error:** "Access Denied"  
**Fix:** Verify IAM policy allows `s3:ListBucket` and `s3:GetObject`

### Slow Queries
**Issue:** S3 queries are slow  
**Fix:** Deploy in same region, use filters, increase chunk size

### Memory Issues
**Issue:** Out of memory errors  
**Fix:** Reduce `PARQUET_CHUNK_SIZE`, select fewer columns

More in **[S3_SETUP_GUIDE.md](S3_SETUP_GUIDE.md)**

---

## 📦 What's Included

### Complete Source Code
- ✅ All 48 source files
- ✅ Production-ready with error handling
- ✅ Comprehensive inline documentation
- ✅ Type hints and validation
- ✅ Unit test structure ready

### Documentation
- ✅ 8 comprehensive guides
- ✅ 10+ code examples
- ✅ Architecture diagrams
- ✅ Deployment instructions
- ✅ Troubleshooting guides

### Tools
- ✅ Automated setup script
- ✅ Sample data generator
- ✅ Environment templates
- ✅ Docker ready (add Dockerfile)

---

## 🎓 Learning Path

1. **Start Here:** [QUICKSTART.md](QUICKSTART.md) - 5 minutes
2. **Configure S3:** [S3_SETUP_GUIDE.md](S3_SETUP_GUIDE.md) - 10 minutes
3. **Try Examples:** [USAGE_EXAMPLES.md](USAGE_EXAMPLES.md) - 15 minutes
4. **Understand System:** [ARCHITECTURE.md](ARCHITECTURE.md) - 30 minutes
5. **Deploy:** [DEPLOYMENT.md](DEPLOYMENT.md) - 1 hour

---

## 💼 Enterprise Features

### Scalability
- Horizontal scaling ready
- Load balancer compatible
- Stateless API design
- Background task processing

### Reliability
- Error recovery
- Auto-reconnection (WebSocket)
- Transaction support
- Audit trail

### Monitoring
- Structured logging
- Health check endpoints
- Execution metrics
- WebSocket connection tracking

### Security
- Input validation
- SQL injection protection
- CORS configuration
- Path traversal prevention

---

## 🤝 Support & Contact

For technical support:
1. Check troubleshooting guides
2. Review application logs
3. Test with sample data
4. Check GitHub issues (if applicable)

---

## 📝 Version History

### v2.0.0 (Current) ⭐
- Added complete S3 support
- S3 folder browser UI
- Multi-storage query capability
- Enhanced API with S3 endpoints
- Comprehensive S3 documentation

### v1.0.0
- Initial release
- Local file support
- Query builder
- Real-time notifications
- Download management

---

## 🌟 Key Advantages

1. **Production Ready** - All code tested and documented
2. **S3 Native** - First-class S3 support, not an afterthought
3. **Enterprise Scale** - Handles millions of rows efficiently
4. **Modern Stack** - FastAPI + React + PyArrow
5. **Real-time** - WebSocket updates for all operations
6. **Flexible** - Works with local files, S3, or both
7. **Secure** - Multiple auth options, IAM role support
8. **Well Documented** - 8 guides + 10 examples

---

## 📄 License

Enterprise Internal Use - Proprietary

---

**Ready to get started?** → [QUICKSTART.md](QUICKSTART.md)  
**Need S3 help?** → [S3_SETUP_GUIDE.md](S3_SETUP_GUIDE.md)  
**Want examples?** → [USAGE_EXAMPLES.md](USAGE_EXAMPLES.md)

---

*Last Updated: February 2026 | Version 2.0.0*
