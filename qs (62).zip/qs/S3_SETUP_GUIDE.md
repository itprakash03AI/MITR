# S3 Integration Setup Guide

This guide explains how to configure and use S3 storage with the Parquet Query Engine.

## Overview

The Parquet Query Engine supports both local and S3 storage, allowing you to:
- Browse S3 folders and files
- Query parquet files directly from S3
- Perform joins across local and S3 files
- Execute queries with the same features as local files

## Configuration Methods

### Method 1: Environment Variables (Recommended for Production)

Edit `backend/.env`:

```env
# S3 Configuration
S3_BUCKET_NAME=your-bucket-name
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key-id
AWS_SECRET_ACCESS_KEY=your-secret-access-key

# Optional: For S3-compatible storage (MinIO, etc.)
S3_ENDPOINT_URL=https://s3.custom-endpoint.com
```

Restart the backend server:
```bash
cd backend
python main_with_s3.py
```

### Method 2: Runtime Configuration via UI

1. Start the application
2. Navigate to Settings or S3 Configuration page
3. Enter your S3 credentials:
   - Bucket Name
   - Region
   - Access Key ID (optional if using IAM roles)
   - Secret Access Key (optional if using IAM roles)
   - Custom Endpoint (for S3-compatible storage)
4. Click "Test Connection"
5. Click "Save Configuration"

### Method 3: API Configuration

```bash
curl -X POST http://localhost:8000/api/s3/configure \
  -H "Content-Type: application/json" \
  -d '{
    "bucket_name": "your-bucket-name",
    "region_name": "us-east-1",
    "aws_access_key_id": "your-access-key",
    "aws_secret_access_key": "your-secret-key"
  }'
```

## AWS IAM Configuration

### Option 1: Using IAM Role (Recommended for EC2/ECS)

If running on AWS infrastructure, use IAM roles instead of credentials:

1. Create an IAM role with S3 access policy
2. Attach the role to your EC2 instance or ECS task
3. Leave `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` empty
4. The SDK will automatically use the IAM role

Example IAM Policy:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket",
        "s3:GetBucketLocation"
      ],
      "Resource": [
        "arn:aws:s3:::your-bucket-name",
        "arn:aws:s3:::your-bucket-name/*"
      ]
    }
  ]
}
```

### Option 2: Using IAM User

1. Create an IAM user
2. Attach S3 access policy (see above)
3. Generate access keys
4. Use the access key ID and secret in configuration

## S3 Bucket Organization

### Recommended Folder Structure

```
your-bucket-name/
├── sales-data/
│   ├── 2023/
│   │   ├── sales_jan_2023.parquet
│   │   ├── sales_feb_2023.parquet
│   │   └── ...
│   └── 2024/
│       └── ...
├── customer-data/
│   ├── customers.parquet
│   └── customer_segments.parquet
├── product-data/
│   └── products.parquet
└── analytics/
    └── ...
```

### Benefits of Organized Structure
- Easy browsing in UI
- Logical separation of datasets
- Simple permission management
- Efficient query building

## Using S3 Files in Queries

### 1. Browse and Select

1. Click "Query Builder"
2. Switch to "S3 Storage" tab
3. Browse folders to find parquet files
4. Select files to query

### 2. Query S3 Files

S3 files are referenced with `s3://` prefix:
```
s3://your-bucket-name/sales-data/2024/sales_jan_2024.parquet
```

Example query:
```json
{
  "files": ["s3://your-bucket-name/sales-data/2024/sales_jan_2024.parquet"],
  "filters": [
    {"column": "status", "operator": "eq", "value": "completed"}
  ]
}
```

### 3. Join Local and S3 Files

You can join files from different storage types:
```json
{
  "files": ["local_file.parquet"],
  "joins": [{
    "left_file": "local_file.parquet",
    "right_file": "s3://your-bucket/customer-data/customers.parquet",
    "left_on": ["customer_id"],
    "right_on": ["id"],
    "how": "inner"
  }]
}
```

## Performance Considerations

### Network Transfer
- S3 files are downloaded to temporary storage during processing
- Large files take longer to download
- Use filters to reduce data transfer
- Consider using AWS Direct Connect for high-throughput needs

### Optimization Tips

1. **Use Column Pruning**
   - Select only needed columns
   - Reduces data transfer

2. **Apply Filters Early**
   - Filter conditions reduce rows before download
   - PyArrow can push down some predicates

3. **Chunk Size**
   - Adjust `PARQUET_CHUNK_SIZE` for S3 files
   - Larger chunks = fewer S3 requests
   - Smaller chunks = less memory usage

4. **Region Selection**
   - Deploy backend in same region as S3 bucket
   - Reduces latency and costs

5. **Use Parquet Partitioning**
   - Partition files by date, region, etc.
   - Query specific partitions only

## S3-Compatible Storage

### MinIO Example

```env
S3_BUCKET_NAME=my-bucket
S3_REGION=us-east-1
S3_ENDPOINT_URL=http://minio-server:9000
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin
```

### Other S3-Compatible Services
- Wasabi
- DigitalOcean Spaces
- Backblaze B2
- Cloudflare R2

All work with custom `S3_ENDPOINT_URL`

## Security Best Practices

### 1. Credentials Management

**❌ Don't:**
- Commit credentials to version control
- Share credentials in plain text
- Use root AWS account credentials
- Store credentials in frontend code

**✅ Do:**
- Use environment variables
- Use IAM roles when possible
- Rotate credentials regularly
- Use AWS Secrets Manager for production

### 2. S3 Bucket Permissions

**Minimum Required Permissions:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::your-bucket-name",
        "arn:aws:s3:::your-bucket-name/*"
      ]
    }
  ]
}
```

**For Production:**
- Enable bucket versioning
- Enable encryption at rest
- Use bucket policies to restrict access
- Enable access logging
- Configure lifecycle policies

### 3. Network Security

- Use VPC endpoints for private S3 access
- Enable SSL/TLS for all connections
- Use AWS PrivateLink when available
- Restrict IP ranges if needed

## Troubleshooting

### Connection Failed

**Error:** "Failed to connect to S3"

**Solutions:**
1. Verify credentials are correct
2. Check bucket name and region
3. Ensure network connectivity
4. Verify IAM permissions
5. Check endpoint URL (if using custom)

### Access Denied

**Error:** "Access Denied" when listing files

**Solutions:**
1. Verify IAM policy allows `s3:ListBucket`
2. Check bucket policy doesn't deny access
3. Ensure credentials have correct permissions
4. Verify bucket name is correct

### Slow Query Performance

**Symptoms:** Queries on S3 files take very long

**Solutions:**
1. Check network bandwidth
2. Move to same AWS region as bucket
3. Use column selection to reduce data
4. Apply filters to reduce rows
5. Increase chunk size for large files
6. Consider caching frequently used files locally

### File Not Found

**Error:** "File not found in S3"

**Solutions:**
1. Verify file path is correct (case-sensitive)
2. Check file exists in bucket
3. Ensure proper S3 prefix in path
4. Verify you have GetObject permission

## Monitoring and Logging

### Enable S3 Access Logging

1. Create logging bucket
2. Enable server access logging on data bucket
3. Analyze access patterns
4. Monitor for unauthorized access

### Application Logging

The application logs S3 operations:
- Connection attempts
- File listings
- Download operations
- Errors and warnings

Check logs at: `./logs/app.log` (or configured location)

### CloudWatch Metrics (AWS)

Monitor:
- S3 request count
- Data transfer
- Error rates
- Request latency

## Cost Optimization

### S3 Storage Costs

1. **Use Storage Classes:**
   - Standard: Frequently accessed
   - Infrequent Access: Rarely accessed
   - Glacier: Long-term archive

2. **Lifecycle Policies:**
   - Transition old files to cheaper storage
   - Delete temporary files automatically

3. **Data Transfer:**
   - Query data in same region
   - Use CloudFront for global access
   - Compress files (Parquet already compressed)

### Request Costs

- List operations: Minimize folder depth
- Get operations: Use column pruning
- Consider caching for frequently accessed files

## Advanced Features

### Server-Side Encryption

Enable in bucket settings:
- SSE-S3 (AWS managed keys)
- SSE-KMS (Customer managed keys)
- SSE-C (Client provided keys)

Configure in application if needed.

### Cross-Region Replication

For disaster recovery:
1. Enable versioning on both buckets
2. Configure replication rules
3. Update application to use replica bucket as failover

### Requester Pays

If using public datasets:
```python
# In S3Config
boto3_config = {
    'RequestPayer': 'requester'
}
```

## Example Workflows

### Workflow 1: Daily Sales Analysis

1. Automated job uploads daily sales to S3
2. Query engine reads from S3 folder
3. Joins with customer data (local)
4. Generates report CSV
5. Stores in downloads

### Workflow 2: Historical Data Query

1. Archive old data to S3 Glacier
2. Restore when needed for analysis
3. Query restored files
4. Delete temporary restored data

### Workflow 3: Multi-Region Setup

1. Replicate data across regions
2. Deploy query engine in each region
3. Each queries local S3 bucket
4. Reduces latency and costs

## Support

For issues with S3 integration:
1. Check application logs
2. Verify AWS CloudTrail for S3 operations
3. Test connection using AWS CLI:
   ```bash
   aws s3 ls s3://your-bucket-name/
   ```
4. Contact support with error logs

## References

- [AWS S3 Documentation](https://docs.aws.amazon.com/s3/)
- [Boto3 Documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/index.html)
- [PyArrow S3 Support](https://arrow.apache.org/docs/python/filesystems.html)
- [AWS IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
