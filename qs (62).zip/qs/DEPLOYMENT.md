# Deployment Guide

Production deployment guide for the Parquet Query Engine.

## Pre-Deployment Checklist

- [ ] Code reviewed and tested
- [ ] Environment variables configured
- [ ] Database backups configured
- [ ] SSL/TLS certificates obtained
- [ ] Monitoring and logging set up
- [ ] Security audit completed
- [ ] Performance testing done
- [ ] Documentation updated

## Production Environment Setup

### Server Requirements

**Minimum:**
- 4 CPU cores
- 8GB RAM
- 100GB SSD storage
- Ubuntu 20.04 LTS or later

**Recommended:**
- 8+ CPU cores
- 16GB+ RAM
- 500GB+ SSD storage
- Ubuntu 22.04 LTS

### Security Hardening

1. **Firewall Configuration**
```bash
sudo ufw allow 22/tcp      # SSH
sudo ufw allow 80/tcp      # HTTP
sudo ufw allow 443/tcp     # HTTPS
sudo ufw enable
```

2. **Create Application User**
```bash
sudo useradd -m -s /bin/bash parquet-engine
sudo usermod -aG sudo parquet-engine
```

3. **Set File Permissions**
```bash
sudo chown -R parquet-engine:parquet-engine /opt/parquet-engine
sudo chmod 755 /opt/parquet-engine
```

## Backend Deployment

### 1. Production Dependencies

```bash
pip install gunicorn
pip install python-dotenv
```

### 2. Environment Variables

Create `/opt/parquet-engine/backend/.env`:

```env
# Production Settings
ENVIRONMENT=production
HOST=0.0.0.0
PORT=8000

# Security
SECRET_KEY=your-secret-key-here
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/parquet_engine
# or for SQLite:
# DATABASE_URL=sqlite:////opt/parquet-engine/data/parquet_query_engine.db

# File Storage
PARQUET_BASE_PATH=/opt/parquet-engine/data/parquet
DOWNLOAD_PATH=/opt/parquet-engine/data/downloads
DOWNLOAD_EXPIRY_DAYS=7

# Performance
PARQUET_CHUNK_SIZE=100000
MAX_WORKERS=4

# Logging
LOG_LEVEL=INFO
LOG_FILE=/var/log/parquet-engine/app.log
```

### 3. Systemd Service

Create `/etc/systemd/system/parquet-engine.service`:

```ini
[Unit]
Description=Parquet Query Engine API
After=network.target

[Service]
Type=notify
User=parquet-engine
Group=parquet-engine
WorkingDirectory=/opt/parquet-engine/backend
Environment="PATH=/opt/parquet-engine/backend/venv/bin"
ExecStart=/opt/parquet-engine/backend/venv/bin/gunicorn main:app \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:8000 \
    --timeout 300 \
    --access-logfile /var/log/parquet-engine/access.log \
    --error-logfile /var/log/parquet-engine/error.log \
    --log-level info

Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 4. Start Service

```bash
sudo systemctl daemon-reload
sudo systemctl enable parquet-engine
sudo systemctl start parquet-engine
sudo systemctl status parquet-engine
```

## Frontend Deployment

### 1. Build Production Bundle

```bash
cd frontend
npm run build
```

### 2. Configure Production Environment

Create `frontend/.env.production`:

```env
REACT_APP_API_URL=https://api.yourdomain.com
REACT_APP_WS_URL=wss://api.yourdomain.com/ws
```

Rebuild:
```bash
npm run build
```

### 3. Nginx Configuration

Create `/etc/nginx/sites-available/parquet-engine`:

```nginx
# Frontend
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    root /opt/parquet-engine/frontend/build;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "no-cache, must-revalidate";
    }

    location /static/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}

# Backend API
server {
    listen 80;
    listen [::]:80;
    server_name api.yourdomain.com;
    
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.yourdomain.com;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # API Proxy
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts for long-running queries
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
    }

    # WebSocket Proxy
    location /ws {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket timeouts
        proxy_connect_timeout 7d;
        proxy_send_timeout 7d;
        proxy_read_timeout 7d;
    }

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=100r/m;
    limit_req zone=api burst=20 nodelay;
}
```

### 4. Enable Nginx Site

```bash
sudo ln -s /etc/nginx/sites-available/parquet-engine /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## SSL/TLS Certificate (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
sudo certbot --nginx -d api.yourdomain.com
```

Auto-renewal:
```bash
sudo certbot renew --dry-run
```

## Database Setup (PostgreSQL - Optional)

For production, consider PostgreSQL instead of SQLite:

```bash
sudo apt install postgresql postgresql-contrib

# Create database
sudo -u postgres createuser parquet_engine
sudo -u postgres createdb parquet_engine_db -O parquet_engine
sudo -u postgres psql -c "ALTER USER parquet_engine WITH PASSWORD 'your-password';"

# Update DATABASE_URL in .env
DATABASE_URL=postgresql://parquet_engine:your-password@localhost:5432/parquet_engine_db
```

## Monitoring Setup

### 1. Application Logging

```bash
sudo mkdir -p /var/log/parquet-engine
sudo chown parquet-engine:parquet-engine /var/log/parquet-engine
```

### 2. Log Rotation

Create `/etc/logrotate.d/parquet-engine`:

```
/var/log/parquet-engine/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 parquet-engine parquet-engine
    sharedscripts
    postrotate
        systemctl reload parquet-engine > /dev/null 2>&1 || true
    endscript
}
```

### 3. System Monitoring

Install monitoring tools:
```bash
sudo apt install htop iotop nethogs
```

## Backup Strategy

### 1. Database Backups

Create `/opt/parquet-engine/scripts/backup.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/opt/parquet-engine/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup SQLite
cp /opt/parquet-engine/data/parquet_query_engine.db \
   $BACKUP_DIR/db_backup_$DATE.db

# Or PostgreSQL
# pg_dump parquet_engine_db > $BACKUP_DIR/db_backup_$DATE.sql

# Compress
gzip $BACKUP_DIR/db_backup_$DATE.*

# Keep only last 30 days
find $BACKUP_DIR -name "db_backup_*.gz" -mtime +30 -delete
```

### 2. Cron Job

```bash
sudo crontab -e -u parquet-engine
# Add:
0 2 * * * /opt/parquet-engine/scripts/backup.sh
```

## Performance Tuning

### 1. Gunicorn Workers

Calculate optimal workers:
```
workers = (2 × num_cores) + 1
```

Example for 4 cores:
```bash
--workers 9
```

### 2. System Limits

Edit `/etc/security/limits.conf`:
```
parquet-engine soft nofile 65536
parquet-engine hard nofile 65536
```

### 3. PostgreSQL (if used)

Edit `/etc/postgresql/14/main/postgresql.conf`:
```
max_connections = 100
shared_buffers = 2GB
effective_cache_size = 6GB
maintenance_work_mem = 512MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
work_mem = 10MB
```

## Health Checks

### 1. API Health Endpoint

```bash
curl https://api.yourdomain.com/health
```

### 2. Monitoring Script

Create `/opt/parquet-engine/scripts/health_check.sh`:

```bash
#!/bin/bash
URL="https://api.yourdomain.com/health"
TIMEOUT=5

if ! curl -f -s --max-time $TIMEOUT "$URL" > /dev/null; then
    echo "Health check failed!"
    systemctl restart parquet-engine
    # Send alert
fi
```

Run every 5 minutes:
```bash
*/5 * * * * /opt/parquet-engine/scripts/health_check.sh
```

## Scaling Strategies

### Horizontal Scaling

1. **Load Balancer**: Use Nginx or HAProxy
2. **Multiple Backend Instances**: Run on different ports
3. **Shared Storage**: NFS or S3 for parquet files
4. **Database**: PostgreSQL with replication

### Vertical Scaling

1. **Increase Resources**: More CPU, RAM, faster storage
2. **Optimize Chunk Size**: Tune based on file sizes
3. **Worker Processes**: Increase Gunicorn workers
4. **Caching**: Redis for query results

## Troubleshooting

### Service Won't Start

```bash
sudo journalctl -u parquet-engine -n 50
sudo systemctl status parquet-engine
```

### High Memory Usage

```bash
ps aux --sort=-%mem | head
htop
```

### Slow Queries

- Check disk I/O: `iotop`
- Monitor CPU: `htop`
- Review query complexity
- Increase chunk size

### WebSocket Issues

- Check Nginx WebSocket config
- Verify firewall allows WebSocket
- Check browser console for errors

## Rollback Procedure

1. Stop service: `sudo systemctl stop parquet-engine`
2. Restore code: `git checkout previous-version`
3. Restore database: `cp backup.db current.db`
4. Restart: `sudo systemctl start parquet-engine`

## Post-Deployment

- [ ] Verify all endpoints working
- [ ] Test WebSocket connection
- [ ] Check logs for errors
- [ ] Monitor resource usage
- [ ] Test with sample queries
- [ ] Verify SSL certificates
- [ ] Update documentation
- [ ] Notify team

## Support Contacts

- DevOps: devops@company.com
- Database Admin: dba@company.com
- Security: security@company.com
