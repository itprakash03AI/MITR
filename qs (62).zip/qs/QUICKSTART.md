# Quick Start Guide

Get up and running with the Parquet Query Engine in 5 minutes!

## Prerequisites

- Python 3.9 or higher
- Node.js 16 or higher
- 4GB RAM minimum

## Installation

### Option 1: Automated Setup (Recommended)

```bash
# Make setup script executable
chmod +x setup.sh

# Run setup
./setup.sh
```

### Option 2: Manual Setup

**Backend:**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
mkdir -p data/parquet data/downloads
cp .env.example .env
```

**Frontend:**
```bash
cd frontend
npm install
cp .env.example .env
```

## Generate Sample Data

```bash
cd backend
source venv/bin/activate
python generate_sample_data.py
```

This creates 4 sample parquet files:
- `sales_data.parquet` - 1M sales transactions
- `customer_data.parquet` - 10K customers
- `product_data.parquet` - 1K products
- `large_events.parquet` - 5M event logs

## Start the Application

**Terminal 1 - Backend:**
```bash
cd backend
source venv/bin/activate
python main.py
```

Server starts at: http://localhost:8000

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

UI opens at: http://localhost:3000

## First Query

1. Open http://localhost:3000 in your browser
2. Click "Query Builder"
3. Select `sales_data.parquet`
4. (Optional) Select columns: `transaction_id`, `date`, `total_amount`, `status`
5. Add filter: `status` equals `completed`
6. Click "Execute Query"
7. Watch real-time notifications in the top-right
8. Navigate to "Downloads" to get your CSV file

## Example Queries

### Simple Filter
```json
{
  "files": ["sales_data.parquet"],
  "filters": [
    {"column": "status", "operator": "eq", "value": "completed"}
  ]
}
```

### Join Two Files
```json
{
  "files": ["sales_data.parquet"],
  "joins": [{
    "left_file": "sales_data.parquet",
    "right_file": "customer_data.parquet",
    "left_on": ["customer_id"],
    "right_on": ["customer_id"],
    "how": "inner"
  }],
  "columns": ["transaction_id", "date", "total_amount", "name", "email"]
}
```

### Complex Query
```json
{
  "files": ["sales_data.parquet"],
  "filters": [
    {"column": "date", "operator": "gte", "value": "2024-01-01"},
    {"column": "total_amount", "operator": "gt", "value": 100}
  ],
  "order_by": [
    {"column": "total_amount", "direction": "desc"}
  ],
  "limit": 1000
}
```

## API Quick Test

### List Files
```bash
curl http://localhost:8000/api/files
```

### Execute Query
```bash
curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type: application/json" \
  -d '{
    "query_config": {
      "files": ["sales_data.parquet"],
      "filters": [{"column": "status", "operator": "eq", "value": "completed"}]
    }
  }'
```

### List Downloads
```bash
curl http://localhost:8000/api/downloads
```

## Troubleshooting

### Backend won't start
- Check Python version: `python3 --version` (need 3.9+)
- Activate virtual environment
- Check port 8000 is available: `lsof -i :8000`

### Frontend won't start
- Check Node version: `node --version` (need 16+)
- Delete `node_modules` and run `npm install` again
- Check port 3000 is available

### No sample data
- Run: `python backend/generate_sample_data.py`
- Check files exist in `backend/data/parquet/`

### WebSocket not connecting
- Ensure backend is running
- Check browser console for errors
- Verify WebSocket URL in frontend/.env

### Query execution hangs
- Check backend logs for errors
- Verify parquet file is valid
- Try with smaller dataset first

## Next Steps

1. **Save Queries**: Click "Save Query" to reuse queries
2. **View History**: Check "Execution History" for past runs
3. **Monitor**: Watch real-time notifications for progress
4. **Download**: Get your results from the "Downloads" page
5. **Optimize**: See README.md for performance tuning

## Support

- Documentation: See README.md and ARCHITECTURE.md
- API Docs: http://localhost:8000/docs (when server running)
- Issues: Check logs in terminal output

## What's Next?

- Upload your own parquet files to `backend/data/parquet/`
- Build complex queries with multiple joins
- Set up scheduled queries
- Deploy to production (see README.md)

Happy querying! 🚀
