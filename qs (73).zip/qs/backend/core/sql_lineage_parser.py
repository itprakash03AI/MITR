"""
SQL Lineage Parser (Phase 49) — AST-based table/column extraction via sqlglot.

Extracts physical table references from SQL text, with fallback to regex
when sqlglot fails. Supports DuckDB, Trino, Snowflake, Databricks, Oracle dialects.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, asdict
from typing import List, Optional

logger = logging.getLogger(__name__)

# ── Data classes ─────────────────────────────────────────────────────────────

@dataclass
class TableRef:
    catalog: Optional[str]
    schema: Optional[str]
    table: str
    access_type: str = "read"   # "read" | "write"
    alias: Optional[str] = None


@dataclass
class ColumnRef:
    """Column-level lineage entry (Phase 51 — stubbed here for forward compat)."""
    source_table: Optional[str]
    source_column: Optional[str]
    target_column: str
    transform_type: str = "direct"  # direct|renamed|computed|aggregated|casted|star_expansion
    transform_expr: Optional[str] = None


# ── Dialect mapping ──────────────────────────────────────────────────────────

_DIALECT_MAP = {
    "s3": "duckdb",
    "local": "duckdb",
    "duckdb": "duckdb",
    "trino": "trino",
    "snowflake": "snowflake",
    "databricks": "databricks",
    "oracle": "oracle",
}


def dialect_for_connection_type(connection_type: str) -> str:
    return _DIALECT_MAP.get((connection_type or "").lower(), "duckdb")


# ── Regex fallback (from reports_api.py) ─────────────────────────────────────

_REGEX_TABLE_PATTERN = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?\s*\.\s*"?(\w+)"?\s*\.\s*"?(\w+)"?',
    re.IGNORECASE,
)

_REGEX_TABLE_2PART = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?\s*\.\s*"?(\w+)"?'
    r'(?!\s*\.)',  # negative lookahead to skip 3-part matches
    re.IGNORECASE,
)

_REGEX_TABLE_1PART = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?'
    r'(?!\s*\.)',
    re.IGNORECASE,
)


def _extract_table_refs_regex(sql: str) -> List[TableRef]:
    """Regex-based fallback extraction of table references."""
    refs: List[TableRef] = []
    seen = set()
    # 3-part: catalog.schema.table
    for m in _REGEX_TABLE_PATTERN.finditer(sql):
        key = (m.group(1), m.group(2), m.group(3))
        if key not in seen:
            seen.add(key)
            refs.append(TableRef(catalog=m.group(1), schema=m.group(2), table=m.group(3)))
    # 2-part: schema.table
    for m in _REGEX_TABLE_2PART.finditer(sql):
        key = (None, m.group(1), m.group(2))
        if key not in seen:
            seen.add(key)
            refs.append(TableRef(catalog=None, schema=m.group(1), table=m.group(2)))
    return refs


# ── sqlglot-based extraction ─────────────────────────────────────────────────

def extract_table_refs(sql: str, dialect: str = "duckdb") -> List[TableRef]:
    """Parse SQL via sqlglot AST and return all physical table references.

    Handles FROM, JOIN, CTE (excluded from results), subqueries,
    INSERT INTO (write), CREATE TABLE AS (write).
    Falls back to regex on parse failure.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        logger.warning("sqlglot not installed — using regex fallback")
        return _extract_table_refs_regex(sql)

    try:
        parsed = sqlglot.parse(sql, dialect=dialect, error_level=sqlglot.ErrorLevel.WARN)
    except Exception as e:
        logger.debug("sqlglot parse failed (%s), falling back to regex: %s", dialect, e)
        return _extract_table_refs_regex(sql)

    refs: List[TableRef] = []
    seen = set()

    for statement in parsed:
        if statement is None:
            continue

        # Collect CTE names so we can exclude them from physical table refs
        cte_names = set()
        for cte in statement.find_all(exp.CTE):
            alias_node = cte.args.get("alias")
            if alias_node:
                cte_names.add(alias_node.name.lower())

        # Determine write targets
        write_tables = set()
        for insert in statement.find_all(exp.Insert):
            tbl = insert.find(exp.Table)
            if tbl:
                write_tables.add(_table_key(tbl))
        for create in statement.find_all(exp.Create):
            tbl = create.find(exp.Table)
            if tbl:
                write_tables.add(_table_key(tbl))

        # Walk all Table nodes
        for tbl in statement.find_all(exp.Table):
            name = tbl.name
            if not name or name.lower() in cte_names:
                continue

            catalog = tbl.catalog or None
            schema = tbl.db or None
            alias = tbl.alias or None
            key = (catalog, schema, name)

            if key in seen:
                continue
            seen.add(key)

            access = "write" if _table_key(tbl) in write_tables else "read"
            refs.append(TableRef(
                catalog=catalog,
                schema=schema,
                table=name,
                access_type=access,
                alias=alias,
            ))

    return refs


def _table_key(tbl) -> str:
    parts = [tbl.catalog or "", tbl.db or "", tbl.name or ""]
    return ".".join(p.lower() for p in parts)


def extract_column_refs(sql: str, dialect: str = "duckdb") -> List[ColumnRef]:
    """Phase 51 stub — returns empty list. Will be implemented in Phase 51."""
    return []


# ── Persistence helper ───────────────────────────────────────────────────────

def extract_and_store_lineage(
    db_manager,
    query_type: str,
    query_id: int,
    sql_text: str,
    connection_id: Optional[int] = None,
    connection_type: str = "duckdb",
) -> None:
    """Parse SQL, extract table refs, persist to DB. Fire-and-forget (swallows errors)."""
    try:
        from core.config import lineage as _lineage_cfg
        if not _lineage_cfg.auto_extract:
            return
    except Exception:
        pass  # config not available — proceed with extraction

    try:
        dialect = dialect_for_connection_type(connection_type)
        refs = extract_table_refs(sql_text, dialect)

        entries = []
        for r in refs:
            entries.append({
                "query_type": query_type,
                "query_id": query_id,
                "connection_id": connection_id,
                "table_catalog": r.catalog,
                "table_schema": r.schema,
                "table_name": r.table,
                "access_type": r.access_type,
                "extraction_method": "sqlglot",
            })

        if entries:
            db_manager.upsert_table_lineage(query_type, query_id, entries)
        else:
            # No refs found — try regex fallback
            try:
                from core.config import lineage as _lineage_cfg
                if not _lineage_cfg.fallback_regex:
                    return
            except Exception:
                pass

            regex_refs = _extract_table_refs_regex(sql_text)
            fallback_entries = []
            for r in regex_refs:
                fallback_entries.append({
                    "query_type": query_type,
                    "query_id": query_id,
                    "connection_id": connection_id,
                    "table_catalog": r.catalog,
                    "table_schema": r.schema,
                    "table_name": r.table,
                    "access_type": r.access_type,
                    "extraction_method": "regex_fallback",
                })
            if fallback_entries:
                db_manager.upsert_table_lineage(query_type, query_id, fallback_entries)

    except Exception:
        logger.debug("Lineage extraction failed for %s:%s", query_type, query_id, exc_info=True)


def table_ref_to_dict(ref: TableRef) -> dict:
    return asdict(ref)
