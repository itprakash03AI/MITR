"""
QueryStudio — centralised configuration loader.

Resolution order (highest → lowest priority):
  1. Environment variables  (QUERYSTUDIO_<SECTION>_<KEY>  e.g. QUERYSTUDIO_SERVER_PORT)
  2. config.json            (backend/config.json)
  3. Built-in defaults      (hardcoded in this file)

For OpenShift / container deployments set env vars in the Deployment manifest or
a ConfigMap/Secret — no code changes required.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# config.json lives next to main.py (backend/)
_CONFIG_FILE = Path(__file__).resolve().parent.parent / "config.json"

# ── Built-in defaults (fallback when neither env var nor config.json provides a value) ──
_DEFAULTS: dict = {
    "database": {
        "type": "sqlite",           # "sqlite" | "oracle"
        "oracle_dsn": "",
        "oracle_user": "",
        "oracle_password": "",
    },
    "auth": {
        "type": "none",             # "none" | "ad" | "local"
        "local_users": "",          # "user1:pass1,user2:pass2" format
        "user_roles": "",           # "user1:admin,user2:analyst,user3:viewer"
        "ad_server": "",
        "ad_domain": "",
        "ad_base_dn": "",
        "ad_user_search_filter": "(sAMAccountName={username})",
        "ad_group_attribute": "memberOf",
        "ad_admin_groups": "",
        "ad_analyst_groups": "",
        "ad_viewer_groups": "",
        "ad_service_account": "",   # Service account for LDAP lookups (e.g. "CN=svc_qs,OU=Service,DC=example,DC=com")
        "ad_service_password": "",  # Service account password
        "ad_connect_timeout": 10,   # seconds to wait for LDAP socket (0 = no limit)
        "ad_use_ssl": False,        # True for ldaps:// connections (port 636)
        "ad_tls_validate": True,    # Validate server TLS cert (set False for self-signed certs in dev)
    },
    "server": {
        "host": "0.0.0.0",
        "port": 8000,
        "log_level": "info",
        "log_format": "json",       # "json" (structured, for ELK/Splunk) | "text" (human-readable)
        "otel_endpoint": "",        # OpenTelemetry OTLP endpoint e.g. "http://jaeger:4317" (empty = disabled)
        "workers": 1,
    },
    "paths": {
        "data_dir": "data",
        "parquet_dir": "data/parquet",
        "downloads_dir": "data/downloads",
        "db_file": "data/parquet_query_engine.db",
        "secret_key_file": "data/secret.key",
        "upload_dir": "data/uploads",
    },
    "query_engine": {
        "chunk_size": 100000,
        "max_workers": 0,
        "query_timeout_seconds": 1800,     # 30 min; 0 = no limit
        "max_concurrent_per_user": 10,     # max parallel queries per user
        "max_concurrent_global": 50,       # system-wide max active queries
        "max_queue_size": 100,             # max queries waiting in queue
        "duckdb_threads_per_query": 4,     # threads per DuckDB query; 0 = auto (cpu_count / 4, min 2)
        "duckdb_memory_limit_mb": 2048,    # per-query memory cap in MB (2GB default); 0 = unlimited
    },
    "s3": {
        "default_region": "us-east-1",
    },
    "s3_results": {
        "enabled": False,                     # upload large results to S3 (requires S3_BUCKET_NAME env)
        "storage_mode": "local",              # "local" = always local, "s3" = always S3, "auto" = S3 above threshold
        "size_threshold_mb": 10,              # results larger than this get uploaded to S3 (auto mode only)
        "prefix": "querystudio/results/",     # S3 key prefix for result files
        "delete_local_after_upload": False,    # remove local parquet after S3 upload
        "bucket_override": "",                # use a different bucket for results (empty = use default S3 bucket)
    },
    "scheduler": {
        "cleanup_temp_files_hours": 1,
        "max_missed_jobs": 3,
        "execution_retention_days": 30,   # delete execution history older than N days
        "mode": "embedded",               # "embedded" (in-process) | "external" (separate worker)
        "worker_port": 8001,              # internal API port for scheduler_worker.py
        "worker_host": "127.0.0.1",       # bind address for scheduler_worker.py
        "notification_poll_interval": 1.5, # seconds between DB notification polls
    },
    "storage": {
        "max_cache_size_mb":     2048,    # LRU-evict cache when total exceeds this
        "max_downloads_size_mb": 10240,   # warn/evict downloads when total exceeds this
        "downloads_expiry_days": 7,       # default download file TTL
    },
    "cors": {
        "allow_origins": ["*"],
        "allow_methods": ["*"],
        "allow_headers": ["*"],
    },
    "email": {
        "host": "",
        "port": 587,
        "user": "",
        "password": "",
        "from_address": "",
        "use_tls": True,
    },
    "cache": {
        "enabled":     True,
        "ttl_seconds": 3600,
        "max_size_mb": 2048,
    },
    "worker_pool": {
        "total_workers":               40,
        "drain_timeout_seconds":       15,
        "interactive_max_concurrent":  30,
        "interactive_default_timeout": 1800,
        "interactive_max_queue":       100,
        "report_max_concurrent":       10,
        "report_default_timeout":      3600,
        "report_max_queue":            20,
        "scheduled_max_concurrent":    5,
        "scheduled_default_timeout":   7200,
        "scheduled_max_queue":         50,
        "export_max_concurrent":       8,
        "export_default_timeout":      900,
        "export_max_queue":            30,
        "system_max_concurrent":       10,
        "system_default_timeout":      300,
        "system_max_queue":            50,
    },
    "limits": {
        "max_stream_files":            200,     # max S3 parquet files per streaming query
        "stream_query_limit_default":  500,     # default row limit for stream queries
        "stream_query_limit_max":      5000,    # max row limit for stream queries
        "stream_page_size_default":    100,     # default page size for stream pagination
        "stream_page_size_max":        5000,    # max page size for stream pagination
        "stream_chart_top_n":          50,      # max rows for streaming chart aggregation
        "stream_chart_max_series":     10,      # max series in multi-series streaming chart
        "max_upload_size_mb":          1024,    # max file upload size in MB (1 GB)
        "max_display_cols":            50,      # default visible columns in grid (user can add/remove)
        "col_auto_project":            50,      # query builder auto-select threshold for wide tables
        "default_query_limit":         1000,    # default query result row limit
        "streaming_default_on":        False,   # default state of streaming toggle
        "stream_bg_download_default":  True,    # default state of background download toggle
    },
    "materialized_views": {
        "storage_dir":              "data/materialized",
        "max_size_mb":              10240,       # 10 GB total for all MVs
        "max_views":                50,
        "refresh_timeout_seconds":  3600,        # 1 hour max refresh time
        "chunk_size":               500000,      # rows per output parquet file
    },
    "local_tables": {
        "storage_dir":              "data/local_tables",
        "max_size_mb":              10240,       # 10 GB total for all local tables
        "max_tables":               100,
        "auto_discard_days":        10,          # discard public tables unused for N days
        "max_upload_size_mb":       1024,        # 1 GB max upload
        "cleanup_interval_hours":   6,           # run cleanup every N hours
    },
    "queue": {
        "backend":        "sqlite",        # "sqlite" (default) | "redis"
        "redis_url":      "redis://localhost:6379/0",
        "redis_password": "",
        "redis_db":       0,
        "redis_ssl":      False,
        "key_prefix":     "qs",            # namespace prefix for Redis keys
        "task_ttl_hours":  24,             # auto-expire completed tasks in Redis
    },
    "executor": {
        "mode":                        "embedded",  # "embedded" (in-process) | "external" (separate worker)
        "worker_port":                 8002,
        "worker_host":                 "127.0.0.1",
        "poll_interval":               1.0,         # seconds between claim polls (executor side)
        "notification_poll_interval":  1.0,         # seconds between completion polls (FastAPI side)
        "max_concurrent":              10,          # max simultaneous tasks in executor
        "stale_timeout_seconds":       600,         # re-claim stuck tasks after N seconds
        "cleanup_interval_hours":      1,           # cleanup old completed tasks every N hours
        "task_retention_hours":        24,          # keep completed/failed tasks for N hours
        "max_memory_per_task_gb":      4,           # DuckDB memory limit per task (GB, 0=unlimited)
    },
    "anomaly_detection": {
        "enabled": True,
        "z_score_threshold": 2.5,
        "min_history_runs": 5,
        "window_size": 20,
    },
    "features": {
        "streaming_mode":              "all",   # "all" | "stream_only" | "download_only"
        "streaming_enabled_roles":     "admin,analyst,viewer",
        "export_enabled_roles":        "admin,analyst,viewer",
        "sql_editor_enabled_roles":    "admin,analyst",
        "scheduler_enabled_roles":     "admin,analyst",
        "connections_enabled_roles":   "admin,analyst",
        "upload_enabled_roles":        "admin,analyst",
        "max_query_limit_by_role":     "",      # "viewer:1000,analyst:10000" (0=unlimited)
    },
    "circuit_breaker": {
        "enabled":           True,
        "failure_threshold": 3,        # consecutive failures before opening circuit
        "cooldown_seconds":  60,       # seconds before attempting a probe request
    },
    "connection_pool": {
        "enabled":              True,
        "max_size":             5,        # max connectors per connection
        "idle_timeout_seconds": 300,      # close idle connectors after 5 min
    },
    "lineage": {
        "auto_extract":        True,      # extract table refs on query save/execute
        "fallback_regex":      True,      # use regex extractor when sqlglot fails
        "max_reparse_batch":   500,       # max queries to re-parse in one /reparse call
    },
}


def _load_file() -> dict:
    # Allow tests / container deployments to override the config file path
    env_override = os.environ.get("QUERYSTUDIO_CONFIG")
    file_to_load = Path(env_override) if env_override else _CONFIG_FILE
    if file_to_load.exists():
        try:
            with open(file_to_load, "r", encoding="utf-8") as f:
                data = json.load(f)
            logger.info("Loaded config from %s", file_to_load)
            return data
        except Exception as e:
            logger.warning("Failed to parse %s: %s — using defaults", file_to_load, e)
    return {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (override wins)."""
    result = dict(base)
    for k, v in override.items():
        if k.startswith("_comment"):
            continue
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _apply_env(cfg: dict, prefix: str = "QUERYSTUDIO") -> dict:
    """
    Override config values from environment variables.

    Mapping:  QUERYSTUDIO_SERVER_PORT=9000  →  cfg["server"]["port"] = 9000
              QUERYSTUDIO_PATHS_DATA_DIR=/mnt/data  →  cfg["paths"]["data_dir"] = "/mnt/data"
    """
    for key, raw in os.environ.items():
        if not key.upper().startswith(prefix + "_"):
            continue
        parts = key[len(prefix) + 1:].lower().split("_", 1)
        if len(parts) != 2:
            continue
        section, field = parts
        if section not in cfg:
            continue
        if field not in cfg[section]:
            continue
        original = cfg[section][field]
        try:
            if isinstance(original, bool):
                cfg[section][field] = raw.lower() in ("1", "true", "yes")
            elif isinstance(original, int):
                cfg[section][field] = int(raw)
            elif isinstance(original, float):
                cfg[section][field] = float(raw)
            elif isinstance(original, list):
                cfg[section][field] = [v.strip() for v in raw.split(",")]
            else:
                cfg[section][field] = raw
        except ValueError:
            logger.warning("Could not cast env var %s=%r to %s — skipping", key, raw, type(original).__name__)
    return cfg


# ── Build the merged config once at import time ──────────────────────────────
_file_cfg = _load_file()
_merged   = _deep_merge(_DEFAULTS, _file_cfg)
_cfg      = _apply_env(_merged)


def get(section: str, key: str, fallback: Any = None) -> Any:
    """Return a config value. Falls back to `fallback` if not found."""
    return _cfg.get(section, {}).get(key, fallback)


# ── Convenience accessors ─────────────────────────────────────────────────────

class _ServerCfg:
    host:       str = property(lambda self: get("server", "host"))        # type: ignore[assignment]
    port:       int = property(lambda self: get("server", "port"))        # type: ignore[assignment]
    log_level:  str = property(lambda self: get("server", "log_level"))   # type: ignore[assignment]
    log_format:    str = property(lambda self: get("server", "log_format", "json"))   # type: ignore[assignment]
    otel_endpoint: str = property(lambda self: get("server", "otel_endpoint", ""))  # type: ignore[assignment]
    workers:       int = property(lambda self: get("server", "workers"))             # type: ignore[assignment]

_HERE = Path(__file__).resolve().parent.parent  # backend/


def _resolve(rel: str) -> Path:
    """Resolve a path that may be relative (to backend/) or absolute."""
    p = Path(rel)
    return p if p.is_absolute() else (_HERE / p)


class _PathsCfg:
    @property
    def data_dir(self)        -> Path: return _resolve(get("paths", "data_dir"))
    @property
    def parquet_dir(self)     -> Path: return _resolve(get("paths", "parquet_dir"))
    @property
    def downloads_dir(self)   -> Path: return _resolve(get("paths", "downloads_dir"))
    @property
    def db_file(self)         -> Path: return _resolve(get("paths", "db_file"))
    @property
    def secret_key_file(self) -> Path: return _resolve(get("paths", "secret_key_file"))
    @property
    def upload_dir(self)      -> Path: return _resolve(get("paths", "upload_dir"))
    @property
    def db_url(self)          -> str:
        return "sqlite:///" + self.db_file.as_posix()


class _QueryEngineCfg:
    @property
    def chunk_size(self)  -> int: return int(get("query_engine", "chunk_size"))
    @property
    def max_workers(self) -> int:
        w = int(get("query_engine", "max_workers"))
        return w if w > 0 else min(32, (os.cpu_count() or 4) + 4)
    @property
    def query_timeout_seconds(self) -> int:
        return int(get("query_engine", "query_timeout_seconds", 1800))
    @property
    def max_concurrent_per_user(self) -> int:
        return int(get("query_engine", "max_concurrent_per_user", 10))
    @property
    def max_concurrent_global(self) -> int:
        return int(get("query_engine", "max_concurrent_global", 50))
    @property
    def max_queue_size(self) -> int:
        return int(get("query_engine", "max_queue_size", 100))
    @property
    def duckdb_threads_per_query(self) -> int:
        """Max DuckDB threads per connection. 0 = auto (cpu_count / 4, min 2)."""
        v = int(get("query_engine", "duckdb_threads_per_query", 4))
        if v > 0:
            return v
        # Auto: quarter of CPU cores, min 2
        cpus = os.cpu_count() or 4
        return max(2, cpus // 4)
    @property
    def duckdb_memory_limit_mb(self) -> int:
        """Per-connection DuckDB memory limit in MB. 0 = unlimited. Default 2GB."""
        return int(get("query_engine", "duckdb_memory_limit_mb", 2048))


class _S3Cfg:
    @property
    def default_region(self) -> str: return get("s3", "default_region")


class _S3ResultsCfg:
    @property
    def enabled(self) -> bool: return bool(get("s3_results", "enabled", False))
    @property
    def storage_mode(self) -> str: return str(get("s3_results", "storage_mode", "local"))  # "local" | "s3" | "auto"
    @property
    def size_threshold_mb(self) -> int: return int(get("s3_results", "size_threshold_mb", 10))
    @property
    def size_threshold_bytes(self) -> int: return self.size_threshold_mb * 1024 * 1024
    @property
    def prefix(self) -> str: return str(get("s3_results", "prefix", "querystudio/results/"))
    @property
    def delete_local_after_upload(self) -> bool: return bool(get("s3_results", "delete_local_after_upload", False))
    @property
    def bucket_override(self) -> str: return str(get("s3_results", "bucket_override", ""))


class _StorageCfg:
    @property
    def max_cache_size_mb(self)     -> int: return int(get("storage", "max_cache_size_mb", 2048))
    @property
    def max_downloads_size_mb(self) -> int: return int(get("storage", "max_downloads_size_mb", 10240))
    @property
    def downloads_expiry_days(self) -> int: return int(get("storage", "downloads_expiry_days", 7))


class _SchedulerCfg:
    @property
    def cleanup_temp_files_hours(self)   -> int: return int(get("scheduler", "cleanup_temp_files_hours"))
    @property
    def max_missed_jobs(self)            -> int: return int(get("scheduler", "max_missed_jobs"))
    @property
    def execution_retention_days(self)   -> int: return int(get("scheduler", "execution_retention_days", 30))
    @property
    def mode(self)                       -> str:   return get("scheduler", "mode", "embedded")
    @property
    def worker_port(self)                -> int:   return int(get("scheduler", "worker_port", 8001))
    @property
    def worker_host(self)                -> str:   return get("scheduler", "worker_host", "127.0.0.1")
    @property
    def notification_poll_interval(self) -> float: return float(get("scheduler", "notification_poll_interval", 1.5))
    @property
    def worker_url(self)                 -> str:   return f"http://{self.worker_host}:{self.worker_port}"


class _CorsCfg:
    @property
    def allow_origins(self) -> list: return get("cors", "allow_origins")
    @property
    def allow_methods(self) -> list: return get("cors", "allow_methods")
    @property
    def allow_headers(self) -> list: return get("cors", "allow_headers")


class _DatabaseCfg:
    @property
    def type(self) -> str:
        return get("database", "type", "sqlite").lower()

    @property
    def db_url(self) -> str:
        """Return the SQLAlchemy DB URL for the metadata store."""
        if self.type == "oracle":
            user = get("database", "oracle_user") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_USER", "")
            pwd  = get("database", "oracle_password") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_PASSWORD", "")
            dsn  = get("database", "oracle_dsn") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_DSN", "")
            if not (user and pwd and dsn):
                raise ValueError(
                    "database.type=oracle requires oracle_user, oracle_password, and oracle_dsn "
                    "in config.json or QUERYSTUDIO_DATABASE_ORACLE_* env vars."
                )
            return f"oracle+oracledb://{user}:{pwd}@{dsn}"
        # Default: SQLite
        return "sqlite:///" + _PathsCfg().db_file.as_posix()


class _AuthCfg:
    @property
    def type(self) -> str:
        return get("auth", "type", "none").lower()

    # ── Local auth ──
    @property
    def local_users(self) -> dict:
        """Parse 'user1:pass1,user2:pass2' into {user1: pass1, ...}"""
        raw = get("auth", "local_users", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                u, p = pair.split(":", 1)
                result[u.strip()] = p.strip()
        return result

    @property
    def user_roles(self) -> dict:
        """Parse 'user1:admin,user2:analyst' into {user1: admin, ...}"""
        raw = get("auth", "user_roles", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                u, r = pair.split(":", 1)
                result[u.strip().lower()] = r.strip().lower()
        return result

    # ── AD config ──
    @property
    def ad_server(self) -> str:         return get("auth", "ad_server", "")
    @property
    def ad_domain(self) -> str:         return get("auth", "ad_domain", "")
    @property
    def ad_base_dn(self) -> str:        return get("auth", "ad_base_dn", "")
    @property
    def ad_user_search_filter(self) -> str:
        return get("auth", "ad_user_search_filter", "(sAMAccountName={username})")
    @property
    def ad_group_attribute(self) -> str: return get("auth", "ad_group_attribute", "memberOf")
    @property
    def ad_admin_groups(self) -> list:
        raw = get("auth", "ad_admin_groups", "")
        return [g.strip().lower() for g in raw.split(",") if g.strip()] if raw else []
    @property
    def ad_analyst_groups(self) -> list:
        raw = get("auth", "ad_analyst_groups", "")
        return [g.strip().lower() for g in raw.split(",") if g.strip()] if raw else []
    @property
    def ad_viewer_groups(self) -> list:
        raw = get("auth", "ad_viewer_groups", "")
        return [g.strip().lower() for g in raw.split(",") if g.strip()] if raw else []
    @property
    def ad_service_account(self) -> str: return get("auth", "ad_service_account", "")
    @property
    def ad_service_password(self) -> str: return get("auth", "ad_service_password", "")
    @property
    def ad_connect_timeout(self) -> int: return int(get("auth", "ad_connect_timeout", 10))
    @property
    def ad_use_ssl(self) -> bool: return bool(get("auth", "ad_use_ssl", False))
    @property
    def ad_tls_validate(self) -> bool: return bool(get("auth", "ad_tls_validate", True))


class _EmailCfg:
    @property
    def host(self) -> str:         return get("email", "host", "")
    @property
    def port(self) -> int:         return int(get("email", "port", 587))
    @property
    def user(self) -> str:         return get("email", "user", "")
    @property
    def password(self) -> str:     return get("email", "password", "")
    @property
    def from_address(self) -> str: return get("email", "from_address", "")
    @property
    def use_tls(self) -> bool:     return bool(get("email", "use_tls", True))
    @property
    def enabled(self) -> bool:     return bool(self.host)


class _CacheCfg:
    @property
    def enabled(self)     -> bool: return bool(get("cache", "enabled", True))
    @property
    def ttl_seconds(self) -> int:  return int(get("cache", "ttl_seconds", 3600))
    @property
    def max_size_mb(self) -> int:  return int(get("cache", "max_size_mb", 2048))


class _WorkerPoolCfg:
    @property
    def total_workers(self) -> int:
        return int(get("worker_pool", "total_workers", 40))
    @property
    def drain_timeout_seconds(self) -> int:
        return int(get("worker_pool", "drain_timeout_seconds", 15))

    # Per-type settings (interactive, report, scheduled, export, system)
    def _type_int(self, prefix: str, suffix: str, default: int) -> int:
        return int(get("worker_pool", f"{prefix}_{suffix}", default))

    @property
    def interactive_max_concurrent(self) -> int: return self._type_int("interactive", "max_concurrent", 30)
    @property
    def interactive_default_timeout(self) -> int: return self._type_int("interactive", "default_timeout", 1800)
    @property
    def interactive_max_queue(self) -> int: return self._type_int("interactive", "max_queue", 100)

    @property
    def report_max_concurrent(self) -> int: return self._type_int("report", "max_concurrent", 10)
    @property
    def report_default_timeout(self) -> int: return self._type_int("report", "default_timeout", 3600)
    @property
    def report_max_queue(self) -> int: return self._type_int("report", "max_queue", 20)

    @property
    def scheduled_max_concurrent(self) -> int: return self._type_int("scheduled", "max_concurrent", 5)
    @property
    def scheduled_default_timeout(self) -> int: return self._type_int("scheduled", "default_timeout", 7200)
    @property
    def scheduled_max_queue(self) -> int: return self._type_int("scheduled", "max_queue", 50)

    @property
    def export_max_concurrent(self) -> int: return self._type_int("export", "max_concurrent", 8)
    @property
    def export_default_timeout(self) -> int: return self._type_int("export", "default_timeout", 900)
    @property
    def export_max_queue(self) -> int: return self._type_int("export", "max_queue", 30)

    @property
    def system_max_concurrent(self) -> int: return self._type_int("system", "max_concurrent", 10)
    @property
    def system_default_timeout(self) -> int: return self._type_int("system", "default_timeout", 300)
    @property
    def system_max_queue(self) -> int: return self._type_int("system", "max_queue", 50)

    def build_type_configs(self) -> dict:
        """Build a WorkType → TypeConfig dict for WorkerPool init."""
        from core.worker_pool import WorkType, TypeConfig
        return {
            WorkType.INTERACTIVE: TypeConfig(self.interactive_max_concurrent, self.interactive_default_timeout, self.interactive_max_queue),
            WorkType.REPORT:      TypeConfig(self.report_max_concurrent,      self.report_default_timeout,      self.report_max_queue),
            WorkType.SCHEDULED:   TypeConfig(self.scheduled_max_concurrent,   self.scheduled_default_timeout,   self.scheduled_max_queue),
            WorkType.EXPORT:      TypeConfig(self.export_max_concurrent,      self.export_default_timeout,      self.export_max_queue),
            WorkType.SYSTEM:      TypeConfig(self.system_max_concurrent,      self.system_default_timeout,      self.system_max_queue),
        }


class _LimitsCfg:
    @property
    def max_stream_files(self) -> int:
        return int(get("limits", "max_stream_files", 200))
    @property
    def stream_query_limit_default(self) -> int:
        return int(get("limits", "stream_query_limit_default", 500))
    @property
    def stream_query_limit_max(self) -> int:
        return int(get("limits", "stream_query_limit_max", 5000))
    @property
    def stream_page_size_default(self) -> int:
        return int(get("limits", "stream_page_size_default", 100))
    @property
    def stream_page_size_max(self) -> int:
        return int(get("limits", "stream_page_size_max", 5000))
    @property
    def stream_chart_top_n(self) -> int:
        return int(get("limits", "stream_chart_top_n", 50))
    @property
    def stream_chart_max_series(self) -> int:
        return int(get("limits", "stream_chart_max_series", 10))
    @property
    def max_upload_size_bytes(self) -> int:
        return int(get("limits", "max_upload_size_mb", 1024)) * 1024 * 1024
    @property
    def max_display_cols(self) -> int:
        return int(get("limits", "max_display_cols", 50))
    @property
    def col_auto_project(self) -> int:
        return int(get("limits", "col_auto_project", 50))
    @property
    def default_query_limit(self) -> int:
        return int(get("limits", "default_query_limit", 1000))
    @property
    def streaming_default_on(self) -> bool:
        return bool(get("limits", "streaming_default_on", False))
    @property
    def stream_bg_download_default(self) -> bool:
        return bool(get("limits", "stream_bg_download_default", True))


class _FeaturesCfg:
    @property
    def streaming_mode(self) -> str:
        return get("features", "streaming_mode", "all")

    def _parse_roles(self, key: str, default: str) -> list:
        raw = get("features", key, default)
        return [r.strip().lower() for r in raw.split(",") if r.strip()]

    @property
    def streaming_enabled_roles(self) -> list:
        return self._parse_roles("streaming_enabled_roles", "admin,analyst,viewer")
    @property
    def export_enabled_roles(self) -> list:
        return self._parse_roles("export_enabled_roles", "admin,analyst,viewer")
    @property
    def sql_editor_enabled_roles(self) -> list:
        return self._parse_roles("sql_editor_enabled_roles", "admin,analyst")
    @property
    def scheduler_enabled_roles(self) -> list:
        return self._parse_roles("scheduler_enabled_roles", "admin,analyst")
    @property
    def connections_enabled_roles(self) -> list:
        return self._parse_roles("connections_enabled_roles", "admin,analyst")
    @property
    def upload_enabled_roles(self) -> list:
        return self._parse_roles("upload_enabled_roles", "admin,analyst")
    @property
    def max_query_limit_by_role(self) -> dict:
        raw = get("features", "max_query_limit_by_role", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if ":" in pair:
                r, v = pair.split(":", 1)
                try:
                    result[r.strip().lower()] = int(v.strip())
                except ValueError:
                    pass
        return result


class _CircuitBreakerCfg:
    @property
    def enabled(self) -> bool: return bool(get("circuit_breaker", "enabled", True))
    @property
    def failure_threshold(self) -> int: return int(get("circuit_breaker", "failure_threshold", 3))
    @property
    def cooldown_seconds(self) -> int: return int(get("circuit_breaker", "cooldown_seconds", 60))


class _ConnectionPoolCfg:
    @property
    def enabled(self) -> bool: return bool(get("connection_pool", "enabled", True))
    @property
    def max_size(self) -> int: return int(get("connection_pool", "max_size", 5))
    @property
    def idle_timeout_seconds(self) -> int: return int(get("connection_pool", "idle_timeout_seconds", 300))


class _LocalTablesCfg:
    @property
    def storage_dir(self) -> str:
        return str(get("local_tables", "storage_dir", "data/local_tables"))
    @property
    def max_size_mb(self) -> int:
        return int(get("local_tables", "max_size_mb", 10240))
    @property
    def max_tables(self) -> int:
        return int(get("local_tables", "max_tables", 100))
    @property
    def auto_discard_days(self) -> int:
        return int(get("local_tables", "auto_discard_days", 10))
    @property
    def max_upload_size_mb(self) -> int:
        return int(get("local_tables", "max_upload_size_mb", 1024))
    @property
    def max_upload_size_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024
    @property
    def cleanup_interval_hours(self) -> int:
        return int(get("local_tables", "cleanup_interval_hours", 6))


class _MaterializedViewsCfg:
    @property
    def storage_dir(self) -> str:
        return str(get("materialized_views", "storage_dir", "data/materialized"))
    @property
    def max_size_mb(self) -> int:
        return int(get("materialized_views", "max_size_mb", 10240))
    @property
    def max_views(self) -> int:
        return int(get("materialized_views", "max_views", 50))
    @property
    def refresh_timeout_seconds(self) -> int:
        return int(get("materialized_views", "refresh_timeout_seconds", 3600))
    @property
    def chunk_size(self) -> int:
        return int(get("materialized_views", "chunk_size", 500000))


class _QueueCfg:
    @property
    def backend(self) -> str:
        return str(get("queue", "backend", "sqlite")).lower()
    @property
    def redis_url(self) -> str:
        return str(get("queue", "redis_url", "redis://localhost:6379/0"))
    @property
    def redis_password(self) -> str:
        return str(get("queue", "redis_password", ""))
    @property
    def redis_db(self) -> int:
        return int(get("queue", "redis_db", 0))
    @property
    def redis_ssl(self) -> bool:
        v = get("queue", "redis_ssl", False)
        if isinstance(v, str):
            return v.lower() in ("true", "1", "yes")
        return bool(v)
    @property
    def key_prefix(self) -> str:
        return str(get("queue", "key_prefix", "qs"))
    @property
    def task_ttl_hours(self) -> int:
        return int(get("queue", "task_ttl_hours", 24))


class _ExecutorCfg:
    @property
    def mode(self) -> str:
        return str(get("executor", "mode", "embedded"))
    @property
    def worker_port(self) -> int:
        return int(get("executor", "worker_port", 8002))
    @property
    def worker_host(self) -> str:
        return str(get("executor", "worker_host", "127.0.0.1"))
    @property
    def poll_interval(self) -> float:
        return float(get("executor", "poll_interval", 1.0))
    @property
    def notification_poll_interval(self) -> float:
        return float(get("executor", "notification_poll_interval", 1.0))
    @property
    def max_concurrent(self) -> int:
        return int(get("executor", "max_concurrent", 10))
    @property
    def stale_timeout_seconds(self) -> int:
        return int(get("executor", "stale_timeout_seconds", 600))
    @property
    def cleanup_interval_hours(self) -> int:
        return int(get("executor", "cleanup_interval_hours", 1))
    @property
    def task_retention_hours(self) -> int:
        return int(get("executor", "task_retention_hours", 24))
    @property
    def max_memory_per_task_gb(self) -> int:
        return int(get("executor", "max_memory_per_task_gb", 4))
    @property
    def worker_url(self) -> str:
        return f"http://{self.worker_host}:{self.worker_port}"


class _AnomalyDetectionCfg:
    @property
    def enabled(self) -> bool: return bool(get("anomaly_detection", "enabled", True))
    @property
    def z_score_threshold(self) -> float: return float(get("anomaly_detection", "z_score_threshold", 2.5))
    @property
    def min_history_runs(self) -> int: return int(get("anomaly_detection", "min_history_runs", 5))
    @property
    def window_size(self) -> int: return int(get("anomaly_detection", "window_size", 20))


class _LineageCfg:
    @property
    def auto_extract(self) -> bool: return bool(get("lineage", "auto_extract", True))
    @property
    def fallback_regex(self) -> bool: return bool(get("lineage", "fallback_regex", True))
    @property
    def max_reparse_batch(self) -> int: return int(get("lineage", "max_reparse_batch", 500))


def reload():
    """Reload config from disk — called after admin changes config.json."""
    global _file_cfg, _merged, _cfg
    _file_cfg = _load_file()
    _merged = _deep_merge(_DEFAULTS, _file_cfg)
    _cfg = _apply_env(_merged)
    logger.info("Config reloaded from %s", _CONFIG_FILE)


server        = _ServerCfg()
paths         = _PathsCfg()
database      = _DatabaseCfg()
auth          = _AuthCfg()
query_engine  = _QueryEngineCfg()
s3            = _S3Cfg()
s3_results    = _S3ResultsCfg()
scheduler     = _SchedulerCfg()
cors          = _CorsCfg()
email         = _EmailCfg()
cache         = _CacheCfg()
storage       = _StorageCfg()
worker_pool   = _WorkerPoolCfg()
limits        = _LimitsCfg()
features      = _FeaturesCfg()
circuit_breaker = _CircuitBreakerCfg()
connection_pool = _ConnectionPoolCfg()
materialized_views = _MaterializedViewsCfg()
local_tables  = _LocalTablesCfg()
queue         = _QueueCfg()
executor      = _ExecutorCfg()
anomaly_detection = _AnomalyDetectionCfg()
lineage       = _LineageCfg()
