"""
Parametric Reports API

Endpoints:
  GET    /api/reports                        — list reports
  POST   /api/reports                        — create report
  GET    /api/reports/{id}                   — get report
  PUT    /api/reports/{id}                   — update report
  DELETE /api/reports/{id}                   — soft delete
  POST   /api/reports/{id}/execute           — run async (returns execution_id)
  GET    /api/reports/{id}/download          — run sync, return CSV directly (for API/curl)
  GET    /api/reports/{id}/source-info       — describe the underlying source query
  GET    /api/reports/{id}/columns           — available columns for the source query

Parameter substitution:
  SQL sources:     {param_name} in SQL → type-safe string replacement
  Parquet sources: {param_name} in filter.value → replaced with param value
  Date shortcuts:  today, yesterday, month_start, -7d, etc. → ISO date
"""

from __future__ import annotations

import asyncio
import functools
import logging
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import date as _date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from fastapi import APIRouter, HTTPException, Query as QParam, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager  = None
_ws_manager  = None
_main_loop   = None
_auth_cfg    = None   # core.config.auth singleton
_rpt_executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix="report_exec")  # legacy, phasing out


def set_report_dependencies(db_manager, ws_manager, loop):
    global _db_manager, _ws_manager, _main_loop
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop


def set_reports_auth(auth_cfg):
    global _auth_cfg
    _auth_cfg = auth_cfg


def _get_current_user_rpt(request: Request) -> Optional[dict]:
    """Local version of _get_current_user for the reports router."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True, "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    # Session token (Bearer) — look up server-side session
    if auth_header.startswith("Bearer "):
        from main import _get_session
        user = _get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user
    # Basic auth fallback
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _is_owner_or_shared_rpt(item: dict, user: dict) -> bool:
    if not user or user.get("is_admin"):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_public", False)
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        from core.worker_pool import get_pool
        _exec = get_pool().executor
    except RuntimeError:
        _exec = _rpt_executor
    if kwargs:
        return await loop.run_in_executor(_exec, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_exec, fn, *args)


def _broadcast(payload: dict):
    if _ws_manager and _main_loop:
        asyncio.run_coroutine_threadsafe(_ws_manager.broadcast(payload), _main_loop)


# ── Partition detection helpers ───────────────────────────────────────────────

_DATE_LIKE_NAMES = frozenset({
    "date", "dt", "day", "month", "year", "business_date", "trade_date",
    "report_date", "event_date", "created_date", "load_date", "partition_date",
    "snapshot_date", "as_of_date", "effective_date",
})


def _looks_like_date(col_name: str) -> bool:
    """Heuristic: does this column name look like a date partition?"""
    norm = col_name.lower().replace("-", "_")
    if norm in _DATE_LIKE_NAMES:
        return True
    return any(norm.endswith(f"_{s}") or norm.startswith(f"{s}_") for s in ("date", "dt", "day"))


def _detect_s3_partitions(saved_query: dict) -> List[Dict[str, Any]]:
    """Detect Hive-style partitions (key=value folders) from S3 file paths."""
    files = (saved_query.get("query_config") or {}).get("files") or []
    if not files:
        return []
    partition_keys: Dict[str, set] = {}
    for f in files[:50]:
        parts = f.replace("\\", "/").split("/")
        for part in parts:
            if "=" in part and not part.startswith("."):
                key, val = part.split("=", 1)
                if key and val:
                    partition_keys.setdefault(key, set()).add(val)
    return [
        {
            "name": k,
            "type": "date" if _looks_like_date(k) else "string",
            "transform": "identity",
            "sample_values": sorted(list(v))[:20],
        }
        for k, v in partition_keys.items()
    ]


def _detect_sql_partitions(sql_query: dict) -> List[Dict[str, Any]]:
    """Detect partition columns from SQL source connection tables."""
    try:
        conn = _db_manager.get_connection_raw(sql_query["primary_connection_id"])
        if not conn:
            return []

        conn_type = conn["connection_type"]
        if conn_type not in ("trino", "starburst", "snowflake", "databricks"):
            return []

        from core.connectors import get_connector
        connector = get_connector(conn_type, conn["config"])
        try:
            # Parse table references from SQL
            sql_text = sql_query.get("primary_sql", "")
            tables = _extract_table_refs(sql_text)
            all_parts = []
            for catalog, schema, table in tables:
                parts = connector.detect_partitions(catalog, schema, table)
                for p in parts:
                    p["source_table"] = f"{catalog}.{schema}.{table}"
                all_parts.extend(parts)
            return all_parts
        finally:
            connector.close()
    except Exception:
        logger.debug("_detect_sql_partitions failed", exc_info=True)
        return []


def _extract_table_refs(sql: str) -> List[tuple]:
    """Extract catalog.schema.table references from SQL text.
    Returns list of (catalog, schema, table) tuples.
    """
    # Match fully-qualified 3-part names: catalog.schema.table
    pattern = re.compile(
        r'(?:FROM|JOIN)\s+'
        r'"?(\w+)"?\s*\.\s*"?(\w+)"?\s*\.\s*"?(\w+)"?',
        re.IGNORECASE
    )
    refs = []
    for m in pattern.finditer(sql):
        refs.append((m.group(1), m.group(2), m.group(3)))
    return refs


def _partitions_to_params(partitions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert detected partitions into report parameter schema entries."""
    seen = set()
    params = []
    for p in partitions:
        name = p["name"]
        if name in seen:
            continue
        seen.add(name)

        ptype = p.get("type", "string")
        is_date = _looks_like_date(name) or ptype in ("date", "timestamp")

        param = {
            "name": name,
            "label": name.replace("_", " ").title(),
            "required": False,
            "description": f"Auto-detected partition column ({p.get('transform', 'identity')})",
        }
        if is_date:
            param["type"] = "date"
            param["default_value"] = "month_start"
        else:
            samples = p.get("sample_values", [])
            if 0 < len(samples) <= 50:
                param["type"] = "multiselect"
                param["source_column"] = name
            else:
                param["type"] = "string"
                param["default_value"] = ""

        params.append(param)
    return params


# ── Parameter substitution ────────────────────────────────────────────────────

_PARAM_RE = re.compile(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}')


def substitute_sql_params(sql: str, param_values: dict, param_schema: list) -> str:
    """
    Replace {param_name} placeholders in SQL with type-safe values.
    - string / date  → wrapped in single quotes, single-quotes in value escaped
    - number         → cast to float, inserted raw (validates it's numeric)
    - boolean        → TRUE / FALSE
    - select         → treated as string
    Unknown params are left as-is (no substitution).
    """
    schema_map = {p["name"]: p for p in (param_schema or [])}

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        val  = param_values.get(name)
        if val is None:
            return m.group(0)    # leave placeholder untouched
        p     = schema_map.get(name, {})
        ptype = p.get("type", "string")

        # ── Multi-select: list/array → 'v1','v2','v3' for IN clauses ──────────
        # Template should use: WHERE col IN ({param_name})
        if isinstance(val, (list, tuple)):
            if not val:
                return "''"   # empty → no match
            safe_parts = [str(v).replace("'", "''") for v in val]
            return "'" + "','".join(safe_parts) + "'"

        if ptype == "number":
            try:
                return str(float(val))
            except (ValueError, TypeError):
                raise ValueError(f"Parameter '{name}' must be a number, got: {val!r}")
        elif ptype == "boolean":
            return "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
        else:
            # string, date, select, multiselect (single value) — wrap in quotes
            safe = str(val).replace("'", "''")
            return f"'{safe}'"

    return _PARAM_RE.sub(_replace, sql)


def substitute_filter_params(filters: list, param_values: dict) -> list:
    """Replace {param_name} in parquet filter values with actual param values."""
    if not filters or not param_values:
        return filters
    result = []
    for f in filters:
        new_f = dict(f)
        val_str = str(f.get("value", ""))
        m = _PARAM_RE.fullmatch(val_str)
        if m:
            param_name = m.group(1)
            if param_name in param_values:
                substituted = param_values[param_name]
                # Empty list/tuple → drop this filter entirely so ALL rows are
                # returned (multiselect with nothing selected = no restriction).
                if isinstance(substituted, (list, tuple)) and len(substituted) == 0:
                    continue
                new_f["value"] = substituted
                # When the substituted value is a non-empty list, upgrade
                # eq → in so the parquet engine can evaluate it correctly.
                if isinstance(substituted, (list, tuple)) and new_f.get("operator") in ("eq", "=", None, ""):
                    new_f["operator"] = "in"
        result.append(new_f)
    return result


def _auto_append_sql_where(sql: str, param_schema: list, param_values: dict,
                           referenced_params: set) -> str:
    """Auto-append WHERE conditions for partition params not already in the SQL.

    If the user selected param values but didn't wire them as {param_name}
    placeholders, we inject WHERE conditions so partition filtering is automatic.
    Skips params already handled by {placeholder} substitution.
    """
    conditions = []
    for p in param_schema:
        name = p["name"]
        if name in referenced_params:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue

        col = name  # column name = param name (partition columns)
        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue
            safe_parts = [str(v).replace("'", "''") for v in val]
            in_list = ", ".join(f"'{v}'" for v in safe_parts)
            conditions.append(f'"{col}" IN ({in_list})')
        else:
            ptype = p.get("type", "string")
            if ptype == "number":
                try:
                    conditions.append(f'"{col}" = {float(val)}')
                except (ValueError, TypeError):
                    safe = str(val).replace("'", "''")
                    conditions.append(f'"{col}" = \'{safe}\'')
            elif ptype == "boolean":
                bval = "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
                conditions.append(f'"{col}" = {bval}')
            else:
                safe = str(val).replace("'", "''")
                conditions.append(f'"{col}" = \'{safe}\'')

    if not conditions:
        return sql

    extra_where = " AND ".join(conditions)

    # Wrap original SQL as subquery and apply WHERE on top.
    # This is safe regardless of the original SQL structure (subqueries, CTEs, etc.)
    stripped = sql.strip().rstrip(";")
    return f"SELECT * FROM ({stripped}) _auto_filtered WHERE {extra_where}"


def validate_param_values(param_schema: list, param_values: dict) -> List[str]:
    """Return list of validation error messages (empty = valid)."""
    errors = []
    for p in param_schema:
        name = p["name"]
        val  = param_values.get(name)
        if p.get("required") and (val is None or str(val).strip() == ""):
            errors.append(f"Required parameter '{p.get('label', name)}' is missing")
    return errors


# ── Business date resolver ────────────────────────────────────────────────────

_RELATIVE_RE = re.compile(r'^([+-])(\d+)d$', re.IGNORECASE)

# Exposed as a module constant for frontend discovery
BUSINESS_DATE_SHORTCUTS = [
    "today", "yesterday", "tomorrow",
    "week_start", "week_end",
    "last_week_start", "last_week_end",
    "month_start", "month_end",
    "last_month_start", "last_month_end",
    "year_start", "year_end",
    "last_year_start", "last_year_end",
]


def resolve_business_dates(param_values: dict) -> dict:
    """
    Expand business date shortcuts in param_values before substitution.
    Shortcuts are case-insensitive and resolved to YYYY-MM-DD strings.

    Supported shortcuts:
      today, yesterday, tomorrow
      week_start / week_end          — Mon/Sun of current ISO week
      last_week_start / last_week_end
      month_start / month_end
      last_month_start / last_month_end
      year_start / year_end
      last_year_start / last_year_end
      -Nd / +Nd                       — relative days (e.g. -7d = 7 days ago)
    """
    today = _date.today()

    def _first(d): return d.replace(day=1)
    def _last(d):
        m2 = d.month % 12 + 1
        y2 = d.year + (1 if d.month == 12 else 0)
        return _date(y2, m2, 1) - timedelta(days=1)

    last_month_last = _first(today) - timedelta(days=1)
    shortcuts = {
        "today":             today,
        "yesterday":         today - timedelta(days=1),
        "tomorrow":          today + timedelta(days=1),
        "week_start":        today - timedelta(days=today.weekday()),
        "week_end":          today + timedelta(days=6 - today.weekday()),
        "last_week_start":   today - timedelta(days=today.weekday() + 7),
        "last_week_end":     today - timedelta(days=today.weekday() + 1),
        "month_start":       _first(today),
        "month_end":         _last(today),
        "last_month_start":  _first(last_month_last),
        "last_month_end":    last_month_last,
        "year_start":        _date(today.year, 1, 1),
        "year_end":          _date(today.year, 12, 31),
        "last_year_start":   _date(today.year - 1, 1, 1),
        "last_year_end":     _date(today.year - 1, 12, 31),
    }

    result = {}
    for key, val in param_values.items():
        if not isinstance(val, str):
            result[key] = val
            continue
        norm = val.strip().lower()
        if norm in shortcuts:
            result[key] = shortcuts[norm].isoformat()
        else:
            m = _RELATIVE_RE.match(val.strip())
            if m:
                sign = 1 if m.group(1) == "+" else -1
                result[key] = (today + timedelta(days=sign * int(m.group(2)))).isoformat()
            else:
                result[key] = val
    return result


# ── Pydantic models ───────────────────────────────────────────────────────────

class ParameterDef(BaseModel):
    name:          str
    label:         str
    type:          str = "string"   # string | number | date | boolean | select
    required:      bool = False
    default_value: Optional[Any] = None
    description:   Optional[str] = None
    options:       Optional[List[str]] = None   # for select type


class CreateReportRequest(BaseModel):
    name:                     str
    description:              Optional[str] = None
    saved_query_id:           Optional[int] = None
    sql_saved_query_id:       Optional[int] = None
    parameters:               List[ParameterDef] = []
    sql_override:             Optional[str] = None
    is_public:                bool = True
    created_by:               Optional[str] = None
    connection_override_id:   Optional[int] = None   # Phase 24A


class UpdateReportRequest(BaseModel):
    name:                     Optional[str] = None
    description:              Optional[str] = None
    saved_query_id:           Optional[int] = None
    sql_saved_query_id:       Optional[int] = None
    parameters:               Optional[List[ParameterDef]] = None
    sql_override:             Optional[str] = None
    is_public:                Optional[bool] = None
    connection_override_id:   Optional[int] = None   # Phase 24A; send 0 to explicitly clear


class ExecuteReportRequest(BaseModel):
    param_values: Dict[str, Any] = {}
    row_limit:    Optional[int]  = None
    executed_by:  Optional[str]  = None


# ── CRUD endpoints ────────────────────────────────────────────────────────────

def _require_db():
    """Raise 503 with a helpful message when the DB manager hasn't been injected yet."""
    if _db_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Reports service not ready — the server may still be starting up or needs a restart.",
        )
    return _db_manager


@router.get("/api/reports")
async def list_reports(
    request: Request,
    active_only: bool = True,
    limit: int = QParam(200, ge=1, le=1000),
    offset: int = QParam(0, ge=0),
):
    db = _require_db()
    items = await _run_in_executor(db.list_reports, active_only, limit, offset)
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_rpt(request)
        items = [i for i in items if _is_owner_or_shared_rpt(i, user)]
    return items


@router.post("/api/reports", status_code=201)
async def create_report(req: CreateReportRequest, request: Request):
    db = _require_db()
    user = _get_current_user_rpt(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    if not req.saved_query_id and not req.sql_saved_query_id:
        raise HTTPException(400, "Must specify either saved_query_id or sql_saved_query_id")
    if req.saved_query_id and req.sql_saved_query_id:
        raise HTTPException(400, "Specify only one source: saved_query_id or sql_saved_query_id")
    return await _run_in_executor(
        db.create_report,
        name=req.name,
        description=req.description,
        saved_query_id=req.saved_query_id,
        sql_saved_query_id=req.sql_saved_query_id,
        parameters=[p.model_dump() for p in req.parameters],
        sql_override=req.sql_override,
        is_public=req.is_public,
        created_by=(user or {}).get("username") or req.created_by or "guest",
    )


# ── Static GET routes — defined BEFORE {report_id} to avoid Starlette shadowing ──

def _normalise_cols(raw: list) -> List[Dict[str, str]]:
    out = []
    for c in (raw or []):
        if isinstance(c, dict):
            name = c.get("name") or c.get("column_name") or ""
            ctype = c.get("type") or c.get("column_type") or "unknown"
        else:
            name, ctype = str(c), "unknown"
        if name:
            out.append({"name": name, "type": ctype})
    return out


def _get_parquet_schema_columns(files: list, db=None) -> List[Dict[str, str]]:
    """
    Return all columns from the first readable source in `files`.
    Handles all path prefixes used by QueryStudio:
      __local__:name          — LocalTable (schema_json from DB)
      __materialized__:name   — MaterializedView parquet storage
      __registered__:name     — S3 registered table (schema cache / materialized copy)
      s3://...                — direct S3 (skipped — needs live credentials)
      <filename>              — local parquet (DuckDB DESCRIBE + PyArrow fallback)
    """
    _log = logging.getLogger(__name__)
    try:
        from core.config import _paths, materialized_views as _mv_cfg
        data_dir = Path(str(_paths.parquet_dir))
        mv_storage = Path(_mv_cfg.storage_dir)
    except Exception:
        data_dir = Path("./data/parquet")
        mv_storage = None

    for fname in (files or [])[:10]:
        fname = str(fname)

        # ── Local table ────────────────────────────────────────────────────────
        if fname.startswith("__local__:"):
            lt_name = fname[len("__local__:"):]
            if db:
                try:
                    lt = db.get_local_table_by_name(lt_name)
                    if lt and lt.get("schema_json"):
                        cols = _normalise_cols(lt["schema_json"])
                        if cols:
                            return cols
                    if lt and lt.get("storage_path"):
                        import glob as _gm
                        pqs = sorted(_gm.glob(str(Path(lt["storage_path"]) / "*.parquet")))
                        if pqs:
                            r = _get_parquet_schema_columns([pqs[0]])
                            if r:
                                return r
                except Exception as exc:
                    _log.debug("__local__ schema %s: %s", lt_name, exc)
            continue

        # ── Materialized view ──────────────────────────────────────────────────
        if fname.startswith("__materialized__:"):
            mv_name = fname[len("__materialized__:"):]
            if db and mv_storage:
                try:
                    mv = db.get_materialized_view_by_name(mv_name)
                    if mv:
                        import glob as _gm
                        pqs = sorted(_gm.glob(str(mv_storage / str(mv["id"]) / "*.parquet")))
                        if pqs:
                            r = _get_parquet_schema_columns([pqs[0]])
                            if r:
                                return r
                except Exception as exc:
                    _log.debug("__materialized__ schema %s: %s", mv_name, exc)
            continue

        # ── Registered S3 table ────────────────────────────────────────────────
        if fname.startswith("__registered__:"):
            tbl_name = fname[len("__registered__:"):]
            if db:
                try:
                    # Prefer local materialized copy
                    if mv_storage:
                        mv = db.get_materialized_view_by_name(tbl_name)
                        if mv:
                            import glob as _gm
                            pqs = sorted(_gm.glob(str(mv_storage / str(mv["id"]) / "*.parquet")))
                            if pqs:
                                r = _get_parquet_schema_columns([pqs[0]])
                                if r:
                                    return r
                    # Fall back to schema cache (fetched on previous browse)
                    cached = db.find_schema_cache_by_name(tbl_name)
                    if cached:
                        cols = _normalise_cols((cached.get("schema_data") or {}).get("columns") or [])
                        if cols:
                            return cols
                except Exception as exc:
                    _log.debug("__registered__ schema %s: %s", tbl_name, exc)
            continue

        # ── S3 streaming (s3://...) — skip, needs live credentials ────────────
        if fname.startswith("s3://"):
            continue

        # ── Local parquet file ─────────────────────────────────────────────────
        candidates = [data_dir / fname, Path(fname)]
        path = next((p for p in candidates if p.exists()), None)
        if path is None:
            _log.debug("preview-columns: file not found %s", fname)
            continue
        p_posix = path.resolve().as_posix().replace("'", "''")

        try:
            import duckdb as _ddb
            con = _ddb.connect(":memory:")
            try:
                rows = con.execute(
                    f"DESCRIBE SELECT * FROM read_parquet('{p_posix}')"
                ).fetchall()
            finally:
                con.close()
            cols = [{"name": r[0], "type": r[1]} for r in rows if r[0]]
            if cols:
                return cols
        except Exception as exc:
            _log.debug("preview-columns DuckDB %s: %s", fname, exc)

        try:
            from core.parquet_engine import ParquetEngine
            info = ParquetEngine(str(data_dir)).get_file_schema(fname)
            cols = _normalise_cols(info.get("columns", []) if isinstance(info, dict) else info)
            if cols:
                return cols
        except Exception:
            pass

    return []


@router.get("/api/reports/preview-columns")
async def get_preview_columns(saved_query_id: Optional[int] = None):
    """
    Return available column names for a source query — used by the
    frontend BEFORE a report is created (create mode).
    Handles local parquet, local tables, materialized views, registered S3 tables.
    """
    db = _require_db()
    columns: List[Dict[str, str]] = []
    if saved_query_id:
        sq = await _run_in_executor(db.get_query, saved_query_id)
        if sq:
            files = (sq.get("query_config") or {}).get("files") or []
            columns = await _run_in_executor(_get_parquet_schema_columns, files, db)
    return {"columns": columns, "source_type": "parquet" if saved_query_id else "sql"}


@router.get("/api/reports/connector-matrix")
async def get_report_connector_matrix(request: Request):
    """Return all reports with their connection assignment details."""
    db = _require_db()
    reports = await _run_in_executor(db.list_reports, False, 10000, 0)
    conn_cache: Dict[int, Optional[dict]] = {}

    def _conn_summary(conn_id: Optional[int]) -> Optional[dict]:
        if not conn_id:
            return None
        if conn_id not in conn_cache:
            c = db.get_connection_raw(conn_id)
            conn_cache[conn_id] = {"id": c["id"], "name": c["name"],
                                   "connection_type": c["connection_type"]} if c else None
        return conn_cache[conn_id]

    result = []
    for r in reports:
        entry: Dict[str, Any] = {
            "id":                        r["id"],
            "name":                      r["name"],
            "description":               r.get("description"),
            "source_type":               "parquet" if r.get("saved_query_id") else "sql",
            "assigned_connection":       None,
            "override_connection":       None,
            "effective_connection":      None,
            "profile_mapped_connection": None,
        }
        if r.get("sql_saved_query_id"):
            sq = db.get_sql_query(r["sql_saved_query_id"])
            if sq:
                entry["assigned_connection"] = _conn_summary(sq.get("primary_connection_id"))
        if r.get("connection_override_id"):
            entry["override_connection"] = _conn_summary(r["connection_override_id"])
        eff = entry["override_connection"] or entry["assigned_connection"]
        entry["effective_connection"] = eff
        if eff:
            mapped_id = db.resolve_connection_via_profile(eff["id"])
            if mapped_id != eff["id"]:
                entry["profile_mapped_connection"] = _conn_summary(mapped_id)
        result.append(entry)
    return {"reports": result}


class BulkConnectionOverrideRequest(BaseModel):
    report_ids:             List[int]
    connection_override_id: Optional[int] = None  # None clears the override


@router.post("/api/reports/bulk-set-connection-override")
async def bulk_set_connection_override(req: BulkConnectionOverrideRequest, request: Request):
    """Set or clear connection_override_id for multiple reports at once (admin only)."""
    db = _require_db()
    user = _get_current_user_rpt(request)
    if _auth_cfg and _auth_cfg.type != "none":
        if (user or {}).get("role") != "admin":
            raise HTTPException(403, "Bulk connection override requires admin role")
    updated = 0
    for rid in req.report_ids:
        res = await _run_in_executor(db.update_report, rid,
                                     connection_override_id=req.connection_override_id)
        if res:
            updated += 1
    return {"updated": updated, "requested": len(req.report_ids)}


@router.get("/api/reports/{report_id}")
async def get_report(report_id: int, request: Request):
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")
    # RLS: non-admins can only see own or public reports
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_rpt(request)
        if not _is_owner_or_shared_rpt(r, user):
            raise HTTPException(404, f"Report {report_id} not found")
    return r


@router.put("/api/reports/{report_id}")
async def update_report(report_id: int, req: UpdateReportRequest, request: Request):
    db = _require_db()
    user = _get_current_user_rpt(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(db.get_report, report_id)
    if not existing:
        raise HTTPException(404, f"Report {report_id} not found")
    # RLS: non-admins can only update their own reports
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(403, "Permission denied")
    updates = req.model_dump(exclude_none=True)
    if "parameters" in updates:
        updates["parameters"] = [p.model_dump() if hasattr(p, "model_dump") else p for p in (req.parameters or [])]
    # Phase 24A: explicit zero means "clear the override" (None is excluded above)
    if updates.get("connection_override_id") == 0:
        updates["connection_override_id"] = None
    result = await _run_in_executor(db.update_report, report_id, **updates)
    if not result:
        raise HTTPException(404, f"Report {report_id} not found")
    return result


@router.delete("/api/reports/{report_id}")
async def delete_report(report_id: int, request: Request, permanent: bool = False):
    db = _require_db()
    user = _get_current_user_rpt(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(db.get_report, report_id)
    if not existing:
        raise HTTPException(404, f"Report {report_id} not found")
    # RLS: non-admins can only delete their own reports
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(403, "Permission denied")
    success = await _run_in_executor(db.delete_report, report_id, not permanent)
    if not success:
        raise HTTPException(404, f"Report {report_id} not found")
    return {"message": "Deleted", "report_id": report_id}


@router.get("/api/reports/{report_id}/source-info")
async def get_report_source_info(report_id: int):
    """Return info about the report's underlying source query."""
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    info: Dict[str, Any] = {"report_id": report_id, "name": r["name"]}

    if r["saved_query_id"]:
        sq = await _run_in_executor(db.get_query, r["saved_query_id"])
        info["source_type"] = "parquet"
        info["source"] = sq
    elif r["sql_saved_query_id"]:
        sq = await _run_in_executor(db.get_sql_query, r["sql_saved_query_id"])
        info["source_type"] = "sql"
        info["source"] = sq
    return info


@router.get("/api/reports/{report_id}/param-values")
async def get_report_param_values(
    report_id: int,
    param_name: str,
    limit: int = QParam(1000, ge=1, le=10000),
):
    """
    Return sorted distinct non-null values for a column (param_name) from the
    report's parquet source.  Used by the frontend to auto-populate multi-select
    parameter dropdowns.

    For SQL-backed reports, returns an empty list (schema unknown until execution).
    """
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    values: List[str] = []
    truncated = False

    if r.get("saved_query_id"):
        values, truncated = await _run_in_executor(
            _fetch_distinct_parquet_values, r, param_name, limit
        )

    return {
        "report_id":  report_id,
        "param_name": param_name,
        "values":     values,
        "total":      len(values),
        "truncated":  truncated,
    }


@router.get("/api/reports/{report_id}/columns")
async def get_report_columns(report_id: int):
    """
    Return available column names for the report's source query (edit mode).
    For Parquet: reads schema from the saved query's files.
    For SQL: returns empty list (schema only known at execution time).
    """
    db = _require_db()
    r = await _run_in_executor(db.get_report, report_id)
    if not r:
        raise HTTPException(404, f"Report {report_id} not found")

    columns: List[Dict[str, str]] = []
    if r.get("saved_query_id"):
        sq = await _run_in_executor(db.get_query, r["saved_query_id"])
        if sq:
            files = (sq.get("query_config") or {}).get("files") or []
            columns = await _run_in_executor(_get_parquet_schema_columns, files)

    return {
        "report_id": report_id,
        "source_type": "parquet" if r.get("saved_query_id") else "sql",
        "columns": columns,
        "date_shortcuts": BUSINESS_DATE_SHORTCUTS,
    }


class SuggestParamsRequest(BaseModel):
    source_type: str  # "parquet" or "sql"
    saved_query_id: Optional[int] = None
    sql_saved_query_id: Optional[int] = None


@router.post("/api/reports/suggest-params")
async def suggest_report_params(req: SuggestParamsRequest):
    """
    Auto-detect partition/clustering columns from the report's data source
    and return suggested parameter definitions.

    For S3/Parquet: scans file paths for Hive-style key=value partitions.
    For SQL (Trino/Snowflake): inspects table DDL for partition/clustering columns.
    """
    db = _require_db()
    partitions: List[Dict[str, Any]] = []
    source_info: Dict[str, Any] = {}

    if req.source_type == "parquet" and req.saved_query_id:
        sq = await _run_in_executor(db.get_query, req.saved_query_id)
        if not sq:
            raise HTTPException(404, f"Saved query {req.saved_query_id} not found")
        source_info = {"type": "parquet", "query_name": sq.get("name", "")}
        partitions = await _run_in_executor(_detect_s3_partitions, sq)

        # Also try Iceberg detection if no Hive partitions found
        if not partitions:
            try:
                iceberg_parts = await _run_in_executor(_detect_iceberg_partitions, sq)
                partitions.extend(iceberg_parts)
            except Exception:
                pass

    elif req.source_type == "sql" and req.sql_saved_query_id:
        sq = await _run_in_executor(db.get_sql_query, req.sql_saved_query_id)
        if not sq:
            raise HTTPException(404, f"SQL query {req.sql_saved_query_id} not found")
        source_info = {"type": "sql", "query_name": sq.get("name", "")}
        partitions = await _run_in_executor(_detect_sql_partitions, sq)

    else:
        raise HTTPException(400, "Provide saved_query_id (parquet) or sql_saved_query_id (sql)")

    suggested = _partitions_to_params(partitions)

    # Generate a WHERE clause snippet for SQL reports so users can see
    # what will be auto-injected, or copy-paste into their SQL override.
    where_parts = []
    for p in suggested:
        name = p["name"]
        if p.get("type") == "date":
            where_parts.append(f'"{name}" >= \'{{{name}}}\'')
        elif p.get("type") == "multiselect":
            where_parts.append(f'"{name}" IN ({{{name}}})')
        else:
            where_parts.append(f'"{name}" = \'{{{name}}}\'')
    suggested_where = " AND ".join(where_parts) if where_parts else ""

    return {
        "suggested_params": suggested,
        "raw_partitions": partitions,
        "source_info": source_info,
        "suggested_where": f"WHERE {suggested_where}" if suggested_where else "",
    }


def _detect_iceberg_partitions(saved_query: dict) -> List[Dict[str, Any]]:
    """Try to detect Iceberg partitions via metadata if available."""
    try:
        from core.iceberg_reader import get_iceberg_partition_values
    except ImportError:
        return []

    files = (saved_query.get("query_config") or {}).get("files") or []
    if not files:
        return []
    # Check if any file path looks like an Iceberg table (has metadata/ subfolder)
    # This is a heuristic — we look at the file prefix
    first_file = files[0].replace("\\", "/")
    # Iceberg data files are typically under <table>/data/ — look for that pattern
    if "/data/" not in first_file:
        return []

    # Extract table prefix (everything before /data/)
    table_prefix = first_file.split("/data/")[0]
    # We'd need an S3 client to read Iceberg metadata — skip if not available
    # This path is for future enhancement when S3 connection context is passed
    return []


@router.get("/api/reports/{report_id}/download")
async def download_report(report_id: int, request: Request,
                          format: str = QParam("csv", pattern="^(csv|xlsx)$")):
    """
    Synchronous download for API/automation/curl access.
    Pass parameter values as query string:
      GET /api/reports/5/download?start_date=month_start&region=EMEA&format=xlsx

    Supported formats: csv (default), xlsx (Excel).
    Date shortcuts (today, yesterday, month_start, -7d, etc.) are resolved automatically.
    """
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    # Exclude 'format' from param_values — it's not a report parameter
    raw_params = {k: v for k, v in request.query_params.items() if k != "format"}
    param_values = resolve_business_dates(raw_params)
    errors = validate_param_values(report["parameters"], param_values)
    if errors:
        raise HTTPException(400, detail={"errors": errors})

    execution_id = str(uuid.uuid4())
    output_dir = Path("./data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_output_path = str(output_dir / f"{execution_id}.csv")

    noop = lambda _: None

    try:
        if report["saved_query_id"]:
            await _run_in_executor(_run_parquet_report, report, param_values, None, csv_output_path, noop)
            csv_path = Path(csv_output_path)
        elif report["sql_saved_query_id"]:
            await _run_in_executor(_run_sql_report, report, param_values, None, execution_id, noop)
            from api.data_grid_api import find_csv_file
            actual = find_csv_file(execution_id)
            if actual and actual.suffix.lower() == ".parquet":
                df_tmp = pd.read_parquet(actual)
                df_tmp.to_csv(csv_output_path, index=False)
                csv_path = Path(csv_output_path)
            else:
                csv_path = actual if actual else Path(csv_output_path)
        else:
            raise HTTPException(400, "Report has no source configured")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))

    if not csv_path.exists():
        raise HTTPException(500, "Report execution produced no output")

    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", report["name"])
    ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')

    if format == "xlsx":
        xlsx_path = str(output_dir / f"{execution_id}.xlsx")
        try:
            df_export = pd.read_csv(csv_path)
            df_export.to_excel(xlsx_path, index=False, engine="openpyxl")
        except Exception:
            # Fallback: try reading as parquet
            parquet_file = output_dir / f"{execution_id}.parquet"
            if parquet_file.exists():
                df_export = pd.read_parquet(parquet_file)
                df_export.to_excel(xlsx_path, index=False, engine="openpyxl")
            else:
                raise HTTPException(500, "Failed to generate Excel file")
        return FileResponse(
            path=xlsx_path,
            filename=f"report_{safe_name}_{ts}.xlsx",
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    filename = f"report_{safe_name}_{ts}.csv"
    return FileResponse(path=str(csv_path), filename=filename, media_type="text/csv")


# ── Result caching helpers ────────────────────────────────────────────────────

import hashlib  # noqa: E402 — grouped with caching helpers below


def _report_cache_key(report_id: int, param_values: dict) -> str:
    """Generate a deterministic cache key from report ID + sorted param values."""
    canon = f"{report_id}:" + "&".join(
        f"{k}={v}" for k, v in sorted(param_values.items())
    )
    return hashlib.sha256(canon.encode()).hexdigest()[:48]


def _find_cached_execution(db, cache_key: str, max_age_minutes: int) -> Optional[dict]:
    """Find a recent completed execution with matching cache key."""
    if max_age_minutes <= 0 or not cache_key:
        return None
    try:
        execs = db.list_executions(limit=50)
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=max_age_minutes)
        for ex in execs:
            cfg = ex.get("query_config") or {}
            if (cfg.get("cache_key") == cache_key
                    and ex.get("status") == "completed"
                    and ex.get("output_file")):
                created = ex.get("created_at")
                if isinstance(created, str):
                    from datetime import datetime as _dt
                    try:
                        created = _dt.fromisoformat(created.replace("Z", "+00:00"))
                    except Exception:
                        continue
                if created and created >= cutoff:
                    # Verify output file still exists
                    if Path(ex["output_file"]).exists():
                        return ex
        return None
    except Exception:
        return None


# ── Execute endpoint ──────────────────────────────────────────────────────────

@router.post("/api/reports/{report_id}/execute")
async def execute_report(report_id: int, req: ExecuteReportRequest):
    """
    Execute a report with parameter values.
    Runs asynchronously — returns execution_id immediately.
    If cache_ttl_minutes > 0 on the report, returns cached result when available.
    Progress / completion broadcast via WebSocket.
    """
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    # Resolve date shortcuts then validate required parameters
    param_values = resolve_business_dates(req.param_values)
    errors = validate_param_values(report["parameters"], param_values)
    if errors:
        raise HTTPException(400, detail={"errors": errors})

    # ── Check cache ──────────────────────────────────────────────────────────
    cache_ttl = report.get("cache_ttl_minutes", 0) or 0
    cache_key = _report_cache_key(report_id, param_values) if cache_ttl > 0 else ""
    if cache_ttl > 0:
        cached = await _run_in_executor(_find_cached_execution, db, cache_key, cache_ttl)
        if cached:
            return {
                "execution_id": cached["execution_id"],
                "status": "completed",
                "message": f"Returning cached result (age < {cache_ttl}min)",
                "cached": True,
            }

    execution_id = str(uuid.uuid4())

    try:
        current_loop = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    def _run(cancel_event=None):
        def _emit(payload):
            loop = current_loop or _main_loop
            if _ws_manager and loop:
                asyncio.run_coroutine_threadsafe(
                    _ws_manager.broadcast({**payload, "execution_id": execution_id}),
                    loop,
                )

        try:
            _emit({"type": "execution_progress", "data": {"status": "starting"}})

            output_dir = Path("./data/downloads")
            output_dir.mkdir(parents=True, exist_ok=True)
            # Both parquet-backed and SQL-backed reports write .parquet (fast columnar format)
            output_path = str(output_dir / f"{execution_id}.parquet")

            if report["saved_query_id"]:
                total_rows = _run_parquet_report(
                    report, param_values, req.row_limit, output_path, _emit
                )
            elif report["sql_saved_query_id"]:
                total_rows = _run_sql_report(
                    report, param_values, req.row_limit, execution_id, _emit
                )
                # SQL engine writes {execution_id}.parquet via cross_source_engine
            else:
                raise ValueError("Report has no source configured")

            # Track execution — temp file is NOT registered in Download Center;
            # user exports explicitly via the grid Export button.
            db.create_execution(
                execution_id=execution_id,
                query_config={
                    "report_id": report_id,
                    "param_values": req.param_values,
                    "query_type": "report",
                    "cache_key": cache_key,
                },
            )
            db.update_execution(execution_id, status="completed", total_rows=total_rows, output_file=output_path)
            db.increment_report_execution(report_id)

            _emit({
                "type": "execution_completed",
                "stats": {"total_rows": total_rows},
            })
        except Exception as exc:
            logger.exception(f"[{execution_id}] Report execution failed")
            try:
                db.update_execution(execution_id, status="failed", error_message=str(exc))
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "reports_api", exc, exc_info=True)
            _emit({"type": "execution_failed", "error": str(exc)})

    # Submit via unified worker pool (falls back to legacy executor)
    try:
        from core.worker_pool import get_pool, WorkType
        get_pool().submit_sync(WorkType.REPORT, _run,
                               execution_id=execution_id, username="system")
    except RuntimeError:
        _rpt_executor.submit(_run)

    return {
        "execution_id": execution_id,
        "status": "running",
        "message": f"Report '{report['name']}' execution started",
    }


# ── Execution history ────────────────────────────────────────────────────────

@router.get("/api/reports/{report_id}/history")
async def get_report_history(
    report_id: int,
    limit: int = QParam(20, ge=1, le=100),
):
    """Return recent execution history for a report."""
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    all_execs = await _run_in_executor(db.list_executions, limit=200)
    history = []
    for ex in all_execs:
        cfg = ex.get("query_config") or {}
        if cfg.get("report_id") == report_id:
            history.append({
                "execution_id": ex["execution_id"],
                "status": ex.get("status", "unknown"),
                "total_rows": ex.get("total_rows"),
                "created_at": ex.get("created_at"),
                "param_values": cfg.get("param_values", {}),
                "duration_seconds": ex.get("duration_seconds"),
                "cached": bool(cfg.get("cache_key")),
            })
            if len(history) >= limit:
                break

    return {
        "report_id": report_id,
        "report_name": report.get("name", ""),
        "executions": history,
        "total": len(history),
    }


# ── Schedule endpoints ───────────────────────────────────────────────────────

class ScheduleReportRequest(BaseModel):
    cron: str                          # e.g. "0 8 * * 1-5"
    recipients: List[str] = []         # email addresses
    format: str = "csv"                # csv | xlsx
    enabled: bool = True


@router.post("/api/reports/{report_id}/schedule")
async def schedule_report(report_id: int, req: ScheduleReportRequest, request: Request):
    """Set up a recurring schedule for a report."""
    db = _require_db()
    user = _get_current_user_rpt(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")

    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    schedule_config = {
        "cron": req.cron,
        "recipients": req.recipients,
        "format": req.format,
        "enabled": req.enabled,
        "scheduled_by": (user or {}).get("username", "guest"),
    }

    await _run_in_executor(
        db.update_report, report_id, schedule_config=schedule_config
    )

    # Register with APScheduler if available
    try:
        from core.scheduler import get_scheduler
        sched = get_scheduler()
        if sched:
            job_id = f"report_schedule_{report_id}"
            if req.enabled:
                from apscheduler.triggers.cron import CronTrigger
                trigger = CronTrigger.from_crontab(req.cron)
                sched.add_job(
                    _execute_scheduled_report,
                    trigger=trigger,
                    id=job_id,
                    replace_existing=True,
                    args=[report_id, schedule_config],
                    name=f"Report: {report.get('name', report_id)}",
                )
            else:
                try:
                    sched.remove_job(job_id)
                except Exception:
                    pass
    except Exception:
        logger.debug("Scheduler not available for report scheduling", exc_info=True)

    return {"message": "Schedule saved", "report_id": report_id, "schedule": schedule_config}


@router.delete("/api/reports/{report_id}/schedule")
async def unschedule_report(report_id: int, request: Request):
    """Remove scheduled execution for a report."""
    db = _require_db()
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    await _run_in_executor(db.update_report, report_id, schedule_config=None)

    try:
        from core.scheduler import get_scheduler
        sched = get_scheduler()
        if sched:
            sched.remove_job(f"report_schedule_{report_id}")
    except Exception:
        pass

    return {"message": "Schedule removed", "report_id": report_id}


def _execute_scheduled_report(report_id: int, schedule_config: dict):
    """Callback for APScheduler — execute a report and optionally email results."""
    try:
        db = _db_manager
        if not db:
            return
        report = db.get_report(report_id)
        if not report or not report.get("is_active"):
            return

        execution_id = str(uuid.uuid4())
        output_dir = Path("./data/downloads")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / f"{execution_id}.parquet")

        # Use default parameter values
        param_values = {}
        for p in (report.get("parameters") or []):
            if p.get("default_value") is not None:
                param_values[p["name"]] = p["default_value"]
        param_values = resolve_business_dates(param_values)

        noop = lambda _: None
        if report["saved_query_id"]:
            total_rows = _run_parquet_report(report, param_values, None, output_path, noop)
        elif report["sql_saved_query_id"]:
            total_rows = _run_sql_report(report, param_values, None, execution_id, noop)
        else:
            return

        db.create_execution(
            execution_id=execution_id,
            query_config={"report_id": report_id, "param_values": param_values,
                         "query_type": "scheduled_report"},
        )
        db.update_execution(execution_id, status="completed", total_rows=total_rows,
                          output_file=output_path)
        db.increment_report_execution(report_id)

        # Email results if recipients configured
        recipients = schedule_config.get("recipients", [])
        if recipients:
            try:
                from core.email_service import send_email
                report_name = report.get("name", "Report")
                fmt = schedule_config.get("format", "csv")
                download_url = f"/api/reports/{report_id}/download?format={fmt}"
                html_body = (
                    f"<h3>Scheduled Report: {report_name}</h3>"
                    f"<p>Execution completed with <strong>{total_rows}</strong> rows.</p>"
                    f"<p><a href='{download_url}'>Download {fmt.upper()}</a></p>"
                )
                send_email(
                    to_addresses=recipients,
                    subject=f"Scheduled Report: {report_name}",
                    html_body=html_body,
                )
            except Exception:
                logger.warning("Failed to email scheduled report %s", report_id, exc_info=True)

        logger.info("Scheduled report %s executed: %s rows", report_id, total_rows)
    except Exception:
        logger.exception("Scheduled report %s failed", report_id)


# ── Distinct-values helper ────────────────────────────────────────────────────

def _fetch_distinct_parquet_values(report: dict, param_name: str, limit: int):
    """
    Return (sorted_values, truncated) for `param_name` column from the report's
    parquet saved-query source.  Uses DuckDB so large files are read cheaply.
    """
    try:
        import duckdb as _duckdb
    except ImportError:
        return [], False

    saved_q = _db_manager.get_query(report["saved_query_id"])
    files = (saved_q.get("query_config") or {}).get("files") or []
    if not files:
        return [], False

    # Sanitise column name — strip quotes to prevent injection, then re-quote
    col = param_name.replace('"', '').replace("'", "")

    values: set = set()
    data_dir = Path("./data/parquet")

    for fname in files[:20]:          # cap at 20 files to keep response fast
        # Resolve path: try relative-to-data-dir first, then absolute
        candidates = [
            data_dir / fname,
            Path(fname),
        ]
        path = next((p for p in candidates if p.exists()), None)
        if path is None:
            continue

        p_posix = path.resolve().as_posix().replace("'", "''")
        try:
            con = _duckdb.connect(":memory:")
            try:
                rows = con.execute(
                    f'SELECT DISTINCT "{col}" '
                    f'FROM read_parquet(\'{p_posix}\') '
                    f'WHERE "{col}" IS NOT NULL '
                    f'LIMIT {limit + 1}'
                ).fetchall()
            finally:
                con.close()
            values.update(str(r[0]) for r in rows)
            if len(values) > limit:
                return sorted(values)[:limit], True
        except Exception as exc:
            logging.getLogger(__name__).warning("%s failed: %s", "reports_api", exc, exc_info=True)
            continue

    sorted_vals = sorted(values)
    return sorted_vals[:limit], len(sorted_vals) > limit


# ── Internal execution helpers ────────────────────────────────────────────────

def _cast_scalar(v):
    """Try int → float → str so PyArrow type-matching works on numeric columns."""
    s = str(v).strip()
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    return s


def _run_parquet_report(report: dict, param_values: dict, row_limit: Optional[int],
                        output_path: str, emit) -> int:
    """Execute the parquet saved query backing this report."""
    from core.optimized_engine import OptimizedParquetEngine, QueryConfig as OptQC

    saved_q  = _db_manager.get_query(report["saved_query_id"])
    qc_dict  = dict(saved_q["query_config"])

    # ── Step 1: find which params are handled by existing {placeholder} filters ──
    original_filters = list(qc_dict.get("filters") or [])
    handled_by_placeholder: set = set()
    for f in original_filters:
        m = _PARAM_RE.fullmatch(str(f.get("value", "")))
        if m:
            handled_by_placeholder.add(m.group(1))

    # ── Step 2: substitute {param_name} placeholders in existing filters ────────
    if qc_dict.get("filters"):
        qc_dict["filters"] = substitute_filter_params(qc_dict["filters"], param_values)
    else:
        qc_dict["filters"] = []

    # ── Step 3: auto-apply any report param not already handled via placeholder ─
    # This lets users add parameters by column name without needing to pre-wire
    # {param_name} placeholders in the saved query's filter definitions.
    for p in (report.get("parameters") or []):
        name = p["name"]
        if name in handled_by_placeholder:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue  # nothing provided

        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue  # empty list = no restriction (all rows)
            # Cast each element for PyArrow type compatibility
            cast_vals = [_cast_scalar(v) for v in val]
            if len(cast_vals) == 1:
                qc_dict["filters"].append({"column": name, "operator": "eq", "value": cast_vals[0]})
            else:
                qc_dict["filters"].append({"column": name, "operator": "in", "value": cast_vals})
        else:
            qc_dict["filters"].append({"column": name, "operator": "eq", "value": _cast_scalar(val)})

    # Apply row_limit override
    if row_limit:
        qc_dict["limit"] = row_limit

    def _dict_to_optimized(d: dict) -> OptQC:
        return OptQC(
            files=d.get("files", []),
            columns=d.get("columns"),
            filters=d.get("filters"),
            joins=d.get("joins"),
            order_by=d.get("order_by"),
            limit=d.get("limit"),
        )

    engine = OptimizedParquetEngine(data_dir="./data/parquet")
    config = _dict_to_optimized(qc_dict)

    emit({"type": "execution_progress", "data": {"status": "processing"}})
    chunks = list(engine.execute_query(config))
    df = pd.concat(chunks, ignore_index=True) if chunks else pd.DataFrame()

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    if output_path.endswith(".parquet"):
        df.to_parquet(output_path, index=False, engine="pyarrow")
    else:
        df.to_csv(output_path, index=False)
    return len(df)


_FILE_CONN_TYPES = frozenset({"s3", "local", "upload"})
_SQL_CONN_TYPES  = frozenset({"trino", "starburst", "snowflake", "databricks", "oracle"})


def _resolve_data_dir(conn: dict) -> str:
    """Resolve the data directory for a file-based connection."""
    ctype = conn["connection_type"]
    if ctype == "s3":
        return conn["config"].get("bucket", "./data/parquet")
    elif ctype == "local":
        return conn["config"].get("path", "./data/parquet")
    elif ctype == "upload":
        return f"./data/uploads/{conn['id']}"
    return "./data/parquet"


def _resolve_primary_connection(report: dict, sql_q: dict) -> dict:
    """Resolve which Connection to use for the primary SQL query.

    Resolution order (Phase 24A + 24B):
      1. report['connection_override_id']  — explicit per-report override
      2. sql_q['primary_connection_id']    — existing default (unchanged behaviour)
      Then: apply active ConnectionProfile mapping (Phase 24B; no-op when no profile active)

    Raises ValueError if the resolved connection does not exist.
    """
    override_id = report.get("connection_override_id")
    base_conn_id = override_id if override_id else sql_q["primary_connection_id"]
    # Phase 24B: apply active profile substitution (returns base_conn_id unchanged if no profile)
    final_conn_id = _db_manager.resolve_connection_via_profile(base_conn_id)
    conn = _db_manager.get_connection_raw(final_conn_id)
    if not conn:
        raise ValueError(f"Connection {final_conn_id} not found")
    return conn


def _run_sql_report(report: dict, param_values: dict, row_limit: Optional[int],
                    execution_id: str, emit) -> int:
    """Execute the SQL saved query backing this report.
    Supports three modes:
      1. Single SQL source
      2. Cross-source SQL-to-SQL join
      3. Hybrid SQL-to-Parquet join (Starburst + S3)
    """
    from core.cross_source_engine import (
        execute_single_source_query, execute_cross_source_query, execute_hybrid_query,
    )

    sql_q = _db_manager.get_sql_query(report["sql_saved_query_id"])

    primary_conn = _resolve_primary_connection(report, sql_q)  # Phase 24A/24B

    # Use sql_override if set, otherwise use the saved query's SQL
    raw_sql = report.get("sql_override") or sql_q["primary_sql"]

    # ── Step 1: substitute {param_name} placeholders in SQL ──────────────────
    primary_sql = substitute_sql_params(raw_sql, param_values, report["parameters"])

    # ── Step 2: auto-append WHERE for unreferenced partition params ───────────
    # Same concept as Parquet Step 3: if a param has a value but isn't wired as
    # {param_name} in the SQL, inject it as a WHERE condition automatically.
    referenced_params = set(_PARAM_RE.findall(raw_sql))
    primary_sql = _auto_append_sql_where(primary_sql, report.get("parameters") or [],
                                          param_values, referenced_params)

    emit({"type": "execution_progress", "data": {"status": "querying"}})

    is_cross = bool(sql_q.get("secondary_connection_id") and sql_q.get("secondary_sql"))

    if is_cross:
        sec_id = _db_manager.resolve_connection_via_profile(sql_q["secondary_connection_id"])
        secondary_conn = _db_manager.get_connection_raw(sec_id)
        raw_secondary = sql_q["secondary_sql"]
        secondary_sql = substitute_sql_params(
            raw_secondary, param_values, report["parameters"]
        )
        # Auto-WHERE for secondary SQL too
        sec_referenced = set(_PARAM_RE.findall(raw_secondary))
        secondary_sql = _auto_append_sql_where(secondary_sql, report.get("parameters") or [],
                                                param_values, sec_referenced)

        pri_type = primary_conn["connection_type"]
        sec_type = secondary_conn["connection_type"]
        pri_is_sql  = pri_type in _SQL_CONN_TYPES
        sec_is_sql  = sec_type in _SQL_CONN_TYPES
        sec_is_file = sec_type in _FILE_CONN_TYPES
        pri_is_file = pri_type in _FILE_CONN_TYPES

        if pri_is_sql and sec_is_file:
            # ── Hybrid: SQL primary + Parquet secondary ──────────────────────
            # Secondary "SQL" is actually a JSON query_config for parquet engine
            import json
            try:
                parquet_config = json.loads(secondary_sql) if secondary_sql.strip().startswith("{") else {"files": [secondary_sql]}
            except (json.JSONDecodeError, ValueError):
                parquet_config = {"files": [secondary_sql]}

            result = execute_hybrid_query(
                sql_conn_type=pri_type,
                sql_conn_config=primary_conn["config"],
                sql_query=primary_sql,
                parquet_data_dir=_resolve_data_dir(secondary_conn),
                parquet_config=parquet_config,
                join_config=sql_q.get("join_config") or {},
                sql_is_primary=True,
                execution_id=execution_id,
                row_limit=row_limit,
            )

        elif pri_is_file and sec_is_sql:
            # ── Hybrid: Parquet primary + SQL secondary ──────────────────────
            import json
            try:
                parquet_config = json.loads(primary_sql) if primary_sql.strip().startswith("{") else {"files": [primary_sql]}
            except (json.JSONDecodeError, ValueError):
                parquet_config = {"files": [primary_sql]}

            result = execute_hybrid_query(
                sql_conn_type=sec_type,
                sql_conn_config=secondary_conn["config"],
                sql_query=secondary_sql,
                parquet_data_dir=_resolve_data_dir(primary_conn),
                parquet_config=parquet_config,
                join_config=sql_q.get("join_config") or {},
                sql_is_primary=False,
                execution_id=execution_id,
                row_limit=row_limit,
            )

        elif pri_is_sql and sec_is_sql:
            # ── Standard: SQL-to-SQL cross-source ────────────────────────────
            result = execute_cross_source_query(
                primary_conn_type=pri_type,
                primary_conn_config=primary_conn["config"],
                primary_sql=primary_sql,
                secondary_conn_type=sec_type,
                secondary_conn_config=secondary_conn["config"],
                secondary_sql=secondary_sql,
                join_config=sql_q.get("join_config") or {},
                execution_id=execution_id,
                row_limit=row_limit,
            )
        else:
            raise ValueError(
                f"Unsupported cross-source combination: {pri_type} + {sec_type}"
            )
    else:
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            execution_id=execution_id,
            row_limit=row_limit,
        )

    return result.total_rows


# ── Public sync helper: returns DataFrame (used by PDF export + bursting) ─────

def _execute_report_sync(report_id: int, param_values: dict,
                         username: str, limit: int = 10000) -> "pd.DataFrame":
    """Execute a report synchronously and return a pandas DataFrame.

    This is the bridge between the PDF/burst APIs and the existing execution
    infrastructure. Raises an exception on failure (callers handle it).
    """
    import tempfile, os as _os, uuid as _uuid

    db = _require_db()
    report = db.get_report(report_id)
    if not report:
        raise ValueError(f"Report {report_id} not found")

    resolved = resolve_business_dates(param_values or {})
    errors = validate_param_values(report["parameters"], resolved)
    if errors:
        raise ValueError("Parameter validation failed: " + "; ".join(errors))

    exec_id = str(_uuid.uuid4())
    with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
        out_path = tmp.name

    noop = lambda _: None

    try:
        if report["saved_query_id"]:
            # Write to parquet output
            csv_path = out_path.replace(".parquet", ".csv")
            _run_parquet_report(report, resolved, limit, csv_path, noop)
            df = pd.read_csv(csv_path)
            try:
                _os.unlink(csv_path)
            except Exception:
                pass
        elif report["sql_saved_query_id"]:
            _run_sql_report(report, resolved, limit, exec_id, noop)
            from api.data_grid_api import find_csv_file
            result_file = find_csv_file(exec_id)
            if result_file and result_file.exists():
                if result_file.suffix.lower() == ".parquet":
                    df = pd.read_parquet(result_file)
                else:
                    df = pd.read_csv(result_file)
            else:
                raise RuntimeError("Report execution produced no output file")
        else:
            raise ValueError("Report has no source configured")
    finally:
        try:
            _os.unlink(out_path)
        except Exception:
            pass

    return df


