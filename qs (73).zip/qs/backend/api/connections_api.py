"""
Connection management endpoints — CRUD, file upload, schema, tables, partitions.
Extracted from main.py (Phase 29 enterprise refactoring).
"""
from __future__ import annotations

import os
import json
import logging
import asyncio
import threading as _threading
import time as _time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple

from fastapi import APIRouter, HTTPException, Depends, Request, File, UploadFile
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin, require_role

logger = logging.getLogger(__name__)

router = APIRouter(tags=["connections"])

# ── Module-level singletons — set via set_connection_dependencies() ───────────
_db_manager   = None
_engine       = None
_conn_manager = None
_paths        = None
_auth_cfg     = None
_lt_cfg       = None

# ── Dedicated light executor for metadata / S3 / schema work ─────────────────
_streaming_executor = ThreadPoolExecutor(
    max_workers=min(20, (os.cpu_count() or 4) * 2),
    thread_name_prefix="conn-stream",
)

# ── File-upload constants (re-evaluated after set_connection_dependencies) ────
_MAX_UPLOAD_SIZE: int = 1 * 1024 * 1024 * 1024  # 1 GB default
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}

# ── Schema cache: L1 in-memory (10 min) ──────────────────────────────────────
_schema_cache: Dict[str, Tuple[float, dict]] = {}
_schema_cache_lock = _threading.Lock()
_SCHEMA_L1_TTL = 600   # 10 minutes

# ── Partition cache: L1 in-memory (5 min) + L2 SQLite (5 hours) ──────────────
_partition_cache: Dict[str, Tuple[float, dict]] = {}
_partition_cache_lock = _threading.Lock()
_PARTITION_L1_TTL = 300      # 5 minutes
_PARTITION_L2_TTL = 18000    # 5 hours
_PARTITION_CACHE_MAX = 100   # max L1 entries

# ── Connection type regex (shared by Pydantic models) ────────────────────────
_ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle)$"


def set_connection_dependencies(db_manager, engine, conn_manager, paths, auth_cfg, lt_cfg):
    """Wire shared singletons from main.py at startup."""
    global _db_manager, _engine, _conn_manager, _paths, _auth_cfg, _lt_cfg
    global _MAX_UPLOAD_SIZE
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _paths        = paths
    _auth_cfg     = auth_cfg
    _lt_cfg       = lt_cfg
    # Re-read configurable upload limit
    if lt_cfg and hasattr(lt_cfg, "max_upload_size_bytes"):
        _MAX_UPLOAD_SIZE = lt_cfg.max_upload_size_bytes


# ── Internal helpers ──────────────────────────────────────────────────────────

def _get_light_executor():
    """Return the dedicated streaming/metadata executor for this module."""
    return _streaming_executor


def _conn_upload_dir(connection_id: int) -> Path:
    """Get (and create) the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _schema_cache_get(key: str):
    with _schema_cache_lock:
        if key in _schema_cache:
            ts, result = _schema_cache[key]
            if _time.time() - ts < _SCHEMA_L1_TTL:
                return result
    return None


def _schema_cache_set(key: str, result: dict):
    with _schema_cache_lock:
        if len(_schema_cache) > 200:
            oldest = min(_schema_cache, key=lambda k: _schema_cache[k][0])
            del _schema_cache[oldest]
        _schema_cache[key] = (_time.time(), result)


def _partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns (hit, result)."""
    with _partition_cache_lock:
        if cache_key in _partition_cache:
            ts, result = _partition_cache[cache_key]
            if _time.time() - ts < _PARTITION_L1_TTL:
                return True, result
    return False, None


def _partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    with _partition_cache_lock:
        if len(_partition_cache) >= _PARTITION_CACHE_MAX:
            oldest = min(_partition_cache, key=lambda k: _partition_cache[k][0])
            del _partition_cache[oldest]
        _partition_cache[cache_key] = (_time.time(), result)


def _partition_l2_get(connection_id: int, table_name: str, scan_type: str):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = _db_manager.get_partition_cache(connection_id, table_name, scan_type)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _PARTITION_L2_TTL:
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def _partition_store(connection_id: int, table_name: str, scan_type: str,
                     cache_key: str, result: dict):
    """Store in both L1 + L2. Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    _partition_l1_set(cache_key, stamped)
    _db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped)


def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # Try the cached handler first — same client the file browser uses
    if conn_id is not None:
        try:
            handler = _conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler and cache it to avoid leaking clients
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        # Cache in connection manager so subsequent calls reuse it
        if conn_id is not None:
            try:
                _conn_manager._s3_handlers[conn_id] = handler
            except Exception:
                pass
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise


def _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix):
    """Fetch schema from S3 — Iceberg reads metadata JSON, Parquet/CSV uses DuckDB DESCRIBE."""
    logger.info("Loading schema from S3 for table '%s' (format=%s)", table_name, fmt)
    if fmt == "iceberg":
        from core.iceberg_reader import _latest_metadata_key, _read_s3_json
        s3 = _make_s3_client_for_conn(conn_raw)
        meta_prefix = table_def["s3_prefix"].rstrip("/") + "/metadata/"
        try:
            meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
            metadata = _read_s3_json(s3, bucket, meta_key)
        except Exception as e:
            logger.error("Failed to read Iceberg metadata for %s: %s", table_name, e, exc_info=True)
            raise ValueError(f"Cannot read Iceberg metadata: {e}")

        # Extract schema from metadata JSON
        schemas_list = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
        current_schema_id = metadata.get("current-schema-id", 0)
        schema_obj = next((s for s in schemas_list if s.get("schema-id") == current_schema_id), schemas_list[0] if schemas_list else {})
        columns = []
        for field in schema_obj.get("fields", []):
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                ftype = ftype.get("type", "struct")
            columns.append({
                "name": field.get("name", ""),
                "type": str(ftype),
                "nullable": not field.get("required", False),
                "field_id": field.get("id") or field.get("field-id"),
            })

        # Extract partition spec
        specs = metadata.get("partition-specs") or ([metadata["partition-spec"]] if "partition-spec" in metadata else [])
        default_spec_id = metadata.get("default-spec-id", 0)
        active_spec = next((s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {})
        field_names = {f.get("id") or f.get("field-id"): f.get("name", "") for f in schema_obj.get("fields", [])}
        partition_spec = []
        for pf in active_spec.get("fields", []):
            src_id = pf.get("source-id") or pf.get("source_id")
            partition_spec.append({
                "name": pf.get("name", ""),
                "transform": pf.get("transform", "identity"),
                "source_column": field_names.get(src_id, str(src_id)),
            })

        # Snapshot info
        current_snap_id = metadata.get("current-snapshot-id")
        snapshots = metadata.get("snapshots", [])
        snap = next((s for s in snapshots if s.get("snapshot-id") == current_snap_id), None) if current_snap_id else None

        summary = snap.get("summary", {}) if snap else {}
        data_file_count = int(summary.get("total-data-files", 0))
        total_records = int(summary.get("total-records", 0))

        return {
            "table_name": table_name,
            "format": "iceberg",
            "s3_prefix": table_def["s3_prefix"],
            "columns": columns,
            "num_rows": total_records,
            "data_file_count": data_file_count,
            "partition_spec": partition_spec,
            "snapshot_id": current_snap_id,
            "format_version": metadata.get("format-version", 1),
        }
    else:
        # Parquet or CSV — use DuckDB DESCRIBE with S3 glob
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(config, connection_id=connection_id)
        try:
            if fmt == "csv":
                src = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
            else:
                src = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
            cols_raw = con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()
            row_count = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
            return {
                "table_name": table_name,
                "format": fmt,
                "s3_prefix": table_def["s3_prefix"],
                "columns": [
                    {"name": c[0], "type": c[1], "nullable": True}
                    for c in cols_raw
                ],
                "num_rows": row_count,
            }
        finally:
            con.close()


# ── Pydantic Models ───────────────────────────────────────────────────────────

class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


class RegisteredTableModel(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""


# ── Connection File Upload Endpoints ──────────────────────────────────────────

@router.post("/api/connections/{connection_id}/upload-files")
async def upload_connection_files(
    connection_id: int,
    files: List[UploadFile] = File(...),
    _user: dict = Depends(require_role("admin", "analyst")),
):
    """Upload multiple data files to a connection's upload directory (max 1 GB each)."""
    conn = _db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="File upload is only for 'upload' type connections")

    upload_dir = _conn_upload_dir(connection_id)
    results = []
    errors = []

    for file in files:
        fname = Path(file.filename).name  # strip directory components
        ext = Path(fname).suffix.lower()
        if ext not in _ALLOWED_EXTENSIONS:
            errors.append(f"{fname}: unsupported format ({ext}). Allowed: {', '.join(sorted(_ALLOWED_EXTENSIONS))}")
            continue

        # Stream to disk in chunks to enforce size limit without loading all into RAM
        dest = upload_dir / fname
        total = 0
        try:
            with open(dest, "wb") as out:
                while True:
                    chunk = await file.read(8 * 1024 * 1024)  # 8 MB chunks
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > _MAX_UPLOAD_SIZE:
                        out.close()
                        dest.unlink(missing_ok=True)
                        errors.append(f"{fname}: exceeds 1 GB limit")
                        break
                    out.write(chunk)
                else:
                    results.append({"filename": fname, "size_bytes": total})
                    logger.info("File uploaded for connection %s: %s (%s bytes)", connection_id, fname, total)
        except Exception as e:
            dest.unlink(missing_ok=True)
            errors.append(f"{fname}: {str(e)}")

    # Update connection config with the upload directory path
    config = conn.get("config", {})
    config["base_path"] = str(upload_dir)
    _db_manager.update_connection(connection_id, {"config": config})

    return {
        "uploaded": results,
        "errors": errors,
        "total_files": len(list(upload_dir.glob("*"))),
        "upload_dir": str(upload_dir),
    }


@router.get("/api/connections/{connection_id}/uploaded-files")
async def list_uploaded_files(
    connection_id: int,
    _user: dict = Depends(get_current_user),
):
    """List files that have been uploaded to this connection."""
    conn = _db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="Not an upload-type connection")

    upload_dir = _conn_upload_dir(connection_id)
    files = []
    for f in sorted(upload_dir.iterdir()):
        if f.is_file():
            files.append({
                "filename": f.name,
                "size_bytes": f.stat().st_size,
                "modified": f.stat().st_mtime,
            })
    return {"files": files, "total_size_bytes": sum(f["size_bytes"] for f in files)}


@router.delete("/api/connections/{connection_id}/uploaded-files/{filename}")
async def delete_uploaded_file(
    connection_id: int,
    filename: str,
    _user: dict = Depends(require_role("admin", "analyst")),
):
    """Delete a single uploaded file from a connection."""
    conn = _db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="Not an upload-type connection")

    upload_dir = _conn_upload_dir(connection_id)
    target = upload_dir / Path(filename).name  # prevent path traversal
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")

    target.unlink()
    remaining = len(list(upload_dir.glob("*")))
    logger.info("Deleted uploaded file %s from connection %s (%d remaining)", filename, connection_id, remaining)
    return {"message": f"Deleted {filename}", "remaining_files": remaining}


@router.get("/api/connections/upload-status")
async def get_upload_connections_status(_user: dict = Depends(get_current_user)):
    """Check all upload-type connections for usage status.
    Returns list of upload connections with whether they're referenced by any saved query."""
    all_conns = _db_manager.list_connections(active_only=True)
    upload_conns = [c for c in all_conns if c.get("connection_type") == "upload"]
    if not upload_conns:
        return {"upload_connections": []}

    # Get all saved queries to check which connections are referenced
    all_queries = _db_manager.list_queries(active_only=True)
    used_conn_ids = set()
    for q in all_queries:
        qc = q.get("query_config", {})
        cid = qc.get("connection_id")
        if cid:
            used_conn_ids.add(int(cid))

    result = []
    for c in upload_conns:
        upload_dir = _paths.upload_dir / str(c["id"])
        file_count = len(list(upload_dir.glob("*"))) if upload_dir.exists() else 0
        total_size = sum(f.stat().st_size for f in upload_dir.glob("*") if f.is_file()) if upload_dir.exists() else 0
        result.append({
            "id": c["id"],
            "name": c["name"],
            "file_count": file_count,
            "total_size_bytes": total_size,
            "is_used": c["id"] in used_conn_ids,
            "created_at": c.get("created_at"),
        })
    return {"upload_connections": result}


# ── Connection CRUD Endpoints ─────────────────────────────────────────────────

@router.get("/api/connections")
async def list_connections(active_only: bool = True, request: Request = None):
    """List connections — users see their own + shared; admins see all."""
    try:
        all_conns = _db_manager.list_connections(active_only=active_only)
        # Apply RLS: non-admins see only their own + shared connections
        if _auth_cfg.type != "none":
            user = get_current_user(request)
            if user and not user.get("is_admin"):
                username = user.get("username", "")
                all_conns = [
                    c for c in all_conns
                    if c.get("created_by") == username
                    or c.get("is_shared")
                    or not c.get("created_by")   # legacy connections (no owner) visible to all
                ]
        return all_conns
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections")
async def create_connection(request: ConnectionConfigModel, _user: dict = Depends(require_role("admin", "analyst"))):
    """Create a new connection — auto-sets created_by from auth user."""
    try:
        conn = _db_manager.create_connection(
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        # Set created_by and is_shared on the new connection
        username = (_user or {}).get("username", "guest")
        is_shared = request.is_shared or False
        _db_manager.update_connection(conn["id"], created_by=username, is_shared=bool(is_shared))
        conn["created_by"] = username
        conn["is_shared"] = bool(is_shared)

        # For upload connections, auto-set base_path to the upload directory
        if request.connection_type == "upload":
            upload_dir = _conn_upload_dir(conn["id"])
            config = conn.get("config", {})
            config["base_path"] = str(upload_dir)
            _db_manager.update_connection(conn["id"], config=config)
            conn["config"] = config

        # Return masked config — never send encrypted credentials to browser
        from core.crypto import decrypt_config, mask_config
        if conn and "config" in conn:
            conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@router.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest, _user: dict = Depends(get_current_user)):
    """Test a connection configuration without saving — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_type = request.connection_type
    conn_cfg  = dict(request.config)

    # When editing a saved connection the browser sends "***" for any sensitive
    # field the user did not change.  Substitute those placeholders with the
    # real (decrypted) values from the DB so the test uses valid credentials.
    if request.connection_id is not None:
        raw = _db_manager.get_connection_raw(request.connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            for k, v in conn_cfg.items():
                if v == "***" and k in raw_cfg:
                    conn_cfg[k] = raw_cfg[k]

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_cfg)
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return _conn_manager.test_connection(conn_type, conn_cfg)
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int, _user: dict = Depends(get_current_user)):
    """Get a specific connection"""
    conn = _db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@router.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel, _user: dict = Depends(require_role("admin", "analyst"))):
    """Update an existing connection"""
    try:
        # The frontend sends "***" for masked sensitive fields the user didn't change.
        # Replace those placeholders with the real (decrypted) values from the DB
        # so we don't accidentally store "***" as the actual credential.
        updated_config = dict(request.config)
        raw = _db_manager.get_connection_raw(connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            from core.crypto import SENSITIVE_FIELDS
            for field in SENSITIVE_FIELDS:
                if updated_config.get(field) == "***" and field in raw_cfg:
                    real_val = raw_cfg[field]
                    if real_val:
                        updated_config[field] = real_val
                    else:
                        logger.warning(
                            "Credential field '%s' decrypted to empty for connection %d — "
                            "user must re-enter it.", field, connection_id
                        )
                        updated_config[field] = ""

        update_kwargs = dict(
            name=request.name,
            connection_type=request.connection_type,
            config=updated_config,
        )
        # Allow toggling is_shared
        if hasattr(request, "is_shared") and request.is_shared is not None:
            update_kwargs["is_shared"] = bool(request.is_shared)

        conn = _db_manager.update_connection(connection_id, **update_kwargs)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        _conn_manager.invalidate_cache(connection_id)
        # Invalidate query result cache entries that used this connection
        from core.query_cache import invalidate_by_source
        invalidate_by_source(connection_id=connection_id)
        # Invalidate connection pool (Phase 40)
        try:
            from core.connection_pool import invalidate_pool
            invalidate_pool(connection_id)
        except Exception:
            pass
        # Return masked config — never send encrypted or plaintext credentials to browser
        from core.crypto import decrypt_config, mask_config
        conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int, _user: dict = Depends(require_role("admin", "analyst"))):
    """Delete a connection and clean up uploaded files if applicable."""
    try:
        # Check if this is an upload connection — clean up files before deleting record
        conn = _db_manager.get_connection(connection_id)
        if conn and conn.get("connection_type") == "upload":
            import shutil
            upload_dir = _paths.upload_dir / str(connection_id)
            if upload_dir.exists():
                shutil.rmtree(upload_dir, ignore_errors=True)
                logger.info("Cleaned up upload directory for connection %s: %s", connection_id, upload_dir)

        success = _db_manager.delete_connection(connection_id, soft_delete=False)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        _conn_manager.invalidate_cache(connection_id)
        # Invalidate query result cache entries that used this connection
        from core.query_cache import invalidate_by_source
        invalidate_by_source(connection_id=connection_id)
        # Invalidate connection pool (Phase 40)
        try:
            from core.connection_pool import invalidate_pool
            invalidate_pool(connection_id)
        except Exception:
            pass
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection and persist the result — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    # Fetch raw creds synchronously (fast SQLite read) before entering executor
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw['connection_type']

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_raw['config'])
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return _conn_manager.test_connection(conn_type, conn_raw['config'])

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        _db_manager.update_connection(
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result.get('message', '')
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Connection Files and Schema Endpoints ─────────────────────────────────────

@router.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = "", _user: dict = Depends(get_current_user)):
    """List tables/files for a connection.
    - S3 / local  → parquet file listing via ConnectionManager
    - SQL connectors → list tables from the configured catalog.schema
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    from core.s3_storage import TokenExpiredError
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _list_sql_tables():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                catalog = cfg.get("catalog") or cfg.get("database") or ""
                schema  = cfg.get("schema") or "public"
                tables  = connector.list_tables(catalog, schema)
                # Normalise to the same shape the frontend expects for file items
                result = []
                for t in tables:
                    tname = t["name"]
                    full_path = f"{catalog}.{schema}.{tname}" if catalog else f"{schema}.{tname}"
                    result.append({
                        "name":       tname,
                        "path":       full_path,
                        "folder":     f"{catalog}/{schema}" if catalog else schema,
                        "num_rows":   None,
                        "num_columns": None,
                        "size_bytes": None,
                        "table_type": t.get("type", "TABLE"),
                    })
                return result
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(_get_light_executor(), _list_sql_tables)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            _get_light_executor(), _conn_manager.list_files, connection_id, folder
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str, _user: dict = Depends(get_current_user)):
    """Get schema for a file or SQL table.
    - S3 / local  → parquet metadata via ConnectionManager
    - SQL connectors → list_columns(catalog, schema, table)
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    from core.s3_storage import TokenExpiredError
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _sql_schema():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                # file_path is "catalog.schema.table" or "schema.table"
                parts = file_path.split(".")
                if len(parts) == 3:
                    catalog, schema, table = parts
                elif len(parts) == 2:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema, table = parts
                else:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema  = cfg.get("schema") or "public"
                    table   = file_path
                cols = connector.list_columns(catalog, schema, table)
                return {"columns": cols}
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(_get_light_executor(), _sql_schema)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            _get_light_executor(), _conn_manager.get_schema, connection_id, file_path
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Registered Tables (Enterprise S3 Table Registry) ─────────────────────────

@router.get("/api/connections/{connection_id}/tables")
async def list_registered_tables(connection_id: int):
    """List all registered tables for an S3 connection."""
    try:
        tables = _conn_manager.get_registered_tables(connection_id)
        return {"tables": tables}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/api/connections/{connection_id}/tables")
async def register_table_endpoint(connection_id: int, table: RegisteredTableModel):
    """Register a named table pointing to an S3 prefix.

    For iceberg format: validates that the prefix has a metadata/ subfolder
    with valid Iceberg metadata files before accepting.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")

    # Validate Iceberg prefix before registering
    if table.format == "iceberg":
        try:
            from core.iceberg_reader import is_iceberg_table
            s3 = _make_s3_client_for_conn(conn_raw)
            bucket = conn_raw["config"]["bucket_name"]
            if not is_iceberg_table(s3, bucket, table.s3_prefix):
                raise HTTPException(
                    status_code=400,
                    detail=f"'{table.s3_prefix}' is not a valid Iceberg table. "
                           f"No metadata/ folder with *.metadata.json found. "
                           f"Make sure you register at the table root level "
                           f"(the folder that contains both data/ and metadata/ subfolders)."
                )
        except HTTPException:
            raise
        except Exception as e:
            logger.warning("Iceberg validation failed for %s: %s", table.s3_prefix, e)

    try:
        result = _conn_manager.register_table(connection_id, table.model_dump())

        # Background-cache schema so subsequent loads are instant
        async def _bg_cache_schema():
            try:
                await get_registered_table_schema(connection_id, table.name, refresh=True)
                logger.info("Background schema cache done for %s:%s", connection_id, table.name)
            except Exception as exc:
                logger.warning("Background schema cache failed for %s:%s: %s", connection_id, table.name, exc)
        asyncio.create_task(_bg_cache_schema())

        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/api/connections/{connection_id}/tables/{table_name}")
async def unregister_table_endpoint(connection_id: int, table_name: str):
    """Remove a registered table and its cached schema."""
    try:
        _conn_manager.unregister_table(connection_id, table_name)
        # Clean up schema cache
        _db_manager.delete_schema_cache(connection_id, table_name)
        _schema_ck = f"schema:{connection_id}:{table_name}"
        with _schema_cache_lock:
            _schema_cache.pop(_schema_ck, None)
        return {"message": f"Table '{table_name}' removed"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/api/connections/{connection_id}/tables/{table_name}/schema")
async def get_registered_table_schema(connection_id: int, table_name: str,
                                       refresh: bool = False):
    """Get schema for a registered table.

    Cache hierarchy: L1 in-memory (10 min) → L2 SQLite DB (persistent) → L3 S3.
    Pass ?refresh=true to force re-read from S3 and update both caches.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")

    bucket = config["bucket_name"]
    fmt = table_def["format"]
    prefix = table_def["s3_prefix"].rstrip("/")

    _schema_ck = f"schema:{connection_id}:{table_name}"

    if not refresh:
        # ── L1 cache check — instant for repeated clicks ─────────────
        cached = _schema_cache_get(_schema_ck)
        if cached:
            logger.debug("Schema L1 hit for %s", _schema_ck)
            return {**cached, "cache": "L1"}

        # ── L2 cache check — SQLite DB (persistent, survives restarts) ──
        db_cached = _db_manager.get_schema_cache(connection_id, table_name)
        if db_cached:
            result = db_cached["schema_data"]
            _schema_cache_set(_schema_ck, result)  # promote to L1
            logger.info("Schema L2 hit for %s (cached %s)", _schema_ck, db_cached.get("updated_at", "?"))
            return {**result, "cache": "L2", "cached_at": db_cached.get("updated_at")}

    def _do():
        try:
            return _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix)
        except BaseException as exc:
            logger.critical("CRASH in schema _do() for '%s': %s", table_name, exc, exc_info=True)
            raise

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        # Store in both L1 + L2
        _schema_cache_set(_schema_ck, result)
        _db_manager.set_schema_cache(connection_id, table_name, fmt, result)
        logger.info("Schema cached for %s:%s (L1 + L2)", connection_id, table_name)
        return {**result, "cache": "none"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error getting registered table schema: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/tables/{table_name}/schema/refresh")
async def refresh_table_schema(connection_id: int, table_name: str,
                                _user: dict = Depends(get_current_user)):
    """Force-refresh schema from S3 and update cache."""
    return await get_registered_table_schema(connection_id, table_name, refresh=True)


@router.post("/api/connections/{connection_id}/schema/refresh-all")
async def refresh_all_table_schemas(connection_id: int,
                                     _user: dict = Depends(get_current_user)):
    """Refresh schemas for ALL registered tables in a connection."""
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    if not tables:
        return {"message": "No registered tables", "refreshed": 0}

    loop = asyncio.get_running_loop()
    results = []
    errors = []

    for tbl in tables:
        table_name = tbl["name"]
        fmt = tbl["format"]
        prefix = tbl["s3_prefix"].rstrip("/")
        bucket = config["bucket_name"]
        try:
            result = await loop.run_in_executor(
                _get_light_executor(),
                lambda t=tbl: _fetch_schema_from_s3(
                    connection_id, conn_raw, config, t, t["name"], bucket, t["format"], t["s3_prefix"].rstrip("/")
                ),
            )
            _schema_ck = f"schema:{connection_id}:{table_name}"
            _schema_cache_set(_schema_ck, result)
            _db_manager.set_schema_cache(connection_id, table_name, fmt, result)
            results.append(table_name)
        except Exception as e:
            logger.warning("Schema refresh failed for %s: %s", table_name, e)
            errors.append({"table": table_name, "error": str(e)})

    return {"refreshed": len(results), "tables": results, "errors": errors}


@router.get("/api/connections/{connection_id}/schema/cache")
async def list_cached_schemas(connection_id: int):
    """List all cached schemas for a connection."""
    entries = _db_manager.list_schema_cache_entries(connection_id)
    return {"connection_id": connection_id, "count": len(entries), "entries": entries}


@router.delete("/api/connections/{connection_id}/schema/cache")
async def clear_schema_cache(connection_id: int,
                              _user: dict = Depends(get_current_user)):
    """Clear all cached schemas for a connection."""
    count = _db_manager.delete_schema_cache(connection_id)
    # Clear L1 too
    with _schema_cache_lock:
        to_remove = [k for k in _schema_cache if k.startswith(f"schema:{connection_id}:")]
        for k in to_remove:
            del _schema_cache[k]
    return {"cleared": count + len(to_remove)}


# ── Partition Endpoints ───────────────────────────────────────────────────────

@router.get("/api/connections/{connection_id}/tables/{table_name}/partitions")
async def get_registered_table_partitions(
    connection_id: int, table_name: str, refresh: bool = False, full_scan: bool = False,
):
    """Get available partition values for a registered Iceberg table.

    Two-tier cache:
      L1 in-memory (5 min) — instant response for repeated requests
      L2 SQLite (5 hours) — survives server restarts, avoids S3 re-scans
    Pass ?refresh=true to force re-scan from S3.
    Pass ?full_scan=true to read individual manifest files for exact combos.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    if table_def.get("format") != "iceberg":
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    bucket = config["bucket_name"]
    scan_type = "full" if full_scan else "fast"
    cache_key = f"{connection_id}:{table_name}::{scan_type}"

    if not refresh:
        # L1 check
        hit, cached = _partition_l1_get(cache_key)
        if hit:
            logger.debug("Partition L1 hit for %s", cache_key)
            return cached
        # L2 check
        hit, cached, _ts = _partition_l2_get(connection_id, table_name, scan_type)
        if hit:
            logger.debug("Partition L2 hit for %s", cache_key)
            _partition_l1_set(cache_key, cached)
            return cached

    def _do():
        from core.iceberg_reader import get_iceberg_partition_values
        s3 = _make_s3_client_for_conn(conn_raw)
        result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=full_scan)
        _partition_store(connection_id, table_name, scan_type, cache_key, result)
        return {**result, "cached_at": datetime.now(timezone.utc).isoformat()}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error getting partition values for %s: %s", table_name, e)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/tables/{table_name}/partitions/refresh")
async def refresh_partition_cache(connection_id: int, table_name: str):
    """Force re-scan partition metadata from S3 and update both caches.

    Runs a full_scan to get exact partition combos.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    if table_def.get("format") != "iceberg":
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    bucket = config["bucket_name"]

    def _do():
        from core.iceberg_reader import get_iceberg_partition_values
        s3 = _make_s3_client_for_conn(conn_raw)
        # Run full scan for exact combos
        result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=True)
        # Store both fast + full in caches (full result is a superset)
        now_iso = datetime.now(timezone.utc).isoformat()
        for stype in ("fast", "full"):
            ck = f"{connection_id}:{table_name}::{stype}"
            _partition_store(connection_id, table_name, stype, ck, result)
        return {**result, "cached_at": now_iso}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error refreshing partition cache for %s: %s", table_name, e)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/partitions/refresh-all")
async def refresh_all_partition_caches(connection_id: int = None):
    """Refresh partition caches for ALL registered Iceberg tables (or one connection).

    Scans S3 manifests and stores results in L1 + L2 caches.
    Pass ?connection_id=N to refresh only tables in that connection.
    """
    def _do():
        from core.scheduler import _do_refresh_all_partitions
        return _do_refresh_all_partitions(connection_id=connection_id)

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        return result
    except Exception as e:
        logger.error("Error refreshing all partition caches: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Discovery and Browse Endpoints ───────────────────────────────────────────

@router.get("/api/connections/{connection_id}/discover-tables")
async def discover_tables(connection_id: int, prefix: str = "", max_depth: int = 4):
    """Discover tables by scanning S3 — prioritizes Iceberg metadata.

    Strategy:
      1. If iceberg_warehouse_path is set, scan that path for Iceberg tables first.
      2. Then scan from root_prefix (or given prefix) recursively up to max_depth.
      3. For Iceberg tables, read metadata to get row count + file count.
      4. For parquet/csv folders, report format detection.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support table discovery")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    iceberg_warehouse = (config.get("iceberg_warehouse_path") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )
    existing_names = {t["name"] for t in config.get("registered_tables", [])}

    def _do():
        from core.iceberg_reader import is_iceberg_table
        s3 = _make_s3_client_for_conn(conn_raw)

        candidates = []
        seen_prefixes = set()  # avoid duplicates between iceberg scan and general scan

        def _build_table_name(folder_prefix: str) -> str:
            """Build a qualified table name from the S3 prefix path.

            Strips root_prefix and iceberg_warehouse_path, then joins
            remaining path segments with dots.
            E.g. root='', warehouse='', prefix='catalog/schema1/'
              -> 'catalog.schema1'
            E.g. root='data/', warehouse='data/catalog/', prefix='data/catalog/schema1/'
              -> 'schema1'
            """
            path = folder_prefix.rstrip("/")
            # Strip root prefix
            if root_prefix and path.startswith(root_prefix):
                path = path[len(root_prefix):].lstrip("/")
            # Strip iceberg warehouse prefix
            if iceberg_warehouse and path.startswith(iceberg_warehouse):
                path = path[len(iceberg_warehouse):].lstrip("/")
            parts = [p for p in path.split("/") if p]
            if len(parts) <= 1:
                return parts[0] if parts else folder_prefix.rstrip("/").split("/")[-1]
            # Use dot-separated qualified name (e.g. catalog.schema)
            return ".".join(parts)

        def _add_iceberg_candidate(folder_prefix: str):
            """Add an Iceberg table candidate with metadata enrichment."""
            if folder_prefix in seen_prefixes:
                return
            name = _build_table_name(folder_prefix)
            if name in existing_names:
                return
            seen_prefixes.add(folder_prefix)

            desc = ""
            try:
                from core.iceberg_reader import get_iceberg_data_files, _latest_metadata_key, _read_s3_json
                data_files = get_iceberg_data_files(s3, bucket, folder_prefix)
                # Read format version from metadata
                meta_prefix = folder_prefix.rstrip("/") + "/metadata/"
                meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
                metadata = _read_s3_json(s3, bucket, meta_key)
                fmt_ver = metadata.get("format-version", 1)
                desc = f"{len(data_files)} files · v{fmt_ver}"
            except Exception as e:
                logger.error("Iceberg metadata enrichment failed for %s: %s", folder_prefix, e, exc_info=True)
                desc = f"Iceberg table (metadata read failed: {str(e)[:60]})"

            candidates.append({
                "name": name,
                "s3_prefix": folder_prefix,
                "format": "iceberg",
                "description": desc,
            })

        # ── Phase 1: Scan iceberg_warehouse_path for Iceberg tables ────────
        if iceberg_warehouse:
            wh_prefix = f"{iceberg_warehouse}/"
            logger.info("Discover: scanning Iceberg warehouse at %s", wh_prefix)

            def _scan_iceberg_warehouse(scan_prefix: str, depth: int):
                if depth > max_depth or len(candidates) >= 50:
                    return
                paginator = s3.get_paginator("list_objects_v2")
                for page in paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/"):
                    for cp in page.get("CommonPrefixes", []):
                        if len(candidates) >= 50:
                            return
                        fp = cp["Prefix"]
                        name = fp.rstrip("/").split("/")[-1]
                        if name.startswith(".") or name.startswith("_") or name == "metadata":
                            continue
                        if is_iceberg_table(s3, bucket, fp):
                            _add_iceberg_candidate(fp)
                        else:
                            # Might be a database/schema level — recurse
                            _scan_iceberg_warehouse(fp, depth + 1)

            _scan_iceberg_warehouse(wh_prefix, 1)

        # ── Phase 2: General scan from root_prefix ─────────────────────────
        def _scan_level(scan_prefix: str, depth: int):
            if depth > max_depth or len(candidates) >= 50:
                return
            if scan_prefix in seen_prefixes:
                return

            paginator = s3.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/")

            for page in pages:
                for cp in page.get("CommonPrefixes", []):
                    if len(candidates) >= 50:
                        return
                    folder_prefix = cp["Prefix"]
                    name = folder_prefix.rstrip("/").split("/")[-1]

                    # Skip hidden/internal folders, but NOT "data" — it's a common
                    # top-level folder name.  "metadata" is only Iceberg internals.
                    if name.startswith(".") or name.startswith("_") or name == "metadata":
                        continue
                    if folder_prefix in seen_prefixes:
                        continue

                    # Skip date-partition folders (e.g. dt=2024-01-01, year=2024)
                    if "=" in name:
                        continue

                    if is_iceberg_table(s3, bucket, folder_prefix):
                        _add_iceberg_candidate(folder_prefix)
                        continue

                    # Check for DIRECT data files at this level only (use Delimiter)
                    try:
                        peek = s3.list_objects_v2(
                            Bucket=bucket, Prefix=folder_prefix, Delimiter="/", MaxKeys=50
                        )
                    except Exception as peek_err:
                        logger.warning("Discover: failed to peek %s: %s", folder_prefix, peek_err)
                        continue

                    has_subfolders = len(peek.get("CommonPrefixes", [])) > 0
                    fmt = "unknown"
                    for obj in peek.get("Contents", []):
                        key = obj["Key"].lower()
                        if key.endswith(".parquet"):
                            fmt = "parquet"
                            break
                        if key.endswith(".csv"):
                            fmt = "csv"
                            break

                    if has_subfolders and fmt == "unknown":
                        # Has subfolders but no direct data files → container, recurse
                        _scan_level(folder_prefix, depth + 1)
                    elif fmt != "unknown" and not has_subfolders:
                        # Leaf folder with data files → register as table
                        qual_name = _build_table_name(folder_prefix)
                        if qual_name in existing_names:
                            continue
                        seen_prefixes.add(folder_prefix)
                        candidates.append({
                            "name": qual_name,
                            "s3_prefix": folder_prefix,
                            "format": fmt,
                            "description": f"{fmt.title()} files at {folder_prefix}",
                        })
                    elif has_subfolders:
                        # Has both subfolders and data files → recurse deeper
                        # (the data files might be in a partition structure)
                        _scan_level(folder_prefix, depth + 1)
                    else:
                        # No data, no subfolders → skip
                        pass

        _scan_level(effective_prefix, 1)
        return {"candidates": candidates, "prefix": effective_prefix}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error discovering tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}/browse-folders")
async def browse_s3_folders(connection_id: int, prefix: str = ""):
    """Browse S3 folders one level at a time. Returns subfolders and file counts.

    Used by the frontend to let users visually pick an S3 prefix for table registration.
    """
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support folder browsing")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(
            Bucket=bucket, Prefix=effective_prefix, Delimiter="/"
        )

        folders = []
        file_summary = {"parquet": 0, "csv": 0, "other": 0}

        for page in pages:
            for cp in page.get("CommonPrefixes", []):
                fp = cp["Prefix"]
                name = fp.rstrip("/").split("/")[-1]
                if not name.startswith("."):
                    # Strip root_prefix for display
                    display_path = fp
                    if root_prefix and display_path.startswith(root_prefix):
                        display_path = display_path[len(root_prefix):].lstrip("/")
                    folders.append({"name": name, "prefix": fp, "display_path": display_path})

            for obj in page.get("Contents", []):
                key = obj["Key"].lower()
                if key.endswith(".parquet"):
                    file_summary["parquet"] += 1
                elif key.endswith(".csv"):
                    file_summary["csv"] += 1
                else:
                    file_summary["other"] += 1

        # Detect if current prefix looks like an iceberg table
        is_iceberg = False
        try:
            from core.iceberg_reader import is_iceberg_table
            is_iceberg = is_iceberg_table(s3, bucket, effective_prefix)
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

        return {
            "prefix": effective_prefix,
            "folders": folders,
            "file_summary": file_summary,
            "is_iceberg": is_iceberg,
        }

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error browsing S3 folders: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Iceberg S3 Endpoints ──────────────────────────────────────────────────────

@router.get("/api/connections/{connection_id}/iceberg/tables")
async def list_iceberg_tables(connection_id: int, prefix: str = ""):
    """
    Scan an S3 prefix for Iceberg table directories — runs in thread (S3 listing is blocking).
    Returns list of {name, prefix, type='iceberg_table', path} dicts.
    """
    from core.iceberg_reader import list_iceberg_tables as _list_iceberg_tables
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']
    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        tables = _list_iceberg_tables(s3, bucket, prefix)
        return {"tables": tables, "bucket": bucket, "prefix": prefix}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error listing Iceberg tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}/iceberg/files")
async def list_iceberg_files(
    connection_id: int,
    table_prefix: str,
    partition_filter: Optional[str] = None,   # JSON: [{"col":"business_date","op":"equals","val":"${today}"}]
):
    """
    Read an Iceberg table's metadata chain — runs in thread (Avro + S3 reads are blocking).
    Returns list of {key, name, path, size_bytes, last_modified, folder, type='parquet'}.

    Optional partition_filter (JSON array) enables server-side manifest pruning so only
    files for the relevant partition(s) are returned.  Date expressions (${today}, etc.)
    in filter values are resolved at request time.
    """
    from core.iceberg_reader import get_iceberg_data_files
    from core.date_resolver import resolve_filter_dates
    import json as _json

    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']

    pfilters = None
    if partition_filter:
        try:
            pfilters = resolve_filter_dates(_json.loads(partition_filter))
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        files = get_iceberg_data_files(s3, bucket, table_prefix, partition_filters=pfilters)
        return {"files": files, "bucket": bucket, "table_prefix": table_prefix, "count": len(files)}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error reading Iceberg data files: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
