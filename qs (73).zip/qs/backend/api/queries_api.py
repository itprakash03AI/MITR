"""
Query management, file operations, downloads, executions, and sharing endpoints.
Extracted from main.py (Phase 29 enterprise refactoring).
"""

from __future__ import annotations
import json, os, logging, asyncio
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any, Union
from fastapi import APIRouter, HTTPException, Depends, Request, File, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from api.deps import get_current_user, require_admin, require_role, require_execute_access, is_owner_or_shared
from core.execution_state import running_tasks, cancellation_flags, user_query_counts, user_query_lock

logger = logging.getLogger(__name__)

router = APIRouter(tags=["queries"])

# ── Module-level singletons — populated by set_query_dependencies() at startup ──
_db_manager  = None
_engine      = None
_conn_manager = None
_paths       = None
_auth_cfg    = None
_qe_cfg      = None
_limits_cfg  = None
_features_cfg = None
_ws_manager  = None

_MAX_UPLOAD_SIZE = None
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}


def set_query_dependencies(db_manager, engine, conn_manager, paths, auth_cfg,
                           qe_cfg, limits_cfg, features_cfg, ws_manager=None):
    """Called once from main.py startup after all components are created."""
    global _db_manager, _engine, _conn_manager, _paths, _auth_cfg
    global _qe_cfg, _limits_cfg, _features_cfg, _ws_manager, _MAX_UPLOAD_SIZE
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _paths        = paths
    _auth_cfg     = auth_cfg
    _qe_cfg       = qe_cfg
    _limits_cfg   = limits_cfg
    _features_cfg = features_cfg
    _ws_manager   = ws_manager
    _MAX_UPLOAD_SIZE = limits_cfg.max_upload_size_bytes


# ── Pydantic models ────────────────────────────────────────────────────────────

_ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle)$"


class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cache strategy: auto = use cache if available; bypass = skip cache (no store);
    #                 refresh = skip cache lookup but store fresh result
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None
    # Async control fields
    wait: bool = False                     # Block until complete (external executor mode only)
    wait_timeout: int = Field(default=30, ge=1, le=300)  # Max seconds to wait
    callback_url: Optional[str] = None    # Webhook POST on completion/failure


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"


class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None


class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


# ── Helper functions ───────────────────────────────────────────────────────────

def convert_query_config_to_engine(config: QueryConfigModel):
    """Convert API model to engine QueryConfig"""
    from core.parquet_engine_v2 import QueryConfig, JoinConfig, AggregationConfig

    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how,
                right_column_aliases=j.right_column_aliases or {},
            )
            for j in config.joins
        ]

    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]

    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]

    aggregations = None
    if config.aggregations:
        aggregations = [
            AggregationConfig(column=a.column, function=a.function.upper(),
                              alias=a.alias, distinct=a.distinct)
            for a in config.aggregations
        ]

    having = None
    if config.having:
        having = [{"column": h.column, "function": h.function.upper(),
                   "operator": h.operator, "value": h.value}
                  for h in config.having]

    computed_columns = None
    if config.computed_columns:
        computed_columns = [{"expression": c.expression, "alias": c.alias}
                           for c in config.computed_columns]

    case_expressions = None
    if config.case_expressions:
        case_expressions = [
            {"when_clauses": [{"when_column": w.when_column, "when_operator": w.when_operator,
                               "when_value": w.when_value, "then_value": w.then_value}
                              for w in ce.when_clauses],
             "else_value": ce.else_value, "alias": ce.alias}
            for ce in config.case_expressions
        ]

    window_functions = None
    if config.window_functions:
        window_functions = [
            {"function": wf.function.upper(), "alias": wf.alias,
             "column": wf.column,
             "partition_by": wf.partition_by,
             "order_by": [{"column": o.column, "direction": o.direction}
                          for o in wf.order_by] if wf.order_by else None,
             "offset": wf.offset, "default_value": wf.default_value}
            for wf in config.window_functions
        ]

    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by,
        group_by=config.group_by,
        aggregations=aggregations,
        distinct=config.distinct,
        having=having,
        filter_logic=config.filter_logic.upper(),
        computed_columns=computed_columns,
        case_expressions=case_expressions,
        column_aliases=config.column_aliases,
        window_functions=window_functions,
    )


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        _db_manager.audit(username, action, resource_type=resource_type,
                          resource_id=resource_id, ip_address=ip,
                          user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


def _conn_upload_dir(connection_id: int) -> Path:
    """Get the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── File Endpoints ─────────────────────────────────────────────────────────────

@router.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = "", _user: dict = Depends(get_current_user)):
    """List all available parquet files from local and/or S3"""
    try:
        files = _engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str, _user: dict = Depends(get_current_user)):
    """Get schema information for a specific file"""
    if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
        raise HTTPException(status_code=400, detail="Use /api/connections/{id}/tables/{name}/schema for registered tables")
    try:
        schema = _engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error("Error getting file schema: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...), _user: dict = Depends(get_current_user)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")

        file_path = Path(_engine.base_path) / file.filename

        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        logger.info(f"File uploaded: {file.filename}")

        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))



# ── Query Management Endpoints ─────────────────────────────────────────────────
# NOTE: Connection file upload endpoints live in api/connections_api.py

@router.post("/api/queries")
async def create_query(req: Request, request: SaveQueryRequest, _user: dict = Depends(require_role("admin", "analyst"))):
    """Save a new query"""
    try:
        # Do NOT validate file existence here — files may be on S3 or remote paths
        # that aren't accessible from the server at save time. Validation runs at
        # execution time when the engine actually needs the files.
        query = _db_manager.create_query(
            name=request.name,
            description=request.description,
            query_config=request.query_config.model_dump(),
            created_by=(_user or {}).get("username") or request.created_by or "guest"
        )
        _audit(_user, "save_query", req, "query", query["id"], {"name": request.name})
        logger.info(f"Query saved: {query['id']}")
        return query

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0,
                       request: Request = None):
    """List saved queries — filtered by owner/shared when auth is enabled."""
    try:
        queries = _db_manager.list_queries(active_only=active_only, limit=limit, offset=offset)
        # Row-level security: non-admin users only see own + shared queries
        if _auth_cfg.type != "none" and request:
            user = get_current_user(request)
            queries = [q for q in queries if is_owner_or_shared(q, user)]
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Join Preview ───────────────────────────────────────────────────────────────

@router.post("/api/joins/preview")
async def join_preview(request: JoinPreviewRequest, _user: dict = Depends(get_current_user)):
    """Return match statistics for a proposed join: row counts + sample rows.
    Runs lightweight DuckDB COUNT(*) queries — no execution record created."""
    import duckdb as _ddb

    def _make_read_fn(file_path: str, conn=None) -> str:
        """Return a DuckDB read expression for the given file path."""
        if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
            raise ValueError(f"Registered/Iceberg tables cannot be used in join preview: {file_path}")
        if file_path.startswith("s3://"):
            return f"read_parquet('{file_path}')"
        if file_path.lower().endswith(".csv"):
            return f"read_csv_auto('{file_path}')"
        return f"read_parquet('{file_path}')"

    try:
        # Resolve S3 credentials if needed
        _join_conn_config: dict = {}
        if request.connection_id:
            try:
                conn_cfg = _db_manager.get_connection_raw(request.connection_id)
                if conn_cfg:
                    _join_conn_config = conn_cfg.get("config", {})
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        from api.data_grid_api import _duckdb_con_with_s3 as _s3_con_fn2
        con = _s3_con_fn2(_join_conn_config, request.connection_id) if _join_conn_config else _ddb.connect()
        try:

            left_read  = _make_read_fn(request.left_file)
            right_read = _make_read_fn(request.right_file)

            on_clause = " AND ".join(
                f't0."{l}" = t1."{r}"'
                for l, r in zip(request.left_on, request.right_on)
            )
            join_type = request.how.upper()
            if join_type not in ("INNER", "LEFT", "RIGHT"):
                join_type = "FULL OUTER"

            left_count  = con.execute(f"SELECT COUNT(*) FROM {left_read} AS t0").fetchone()[0]
            right_count = con.execute(f"SELECT COUNT(*) FROM {right_read} AS t1").fetchone()[0]
            matched_count = con.execute(
                f"SELECT COUNT(*) FROM {left_read} AS t0"
                f" INNER JOIN {right_read} AS t1 ON {on_clause}"
            ).fetchone()[0]

            # Sample rows from the configured join type
            sample_df = con.execute(
                f"SELECT * FROM {left_read} AS t0"
                f" {join_type} JOIN {right_read} AS t1 ON {on_clause} LIMIT 5"
            ).fetchdf()
            columns = list(sample_df.columns)
            sample_rows = sample_df.to_dict(orient="records")

        finally:
            con.close()

        match_rate = round(matched_count / left_count, 4) if left_count > 0 else 0.0
        return {
            "left_count": left_count,
            "right_count": right_count,
            "matched_count": matched_count,
            "match_rate": match_rate,
            "columns": columns,
            "sample_rows": sample_rows,
        }
    except Exception as exc:
        logger.error("join_preview error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail=str(exc))


# ── Preview SQL Endpoint ───────────────────────────────────────────────────────

@router.post("/api/execute/preview-sql")
async def preview_sql(request: PreviewSqlRequest, _user: dict = Depends(get_current_user)):
    """Generate the actual SQL that would be executed for a given query config.
    Returns DuckDB read_parquet SQL for parquet connections, or native SQL for SQL connectors."""
    try:
        from core.parquet_engine_v2 import ParquetQueryEngine
        from core.s3_storage import build_s3_config
        from core.connectors import SQL_CONNECTOR_TYPES
        from core.connection_manager import _normalize_path

        engine_config = convert_query_config_to_engine(request.query_config)
        if request.connection_id:
            conn = _db_manager.get_connection_raw(request.connection_id)
            if conn:
                conn_type = conn.get('connection_type')
                cfg = conn.get('config', {})
                if conn_type in SQL_CONNECTOR_TYPES:
                    table_ref = request.query_config.files[0] if request.query_config.files else ""
                    sql = _engine.build_query_sql(engine_config, table_ref)
                    return {"sql": sql, "dialect": conn_type}
                elif conn_type == 'local':
                    local_path = str(_normalize_path(cfg.get('base_path', './data/parquet')))
                    local_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
                    sql = local_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
                elif conn_type == 's3':
                    s3_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(cfg),
                    )
                    sql = s3_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
        sql = _engine.get_duckdb_sql(engine_config)
        return {"sql": sql, "dialect": "duckdb"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── Downloads Endpoints ────────────────────────────────────────────────────────

@router.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0, _user: dict = Depends(get_current_user)):
    """List available downloads"""
    try:
        downloads = _db_manager.list_download_files(status=status, limit=limit, offset=offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/downloads/{file_id}")
async def download_file(file_id: str, _user: dict = Depends(get_current_user)):
    """Download a file"""
    try:
        download_info = _db_manager.get_download_file(file_id)

        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")

        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")

        file_path = Path(download_info["file_path"])

        if not file_path.exists():
            # File deleted from disk — purge the stale record so it stops showing in history
            _db_manager.update_download_file(file_id, status="deleted")
            raise HTTPException(status_code=410, detail="File has been deleted")

        _db_manager.increment_download_count(file_id)

        logger.info(f"File downloaded: {file_id}")

        _media_map = {
            ".csv":   "text/csv",
            ".xlsx":  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".json":  "application/json",
            ".parquet": "application/octet-stream",
        }
        _media_type = _media_map.get(file_path.suffix.lower(), "application/octet-stream")
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type=_media_type,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str, _user: dict = Depends(get_current_user)):
    """Mark a download as deleted and remove from disk"""
    try:
        download = _db_manager.get_download_file(file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")
        # RLS: non-admins can only delete their own downloads
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if download.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")

        # Remove file from disk if it exists
        file_path = Path(download["file_path"])
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        _db_manager.update_download_file(file_id, status="deleted")

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Query CRUD Endpoints ───────────────────────────────────────────────────────

@router.get("/api/queries/{query_id}")
async def get_query(query_id: int):
    """Get a single saved query by ID"""
    try:
        query = _db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, req: Request, _user: dict = Depends(get_current_user)):
    """Soft-delete a saved query (sets is_active=False)"""
    try:
        query = _db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only delete their own queries
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if query.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        _db_manager.delete_query(query_id, soft_delete=True)
        _audit(_user, "delete_query", req, "query", query_id, {"name": query.get("name")})
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/queries/{query_id}/favorite")
async def toggle_query_favorite(query_id: int, req: Request, _user: dict = Depends(get_current_user)):
    """Toggle the is_favorite flag on a saved query."""
    try:
        result = _db_manager.toggle_favorite(query_id)
        if not result:
            raise HTTPException(status_code=404, detail="Query not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error toggling favorite for query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/queries/{query_id}")
async def update_query(query_id: int, request: UpdateQueryRequest,
                       _user: dict = Depends(get_current_user)):
    """Update a saved query — auto-saves a version snapshot before changes."""
    try:
        existing = _db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only update their own queries
        if _auth_cfg.type != "none" and not _user.get("is_admin"):
            if existing.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        # Snapshot before change
        _db_manager.create_query_version(
            query_id=query_id,
            name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"],
            changed_by=_user.get("username"), change_note=request.change_note,
        )
        updates = {}
        if request.name is not None:        updates["name"] = request.name
        if request.description is not None: updates["description"] = request.description
        if request.query_config is not None:
            updates["query_config"] = request.query_config.model_dump()
        result = _db_manager.update_query(query_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Version History Endpoints ──────────────────────────────────────────────────

@router.get("/api/queries/{query_id}/versions")
async def list_query_versions(query_id: int, _user: dict = Depends(get_current_user)):
    try:
        return _db_manager.list_query_versions(query_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/queries/{query_id}/versions/{version_id}/restore")
async def restore_query_version(query_id: int, version_id: int,
                                _user: dict = Depends(get_current_user)):
    try:
        v = _db_manager.get_query_version(version_id)
        if not v or v["query_id"] != query_id:
            raise HTTPException(status_code=404, detail="Version not found")
        existing = _db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # Save current state as a version before restoring
        _db_manager.create_query_version(
            query_id=query_id, name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"], changed_by=_user.get("username"),
            change_note=f"Auto-saved before restore to v{v['version_number']}",
        )
        _db_manager.update_query(query_id, name=v["name"], description=v["description"],
                                 query_config=v["query_config"])
        return {"message": f"Restored to version {v['version_number']}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Query Sharing Endpoints ────────────────────────────────────────────────────

@router.post("/api/queries/{query_id}/share")
async def share_query(query_id: int, request: ShareQueryRequest,
                      _user: dict = Depends(get_current_user)):
    q = _db_manager.get_query(query_id)
    if not q:
        raise HTTPException(status_code=404, detail="Query not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = _db_manager.create_share(query_id, _user.get("username"), expires_at)
    return share


@router.get("/api/queries/{query_id}/shares")
async def list_query_shares(query_id: int, _user: dict = Depends(get_current_user)):
    return _db_manager.list_shares(query_id)


@router.delete("/api/queries/{query_id}/shares/{token}")
async def revoke_share(query_id: int, token: str, _user: dict = Depends(get_current_user)):
    _db_manager.deactivate_share(token)
    return {"message": "Share revoked"}


# PUBLIC endpoint — NO auth (accessible by anyone with the link)
@router.get("/api/shared/{token}")
async def get_shared_query(token: str):
    share = _db_manager.get_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)
    _db_manager.increment_share_access(token)
    q = _db_manager.get_query(share["query_id"])
    if not q:
        raise HTTPException(status_code=404, detail="Query no longer exists")
    return {"query": q, "share": share}


# ── Dashboard Sharing Endpoints ────────────────────────────────────────────────

@router.post("/api/dashboards/{dashboard_id}/share")
async def share_dashboard(dashboard_id: int, request: ShareDashboardRequest,
                          _user: dict = Depends(get_current_user)):
    d = _db_manager.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = _db_manager.create_dashboard_share(dashboard_id, _user.get("username"), expires_at)
    return share


@router.get("/api/shared-dashboard/{token}")
async def get_shared_dashboard(token: str):
    """Public endpoint — no auth required."""
    share = _db_manager.get_dashboard_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)
    _db_manager.increment_dashboard_share_access(token)
    d = _db_manager.get_dashboard(share["dashboard_id"])
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard no longer exists")
    widgets = _db_manager.list_widgets(share["dashboard_id"])
    return {"dashboard": d, "widgets": widgets, "share": share}


# ── Executions Endpoints ───────────────────────────────────────────────────────

@router.get("/api/executions")
async def list_executions(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = None,
    _user: dict = Depends(get_current_user),
):
    """List recent query executions"""
    try:
        executions = _db_manager.list_executions(
            limit=limit,
            offset=offset,
            status=status if status else None
        )
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str, _user: dict = Depends(get_current_user)):
    """Get a single execution record by ID"""
    try:
        execution = _db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str, _user: dict = Depends(get_current_user)):
    """
    Get status of an execution — polled by ReportPage.
    Returns: { execution_id, status, total_rows, started_at, completed_at, error_message }
    status values: pending | processing | completed | failed
    """
    try:
        execution = _db_manager.get_execution(execution_id)

        if not execution:
            # Not in DB yet (just started) — check downloads as fallback
            downloads = _db_manager.list_download_files(status="available", limit=500, offset=0)
            match = next(
                (d for d in downloads if d.get("execution_id") == execution_id),
                None
            )
            if match:
                return {
                    "execution_id": execution_id,
                    "status": "completed",
                    "file_id": match["file_id"],
                    "filename": match["filename"],
                    "total_rows": None,
                }
            return {"execution_id": execution_id, "status": "pending"}

        return {
            "execution_id": execution_id,
            "status": execution.get("status", "unknown"),
            "total_rows": execution.get("total_rows"),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "error_message": execution.get("error_message"),
        }

    except Exception as e:
        logger.error(f"Error getting execution status {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str, _user: dict = Depends(get_current_user)):
    """
    Cancel a running execution.
    Works by:
      1. Setting the threading.Event — stops the worker thread after the current chunk.
      2. Cancelling the asyncio.Task — stops the coroutine waiting on run_in_executor.
      3. Marking the DB record as cancelled immediately.
    """
    try:
        execution = _db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # 1. Signal cancellation — route depends on executor mode
        from core.config import executor as _exec_cfg
        if _exec_cfg.mode == "external":
            # External executor: set cancel_requested flag in task queue
            from core.queue_backend import get_task_queue
            get_task_queue().request_task_cancel(execution_id)
        else:
            # Embedded mode: signal the worker pool directly
            from core.worker_pool import get_pool
            try:
                get_pool().cancel_by_execution_id(execution_id)
            except RuntimeError:
                cancel_event = cancellation_flags.get(execution_id)
                if cancel_event:
                    cancel_event.set()
                task = running_tasks.get(execution_id)
                if task and not task.done():
                    task.cancel()

        # 2. Mark as cancelled in DB immediately (don't wait for thread/executor to stop)
        _db_manager.update_execution(
            execution_id,
            status="cancelled",
            error_message="Cancelled by user"
        )

        if _ws_manager:
            await _ws_manager.broadcast({
                "type": "execution_cancelled",
                "execution_id": execution_id,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

        _db_manager.audit("system", "cancel_query", resource_type="execution",
                          resource_id=execution_id)
        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: /api/exports lives in api/admin_api.py
