"""
Phase 22F — GraphQL API (Strawberry)

Provides a /graphql endpoint (Playground + queries/mutations) wrapping existing
REST business logic via the shared DatabaseManager singleton.

Usage:
    pip install strawberry-graphql[fastapi]

Wire from main.py:
    from api.graphql_api import graphql_app, set_graphql_dependencies
    set_graphql_dependencies(db_manager, auth_cfg)
    app.include_router(graphql_app, prefix="/graphql", tags=["graphql"])
"""

from __future__ import annotations

import logging
from typing import Optional, List
from datetime import datetime

logger = logging.getLogger(__name__)

# ── Module-level singletons (set from main.py at startup) ────────────────────
_db_manager = None
_auth_cfg = None


def set_graphql_dependencies(db_manager, auth_cfg) -> None:
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


# ── Lazy init — defer Strawberry import until first use ──────────────────────
_graphql_app = None


def get_graphql_router():
    """Return the Strawberry FastAPI GraphQLRouter, creating it on first call."""
    global _graphql_app
    if _graphql_app is not None:
        return _graphql_app

    try:
        import strawberry
        from strawberry.fastapi import GraphQLRouter
        from strawberry.types import Info
    except ImportError:
        logger.warning("strawberry-graphql not installed — GraphQL endpoint disabled")
        from fastapi import APIRouter
        _graphql_app = APIRouter()
        return _graphql_app

    # ══════════════════════════════════════════════════════════════════════════
    # Strawberry Type Definitions
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.type
    class ConnectionType:
        id: int
        name: str
        connection_type: str
        is_active: bool
        created_at: Optional[str] = None
        created_by: Optional[str] = None
        description: Optional[str] = None

    @strawberry.type
    class SavedQueryType:
        id: int
        name: str
        description: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None
        updated_at: Optional[str] = None
        is_active: bool = True
        is_favorite: bool = False
        is_shared: bool = False
        execution_count: int = 0
        last_executed_at: Optional[str] = None

    @strawberry.type
    class ExecutionType:
        id: int
        execution_id: str
        status: str
        started_at: Optional[str] = None
        completed_at: Optional[str] = None
        total_rows: int = 0
        file_size_bytes: int = 0
        error_message: Optional[str] = None
        executed_by: Optional[str] = None

    @strawberry.type
    class ReportType:
        id: int
        name: str
        description: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None
        is_active: bool = True
        report_type: Optional[str] = None

    @strawberry.type
    class UserType:
        username: str
        role: str
        display_name: Optional[str] = None
        is_admin: bool = False

    @strawberry.type
    class DashboardType:
        id: int
        name: str
        description: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None
        is_active: bool = True

    @strawberry.type
    class WorkspaceType:
        id: int
        name: str
        slug: str
        description: Optional[str] = None
        is_default: bool = False

    @strawberry.type
    class ScheduleType:
        id: int
        name: str
        cron_expression: Optional[str] = None
        is_active: bool = True
        next_run_at: Optional[str] = None
        last_run_at: Optional[str] = None

    @strawberry.type
    class DeleteResult:
        success: bool
        message: str

    @strawberry.type
    class PaginatedExecutions:
        items: List[ExecutionType]
        total: int

    # ── Helper: dict → strawberry type ────────────────────────────────────────

    def _to_connection(d: dict) -> ConnectionType:
        return ConnectionType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            connection_type=d.get("connection_type", ""),
            is_active=d.get("is_active", True),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            created_by=d.get("created_by"),
            description=d.get("description"),
        )

    def _to_query(d: dict) -> SavedQueryType:
        return SavedQueryType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            updated_at=str(d["updated_at"]) if d.get("updated_at") else None,
            is_active=d.get("is_active", True),
            is_favorite=d.get("is_favorite", False),
            is_shared=d.get("is_shared", False),
            execution_count=d.get("execution_count", 0),
            last_executed_at=str(d["last_executed_at"]) if d.get("last_executed_at") else None,
        )

    def _to_execution(d: dict) -> ExecutionType:
        return ExecutionType(
            id=d.get("id", 0),
            execution_id=d.get("execution_id", ""),
            status=d.get("status", "unknown"),
            started_at=str(d["started_at"]) if d.get("started_at") else None,
            completed_at=str(d["completed_at"]) if d.get("completed_at") else None,
            total_rows=d.get("total_rows", 0),
            file_size_bytes=d.get("file_size_bytes", 0),
            error_message=d.get("error_message"),
            executed_by=d.get("executed_by"),
        )

    def _to_report(d: dict) -> ReportType:
        return ReportType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            is_active=d.get("is_active", True),
            report_type=d.get("report_type"),
        )

    def _to_dashboard(d: dict) -> DashboardType:
        return DashboardType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            is_active=d.get("is_active", True),
        )

    def _to_workspace(d: dict) -> WorkspaceType:
        return WorkspaceType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            slug=d.get("slug", ""),
            description=d.get("description"),
            is_default=d.get("is_default", False),
        )

    def _to_schedule(d: dict) -> ScheduleType:
        return ScheduleType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            cron_expression=d.get("cron_expression"),
            is_active=d.get("is_active", True),
            next_run_at=str(d["next_run_at"]) if d.get("next_run_at") else None,
            last_run_at=str(d["last_run_at"]) if d.get("last_run_at") else None,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Query Root
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.type
    class Query:
        # ── Connections ───────────────────────────────────────────────────────
        @strawberry.field(description="List data connections")
        def connections(self, active_only: bool = True) -> List[ConnectionType]:
            rows = _db_manager.list_connections(active_only=active_only)
            return [_to_connection(r) for r in rows]

        @strawberry.field(description="Get a single connection by ID")
        def connection(self, id: int) -> Optional[ConnectionType]:
            row = _db_manager.get_connection(id)
            return _to_connection(row) if row else None

        # ── Saved Queries ─────────────────────────────────────────────────────
        @strawberry.field(description="List saved queries")
        def queries(self, active_only: bool = True) -> List[SavedQueryType]:
            rows = _db_manager.list_queries(active_only=active_only)
            return [_to_query(r) for r in rows]

        @strawberry.field(description="Get a single saved query by ID")
        def query(self, id: int) -> Optional[SavedQueryType]:
            row = _db_manager.get_query(id)
            return _to_query(row) if row else None

        # ── Executions ────────────────────────────────────────────────────────
        @strawberry.field(description="List query executions")
        def executions(
            self,
            limit: int = 50,
            offset: int = 0,
            status: Optional[str] = None,
        ) -> PaginatedExecutions:
            rows = _db_manager.list_executions(limit=limit, offset=offset, status=status)
            return PaginatedExecutions(
                items=[_to_execution(r) for r in rows],
                total=len(rows),
            )

        @strawberry.field(description="Get a single execution by ID")
        def execution(self, execution_id: str) -> Optional[ExecutionType]:
            row = _db_manager.get_execution(execution_id)
            return _to_execution(row) if row else None

        # ── Reports ───────────────────────────────────────────────────────────
        @strawberry.field(description="List reports")
        def reports(self, active_only: bool = True) -> List[ReportType]:
            rows = _db_manager.list_reports(active_only=active_only)
            return [_to_report(r) for r in rows]

        @strawberry.field(description="Get a single report by ID")
        def report(self, id: int) -> Optional[ReportType]:
            row = _db_manager.get_report(id)
            return _to_report(row) if row else None

        # ── Dashboards ────────────────────────────────────────────────────────
        @strawberry.field(description="List dashboards")
        def dashboards(self) -> List[DashboardType]:
            try:
                rows = _db_manager.list_dashboards()
                return [_to_dashboard(r) for r in rows]
            except Exception:
                return []

        # ── Workspaces ────────────────────────────────────────────────────────
        @strawberry.field(description="List workspaces")
        def workspaces(self) -> List[WorkspaceType]:
            try:
                rows = _db_manager.list_workspaces()
                return [_to_workspace(r) for r in rows]
            except Exception:
                return []

        # ── Schedules ─────────────────────────────────────────────────────────
        @strawberry.field(description="List schedules")
        def schedules(self) -> List[ScheduleType]:
            try:
                rows = _db_manager.list_schedules()
                return [_to_schedule(r) for r in rows]
            except Exception:
                return []

    # ══════════════════════════════════════════════════════════════════════════
    # Mutation Root
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.input
    class SaveQueryInput:
        name: str
        description: Optional[str] = None
        query_config: str  # JSON string — client serialises the config

    @strawberry.input
    class UpdateQueryInput:
        name: Optional[str] = None
        description: Optional[str] = None
        is_favorite: Optional[bool] = None
        is_shared: Optional[bool] = None

    @strawberry.type
    class Mutation:
        # ── Saved Queries ─────────────────────────────────────────────────────
        @strawberry.mutation(description="Create a saved query")
        def create_query(self, input: SaveQueryInput) -> SavedQueryType:
            import json
            config = json.loads(input.query_config)
            row = _db_manager.create_query(
                name=input.name,
                query_config=config,
                description=input.description,
                created_by="graphql_user",
            )
            return _to_query(row)

        @strawberry.mutation(description="Update a saved query")
        def update_query(self, id: int, input: UpdateQueryInput) -> Optional[SavedQueryType]:
            updates = {}
            if input.name is not None:
                updates["name"] = input.name
            if input.description is not None:
                updates["description"] = input.description
            if input.is_favorite is not None:
                updates["is_favorite"] = input.is_favorite
            if input.is_shared is not None:
                updates["is_shared"] = input.is_shared
            row = _db_manager.update_query(id, **updates)
            return _to_query(row) if row else None

        @strawberry.mutation(description="Delete a saved query (soft delete)")
        def delete_query(self, id: int) -> DeleteResult:
            ok = _db_manager.delete_query(id, soft_delete=True)
            return DeleteResult(success=ok, message="Deleted" if ok else "Not found")

        # ── Reports ───────────────────────────────────────────────────────────
        @strawberry.mutation(description="Delete a report (soft delete)")
        def delete_report(self, id: int) -> DeleteResult:
            ok = _db_manager.delete_report(id, soft_delete=True)
            return DeleteResult(success=ok, message="Deleted" if ok else "Not found")

        # ── Connections ───────────────────────────────────────────────────────
        @strawberry.mutation(description="Delete a connection (soft delete)")
        def delete_connection(self, id: int) -> DeleteResult:
            ok = _db_manager.delete_connection(id, soft_delete=True)
            return DeleteResult(success=ok, message="Deleted" if ok else "Not found")

    # ══════════════════════════════════════════════════════════════════════════
    # Build schema + router
    # ══════════════════════════════════════════════════════════════════════════

    schema = strawberry.Schema(query=Query, mutation=Mutation)
    _graphql_app = GraphQLRouter(schema, path="/")

    logger.info("GraphQL endpoint initialised (Strawberry %s)", strawberry.__version__)
    return _graphql_app
