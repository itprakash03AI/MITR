"""
Unified FastAPI auth dependencies — used by ALL routers.

Every router imports from here instead of duplicating auth logic.
Replaces the per-router _get_user() copies spread across 5+ files.

Initialization:
    Call ``init_deps(auth_cfg, db_manager)`` once at application startup
    (in main.py after db_manager is created).

Usage in routers:
    from api.deps import get_current_user, require_admin, require_role, require_execute_access

    @router.get("/api/something")
    async def my_endpoint(user: dict = Depends(get_current_user)):
        ...

    @router.delete("/api/admin/something")
    async def admin_only(user: dict = Depends(require_admin)):
        ...
"""
from __future__ import annotations

from typing import Optional
from fastapi import Depends, Header, HTTPException, Request

from core.sessions import get_session

# ── Module-level singletons — populated by init_deps() at startup ─────────────
_auth_cfg   = None   # core.config.auth singleton
_db_manager = None   # DatabaseManager singleton


def init_deps(auth_cfg, db_manager) -> None:
    """Called once from main.py startup after components are created."""
    global _auth_cfg, _db_manager
    _auth_cfg   = auth_cfg
    _db_manager = db_manager


# ── Core dependency ────────────────────────────────────────────────────────────

def get_current_user(request: Request) -> dict:
    """
    FastAPI dependency — resolves the caller's identity.

    Priority:
      1. auth.type == "none"  →  guest admin (dev/testing mode)
      2. Bearer <token>       →  server-side session lookup
      3. Basic <base64>       →  direct AD/local authentication (fallback)

    Raises HTTP 401 if credentials are missing or invalid.
    """
    if not _auth_cfg or _auth_cfg.type == "none":
        return {
            "username": "guest",
            "display_name": "Guest",
            "is_admin": True,
            "groups": [],
            "role": "admin",
        }

    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Bearer → session lookup (preferred — no password ever re-transmitted)
    if auth_header.startswith("Bearer "):
        user = get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Basic → direct authentication (legacy clients / API testing)
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        user = authenticate_user(username, password)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        return user
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))


# ── Role-based dependencies ────────────────────────────────────────────────────

def require_admin(user: dict = Depends(get_current_user)) -> dict:
    """Dependency that enforces admin-only access."""
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def require_role(*allowed_roles: str):
    """
    Factory — returns a dependency that allows only the specified roles.

    Example:
        @router.post("/api/reports")
        async def create_report(user: dict = Depends(require_role("admin", "analyst"))):
    """
    def _dep(user: dict = Depends(get_current_user)) -> dict:
        if _auth_cfg and _auth_cfg.type != "none":
            role = (user or {}).get("role", "viewer")
            if role not in allowed_roles:
                raise HTTPException(
                    status_code=403,
                    detail=f"Requires role: {', '.join(allowed_roles)}",
                )
        return user
    return _dep


def require_execute_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    x_embed_token: Optional[str] = Header(None),
    _user: Optional[dict] = Depends(get_current_user),
) -> dict:
    """
    Dependency for execution endpoints.
    Grants access via normal auth OR a valid share/embed token —
    enabling SharedQueryPage, SharedDashboardPage, and EmbeddedReportPage
    to execute queries without requiring the viewer to be logged in.
    """
    if not _auth_cfg or _auth_cfg.type == "none":
        return _user or {"username": "guest", "role": "admin", "is_admin": True}

    # Authenticated analyst/admin
    if _user and _user.get("role") in ("admin", "analyst"):
        return _user

    # Share-token path
    if x_share_token and _db_manager:
        try:
            share = _db_manager.get_share_by_token(x_share_token)
            if not share:
                share = _db_manager.get_dashboard_share_by_token(x_share_token)
            if share and share.get("is_active"):
                return {
                    "username": f"shared:{x_share_token[:8]}",
                    "role": "analyst",
                    "is_admin": False,
                }
        except Exception:
            pass

    # Embed-token path (Phase 27)
    if x_embed_token and _db_manager:
        try:
            from datetime import datetime, timezone as _tz
            tok = _db_manager.get_embed_token(x_embed_token)
            if tok and tok.get("is_active"):
                expires = tok.get("expires_at")
                if expires:
                    if isinstance(expires, str):
                        expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    if expires.tzinfo is None:
                        expires = expires.replace(tzinfo=_tz.utc)
                    if datetime.now(_tz.utc) > expires:
                        raise HTTPException(status_code=410, detail="Embed token expired")
                return {
                    "username": f"embed:{x_embed_token[:8]}",
                    "role": "analyst",
                    "is_admin": False,
                }
        except HTTPException:
            raise
        except Exception:
            pass

    raise HTTPException(status_code=403, detail="Authorization required")


# ── Ownership helper ───────────────────────────────────────────────────────────

def is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if user owns item, it's shared, or user is admin."""
    if not user or user.get("is_admin"):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )
