"""
Local Tables API — CRUD, file upload/promote, preview, profile, and table favorites.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_local_table_dependencies(...)`` once at startup (in main.py after
    all core components are created).

Endpoints:
  GET    /api/local-tables                    — list local tables
  GET    /api/local-tables/storage            — disk usage stats (admin/analyst)
  GET    /api/local-tables/{lt_id}            — get single local table
  POST   /api/local-tables                    — create local table record
  PUT    /api/local-tables/{lt_id}            — update local table
  DELETE /api/local-tables/{lt_id}            — delete local table + storage
  POST   /api/local-tables/promote            — promote download file → local table
  POST   /api/local-tables/upload             — upload CSV/Excel/JSON/Parquet file
  GET    /api/local-tables/{lt_id}/schema     — read parquet schema

  POST   /api/tables/preview                  — preview first N rows of any table type
  POST   /api/tables/profile                  — column-level stats
  POST   /api/tables/favorite                 — toggle table favorite
  GET    /api/tables/favorites                — list favorites for current user
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_role

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Local Tables"])

# ── Module-level singletons — populated by set_local_table_dependencies() ────

_db_manager = None
_engine = None
_ws_manager = None
_lt_cfg = None
_mv_cfg = None
_paths = None
_light_executor = None


def set_local_table_dependencies(db_manager, engine, ws_manager, lt_cfg, mv_cfg, paths,
                                  light_executor=None) -> None:
    """Called once from main.py after all core components are created."""
    global _db_manager, _engine, _ws_manager, _lt_cfg, _mv_cfg, _paths, _light_executor
    _db_manager = db_manager
    _engine = engine
    _ws_manager = ws_manager
    _lt_cfg = lt_cfg
    _mv_cfg = mv_cfg
    _paths = paths
    _light_executor = light_executor


def _get_light_executor():
    """Return the dedicated streaming/metadata executor (injected at startup)."""
    return _light_executor


# ── Pydantic models ────────────────────────────────────────────────────────────

class LocalTableCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


class LocalTableUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    visibility: Optional[str] = None
    auto_discard_days: Optional[int] = None
    is_active: Optional[bool] = None


class LocalTablePromoteModel(BaseModel):
    file_id: str
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


# ── Sync helper functions ──────────────────────────────────────────────────────

def _promote_download_sync(lt_id: int, source_path: str):
    """Copy a download parquet file into local table storage and read metadata."""
    import shutil
    import pyarrow.parquet as _pq

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)

    try:
        # Copy parquet file (don't move — keeps download intact)
        dest = os.path.join(lt_dir, "data.parquet")
        shutil.copy2(source_path, dest)

        # Read schema + metadata
        pf = _pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for i, field in enumerate(pf.schema_arrow):
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d promoted successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table promote failed for %d: %s", lt_id, e)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass


def _upload_file_to_local_table_sync(lt_id: int, temp_path: str, original_filename: str):
    """Convert uploaded file (CSV/Excel/JSON/Parquet) to local parquet."""
    import shutil
    import duckdb as _ddb

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)
    dest = os.path.join(lt_dir, "data.parquet")
    ext = os.path.splitext(original_filename)[1].lower()

    try:
        if ext == ".parquet":
            shutil.copy2(temp_path, dest)
        else:
            con = _ddb.connect()
            try:
                temp_fixed = temp_path.replace("\\", "/")
                dest_fixed = dest.replace("\\", "/")
                if ext in (".csv", ".tsv", ".txt"):
                    con.execute(f"COPY (SELECT * FROM read_csv_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                elif ext in (".xlsx", ".xls"):
                    # Try DuckDB spatial extension for Excel
                    try:
                        con.execute("INSTALL spatial; LOAD spatial;")
                        con.execute(f"COPY (SELECT * FROM st_read('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                    except Exception:
                        # Fallback to pandas
                        import pandas as pd
                        df = pd.read_excel(temp_path)
                        df.to_parquet(dest, index=False)
                elif ext == ".json":
                    con.execute(f"COPY (SELECT * FROM read_json_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                else:
                    raise ValueError(f"Unsupported file type: {ext}")
            finally:
                con.close()

        # Read final parquet metadata
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for field in pf.schema_arrow:
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d uploaded successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table upload failed for %d: %s", lt_id, e)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass
    finally:
        # Cleanup temp file
        try:
            os.unlink(temp_path)
        except Exception:
            pass


def _cleanup_expired_local_tables():
    """Auto-discard public local tables unused beyond their auto_discard_days."""
    import shutil
    expired = _db_manager.list_expired_local_tables()
    count = 0
    for lt in expired:
        try:
            lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt["id"]))
            if os.path.isdir(lt_dir):
                shutil.rmtree(lt_dir)
            _db_manager.delete_local_table(lt["id"])
            count += 1
            logger.info("Auto-discarded local table %d (%s) — unused for %d+ days",
                        lt["id"], lt["name"], lt["auto_discard_days"])
        except Exception as e:
            logger.warning("Failed to discard local table %d: %s", lt["id"], e)
    if count > 0:
        try:
            _ws_manager.broadcast_sync({"type": "local_tables_cleanup", "discarded_count": count})
        except Exception:
            pass
        logger.info("Auto-discard cleaned up %d expired local tables", count)


# ── Table resolver helper ──────────────────────────────────────────────────────

def _resolve_table_duckdb_sql(table_path: str, connection_id: int = None) -> tuple:
    """Resolve a table_path to a DuckDB-compatible FROM clause + optional DuckDB connection.

    Returns (from_clause: str, con: duckdb.Connection | None, needs_close: bool).
    If con is returned, caller must close it.
    """
    import duckdb as _ddb

    if table_path.startswith("__materialized__:"):
        mv_name = table_path.replace("__materialized__:", "")
        mv_rec = _db_manager.get_materialized_view_by_name(mv_name)
        if not mv_rec or mv_rec["status"] != "ready":
            raise ValueError(f"Materialized view '{mv_name}' not found or not ready")
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_rec["id"]))
        import glob as _gm
        pq_files = _gm.glob(os.path.join(mv_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for MV '{mv_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__local__:"):
        lt_name = table_path.replace("__local__:", "")
        lt_rec = _db_manager.get_local_table_by_name(lt_name)
        if not lt_rec or lt_rec["status"] != "ready":
            raise ValueError(f"Local table '{lt_name}' not found or not ready")
        lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_rec["id"]))
        import glob as _gm2
        pq_files = _gm2.glob(os.path.join(lt_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for local table '{lt_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__registered__:"):
        reg_name = table_path.replace("__registered__:", "")
        if not connection_id:
            raise ValueError("connection_id required for registered table preview")
        conn_record = _db_manager.get_connection_raw(connection_id)
        if not conn_record:
            raise ValueError(f"Connection {connection_id} not found")
        cfg = conn_record.get("config", {})
        registered_tables = cfg.get("registered_tables", [])
        tdef = None
        for t in registered_tables:
            if t["name"] == reg_name:
                tdef = t
                break
        if not tdef:
            raise ValueError(f"Registered table '{reg_name}' not found in connection")
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg, connection_id=connection_id)
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        bucket = cfg["bucket_name"]
        if fmt == "iceberg":
            from_clause = f"iceberg_scan('s3://{bucket}/{prefix}')"
        elif fmt == "csv":
            from_clause = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
        else:
            from_clause = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
        return from_clause, con, True

    # Raw file path — local parquet or csv
    norm = table_path.replace("\\", "/")
    if norm.lower().endswith(".csv"):
        return f"read_csv_auto('{norm}')", None, False
    return f"read_parquet('{norm}', hive_partitioning=true)", None, False


# ── Local Table CRUD endpoints ────────────────────────────────────────────────

@router.get("/api/local-tables")
async def list_local_tables(visibility: Optional[str] = None,
                            created_by: Optional[str] = None,
                            _user: dict = Depends(get_current_user)):
    return _db_manager.list_local_tables(visibility=visibility, created_by=created_by)


@router.get("/api/local-tables/storage")
async def local_tables_storage(_user: dict = Depends(require_role("admin", "analyst"))):
    """Disk usage stats for local tables."""
    tables = _db_manager.list_local_tables(active_only=False)
    total_bytes = sum(lt.get("size_bytes", 0) for lt in tables)
    return {
        "total_tables": len(tables),
        "max_tables": _lt_cfg.max_tables,
        "total_size_bytes": total_bytes,
        "max_size_bytes": _lt_cfg.max_size_mb * 1024 * 1024,
        "storage_dir": _lt_cfg.storage_dir,
    }


@router.get("/api/local-tables/{lt_id}")
async def get_local_table(lt_id: int, _user: dict = Depends(get_current_user)):
    lt = _db_manager.get_local_table(lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")
    return lt


@router.post("/api/local-tables")
async def create_local_table(body: LocalTableCreateModel,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    # Check limits
    existing = _db_manager.list_local_tables()
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if _db_manager.get_local_table_by_name(body.name):
        raise HTTPException(400, f"Local table '{body.name}' already exists")

    username = _user.get("username", "unknown") if _user else "unknown"
    lt = _db_manager.create_local_table(
        name=body.name,
        description=body.description,
        source_type="manual_create",
        visibility=body.visibility,
        auto_discard_days=body.auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="pending",
    )
    # Update storage_path with actual ID
    _db_manager.update_local_table(lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))
    return {**lt, "storage_path": os.path.join(_lt_cfg.storage_dir, str(lt["id"]))}


@router.put("/api/local-tables/{lt_id}")
async def update_local_table(lt_id: int, body: LocalTableUpdateModel,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    lt = _db_manager.get_local_table(lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    updates = body.dict(exclude_unset=True)
    if "name" in updates and updates["name"] != lt["name"]:
        if _db_manager.get_local_table_by_name(updates["name"]):
            raise HTTPException(400, f"Local table '{updates['name']}' already exists")

    result = _db_manager.update_local_table(lt_id, **updates)
    return result


@router.delete("/api/local-tables/{lt_id}")
async def delete_local_table(lt_id: int,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    lt = _db_manager.get_local_table(lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    import shutil
    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    if os.path.isdir(lt_dir):
        shutil.rmtree(lt_dir)

    _db_manager.delete_local_table(lt_id)
    try:
        _ws_manager.broadcast_sync({"type": "local_table_deleted", "id": lt_id, "name": lt["name"]})
    except Exception:
        pass
    return {"status": "deleted", "id": lt_id}


@router.post("/api/local-tables/promote")
async def promote_to_local_table(body: LocalTablePromoteModel,
                                 _user: dict = Depends(require_role("admin", "analyst"))):
    """Promote a download file to a local table (copies parquet)."""
    # Check limits
    existing = _db_manager.list_local_tables()
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if _db_manager.get_local_table_by_name(body.name):
        raise HTTPException(400, f"Local table '{body.name}' already exists")

    # Find the download file
    dl = _db_manager.get_download_file(body.file_id)
    if not dl:
        raise HTTPException(404, f"Download file '{body.file_id}' not found")
    if not dl.get("file_path", "").endswith(".parquet"):
        raise HTTPException(400, "Only parquet files can be promoted to local tables")
    source_path = dl["file_path"]
    if not os.path.isfile(source_path):
        raise HTTPException(400, "Download file no longer exists on disk")

    username = _user.get("username", "unknown") if _user else "unknown"
    lt = _db_manager.create_local_table(
        name=body.name,
        description=body.description,
        source_type="download_promote",
        source_file_id=body.file_id,
        original_filename=dl.get("filename", ""),
        visibility=body.visibility,
        auto_discard_days=body.auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="processing",
    )
    _db_manager.update_local_table(lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))

    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, _promote_download_sync, lt["id"], source_path)
    return {**lt, "status": "processing"}


@router.post("/api/local-tables/upload")
async def upload_local_table(request: Request,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    """Upload a file (CSV/Excel/JSON/Parquet) and create a local table."""
    form = await request.form()
    file = form.get("file")
    if not file:
        raise HTTPException(400, "No file provided")

    name = form.get("name", "").strip()
    if not name:
        name = os.path.splitext(file.filename)[0]
    description = form.get("description", "").strip() or None
    visibility = form.get("visibility", "public").strip()
    auto_discard_days = int(form.get("auto_discard_days", "10"))

    # Check limits
    existing = _db_manager.list_local_tables()
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if _db_manager.get_local_table_by_name(name):
        raise HTTPException(400, f"Local table '{name}' already exists")

    # Validate extension
    ext = os.path.splitext(file.filename)[1].lower()
    allowed = {".csv", ".tsv", ".txt", ".xlsx", ".xls", ".json", ".parquet"}
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type: {ext}. Allowed: {', '.join(sorted(allowed))}")

    # Save to temp file
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext, dir=str(_paths.data_dir))
    size = 0
    try:
        while True:
            chunk = await file.read(1024 * 1024)  # 1MB chunks
            if not chunk:
                break
            size += len(chunk)
            if size > _lt_cfg.max_upload_size_bytes:
                tmp.close()
                os.unlink(tmp.name)
                raise HTTPException(400, f"File exceeds max upload size ({_lt_cfg.max_upload_size_mb} MB)")
            tmp.write(chunk)
        tmp.close()
    except HTTPException:
        raise
    except Exception as e:
        tmp.close()
        try:
            os.unlink(tmp.name)
        except Exception:
            pass
        raise HTTPException(500, f"Failed to save upload: {e}")

    username = _user.get("username", "unknown") if _user else "unknown"
    lt = _db_manager.create_local_table(
        name=name,
        description=description,
        source_type="file_upload",
        original_filename=file.filename,
        visibility=visibility,
        auto_discard_days=auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="processing",
    )
    _db_manager.update_local_table(lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))

    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, _upload_file_to_local_table_sync, lt["id"], tmp.name, file.filename)
    return {**lt, "status": "processing"}


@router.get("/api/local-tables/{lt_id}/schema")
async def get_local_table_schema(lt_id: int, _user: dict = Depends(get_current_user)):
    """Read schema from local parquet files of a local table."""
    lt = _db_manager.get_local_table(lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    # Return cached schema if available
    if lt.get("schema_json"):
        return {"columns": lt["schema_json"], "source": lt["name"]}

    if lt["status"] != "ready":
        raise HTTPException(400, "Local table not ready")

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    import glob as _glob_mod
    pq_files = sorted(_glob_mod.glob(os.path.join(lt_dir, "*.parquet")))
    if not pq_files:
        raise HTTPException(400, "No parquet files found")

    try:
        import pyarrow.parquet as pq
        schema = pq.read_schema(pq_files[0])
        columns = [{"name": f.name, "type": str(f.type), "nullable": f.nullable} for f in schema]
        return {"columns": columns, "source": lt["name"], "file_count": len(pq_files)}
    except Exception as e:
        raise HTTPException(500, f"Failed to read schema: {e}")


# ── Table Preview / Profile / Favorites (Phase 1 UX) ─────────────────────────

@router.post("/api/tables/preview")
async def preview_table(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Preview first N rows of any table type.
    Body: { table_path, connection_id (optional), limit (default 100) }
    """
    table_path = body.get("table_path")
    connection_id = body.get("connection_id")
    limit = min(body.get("limit", 100), 1000)

    if not table_path:
        raise HTTPException(400, "table_path is required")

    try:
        import duckdb as _ddb
        loop = asyncio.get_running_loop()

        def _do_preview():
            from_clause, con, needs_close = _resolve_table_duckdb_sql(table_path, connection_id)
            local_con = con or _ddb.connect()
            try:
                result = local_con.execute(f"SELECT * FROM {from_clause} LIMIT {limit}").fetchdf()
                columns = [
                    {"name": col, "type": str(result[col].dtype)}
                    for col in result.columns
                ]
                rows = result.values.tolist()
                # Estimate total rows
                try:
                    count_result = local_con.execute(
                        f"SELECT COUNT(*) FROM {from_clause}"
                    ).fetchone()
                    total_estimate = count_result[0] if count_result else len(rows)
                except Exception:
                    total_estimate = len(rows)
                return {"columns": columns, "rows": rows, "total_rows_estimate": total_estimate}
            finally:
                if needs_close and con:
                    con.close()
                elif not con:
                    local_con.close()

        result = await loop.run_in_executor(_get_light_executor(), _do_preview)
        return result

    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error("Table preview failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Preview failed: {e}")


@router.post("/api/tables/profile")
async def profile_table(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Column-level stats: min, max, null_count, distinct_count.
    Body: { table_path, connection_id (optional), columns (optional list), sample_size (default 10000) }
    """
    table_path = body.get("table_path")
    connection_id = body.get("connection_id")
    requested_columns = body.get("columns")  # None = all columns
    sample_size = min(body.get("sample_size", 10000), 100000)

    if not table_path:
        raise HTTPException(400, "table_path is required")

    try:
        import duckdb as _ddb
        loop = asyncio.get_running_loop()

        def _do_profile():
            from_clause, con, needs_close = _resolve_table_duckdb_sql(table_path, connection_id)
            local_con = con or _ddb.connect()
            try:
                # Get column info from schema
                schema_result = local_con.execute(
                    f"SELECT * FROM {from_clause} LIMIT 0"
                ).description
                all_columns = [(desc[0], desc[1]) for desc in schema_result]

                if requested_columns:
                    all_columns = [(n, t) for n, t in all_columns if n in requested_columns]

                sample_clause = f"(SELECT * FROM {from_clause} LIMIT {sample_size})"
                profiles = []
                for col_name, col_type in all_columns:
                    safe_col = f'"{col_name}"'
                    try:
                        stats = local_con.execute(f"""
                            SELECT
                                COUNT(*) as total,
                                COUNT({safe_col}) as non_null,
                                approx_count_distinct({safe_col}) as distinct_count,
                                MIN({safe_col}::VARCHAR) as min_val,
                                MAX({safe_col}::VARCHAR) as max_val
                            FROM {sample_clause}
                        """).fetchone()
                        total, non_null, distinct_count, min_val, max_val = stats
                        null_count = total - non_null
                        null_pct = round(null_count / total * 100, 1) if total > 0 else 0
                        profiles.append({
                            "name": col_name,
                            "type": str(col_type),
                            "total": total,
                            "null_count": null_count,
                            "null_pct": null_pct,
                            "distinct_count": distinct_count,
                            "min": min_val,
                            "max": max_val,
                        })
                    except Exception as col_exc:
                        profiles.append({
                            "name": col_name,
                            "type": str(col_type),
                            "error": str(col_exc),
                        })

                return {"columns": profiles, "sample_size": sample_size}
            finally:
                if needs_close and con:
                    con.close()
                elif not con:
                    local_con.close()

        result = await loop.run_in_executor(_get_light_executor(), _do_profile)
        return result

    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error("Table profile failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Profile failed: {e}")


@router.post("/api/tables/favorite")
async def toggle_table_favorite(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Toggle a table as favorite for the current user.
    Body: { table_path, table_name, connection_id (optional), table_type (optional) }
    Returns: { favorited: true/false }
    """
    table_path = body.get("table_path")
    table_name = body.get("table_name")
    connection_id = body.get("connection_id")
    table_type = body.get("table_type")

    if not table_path or not table_name:
        raise HTTPException(400, "table_path and table_name are required")

    username = _user.get("username", "guest") if _user else "guest"

    try:
        added = _db_manager.toggle_table_favorite(
            username=username,
            table_path=table_path,
            table_name=table_name,
            connection_id=connection_id,
            table_type=table_type,
        )
        return {"favorited": added}
    except Exception as e:
        logger.error("Toggle favorite failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Failed to toggle favorite: {e}")


@router.get("/api/tables/favorites")
async def list_table_favorites(connection_id: int = None, _user: dict = Depends(get_current_user)):
    """List table favorites for the current user."""
    username = _user.get("username", "guest") if _user else "guest"
    try:
        favorites = _db_manager.list_table_favorites(username=username, connection_id=connection_id)
        return {"favorites": favorites}
    except Exception as e:
        logger.error("List favorites failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Failed to list favorites: {e}")
