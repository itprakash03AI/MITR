/**
 * Column Intelligence — smart defaults for charts, pivots, and joins.
 *
 * Classifies columns by DuckDB type string and first-page data,
 * then recommends chart type, axis columns, pivot dimensions, and join keys.
 */

// ── Type classification ────────────────────────────────────────────────

export type ColRole = 'numeric' | 'categorical' | 'temporal' | 'boolean' | 'id' | 'unknown';

export interface ClassifiedColumn {
  name: string;
  role: ColRole;
  duckdbType: string;         // raw type from schema (may be empty)
  distinctEstimate: number;   // estimated unique values from first page (-1 if unknown)
  nullPct: number;            // 0-1 fraction of nulls in first page
}

const NUMERIC_RE  = /^(TINYINT|SMALLINT|INT|INTEGER|BIGINT|HUGEINT|FLOAT|DOUBLE|DECIMAL|NUMERIC|REAL|UTINYINT|USMALLINT|UINT|UINTEGER|UBIGINT|int\d*|float\d*|double|decimal|numeric|number)/i;
const TEMPORAL_RE = /^(DATE|TIME|TIMESTAMP|DATETIME|INTERVAL|TIMESTAMPTZ|TIMESTAMP_S|TIMESTAMP_MS|TIMESTAMP_NS|date|time|timestamp)/i;
const BOOLEAN_RE  = /^(BOOLEAN|BOOL|boolean|bool)/i;
const ID_NAME_RE  = /^(id|_id|pk|key)$|_id$|_key$|_pk$/i;

function inferRoleFromType(typeName: string): ColRole | null {
  if (!typeName) return null;
  if (BOOLEAN_RE.test(typeName)) return 'boolean';
  if (TEMPORAL_RE.test(typeName)) return 'temporal';
  if (NUMERIC_RE.test(typeName)) return 'numeric';
  // VARCHAR, TEXT, BLOB, ENUM, etc. → categorical
  return 'categorical';
}

function inferRoleFromData(values: any[]): ColRole {
  const sample = values.filter(v => v != null).slice(0, 50);
  if (sample.length === 0) return 'unknown';

  // Check if all are booleans
  if (sample.every(v => typeof v === 'boolean' || v === 0 || v === 1)) return 'boolean';

  // Check numbers
  if (sample.every(v => typeof v === 'number' || (typeof v === 'string' && !isNaN(Number(v)) && v.trim() !== ''))) {
    return 'numeric';
  }

  // Check temporal strings (ISO dates / timestamps)
  const dateRe = /^\d{4}-\d{2}-\d{2}/;
  if (sample.every(v => typeof v === 'string' && dateRe.test(v))) return 'temporal';

  return 'categorical';
}

/**
 * Classify all columns using schema types + first-page row data.
 * @param columns column names in order
 * @param rows first-page rows (array of objects)
 * @param schemaTypes optional map of column name → DuckDB type string
 */
export function classifyColumns(
  columns: string[],
  rows: Record<string, any>[],
  schemaTypes?: Record<string, string>,
): ClassifiedColumn[] {
  return columns.map(name => {
    const rawType = schemaTypes?.[name] || '';
    const values = rows.map(r => r[name]);
    const nonNull = values.filter(v => v != null);
    const nullPct = rows.length > 0 ? 1 - nonNull.length / rows.length : 0;

    // Distinct estimate from first page
    const distinctEstimate = nonNull.length > 0 ? new Set(nonNull.map(String)).size : 0;

    // Role: prefer schema type, fall back to data inference
    let role = inferRoleFromType(rawType);
    if (!role) role = inferRoleFromData(values);

    // Heuristic: numeric column that looks like an ID (name pattern + high cardinality)
    if (role === 'numeric' && ID_NAME_RE.test(name) && distinctEstimate > rows.length * 0.8) {
      role = 'id';
    }
    // Categorical with very high cardinality relative to rows → treat as ID
    if (role === 'categorical' && distinctEstimate > 0 && distinctEstimate >= rows.length * 0.95 && ID_NAME_RE.test(name)) {
      role = 'id';
    }

    return { name, role, duckdbType: rawType, distinctEstimate, nullPct };
  });
}

// ── Chart recommendation ───────────────────────────────────────────────

export interface ChartSuggestion {
  chartType: string;
  xCol: string;
  yCol: string;
  seriesCol: string;
  agg: string;
}

export function suggestChart(classified: ClassifiedColumn[]): ChartSuggestion {
  const temporals   = classified.filter(c => c.role === 'temporal');
  const categoricals = classified.filter(c => c.role === 'categorical');
  const numerics    = classified.filter(c => c.role === 'numeric');
  const lowCard     = categoricals.filter(c => c.distinctEstimate > 0 && c.distinctEstimate <= 20);
  const veryLowCard = categoricals.filter(c => c.distinctEstimate > 0 && c.distinctEstimate <= 8);

  let chartType = 'bar';
  let xCol = '';
  let yCol = numerics[0]?.name || '';
  let seriesCol = '';
  let agg = 'sum';

  // Priority 1: temporal + numeric → line chart (time series)
  if (temporals.length > 0 && numerics.length > 0) {
    chartType = 'line';
    xCol = temporals[0].name;
    yCol = numerics[0].name;
    agg = 'sum';
    // If there's a low-cardinality categorical → multi-line
    if (veryLowCard.length > 0) {
      chartType = 'multi_line';
      seriesCol = veryLowCard[0].name;
    }
    return { chartType, xCol, yCol, seriesCol, agg };
  }

  // Priority 2: two numerics (no good categorical) → scatter
  if (numerics.length >= 2 && lowCard.length === 0 && temporals.length === 0) {
    return { chartType: 'scatter', xCol: numerics[0].name, yCol: numerics[1].name, seriesCol: '', agg: 'sum' };
  }

  // Priority 3: low-cardinality categorical + numeric → bar
  if (lowCard.length > 0 && numerics.length > 0) {
    xCol = lowCard[0].name;
    yCol = numerics[0].name;

    // Very few values → pie
    if (lowCard[0].distinctEstimate <= 6) {
      chartType = 'pie';
    } else {
      chartType = 'bar';
    }

    // Second low-card categorical → grouped bar
    if (veryLowCard.length > 1 && chartType === 'bar') {
      seriesCol = veryLowCard.find(c => c.name !== xCol)?.name || '';
      if (seriesCol) chartType = 'grouped_bar';
    } else if (veryLowCard.length > 0 && veryLowCard[0].name !== xCol && chartType === 'bar') {
      seriesCol = veryLowCard[0].name;
      chartType = 'grouped_bar';
    }

    return { chartType, xCol, yCol, seriesCol, agg };
  }

  // Priority 4: any categorical + numeric
  if (categoricals.length > 0 && numerics.length > 0) {
    return { chartType: 'bar', xCol: categoricals[0].name, yCol: numerics[0].name, seriesCol: '', agg: 'sum' };
  }

  // Fallback: first two columns
  const all = classified.filter(c => c.role !== 'unknown');
  xCol = all[0]?.name || classified[0]?.name || '';
  yCol = all[1]?.name || classified[1]?.name || xCol;
  return { chartType: 'bar', xCol, yCol, seriesCol: '', agg: 'sum' };
}

// ── Pivot recommendation ───────────────────────────────────────────────

export interface PivotSuggestion {
  rowFields: string[];
  colField: string;
  values: { column: string; function: string }[];
}

export function suggestPivot(classified: ClassifiedColumn[]): PivotSuggestion {
  const temporals   = classified.filter(c => c.role === 'temporal');
  const categoricals = classified.filter(c => c.role === 'categorical');
  const numerics    = classified.filter(c => c.role === 'numeric');
  const lowCard     = categoricals.filter(c => c.distinctEstimate > 0 && c.distinctEstimate <= 20);
  const veryLowCard = categoricals.filter(c => c.distinctEstimate > 0 && c.distinctEstimate <= 10);

  const rowFields: string[] = [];
  let colField = '';
  const values: { column: string; function: string }[] = [];

  // Row fields: prefer temporal first (for time-based grouping), then low-card categoricals
  if (temporals.length > 0) rowFields.push(temporals[0].name);
  for (const c of lowCard) {
    if (!rowFields.includes(c.name) && rowFields.length < 2) rowFields.push(c.name);
  }
  // If no rows yet, take any categorical
  if (rowFields.length === 0 && categoricals.length > 0) {
    rowFields.push(categoricals[0].name);
  }

  // Column field (cross-tab): very low cardinality categorical not already in rows
  const colCandidate = veryLowCard.find(c => !rowFields.includes(c.name));
  if (colCandidate) colField = colCandidate.name;

  // Values: first 2 numeric columns with SUM
  for (const n of numerics.slice(0, 2)) {
    values.push({ column: n.name, function: 'sum' });
  }
  // If no numeric columns, use count(*)
  if (values.length === 0) {
    values.push({ column: '*', function: 'count' });
  }

  return { rowFields, colField, values };
}

// ── Join key suggestion ────────────────────────────────────────────────

export interface JoinSuggestion {
  leftColumn: string;
  rightColumn: string;
  confidence: 'exact' | 'pattern' | 'type';
}

/**
 * Suggest join keys between two tables based on column name + type matching.
 * @param leftCols columns of left table [{name, type}]
 * @param rightCols columns of right table [{name, type}]
 * @param leftTableName name of left table (for pattern matching)
 * @param rightTableName name of right table (for pattern matching)
 */
export function suggestJoins(
  leftCols: { name: string; type: string }[],
  rightCols: { name: string; type: string }[],
  leftTableName?: string,
  rightTableName?: string,
): JoinSuggestion[] {
  const suggestions: JoinSuggestion[] = [];
  const usedRight = new Set<string>();

  const leftName = (leftTableName || '').replace(/\.[^.]+$/, '').split(/[/\\]/).pop()?.toLowerCase() || '';
  const rightName = (rightTableName || '').replace(/\.[^.]+$/, '').split(/[/\\]/).pop()?.toLowerCase() || '';

  // Normalize type for comparison (strip precision, convert aliases)
  const normalizeType = (t: string) => {
    const s = t.toUpperCase().replace(/\(.*\)/, '').trim();
    if (['INT', 'INTEGER', 'INT32', 'INT64', 'BIGINT', 'SMALLINT', 'TINYINT'].includes(s)) return 'INT';
    if (['VARCHAR', 'TEXT', 'STRING', 'CHAR', 'BPCHAR'].includes(s)) return 'STR';
    if (['FLOAT', 'DOUBLE', 'REAL', 'DECIMAL', 'NUMERIC', 'FLOAT4', 'FLOAT8'].includes(s)) return 'FLOAT';
    return s;
  };

  // Build right column lookup
  const rightByName = new Map(rightCols.map(c => [c.name.toLowerCase(), c]));
  const rightByNorm = new Map(rightCols.map(c => [c.name.toLowerCase().replace(/^(fk_|ref_)/, ''), c]));

  for (const lc of leftCols) {
    const lName = lc.name.toLowerCase();
    const lNorm = lName.replace(/^(fk_|ref_)/, '');
    const lType = normalizeType(lc.type);

    // 1. Exact name match (highest confidence)
    const exactMatch = rightByName.get(lName);
    if (exactMatch && !usedRight.has(exactMatch.name) && normalizeType(exactMatch.type) === lType) {
      suggestions.push({ leftColumn: lc.name, rightColumn: exactMatch.name, confidence: 'exact' });
      usedRight.add(exactMatch.name);
      continue;
    }

    // 2. Pattern: left "table_id" ↔ right "id" (or vice versa)
    // e.g., left has "customer_id", right table is "customer" with column "id"
    if (rightName && lNorm === `${rightName}_id`) {
      const ridCol = rightByName.get('id') || rightByName.get(`${rightName}_id`);
      if (ridCol && !usedRight.has(ridCol.name) && normalizeType(ridCol.type) === lType) {
        suggestions.push({ leftColumn: lc.name, rightColumn: ridCol.name, confidence: 'pattern' });
        usedRight.add(ridCol.name);
        continue;
      }
    }

    // 3. Pattern: left "id" ↔ right "lefttable_id"
    if (leftName && lName === 'id') {
      const rFkCol = rightByName.get(`${leftName}_id`);
      if (rFkCol && !usedRight.has(rFkCol.name) && normalizeType(rFkCol.type) === lType) {
        suggestions.push({ leftColumn: lc.name, rightColumn: rFkCol.name, confidence: 'pattern' });
        usedRight.add(rFkCol.name);
        continue;
      }
    }

    // 4. Pattern: normalized match (strip fk_/ref_ prefixes)
    if (lNorm !== lName) {
      const normMatch = rightByNorm.get(lNorm);
      if (normMatch && !usedRight.has(normMatch.name) && normalizeType(normMatch.type) === lType) {
        suggestions.push({ leftColumn: lc.name, rightColumn: normMatch.name, confidence: 'pattern' });
        usedRight.add(normMatch.name);
      }
    }
  }

  // Sort: exact matches first, then pattern
  suggestions.sort((a, b) => {
    const order = { exact: 0, pattern: 1, type: 2 };
    return order[a.confidence] - order[b.confidence];
  });

  return suggestions;
}
