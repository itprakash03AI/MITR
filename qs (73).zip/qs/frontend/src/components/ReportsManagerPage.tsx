/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-nocheck  — MUI v7 Grid API changes: runtime correct, types require "size" instead of "xs"
/**
 * Parametric Reports Manager
 *
 * Left panel  — report list + create/edit dialog
 * Right panel — parameter form + execution results (Superset-style split)
 *
 * Features:
 *   - Column loader: when a source is selected, fetches available columns to aid
 *     parameter schema creation (click a column name → auto-fill param name)
 *   - Business date shortcuts: chips shown below date-type params
 *     (today, yesterday, month_start, -7d, …)
 *   - API download URL: after execution shows the curl/API equivalent URL
 *   - Inline paginated results preview
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions,
  DialogContent, DialogTitle, Divider, FormControl, FormControlLabel, Grid,
  IconButton, InputLabel, MenuItem, Paper, Select, Switch, TextField, Tooltip,
  Typography,
} from '@mui/material';
import Autocomplete from '@mui/material/Autocomplete';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  PlayArrow as RunIcon, Assessment as ReportIcon,
  Refresh as RefreshIcon, Close as CloseIcon,
  AddCircleOutline as AddParamIcon, RemoveCircleOutline as RemoveParamIcon,
  Download as DownloadIcon, ContentCopy as CopyIcon,
  TableChart as ColumnsIcon, EventNote as DateIcon,
  Link as LinkIcon, ChevronLeft as CollapseIcon, ChevronRight as ExpandIcon,
  ExpandMore as ExpandMoreIcon, ExpandLess as ExpandLessIcon,
  AutoFixHigh as AutoDetectIcon, History as HistoryIcon,
  Schedule as ScheduleIcon, ArrowDropDown as ArrowDropDownIcon,
  PictureAsPdf as PdfIcon,
  Bookmark as BookmarkIcon,
  BookmarkAdd as BookmarkAddIcon,
  MoreVert as MoreVertIcon,
  SendToMobile as BurstIcon,
  NotificationsActive as AlertIcon,
  FormatPaint as FormatIcon,
  Security as RLSIcon,
  Code as EmbedIcon,
  ContentCopy as EmbedCopyIcon,
} from '@mui/icons-material';
import Menu from '@mui/material/Menu';
import { useSearchParams } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import { useAppSettings } from '../context/AppSettingsContext';
import DataGridViewer from './DataGridViewer';

const API_BASE = import.meta.env.VITE_API_URL || '';

// ─── Param type options ────────────────────────────────────────────────────

const PARAM_TYPES = [
  { value: 'string',      label: 'Text' },
  { value: 'number',      label: 'Number' },
  { value: 'date',        label: 'Date' },
  { value: 'boolean',     label: 'Boolean' },
  { value: 'select',      label: 'Select (single)' },
  { value: 'multiselect', label: 'Multi-select (auto from data)' },
];

// Common business date shortcuts for the UI helper
const DATE_SHORTCUT_GROUPS = [
  { label: 'Current', values: ['today', 'yesterday', 'tomorrow'] },
  { label: 'Week',    values: ['week_start', 'week_end', 'last_week_start', 'last_week_end'] },
  { label: 'Month',   values: ['month_start', 'month_end', 'last_month_start', 'last_month_end'] },
  { label: 'Year',    values: ['year_start', 'year_end', 'last_year_start', 'last_year_end'] },
  { label: 'Relative', values: ['-1d', '-7d', '-30d', '-90d', '+1d', '+7d', '+30d'] },
];

// ─── DateShortcutHelper ───────────────────────────────────────────────────

function DateShortcutHelper({ onPick }) {
  const [open, setOpen] = useState(false);
  return (
    <Box sx={{ mt: 0.5 }}>
      <Button
        size="small" startIcon={<DateIcon />} onClick={() => setOpen(v => !v)}
        sx={{ fontSize: 10, py: 0, px: 0.5, minWidth: 0 }} variant="text" color="inherit"
      >
        Date shortcuts
      </Button>
      <Collapse in={open}>
        <Box sx={{ mt: 0.5, p: 1, bgcolor: 'grey.50', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
          {DATE_SHORTCUT_GROUPS.map(g => (
            <Box key={g.label} sx={{ mb: 0.75 }}>
              <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mb: 0.25 }}>
                {g.label}
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {g.values.map(s => (
                  <Chip
                    key={s} label={s} size="small"
                    onClick={() => { onPick(s); setOpen(false); }}
                    sx={{ height: 18, fontSize: 9, cursor: 'pointer', fontFamily: 'monospace' }}
                    variant="outlined"
                  />
                ))}
              </Box>
            </Box>
          ))}
          <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 0.5 }}>
            Resolved to YYYY-MM-DD at execution time. Also works as default_value in scheduled jobs.
          </Typography>
        </Box>
      </Collapse>
    </Box>
  );
}

// ─── ColumnHelper ─────────────────────────────────────────────────────────

function ColumnHelper({ columns, loading, onPickColumn }) {
  if (loading) return <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center', mt: 1 }}><CircularProgress size={12} /><Typography variant="caption">Loading columns…</Typography></Box>;
  if (!columns || columns.length === 0) return null;
  return (
    <Box sx={{ mt: 1, p: 1, bgcolor: 'primary.50', borderRadius: 1, border: '1px solid', borderColor: 'primary.100' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
        <ColumnsIcon sx={{ fontSize: 13, color: 'primary.main' }} />
        <Typography variant="caption" color="primary.main" sx={{ fontWeight: 600 }}>
          Available columns — click to use as parameter name
        </Typography>
      </Box>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, maxHeight: 80, overflowY: 'auto' }}>
        {columns.map(c => (
          <Chip
            key={c.name} label={c.name}
            size="small" variant="outlined" color="primary"
            onClick={() => onPickColumn(c.name)}
            sx={{ height: 20, fontSize: 10, cursor: 'pointer', fontFamily: 'monospace' }}
            title={c.type}
          />
        ))}
      </Box>
    </Box>
  );
}

// ─── ParamEditor ──────────────────────────────────────────────────────────

function ParamEditor({ params, onChange, availableColumns, loadingColumns }) {
  const [pickerTarget, setPickerTarget] = useState(null); // index waiting for column pick

  const addParam = () => {
    const hasEmpty = params.some(p => !p.name.trim());
    if (hasEmpty) return; // prevent adding while an existing param has no name
    onChange([...params, { name: '', label: '', type: 'string', required: false, default_value: '', description: '', options: '', source_column: '' }]);
  };

  const removeParam = (i) => onChange(params.filter((_, idx) => idx !== i));

  // Always update via the latest `params` snapshot (use functional updater pattern)
  // so that multiple field changes in the same callback don't clobber each other.
  const update = (i, field, value) =>
    onChange(params.map((p, idx) => idx === i ? { ...p, [field]: value } : p));

  const pickColumn = (colName) => {
    if (pickerTarget === null) return;
    // Combine both field changes in ONE onChange call to avoid stale-closure overwrite
    const label = colName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    onChange(params.map((p, idx) => idx === pickerTarget ? { ...p, name: colName, label } : p));
    setPickerTarget(null);
  };

  return (
    <Box>
      <ColumnHelper columns={availableColumns} loading={loadingColumns} onPickColumn={pickColumn} />

      {params.length === 0 && (
        <Box sx={{ py: 2, px: 1, my: 1, bgcolor: 'grey.50', borderRadius: 1, border: '1px dashed', borderColor: 'divider', textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary">No parameters defined.</Typography>
          <Typography variant="caption" color="text.disabled">
            Click "Add Parameter" to let users filter this report when running it.
          </Typography>
        </Box>
      )}

      {params.map((p, i) => (
        <Paper
          key={i} variant="outlined"
          sx={{
            p: 1.5, mb: 1.5, mt: i === 0 ? 1.5 : 0,
            border: pickerTarget === i ? '1.5px solid' : '1px solid',
            borderColor: pickerTarget === i ? 'primary.main' : 'divider',
          }}
        >
          {/* Row 1: name, label, type, required, delete */}
          <Grid container spacing={1} alignItems="flex-start">
            <Grid size={3}>
              <TextField
                label="Parameter Name" size="small" fullWidth value={p.name}
                onChange={e => update(i, 'name', e.target.value.replace(/\s/g, '_'))}
                placeholder="e.g. start_date"
                helperText={
                  availableColumns?.length > 0
                    ? <span style={{ cursor: 'pointer', color: '#00AFEC' }} onClick={() => setPickerTarget(pickerTarget === i ? null : i)}>
                        {pickerTarget === i ? '↑ click a column above' : 'or pick a column ↑'}
                      </span>
                    : <span>Use <code style={{ fontFamily: 'monospace' }}>{'{name}'}</code> in SQL</span>
                }
              />
            </Grid>
            <Grid size={3}>
              <TextField
                label="Display Label" size="small" fullWidth value={p.label}
                onChange={e => update(i, 'label', e.target.value)}
                placeholder="e.g. Start Date"
                helperText="Shown to users in the run form"
              />
            </Grid>
            <Grid size={2}>
              <FormControl size="small" fullWidth>
                <InputLabel>Type</InputLabel>
                <Select label="Type" value={p.type} onChange={e => update(i, 'type', e.target.value)}>
                  {PARAM_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
                </Select>
              </FormControl>
            </Grid>
            <Grid size={2}>
              <TextField
                label="Default Value" size="small" fullWidth value={p.default_value ?? ''}
                onChange={e => update(i, 'default_value', e.target.value)}
                placeholder={p.type === 'date' ? 'today' : p.type === 'boolean' ? 'false' : ''}
                helperText="Pre-filled when running"
              />
              {p.type === 'date' && (
                <DateShortcutHelper onPick={v => update(i, 'default_value', v)} />
              )}
            </Grid>
            <Grid size={1} sx={{ pt: '6px !important' }}>
              <Tooltip title="If checked, user must provide a value before running">
                <FormControlLabel
                  control={<Switch size="small" checked={!!p.required} onChange={e => update(i, 'required', e.target.checked)} />}
                  label={<Typography variant="caption">Req.</Typography>}
                  sx={{ m: 0 }}
                />
              </Tooltip>
            </Grid>
            <Grid size={1} sx={{ display: 'flex', justifyContent: 'flex-end', pt: '6px !important' }}>
              <Tooltip title="Remove parameter">
                <IconButton size="small" onClick={() => removeParam(i)} color="error">
                  <RemoveParamIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Grid>

            {/* Row 2: description + select options */}
            <Grid size={p.type === 'select' ? 6 : 12}>
              <TextField
                label="Help Text (optional)" size="small" fullWidth value={p.description || ''}
                onChange={e => update(i, 'description', e.target.value)}
                placeholder="Explain what this parameter does…"
                helperText="Shown as hint below the input field when running the report"
              />
            </Grid>
            {p.type === 'select' && (
              <Grid size={6}>
                <TextField
                  label="Options (comma-separated)" size="small" fullWidth value={p.options || ''}
                  onChange={e => update(i, 'options', e.target.value)}
                  placeholder="Option A, Option B, Option C"
                  helperText="Values shown in the dropdown"
                />
              </Grid>
            )}
            {p.type === 'multiselect' && (
              <Grid size={6}>
                <Autocomplete
                  size="small"
                  freeSolo
                  options={availableColumns?.map(c => c.name || c) || []}
                  value={p.source_column || ''}
                  onChange={(_, v) => update(i, 'source_column', v || '')}
                  onInputChange={(_, v) => update(i, 'source_column', v)}
                  renderInput={ap => (
                    <TextField
                      {...ap}
                      label="Source Column (for auto-loading values)"
                      size="small"
                      helperText={loadingColumns ? 'Loading columns…' : 'Column whose distinct values populate the dropdown'}
                      InputProps={{ ...ap.InputProps, endAdornment: <>{loadingColumns && <CircularProgress size={14} />}{ap.InputProps.endAdornment}</> }}
                    />
                  )}
                />
              </Grid>
            )}
          </Grid>
        </Paper>
      ))}

      <Button size="small" startIcon={<AddParamIcon />} onClick={addParam} sx={{ mt: 0.5 }}>
        Add Parameter
      </Button>
    </Box>
  );
}

// ─── ParamValueForm ───────────────────────────────────────────────────────

/**
 * Renders one parameter input.
 * For `multiselect` type: auto-fetches distinct values from the report's data
 * source and shows a multi-select Autocomplete with a "Select all" shortcut.
 */
function ParamInput({ param: p, value, onChange, reportId }) {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [truncated, setTruncated] = useState(false);
  const fetchedRef = useRef(false);

  const isMulti   = p.type === 'multiselect';
  const isSelect  = p.type === 'select';
  const needsFetch = (isMulti || (isSelect && !p.options?.length)) && reportId;

  // Auto-load distinct values once when this param is first rendered
  useEffect(() => {
    if (!needsFetch || fetchedRef.current) return;
    fetchedRef.current = true;
    setLoading(true);
    api.getReportParamValues(reportId, p.source_column || p.name)
      .then(res => {
        setOptions(res.values || []);
        setTruncated(!!res.truncated);
      })
      .finally(() => setLoading(false));
  }, [needsFetch, reportId, p.name]);

  const label = `${p.label || p.name}${p.required ? ' *' : ''}`;

  if (p.type === 'boolean') {
    return (
      <FormControlLabel
        control={
          <Switch
            checked={String(value ?? p.default_value ?? false) === 'true'}
            onChange={e => onChange(e.target.checked)}
          />
        }
        label={label}
      />
    );
  }

  if (isMulti) {
    const selected = Array.isArray(value) ? value : (value ? [value] : []);
    return (
      <Box>
        <Autocomplete
          multiple
          size="small"
          options={options}
          value={selected}
          loading={loading}
          onChange={(_, newVal) => onChange(newVal)}
          disableCloseOnSelect
          limitTags={4}
          renderInput={params => (
            <TextField
              {...params}
              label={label}
              helperText={
                loading ? 'Loading values…' :
                truncated ? `Showing top ${options.length} values` :
                p.description || `${options.length} distinct values`
              }
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loading && <CircularProgress size={14} sx={{ mr: 1 }} />}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
          renderTags={(vals, getTagProps) =>
            vals.map((v, idx) => (
              <Chip
                key={v} label={v} size="small"
                sx={{ height: 20, fontSize: 11, fontFamily: 'monospace' }}
                {...getTagProps({ index: idx })}
              />
            ))
          }
        />
        <Box sx={{ display: 'flex', gap: 1, mt: 0.5, alignItems: 'center' }}>
          {options.length > 0 && (
            <Button size="small" sx={{ fontSize: 10, py: 0, minWidth: 0 }} onClick={() => onChange(options)}>
              Select all
            </Button>
          )}
          {selected.length > 0 && (
            <Button size="small" sx={{ fontSize: 10, py: 0, minWidth: 0 }} color="inherit" onClick={() => onChange([])}>
              Clear
            </Button>
          )}
          {selected.length === 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic', fontSize: 10 }}>
              No selection — all rows included
            </Typography>
          )}
        </Box>
      </Box>
    );
  }

  if (isSelect) {
    const optList = options.length > 0
      ? options
      : (typeof p.options === 'string'
          ? p.options.split(',').map(s => s.trim()).filter(Boolean)
          : (p.options || []));
    return (
      <Autocomplete
        size="small"
        options={optList}
        value={value ?? p.default_value ?? null}
        loading={loading}
        onChange={(_, newVal) => onChange(newVal ?? '')}
        freeSolo
        renderInput={params => (
          <TextField
            {...params}
            label={label}
            helperText={p.description || undefined}
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <>
                  {loading && <CircularProgress size={14} sx={{ mr: 1 }} />}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
          />
        )}
      />
    );
  }

  return (
    <Box>
      <TextField
        label={label}
        size="small" fullWidth
        type={p.type === 'number' ? 'number' : 'text'}
        value={value ?? p.default_value ?? ''}
        onChange={e => onChange(e.target.value)}
        helperText={p.description || undefined}
      />
      {p.type === 'date' && (
        <DateShortcutHelper onPick={v => onChange(v)} />
      )}
    </Box>
  );
}


function ParamValueForm({ params, values, onChange, reportId }) {
  if (!params || params.length === 0)
    return <Typography variant="body2" color="text.secondary">This report has no parameters — runs with all data.</Typography>;

  return (
    <Grid container spacing={1.5}>
      {params.map(p => (
        <Grid size={{ xs: 12, sm: p.type === 'multiselect' ? 12 : 6 }} key={p.name}>
          <ParamInput
            param={p}
            value={values[p.name]}
            onChange={v => onChange({ ...values, [p.name]: v })}
            reportId={reportId}
          />
        </Grid>
      ))}
    </Grid>
  );
}

// ─── ApiUrlBox ────────────────────────────────────────────────────────────

function ApiUrlBox({ reportId, reportName, paramValues }) {
  const [copied, setCopied] = useState(false);
  const qs = Object.entries(paramValues || {}).filter(([, v]) => v !== '' && v != null).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
  const url = `${API_BASE}/api/reports/${reportId}/download${qs ? '?' + qs : ''}`;

  const copy = () => {
    navigator.clipboard.writeText(url).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800); });
  };

  return (
    <Box sx={{ mt: 1.5, p: 1.5, bgcolor: 'grey.50', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.75 }}>
        <LinkIcon sx={{ fontSize: 13, color: 'text.secondary' }} />
        <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
          API / Automation URL (direct CSV download)
        </Typography>
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography
          variant="caption"
          sx={{ flex: 1, fontFamily: 'monospace', fontSize: 11, wordBreak: 'break-all', color: 'primary.main', bgcolor: 'white', border: '1px solid', borderColor: 'divider', borderRadius: 0.5, p: 0.75, display: 'block' }}
        >
          GET {url}
        </Typography>
        <Tooltip title={copied ? 'Copied!' : 'Copy URL'}>
          <IconButton size="small" onClick={copy} color={copied ? 'success' : 'default'}>
            <CopyIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Download now">
          <IconButton size="small" color="primary" onClick={() => window.open(url, '_blank')}>
            <DownloadIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
      <Typography variant="caption" color="text.disabled">
        Use with curl, Power Automate, or any HTTP client. Date shortcuts (today, month_start, -7d) are resolved automatically.
      </Typography>
    </Box>
  );
}

// ─── ReportDialog ─────────────────────────────────────────────────────────

function ReportDialog({ open, onClose, onSaved, initialData, savedQueries, sqlQueries }) {
  const isEdit = !!initialData;
  const [form, setForm] = useState({
    name: '', description: '', source_type: 'parquet',
    saved_query_id: '', sql_saved_query_id: '',
    parameters: [], sql_override: '', is_public: true,
    connection_override_id: null as number | null,   // Phase 24A
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [availableColumns, setAvailableColumns] = useState([]);
  const [loadingColumns, setLoadingColumns] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [sqlConnections, setSqlConnections] = useState<any[]>([]);  // Phase 24A

  // Load SQL connections for the override picker whenever SQL mode is active
  useEffect(() => {
    if (!open || form.source_type !== 'sql') return;
    api.listConnections(true).then((r: any) => {
      const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 'oracle'];
      setSqlConnections((r || []).filter((c: any) => SQL_TYPES.includes(c.connection_type)));
    }).catch(() => setSqlConnections([]));
  }, [open, form.source_type]);

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      if (initialData) {
        setForm({
          name:                   initialData.name || '',
          description:            initialData.description || '',
          source_type:            initialData.saved_query_id ? 'parquet' : 'sql',
          saved_query_id:         initialData.saved_query_id || '',
          sql_saved_query_id:     initialData.sql_saved_query_id || '',
          parameters:             (initialData.parameters || []).map(p => ({
            ...p,
            options: Array.isArray(p.options) ? p.options.join(', ') : (p.options || ''),
          })),
          sql_override:           initialData.sql_override || '',
          is_public:              initialData.is_public !== false,
          connection_override_id: initialData.connection_override_id || null,
        });
      } else {
        setForm({ name: '', description: '', source_type: 'parquet', saved_query_id: '', sql_saved_query_id: '', parameters: [], sql_override: '', is_public: true, connection_override_id: null });
      }
      setErr('');
      setAvailableColumns([]);
    }
  }, [open, initialData]);

  // Load columns when a report already exists (edit mode) and has a saved_query_id
  useEffect(() => {
    if (!open || !isEdit || !initialData?.id) return;
    setLoadingColumns(true);
    api.getReportColumns(initialData.id)
      .then(res => setAvailableColumns(res.columns || []))
      .catch(() => setAvailableColumns([]))
      .finally(() => setLoadingColumns(false));
  }, [open, isEdit, initialData?.id]);

  // Load columns from source when saved_query_id changes (create mode — no report id yet)
  useEffect(() => {
    if (!open || isEdit) return;
    const sqId = form.source_type === 'parquet' ? (Number(form.saved_query_id) || null) : null;
    if (!sqId) { setAvailableColumns([]); return; }
    setLoadingColumns(true);
    api.getPreviewColumns(sqId)
      .then(res => setAvailableColumns(res.columns || []))
      .catch(() => setAvailableColumns([]))
      .finally(() => setLoadingColumns(false));
  }, [open, form.saved_query_id, form.source_type, isEdit]);

  // Smart auto-suggest: when a parquet query is selected in create mode with no params yet,
  // auto-detect partition columns and pre-fill the parameter list.
  useEffect(() => {
    if (!open || isEdit || form.source_type !== 'parquet' || !form.saved_query_id) return;
    if (form.parameters.length > 0) return; // don't clobber manually-added params
    const sqId = Number(form.saved_query_id);
    if (!sqId) return;
    api.suggestReportParams({ source_type: 'parquet', saved_query_id: sqId })
      .then(res => {
        const suggested = (res.suggested_params || []).map(p => ({
          ...p,
          options: p.type === 'select' && Array.isArray(p.options) ? p.options.join(', ') : (p.options || ''),
        }));
        if (suggested.length > 0) {
          // Only apply if the user hasn't added any params in the meantime
          setForm(f => f.parameters.length === 0 ? { ...f, parameters: suggested } : f);
        }
      })
      .catch(() => {}); // silent — user can still click "Auto-detect" manually
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, form.saved_query_id, form.source_type, isEdit]);

  const handleSave = async () => {
    if (!form.name.trim()) { setErr('Name is required'); return; }
    if (form.source_type === 'parquet' && !form.saved_query_id) { setErr('Select a Parquet saved query'); return; }
    if (form.source_type === 'sql' && !form.sql_saved_query_id) { setErr('Select a SQL saved query'); return; }
    const emptyParam = form.parameters.findIndex(p => !p.name.trim());
    if (emptyParam >= 0) { setErr(`Parameter #${emptyParam + 1} has no name — fill in the Parameter Name field`); return; }
    setSaving(true); setErr('');
    try {
      const params = form.parameters.map(p => ({
        ...p,
        options: p.type === 'select' && typeof p.options === 'string'
          ? p.options.split(',').map(s => s.trim()).filter(Boolean)
          : p.type === 'multiselect'
            ? null   // options auto-loaded from data; don't persist
            : (p.options || null),
      }));
      const payload = {
        name:               form.name,
        description:        form.description || null,
        saved_query_id:     form.source_type === 'parquet' ? (Number(form.saved_query_id) || null) : null,
        sql_saved_query_id: form.source_type === 'sql' ? (Number(form.sql_saved_query_id) || null) : null,
        parameters:         params,
        sql_override:           form.sql_override || null,
        is_public:              form.is_public,
        connection_override_id: form.connection_override_id || null,  // Phase 24A
      };
      if (isEdit) { await api.updateReport(initialData.id, payload); }
      else        { await api.createReport(payload); }
      onSaved();
    } catch (e) {
      const msg = e.message || 'Save failed';
      // Give a specific hint for common infrastructure errors
      if (msg.includes('404') || msg.includes('Not Found'))
        setErr('404 — backend route not found. The backend server needs to be restarted to pick up the latest code.');
      else if (msg.includes('503') || msg.includes('not ready') || msg.includes('not initialized'))
        setErr('503 — backend service not ready. Please restart the backend server and try again.');
      else
        setErr(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ pb: 1 }}>
        {isEdit ? 'Edit Report' : 'Create Parametric Report'}
        <IconButton onClick={onClose} sx={{ position: 'absolute', right: 8, top: 8 }}><CloseIcon /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        <Collapse in={!!err}><Alert severity="error" sx={{ mb: 2 }}>{err}</Alert></Collapse>
        <Grid container spacing={2}>
          <Grid size={8}>
            <TextField label="Report Name" size="small" fullWidth required
              value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </Grid>
          <Grid size={4} sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControlLabel
              control={<Switch checked={form.is_public} onChange={e => setForm(f => ({ ...f, is_public: e.target.checked }))} />}
              label="Public (visible to all)"
            />
          </Grid>
          <Grid size={12}>
            <TextField label="Description" size="small" fullWidth multiline rows={2}
              value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          </Grid>
          <Grid size={12}>
            <FormControl size="small">
              <InputLabel>Source Type</InputLabel>
              <Select label="Source Type" value={form.source_type} sx={{ minWidth: 180 }}
                onChange={e => setForm(f => ({ ...f, source_type: e.target.value, saved_query_id: '', sql_saved_query_id: '' }))}
              >
                <MenuItem value="parquet">Parquet Saved Query</MenuItem>
                <MenuItem value="sql">SQL Saved Query</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {form.source_type === 'parquet' && (
            <Grid size={12}>
              <Autocomplete
                size="small"
                options={savedQueries}
                getOptionLabel={q => q.name || ''}
                isOptionEqualToValue={(o, v) => o.id === v?.id}
                value={savedQueries.find(q => q.id === form.saved_query_id) || null}
                onChange={(_, v) => setForm(f => ({ ...f, saved_query_id: v?.id || '' }))}
                renderInput={ap => <TextField {...ap} label="Parquet Saved Query *" size="small" required />}
              />
            </Grid>
          )}

          {form.source_type === 'sql' && (
            <>
              <Grid size={12}>
                <Autocomplete
                  size="small"
                  options={sqlQueries}
                  getOptionLabel={q => q.name || ''}
                  isOptionEqualToValue={(o, v) => o.id === v?.id}
                  value={sqlQueries.find(q => q.id === form.sql_saved_query_id) || null}
                  onChange={(_, v) => setForm(f => ({ ...f, sql_saved_query_id: v?.id || '' }))}
                  renderInput={ap => <TextField {...ap} label="SQL Saved Query *" size="small" required />}
                />
              </Grid>
              <Grid size={12}>
                <TextField
                  label="SQL Override (optional)" size="small" fullWidth multiline rows={4}
                  placeholder="Leave empty to use the saved query's SQL. Use {param_name} for substitution."
                  value={form.sql_override}
                  onChange={e => setForm(f => ({ ...f, sql_override: e.target.value }))}
                />
              </Grid>
              <Grid size={12}>
                <FormControl size="small" fullWidth>
                  <InputLabel>Connection Override (optional)</InputLabel>
                  <Select
                    value={form.connection_override_id || ''}
                    onChange={e => setForm(f => ({
                      ...f,
                      connection_override_id: e.target.value ? Number(e.target.value) : null,
                    }))}
                    label="Connection Override (optional)"
                  >
                    <MenuItem value=""><em>Use query's default connection</em></MenuItem>
                    {sqlConnections.map((c: any) => (
                      <MenuItem key={c.id} value={c.id}>
                        {c.name} <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>({c.connection_type})</Typography>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </>
          )}

          <Grid size={12}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>Parameter Schema</Typography>
              <Button
                variant="outlined" size="small"
                startIcon={detecting ? <CircularProgress size={14} /> : <AutoDetectIcon />}
                disabled={detecting || (!form.saved_query_id && !form.sql_saved_query_id)}
                onClick={async () => {
                  setDetecting(true);
                  try {
                    const res = await api.suggestReportParams({
                      source_type: form.source_type,
                      saved_query_id: form.source_type === 'parquet' ? Number(form.saved_query_id) || null : null,
                      sql_saved_query_id: form.source_type === 'sql' ? Number(form.sql_saved_query_id) || null : null,
                    });
                    const suggested = res.suggested_params || [];
                    if (suggested.length === 0) {
                      setErr('No partition columns detected for this source');
                      return;
                    }
                    // Merge: skip params whose name already exists
                    const existing = new Set(form.parameters.map(p => p.name));
                    const newParams = suggested.filter(p => !existing.has(p.name)).map(p => ({
                      ...p,
                      options: p.type === 'select' && Array.isArray(p.options) ? p.options.join(', ') : (p.options || ''),
                    }));
                    if (newParams.length > 0) {
                      setForm(f => ({ ...f, parameters: [...f.parameters, ...newParams] }));
                    } else {
                      setErr('All detected partitions are already in the parameter list');
                    }
                  } catch (e) {
                    setErr(e.message || 'Auto-detect failed');
                  } finally {
                    setDetecting(false);
                  }
                }}
                sx={{ textTransform: 'none', fontSize: '0.75rem' }}
              >
                Auto-detect Partitions
              </Button>
            </Box>
            <Box sx={{ p: 1.5, mb: 1, bgcolor: 'info.50', borderRadius: 1, border: '1px solid', borderColor: 'info.200' }}>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                <strong>SQL source:</strong> write <code style={{ fontFamily: 'monospace', fontSize: 11, bgcolor: 'inherit' }}>{'{param_name}'}</code> anywhere in the SQL — e.g. <code style={{ fontFamily: 'monospace', fontSize: 11 }}>WHERE date &gt;= &#39;{'{start_date}'}&#39;</code>
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                <strong>Parquet source:</strong> enter the parameter name as the filter value in the saved query — e.g. filter <em>date &gt;= {'{start_date}'}</em>
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                <strong>Date params:</strong> users can type shortcuts like <code style={{ fontFamily: 'monospace', fontSize: 11 }}>today</code>, <code style={{ fontFamily: 'monospace', fontSize: 11 }}>month_start</code>, <code style={{ fontFamily: 'monospace', fontSize: 11 }}>-7d</code> — resolved automatically at run time.
              </Typography>
            </Box>
            <ParamEditor
              params={form.parameters}
              onChange={params => setForm(f => ({ ...f, parameters: params }))}
              availableColumns={availableColumns}
              loadingColumns={loadingColumns}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}
          startIcon={saving ? <CircularProgress size={14} /> : null}
        >
          {isEdit ? 'Update' : 'Create Report'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ResultsPanel is replaced by DataGridViewer (embedded mode)
// Kept as a thin wrapper so usage site (below) stays readable
function ResultsPanel({ executionId }) {
  if (!executionId) return null;
  return <DataGridViewer executionId={executionId} embedded />;
}

// ─── BookmarksBar ──────────────────────────────────────────────────────────

function BookmarksBar({ reportId, paramValues, onLoadBookmark }) {
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    if (!reportId) return;
    const res = await api.listReportBookmarks(reportId);
    setBookmarks(res.bookmarks || []);
  }, [reportId]);

  useEffect(() => { load(); }, [load]);

  const handleSave = async () => {
    if (!saveName.trim()) return;
    setSaving(true);
    try {
      await api.saveReportBookmark(reportId, saveName.trim(), paramValues);
      setSaveName(''); setSaveOpen(false);
      load();
    } catch (e: any) { alert(e.message); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: number) => {
    try { await api.deleteReportBookmark(id); load(); }
    catch (e: any) { alert(e.message); }
  };

  if (bookmarks.length === 0 && !saveOpen) {
    return (
      <Box sx={{ px: 2, py: 0.5, display: 'flex', alignItems: 'center', gap: 0.5,
        borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50' }}>
        <BookmarkIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
        <Typography variant="caption" color="text.disabled">No bookmarks</Typography>
        <Tooltip title="Save current params as bookmark">
          <IconButton size="small" sx={{ ml: 0.5 }} onClick={() => setSaveOpen(true)}>
            <BookmarkAddIcon sx={{ fontSize: 14 }} />
          </IconButton>
        </Tooltip>
      </Box>
    );
  }

  return (
    <Box sx={{ px: 2, py: 0.5, display: 'flex', alignItems: 'center', gap: 0.5, flexWrap: 'wrap',
      borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50' }}>
      <BookmarkIcon sx={{ fontSize: 13, color: 'text.secondary', flexShrink: 0 }} />
      {bookmarks.map(bm => (
        <Chip key={bm.id} label={bm.name} size="small" variant="outlined"
          sx={{ height: 20, fontSize: 10, cursor: 'pointer' }}
          onClick={() => onLoadBookmark(bm.param_values || {})}
          onDelete={() => handleDelete(bm.id)}
        />
      ))}
      {saveOpen ? (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <TextField size="small" value={saveName} onChange={e => setSaveName(e.target.value)}
            placeholder="Bookmark name" sx={{ '& .MuiInputBase-root': { height: 24, fontSize: 12 } }}
            onKeyDown={e => { if (e.key === 'Enter') handleSave(); if (e.key === 'Escape') setSaveOpen(false); }}
            autoFocus />
          <Button size="small" variant="contained" onClick={handleSave} disabled={saving}
            sx={{ py: 0, px: 1, minWidth: 0, fontSize: 11 }}>
            Save
          </Button>
          <IconButton size="small" onClick={() => setSaveOpen(false)}><CloseIcon sx={{ fontSize: 14 }} /></IconButton>
        </Box>
      ) : (
        <Tooltip title="Save current params as bookmark">
          <IconButton size="small" onClick={() => { setSaveName(''); setSaveOpen(true); }}>
            <BookmarkAddIcon sx={{ fontSize: 14 }} />
          </IconButton>
        </Tooltip>
      )}
    </Box>
  );
}

// ─── BurstDialog ───────────────────────────────────────────────────────────

function BurstDialog({ open, report, onClose }) {
  const [burstCol, setBurstCol] = useState('');
  const [deliveryType, setDeliveryType] = useState('email');
  const [outputFormat, setOutputFormat] = useState('pdf');
  const [defaultRecipient, setDefaultRecipient] = useState('');
  const [s3Prefix, setS3Prefix] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) { setBurstCol(''); setDeliveryType('email'); setOutputFormat('pdf');
      setDefaultRecipient(''); setS3Prefix(''); setResult(null); setError(''); }
  }, [open]);

  const handleSubmit = async () => {
    if (!burstCol.trim()) { setError('Burst column is required'); return; }
    setSubmitting(true); setError('');
    try {
      const body: any = {
        burst_column: burstCol.trim(),
        output_format: outputFormat,
        delivery_type: deliveryType,
      };
      if (deliveryType === 'email') body.default_recipient = defaultRecipient;
      else body.s3_prefix = s3Prefix;
      const res = await api.triggerBurst(report.id, body);
      setResult(res);
    } catch (e: any) { setError(e.message); }
    finally { setSubmitting(false); }
  };

  const cols = (report?.parameters || []).map((p: any) => p.name);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <BurstIcon color="primary" />
          <Typography variant="h6">Burst Report</Typography>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
          Run one report slice per distinct value of a column, then deliver each to its recipient.
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        {result ? (
          <Alert severity="success" sx={{ mb: 1 }}>
            Burst job <strong>#{result.job_id}</strong> started! Poll{' '}
            <code>GET /api/reports/burst/{result.job_id}</code> for progress.
          </Alert>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            {error && <Alert severity="error">{error}</Alert>}
            <TextField label="Burst column" size="small" fullWidth value={burstCol}
              onChange={e => setBurstCol(e.target.value)}
              placeholder="e.g. region, department"
              helperText="Column whose distinct values each get their own report slice" />
            <FormControl size="small" fullWidth>
              <InputLabel>Output format</InputLabel>
              <Select value={outputFormat} label="Output format" onChange={e => setOutputFormat(e.target.value)}>
                {['pdf', 'excel', 'csv'].map(f => <MenuItem key={f} value={f}>{f.toUpperCase()}</MenuItem>)}
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel>Delivery type</InputLabel>
              <Select value={deliveryType} label="Delivery type" onChange={e => setDeliveryType(e.target.value)}>
                <MenuItem value="email">Email</MenuItem>
                <MenuItem value="s3">S3</MenuItem>
              </Select>
            </FormControl>
            {deliveryType === 'email' && (
              <TextField label="Default recipient email" size="small" fullWidth
                value={defaultRecipient} onChange={e => setDefaultRecipient(e.target.value)}
                placeholder="fallback@company.com"
                helperText="Used when no recipient_map entry exists for the value" />
            )}
            {deliveryType === 's3' && (
              <TextField label="S3 prefix" size="small" fullWidth
                value={s3Prefix} onChange={e => setS3Prefix(e.target.value)}
                placeholder="my-bucket/reports/burst" />
            )}
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{result ? 'Close' : 'Cancel'}</Button>
        {!result && (
          <Button variant="contained" startIcon={submitting ? <CircularProgress size={14} color="inherit" /> : <BurstIcon />}
            onClick={handleSubmit} disabled={submitting}>
            Start Burst
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}

// ─── AlertRulesDialog ──────────────────────────────────────────────────────

function AlertRulesDialog({ open, report, onClose }) {
  const [rules, setRules] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ name: '', column_name: '', operator: '>', threshold_value: '', recipients: '', cooldown_minutes: 60 });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const loadRules = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    try { const res = await api.listAlertRules(report.id); setRules(res.rules || []); }
    finally { setLoading(false); }
  }, [report?.id]);

  useEffect(() => { if (open) loadRules(); }, [open, loadRules]);

  const handleCreate = async () => {
    if (!form.name || !form.column_name || !form.threshold_value) {
      setError('Name, column, and threshold are required'); return;
    }
    setSaving(true); setError('');
    try {
      await api.createAlertRule(report.id, { ...form, threshold_value: Number(form.threshold_value), channels: ['email'] });
      setAddOpen(false);
      setForm({ name: '', column_name: '', operator: '>', threshold_value: '', recipients: '', cooldown_minutes: 60 });
      loadRules();
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: number) => {
    try { await api.deleteAlertRule(id); loadRules(); }
    catch (e: any) { alert(e.message); }
  };

  const OPERATORS = ['>', '<', '>=', '<=', '=', '!='];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <AlertIcon color="warning" />
            <Typography variant="h6">Alert Rules — {report?.name}</Typography>
          </Box>
          <Button size="small" startIcon={<AddIcon />} variant="outlined" onClick={() => setAddOpen(v => !v)}>
            Add Rule
          </Button>
        </Box>
      </DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}
        <Collapse in={addOpen}>
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>New Alert Rule</Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
              <TextField label="Rule name" size="small" value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} sx={{ flex: '1 1 200px' }} />
              <TextField label="Column" size="small" value={form.column_name}
                onChange={e => setForm(f => ({ ...f, column_name: e.target.value }))} sx={{ flex: '1 1 160px' }} />
              <FormControl size="small" sx={{ flex: '0 0 90px' }}>
                <InputLabel>Op</InputLabel>
                <Select value={form.operator} label="Op" onChange={e => setForm(f => ({ ...f, operator: e.target.value }))}>
                  {OPERATORS.map(op => <MenuItem key={op} value={op}>{op}</MenuItem>)}
                </Select>
              </FormControl>
              <TextField label="Threshold" size="small" type="number" value={form.threshold_value}
                onChange={e => setForm(f => ({ ...f, threshold_value: e.target.value }))} sx={{ flex: '0 0 120px' }} />
              <TextField label="Recipients (comma-sep)" size="small" value={form.recipients}
                onChange={e => setForm(f => ({ ...f, recipients: e.target.value }))} sx={{ flex: '1 1 200px' }} />
            </Box>
            <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
              <Button size="small" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button size="small" variant="contained" onClick={handleCreate} disabled={saving}>
                {saving ? <CircularProgress size={14} /> : 'Create Rule'}
              </Button>
            </Box>
          </Paper>
        </Collapse>
        {loading ? <CircularProgress size={20} /> : rules.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
            No alert rules yet. Add one above.
          </Typography>
        ) : rules.map(rule => (
          <Paper key={rule.id} variant="outlined" sx={{ p: 1.5, mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="body2" fontWeight={600}>{rule.name}</Typography>
              <Typography variant="caption" color="text.secondary">
                {rule.column_name} {rule.operator} {rule.threshold_value}
                {rule.recipients && ` → ${rule.recipients}`}
              </Typography>
            </Box>
            <Chip label={rule.is_enabled ? 'Enabled' : 'Disabled'} size="small"
              color={rule.is_enabled ? 'success' : 'default'} variant="outlined" sx={{ height: 20, fontSize: 10 }} />
            <Tooltip title="Delete rule">
              <IconButton size="small" color="error" onClick={() => handleDelete(rule.id)}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Paper>
        ))}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}

// ─── ConditionalFormattingDialog ────────────────────────────────────────────

function ConditionalFormattingDialog({ open, report, onClose }) {
  const [rules, setRules] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ column_name: '', condition_type: 'value_range', bg_color: '#fff176', text_color: '', bold: false });

  const loadRules = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    try { const res = await api.getConditionalFormats(report.id); setRules(res.rules || []); }
    finally { setLoading(false); }
  }, [report?.id]);

  useEffect(() => { if (open) loadRules(); }, [open, loadRules]);

  const handleSave = async () => {
    setSaving(true);
    try { await api.saveConditionalFormats(report.id, rules); }
    catch (e: any) { alert(e.message); }
    finally { setSaving(false); }
  };

  const handleAdd = () => {
    if (!form.column_name.trim()) return;
    setRules(prev => [...prev, { ...form, rule_order: prev.length, is_enabled: true, id: Date.now() }]);
    setForm({ column_name: '', condition_type: 'value_range', bg_color: '#fff176', text_color: '', bold: false });
    setAddOpen(false);
  };

  const handleRemove = (idx: number) => {
    setRules(prev => prev.filter((_, i) => i !== idx));
  };

  const CONDITION_TYPES = [
    { value: 'value_range', label: 'Value range' },
    { value: 'equals',      label: 'Equals' },
    { value: 'contains',    label: 'Contains' },
    { value: 'not_null',    label: 'Not null' },
    { value: 'is_null',     label: 'Is null' },
  ];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <FormatIcon color="secondary" />
            <Typography variant="h6">Conditional Formatting — {report?.name}</Typography>
          </Box>
          <Button size="small" startIcon={<AddIcon />} variant="outlined" onClick={() => setAddOpen(v => !v)}>
            Add Rule
          </Button>
        </Box>
      </DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        <Collapse in={addOpen}>
          <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>New Rule</Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
              <TextField label="Column name" size="small" value={form.column_name}
                onChange={e => setForm(f => ({ ...f, column_name: e.target.value }))} sx={{ flex: '1 1 180px' }} />
              <FormControl size="small" sx={{ flex: '1 1 160px' }}>
                <InputLabel>Condition</InputLabel>
                <Select value={form.condition_type} label="Condition"
                  onChange={e => setForm(f => ({ ...f, condition_type: e.target.value }))}>
                  {CONDITION_TYPES.map(ct => <MenuItem key={ct.value} value={ct.value}>{ct.label}</MenuItem>)}
                </Select>
              </FormControl>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="caption" color="text.secondary">BG:</Typography>
                <input type="color" value={form.bg_color}
                  onChange={e => setForm(f => ({ ...f, bg_color: e.target.value }))}
                  style={{ width: 32, height: 26, border: 'none', padding: 0, cursor: 'pointer' }} />
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="caption" color="text.secondary">Text:</Typography>
                <input type="color" value={form.text_color || '#000000'}
                  onChange={e => setForm(f => ({ ...f, text_color: e.target.value }))}
                  style={{ width: 32, height: 26, border: 'none', padding: 0, cursor: 'pointer' }} />
              </Box>
            </Box>
            <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
              <Button size="small" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button size="small" variant="contained" onClick={handleAdd}>Add</Button>
            </Box>
          </Paper>
        </Collapse>
        {loading ? <CircularProgress size={20} /> : rules.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
            No formatting rules yet. Add one above.
          </Typography>
        ) : rules.map((rule, idx) => (
          <Paper key={rule.id || idx} variant="outlined" sx={{ p: 1.5, mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Box sx={{ width: 20, height: 20, borderRadius: 0.5, bgcolor: rule.bg_color || '#fff', border: '1px solid #ccc', flexShrink: 0 }} />
            <Box sx={{ flex: 1 }}>
              <Typography variant="body2" fontWeight={600}>{rule.column_name}</Typography>
              <Typography variant="caption" color="text.secondary">
                {CONDITION_TYPES.find(c => c.value === rule.condition_type)?.label || rule.condition_type}
                {rule.bold && ' · Bold'}
              </Typography>
            </Box>
            <Tooltip title="Remove">
              <IconButton size="small" color="error" onClick={() => handleRemove(idx)}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Paper>
        ))}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={14} /> : 'Save Rules'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ─── EmbedDialog ─────────────────────────────────────────────────────────────

function EmbedDialog({ open, report, onClose }) {
  const [tokens, setTokens] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [expiryDays, setExpiryDays] = useState<string>('');
  const [copied, setCopied] = useState('');

  const BASE = (import.meta.env.VITE_API_URL || window.location.origin).replace(/\/$/, '');
  const appOrigin = window.location.origin;

  const loadTokens = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    try { const res = await (api as any).listEmbedTokens(report.id); setTokens(res.tokens || []); }
    finally { setLoading(false); }
  }, [report?.id]);

  useEffect(() => { if (open) loadTokens(); }, [open, loadTokens]);

  const handleCreate = async () => {
    setCreating(true);
    try {
      await (api as any).createEmbedToken(report.id, expiryDays ? parseInt(expiryDays, 10) : null);
      setExpiryDays('');
      loadTokens();
    } catch (e: any) { alert(e.message); }
    finally { setCreating(false); }
  };

  const handleRevoke = async (token: string) => {
    if (!window.confirm('Revoke this embed token?')) return;
    await (api as any).revokeEmbedToken(token);
    loadTokens();
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(''), 2000);
    });
  };

  const embedUrl = (token: string) => `${appOrigin}/embed/${token}`;
  const iframeSnippet = (token: string) =>
    `<iframe src="${embedUrl(token)}" width="100%" height="600" frameborder="0" allowfullscreen></iframe>`;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <EmbedIcon color="info" />
        Embed Report — {report?.name}
        <Box sx={{ flex: 1 }} />
        <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        {/* Create new token */}
        <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
          <Typography variant="subtitle2">Create new embed token</Typography>
          <TextField
            select size="small" label="Expires in" value={expiryDays}
            onChange={e => setExpiryDays(e.target.value)} sx={{ minWidth: 130 }}
          >
            <MenuItem value="">Never</MenuItem>
            <MenuItem value="7">7 days</MenuItem>
            <MenuItem value="30">30 days</MenuItem>
            <MenuItem value="90">90 days</MenuItem>
          </TextField>
          <Button variant="contained" size="small" onClick={handleCreate} disabled={creating}>
            {creating ? <CircularProgress size={14} /> : 'Generate Token'}
          </Button>
        </Box>
        <Divider sx={{ mb: 2 }} />
        {loading ? <CircularProgress size={20} /> : tokens.length === 0 ? (
          <Typography variant="body2" color="text.secondary">No embed tokens yet.</Typography>
        ) : tokens.map(t => {
          const isExpired = t.expires_at && new Date(t.expires_at) < new Date();
          return (
            <Paper key={t.token} variant="outlined" sx={{ p: 1.5, mb: 1.5 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                <Chip label={t.is_active && !isExpired ? 'Active' : isExpired ? 'Expired' : 'Revoked'}
                  size="small" color={t.is_active && !isExpired ? 'success' : 'default'} />
                <Typography variant="caption" color="text.secondary">
                  Created {t.created_at ? new Date(t.created_at).toLocaleDateString() : '—'}
                  {t.expires_at ? ` · Expires ${new Date(t.expires_at).toLocaleDateString()}` : ' · Never expires'}
                  {` · ${t.access_count || 0} views`}
                </Typography>
                <Box sx={{ flex: 1 }} />
                {t.is_active && !isExpired && (
                  <Tooltip title={copied === `url:${t.token}` ? 'Copied!' : 'Copy URL'}>
                    <IconButton size="small" onClick={() => copyText(embedUrl(t.token), `url:${t.token}`)}>
                      <EmbedCopyIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                )}
                {t.is_active && (
                  <Tooltip title="Revoke token">
                    <IconButton size="small" color="error" onClick={() => handleRevoke(t.token)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                )}
              </Box>
              {t.is_active && !isExpired && (
                <Box sx={{ mt: 1 }}>
                  <Typography variant="caption" color="text.secondary">Iframe snippet:</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                    <Box component="code" sx={{ flex: 1, p: 1, bgcolor: 'grey.100', borderRadius: 1, fontSize: 11, overflowX: 'auto', display: 'block', whiteSpace: 'pre' }}>
                      {iframeSnippet(t.token)}
                    </Box>
                    <Tooltip title={copied === `iframe:${t.token}` ? 'Copied!' : 'Copy iframe'}>
                      <IconButton size="small" onClick={() => copyText(iframeSnippet(t.token), `iframe:${t.token}`)}>
                        <EmbedCopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              )}
            </Paper>
          );
        })}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────

export default function ReportsManagerPage() {
  const { lastMessage } = useWebSocket();
  const appSettings = useAppSettings();
  const [searchParams] = useSearchParams();

  const [reports, setReports] = useState([]);
  const [savedQueries, setSavedQueries] = useState([]);
  const [sqlQueries, setSqlQueries] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedReport, setSelectedReport] = useState(null);
  const [paramValues, setParamValues] = useState({});
  const [executing, setExecuting] = useState(false);
  const [execError, setExecError] = useState('');
  const [executionId, setExecutionId] = useState(null);
  const [execStatus, setExecStatus] = useState(''); // 'running' | 'completed' | 'failed'

  const [leftOpen, setLeftOpen] = useState(true);
  const [paramsOpen, setParamsOpen] = useState(true);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Enterprise feature dialogs
  const [burstOpen, setBurstOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [formattingOpen, setFormattingOpen] = useState(false);
  const [embedOpen, setEmbedOpen] = useState(false);
  const [moreAnchorEl, setMoreAnchorEl] = useState<null | HTMLElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [rpts, sqs, sqls] = await Promise.all([
        api.listReports(false),
        api.listQueries(true),
        api.listSqlQueries(true),
      ]);
      setReports(rpts);
      setSavedQueries(sqs);
      setSqlQueries(sqls);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Auto-select report from ?reportId URL param (e.g. navigated from Report Catalog)
  useEffect(() => {
    const reportId = searchParams.get('reportId');
    if (!reportId || reports.length === 0) return;
    const found = reports.find(r => String(r.id) === reportId);
    if (found && (!selectedReport || String(selectedReport.id) !== reportId)) {
      handleSelectReport(found);
    }
  }, [reports, searchParams]); // eslint-disable-line react-hooks/exhaustive-deps

  // WS: execution completion
  useEffect(() => {
    if (!lastMessage || !executionId) return;
    const { type, execution_id } = lastMessage;
    if (execution_id !== executionId) return;
    if (type === 'execution_completed') { setExecStatus('completed'); setExecuting(false); }
    else if (type === 'execution_failed') { setExecStatus('failed'); setExecError(lastMessage.error || 'Execution failed'); setExecuting(false); }
  }, [lastMessage, executionId]);

  const loadHistory = useCallback(async (reportId: string) => {
    setHistoryLoading(true);
    try {
      const res = await api.getReportHistory(reportId);
      setHistory(res.executions || []);
    } catch { setHistory([]); }
    finally { setHistoryLoading(false); }
  }, []);

  const handleSelectReport = (r) => {
    setSelectedReport(r);
    setParamsOpen(true);
    setHistoryOpen(false);
    setHistory([]);
    const defaults = {};
    (r.parameters || []).forEach(p => {
      if (p.type === 'multiselect') {
        defaults[p.name] = p.default_value ? [p.default_value] : [];
      } else if (p.default_value != null) {
        defaults[p.name] = p.default_value;
      }
    });
    setParamValues(defaults);
    setExecutionId(null);
    setExecStatus('');
    setExecError('');
  };

  const handleExecute = async () => {
    setParamsOpen(false); // collapse params to maximize results area
    setExecuting(true);
    setExecError('');
    setExecutionId(null);
    setExecStatus('running');
    try {
      const res = await api.executeReport(selectedReport.id, paramValues);
      setExecutionId(res.execution_id);
    } catch (e) {
      setExecError(e.message || 'Execution failed');
      setExecStatus('failed');
      setExecuting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteReport(deleteTarget.id);
      if (selectedReport?.id === deleteTarget.id) setSelectedReport(null);
      setDeleteTarget(null);
      load();
    } catch (e) { alert(e.message); }
  };

  const sourceLabel = (r) => r.saved_query_id ? 'Parquet' : r.sql_saved_query_id ? 'SQL' : '—';

  return (
    <Box sx={{ display: 'flex', height: '100%', minHeight: 0, overflow: 'hidden' }}>

      {/* ── Left: Report List ──────────────────────────────────────── */}
      <Box sx={{
        width: leftOpen ? 320 : 0,
        minWidth: leftOpen ? 320 : 0,
        flexShrink: 0,
        borderRight: leftOpen ? '1px solid' : 'none',
        borderColor: 'divider',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        transition: 'width 0.2s ease, min-width 0.2s ease',
      }}>
        <Box sx={{ px: 2, py: 1.5, display: 'flex', alignItems: 'center', gap: 1, borderBottom: '1px solid', borderColor: 'divider', minWidth: 320 }}>
          <ReportIcon color="primary" fontSize="small" />
          <Typography variant="subtitle2" sx={{ flex: 1, fontWeight: 600 }}>Reports</Typography>
          <Tooltip title="Refresh">
            <IconButton size="small" onClick={load} disabled={loading}><RefreshIcon fontSize="small" /></IconButton>
          </Tooltip>
          <Button size="small" variant="contained" startIcon={<AddIcon />}
            onClick={() => { setEditTarget(null); setDialogOpen(true); }}>
            New
          </Button>
          <Tooltip title="Hide panel">
            <IconButton size="small" onClick={() => setLeftOpen(false)}><CollapseIcon fontSize="small" /></IconButton>
          </Tooltip>
        </Box>

        <Box sx={{ flex: 1, overflowY: 'auto', minWidth: 320 }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', pt: 4 }}><CircularProgress size={24} /></Box>
          ) : reports.length === 0 ? (
            <Box sx={{ px: 3, pt: 4, textAlign: 'center' }}>
              <Typography variant="body2" color="text.secondary">No reports yet.</Typography>
              <Typography variant="caption" color="text.disabled">Create one to get started.</Typography>
            </Box>
          ) : reports.map(r => {
            const active = selectedReport?.id === r.id;
            return (
              <Box key={r.id} onClick={() => handleSelectReport(r)}
                sx={{
                  px: 2, py: 1.5, cursor: 'pointer', borderBottom: '1px solid', borderColor: 'divider',
                  bgcolor: active ? 'primary.50' : 'transparent',
                  borderLeft: '3px solid', borderLeftColor: active ? 'primary.main' : 'transparent',
                  '&:hover': { bgcolor: active ? 'primary.50' : 'action.hover' },
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                  <Box sx={{ minWidth: 0, flex: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: active ? 600 : 400, color: active ? 'primary.main' : 'text.primary', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {r.name}
                    </Typography>
                    {r.description && (
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {r.description}
                      </Typography>
                    )}
                    <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, flexWrap: 'wrap' }}>
                      <Chip label={sourceLabel(r)} size="small" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                      {(r.parameters || []).length > 0 && (
                        <Chip label={`${r.parameters.length} param${r.parameters.length !== 1 ? 's' : ''}`} size="small" color="primary" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                      )}
                      {r.execution_count > 0 && (
                        <Chip label={`${r.execution_count} runs`} size="small" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                      )}
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', flexShrink: 0, ml: 1 }}>
                    <Tooltip title="Edit">
                      <IconButton size="small" onClick={e => { e.stopPropagation(); setEditTarget(r); setDialogOpen(true); }}>
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={e => { e.stopPropagation(); setDeleteTarget(r); }}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </Box>
            );
          })}
        </Box>
      </Box>

      {/* ── Collapsed-panel tab (always visible when left is hidden) ── */}
      {!leftOpen && (
        <Tooltip title="Show reports list" placement="right">
          <Box
            onClick={() => setLeftOpen(true)}
            sx={{
              width: 24, flexShrink: 0,
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
              borderRight: '1px solid', borderColor: 'divider',
              bgcolor: 'background.paper',
              '&:hover': { bgcolor: 'action.hover' },
              gap: 0.5, py: 2,
            }}
          >
            <ExpandIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography
              variant="caption"
              sx={{ fontSize: 9, color: 'text.secondary', writingMode: 'vertical-rl', letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 600 }}
            >
              Reports
            </Typography>
          </Box>
        </Tooltip>
      )}

      {/* ── Right: Execution panel ─────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Phase 24B: active profile banner */}
        {appSettings.active_connection_profile && (
          <Alert severity="warning" sx={{ borderRadius: 0, py: 0.5, fontSize: 12 }}>
            Connection profile active: <strong>{appSettings.active_connection_profile.name}</strong> — connections may be redirected.
          </Alert>
        )}
        {!selectedReport ? (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', flexDirection: 'column', gap: 2 }}>
            <ReportIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
            <Typography variant="h6" color="text.secondary">Select a report to run it</Typography>
            <Typography variant="body2" color="text.disabled">or create a new parametric report</Typography>
          </Box>
        ) : (
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minHeight: 0 }}>
            {/* Report header */}
            <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'background.paper', display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, lineHeight: 1.3 }}>{selectedReport.name}</Typography>
                {selectedReport.description && (
                  <Typography variant="body2" color="text.secondary" sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedReport.description}</Typography>
                )}
              </Box>
              <Box sx={{ display: 'flex', gap: 0.5, flexShrink: 0, alignItems: 'center' }}>
                {selectedReport.schedule_config?.enabled && (
                  <Tooltip title={`Scheduled: ${selectedReport.schedule_config.cron}`}>
                    <Chip icon={<ScheduleIcon />} label="Scheduled" size="small" color="info" variant="outlined" sx={{ height: 22, fontSize: 10 }} />
                  </Tooltip>
                )}
                {(selectedReport.cache_ttl_minutes || 0) > 0 && (
                  <Tooltip title={`Cache TTL: ${selectedReport.cache_ttl_minutes} min`}>
                    <Chip label={`Cache ${selectedReport.cache_ttl_minutes}m`} size="small" color="warning" variant="outlined" sx={{ height: 22, fontSize: 10 }} />
                  </Tooltip>
                )}
                {selectedReport.connection_override_id && (
                  <Tooltip title={`Connection override active (ID: ${selectedReport.connection_override_id})`}>
                    <Chip label="Override" size="small" color="secondary" variant="outlined" sx={{ height: 22, fontSize: 10 }} />
                  </Tooltip>
                )}
                <Tooltip title="Execution history">
                  <IconButton size="small" onClick={() => { setHistoryOpen(v => !v); if (!historyOpen) loadHistory(selectedReport.id); }}>
                    <HistoryIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Edit report">
                  <IconButton size="small" onClick={() => { setEditTarget(selectedReport); setDialogOpen(true); }}>
                    <EditIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Download CSV">
                  <IconButton size="small" onClick={() => api.downloadReportDirect(selectedReport.id, paramValues, 'csv')}>
                    <DownloadIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Download PDF">
                  <IconButton size="small" color="error"
                    onClick={() => api.downloadReportPDF(selectedReport.id, Object.fromEntries(Object.entries(paramValues).map(([k,v])=>[k,String(v)])))}>
                    <PdfIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Enterprise features">
                  <IconButton size="small" onClick={e => setMoreAnchorEl(e.currentTarget)}>
                    <MoreVertIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Menu anchorEl={moreAnchorEl} open={Boolean(moreAnchorEl)} onClose={() => setMoreAnchorEl(null)}>
                  <MenuItem onClick={() => { setMoreAnchorEl(null); setBurstOpen(true); }}>
                    <BurstIcon fontSize="small" sx={{ mr: 1, color: 'primary.main' }} /> Burst Report
                  </MenuItem>
                  <MenuItem onClick={() => { setMoreAnchorEl(null); setAlertsOpen(true); }}>
                    <AlertIcon fontSize="small" sx={{ mr: 1, color: 'warning.main' }} /> Alert Rules
                  </MenuItem>
                  <MenuItem onClick={() => { setMoreAnchorEl(null); setFormattingOpen(true); }}>
                    <FormatIcon fontSize="small" sx={{ mr: 1, color: 'secondary.main' }} /> Conditional Formatting
                  </MenuItem>
                  <MenuItem onClick={() => { setMoreAnchorEl(null); setEmbedOpen(true); }}>
                    <EmbedIcon fontSize="small" sx={{ mr: 1, color: 'info.main' }} /> Embed Report
                  </MenuItem>
                </Menu>
              </Box>
            </Box>

            {/* Execution History — collapsible */}
            <Collapse in={historyOpen}>
              <Box sx={{ px: 2, py: 1, borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50', maxHeight: 200, overflowY: 'auto' }}>
                <Typography variant="caption" sx={{ fontWeight: 600, mb: 0.5, display: 'block' }}>Execution History</Typography>
                {historyLoading ? <CircularProgress size={16} /> : history.length === 0 ? (
                  <Typography variant="caption" color="text.disabled">No executions yet</Typography>
                ) : history.map(h => (
                  <Box key={h.execution_id} sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.25 }}>
                    <Chip
                      label={h.status}
                      size="small"
                      color={h.status === 'completed' ? 'success' : h.status === 'failed' ? 'error' : 'default'}
                      variant="outlined"
                      sx={{ height: 18, fontSize: 10, minWidth: 60 }}
                    />
                    <Typography variant="caption" color="text.secondary" sx={{ minWidth: 120 }}>
                      {h.created_at ? new Date(h.created_at).toLocaleString() : '—'}
                    </Typography>
                    <Typography variant="caption">{h.total_rows != null ? `${h.total_rows} rows` : ''}</Typography>
                    {h.cached && <Chip label="cached" size="small" variant="outlined" sx={{ height: 16, fontSize: 9 }} />}
                    <Box sx={{ flex: 1 }} />
                    {h.status === 'completed' && (
                      <Button size="small" sx={{ fontSize: 10, minWidth: 0, py: 0 }}
                        onClick={() => { setExecutionId(h.execution_id); setExecStatus('completed'); }}>
                        View
                      </Button>
                    )}
                  </Box>
                ))}
              </Box>
            </Collapse>

            {/* Bookmarks bar */}
            <BookmarksBar
              reportId={selectedReport.id}
              paramValues={paramValues}
              onLoadBookmark={(vals) => setParamValues(vals)}
            />

            {/* Parameters — collapsible strip */}
            <Box sx={{ borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50', flexShrink: 0 }}>
              {/* Single-line header: toggle + label + chip + Run button + status */}
              <Box sx={{ px: 2, py: 0.75, display: 'flex', alignItems: 'center', gap: 1 }}>
                <Tooltip title={paramsOpen ? 'Collapse parameters' : 'Expand parameters'}>
                  <IconButton size="small" onClick={() => setParamsOpen(v => !v)} sx={{ p: 0.25 }}>
                    {paramsOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                  </IconButton>
                </Tooltip>
                <Typography
                  variant="body2" sx={{ fontWeight: 600, cursor: 'pointer', userSelect: 'none' }}
                  onClick={() => setParamsOpen(v => !v)}
                >
                  Parameters
                </Typography>
                {(selectedReport.parameters || []).length > 0 ? (
                  <Chip
                    label={`${selectedReport.parameters.length} param${selectedReport.parameters.length !== 1 ? 's' : ''}`}
                    size="small" color="primary" variant="outlined" sx={{ height: 18, fontSize: 10 }}
                  />
                ) : (
                  <Typography variant="caption" color="text.secondary">— runs all data</Typography>
                )}
                <Box sx={{ flex: 1 }} />
                <Button
                  variant="contained" size="small"
                  startIcon={executing ? <CircularProgress size={13} color="inherit" /> : <RunIcon />}
                  onClick={handleExecute} disabled={executing}
                >
                  {executing ? 'Running…' : 'Run Report'}
                </Button>
                {execStatus === 'running'   && <Chip label="Running…"  color="info"    size="small" />}
                {execStatus === 'completed' && <Chip label="Completed" color="success" size="small" />}
                {execStatus === 'failed'    && <Chip label="Failed"    color="error"   size="small" />}
              </Box>

              {/* Collapsible body: param inputs + error + API URL */}
              <Collapse in={paramsOpen}>
                <Box sx={{ px: 3, py: 1.5, borderTop: '1px solid', borderColor: 'divider', maxHeight: '40vh', overflowY: 'auto' }}>
                  <ParamValueForm
                    params={selectedReport.parameters}
                    values={paramValues}
                    onChange={setParamValues}
                    reportId={selectedReport.id}
                  />
                  <Collapse in={!!execError}>
                    <Alert severity="error" sx={{ mt: 1.5 }}>{execError}</Alert>
                  </Collapse>
                  <ApiUrlBox
                    reportId={selectedReport.id}
                    reportName={selectedReport.name}
                    paramValues={paramValues}
                  />
                </Box>
              </Collapse>
            </Box>

            {/* Results — DataGridViewer takes full remaining height */}
            <Box sx={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
              {execStatus === 'completed' && executionId && <ResultsPanel executionId={executionId} />}
              {execStatus === 'running' && (
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', pt: 6, gap: 2 }}>
                  <CircularProgress />
                  <Typography color="text.secondary">Executing report…</Typography>
                </Box>
              )}
              {!execStatus && (
                <Box sx={{ pt: 4, textAlign: 'center' }}>
                  <Typography variant="body2" color="text.disabled">
                    Fill in parameters above and click Run Report.
                  </Typography>
                </Box>
              )}
            </Box>
          </Box>
        )}
      </Box>

      {/* ── Create/Edit Dialog ──────────────────────────────────────── */}
      <ReportDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSaved={() => { setDialogOpen(false); load(); }}
        initialData={editTarget}
        savedQueries={savedQueries}
        sqlQueries={sqlQueries}
      />

      {/* ── Delete Confirm ─────────────────────────────────────────── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs">
        <DialogTitle>Delete Report?</DialogTitle>
        <DialogContent>
          <Typography>Delete <strong>{deleteTarget?.name}</strong>? This cannot be undone.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>

      {/* ── Enterprise Feature Dialogs ─────────────────────────────── */}
      <BurstDialog
        open={burstOpen}
        report={selectedReport}
        onClose={() => setBurstOpen(false)}
      />
      <AlertRulesDialog
        open={alertsOpen}
        report={selectedReport}
        onClose={() => setAlertsOpen(false)}
      />
      <ConditionalFormattingDialog
        open={formattingOpen}
        report={selectedReport}
        onClose={() => setFormattingOpen(false)}
      />
      <EmbedDialog
        open={embedOpen}
        report={selectedReport}
        onClose={() => setEmbedOpen(false)}
      />
    </Box>
  );
}
