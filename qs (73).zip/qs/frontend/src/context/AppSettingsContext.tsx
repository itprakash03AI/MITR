import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { getAuthHeader } from './AuthContext';

export interface AppLimits {
  col_auto_project: number;
  default_query_limit: number;
  streaming_default_on: boolean;
  stream_bg_download_default: boolean;
  max_display_cols: number;
  stream_query_limit_max: number;
  max_stream_files: number;
}

export interface AppFeatures {
  streaming_mode: string;
  streaming_enabled: boolean;
  export_enabled: boolean;
  sql_editor_enabled: boolean;
  scheduler_enabled: boolean;
  connections_enabled: boolean;
  upload_enabled: boolean;
  max_query_limit: number;
}

export interface WorkspaceInfo {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  member_count?: number;
}

export interface AppSettings {
  limits: AppLimits;
  features: AppFeatures;
  role: string;
  loaded: boolean;
  active_connection_profile?: { id: number; name: string } | null;
  workspaces?: WorkspaceInfo[];
}

const DEFAULTS: AppSettings = {
  limits: {
    col_auto_project: 50,
    default_query_limit: 1000,
    streaming_default_on: false,
    stream_bg_download_default: true,
    max_display_cols: 50,
    stream_query_limit_max: 5000,
    max_stream_files: 200,
  },
  features: {
    streaming_mode: 'all',
    streaming_enabled: true,
    export_enabled: true,
    sql_editor_enabled: true,
    scheduler_enabled: true,
    connections_enabled: true,
    upload_enabled: true,
    max_query_limit: 0,
  },
  role: 'admin',
  loaded: false,
};

const AppSettingsContext = createContext<AppSettings>(DEFAULTS);
const AppSettingsRefreshContext = createContext<() => void>(() => {});

export const useAppSettings = () => useContext(AppSettingsContext);
export const useAppSettingsRefresh = () => useContext(AppSettingsRefreshContext);

const API_BASE_URL = import.meta.env.VITE_API_URL || '';

export const AppSettingsProvider = ({ children }: { children: ReactNode }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULTS);

  const fetchSettings = useCallback(async () => {
    try {
      const headers: Record<string, string> = {};
      const authHeader = getAuthHeader();
      if (authHeader) headers['Authorization'] = authHeader;
      const res = await fetch(`${API_BASE_URL}/api/app-settings`, { headers });
      if (res.ok) {
        const data = await res.json();
        setSettings({ ...data, loaded: true });
      }
    } catch {
      // Use defaults if fetch fails
    }
  }, []);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  return (
    <AppSettingsContext.Provider value={settings}>
      <AppSettingsRefreshContext.Provider value={fetchSettings}>
        {children}
      </AppSettingsRefreshContext.Provider>
    </AppSettingsContext.Provider>
  );
};
