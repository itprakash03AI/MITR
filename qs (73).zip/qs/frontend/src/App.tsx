import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeContextProvider } from './context/ThemeContext';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Layout from './components/Layout';
import LoginPage from './components/LoginPage';
import QueryTabManager from './components/QueryTabManager';
import SavedQueries from './components/SavedQueries';
import Downloads from './components/Downloads';
import ExecutionHistory from './components/ExecutionHistory';
import ReportPage from './components/ReportPage';
import ConnectionManager from './components/ConnectionManager';
import SqlQueryPage from './components/SqlQueryPage';
import ReportsManagerPage from './components/ReportsManagerPage';
import ReportConnectorsPage from './components/ReportConnectorsPage';
import SchedulesPage from './components/SchedulesPage';
import FilePreviewPage from './components/FilePreviewPage';
import DashboardPage from './components/DashboardPage';
import SharedQueryPage from './components/SharedQueryPage';
import SharedDashboardPage from './components/SharedDashboardPage';
import EmbeddedReportPage from './components/EmbeddedReportPage';
import MaterializedViewsPage from './components/MaterializedViewsPage';
import LocalTablesPage from './components/LocalTablesPage';
import ErrorBoundary from './components/ErrorBoundary';

// Lazy-loaded heavy pages — split into separate chunks to reduce initial bundle size
const AdminPage = lazy(() => import('./components/AdminPage'));
const LineagePage = lazy(() => import('./components/LineagePage'));
const ReportCatalogPage = lazy(() => import('./components/ReportCatalogPage'));
import { WebSocketProvider } from './context/WebSocketContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppSettingsProvider } from './context/AppSettingsContext';
import { WorkspaceProvider } from './context/WorkspaceContext';
import NotificationCenter from './components/NotificationCenter';
import './App.css';

// Shown to logged-in AD users who lack the required role
const AccessDenied = () => {
  const { user, logout } = useAuth();
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 2 }}>
      <LockOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
      <Typography variant="h5" fontWeight={600}>Access Denied</Typography>
      <Typography color="text.secondary">
        Your account (<strong>{user?.display_name || user?.username}</strong>) does not have permission to access QueryStudio.
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Contact your administrator to be added to an authorised AD group.
      </Typography>
      <Button variant="outlined" onClick={logout}>Sign Out</Button>
    </Box>
  );
};

// Role guard — restricts route access based on RBAC role
const RoleGuard = ({ roles, children }: { roles: string[], children: React.ReactNode }) => {
  const { user, authEnabled } = useAuth();
  if (!authEnabled) return <>{children}</>;
  const role = (user as any)?.role || 'viewer';
  if (!roles.includes(role)) return <AccessDenied />;
  return <>{children}</>;
};

const AppRoutes = () => {
  const { authEnabled, user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Auth enabled but not logged in → login screen
  if (authEnabled && !user) {
    return <LoginPage />;
  }

  return (
    <AppSettingsProvider>
    <WorkspaceProvider>
    <WebSocketProvider>
      <NotificationProvider>
        <Layout>
          <NotificationCenter />
          <ErrorBoundary resetKey={location.pathname}>
            <Suspense fallback={<Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress /></Box>}>
              <Routes>
                <Route path="/connections"       element={<RoleGuard roles={['admin','analyst']}><ConnectionManager /></RoleGuard>} />
                <Route path="/materialized-views" element={<RoleGuard roles={['admin','analyst']}><MaterializedViewsPage /></RoleGuard>} />
                <Route path="/local-tables"       element={<RoleGuard roles={['admin','analyst']}><LocalTablesPage /></RoleGuard>} />
                <Route path="/lineage"            element={<RoleGuard roles={['admin','analyst']}><LineagePage /></RoleGuard>} />
                <Route path="/"                  element={<RoleGuard roles={['admin','analyst']}><QueryTabManager /></RoleGuard>} />
                <Route path="/reports"           element={<ReportPage />} />
                <Route path="/reports/:reportId" element={<ReportPage />} />
                <Route path="/saved-queries"     element={<SavedQueries />} />
                <Route path="/executions"        element={<ExecutionHistory />} />
                <Route path="/downloads"         element={<Downloads />} />
                <Route path="/sql"               element={<RoleGuard roles={['admin','analyst']}><SqlQueryPage /></RoleGuard>} />
                <Route path="/report-manager"    element={<ReportsManagerPage />} />
                <Route path="/report-catalog"    element={<ReportCatalogPage />} />
                <Route path="/report-connectors" element={<RoleGuard roles={['admin','analyst']}><ReportConnectorsPage /></RoleGuard>} />
                <Route path="/schedules"         element={<RoleGuard roles={['admin','analyst']}><SchedulesPage /></RoleGuard>} />
                <Route path="/file-preview"      element={<FilePreviewPage />} />
                <Route path="/dashboards"        element={<DashboardPage />} />
                <Route path="/admin"             element={<RoleGuard roles={['admin']}><AdminPage /></RoleGuard>} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </Layout>
      </NotificationProvider>
    </WebSocketProvider>
    </WorkspaceProvider>
    </AppSettingsProvider>
  );
};

function App() {
  return (
    <ThemeContextProvider>
      <Router>
        {/* Public routes — no auth required */}
        <Routes>
          <Route path="/shared/:token" element={<SharedQueryPage />} />
          <Route path="/shared-dashboard/:token" element={<SharedDashboardPage />} />
          <Route path="/embed/:token" element={<EmbeddedReportPage />} />
          <Route path="/*" element={
            <AuthProvider>
              <AppRoutes />
            </AuthProvider>
          } />
        </Routes>
      </Router>
    </ThemeContextProvider>
  );
}

export default App;
