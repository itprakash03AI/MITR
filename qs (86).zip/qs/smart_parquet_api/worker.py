#!/usr/bin/env python3
# ============================================================
# worker.py — Distributed DuckDB query worker
# ============================================================
"""
WHAT THIS FILE IS
══════════════════
A standalone process that:
  1. Connects to Redis
  2. Waits for jobs (BRPOP — blocking, no CPU spin)
  3. Executes DuckDB query
  4. Stores result back in Redis (or S3 for large results)
  5. Calls webhook if configured
  6. Repeats forever

HOW TO RUN
═══════════
  # Single worker
  python worker.py

  # Multiple workers on same machine (each independent)
  python worker.py &
  python worker.py &
  python worker.py &

  # Docker
  docker run -e REDIS_URL=redis://redis:6379 my-api-image python worker.py

  # Docker Compose scale
  docker-compose up --scale worker=8

  # Kubernetes
  kubectl scale deployment query-worker --replicas=10

WORKER SPECIALISATION (optional)
══════════════════════════════════
  # Heavy worker — only picks up high-priority jobs
  WORKER_QUEUES=jobs:high python worker.py

  # Light worker — handles normal + low
  WORKER_QUEUES=jobs:normal,jobs:low python worker.py

  # The default handles all three (high → normal → low)

ENVIRONMENT VARIABLES
══════════════════════
  REDIS_URL           redis://localhost:6379/0
  WORKER_ID           auto-generated UUID (set to pod name in Kubernetes)
  WORKER_QUEUES       comma-separated queue names (default: all three)
  DUCKDB_THREADS      threads per query (default: 4)
  DUCKDB_MEMORY_LIMIT memory limit per worker (default: 4GB)
  S3_ENABLED          true/false
  AWS_ACCESS_KEY_ID   ...
  AWS_SECRET_ACCESS_KEY ...
  S3_REGION           us-east-1
  RESULT_SIZE_THRESHOLD_MB  10.0 — results larger than this go to S3
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add project root to path so we can import app modules
sys.path.insert(0, str(Path(__file__).parent))

import duckdb
import structlog

logger = structlog.get_logger()


# ═══════════════════════════════════════════════════════════════════════════
# Worker configuration
# ═══════════════════════════════════════════════════════════════════════════

WORKER_ID     = os.getenv("WORKER_ID", f"worker-{uuid.uuid4().hex[:8]}")
REDIS_URL     = os.getenv("REDIS_URL",     "redis://localhost:6379/0")
DATA_DIR      = os.getenv("LOCAL_DATA_DIR", str(Path(__file__).parent / "data"))
DUCKDB_THREADS = int(os.getenv("DUCKDB_THREADS",     "4"))
MEMORY_LIMIT  = os.getenv("DUCKDB_MEMORY_LIMIT",     "4GB")
TEMP_DIR      = os.getenv("DUCKDB_TEMP_DIR",         "/tmp/duckdb")
JOB_TTL       = int(os.getenv("JOB_TTL_SECONDS",     "3600"))
RESULT_MB_MAX = float(os.getenv("RESULT_SIZE_THRESHOLD_MB", "10.0"))
INLINE_MAX    = int(os.getenv("RESULT_INLINE_MAX_ROWS", "50000"))

# Queues this worker listens to (priority order — BRPOP drains left to right)
_queues_env = os.getenv("WORKER_QUEUES", "")
QUEUES = (
    [q.strip() for q in _queues_env.split(",") if q.strip()]
    if _queues_env
    else ["jobs:high", "jobs:normal", "jobs:low"]
)

# S3 settings
S3_ENABLED     = os.getenv("S3_ENABLED", "false").lower() == "true"
S3_BUCKET      = os.getenv("S3_BUCKET", "")
S3_REGION      = os.getenv("S3_REGION", "us-east-1")
S3_PREFIX      = os.getenv("S3_RESULTS_PREFIX", "query-results")
AWS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET     = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_TOKEN      = os.getenv("AWS_SESSION_TOKEN")
S3_ENDPOINT    = os.getenv("S3_ENDPOINT_URL")


# ═══════════════════════════════════════════════════════════════════════════
# DuckDB connection (one per worker process)
# ═══════════════════════════════════════════════════════════════════════════

def _make_duckdb() -> duckdb.DuckDBPyConnection:
    os.makedirs(TEMP_DIR, exist_ok=True)
    conn = duckdb.connect(":memory:")
    conn.execute(f"SET threads TO {DUCKDB_THREADS}")
    conn.execute(f"SET memory_limit='{MEMORY_LIMIT}'")
    conn.execute(f"SET temp_directory='{TEMP_DIR}'")
    conn.execute("SET enable_progress_bar=false")

    if S3_ENABLED:
        conn.execute("INSTALL httpfs; LOAD httpfs")
        conn.execute(f"SET s3_region='{S3_REGION}'")
        if AWS_KEY_ID:
            conn.execute(f"SET s3_access_key_id='{AWS_KEY_ID}'")
        if AWS_SECRET:
            conn.execute(f"SET s3_secret_access_key='{AWS_SECRET}'")
        if AWS_TOKEN:
            conn.execute(f"SET s3_session_token='{AWS_TOKEN}'")
        if S3_ENDPOINT:
            conn.execute(f"SET s3_endpoint='{S3_ENDPOINT}'")
            conn.execute("SET s3_use_ssl=false; SET s3_url_style='path'")

    logger.info("duckdb_ready", threads=DUCKDB_THREADS, memory=MEMORY_LIMIT)
    return conn


# One DuckDB connection per worker (never shared across threads here)
_db: Optional[duckdb.DuckDBPyConnection] = None

def get_db() -> duckdb.DuckDBPyConnection:
    global _db
    if _db is None:
        _db = _make_duckdb()
    return _db


# ═══════════════════════════════════════════════════════════════════════════
# Result storage helpers
# ═══════════════════════════════════════════════════════════════════════════

def _estimate_mb(rows: List[Dict]) -> float:
    """Rough size estimate without full serialisation."""
    sample = rows[:100]
    if not sample:
        return 0.0
    sample_bytes = len(json.dumps(sample, default=str).encode())
    return (sample_bytes / len(sample)) * len(rows) / 1_048_576


def _write_result_to_s3(job_id: str, rows: List[Dict], columns: List[str]) -> str:
    """
    Write large result as Parquet to S3.
    Returns the s3:// path.
    Worker-side S3 write via DuckDB COPY statement.
    """
    import tempfile
    import pandas as pd

    # Write locally first, then upload
    tmp_path = f"/tmp/result_{job_id}.parquet"
    df = pd.DataFrame(rows, columns=columns)
    df.to_parquet(tmp_path, index=False)

    s3_path = f"s3://{S3_BUCKET}/{S3_PREFIX}/{job_id}/result.parquet"

    try:
        import boto3
        s3 = boto3.client(
            "s3", region_name=S3_REGION,
            aws_access_key_id=AWS_KEY_ID,
            aws_secret_access_key=AWS_SECRET,
            aws_session_token=AWS_TOKEN,
        )
        s3.upload_file(tmp_path, S3_BUCKET, f"{S3_PREFIX}/{job_id}/result.parquet")
        os.unlink(tmp_path)
        logger.info("result_written_s3", job_id=job_id, path=s3_path)
        return s3_path
    except Exception as e:
        logger.error("s3_upload_failed", job_id=job_id, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════════════
# Core query execution
# ═══════════════════════════════════════════════════════════════════════════

def execute_query(job: Dict) -> Dict:
    """
    Run the DuckDB query for this job. Returns result dict.
    This runs synchronously — worker is single-threaded per process.
    """
    sql       = job["sql"]
    page      = job.get("page", 1)
    page_size = min(job.get("page_size", 1000), 50_000)
    job_id    = job["job_id"]

    offset    = (page - 1) * page_size
    count_sql = f"SELECT COUNT(*) FROM ({sql}) __c__"
    paged_sql = f"SELECT * FROM ({sql}) __p__ LIMIT {page_size} OFFSET {offset}"

    t0   = time.perf_counter()
    db   = get_db()

    total_rows = db.execute(count_sql).fetchone()[0]
    rel        = db.execute(paged_sql)
    cols       = [d[0] for d in rel.description]
    rows       = [dict(zip(cols, r)) for r in rel.fetchall()]
    elapsed_ms = (time.perf_counter() - t0) * 1000

    logger.info(
        "query_done",
        job_id=job_id,
        total_rows=total_rows,
        returned=len(rows),
        ms=round(elapsed_ms, 2),
    )

    # Decide where to store result
    size_mb = _estimate_mb(rows)
    if size_mb > RESULT_MB_MAX and S3_ENABLED and S3_BUCKET:
        s3_path  = _write_result_to_s3(job_id, rows, cols)
        result   = {
            "type":        "s3",
            "location":    s3_path,
            "columns":     cols,
            "total_rows":  total_rows,
            "page":        page,
            "page_size":   page_size,
            "execution_ms": round(elapsed_ms, 2),
            "size_mb":     round(size_mb, 2),
        }
    else:
        # Inline — serialise and store in Redis
        result = {
            "type":       "inline",
            "columns":    cols,
            "total_rows": total_rows,
            "page":       page,
            "page_size":  page_size,
            "total_pages": max(1, (total_rows + page_size - 1) // page_size),
            "execution_ms": round(elapsed_ms, 2),
            "data":       rows,
        }

    return result, round(elapsed_ms, 2), total_rows


# ═══════════════════════════════════════════════════════════════════════════
# Redis key helpers (same as job_queue.py — kept independent for portability)
# ═══════════════════════════════════════════════════════════════════════════

def _k_status(jid):    return f"job:{jid}:status"
def _k_meta(jid):      return f"job:{jid}:meta"
def _k_result(jid):    return f"job:{jid}:result"
def _k_heartbeat(wid): return f"worker:{wid}:heartbeat"   # worker liveness
def _k_job_lock(jid):  return f"job:{jid}:lock"           # which worker owns this job


HEARTBEAT_INTERVAL = 5    # seconds between heartbeats
HEARTBEAT_TTL      = 20   # seconds before worker considered dead (4× interval)
WATCHDOG_INTERVAL  = 15   # seconds between watchdog scans


# ═══════════════════════════════════════════════════════════════════════════
# Heartbeat — proves this worker is still alive
# ═══════════════════════════════════════════════════════════════════════════

async def heartbeat_loop(r, worker_id: str):
    """
    Every 5 seconds, write a key to Redis with 20s TTL.
    If this worker crashes, the key expires after 20s.
    Watchdog uses this to detect dead workers.
    """
    while True:
        try:
            await r.setex(_k_heartbeat(worker_id), HEARTBEAT_TTL, "alive")
        except Exception as e:
            logger.warning("heartbeat_failed", error=str(e))
        await asyncio.sleep(HEARTBEAT_INTERVAL)


# ═══════════════════════════════════════════════════════════════════════════
# Watchdog — requeues jobs from crashed workers
# ═══════════════════════════════════════════════════════════════════════════

async def watchdog_loop(r):
    """
    Every 15 seconds, scan for jobs stuck in 'running' state
    whose worker's heartbeat has expired (worker crashed).
    Requeues them so another worker picks them up.

    WHY THIS MATTERS:
      Worker crashes mid-query
      → job:abc:status stays "running" forever
      → client polls and never sees "done" or "failed"
      → result never arrives

    WITH WATCHDOG:
      Worker crashes
      → heartbeat key expires after 20s
      → watchdog sees job:abc:lock points to dead worker
      → requeues job to original priority queue
      → another worker picks it up and re-executes
      → client eventually gets result
    """
    await asyncio.sleep(WATCHDOG_INTERVAL)  # let workers start first

    while True:
        try:
            # Find all running jobs via lock keys
            async for lock_key in r.scan_iter("job:*:lock", count=100):
                job_id    = lock_key.split(":")[1]
                worker_id = await r.get(lock_key)

                if not worker_id:
                    continue

                # Is that worker still alive?
                heartbeat = await r.get(_k_heartbeat(worker_id))
                if heartbeat is not None:
                    continue  # worker alive — all good

                # Worker is dead — check the job is actually still "running"
                status = await r.get(_k_status(job_id))
                if status != "running":
                    # Job already done/failed by the time we checked — clean up lock
                    await r.delete(lock_key)
                    continue

                # Dead worker + running job → requeue
                meta_raw = await r.get(_k_meta(job_id))
                if not meta_raw:
                    continue

                meta     = json.loads(meta_raw)
                priority = meta.get("priority", "normal")
                queue    = {
                    "high":   "jobs:high",
                    "normal": "jobs:normal",
                    "low":    "jobs:low",
                }.get(priority, "jobs:normal")

                # Reset status and requeue
                meta["status"]     = "queued"
                meta["worker_id"]  = None
                meta["started_at"] = None
                meta["requeued_at"] = time.time()
                meta["requeue_reason"] = f"worker {worker_id} heartbeat expired"

                pipe = r.pipeline()
                pipe.setex(_k_status(job_id), JOB_TTL, "queued")
                pipe.setex(_k_meta(job_id),   JOB_TTL, json.dumps(meta, default=str))
                pipe.delete(lock_key)
                pipe.lpush(queue, job_id)
                await pipe.execute()

                logger.warning(
                    "job_requeued_dead_worker",
                    job_id=job_id,
                    dead_worker=worker_id,
                    queue=queue,
                )

        except Exception as e:
            logger.error("watchdog_error", error=str(e))

        await asyncio.sleep(WATCHDOG_INTERVAL)


# ═══════════════════════════════════════════════════════════════════════════
# Main worker loop
# ═══════════════════════════════════════════════════════════════════════════

# ── Graceful shutdown ─────────────────────────────────────────────────────
# When OpenShift/Kubernetes sends SIGTERM (pod termination), we:
#   1. Stop picking up new jobs
#   2. Finish the current in-flight job
#   3. Exit cleanly — job lock expires naturally, watchdog requeues
# Without this, SIGTERM kills mid-query → job stuck in "running" forever
#   (watchdog will requeue it after 20s, but cleaner to finish it)

_shutdown_requested = False

def _handle_sigterm(signum, frame):
    global _shutdown_requested
    logger.warning("shutdown_signal_received", signal=signum)
    _shutdown_requested = True

signal.signal(signal.SIGTERM, _handle_sigterm)
signal.signal(signal.SIGINT,  _handle_sigterm)


async def run_worker():
    try:
        import redis.asyncio as aioredis
    except ImportError:
        print("ERROR: redis not installed. Run: pip install 'redis[asyncio]'")
        sys.exit(1)

    r = await aioredis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
    loop = asyncio.get_event_loop()

    logger.info(
        "worker_started",
        worker_id=WORKER_ID,
        queues=QUEUES,
        duckdb_threads=DUCKDB_THREADS,
        memory=MEMORY_LIMIT,
    )

    # Pre-warm DuckDB connection
    get_db()

    # Start heartbeat (proves this worker is alive every 5s)
    asyncio.create_task(heartbeat_loop(r, WORKER_ID))

    # Start watchdog (one per worker — only first one matters, idempotent)
    asyncio.create_task(watchdog_loop(r))

    while not _shutdown_requested:
        try:
            item = await r.brpop(QUEUES, timeout=5)
            if item is None:
                if _shutdown_requested:
                    break
                continue

            _, job_id = item

            # ── Load job metadata ─────────────────────────────────────────
            meta_raw = await r.get(_k_meta(job_id))
            if meta_raw is None:
                logger.warning("job_meta_missing", job_id=job_id)
                continue

            job = json.loads(meta_raw)

            # ── Check for cancellation ────────────────────────────────────
            status = await r.get(_k_status(job_id))
            if status == "cancelled":
                logger.info("job_skipped_cancelled", job_id=job_id)
                continue

            # ── Claim the job with a lock (watchdog uses this) ────────────
            # Lock key maps job → worker. Expires with heartbeat TTL.
            # If we crash, heartbeat expires → watchdog sees orphaned lock → requeues.
            started_at = time.time()
            job.update({
                "status":     "running",
                "worker_id":  WORKER_ID,
                "started_at": started_at,
            })
            pipe = r.pipeline()
            pipe.setex(_k_status(job_id),   JOB_TTL,        "running")
            pipe.setex(_k_meta(job_id),     JOB_TTL,        json.dumps(job))
            pipe.setex(_k_job_lock(job_id), HEARTBEAT_TTL,  WORKER_ID)   # ← lock
            await pipe.execute()

            # Keep renewing the lock while query runs
            async def _renew_lock():
                while True:
                    await asyncio.sleep(HEARTBEAT_INTERVAL)
                    still_running = await r.get(_k_status(job_id))
                    if still_running != "running":
                        break
                    await r.setex(_k_job_lock(job_id), HEARTBEAT_TTL, WORKER_ID)

            lock_renewal = asyncio.create_task(_renew_lock())

            logger.info("job_started", job_id=job_id, worker=WORKER_ID,
                        sql_preview=job["sql"][:80])

            is_export = job.get("tags", {}).get("mode") == "export"

            # ── Execute ───────────────────────────────────────────────────
            try:
                if is_export:
                    # S3 Parquet export — SELECT * allowed, writes to S3
                    from app.core.s3_exporter import s3_exporter
                    export_result = await loop.run_in_executor(
                        None, lambda: s3_exporter.export(job_id, job["sql"])
                    )
                    if export_result.error:
                        raise RuntimeError(export_result.error)
                    result     = export_result.to_response()
                    elapsed_ms = export_result.execution_s * 1000
                    total_rows = export_result.total_rows
                    finished_at = time.time()
                    job.update({
                        "status":          "done",
                        "finished_at":     finished_at,
                        "execution_ms":    round(elapsed_ms, 1),
                        "total_rows":      total_rows,
                        "result_location": export_result.s3_prefix,
                    })
                    pipe = r.pipeline()
                    pipe.setex(_k_status(job_id), JOB_TTL, "done")
                    pipe.setex(_k_meta(job_id),   JOB_TTL, json.dumps(job, default=str))
                    pipe.setex(_k_result(job_id), JOB_TTL, json.dumps(result, default=str))
                    pipe.delete(_k_job_lock(job_id))
                    await pipe.execute()

                else:
                    # Normal paginated query
                    result, elapsed_ms, total_rows = await loop.run_in_executor(
                        None, lambda: execute_query(job),
                    )
                    finished_at = time.time()
                    job.update({
                        "status":          "done",
                        "finished_at":     finished_at,
                        "execution_ms":    elapsed_ms,
                        "total_rows":      total_rows,
                        "result_location": result.get("location", "inline"),
                    })
                    import hashlib as _hl
                    _sql_hash  = _hl.sha256(
                        f"{job['sql'].strip().upper()}:{job.get('page',1)}:{job.get('page_size',1000)}".encode()
                    ).hexdigest()[:32]
                    _cache_key = f"cache:{_sql_hash}:result"
                    _cache_ttl = int(os.getenv("CACHE_TTL_SECONDS", "300"))
                    pipe = r.pipeline()
                    pipe.setex(_k_status(job_id), JOB_TTL, "done")
                    pipe.setex(_k_meta(job_id),   JOB_TTL, json.dumps(job, default=str))
                    pipe.setex(_k_result(job_id), JOB_TTL, json.dumps({"_cache_ref": _cache_key}))
                    pipe.setex(_cache_key, _cache_ttl, json.dumps(result, default=str))
                    pipe.delete(_k_job_lock(job_id))
                    await pipe.execute()

                lock_renewal.cancel()
                logger.info("job_done", job_id=job_id, worker=WORKER_ID,
                            mode="export" if is_export else "query",
                            ms=round(elapsed_ms, 1), rows=total_rows)

                if job.get("callback_url"):
                    asyncio.create_task(_call_webhook(job["callback_url"], job_id, "done"))

            except Exception as exc:
                lock_renewal.cancel()
                logger.error("job_failed", job_id=job_id, worker=WORKER_ID, error=str(exc))
                job.update({
                    "status":      "failed",
                    "finished_at": time.time(),
                    "error":       str(exc),
                })
                pipe = r.pipeline()
                pipe.setex(_k_status(job_id), JOB_TTL, "failed")
                pipe.setex(_k_meta(job_id),   JOB_TTL, json.dumps(job, default=str))
                pipe.delete(_k_job_lock(job_id))   # release lock — job failed
                await pipe.execute()

                if job.get("callback_url"):
                    asyncio.create_task(_call_webhook(job["callback_url"], job_id, "failed"))

        except Exception as exc:
            logger.error("worker_loop_error", error=str(exc), exc_info=True)
            await asyncio.sleep(1)

    logger.info("worker_shutdown_clean", worker_id=WORKER_ID)
    try:
        await r.aclose()
    except Exception:
        pass


async def _call_webhook(url: str, job_id: str, status: str):
    """Fire-and-forget HTTP callback on job completion."""
    try:
        import httpx
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(url, json={"job_id": job_id, "status": status})
    except Exception as e:
        logger.warning("webhook_failed", url=url, job_id=job_id, error=str(e))


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)

    print(f"""
╔══════════════════════════════════════════════════════╗
║  Smart Parquet Query Worker                          ║
║  ID:      {WORKER_ID:<42} ║
║  Redis:   {REDIS_URL:<42} ║
║  Queues:  {', '.join(QUEUES):<42} ║
║  DuckDB:  {DUCKDB_THREADS} threads, {MEMORY_LIMIT:<35} ║
╚══════════════════════════════════════════════════════╝
    """)

    asyncio.run(run_worker())
