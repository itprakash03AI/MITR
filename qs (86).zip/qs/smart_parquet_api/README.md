# Smart Parquet Query API — Distributed Query Engine

## What This Is

A DuckDB-powered query API that handles 100+ concurrent heavy analytical
queries by distributing work across multiple independent worker processes
via a Redis job queue.

No Spark. No Hadoop. No JVM. Just Python + DuckDB + Redis.

---

## Architecture

```
Client sends SQL
      │
      ▼
FastAPI (N replicas)        ← validates, caches, returns job_id in <5ms
      │ LPUSH
      ▼
Redis Job Queue             ← buffers 1000s of jobs, zero CPU cost
  jobs:high   ← dashboard / interactive
  jobs:normal ← standard API
  jobs:low    ← batch exports
      │ BRPOP
      ▼
DuckDB Workers (N replicas) ← each owns its DuckDB, reads Parquet/S3/Iceberg
      │
      ▼
Result → Redis (small) or S3 (large)
      │
      ▼
Client polls → gets result
```

---

## Quickstart

```bash
# 1. Sample data
python scripts/generate_sample_data.py

# 2. Start stack (Redis + 4 workers + 2 API + Nginx)
docker-compose up

# Scale workers at any time (zero downtime):
docker-compose up --scale worker=8

# 3. Submit heavy query (returns in <5ms, DuckDB not touched yet)
curl -X POST "http://localhost/api/jobs/submit?sql=SELECT+account_type,SUM(debit_amount)+FROM+read_parquet('data/tb_transactions.parquet')+GROUP+BY+1&priority=high"
# { "job_id": "abc-123", "status": "queued" }

# Poll status
curl http://localhost/api/jobs/abc-123

# Get result when done
curl http://localhost/api/jobs/abc-123/result

# 4. For fast queries — synchronous shortcut
curl "http://localhost/api/execute/sql" -d "SELECT COUNT(*) FROM read_parquet('data/tb_accounts.parquet')"
```

---

## Endpoints

### Direct DuckDB (fast, synchronous)
```
POST /api/execute/sql
GET  /api/query/{endpoint_id}
GET  /api/admin/health
GET  /api/admin/metrics
```

### Distributed jobs (async, horizontally scalable)
```
POST   /api/jobs/submit?sql=...&priority=high|normal|low
GET    /api/jobs/{job_id}
GET    /api/jobs/{job_id}/result
DELETE /api/jobs/{job_id}
POST   /api/jobs/admin/submit-batch
GET    /api/jobs/admin/queue-depths
```

### Iceberg on S3
```
GET  /api/iceberg/test-connection
GET  /api/iceberg/namespaces
POST /api/iceberg/query
```

### GraphQL
```
GET/POST /graphql
```

---

## Capacity

```
8 workers × 4 threads/query = 32 CPU threads, zero contention
80% cache hit rate (typical) → 8 workers handles 100+ req/s

Scale: docker-compose up --scale worker=16
Monitor: curl http://localhost/api/jobs/admin/queue-depths
```

---

## Configuration (.env)

```bash
DISTRIBUTED_MODE=true
REDIS_URL=redis://localhost:6379/0
LOCAL_DATA_DIR=./data
S3_ENABLED=true
S3_BUCKET=my-bucket
S3_REGION=us-east-1
ICEBERG_CATALOG_TYPE=hadoop
ICEBERG_HADOOP_WAREHOUSE=s3://bucket/warehouse
MAX_CONCURRENT_QUERIES=4
DUCKDB_THREADS=4
```

---

## Production

```bash
# API
gunicorn -c gunicorn.conf.py app.main:app

# Workers (run as many as you have CPU for)
python worker.py &
python worker.py &
python worker.py &
python worker.py &
```
