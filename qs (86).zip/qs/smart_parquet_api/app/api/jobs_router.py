# ============================================================
# app/api/jobs_router.py — Distributed query job endpoints
# ============================================================
"""
API surface for the distributed query engine.

USAGE PATTERNS
═══════════════

Pattern 1: Fire and poll (recommended for long queries)
  POST /api/jobs/submit          → { job_id: "abc-123" }
  GET  /api/jobs/abc-123         → { status: "running", ... }
  GET  /api/jobs/abc-123         → { status: "done", ... }
  GET  /api/jobs/abc-123/result  → { data: [...], meta: {...} }

Pattern 2: Fire and webhook (best for batch)
  POST /api/jobs/submit  body: { sql: "...", callback_url: "https://your-system/done" }
  → your endpoint gets called when done: { job_id, status }

Pattern 3: Wait synchronously (short queries only, max 30s)
  POST /api/jobs/submit?wait=true
  → blocks until done, returns result directly

Pattern 4: Priority queue (interactive vs batch)
  POST /api/jobs/submit  body: { sql: "...", priority: "high" }   # dashboard
  POST /api/jobs/submit  body: { sql: "...", priority: "low"  }   # nightly export
"""
from typing import Optional
import asyncio
import time

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
import json
import httpx
import structlog

from app.core.job_queue import (
    Job, JobPriority, JobStatus,
    JobQueueClient, get_job_queue,
)
from app.core.sql_analyzer import sql_analyzer
from app.core.settings import settings

logger = structlog.get_logger()

jobs_router = APIRouter(prefix="/api/jobs", tags=["⚡ Distributed Query Engine"])


# ─────────────────────────────────────────────────────────────────────────────
# Submit
# ─────────────────────────────────────────────────────────────────────────────

@jobs_router.post(
    "/submit",
    summary="Submit a query job to the distributed queue",
    description="""
## Distributed Query Submission

Submits a query to the Redis job queue. A worker process picks it up,
executes it against DuckDB + Parquet/Iceberg, and stores the result.

**Workers are fully independent** — they can run on different machines,
different containers, different Kubernetes pods.

### Priority levels

| Priority | Queue | Use for |
|---|---|---|
| `high` | jobs:high | Dashboard queries, interactive reports |
| `normal` | jobs:normal | Standard API requests (default) |
| `low` | jobs:low | Batch exports, full table scans, nightly jobs |

### Wait mode

Set `?wait=true` to block until the job completes (max 30s).
Use only for fast queries — prefer polling for anything over 1s.

### Webhooks

Set `callback_url` to get a POST to your endpoint when the job finishes:
```json
{ "job_id": "abc-123", "status": "done" }
```

### Large results

Results > 10MB are automatically written to S3 as Parquet.
The result response will contain `"type": "s3"` and a `"location"` field
with the `s3://` path for direct streaming.
""",
)
async def submit_job(
    sql: str = Query(..., description="DuckDB SQL — SELECT/WITH/EXPLAIN only"),
    priority: JobPriority = Query(default=JobPriority.NORMAL, description="Queue priority (auto-detected if not set)"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=settings.default_page_size, ge=1, le=settings.max_page_size),
    cache: bool = Query(default=True),
    wait: bool = Query(default=False, description="Block until done (max 30s)"),
    callback_url: Optional[str] = Query(default=None, description="Webhook URL on completion"),
    estimated_rows: Optional[int] = Query(default=None, description="Hint: estimated rows in source table. Used for queue routing. E.g. 9000000 for 9M row table."),
    tag_user: Optional[str] = Query(default=None),
    tag_report: Optional[str] = Query(default=None),
    queue: JobQueueClient = Depends(get_job_queue),
):
    # ── SQL analysis — checks for large-data dangers BEFORE queuing ──────
    analysis = sql_analyzer.analyze(sql, estimated_row_hint=estimated_rows)

    if not analysis.is_safe:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "SQL blocked by large-data safety guard",
                "errors":  analysis.errors,
                "hints": [
                    "Specify column names instead of SELECT *",
                    f"Max columns per query: {settings.max_columns_in_query}",
                    f"Max rows per page:     {settings.max_page_size:,}",
                    "Add WHERE clause to filter rows before they reach memory",
                    "Use pagination (page/page_size) for large result sets",
                ],
            }
        )

    # Auto-route to correct priority queue if caller didn't force one
    if priority == JobPriority.NORMAL and analysis.suggested_queue != "normal":
        priority = JobPriority(analysis.suggested_queue)

    safe_sql = analysis.safe_sql

    tags = {}
    if tag_user:   tags["user"]   = tag_user
    if tag_report: tags["report"] = tag_report

    job = Job(
        sql=safe_sql,
        priority=priority,
        page=page,
        page_size=page_size,
        cache=cache,
        tags=tags,
        callback_url=callback_url,
    )

    job_id = await queue.submit(job)

    logger.info(
        "job_submitted",
        job_id=job_id,
        priority=str(priority),
        has_select_star=analysis.has_select_star,
        suggested_queue=analysis.suggested_queue,
        has_where=analysis.has_where,
        wait=wait,
        mode="export" if tags.get("mode") == "export" else "query",
    )

    response = {
        "job_id":          job_id,
        "status":          "queued",
        "priority":        priority,
        "auto_routed":     analysis.suggested_queue != "normal",
        "warnings":        analysis.warnings,
        "analysis": {
            "has_select_star":   analysis.has_select_star,
            "estimated_columns": analysis.estimated_columns,
            "has_where":         analysis.has_where,
            "suggested_queue":   analysis.suggested_queue,
        },
        "message": f"Poll GET /api/jobs/{job_id} for status",
    }

    logger.info("job_submitted_api", job_id=job_id, priority=priority, wait=wait)

    if not wait:
        return response

    # Wait mode — poll up to 30s
    deadline = time.time() + 30
    while time.time() < deadline:
        status_data = await queue.get_status(job_id)
        if status_data and status_data.get("status") in ("done", "failed", "cancelled"):
            break
        await asyncio.sleep(0.25)

    status_data = await queue.get_status(job_id)
    if not status_data:
        raise HTTPException(status_code=500, detail="Job lost from queue")

    if status_data["status"] == "done":
        result = await queue.get_result(job_id)
        return result

    if status_data["status"] == "failed":
        raise HTTPException(status_code=500, detail=status_data.get("error", "Job failed"))

    # Still running after 30s
    return {
        "job_id":  job_id,
        "status":  status_data.get("status", "running"),
        "message": "Query is still running. Poll GET /api/jobs/{job_id}/result",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Status
# ─────────────────────────────────────────────────────────────────────────────

@jobs_router.get(
    "/{job_id}",
    summary="Get job status and metadata",
    description="""
Returns the current status and metadata for a submitted job.

**Statuses:**
- `queued` — waiting in the Redis queue for a worker
- `running` — a worker is executing the DuckDB query
- `done` — complete, call `/result` to get data
- `failed` — query error, check the `error` field
- `cancelled` — cancelled via DELETE

**Response includes:**
- `worker_id` — which worker process picked it up
- `started_at` / `finished_at` — Unix timestamps
- `wait_time_s` — how long it waited in queue before running
- `execution_ms` — DuckDB execution time
- `total_rows` — row count of full result set
""",
)
async def get_job_status(
    job_id: str,
    queue: JobQueueClient = Depends(get_job_queue),
):
    logger.debug("job_status_poll", job_id=job_id)
    data = await queue.get_status(job_id)
    if data is None:
        raise HTTPException(
            status_code=404,
            detail=f"Job '{job_id}' not found. It may have expired (TTL={settings.job_ttl_seconds}s)."
        )
    return data


# ─────────────────────────────────────────────────────────────────────────────
# Result
# ─────────────────────────────────────────────────────────────────────────────

@jobs_router.get(
    "/{job_id}/result",
    summary="Fetch query result",
    description="""
Returns the query result once the job status is `done`.

### Small results (< 10MB)
Returned inline as JSON:
```json
{
  "type": "inline",
  "columns": ["account_id", "debit_amount", ...],
  "total_rows": 5000,
  "page": 1,
  "page_size": 1000,
  "data": [{"account_id": "ACC-001", ...}, ...]
}
```

### Large results (> 10MB)
Worker writes Parquet to S3. Response contains the path:
```json
{
  "type": "s3",
  "location": "s3://my-bucket/query-results/abc-123/result.parquet",
  "columns": [...],
  "total_rows": 500000,
  "size_mb": 42.3
}
```
Client reads directly from S3 — no API bottleneck on large data.
""",
)
async def get_job_result(
    job_id: str,
    queue: JobQueueClient = Depends(get_job_queue),
):
    logger.info("job_result_fetch", job_id=job_id)
    status_data = await queue.get_status(job_id)
    if status_data is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found")

    status = status_data.get("status")
    if status == "failed":
        raise HTTPException(
            status_code=500,
            detail=f"Job failed: {status_data.get('error', 'unknown error')}"
        )
    if status == "cancelled":
        raise HTTPException(status_code=410, detail="Job was cancelled")
    if status in ("queued", "running"):
        raise HTTPException(
            status_code=202,
            detail=f"Job is still {status}. Retry after a moment.",
            headers={"Retry-After": "1"},
        )

    result = await queue.get_result(job_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Result not found (may have expired)")

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Cancel
# ─────────────────────────────────────────────────────────────────────────────

@jobs_router.delete(
    "/{job_id}",
    summary="Cancel a queued job",
    description="Marks the job cancelled. If it hasn't started yet, the worker will skip it.",
)
async def cancel_job(
    job_id: str,
    queue: JobQueueClient = Depends(get_job_queue),
):
    logger.info("job_cancel_request", job_id=job_id)
    ok = await queue.cancel(job_id)
    if not ok:
        status_data = await queue.get_status(job_id)
        status = status_data.get("status") if status_data else "not found"
        raise HTTPException(
            status_code=409,
            detail=f"Cannot cancel job with status '{status}'"
        )
    return {"job_id": job_id, "status": "cancelled"}


# ─────────────────────────────────────────────────────────────────────────────
# Queue admin
# ─────────────────────────────────────────────────────────────────────────────

@jobs_router.get(
    "/admin/queue-depths",
    summary="How many jobs are waiting in each queue",
)
async def queue_depths(queue: JobQueueClient = Depends(get_job_queue)):
    depths = await queue.queue_depths()
    total  = sum(depths.values())
    return {
        **depths,
        "total": total,
        "recommendation": (
            "Healthy" if total < 50 else
            "High load — consider scaling workers" if total < 200 else
            "Critical — scale workers immediately"
        ),
    }


@jobs_router.get(
    "/admin/memory",
    summary="Redis memory usage and cache stats",
    description="""
Shows exactly how much memory the job queue and result cache are using in Redis.

**cache_stats.cached_unique_results** — number of unique SQL results stored.
  50 jobs ran same SQL → still only 1 result stored here.

**cache_stats.estimated_mb** — how much Redis memory the results use.

**redis_used_mb** — total Redis memory. Should stay well under redis_max_mb.
  If approaching limit, either:
  - Lower CACHE_TTL_SECONDS (results expire sooner)
  - Lower RESULT_SIZE_THRESHOLD_MB (push large results to S3 sooner)
  - Increase Redis maxmemory
""",
)
async def memory_stats(queue: JobQueueClient = Depends(get_job_queue)):
    cache   = await queue.cache_stats()
    memory  = await queue.memory_usage()
    return {
        "cache_stats":  cache,
        "redis_memory": memory,
        "tuning_tips": {
            "reduce_cache_size": "Lower CACHE_TTL_SECONDS (default 300s)",
            "reduce_result_size": "Lower RESULT_SIZE_THRESHOLD_MB to push more to S3",
            "current_threshold_mb": settings.result_size_threshold_mb,
            "current_ttl_s": settings.cache_ttl_seconds,
        },
    }


@jobs_router.get(
    "/admin/list",
    summary="List recent jobs",
    description="Returns up to 50 recent jobs with their status.",
)
async def list_jobs(
    limit: int = Query(default=50, ge=1, le=200),
    queue: JobQueueClient = Depends(get_job_queue),
):
    jobs = await queue.list_jobs(limit=limit)
    return {
        "total": len(jobs),
        "jobs":  jobs,
    }


@jobs_router.post(
    "/admin/submit-batch",
    summary="Submit multiple jobs at once",
    description="""
Submit a list of SQL queries as a batch. All go to the `low` priority queue.
Returns a list of job IDs to poll.

Request body:
```json
[
  { "sql": "SELECT ...", "tags": {"report": "tb_2024"} },
  { "sql": "SELECT ...", "tags": {"report": "pl_2024"} }
]
```
""",
)
async def submit_batch(
    jobs_payload: list,
    queue: JobQueueClient = Depends(get_job_queue),
):
    submitted = []
    for item in jobs_payload[:50]:   # max 50 at once
        sql  = item.get("sql", "")
        tags = item.get("tags", {})
        if not sql.strip().upper().startswith(("SELECT", "WITH")):
            submitted.append({"error": "invalid SQL", "sql_preview": sql[:60]})
            continue
        job    = Job(sql=sql, priority=JobPriority.LOW, tags=tags)
        job_id = await queue.submit(job)
        submitted.append({"job_id": job_id, "status": "queued", "tags": tags})

    return {"submitted": len(submitted), "jobs": submitted}
