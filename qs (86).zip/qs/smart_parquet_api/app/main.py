# ============================================================
# app/main.py — Application factory
# ============================================================
from contextlib import asynccontextmanager
from typing import AsyncIterator

import structlog
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.core.config_loader import registry
from app.core.database import db_pool
from app.core.logging import setup_logging
from app.core.middleware import register_middleware
from app.core.settings import settings
from app.api.router import admin_router, query_router, generic_router, iceberg_router, register_all_endpoints
from app.api.jobs_router import jobs_router
from app.api.stream_router import stream_router

# GraphQL is optional — app starts fine without strawberry-graphql installed
try:
    from app.api.graphql_schema import graphql_router
    _graphql_available = True
except ImportError:
    graphql_router = None
    _graphql_available = False

logger = structlog.get_logger()


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    # ── Startup ──────────────────────────────────────────────
    setup_logging()
    logger.info("app_starting", name=settings.app_name, version=settings.app_version)

    # Initialise DuckDB connection pool
    db_pool.initialize()

    logger.info("app_ready", endpoints=len(registry.all()))
    yield

    # ── Shutdown ─────────────────────────────────────────────
    db_pool.shutdown()
    logger.info("app_shutdown")


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="""
## Smart Parquet Query API

Enterprise-grade, config-driven API for querying Parquet files on **local disk**
or **Amazon S3** using **DuckDB** as the embedded analytical engine.

📖 **[Full User Guide](/guide)** &nbsp;|&nbsp; 📚 **[Technical Docs](/redoc)**

### Features
- 🗂  **Config-driven endpoints** — all queries live in `config/queries.yaml`
- ⚡  **DuckDB** — vectorised query engine; sub-second on large Parquet files
- ☁️  **S3 + local** — transparent source routing per endpoint
- 📄  **Pagination** — `page` + `pageSize` on every endpoint
- 🗃  **Result cache** — TTL-based in-memory cache
- 🌊  **Streaming** — NDJSON streaming for huge result sets
- 🔍  **EXPLAIN** — query plan endpoint for debugging
- 🧊  **Apache Iceberg** — metadata resolution + schema evolution
- 📦  **S3 Parquet export** — partitioned export with presigned URLs
- 🔗  **GraphQL** — Strawberry schema with column pushdown + subscriptions
        """,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # ── Middleware + error handlers ───────────────────────────
    app.add_middleware(GZipMiddleware, minimum_size=1024)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    register_middleware(app)   # request_id, access log, api_key, global error handler

    # ── Load config-driven endpoints before including the router ──
    registry.load()
    register_all_endpoints(query_router)

    # ── Routers ───────────────────────────────────────────────
    app.include_router(admin_router)
    app.include_router(generic_router)
    app.include_router(iceberg_router)
    app.include_router(query_router)
    app.include_router(jobs_router)
    app.include_router(stream_router)
    if _graphql_available and graphql_router is not None:
        app.include_router(graphql_router, prefix="/graphql")
        logger.info("graphql_enabled", path="/graphql")

    # ── User guide ───────────────────────────────────────────
    import os
    from fastapi.responses import FileResponse, HTMLResponse

    docs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "docs")
    guide_path = os.path.join(docs_dir, "user_guide.html")

    @app.get("/guide", include_in_schema=False)
    async def user_guide():
        if os.path.isfile(guide_path):
            return FileResponse(guide_path, media_type="text/html")
        return HTMLResponse("<h2>User guide not found.</h2>", status_code=404)

    # Serve remaining static docs assets (if any CSS/JS added later)
    if os.path.isdir(docs_dir):
        app.mount("/docs-static", StaticFiles(directory=docs_dir), name="docs-static")

    # Root redirect to docs
    @app.get("/", include_in_schema=False)
    async def root():
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/docs")

    return app


# ── Entry point ───────────────────────────────────────────────────────────────
app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        workers=1,          # use 1 for dev; set workers in gunicorn for prod
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )
