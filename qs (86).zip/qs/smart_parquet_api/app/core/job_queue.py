# ============================================================
# app/core/job_queue.py — Distributed query job queue (Redis)
# ============================================================
"""
REDIS MEMORY LAYOUT — EXACTLY WHAT IS STORED
══════════════════════════════════════════════

Key pattern              Size          TTL        Purpose
────────────────────     ─────         ───        ───────
job:{id}:status          ~20 bytes     1 hour     "queued/running/done/failed"
job:{id}:meta            ~1 KB         1 hour     sql, timestamps, worker_id, tags
job:{id}:result          pointer only  1 hour     points to cache:{sql_hash}:result
cache:{sql_hash}:result  actual data   5 min      SHARED result across all jobs with same SQL
jobs:high                list          forever    queue of job_ids
jobs:normal              list          forever    queue of job_ids
jobs:low                 list          forever    queue of job_ids
worker:{id}:heartbeat    ~10 bytes     20 sec     liveness (expires if worker crashes)
job:{id}:lock            ~20 bytes     20 sec     which worker owns this job

KEY INSIGHT — SHARED RESULT CACHE
════════════════════════════════════
50 jobs all run: SELECT COUNT(*) FROM tb_accounts

Without shared cache:
  50 jobs × result stored per job = 50 copies of same data in Redis

With shared cache:
  Job 1 runs → stores result at cache:{hash}:result
  Jobs 2-50  → cache hit at submit time → return instantly, never touch DuckDB
               Each job:result points to cache:{hash}:result
               Redis stores the data ONCE regardless of how many jobs ran it

MEMORY ESTIMATE FOR 100 CONCURRENT REQUESTS
═════════════════════════════════════════════
  Assume 80% cache hit rate (realistic for dashboards):
    100 requests → 20 unique queries execute
    20 results × 1MB each = 20MB in Redis (unique results)
    80 cache hits × ~1KB metadata = 80KB (just pointers)
    Total: ~20MB for 100 requests

  Worst case (all unique, all 1MB results):
    100 × 1MB = 100MB in Redis

  Large results (>10MB threshold) → go to S3 automatically:
    Redis stores only: { "type": "s3", "location": "s3://..." } = ~200 bytes
    Actual data in S3 Parquet

  Redis maxmemory=2GB with allkeys-lru:
    Evicts oldest results when full — safe, jobs still complete
    Result just won't be cached on second call

RESULT STORAGE DECISION TREE (per query result)
═════════════════════════════════════════════════
  Result size < RESULT_SIZE_THRESHOLD_MB (default 10MB)?
    YES → store JSON inline in Redis
    NO  → worker writes Parquet to S3
          Redis stores { "type": "s3", "location": "s3://..." }
          Client reads from S3 directly (no API memory pressure)
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from enum import Enum
from typing import Any, Dict, List, Optional

import structlog

from app.core.settings import settings

logger = structlog.get_logger()


# ═══════════════════════════════════════════════════════════════════════════
# Job model
# ═══════════════════════════════════════════════════════════════════════════

class JobStatus(str, Enum):
    SUBMITTED  = "submitted"
    QUEUED     = "queued"
    RUNNING    = "running"
    DONE       = "done"
    FAILED     = "failed"
    CANCELLED  = "cancelled"


class JobPriority(str, Enum):
    HIGH   = "high"
    NORMAL = "normal"
    LOW    = "low"


class Job:
    def __init__(
        self,
        sql:          str,
        priority:     JobPriority = JobPriority.NORMAL,
        page:         int = 1,
        page_size:    int = 1000,
        cache:        bool = True,
        tags:         Optional[Dict[str, str]] = None,
        callback_url: Optional[str] = None,
    ):
        self.job_id       = str(uuid.uuid4())
        self.sql          = sql
        self.sql_hash     = _sql_hash(sql, page, page_size)   # for shared cache lookup
        self.priority     = priority
        self.page         = page
        self.page_size    = page_size
        self.cache        = cache
        self.tags         = tags or {}
        self.callback_url = callback_url
        self.submitted_at = time.time()
        self.status       = JobStatus.SUBMITTED

    def to_redis_payload(self) -> str:
        return json.dumps({
            "job_id":       self.job_id,
            "sql":          self.sql,
            "sql_hash":     self.sql_hash,
            "priority":     self.priority,
            "page":         self.page,
            "page_size":    self.page_size,
            "cache":        self.cache,
            "tags":         self.tags,
            "callback_url": self.callback_url,
            "submitted_at": self.submitted_at,
            "status":       self.status,
        })

    def to_status_dict(self) -> Dict:
        return {
            "job_id":       self.job_id,
            "status":       self.status,
            "priority":     self.priority,
            "submitted_at": self.submitted_at,
            "sql_preview":  self.sql[:200],
            "tags":         self.tags,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Redis key schema — all in one place
# ═══════════════════════════════════════════════════════════════════════════

def _key_status(job_id: str)   -> str: return f"job:{job_id}:status"
def _key_meta(job_id: str)     -> str: return f"job:{job_id}:meta"
def _key_result(job_id: str)   -> str: return f"job:{job_id}:result"
def _key_cache(sql_hash: str)  -> str: return f"cache:{sql_hash}:result"   # SHARED across jobs
def _key_queue(priority: JobPriority) -> str:
    return {
        JobPriority.HIGH:   settings.queue_high,
        JobPriority.NORMAL: settings.queue_normal,
        JobPriority.LOW:    settings.queue_low,
    }[priority]

def _sql_hash(sql: str, page: int, page_size: int) -> str:
    """Deterministic key for a unique (sql, page, page_size) combination."""
    return hashlib.sha256(
        f"{sql.strip().upper()}:{page}:{page_size}".encode()
    ).hexdigest()[:32]


# ═══════════════════════════════════════════════════════════════════════════
# Queue client
# ═══════════════════════════════════════════════════════════════════════════

class JobQueueClient:

    def __init__(self):
        self._redis = None

    async def _get_redis(self):
        if self._redis is None:
            try:
                import redis.asyncio as aioredis
            except ImportError:
                raise RuntimeError("Run: pip install 'redis[asyncio]'")
            self._redis = await aioredis.from_url(
                settings.redis_url,
                encoding="utf-8",
                decode_responses=True,
            )
        return self._redis

    # ─────────────────────────────────────────────────────────────────────
    # Submit — cache check happens HERE before queuing
    # ─────────────────────────────────────────────────────────────────────

    async def submit(self, job: Job) -> str:
        """
        Submit a job.

        If cache=True and an identical query result exists in Redis shared cache:
          → mark job as DONE immediately, point to cached result
          → DuckDB never involved, worker never involved
          → returns in <5ms

        Otherwise:
          → push to priority queue
          → worker picks up, executes, stores result in shared cache
        """
        r = await self._get_redis()

        # ── Shared cache check ────────────────────────────────────────────
        if job.cache and settings.cache_enabled:
            cached = await r.get(_key_cache(job.sql_hash))
            if cached is not None:
                # Cache hit — complete this job immediately, no worker needed
                logger.info(
                    "job_cache_hit",
                    job_id=job.job_id,
                    sql_hash=job.sql_hash[:12],
                )
                pipe = r.pipeline()
                pipe.setex(
                    _key_meta(job.job_id),
                    settings.job_ttl_seconds,
                    json.dumps({
                        **json.loads(job.to_redis_payload()),
                        "status":       "done",
                        "started_at":   job.submitted_at,
                        "finished_at":  job.submitted_at,
                        "execution_ms": 0,
                        "cache_hit":    True,
                    })
                )
                pipe.setex(_key_status(job.job_id), settings.job_ttl_seconds, "done")
                # Point to the shared cache result (not a copy — just a pointer)
                pipe.setex(
                    _key_result(job.job_id),
                    settings.job_ttl_seconds,
                    json.dumps({"_cache_ref": _key_cache(job.sql_hash)})
                )
                await pipe.execute()
                return job.job_id

        # ── No cache hit — queue for worker ───────────────────────────────
        queue = _key_queue(job.priority)
        pipe  = r.pipeline()
        pipe.setex(_key_meta(job.job_id),    settings.job_ttl_seconds, job.to_redis_payload())
        pipe.setex(_key_status(job.job_id),  settings.job_ttl_seconds, JobStatus.QUEUED)
        pipe.lpush(queue, job.job_id)
        await pipe.execute()

        logger.info(
            "job_queued",
            job_id=job.job_id,
            queue=queue,
            priority=job.priority,
            sql_hash=job.sql_hash[:12],
        )
        return job.job_id

    # ─────────────────────────────────────────────────────────────────────
    # Status
    # ─────────────────────────────────────────────────────────────────────

    async def get_status(self, job_id: str) -> Optional[Dict]:
        r        = await self._get_redis()
        meta_raw = await r.get(_key_meta(job_id))
        if meta_raw is None:
            return None
        meta   = json.loads(meta_raw)
        status = await r.get(_key_status(job_id))
        if status:
            meta["status"] = status
        return meta

    # ─────────────────────────────────────────────────────────────────────
    # Result — resolves cache pointer if needed
    # ─────────────────────────────────────────────────────────────────────

    async def get_result(self, job_id: str) -> Optional[Dict]:
        """
        Fetch result for a done job.
        Follows cache pointer if result is shared (multiple jobs, same SQL).
        """
        r      = await self._get_redis()
        status = await r.get(_key_status(job_id))
        if status != JobStatus.DONE:
            return None

        result_raw = await r.get(_key_result(job_id))
        if result_raw is None:
            return None

        result = json.loads(result_raw)

        # Follow cache pointer if this job's result points to shared cache
        if "_cache_ref" in result:
            shared_raw = await r.get(result["_cache_ref"])
            if shared_raw is None:
                # Shared cache expired — caller should resubmit
                return None
            result = json.loads(shared_raw)
            result["cache_hit"] = True

        return result

    # ─────────────────────────────────────────────────────────────────────
    # Cancel
    # ─────────────────────────────────────────────────────────────────────

    async def cancel(self, job_id: str) -> bool:
        r      = await self._get_redis()
        status = await r.get(_key_status(job_id))
        if status in (JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED):
            return False
        await r.setex(_key_status(job_id), settings.job_ttl_seconds, JobStatus.CANCELLED)
        return True

    # ─────────────────────────────────────────────────────────────────────
    # Admin
    # ─────────────────────────────────────────────────────────────────────

    async def queue_depths(self) -> Dict[str, int]:
        r = await self._get_redis()
        return {
            "high":   await r.llen(settings.queue_high),
            "normal": await r.llen(settings.queue_normal),
            "low":    await r.llen(settings.queue_low),
        }

    async def cache_stats(self) -> Dict:
        """How many unique results are cached in Redis."""
        r     = await self._get_redis()
        count = 0
        total_bytes = 0
        async for key in r.scan_iter("cache:*:result", count=100):
            count += 1
            val = await r.get(key)
            if val:
                total_bytes += len(val.encode())
        return {
            "cached_unique_results": count,
            "estimated_mb":          round(total_bytes / 1_048_576, 2),
            "cache_ttl_seconds":     settings.cache_ttl_seconds,
        }

    async def memory_usage(self) -> Dict:
        """Estimate total Redis memory used by this API."""
        r = await self._get_redis()
        info = await r.info("memory")
        return {
            "redis_used_mb":     round(info["used_memory"] / 1_048_576, 1),
            "redis_peak_mb":     round(info["used_memory_peak"] / 1_048_576, 1),
            "redis_max_mb":      round(info.get("maxmemory", 0) / 1_048_576, 1) or "unlimited",
            "eviction_policy":   info.get("maxmemory_policy", "unknown"),
        }

    async def list_jobs(self, limit: int = 50) -> List[Dict]:
        r    = await self._get_redis()
        jobs = []
        async for key in r.scan_iter("job:*:meta", count=100):
            raw = await r.get(key)
            if raw:
                jobs.append(json.loads(raw))
        jobs.sort(key=lambda j: j.get("submitted_at", 0), reverse=True)
        return jobs[:limit]

    async def close(self):
        if self._redis:
            await self._redis.aclose()


# ═══════════════════════════════════════════════════════════════════════════
# Worker-side helper — called by worker.py to store result in shared cache
# ═══════════════════════════════════════════════════════════════════════════

def make_cache_key(sql: str, page: int, page_size: int) -> str:
    return _key_cache(_sql_hash(sql, page, page_size))


# Singleton
job_queue_client = JobQueueClient()

async def get_job_queue() -> JobQueueClient:
    return job_queue_client
