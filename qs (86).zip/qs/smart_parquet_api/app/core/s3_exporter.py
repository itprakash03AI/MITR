# ============================================================
# app/core/s3_exporter.py  —  S3 Parquet export for huge results
# ============================================================
"""
WHAT THIS SOLVES
═════════════════
  9M rows × 1000 columns = 72GB source
  Aggregation result     = could be 500k groups × 50 cols = still huge

  Cannot stream as JSON — 180GB of text
  Cannot store in Redis — would exhaust memory
  Cannot return as single file — 5-20GB download

  Solution: Write as partitioned Parquet directly to S3
  DuckDB writes part-000.parquet, part-001.parquet, ...
  Each part is 200-500MB — manageable
  Client gets presigned URLs → downloads in parallel

HOW DUCKDB WRITES TO S3
════════════════════════
  DuckDB's httpfs extension supports direct S3 writes:

  COPY (SELECT ...) TO 's3://bucket/prefix/'
  (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE, ROW_GROUP_SIZE 100000)

  PER_THREAD_OUTPUT TRUE  →  each DuckDB thread writes its own part file
                              4 threads = 4 part files in parallel
                              No single-file bottleneck

  ROW_GROUP_SIZE 100000   →  controls granularity inside each Parquet file
                              Smaller = better predicate pushdown when reading back
                              Larger = better compression

OUTPUT STRUCTURE IN S3
═══════════════════════
  s3://your-bucket/exports/job-abc-123/
    part-0.parquet     (500MB)
    part-1.parquet     (500MB)
    part-2.parquet     (500MB)
    part-3.parquet     (500MB)
    _metadata.json     (schema, row counts, presigned URLs)

  Total: ~2GB compressed Parquet vs 72GB JSON
  Compression ratio: 30-50× for financial/analytical data

PRESIGNED URL FLOW
═══════════════════
  Worker writes parts to S3
  API generates presigned URL for each part (valid 4 hours)
  Client receives:
  {
    "export_id":    "job-abc-123",
    "total_rows":   9000000,
    "part_count":   4,
    "parts": [
      {
        "part":         0,
        "rows":         2250000,
        "size_mb":      487.3,
        "url":          "https://s3.amazonaws.com/bucket/exports/...",
        "expires_at":   "2024-01-15T18:00:00Z"
      },
      ...
    ],
    "read_all_pandas":  "pd.read_parquet('s3://bucket/exports/job-abc-123/')",
    "read_all_duckdb":  "SELECT * FROM read_parquet('s3://bucket/exports/job-abc-123/*.parquet')"
  }

  Client can:
  1. Download each URL directly (wget, curl, browser)
  2. Read with pandas:  pd.read_parquet(presigned_url)
  3. Read with DuckDB:  read_parquet('s3://bucket/exports/job-abc-123/*.parquet')
  4. Pass to BI tool:   Tableau/PowerBI support presigned S3 URLs
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

import duckdb
import structlog

from app.core.settings import settings

logger = structlog.get_logger()


# ═══════════════════════════════════════════════════════════════════════════
# Export result model
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ExportPart:
    part:       int
    s3_key:     str
    s3_path:    str           # s3://bucket/key
    size_bytes: int = 0
    row_count:  int = 0
    presigned_url: Optional[str] = None
    expires_at: Optional[str]    = None


@dataclass
class ExportResult:
    job_id:      str
    s3_prefix:   str          # s3://bucket/exports/job-id/
    total_rows:  int          = 0
    total_bytes: int          = 0
    part_count:  int          = 0
    execution_s: float        = 0.0
    parts:       List[ExportPart] = field(default_factory=list)
    columns:     List[str]    = field(default_factory=list)
    error:       Optional[str]= None

    def to_response(self) -> Dict:
        total_mb = round(self.total_bytes / 1_048_576, 1)
        return {
            "export_id":    self.job_id,
            "status":       "ready" if not self.error else "failed",
            "total_rows":   self.total_rows,
            "total_mb":     total_mb,
            "part_count":   self.part_count,
            "columns":      self.columns,
            "execution_s":  round(self.execution_s, 1),
            "s3_prefix":    self.s3_prefix,
            "parts": [
                {
                    "part":        p.part,
                    "size_mb":     round(p.size_bytes / 1_048_576, 1),
                    "row_count":   p.row_count,
                    "url":         p.presigned_url,
                    "expires_at":  p.expires_at,
                    "s3_path":     p.s3_path,
                }
                for p in self.parts
            ],
            "how_to_read": {
                "pandas":    f"pd.read_parquet('{self.s3_prefix}')",
                "duckdb":    f"SELECT * FROM read_parquet('{self.s3_prefix}*.parquet')",
                "direct_dl": "Use the presigned 'url' field for each part",
                "note":      f"Presigned URLs expire in {settings.export_presigned_url_ttl // 3600} hours",
            },
            "error": self.error,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Exporter
# ═══════════════════════════════════════════════════════════════════════════

class S3Exporter:
    """
    Runs inside a worker process.
    Uses DuckDB COPY TO S3 to write partitioned Parquet.
    Then generates presigned URLs via boto3.
    """

    def export(self, job_id: str, sql: str) -> ExportResult:
        """
        Execute SQL and write result to S3 as partitioned Parquet.
        Returns ExportResult with presigned URLs for each part.

        This runs synchronously inside a worker thread — can take minutes for 9M rows.
        Progress is visible in worker logs.
        """
        if not settings.s3_enabled or not settings.s3_bucket:
            raise RuntimeError(
                "S3 export requires S3_ENABLED=true and S3_BUCKET to be set. "
                "Set these env vars and restart the worker."
            )

        s3_prefix = (
            f"s3://{settings.s3_bucket}/"
            f"{settings.s3_export_prefix}/{job_id}/"
        )
        result = ExportResult(job_id=job_id, s3_prefix=s3_prefix)

        t0 = time.perf_counter()

        conn = self._make_conn()
        try:
            logger.info("export_starting", job_id=job_id, s3_prefix=s3_prefix)

            # ── Step 1: Count rows so we can log progress ─────────────────
            # Wrap in try — count might be slow on 9M rows, not critical
            try:
                total_rows = conn.execute(
                    f"SELECT COUNT(*) FROM ({sql}) __c__"
                ).fetchone()[0]
                result.total_rows = total_rows
                logger.info("export_row_count", job_id=job_id, rows=total_rows)
            except Exception:
                result.total_rows = 0  # unknown — will be filled after write

            # ── Step 2: Get column list ────────────────────────────────────
            sample = conn.execute(f"SELECT * FROM ({sql}) __s__ LIMIT 0")
            result.columns = [d[0] for d in sample.description]

            # ── Step 3: COPY to S3 as partitioned Parquet ──────────────────
            # PER_THREAD_OUTPUT TRUE  → one file per DuckDB thread (parallel write)
            # ROW_GROUP_SIZE          → row groups inside each file
            # COMPRESSION SNAPPY      → good balance: fast + compressed
            copy_sql = f"""
            COPY (
                {sql}
            ) TO '{s3_prefix}'
            (
                FORMAT          PARQUET,
                PER_THREAD_OUTPUT TRUE,
                ROW_GROUP_SIZE  {settings.export_row_group_size},
                COMPRESSION     SNAPPY
            )
            """
            logger.info("export_copy_start", job_id=job_id)
            conn.execute(copy_sql)
            logger.info("export_copy_done", job_id=job_id)

        except Exception as exc:
            result.error = str(exc)
            logger.error("export_failed", job_id=job_id, error=str(exc))
            return result
        finally:
            try:
                conn.close()
            except Exception:
                pass

        # ── Step 4: List written files + generate presigned URLs ──────────
        try:
            result.parts = self._list_and_sign(
                bucket     = settings.s3_bucket,
                prefix_key = f"{settings.s3_export_prefix}/{job_id}/",
                s3_prefix  = s3_prefix,
            )
            result.part_count  = len(result.parts)
            result.total_bytes = sum(p.size_bytes for p in result.parts)

            if result.total_rows == 0:
                # Fallback: sum row counts from metadata if count query was skipped
                result.total_rows = sum(p.row_count for p in result.parts)

        except Exception as exc:
            logger.warning("export_sign_failed", job_id=job_id, error=str(exc))
            result.error = f"Written to S3 but presigned URLs failed: {exc}"

        result.execution_s = time.perf_counter() - t0
        logger.info(
            "export_complete",
            job_id=job_id,
            parts=result.part_count,
            total_mb=round(result.total_bytes / 1_048_576, 1),
            elapsed_s=round(result.execution_s, 1),
        )
        return result

    # ─────────────────────────────────────────────────────────────────────
    # List S3 parts + generate presigned URLs
    # ─────────────────────────────────────────────────────────────────────

    def _list_and_sign(
        self,
        bucket:     str,
        prefix_key: str,
        s3_prefix:  str,
    ) -> List[ExportPart]:
        """List exported Parquet parts in S3 and generate presigned URLs."""
        try:
            import boto3
            from botocore.exceptions import ClientError
            from datetime import datetime, timezone, timedelta
        except ImportError:
            raise RuntimeError("boto3 not installed. Run: pip install boto3")

        s3 = boto3.client(
            "s3",
            region_name          = settings.s3_region,
            aws_access_key_id    = settings.aws_access_key_id,
            aws_secret_access_key= settings.aws_secret_access_key,
            aws_session_token    = settings.aws_session_token,
            endpoint_url         = settings.s3_endpoint_url or None,
        )

        # List all .parquet files under the export prefix
        paginator = s3.get_paginator("list_objects_v2")
        pages     = paginator.paginate(Bucket=bucket, Prefix=prefix_key)

        parts = []
        idx   = 0
        expires_dt = (
            datetime.now(timezone.utc)
            + timedelta(seconds=settings.export_presigned_url_ttl)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")

        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if not key.endswith(".parquet"):
                    continue

                # Generate presigned URL
                try:
                    url = s3.generate_presigned_url(
                        "get_object",
                        Params    = {"Bucket": bucket, "Key": key},
                        ExpiresIn = settings.export_presigned_url_ttl,
                    )
                except ClientError as e:
                    logger.warning("presign_failed", key=key, error=str(e))
                    url = None

                # Try to get row count from Parquet metadata
                row_count = self._get_parquet_row_count(s3, bucket, key)

                parts.append(ExportPart(
                    part        = idx,
                    s3_key      = key,
                    s3_path     = f"s3://{bucket}/{key}",
                    size_bytes  = obj["Size"],
                    row_count   = row_count,
                    presigned_url = url,
                    expires_at  = expires_dt,
                ))
                idx += 1

        parts.sort(key=lambda p: p.s3_key)
        return parts

    def _get_parquet_row_count(self, s3_client, bucket: str, key: str) -> int:
        """Read row count from Parquet file footer metadata."""
        try:
            import pyarrow.parquet as pq
            import io
            # Only read the footer (last 8+ bytes) — not the full file
            obj   = s3_client.get_object(Bucket=bucket, Key=key)
            data  = obj["Body"].read()
            pf    = pq.ParquetFile(io.BytesIO(data))
            return pf.metadata.num_rows
        except Exception:
            return 0   # not critical

    def _make_conn(self) -> duckdb.DuckDBPyConnection:
        import os
        os.makedirs(settings.duckdb_temp_dir, exist_ok=True)
        conn = duckdb.connect(":memory:")
        conn.execute(f"SET threads TO {settings.duckdb_threads}")
        conn.execute(f"SET memory_limit='{settings.duckdb_memory_limit}'")
        conn.execute(f"SET temp_directory='{settings.duckdb_temp_dir}'")
        conn.execute("SET enable_progress_bar=false")
        conn.execute("INSTALL httpfs; LOAD httpfs")
        conn.execute(f"SET s3_region='{settings.s3_region}'")
        if settings.aws_access_key_id:
            conn.execute(f"SET s3_access_key_id='{settings.aws_access_key_id}'")
        if settings.aws_secret_access_key:
            conn.execute(f"SET s3_secret_access_key='{settings.aws_secret_access_key}'")
        if settings.aws_session_token:
            conn.execute(f"SET s3_session_token='{settings.aws_session_token}'")
        if settings.s3_endpoint_url:
            conn.execute(f"SET s3_endpoint='{settings.s3_endpoint_url}'")
            conn.execute("SET s3_use_ssl=false; SET s3_url_style='path'")
        return conn


# Singleton used by worker.py
s3_exporter = S3Exporter()
