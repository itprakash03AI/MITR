# ============================================================
# app/core/sql_analyzer.py — Large-data SQL safety layer
# ============================================================
"""
WHY THIS EXISTS
════════════════
With 9M rows × 1000 columns, a single careless query can:
  SELECT *  →  DuckDB reads 72GB from S3
  No WHERE   →  full table scan, 9M rows in result
  Too many cols → result JSON too large for Redis, API, client

This module inspects SQL BEFORE DuckDB runs it and either:
  - Blocks it with a clear error message
  - Rewrites it safely (adds LIMIT, strips trailing *)
  - Routes it to the correct priority queue based on estimated size
  - Warns the caller about what it detected

WHAT IT CHECKS
═══════════════
  1. SELECT * detection          → block or rewrite
  2. Column count estimation     → block if > MAX_COLUMNS
  3. Missing WHERE on large table → warn / block
  4. Missing LIMIT               → auto-inject LIMIT
  5. Estimated result rows       → route to correct queue
  6. Dangerous patterns          → block (COPY, INSTALL, etc.)

COLUMN PRUNING (how DuckDB avoids reading 1000 cols)
══════════════════════════════════════════════════════
  SELECT a, b, c FROM read_parquet('big.parquet')
    → DuckDB reads ONLY columns a, b, c from the Parquet file
    → Other 997 columns never touched on disk or in memory
    → This is why forcing explicit column names is critical

  SELECT * FROM read_parquet('big.parquet')
    → DuckDB reads ALL 1000 columns
    → Even a simple COUNT(*) on a 1000-col file is slower
    → Avoid completely for large files
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from app.core.settings import settings


# ═══════════════════════════════════════════════════════════════════════════
# Analysis result
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SQLAnalysis:
    original_sql:      str
    safe_sql:          str          # possibly rewritten SQL
    is_safe:           bool
    errors:            List[str]    = field(default_factory=list)   # hard blocks
    warnings:          List[str]    = field(default_factory=list)   # soft warnings
    has_select_star:   bool         = False
    estimated_columns: Optional[int] = None
    has_where:         bool         = True
    has_limit:         bool         = True
    limit_value:       Optional[int] = None
    suggested_queue:   str          = "normal"   # high / normal / low
    estimated_row_hint: Optional[int] = None     # from caller hint

    def to_dict(self):
        return {
            "is_safe":           self.is_safe,
            "errors":            self.errors,
            "warnings":          self.warnings,
            "has_select_star":   self.has_select_star,
            "estimated_columns": self.estimated_columns,
            "has_where":         self.has_where,
            "has_limit":         self.has_limit,
            "limit_value":       self.limit_value,
            "suggested_queue":   self.suggested_queue,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Analyser
# ═══════════════════════════════════════════════════════════════════════════

class SQLAnalyzer:

    # Patterns we always block regardless of context
    _BLOCK_PATTERNS = [
        (r"\bCOPY\b",        "COPY is not allowed"),
        (r"\bEXPORT\b",      "EXPORT is not allowed"),
        (r"\bINSTALL\b",     "INSTALL is not allowed"),
        (r"\bLOAD\b",        "LOAD is not allowed"),
        (r"\bCREATE\b",      "CREATE is not allowed"),
        (r"\bDROP\b",        "DROP is not allowed"),
        (r"\bINSERT\b",      "INSERT is not allowed"),
        (r"\bUPDATE\b",      "UPDATE is not allowed"),
        (r"\bDELETE\b",      "DELETE is not allowed"),
        (r"\bATTACH\b",      "ATTACH is not allowed"),
        (r"shell\s*\(",      "Shell calls are not allowed"),
        (r"read_text\s*\(",  "read_text is not allowed"),
    ]

    def analyze(
        self,
        sql:                str,
        estimated_row_hint: Optional[int] = None,   # caller can pass known row count
    ) -> SQLAnalysis:
        """
        Analyse SQL and return SQLAnalysis with safe_sql ready to execute.
        Raises nothing — caller checks result.is_safe.
        """
        result = SQLAnalysis(
            original_sql=sql,
            safe_sql=sql,
            is_safe=True,
            estimated_row_hint=estimated_row_hint,
        )

        upper = sql.strip().upper()

        # ── 1. Hard blocks ────────────────────────────────────────────────
        for pattern, msg in self._BLOCK_PATTERNS:
            if re.search(pattern, upper):
                result.errors.append(msg)
                result.is_safe = False

        if not result.is_safe:
            return result

        # ── 2. SELECT * detection ─────────────────────────────────────────
        result.has_select_star = self._has_select_star(upper)
        if result.has_select_star:
            if settings.block_select_star:
                result.errors.append(
                    "SELECT * is not allowed on large Parquet files. "
                    f"Specify column names explicitly. "
                    f"Max allowed columns: {settings.max_columns_in_query}. "
                    "Example: SELECT account_id, account_type, closing_balance FROM ..."
                )
                result.is_safe = False
                return result
            else:
                result.warnings.append(
                    f"SELECT * reads ALL columns. For 1000-column files this loads "
                    f"~72GB from S3. Specify only the columns you need."
                )

        # ── 3. Column count estimation ────────────────────────────────────
        estimated_cols = self._estimate_column_count(sql)
        result.estimated_columns = estimated_cols
        if estimated_cols and estimated_cols > settings.max_columns_in_query:
            result.errors.append(
                f"Query selects ~{estimated_cols} columns. "
                f"Maximum allowed is {settings.max_columns_in_query}. "
                f"Select only the columns you need to reduce memory usage."
            )
            result.is_safe = False
            return result

        # ── 4. WHERE clause check ─────────────────────────────────────────
        result.has_where = self._has_where_clause(upper)
        if not result.has_where:
            result.warnings.append(
                "No WHERE clause detected. On a 9M-row table this will scan all rows. "
                "Add a filter (e.g. WHERE fiscal_year = 2024) to reduce scan scope."
            )

        # ── 5. LIMIT check and auto-inject ────────────────────────────────
        limit_val = self._extract_limit(upper)
        result.has_limit   = limit_val is not None
        result.limit_value = limit_val

        if limit_val is None:
            # No LIMIT — check if it's an aggregation (safe without LIMIT)
            if not self._is_aggregation(upper):
                # Raw SELECT without LIMIT on potentially large table
                result.warnings.append(
                    f"No LIMIT clause. Auto-capping result at {settings.max_page_size:,} rows. "
                    f"Add LIMIT explicitly to make intent clear."
                )
                # Don't block — pagination handles this, but warn the caller

        elif limit_val > settings.max_page_size:
            result.errors.append(
                f"LIMIT {limit_val:,} exceeds maximum allowed ({settings.max_page_size:,}). "
                f"Use pagination (page/page_size) to retrieve large result sets."
            )
            result.is_safe = False
            return result

        # ── 6. Queue routing based on estimated size ──────────────────────
        result.suggested_queue = self._suggest_queue(estimated_row_hint, result)

        return result

    # ─────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────

    def _has_select_star(self, upper_sql: str) -> bool:
        """Detect SELECT * — handles SELECT *, SELECT t.*, SELECT a, *, b."""
        # After SELECT keyword, check for bare * or alias.*
        select_clause = re.search(
            r'\bSELECT\b(.*?)\bFROM\b', upper_sql, re.DOTALL
        )
        if not select_clause:
            return False
        cols = select_clause.group(1)
        # Match bare * or t.* but not COUNT(*) or SUM(*)
        return bool(re.search(r'(?<!\w)\*(?!\s*\))', cols))

    def _estimate_column_count(self, sql: str) -> Optional[int]:
        """
        Count columns in SELECT clause.
        Returns None if it can't determine (e.g. subquery, CTE).
        """
        upper = sql.strip().upper()
        match = re.search(r'\bSELECT\b(.*?)\bFROM\b', upper, re.DOTALL)
        if not match:
            return None
        cols_str = match.group(1).strip()
        if not cols_str or cols_str == '*':
            return None
        # Count top-level commas (not inside parentheses)
        depth = 0
        count = 1
        for ch in cols_str:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 0:
                count += 1
        return count

    def _has_where_clause(self, upper_sql: str) -> bool:
        """Detect WHERE clause (not inside subqueries for simplicity)."""
        # Remove CTEs and subqueries by checking top-level WHERE
        return bool(re.search(r'\bWHERE\b', upper_sql))

    def _extract_limit(self, upper_sql: str) -> Optional[int]:
        """Extract LIMIT value from outermost query."""
        match = re.search(r'\bLIMIT\s+(\d+)', upper_sql)
        return int(match.group(1)) if match else None

    def _is_aggregation(self, upper_sql: str) -> bool:
        """True if query is purely aggregating (GROUP BY, COUNT, SUM, etc.)."""
        agg_functions = r'\b(COUNT|SUM|AVG|MIN|MAX|STDDEV|VARIANCE|MEDIAN)\s*\('
        has_agg  = bool(re.search(agg_functions, upper_sql))
        has_group = bool(re.search(r'\bGROUP\s+BY\b', upper_sql))
        return has_agg or has_group

    def _suggest_queue(
        self,
        row_hint: Optional[int],
        analysis: SQLAnalysis,
    ) -> str:
        """
        Suggest which queue to use based on estimated data volume.

        Without a row hint, uses SQL patterns:
          - Aggregation (GROUP BY, COUNT) → can be heavy but bounded result → normal
          - No WHERE on raw SELECT        → potentially 9M rows → low
          - Has WHERE + LIMIT             → bounded → high
        """
        if row_hint:
            if row_hint <= settings.queue_threshold_high_rows:
                return "high"
            elif row_hint <= settings.queue_threshold_normal_rows:
                return "normal"
            else:
                return "low"

        upper = analysis.safe_sql.strip().upper()

        # Aggregation: result is small even on 9M rows → normal
        if self._is_aggregation(upper):
            return "normal"

        # Has WHERE + LIMIT → bounded, probably fast → high
        if analysis.has_where and analysis.has_limit:
            return "high"

        # No WHERE, raw SELECT → full scan risk → low
        if not analysis.has_where:
            return "low"

        return "normal"


# Singleton
sql_analyzer = SQLAnalyzer()
