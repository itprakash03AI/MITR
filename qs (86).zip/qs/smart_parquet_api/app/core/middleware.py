# ============================================================
# app/core/middleware.py — Production middleware
# ============================================================
"""
Middleware stack (applied in order):
  1. Request ID    — assign/propagate X-Request-ID header
  2. Request log   — log every request with method, path, status, duration
  3. API key       — optional bearer token auth
  4. Error handler — catch unhandled exceptions, log with full context

Every log line from a request carries request_id in structlog context.
This lets you grep all logs for a single request across API + worker.
"""
import time
import uuid

import structlog
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.core.settings import settings

logger = structlog.get_logger()

# Paths that bypass API key check and verbose logging
_PASSTHROUGH_PATHS = {"/", "/docs", "/redoc", "/openapi.json", "/api/admin/health"}


def register_middleware(app: FastAPI) -> None:
    """Attach all middleware to the FastAPI app. Call once in create_app()."""

    # ── 1. Request ID ────────────────────────────────────────
    # Must be first so all downstream middleware + handlers have request_id
    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next):
        request_id = (
            request.headers.get("X-Request-ID")     # honour caller's ID
            or str(uuid.uuid4())[:12]
        )
        # Bind to structlog context — every log line in this request carries it
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            method=request.method,
            path=request.url.path,
        )
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    # ── 2. Request timing + access log ───────────────────────
    @app.middleware("http")
    async def access_log_middleware(request: Request, call_next):
        if request.url.path in _PASSTHROUGH_PATHS:
            return await call_next(request)

        t0 = time.perf_counter()
        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            return response
        except Exception as exc:
            logger.error(
                "request_unhandled_exception",
                error=str(exc),
                error_type=type(exc).__name__,
            )
            raise
        finally:
            elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)
            level = "warning" if status_code >= 400 else "info"
            log = logger.bind(
                status=status_code,
                duration_ms=elapsed_ms,
                client_ip=request.client.host if request.client else "unknown",
            )
            if status_code >= 500:
                log.error("request_completed")
            elif status_code >= 400:
                log.warning("request_completed")
            else:
                log.info("request_completed")

            # Add timing to response headers (useful for debugging)
            # Note: response is already sent for streaming — header setting is no-op there
            try:
                response.headers["X-Process-Time-Ms"] = str(elapsed_ms)
            except Exception:
                pass

    # ── 3. API Key (optional) ─────────────────────────────────
    if settings.api_key_enabled and settings.api_key:
        @app.middleware("http")
        async def api_key_middleware(request: Request, call_next):
            if request.url.path in _PASSTHROUGH_PATHS:
                return await call_next(request)

            key = (
                request.headers.get("X-API-Key")
                or request.query_params.get("api_key")
            )
            if not key:
                logger.warning("auth_missing_key")
                return JSONResponse(
                    status_code=401,
                    content={"error": "Missing API key", "hint": "Pass X-API-Key header"},
                )
            if key != settings.api_key:
                logger.warning("auth_invalid_key", key_prefix=key[:4] + "***")
                return JSONResponse(
                    status_code=401,
                    content={"error": "Invalid API key"},
                )
            return await call_next(request)

    # ── 4. Global exception handler ───────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(
            "unhandled_exception",
            error=str(exc),
            error_type=type(exc).__name__,
            exc_info=True,
        )
        return JSONResponse(
            status_code=500,
            content={
                "error":      "Internal server error",
                "error_type": type(exc).__name__,
                "request_id": structlog.contextvars.get_contextvars().get("request_id"),
                "hint":       "Check server logs with this request_id for details",
            },
        )
