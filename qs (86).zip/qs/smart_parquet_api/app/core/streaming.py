# ============================================================
# app/core/streaming.py  —  True NDJSON row streaming
# ============================================================
"""
WHAT THIS SOLVES
═════════════════
  9M rows × 50 columns = ~22GB of JSON

  Normal API:   DuckDB → full result in memory → JSON → client
                22GB in memory — impossible

  This module:  DuckDB reads 10k rows → send to client → read next 10k → ...
                Memory at any time: ONE chunk = ~25MB
                Client starts receiving rows immediately
                Never holds full result in memory anywhere

HOW HTTP CHUNKED STREAMING WORKS
══════════════════════════════════
  HTTP/1.1 200 OK
  Content-Type: application/x-ndjson
  Transfer-Encoding: chunked

  {"account_id":"ACC-001","fiscal_year":2024,...}\n
  {"account_id":"ACC-002","fiscal_year":2024,...}\n
  {"account_id":"ACC-003","fiscal_year":2024,...}\n
  ... (9M lines total, sent as they are read)
  {"_stream_complete":true,"total_rows":9000000,"elapsed_ms":45231}\n

  Each \n-separated JSON object is a complete row.
  Client reads line by line — no need to buffer the full response.
  Connection closes when all rows are sent.

MEMORY BREAKDOWN
═════════════════
  DuckDB internal: reads Parquet in row groups (~1GB page cache max)
  Our chunk:       10,000 rows × 50 cols × 50 bytes = ~25MB
  serialised JSON: ~25MB per chunk
  Total API mem:   ~50-100MB regardless of how many rows the file has

CLIENT CONSUMPTION
═══════════════════

  Python (requests):
    import requests, json
    with requests.get('http://api/api/stream/sql?sql=...', stream=True) as r:
        for line in r.iter_lines():
            if line:
                row = json.loads(line)
                if '_stream_complete' in row:
                    print(f"Done: {row['total_rows']} rows")
                    break
                process(row)

  Python (httpx async):
    async with httpx.AsyncClient() as client:
        async with client.stream('GET', url, params={'sql': sql}) as r:
            async for line in r.aiter_lines():
                if line:
                    row = json.loads(line)

  curl:
    curl -N "http://api/api/stream/sql?sql=SELECT+..."
    # -N disables buffering so rows appear as they arrive

  pandas (via temp file or direct):
    import pandas as pd, requests, io, json
    rows = []
    with requests.get(url, stream=True) as r:
        for line in r.iter_lines():
            if line:
                obj = json.loads(line)
                if '_stream_complete' not in obj:
                    rows.append(obj)
    df = pd.DataFrame(rows)

  JavaScript (fetch streaming):
    const res = await fetch(url);
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
        const lines = buffer.split('\n');
        buffer = lines.pop();
        for (const line of lines) {
            if (line) {
                const row = JSON.parse(line);
                if (!row._stream_complete) processRow(row);
            }
        }
    }
"""
from __future__ import annotations

import asyncio
import json
import time
from concurrent.futures import ThreadPoolExecutor
from typing import AsyncGenerator, Optional

import duckdb
import structlog

from app.core.settings import settings

logger = structlog.get_logger()

# Dedicated pool — streaming queries hold a connection open for minutes
# Keep separate from the regular query pool so streams don't block queries
_stream_pool = ThreadPoolExecutor(
    max_workers=settings.max_concurrent_streams,
    thread_name_prefix="duckdb-stream",
)


async def stream_query_ndjson(
    sql:        str,
    chunk_size: Optional[int] = None,
) -> AsyncGenerator[bytes, None]:
    """
    Execute SQL and yield NDJSON-encoded chunks.

    Each yielded bytes object contains one or more complete JSON lines.
    The last line is always the _stream_complete sentinel.

    Args:
        sql:        DuckDB SQL to execute (SELECT only — no aggregations)
        chunk_size: rows per yield (default: settings.stream_chunk_size)

    Yields:
        bytes: newline-separated JSON rows, UTF-8 encoded

    Usage (FastAPI StreamingResponse):
        return StreamingResponse(
            stream_query_ndjson(sql),
            media_type="application/x-ndjson",
            headers={"X-Accel-Buffering": "no"},  # disable nginx buffering
        )
    """
    chunk_size = chunk_size or settings.stream_chunk_size
    loop       = asyncio.get_running_loop()

    # Bounded async queue — backpressure so DuckDB doesn't run ahead of client
    # maxsize=4 means at most 4 unsent chunks buffered (4 × 25MB = 100MB max)
    queue: asyncio.Queue = asyncio.Queue(maxsize=4)

    t_start = time.perf_counter()

    def _producer():
        """
        Runs in thread pool — reads DuckDB in batches, puts chunks on queue.
        Never loads full result into memory.
        """
        total_rows = 0
        try:
            conn = duckdb.connect(":memory:")
            _configure_conn(conn)

            rel  = conn.execute(sql)
            cols = [d[0] for d in rel.description]

            while True:
                batch = rel.fetchmany(chunk_size)
                if not batch:
                    break

                # Serialize chunk to NDJSON bytes
                lines = []
                for row in batch:
                    lines.append(json.dumps(dict(zip(cols, row)), default=str))
                chunk_bytes = ("\n".join(lines) + "\n").encode("utf-8")

                total_rows += len(batch)
                asyncio.run_coroutine_threadsafe(queue.put(chunk_bytes), loop).result()

            # Sentinel — tells consumer stream is complete
            elapsed_ms = (time.perf_counter() - t_start) * 1000
            sentinel = json.dumps({
                "_stream_complete": True,
                "total_rows":       total_rows,
                "columns":          cols,
                "elapsed_ms":       round(elapsed_ms, 1),
                "chunk_size":       chunk_size,
            }) + "\n"
            asyncio.run_coroutine_threadsafe(
                queue.put(sentinel.encode("utf-8")), loop
            ).result()

            logger.info(
                "stream_complete",
                total_rows=total_rows,
                elapsed_ms=round(elapsed_ms, 1),
            )

        except Exception as exc:
            logger.error("stream_error", error=str(exc))
            # Send error as a JSON line so client knows
            err_line = json.dumps({
                "_stream_error": True,
                "error":         str(exc),
            }) + "\n"
            asyncio.run_coroutine_threadsafe(
                queue.put(err_line.encode("utf-8")), loop
            ).result()
        finally:
            asyncio.run_coroutine_threadsafe(queue.put(None), loop).result()
            try:
                conn.close()
            except Exception:
                pass

    # Start producer in thread pool — non-blocking for event loop
    loop.run_in_executor(_stream_pool, _producer)

    # Yield chunks as they arrive
    while True:
        chunk = await queue.get()
        if chunk is None:
            break
        yield chunk


def _configure_conn(conn: duckdb.DuckDBPyConnection) -> None:
    """Apply S3 / performance settings to a fresh DuckDB connection."""
    from app.core.settings import settings as s

    conn.execute(f"SET threads TO {s.duckdb_threads}")
    conn.execute(f"SET memory_limit='{s.duckdb_memory_limit}'")
    conn.execute(f"SET temp_directory='{s.duckdb_temp_dir}'")
    conn.execute("SET enable_progress_bar=false")

    if s.s3_enabled:
        conn.execute("INSTALL httpfs; LOAD httpfs")
        conn.execute(f"SET s3_region='{s.s3_region}'")
        if s.aws_access_key_id:
            conn.execute(f"SET s3_access_key_id='{s.aws_access_key_id}'")
        if s.aws_secret_access_key:
            conn.execute(f"SET s3_secret_access_key='{s.aws_secret_access_key}'")
        if s.aws_session_token:
            conn.execute(f"SET s3_session_token='{s.aws_session_token}'")
        if s.s3_endpoint_url:
            conn.execute(f"SET s3_endpoint='{s.s3_endpoint_url}'")
            conn.execute("SET s3_use_ssl=false; SET s3_url_style='path'")
