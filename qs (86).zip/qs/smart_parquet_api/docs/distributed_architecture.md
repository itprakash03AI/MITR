# Execution Model — Where Queries Run and Why Nothing Blocks

## Current: Does execution block other requests?

**No.** Here is exactly what happens when a request arrives:

```
HTTP request arrives
        │
        ▼ (event loop thread — shared by ALL requests)
   FastAPI handler
        │
        ├─ Cache hit? ──────────────────────────────────────► return in <1ms
        │                                                      event loop never left
        │
        ├─ Semaphore acquire (async)
        │   await sem.acquire()  ◄── event loop FREE here
        │   other requests handled while this one waits        no thread consumed
        │
        └─ run_in_executor(thread_pool, duckdb_call)
                │
                │   event loop immediately FREE ◄─────────────  handles other requests
                │   while DuckDB runs in a thread               while DuckDB is running
                ▼
         Thread pool thread
              DuckDB executes
              reads Parquet / S3
              returns result
                │
                ▼
         Future resolves
         event loop resumes handler
         response sent
```

**The key:** `run_in_executor` offloads blocking DuckDB work to a thread pool,
releasing the event loop to handle other HTTP requests simultaneously.
`await sem.acquire()` is non-blocking — the event loop stays free while waiting.

## The Remaining Problem: Single Machine

Even though nothing blocks, everything runs on one server.

```
Problems with single machine at 100+ req/s:
  ✗ One server's RAM limits query size (can't query 500GB tables)
  ✗ One server goes down → full outage
  ✗ All workers compete for same CPU/disk
  ✗ Can't scale individual components independently
  ✗ Long batch export blocks interactive dashboard queries
```

## Distributed Architecture: How It Works

```
                        ┌─────────────────────────────────────┐
  Any client            │  Nginx (load balancer)              │
  curl / browser ──────►│  Round-robin to API instances       │
  BI tool               └─────────────────┬───────────────────┘
                                          │
                    ┌─────────────────────┼─────────────────────┐
                    ▼                     ▼                     ▼
              ┌──────────┐         ┌──────────┐         ┌──────────┐
              │  API #1  │         │  API #2  │         │  API #3  │
              │ FastAPI  │         │ FastAPI  │         │ FastAPI  │
              │ (no DB!) │         │ (no DB!) │         │ (no DB!) │
              └────┬─────┘         └────┬─────┘         └────┬─────┘
                   │                    │                    │
                   └────────────────────┼────────────────────┘
                                        │  LPUSH job_id
                                        ▼
                              ┌─────────────────────┐
                              │        Redis        │
                              │                     │
                              │  jobs:high  [...]   │ ◄── dashboard queries
                              │  jobs:normal [...]  │ ◄── standard requests
                              │  jobs:low   [...]   │ ◄── batch exports
                              │                     │
                              │  job:abc:status     │
                              │  job:abc:result     │
                              └──────────┬──────────┘
                                         │  BRPOP (blocking pop)
                    ┌────────────────────┼────────────────────┐
                    ▼                    ▼                    ▼
              ┌──────────┐        ┌──────────┐        ┌──────────┐
              │ Worker 1 │        │ Worker 2 │        │ Worker N │
              │ DuckDB   │        │ DuckDB   │        │ DuckDB   │
              │ 8 threads│        │ 8 threads│        │ 8 threads│
              │ 32GB RAM │        │ 32GB RAM │        │ 32GB RAM │
              └────┬─────┘        └────┬─────┘        └──────────┘
                   │                   │
                   └───────────────────┘
                               │
                               ▼
                    ┌──────────────────────┐
                    │   S3 / MinIO         │
                    │                      │
                    │  /parquet-data/      │ ◄── source data
                    │  /query-results/     │ ◄── large results
                    └──────────────────────┘
```

## Key Design Decisions

### API instances have NO DuckDB
The API only: validates SQL, pushes to Redis, polls status, returns result.
It never executes a query itself in distributed mode.
This means API instances are lightweight — they can run on tiny containers.

### Workers have dedicated DuckDB
Each worker has its own DuckDB connection, own memory, own thread pool.
One worker crash → others keep running.
Add workers → linear throughput increase.
Workers can be on different machines with different RAM amounts.

### Priority queues separate interactive from batch
```
High:   dashboard refresh, interactive reports  ← always runs first
Normal: standard API calls
Low:    nightly batch exports, full table scans ← runs only when high/normal empty
```
Workers do: `BRPOP jobs:high jobs:normal jobs:low`
Redis guarantees high is always drained before normal.

### Large results bypass the API
Results > 10MB: worker writes Parquet directly to S3.
Client gets back `{ "type": "s3", "location": "s3://bucket/results/abc.parquet" }`.
Client reads from S3 directly — API never touches the data.
This prevents a 500MB result from choking the API process.

## Capacity Math

```
Setup: 4 API + 8 Workers + Redis

API layer:
  4 instances × 200 queue depth = 800 requests accepted before 503
  Submission is near-instant (Redis LPUSH = microseconds)

Worker layer:
  8 workers × 1 query at a time = 8 parallel DuckDB executions
  8 × 8 threads = 64 threads doing real DuckDB work
  Average query 500ms → 8 / 0.5s = 16 queries/sec throughput

With cache (80% hit rate typical):
  100 req/s → 20 hit workers → 80 return from Redis cache
  Effective throughput: 100 req/s on 8 workers

Scaling:
  Add workers: docker-compose up --scale worker=16
  No code changes, no restart of API or Redis
```

## Usage Patterns

### 1. Fire and poll (recommended for queries > 100ms)
```bash
# Submit
JOB=$(curl -s -X POST "http://localhost/api/jobs/submit?sql=SELECT+..." | jq -r .job_id)

# Poll
while true; do
  STATUS=$(curl -s "http://localhost/api/jobs/$JOB" | jq -r .status)
  echo "Status: $STATUS"
  [ "$STATUS" = "done" ] && break
  sleep 1
done

# Get result
curl "http://localhost/api/jobs/$JOB/result"
```

### 2. Wait mode (for fast queries < 5s)
```bash
curl "http://localhost/api/jobs/submit?sql=SELECT+COUNT(*)...&wait=true"
```

### 3. Priority (interactive vs batch)
```bash
# Dashboard query — goes to front of queue
curl "http://localhost/api/jobs/submit?sql=...&priority=high"

# Nightly export — runs when workers are idle
curl "http://localhost/api/jobs/submit?sql=...&priority=low"
```

### 4. Batch submit (multiple queries at once)
```bash
curl -X POST http://localhost/api/jobs/admin/submit-batch \
  -H 'Content-Type: application/json' \
  -d '[
    {"sql": "SELECT ...", "tags": {"report": "tb_2024_q1"}},
    {"sql": "SELECT ...", "tags": {"report": "tb_2024_q2"}},
    {"sql": "SELECT ...", "tags": {"report": "tb_2024_q3"}}
  ]'
```

### 5. Webhook (push instead of poll)
```bash
curl "http://localhost/api/jobs/submit?sql=...&callback_url=https://your-system/done"
# Your endpoint receives: {"job_id": "abc-123", "status": "done"}
```

## Starting the Stack

```bash
# Development (with MinIO replacing S3)
docker-compose up

# Scale workers
docker-compose up --scale worker=8

# Check queue depths
curl http://localhost/api/jobs/admin/queue-depths

# List recent jobs
curl http://localhost/api/jobs/admin/list
```

## When to Use Distributed vs Direct

| Scenario | Use |
|---|---|
| Query < 200ms, interactive | Direct (`/api/execute/sql` or `/api/query/`) |
| Query 200ms–30s | Distributed with `?wait=true` |
| Query > 30s or large result | Distributed with polling |
| Batch of many queries | Distributed `/api/jobs/admin/submit-batch` |
| 100+ concurrent users | Distributed always |
