# Smart Parquet Query API — Complete Reference

---

## All Endpoints At a Glance

```
GROUP             METHOD  PATH                                    USE CASE
────────────────  ──────  ──────────────────────────────────────  ────────────────────────────────────
SYNC QUERY        POST    /api/execute/sql                        Fast SQL, result inline, <10MB
                  POST    /api/execute/sql/explain                DuckDB query plan (debug)
                  POST    /api/execute/parquet/schema             Inspect columns of any Parquet file
                  POST    /api/execute/parquet/sample             Peek at first N rows
NAMED QUERIES     GET     /api/query/{endpoint_id}               Pre-defined SQL from config/queries.yaml
STREAMING         GET     /api/stream/sql                         9M rows × ≤50 cols, live NDJSON
EXPORT            POST    /api/stream/export                      9M × 1000 cols → S3 Parquet parts
DISTRIBUTED       POST    /api/jobs/submit                        Any heavy query, async, prioritised
                  GET     /api/jobs/{job_id}                      Poll status
                  GET     /api/jobs/{job_id}/result               Fetch result when done
                  DELETE  /api/jobs/{job_id}                      Cancel queued job
                  POST    /api/jobs/admin/submit-batch            Submit up to 50 jobs at once
ICEBERG           GET     /api/iceberg/test-connection            Diagnose S3/catalog connectivity
                  GET     /api/iceberg/namespaces/{ns}/tables     List tables in namespace
                  GET     /api/iceberg/namespaces/{ns}/tables/{t} Schema + snapshot info
                  POST    /api/iceberg/query                      SQL on an Iceberg table
                  GET     /api/iceberg/namespaces/{ns}/tables/{t}/snapshots   Time-travel history
ADMIN             GET     /api/admin/health                       Health + concurrency stats
                  GET     /api/admin/metrics                      Cache hit rate, running queries
                  GET     /api/admin/cache                        Cache stats
                  DELETE  /api/admin/cache                        Clear cache
                  GET     /api/admin/endpoints                    List all named query endpoints
QUEUE ADMIN       GET     /api/jobs/admin/queue-depths            Jobs waiting per priority
                  GET     /api/jobs/admin/memory                  Redis memory + cache stats
                  GET     /api/jobs/admin/list                    Recent jobs + status
GRAPHQL           GET     /graphql                                GraphiQL browser IDE
                  POST    /graphql                                Full GraphQL with column pushdown
```

---

## When to Use Which — Decision Tree

```
You want to query Parquet / Iceberg data
              │
              ├─ Do you know the result will be small? (<10MB, <10k rows)
              │    └── POST /api/execute/sql          (sync, instant response)
              │
              ├─ Named, pre-defined report?
              │    └── GET  /api/query/{id}           (from queries.yaml config)
              │
              ├─ 9M rows × ≤50 columns, raw SELECT, need rows as they come?
              │    └── GET  /api/stream/sql           (NDJSON stream, ~25MB memory)
              │
              ├─ 9M rows × 1000 columns, need ALL columns?
              │    └── POST /api/stream/export        (S3 Parquet parts + presigned URLs)
              │
              ├─ Heavy aggregation, result could be large, caller can wait?
              │    └── POST /api/jobs/submit          (async, Redis queue, poll for result)
              │
              ├─ Query Iceberg table on S3?
              │    └── POST /api/iceberg/query        (reads snapshot metadata → Parquet)
              │
              └─ Flexible, nested queries, frontend?
                   └── POST /graphql                  (column pushdown, introspection)
```

---

## Endpoint Details

---

### 1. POST /api/execute/sql
**Use for:** Ad-hoc SQL, result fits in memory, interactive queries

```
Request:
  ?sql=SELECT account_type, SUM(debit_amount) FROM read_parquet('...') GROUP BY 1
  ?page=1          (default: 1)
  ?page_size=1000  (default: 1000, max: 10000)
  ?cache=true      (default: false for ad-hoc)

Response:
  {
    "columns":     ["account_type", "sum(debit_amount)"],
    "rows":        [{"account_type": "ASSET", "sum(debit_amount)": 123456.78}, ...],
    "total_rows":  42,
    "page":        1,
    "page_size":   1000,
    "total_pages": 1,
    "execution_ms": 145,
    "cached":      false
  }
```

**Guarantees:**
- `total_rows` = exact count of ALL rows matching the query (not just this page)
- `total_pages` = `ceil(total_rows / page_size)` — tells you exactly how many pages exist
- `rows` always has ≤ `page_size` entries
- Page 1 always has the first `page_size` rows — no overlap, no gaps

---

### 2. GET /api/stream/sql
**Use for:** 9M rows, ≤50 columns, raw SELECT, no GROUP BY

```
Request:
  ?sql=SELECT col1, col2, ..., col50 FROM read_parquet('s3://...')
  ?chunk_size=10000  (optional, default: 10000 rows per HTTP chunk)

Response: HTTP 200, Content-Type: application/x-ndjson, Transfer-Encoding: chunked

Stream format (one JSON object per line):
  {"col1":"val","col2":"val",...}      ← row 1
  {"col1":"val","col2":"val",...}      ← row 2
  ...                                  ← 9,999,998 more rows
  {"_stream_complete":true,"total_rows":9000000,"columns":["col1","col2",...],"elapsed_ms":45231}

The LAST line is ALWAYS the _stream_complete sentinel.
Connection closes after sentinel is sent.
```

**How client knows data is complete:**
```python
import requests, json

complete = False
row_count = 0

with requests.get(url, params={"sql": sql}, stream=True) as r:
    for line in r.iter_lines():
        if not line:
            continue
        obj = json.loads(line)

        if "_stream_complete" in obj:
            # ✅ Confirmed complete
            assert obj["total_rows"] == row_count, "Count mismatch!"
            complete = True
            break
        else:
            process(obj)
            row_count += 1

if not complete:
    raise Exception("Stream ended without completion sentinel — connection dropped")
```

**SELECT \* is blocked here.** For 1000 columns use `/api/stream/export`.

---

### 3. POST /api/stream/export
**Use for:** 9M × 1000 cols, SELECT \*, aggregation with huge result

```
Request:
  ?sql=SELECT * FROM read_parquet('s3://bucket/9m_1000col.parquet')
  ?priority=low   (exports are slow — default to low queue)

Response (immediate, <5ms):
  {
    "job_id":  "abc-123",
    "status":  "queued",
    "message": "Poll GET /api/jobs/abc-123"
  }

After polling and status=done, GET /api/jobs/abc-123/result:
  {
    "export_id":  "abc-123",
    "status":     "ready",
    "total_rows": 9000000,
    "total_mb":   1840.5,
    "part_count": 4,
    "columns":    ["col1", "col2", ... "col1000"],
    "execution_s": 187.3,
    "s3_prefix":  "s3://bucket/exports/abc-123/",
    "parts": [
      {
        "part":      0,
        "size_mb":   487.3,
        "row_count": 2250000,
        "url":       "https://s3.amazonaws.com/bucket/exports/abc-123/part-0.parquet?...",
        "expires_at":"2024-01-15T18:00:00Z"
      },
      {
        "part":      1,
        "size_mb":   451.2,
        "row_count": 2250000,
        "url":       "https://..."
      },
      ...
    ],
    "how_to_read": {
      "pandas": "pd.read_parquet('s3://bucket/exports/abc-123/')",
      "duckdb": "SELECT * FROM read_parquet('s3://bucket/exports/abc-123/*.parquet')"
    }
  }
```

**How client knows data is complete:**
```python
import pandas as pd

total_rows_expected = result["total_rows"]   # from API response
total_rows_received = 0

for part in result["parts"]:
    df = pd.read_parquet(part["url"])         # download each part
    total_rows_received += len(df)
    process(df)

# Verify completeness
assert total_rows_received == total_rows_expected, \
    f"Missing {total_rows_expected - total_rows_received} rows!"

# Or just trust the metadata — DuckDB COPY is atomic per part file
# part["row_count"] is read from Parquet file footer — always accurate
total_from_meta = sum(p["row_count"] for p in result["parts"])
assert total_from_meta == total_rows_expected
```

**Why parts never have duplicates:**
DuckDB `COPY TO s3:// (PER_THREAD_OUTPUT TRUE)` assigns each output row to exactly
one thread's output file. No row appears in more than one part. Row assignment is
deterministic — part 0 = thread 0's rows, part 1 = thread 1's rows, etc.

---

### 4. POST /api/jobs/submit
**Use for:** Heavy aggregations, 100+ concurrent, priority routing, webhooks

```
Request:
  ?sql=SELECT account_type, fiscal_year, SUM(debit), COUNT(*)
       FROM read_parquet('s3://bucket/3m_rows.parquet')
       GROUP BY 1, 2
  ?priority=high    (high / normal / low)
  ?page=1
  ?page_size=1000
  ?wait=false       (true = block up to 30s, false = return job_id immediately)
  ?estimated_rows=3000000   (helps auto-route to correct queue)
  ?callback_url=https://your-system/done   (webhook on completion)

Immediate response (<5ms):
  {
    "job_id":        "abc-123",
    "status":        "queued",
    "priority":      "normal",
    "auto_routed":   true,
    "warnings":      [],
    "analysis": {
      "has_where":        false,
      "suggested_queue":  "normal"
    }
  }

Poll GET /api/jobs/abc-123:
  {
    "job_id":      "abc-123",
    "status":      "running",   ← queued → running → done / failed
    "worker_id":   "worker-3",
    "started_at":  1705320000,
    "wait_time_s": 0.8
  }

GET /api/jobs/abc-123/result (when status=done):
  {
    "type":        "inline",    ← or "s3" if result > 1MB
    "columns":     ["account_type", "fiscal_year", "sum(debit)", "count_star()"],
    "total_rows":  84,
    "page":        1,
    "page_size":   1000,
    "total_pages": 1,
    "execution_ms": 4821,
    "data":        [{"account_type": "ASSET", "fiscal_year": 2024, ...}, ...]
  }
```

**Priority queue auto-routing (when estimated_rows provided):**
```
estimated_rows ≤ 500k       →  jobs:high    (fast workers, drained first)
estimated_rows ≤ 3M         →  jobs:normal
estimated_rows > 3M         →  jobs:low     (long-running, don't block fast jobs)
```

---

### 5. Paginating Large Results — No Duplicates Guaranteed

This is how pagination works across all endpoints that return `total_pages`:

```
First call:  ?page=1&page_size=1000
             SQL internally: SELECT ... LIMIT 1000 OFFSET 0

Second call: ?page=2&page_size=1000
             SQL internally: SELECT ... LIMIT 1000 OFFSET 1000

Nth call:    ?page=N&page_size=1000
             SQL internally: SELECT ... LIMIT 1000 OFFSET (N-1)*1000
```

**Why there are no duplicates:**
- OFFSET is mathematically exclusive — row 1000 is in page 1 (rows 0-999), page 2 starts at row 1000
- The underlying SQL never changes between pages — same ORDER BY, same WHERE
- `total_rows` is computed once via `COUNT(*)` on the same query and returned on every page

**Client loop with completeness check:**
```python
import requests

base_url  = "http://localhost:8000/api/execute/sql"
sql       = "SELECT * FROM read_parquet('...') ORDER BY account_id"
page_size = 1000
page      = 1
all_rows  = []

while True:
    r = requests.post(base_url, params={
        "sql":       sql,
        "page":      page,
        "page_size": page_size,
    })
    data = r.json()

    all_rows.extend(data["rows"])
    total_pages = data["total_pages"]
    total_rows  = data["total_rows"]

    print(f"Page {page}/{total_pages} — {len(all_rows)}/{total_rows} rows")

    if page >= total_pages:
        break
    page += 1

# Verify — should always pass
assert len(all_rows) == total_rows, f"Got {len(all_rows)}, expected {total_rows}"
print("✅ Complete — no missing rows, no duplicates")
```

**Important:** Always include `ORDER BY` in paginated queries. Without it, DuckDB may
return rows in different order on each call, which could technically cause apparent
duplicates or gaps if the underlying data changes between calls.

---

### 6. POST /api/jobs/admin/submit-batch
**Use for:** Month-end batch — submit 50 queries at once

```
POST /api/jobs/admin/submit-batch
Body: [
  {"sql": "SELECT ...", "tags": {"report": "tb_2024_q1"}},
  {"sql": "SELECT ...", "tags": {"report": "tb_2024_q2"}},
  {"sql": "SELECT ...", "tags": {"report": "pl_2024_q1"}}
]

Response:
  {
    "submitted": 3,
    "jobs": [
      {"job_id": "aaa-111", "status": "queued", "tags": {"report": "tb_2024_q1"}},
      {"job_id": "bbb-222", "status": "queued", "tags": {"report": "tb_2024_q2"}},
      {"job_id": "ccc-333", "status": "queued", "tags": {"report": "pl_2024_q1"}}
    ]
  }
```

---

### 7. POST /api/iceberg/query
**Use for:** Tables managed by Iceberg catalog (Glue, Hive, REST, Nessie)

```
POST /api/iceberg/query
Body: {
  "namespace": "finance",
  "table":     "tb_balances",
  "sql":       "SELECT account_type, SUM(closing_balance) FROM {table} GROUP BY 1",
  "snapshot_id": null   (null = latest, or pass ID for time-travel)
}

Response: same as /api/execute/sql (paginated)
```

**Snapshot/time-travel:**
```
GET /api/iceberg/namespaces/finance/tables/tb_balances/snapshots
→ [
    {"snapshot_id": 1234, "timestamp": "2024-01-14T00:00:00Z", "operation": "append"},
    {"snapshot_id": 1233, "timestamp": "2024-01-13T00:00:00Z", "operation": "append"},
    ...
  ]

Then query a specific snapshot:
POST /api/iceberg/query
  { "snapshot_id": 1233, ... }   ← reads data as it was on Jan 13
```

---

### 8. GET /graphql + POST /graphql
**Use for:** Frontend applications, flexible column selection, nested queries

```graphql
# List accounts with filtering
query {
  accounts(
    filters: [{column: "account_type", operator: "eq", value: "ASSET"}]
    limit: 100
  ) {
    account_id
    account_type
    opening_balance
    closing_balance
  }
}

# Aggregation
query {
  trialBalance(
    groupBy: ["account_type", "fiscal_year"]
  ) {
    account_type
    fiscal_year
    total_debit
    total_credit
  }
}
```

---

### 9. Admin & Monitoring

```
GET /api/admin/health
→ {
    "status": "ok",
    "concurrency": {
      "current_running": 4,
      "current_waiting": 12,
      "total_cached": 843,
      "cache": {"hit_rate": 0.74}
    }
  }

GET /api/admin/metrics
→ live per-process DuckDB concurrency stats

GET /api/jobs/admin/queue-depths
→ {"high": 0, "normal": 8, "low": 23, "total": 31}

GET /api/jobs/admin/memory
→ {
    "cache_stats": {
      "cached_unique_results": 23,
      "estimated_mb": 18.4
    },
    "redis_memory": {
      "redis_used_mb": 42.1,
      "redis_max_mb": 2048
    }
  }
```

---

## Completeness Guarantees — Summary

| Endpoint              | How you know data is complete                                           |
|-----------------------|-------------------------------------------------------------------------|
| `/api/execute/sql`    | `len(rows) == total_rows` when single page, OR `page == total_pages`   |
| `/api/stream/sql`     | Last line contains `{"_stream_complete": true, "total_rows": N}`       |
| `/api/stream/export`  | `sum(part.row_count) == total_rows` in response                        |
| `/api/jobs/submit`    | `status == "done"` + result has `total_rows` + `total_pages`           |
| `/api/iceberg/query`  | Same as `/api/execute/sql` — paginated with `total_rows`               |

---

## Pagination — No Duplicate Guarantee

Every paginated endpoint (execute, jobs, iceberg) uses this SQL pattern internally:

```sql
-- Count (runs once, cached)
SELECT COUNT(*) FROM ({your_sql}) __count__

-- Page N (runs on each page request)
SELECT * FROM ({your_sql}) __page__
LIMIT {page_size} OFFSET {(page-1) * page_size}
```

**Why duplicates are impossible:**
- OFFSET is purely arithmetic — page 2 starts exactly where page 1 ends
- The inner SQL is identical on every page call — same filter, same sort
- `total_rows` is computed from the same query — count always matches pages
- Shared result cache means repeated requests for same page return same rows

**One rule:** Always add `ORDER BY` to paginated queries.
Without it, row order is non-deterministic and could vary per page call.

---

## Data Flow Summary

```
Source Data (Parquet / Iceberg on S3 or local disk)
        │
        │ DuckDB reads only needed columns (column pruning)
        │ DuckDB applies WHERE before reading row groups (predicate pushdown)
        │ DuckDB spills to /tmp if result exceeds memory limit
        │
        ▼
   [Worker Process]
        │
        ├─ Small result (<1MB)    → Redis inline → client polls → gets JSON
        │
        ├─ Medium result (1-10MB) → S3 as Parquet → client gets presigned URL
        │
        ├─ Streaming (≤50 cols)  → NDJSON chunks over HTTP → client reads live
        │
        └─ Export (1000 cols)    → Partitioned Parquet → S3 parts → presigned URLs
                                    client downloads parts in parallel
                                    pandas/DuckDB reads Parquet natively
```

---

## Quick Reference Card

```bash
# Fast query
curl -X POST "localhost:8000/api/execute/sql?sql=SELECT+COUNT(*)+FROM+read_parquet('...')"

# Stream 9M rows (≤50 cols)
curl -N "localhost:8000/api/stream/sql?sql=SELECT+col1,col2+FROM+read_parquet('...')"

# Export all 1000 cols to S3
curl -X POST "localhost:8000/api/stream/export?sql=SELECT+*+FROM+read_parquet('...')"
JOB=<job_id from above>
curl "localhost:8000/api/jobs/$JOB/result"   # presigned URLs

# Heavy aggregation, async
curl -X POST "localhost:8000/api/jobs/submit?sql=SELECT+...GROUP+BY+...&priority=normal"
curl "localhost:8000/api/jobs/$JOB"          # poll
curl "localhost:8000/api/jobs/$JOB/result"   # get result

# Batch submit (month-end)
curl -X POST localhost:8000/api/jobs/admin/submit-batch \
  -H 'Content-Type: application/json' \
  -d '[{"sql":"SELECT ..."},{"sql":"SELECT ..."}]'

# Monitor
curl "localhost:8000/api/admin/metrics"
curl "localhost:8000/api/jobs/admin/queue-depths"
curl "localhost:8000/api/jobs/admin/memory"
```
