# Smart Parquet Query API — Enterprise Runbook

## Getting Started in 5 Minutes

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env — minimum required: set S3_BUCKET if using S3

# 2. Generate sample data
pip install pandas pyarrow
python scripts/generate_sample_data.py

# 3. Start everything
docker-compose up --scale worker=4

# 4. Verify
curl http://localhost/api/admin/health

# 5. Open interactive docs
open http://localhost/docs
```

---

## Architecture

```
                    ┌─────────────────────────────┐
Clients ──────────► │  Nginx (port 80)            │ load balancer
                    └──────────────┬──────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              ▼                    ▼                    ▼
   ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
   │  API pod 1       │ │  API pod 2       │ │  API pod N       │
   │  FastAPI/Gunicorn│ │  FastAPI/Gunicorn│ │  FastAPI/Gunicorn│
   │  - validate SQL  │ │  - validate SQL  │ │  - validate SQL  │
   │  - check cache   │ │  - check cache   │ │  - check cache   │
   │  - push to Redis │ │  - push to Redis │ │  - push to Redis │
   └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
            └────────────────────┼────────────────────┘
                                 │ LPUSH / BRPOP
                    ┌────────────▼────────────────┐
                    │  Redis                      │
                    │  jobs:high   [...]          │ priority queues
                    │  jobs:normal [...]          │
                    │  jobs:low    [...]          │
                    │  cache:*     result data    │ shared result cache
                    │  job:*       metadata       │
                    │  worker:*    heartbeats     │
                    └────────────┬────────────────┘
              ┌──────────────────┼──────────────────┐
              ▼                  ▼                  ▼
   ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
   │  Worker 1       │ │  Worker 2       │ │  Worker N       │
   │  DuckDB         │ │  DuckDB         │ │  DuckDB         │
   │  own process    │ │  own process    │ │  own process    │
   │  own memory     │ │  own memory     │ │  own memory     │
   └────────┬────────┘ └────────┬────────┘ └────────┬────────┘
            └──────────────────┬──────────────────┘
                               │ reads Parquet
                    ┌──────────▼────────────────┐
                    │  S3 / Local Parquet        │
                    │  Apache Iceberg tables     │
                    └───────────────────────────┘
```

---

## All Endpoints — Complete Reference

### Decision Tree

```
Need query results?
│
├─ Fast, result < 10MB, interactive?
│    └── POST /api/execute/sql
│
├─ Pre-defined report from config?
│    └── GET  /api/query/{report_id}
│
├─ 9M rows, ≤50 named columns, need rows live?
│    └── GET  /api/stream/sql
│
├─ 9M rows × ALL 1000 columns / SELECT *?
│    └── POST /api/stream/export         → S3 Parquet parts + presigned URLs
│
├─ Heavy aggregation, 100+ concurrent?
│    └── POST /api/jobs/submit           → async, poll for result
│
├─ Iceberg catalog (Glue/Hive/REST)?
│    └── POST /api/iceberg/query
│
└─ Frontend, flexible column selection?
     └── POST /graphql
```

---

### 1. POST /api/execute/sql — Fast synchronous query

**When to use:** Interactive, ad-hoc SQL. Result fits in memory (<10MB).

```bash
curl -X POST "http://localhost/api/execute/sql" \
  -H "Content-Type: text/plain" \
  --data-binary "
    SELECT account_type, fiscal_year, SUM(debit_amount) as total_debit
    FROM read_parquet('s3://my-bucket/tb_transactions/*.parquet')
    WHERE fiscal_year = 2024
    GROUP BY account_type, fiscal_year
    ORDER BY account_type
  "
```

**With pagination:**
```bash
curl "http://localhost/api/execute/sql?page=2&page_size=500" \
  -d "SELECT * FROM read_parquet('data/accounts.parquet') ORDER BY account_id"
```

**Response:**
```json
{
  "columns":     ["account_type", "fiscal_year", "total_debit"],
  "rows":        [{"account_type": "ASSET", "fiscal_year": 2024, "total_debit": 1234567.89}],
  "total_rows":  6,
  "page":        1,
  "page_size":   1000,
  "total_pages": 1,
  "execution_ms": 145,
  "cached":      false,
  "warnings":    []
}
```

---

### 2. POST /api/jobs/submit — Async distributed query

**When to use:** Heavy queries, 100+ concurrent users, large aggregations, priority routing.

```bash
# Submit — returns immediately (<5ms)
JOB=$(curl -s -X POST "http://localhost/api/jobs/submit" \
  -G \
  --data-urlencode "sql=SELECT account_type, fiscal_year, SUM(debit_amount), COUNT(*)
    FROM read_parquet('s3://my-bucket/tb_transactions/*.parquet')
    GROUP BY account_type, fiscal_year
    ORDER BY fiscal_year DESC" \
  -d "priority=normal" \
  -d "estimated_rows=3000000" \
  | jq -r '.job_id')

echo "Job ID: $JOB"

# Poll until done
while true; do
  STATUS=$(curl -s "http://localhost/api/jobs/$JOB" | jq -r '.status')
  echo "Status: $STATUS"
  [ "$STATUS" = "done" ] || [ "$STATUS" = "failed" ] && break
  sleep 2
done

# Get result
curl -s "http://localhost/api/jobs/$JOB/result" | jq '.data[:3]'
```

**Priority levels:**
```bash
# High — drained first, for dashboards / interactive
-d "priority=high"

# Normal — default
-d "priority=normal"

# Low — batch exports, full table scans, background
-d "priority=low"

# Auto-route based on data size (recommended)
-d "estimated_rows=9000000"   # → auto-routed to low queue
-d "estimated_rows=500000"    # → auto-routed to high queue
```

**With webhook callback:**
```bash
curl -X POST "http://localhost/api/jobs/submit" \
  -G \
  --data-urlencode "sql=SELECT ..." \
  -d "callback_url=https://your-system.internal/webhook/job-done"
# When job completes, POST to your webhook: {"job_id": "abc-123", "status": "done"}
```

**Batch submit (month-end reports):**
```bash
curl -X POST "http://localhost/api/jobs/admin/submit-batch" \
  -H "Content-Type: application/json" \
  -d '[
    {"sql": "SELECT ... FROM tb_q1.parquet", "tags": {"report": "tb_2024_q1"}},
    {"sql": "SELECT ... FROM tb_q2.parquet", "tags": {"report": "tb_2024_q2"}},
    {"sql": "SELECT ... FROM pl_2024.parquet", "tags": {"report": "pl_2024"}}
  ]'
```

**Job lifecycle:**
```
submitted → queued → running → done
                            → failed
                            → cancelled (if DELETE called while queued)
```

---

### 3. GET /api/stream/sql — NDJSON row streaming

**When to use:** 9M rows, ≤50 columns, SELECT (no aggregation), need rows as they arrive.

```bash
# curl — rows appear live as DuckDB reads them
curl -N "http://localhost/api/stream/sql" \
  -G \
  --data-urlencode "sql=
    SELECT account_id, account_type, fiscal_year, opening_balance, closing_balance
    FROM read_parquet('s3://my-bucket/9m_rows.parquet')
    WHERE fiscal_year = 2024
    ORDER BY account_id"

# Output (one JSON object per line):
# {"account_id":"ACC-000001","account_type":"ASSET","fiscal_year":2024,...}
# {"account_id":"ACC-000002","account_type":"ASSET","fiscal_year":2024,...}
# ... (9M lines)
# {"_stream_complete":true,"total_rows":9000000,"elapsed_ms":45231}
```

**Python consumer — with completeness check:**
```python
import requests, json

url    = "http://localhost/api/stream/sql"
sql    = """
    SELECT account_id, account_type, fiscal_year, closing_balance
    FROM read_parquet('s3://my-bucket/9m_rows.parquet')
    ORDER BY account_id
"""
rows_received = 0
complete      = False

with requests.get(url, params={"sql": sql}, stream=True, timeout=600) as r:
    r.raise_for_status()
    for raw_line in r.iter_lines():
        if not raw_line:
            continue
        obj = json.loads(raw_line)
        if "_stream_complete" in obj:
            # ✅ Confirmed — stream ended cleanly
            assert obj["total_rows"] == rows_received, \
                f"INCOMPLETE: got {rows_received}, expected {obj['total_rows']}"
            complete = True
            print(f"Done: {rows_received:,} rows in {obj['elapsed_ms']}ms")
            break
        if "_stream_error" in obj:
            raise RuntimeError(f"Stream error: {obj['error']}")
        # Process your row here
        rows_received += 1

if not complete:
    raise RuntimeError("Connection dropped before stream completed — retry")
```

**JavaScript consumer:**
```javascript
const response = await fetch(`/api/stream/sql?sql=${encodeURIComponent(sql)}`);
const reader   = response.body.getReader();
const decoder  = new TextDecoder();
let buffer = '';
let rowCount = 0;

while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();                         // incomplete last line
    for (const line of lines) {
        if (!line.trim()) continue;
        const obj = JSON.parse(line);
        if (obj._stream_complete) {
            console.log(`Done: ${obj.total_rows} rows`);
        } else if (obj._stream_error) {
            throw new Error(obj.error);
        } else {
            rowCount++;
            processRow(obj);                      // your handler here
        }
    }
}
```

**Rules:**
- SELECT \* blocked — specify column names (max 50)
- No GROUP BY — aggregations must complete before first row; use `/api/jobs/submit` instead
- Add `ORDER BY` for consistent row ordering across retries

---

### 4. POST /api/stream/export — S3 Parquet export (all columns)

**When to use:** SELECT \*, 1000 columns, huge aggregation result, BI tools, pandas pipelines.

```bash
# Submit export — SELECT * allowed here
JOB=$(curl -s -X POST "http://localhost/api/stream/export" \
  -G \
  --data-urlencode "sql=SELECT * FROM read_parquet('s3://my-bucket/9m_1000col.parquet')" \
  | jq -r '.job_id')

# Poll — export takes 2-10 minutes for 9M rows
watch -n 5 "curl -s http://localhost/api/jobs/$JOB | jq '{status, execution_s: .execution_ms}'"

# Get presigned download URLs when done
curl -s "http://localhost/api/jobs/$JOB/result" | jq '.'
```

**Result:**
```json
{
  "export_id":  "abc-123",
  "status":     "ready",
  "total_rows": 9000000,
  "total_mb":   1840.5,
  "part_count": 4,
  "execution_s": 187.3,
  "parts": [
    {
      "part":      0,
      "size_mb":   487.3,
      "row_count": 2250000,
      "url":       "https://s3.amazonaws.com/bucket/exports/abc-123/part-0.parquet?...",
      "expires_at":"2024-01-15T18:00:00Z"
    },
    { "part": 1, "size_mb": 451.2, "row_count": 2250000, "url": "https://..." },
    { "part": 2, "size_mb": 469.0, "row_count": 2250000, "url": "https://..." },
    { "part": 3, "size_mb": 433.0, "row_count": 2250000, "url": "https://..." }
  ],
  "how_to_read": {
    "pandas": "pd.read_parquet('s3://bucket/exports/abc-123/')",
    "duckdb": "SELECT * FROM read_parquet('s3://bucket/exports/abc-123/*.parquet')"
  }
}
```

**Download with completeness check:**
```python
import pandas as pd
import requests

# Get result
result = requests.get(f"http://localhost/api/jobs/{job_id}/result").json()

total_expected = result["total_rows"]
total_received = 0
all_parts      = []

for part in result["parts"]:
    print(f"Downloading part {part['part']} ({part['size_mb']}MB, {part['row_count']:,} rows)...")
    df = pd.read_parquet(part["url"])

    # Verify part row count matches metadata
    assert len(df) == part["row_count"], f"Part {part['part']} row count mismatch"
    total_received += len(df)
    all_parts.append(df)

# Verify total
assert total_received == total_expected, \
    f"INCOMPLETE: got {total_received:,}, expected {total_expected:,}"

full_df = pd.concat(all_parts, ignore_index=True)
print(f"✅ Complete: {len(full_df):,} rows, {len(full_df.columns)} columns")
```

**Why parts have no duplicates:**
DuckDB `COPY TO S3 (PER_THREAD_OUTPUT TRUE)` assigns each row to exactly one thread's
output file. Row assignment is deterministic — part-0 = thread-0's rows, etc.
`sum(part.row_count) == total_rows` always. Verified from Parquet file footer metadata.

---

### 5. POST /api/iceberg/query — Query Iceberg tables

```bash
curl -X POST "http://localhost/api/iceberg/query" \
  -H "Content-Type: application/json" \
  -d '{
    "namespace": "finance",
    "table":     "tb_balances",
    "sql":       "SELECT account_type, SUM(closing_balance) FROM {table} WHERE fiscal_year=2024 GROUP BY 1",
    "page":      1,
    "page_size": 1000
  }'

# Time-travel — query data as it was at a previous snapshot
curl -X POST "http://localhost/api/iceberg/query" \
  -H "Content-Type: application/json" \
  -d '{
    "namespace":   "finance",
    "table":       "tb_balances",
    "snapshot_id": 1234567890,
    "sql":         "SELECT COUNT(*) FROM {table}"
  }'

# List snapshots
curl "http://localhost/api/iceberg/namespaces/finance/tables/tb_balances/snapshots"
```

---

### 6. POST /graphql — GraphQL

```graphql
# Open browser: http://localhost/graphql

query GetTrialBalance {
  trialBalance(
    filters: [
      { column: "fiscal_year", operator: "eq", value: "2024" }
      { column: "account_type", operator: "in", value: "ASSET,LIABILITY" }
    ]
    groupBy: ["account_type"]
    limit: 100
  ) {
    account_type
    total_debit
    total_credit
    net_balance
  }
}
```

---

### 7. GET /api/query/{report_id} — Named reports from config

Define in `config/queries.yaml`, call by ID. No SQL needed from the caller.

```bash
# List available named endpoints
curl "http://localhost/api/admin/endpoints"

# Call a named report with parameters
curl "http://localhost/api/query/trial_balance?fiscal_year=2024&account_type=ASSET"
```

---

## Pagination — Complete Guide

Every paginated endpoint returns these fields:

```json
{
  "total_rows":  9000000,
  "page":        1,
  "page_size":   1000,
  "total_pages": 9000,
  "rows":        [...]
}
```

**Complete pagination loop:**
```python
import requests

def fetch_all(sql: str, page_size: int = 1000) -> list:
    url       = "http://localhost/api/execute/sql"
    page      = 1
    all_rows  = []

    while True:
        resp = requests.post(url, params={"page": page, "page_size": page_size},
                             data=sql)
        resp.raise_for_status()
        data = resp.json()

        all_rows.extend(data["rows"])
        print(f"Page {page}/{data['total_pages']} — {len(all_rows)}/{data['total_rows']} rows")

        if page >= data["total_pages"]:
            break
        page += 1

    # Final verification
    assert len(all_rows) == data["total_rows"], "Row count mismatch!"
    return all_rows
```

**No duplicate guarantee:**
Internally uses `LIMIT {page_size} OFFSET {(page-1) * page_size}`.
OFFSET is arithmetic — pages never overlap. Always add `ORDER BY` to your SQL.

---

## Logging

### Log format (production JSON)

```json
{
  "event":       "job_done",
  "job_id":      "abc-123",
  "worker_id":   "worker-7f3a",
  "ms":          4821,
  "rows":        84,
  "mode":        "query",
  "request_id":  "f3a9b2c1",
  "level":       "info",
  "timestamp":   "2024-01-15T10:30:04.821Z"
}
```

### Key events to monitor

| Event | Source | Meaning |
|-------|--------|---------|
| `request_completed` | API | Every HTTP request with status + duration_ms |
| `job_submitted` | API | Job pushed to queue |
| `job_started` | Worker | Worker claimed job, DuckDB starting |
| `job_done` | Worker | Query finished, result stored |
| `job_failed` | Worker | Query error — check `error` field |
| `job_requeued_dead_worker` | Worker | Watchdog requeued orphaned job |
| `stream_start` | API | NDJSON stream beginning |
| `stream_complete` | Worker | All rows sent |
| `export_starting` | Worker | S3 Parquet export started |
| `export_complete` | Worker | Parts written to S3 |
| `worker_shutdown_clean` | Worker | Graceful SIGTERM handled |
| `unhandled_exception` | API | Bug — needs investigation |
| `auth_invalid_key` | API | Bad API key — possible attack |

### Useful log queries

```bash
# All errors in last hour
docker logs query-api --since 1h 2>&1 | grep '"level":"error"' | jq .

# Slow queries (>5 seconds)
docker logs query-worker 2>&1 | jq 'select(.ms > 5000) | {job_id, ms, sql_preview: .sql_preview}'

# One full request trace (API + worker)
REQUEST_ID="f3a9b2c1"
docker logs query-api    2>&1 | jq "select(.request_id==\"$REQUEST_ID\")"
docker logs query-worker 2>&1 | jq "select(.request_id==\"$REQUEST_ID\")"

# Cache hit rate (last 100 requests)
docker logs query-api 2>&1 | jq 'select(.event=="request_completed")' | tail -100 \
  | jq -s 'map(select(.cached==true)) | length'

# Jobs requeued (worker crashes)
docker logs query-worker 2>&1 | jq 'select(.event=="job_requeued_dead_worker")'

# Export activity
docker logs query-worker 2>&1 | jq 'select(.event | startswith("export_"))'
```

---

## Monitoring

```bash
# Health
curl http://localhost/api/admin/health

# Live metrics (cache hit rate, running queries, queue depth)
curl http://localhost/api/admin/metrics

# Queue depth per priority
curl http://localhost/api/jobs/admin/queue-depths
# {"high":0,"normal":8,"low":23,"total":31,"recommendation":"Healthy"}

# Redis memory (result cache size)
curl http://localhost/api/jobs/admin/memory

# Recent jobs
curl http://localhost/api/jobs/admin/list?limit=20
```

**When to scale workers:**
```bash
# If queue depth growing and not draining:
docker-compose up --scale worker=8    # add more workers (zero downtime)
# or on OpenShift:
oc scale deployment query-worker --replicas=8
```

---

## OpenShift Deployment

```bash
# Create secrets (never hardcode)
oc create secret generic query-api-secrets \
  --from-literal=s3-bucket=my-bucket \
  --from-literal=aws-access-key-id=AKIA... \
  --from-literal=aws-secret-access-key=... \
  -n your-namespace

# Apply all manifests
oc apply -f openshift/

# Check pods
oc get pods -n your-namespace
# NAME                         READY  STATUS
# redis-xxx                    1/1    Running
# query-api-xxx                1/1    Running
# query-api-yyy                1/1    Running
# query-worker-aaa             1/1    Running  ← 4 workers
# query-worker-bbb             1/1    Running
# query-worker-ccc             1/1    Running
# query-worker-ddd             1/1    Running

# Scale workers on demand
oc scale deployment query-worker --replicas=8 -n your-namespace

# Follow logs
oc logs -f deployment/query-worker -n your-namespace | jq 'select(.level=="error")'
```

---

## Environment Variables — Complete Reference

```bash
# ── App ──────────────────────────────────────────────────────
LOG_LEVEL=INFO                  # DEBUG / INFO / WARNING / ERROR
DEBUG=false                     # true = coloured dev logs, false = JSON prod logs

# ── DuckDB (per worker) ───────────────────────────────────────
DUCKDB_THREADS=4                # threads per query (lower = more parallel queries)
DUCKDB_MEMORY_LIMIT=8GB         # RAM cap per worker (spills to disk beyond this)
DUCKDB_TEMP_DIR=/tmp/duckdb     # spill-to-disk directory

# ── Concurrency ───────────────────────────────────────────────
MAX_CONCURRENT_QUERIES=2        # parallel DuckDB queries per worker (heavy data: 2)
THREAD_POOL_SIZE=4              # must be >= MAX_CONCURRENT_QUERIES
MAX_QUEUE_DEPTH=200             # requests before 503 (per API instance)

# ── Large data guards ─────────────────────────────────────────
BLOCK_SELECT_STAR=true          # block SELECT * on query/stream (allow on export)
MAX_COLUMNS_IN_QUERY=50         # max columns on non-export endpoints

# ── Pagination ────────────────────────────────────────────────
DEFAULT_PAGE_SIZE=1000
MAX_PAGE_SIZE=10000

# ── Cache ────────────────────────────────────────────────────
CACHE_ENABLED=true
CACHE_TTL_SECONDS=300           # 5 min — shared across all jobs with same SQL

# ── Distributed mode ─────────────────────────────────────────
DISTRIBUTED_MODE=true
REDIS_URL=redis://redis:6379/0
JOB_TTL_SECONDS=3600            # how long results stay in Redis
RESULT_SIZE_THRESHOLD_MB=1.0    # results above this → S3 (not Redis)
RESULT_INLINE_MAX_ROWS=5000

# ── Streaming ────────────────────────────────────────────────
STREAM_CHUNK_SIZE=10000         # rows per HTTP chunk
MAX_CONCURRENT_STREAMS=4        # simultaneous streaming connections

# ── S3 export ────────────────────────────────────────────────
EXPORT_ROW_GROUP_SIZE=100000
S3_EXPORT_PREFIX=exports
EXPORT_PRESIGNED_URL_TTL=14400  # 4 hours

# ── S3 / AWS ─────────────────────────────────────────────────
S3_ENABLED=true
S3_BUCKET=my-data-lake
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=              # blank = use IAM role (recommended for OpenShift)
AWS_SECRET_ACCESS_KEY=
# S3_ENDPOINT_URL=http://minio:9000   # MinIO / LocalStack

# ── Security ─────────────────────────────────────────────────
API_KEY_ENABLED=false
API_KEY=your-secret-key         # pass as X-API-Key header
```

---

## Troubleshooting

### Job stuck in "running"
Worker crashed mid-query. Watchdog detects it in 20s and requeues automatically.
```bash
# Check watchdog activity
docker logs query-worker 2>&1 | jq 'select(.event=="job_requeued_dead_worker")'
# Check worker health
docker ps | grep worker
```

### "SELECT * is not allowed"
Expected — use specific column names. For ALL columns use `/api/stream/export` instead.
```bash
# Wrong (blocked):
sql="SELECT * FROM read_parquet('file.parquet')"

# Right (≤50 cols):
sql="SELECT account_id, account_type, closing_balance FROM read_parquet('file.parquet')"

# Right (ALL cols):
curl -X POST "http://localhost/api/stream/export?sql=SELECT * FROM read_parquet('file.parquet')"
```

### Stream ends without _stream_complete
Connection dropped (timeout, network, pod restart). Retry the stream.
```python
for attempt in range(3):
    try:
        result = consume_stream(sql)
        break
    except RuntimeError as e:
        if "Connection dropped" in str(e) and attempt < 2:
            time.sleep(5)
            continue
        raise
```

### Redis out of memory
Results accumulating faster than TTL clears them.
```bash
# Check usage
curl http://localhost/api/jobs/admin/memory

# Options:
# 1. Lower CACHE_TTL_SECONDS (results expire sooner)
# 2. Lower RESULT_SIZE_THRESHOLD_MB (push more to S3)
# 3. Increase Redis maxmemory in docker-compose
```

### Presigned URL expired
URLs expire after `EXPORT_PRESIGNED_URL_TTL` seconds (default 4h).
Resubmit the export job — it will regenerate fresh URLs.

### 503 "Queue full"
API at capacity. Either scale workers or increase MAX_QUEUE_DEPTH.
```bash
docker-compose up --scale worker=8
# or
oc scale deployment query-worker --replicas=8
```

### Worker OOM killed
Query exceeded DUCKDB_MEMORY_LIMIT. DuckDB spills to DUCKDB_TEMP_DIR first,
but if that fills too then it's OOM. Options:
- Increase worker memory limits in docker-compose
- Add WHERE clause to query to reduce data scanned
- Use fewer columns

---

## Redis — Installation & Setup Guide

Redis is **only required when `DISTRIBUTED_MODE=true`** (the async job queue).
If you are using the API in simple sync mode (`/api/execute/sql` only), skip this section.

---

### Option 1 — Docker (Recommended for local dev + quick start)

Already included in `docker-compose.yml`. Just run:

```bash
docker-compose up redis
```

To run Redis standalone without the full stack:
```bash
docker run -d \
  --name redis \
  -p 6379:6379 \
  --restart unless-stopped \
  redis:7-alpine \
  redis-server \
    --maxmemory 2gb \
    --maxmemory-policy allkeys-lru \
    --save 60 1

# Verify
docker exec redis redis-cli ping
# → PONG

# Check memory
docker exec redis redis-cli info memory | grep used_memory_human
```

---

### Option 2 — Linux (bare metal / VM)

**Ubuntu / Debian:**
```bash
# Install
sudo apt-get update
sudo apt-get install -y redis-server

# Configure
sudo nano /etc/redis/redis.conf
# Set these lines:
#   maxmemory 2gb
#   maxmemory-policy allkeys-lru
#   bind 0.0.0.0           ← only if other hosts need to connect
#   requirepass yourpassword  ← recommended in production

# Start + enable on boot
sudo systemctl enable redis-server
sudo systemctl start redis-server
sudo systemctl status redis-server

# Verify
redis-cli ping
# → PONG
```

**RHEL / CentOS / Fedora:**
```bash
sudo dnf install -y redis
sudo systemctl enable redis
sudo systemctl start redis
redis-cli ping
```

---

### Option 3 — OpenShift (Production)

Redis runs as a separate pod. Create these two files and apply them:

**redis-deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: your-namespace
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
        - name: redis
          image: redis:7-alpine
          command:
            - redis-server
            - --maxmemory
            - "2gb"
            - --maxmemory-policy
            - allkeys-lru
            - --save
            - ""          # disable persistence (job results are ephemeral)
          ports:
            - containerPort: 6379
          resources:
            requests:
              memory: "512Mi"
              cpu:    "250m"
            limits:
              memory: "2.5Gi"   # slightly above maxmemory to prevent OOM kill
              cpu:    "1000m"
          livenessProbe:
            exec:
              command: ["redis-cli", "ping"]
            initialDelaySeconds: 10
            periodSeconds: 10
          readinessProbe:
            exec:
              command: ["redis-cli", "ping"]
            initialDelaySeconds: 5
            periodSeconds: 5
```

**redis-service.yaml:**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: your-namespace
spec:
  type: ClusterIP          # internal only — not exposed outside cluster
  selector:
    app: redis
  ports:
    - port: 6379
      targetPort: 6379
```

```bash
# Apply
oc apply -f redis-deployment.yaml -n your-namespace
oc apply -f redis-service.yaml -n your-namespace

# Verify pod is running
oc get pods -l app=redis -n your-namespace

# Test connectivity from inside the cluster
oc exec deployment/redis -- redis-cli ping
# → PONG

# Your API and workers connect via:
# REDIS_URL=redis://redis:6379/0
# ("redis" resolves to the ClusterIP service automatically)
```

---

### Option 4 — AWS ElastiCache (Managed Redis)

If you're already on AWS, use ElastiCache instead of running Redis yourself.

```bash
# Create via CLI
aws elasticache create-cache-cluster \
  --cache-cluster-id smart-parquet-redis \
  --engine redis \
  --cache-node-type cache.t3.medium \
  --num-cache-nodes 1 \
  --region us-east-1

# Get the endpoint
aws elasticache describe-cache-clusters \
  --cache-cluster-id smart-parquet-redis \
  --show-cache-node-info \
  | jq '.CacheClusters[0].CacheNodes[0].Endpoint.Address'

# Set in your .env or OpenShift secret:
REDIS_URL=redis://your-cluster.abc123.use1.cache.amazonaws.com:6379/0
```

**Important:** ElastiCache Redis is only accessible from within the same VPC.
Your API and worker pods must be in the same VPC / subnet.

---

### Option 5 — Redis Cloud (Fully managed, any cloud)

```bash
# 1. Sign up at https://redis.com/try-free/
# 2. Create a free database (30MB free tier)
# 3. Copy the connection string from the dashboard

REDIS_URL=redis://default:yourpassword@redis-12345.c1.us-east-1-2.ec2.cloud.redislabs.com:12345/0
```

---

### Verify Redis Is Working With the API

```bash
# 1. Set REDIS_URL in your .env
echo "REDIS_URL=redis://localhost:6379/0" >> .env
echo "DISTRIBUTED_MODE=true" >> .env

# 2. Start the API
docker-compose up api

# 3. Submit a test job
JOB=$(curl -s -X POST "http://localhost/api/jobs/submit" \
  -G --data-urlencode "sql=SELECT 42 AS answer" \
  | jq -r '.job_id')

echo "Job ID: $JOB"

# 4. Start a worker (in another terminal)
docker-compose up worker

# 5. Poll result
sleep 3
curl -s "http://localhost/api/jobs/$JOB/result" | jq '.data'
# → [{"answer": 42}]  ✅ Redis + worker are connected
```

---

### Redis Memory Sizing Guide

| Workers | Typical load | Recommended maxmemory |
|---------|-------------|----------------------|
| 2-4     | Dev / small  | 512MB                |
| 4-8     | Production   | 2GB                  |
| 8-16    | Heavy load   | 4GB                  |

The API exposes real-time memory usage:
```bash
curl http://localhost/api/jobs/admin/memory
```

If Redis hits `maxmemory`, it uses `allkeys-lru` eviction — oldest cached results
are dropped first. Job metadata is never lost (TTL is 1 hour, much shorter than
result cache).

---

### Common Redis Errors and Fixes

```
Error: redis.exceptions.ConnectionError: Connection refused
Fix:   Redis not running. docker-compose up redis

Error: redis.exceptions.AuthenticationError
Fix:   Add password to REDIS_URL: redis://:yourpassword@localhost:6379/0

Error: LOADING Redis is loading the dataset in memory
Fix:   Redis restarting after crash — wait 10-30s for it to load AOF log

Error: OOM command not allowed when used memory > 'maxmemory'
Fix:   Increase maxmemory in redis.conf or docker-compose, or lower CACHE_TTL_SECONDS
```
