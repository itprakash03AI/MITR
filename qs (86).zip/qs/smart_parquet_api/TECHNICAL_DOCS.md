# Smart Parquet Query API — Technical Documentation

> Version 1.0.0 | DuckDB · FastAPI · Redis · Apache Iceberg

---

## Table of Contents

1. [Overview](#1-overview)
2. [Architecture](#2-architecture)
3. [Project Structure](#3-project-structure)
4. [Core Components](#4-core-components)
   - 4.1 [Application Factory (main.py)](#41-application-factory-mainpy)
   - 4.2 [DuckDB Connection Pool (database.py)](#42-duckdb-connection-pool-databasepy)
   - 4.3 [Query Executor (query_executor.py)](#43-query-executor-query_executorpy)
   - 4.4 [Config Loader (config_loader.py)](#44-config-loader-config_loaderpy)
   - 4.5 [SQL Analyzer (sql_analyzer.py)](#45-sql-analyzer-sql_analyzerpy)
   - 4.6 [Job Queue (job_queue.py)](#46-job-queue-job_queuepy)
   - 4.7 [Streaming (streaming.py)](#47-streaming-streamingpy)
   - 4.8 [S3 Exporter (s3_exporter.py)](#48-s3-exporter-s3_exporterpy)
   - 4.9 [Iceberg Catalog (iceberg.py)](#49-iceberg-catalog-icebergpy)
   - 4.10 [Middleware (middleware.py)](#410-middleware-middlewarepy)
   - 4.11 [Structured Logging (logging.py)](#411-structured-logging-loggingpy)
5. [API Routers](#5-api-routers)
   - 5.1 [Admin Router](#51-admin-router-apiadmin)
   - 5.2 [Generic SQL Executor](#52-generic-sql-executor-apiexecute)
   - 5.3 [Config-Driven Query Router](#53-config-driven-query-router-apiquery)
   - 5.4 [Distributed Job Router](#54-distributed-job-router-apijobs)
   - 5.5 [Streaming & Export Router](#55-streaming--export-router-apistream)
   - 5.6 [Iceberg Catalog Router](#56-iceberg-catalog-router-apiiceberg)
   - 5.7 [GraphQL Endpoint (optional)](#57-graphql-endpoint-optional-graphql)
6. [Worker Process (worker.py)](#6-worker-process-workerpy)
7. [Configuration Reference](#7-configuration-reference)
8. [Data Flow Diagrams](#8-data-flow-diagrams)
9. [Concurrency Model](#9-concurrency-model)
10. [Caching Strategy](#10-caching-strategy)
11. [Large-Data Protection](#11-large-data-protection)
12. [Deployment](#12-deployment)
13. [Adding New Endpoints](#13-adding-new-endpoints)

---

## 1. Overview

Smart Parquet Query API is a **production-grade, config-driven analytical query engine** that exposes Parquet files (local disk or Amazon S3) through a FastAPI HTTP layer backed by DuckDB.

**Key characteristics:**

| Property | Value |
|---|---|
| Query engine | DuckDB (embedded, no JVM) |
| Data sources | Local Parquet, S3 Parquet, Apache Iceberg |
| API framework | FastAPI + Gunicorn/Uvicorn |
| Caching | In-process TTL cache + Redis shared cache |
| Concurrency | Async semaphore + thread pool + request coalescing |
| Distributed mode | Redis job queue + independent worker processes |
| Max concurrent queries | 16 (4 workers × 4 DuckDB queries) |
| Max queued requests | 800 (4 workers × 200 queue depth) |
| Streaming | NDJSON row-by-row streaming for 9M+ row tables |
| Large result export | DuckDB COPY → S3 Parquet parts + presigned URLs |

---

## 2. Architecture

```
                         CLIENT REQUESTS
                               │
                    ┌──────────▼──────────┐
                    │   Nginx (port 80)   │  Round-robin load balancer
                    └──────────┬──────────┘
                               │
          ┌────────────────────┼────────────────────┐
          │                    │                    │
    ┌─────▼────┐         ┌─────▼────┐        ┌─────▼────┐
    │  API #1  │         │  API #2  │        │  API #3  │
    │(Gunicorn)│         │(Gunicorn)│        │(Gunicorn)│
    │          │         │          │        │          │
    │ In-proc  │         │ In-proc  │        │ In-proc  │
    │ DuckDB   │         │ DuckDB   │        │ DuckDB   │
    │ Pool(4)  │         │ Pool(4)  │        │ Pool(4)  │
    └──────────┘         └──────────┘        └──────────┘
          │                    │                    │
          └────────────────────┼────────────────────┘
                    ┌──────────▼──────────┐
                    │    Redis (6379)     │  Job queue + shared result cache
                    │  jobs:high          │
                    │  jobs:normal        │
                    │  jobs:low           │
                    └──────────┬──────────┘
          ┌────────────────────┼────────────────────┐
          │                    │                    │
    ┌─────▼────┐         ┌─────▼────┐        ┌─────▼────┐
    │Worker #1 │         │Worker #2 │        │Worker #N │
    │(DuckDB)  │         │(DuckDB)  │        │(DuckDB)  │
    └──────────┘         └──────────┘        └──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  S3 / Local Parquet  │
                    │  Apache Iceberg      │
                    │  MinIO (dev)         │
                    └─────────────────────┘
```

### Request flow (non-distributed)

```
HTTP Request
    │
    ├─► Middleware (request_id, access log, api_key)
    │
    ├─► Route handler (router.py or config-driven)
    │
    ├─► SQL Analyzer (safety check, SELECT * guard, LIMIT check)
    │
    ├─► QueryExecutor.execute()
    │       │
    │       ├─► TTL Cache check → HIT: return cached result
    │       │
    │       ├─► Queue depth guard → FULL: 503
    │       │
    │       ├─► Request coalescing → DUPLICATE: await same Future
    │       │
    │       ├─► Semaphore acquire (async wait, no CPU)
    │       │
    │       └─► ThreadPoolExecutor → DuckDB query
    │               └─► DuckDB reads Parquet (local/S3/Iceberg)
    │
    └─► JSON response (paginated)
```

---

## 3. Project Structure

```
smart_parquet_api/
├── app/
│   ├── main.py                   # Application factory + lifespan
│   ├── api/
│   │   ├── router.py             # Admin, generic SQL, Iceberg, config-driven routes
│   │   ├── jobs_router.py        # Distributed job queue endpoints
│   │   ├── stream_router.py      # NDJSON streaming + S3 export endpoints
│   │   ├── graphql_schema.py     # Optional Strawberry GraphQL schema
│   │   └── models.py             # Pydantic request/response models
│   └── core/
│       ├── settings.py           # Pydantic Settings (env-driven configuration)
│       ├── database.py           # DuckDB connection pool
│       ├── query_executor.py     # Concurrency: semaphore, cache, coalescing
│       ├── config_loader.py      # queries.yaml → EndpointSpec registry
│       ├── sql_analyzer.py       # SQL safety analysis (SELECT *, LIMIT, etc.)
│       ├── job_queue.py          # Redis job queue client
│       ├── streaming.py          # NDJSON row streaming generator
│       ├── s3_exporter.py        # DuckDB COPY → S3 Parquet export
│       ├── iceberg.py            # PyIceberg catalog bridge
│       ├── middleware.py         # Request ID, access log, API key, error handler
│       └── logging.py            # Structlog setup (JSON prod / console dev)
├── config/
│   └── queries.yaml              # All config-driven endpoint definitions
├── worker.py                     # Standalone distributed worker process
├── requirements.txt              # Python dependencies
├── docker-compose.yml            # Multi-service production deployment
├── .env.example                  # All configurable environment variables
└── TECHNICAL_DOCS.md             # This file
```

---

## 4. Core Components

### 4.1 Application Factory (`main.py`)

**File:** [app/main.py](app/main.py)

The application is created by `create_app()` which:

1. Attaches middleware (GZip, CORS, request ID, access log, API key)
2. Mounts all routers
3. Optionally mounts GraphQL router if `strawberry-graphql` is installed

The `lifespan` async context manager handles startup/shutdown:

```python
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    setup_logging()          # configure structlog
    registry.load()          # parse queries.yaml → endpoint registry
    db_pool.initialize()     # create DuckDB connection pool
    register_all_endpoints(query_router)  # mount config-driven routes
    yield
    db_pool.shutdown()       # close DuckDB connections cleanly
```

**Why lifespan over startup/shutdown events?**
FastAPI's `lifespan` is the recommended pattern since v0.93. It ensures correct ordering and proper cleanup on SIGTERM.

---

### 4.2 DuckDB Connection Pool (`database.py`)

**File:** [app/core/database.py](app/core/database.py)

```python
class DuckDBPool:
    """Thread-safe pool of read-only DuckDB in-memory connections."""
```

**Design decisions:**

- **In-memory connections** (`:memory:`) — all data read from Parquet files; no persistent state needed.
- **Pool size** = `DUCKDB_THREADS` (default 4) — one connection per potential concurrent query.
- **Thread safety** — uses `queue.Queue` (blocking thread-safe FIFO). Connection checkout blocks for up to 30s before timeout.
- **Broken connection recovery** — if an exception occurs during query execution, the connection is closed and replaced with a fresh one.
- **S3 credentials** injected at connection creation time (not per-query).

**Connection lifecycle:**

```
Pool initialized (startup)
    │
    ├── conn[0]: connect(":memory:") + SET threads, memory_limit, S3 creds
    ├── conn[1]: ...
    └── conn[N]: ...

Query arrives
    │
    ├── _pool.get(timeout=30)  ← blocks if all connections in use
    │
    ├── DuckDB query executes (reads Parquet)
    │
    └── _pool.put(conn)  ← returns connection to pool
```

**Dependency injection:**

```python
def get_db_pool() -> DuckDBPool:
    return db_pool   # global singleton

# Used in route handlers:
pool: DuckDBPool = Depends(get_db_pool)
```

---

### 4.3 Query Executor (`query_executor.py`)

**File:** [app/core/query_executor.py](app/core/query_executor.py)

The central concurrency engine. Handles 100+ simultaneous requests safely.

#### TTLCache

```python
class TTLCache:
    """Thread-safe dict with per-entry expiry."""
```

- Lock-protected `dict` mapping `cache_key → (value, expires_at)`
- `get()` — returns `None` if key missing or expired, deletes expired entry
- `set(key, value, ttl)` — stores with `time.monotonic() + ttl` expiry
- Tracks hits/misses for metrics endpoint

#### Concurrency primitives

```python
_thread_pool  = ThreadPoolExecutor(max_workers=settings.thread_pool_size)
_semaphore    = asyncio.Semaphore(settings.max_concurrent_queries)   # lazy
_in_flight    = {}     # cache_key → asyncio.Future (request coalescing)
```

#### `QueryExecutor.execute()` — the full flow

```
Request arrives with SQL
    │
    1. TTL Cache check (thread-safe dict lookup, ~1µs)
    │   └── HIT: return immediately, no DuckDB
    │
    2. Queue depth guard
    │   └── current_waiting >= max_queue_depth: raise OverflowError → 503
    │
    3. Request coalescing (async lock)
    │   ├── cache_key already in _in_flight?
    │   │   └── YES: await the existing Future (0 DuckDB executions)
    │   └── NO: create new Future, register in _in_flight
    │
    4. Semaphore acquire (async wait, 0 CPU)
    │   └── timeout → TimeoutError → 504
    │
    5. DuckDB in thread pool (releases GIL)
    │   ├── COUNT(*) for total_rows
    │   ├── SELECT ... LIMIT ... OFFSET ... for page
    │   └── Build QueryResult
    │
    6. Store in TTL cache
    │
    7. Resolve Future (all coalesced requests receive result)
    │
    └── Return QueryResult
```

#### `QueryExecutor.stream()` — streaming variant

Used for large result sets that bypass the semaphore:

```python
async def stream(self, sql, chunk_size=5000) -> AsyncGenerator[List[Dict], None]:
    loop = asyncio.get_running_loop()
    queue = asyncio.Queue(maxsize=4)   # backpressure: 4 unsent chunks max

    def _producer():
        # Runs in thread pool
        with pool.get_connection() as conn:
            rel = conn.execute(sql)
            while True:
                batch = rel.fetchmany(chunk_size)
                if not batch: break
                asyncio.run_coroutine_threadsafe(queue.put(batch), loop).result()
        asyncio.run_coroutine_threadsafe(queue.put(None), loop).result()

    loop.run_in_executor(_thread_pool, _producer)
    async for chunk in queue:
        yield chunk
```

The `asyncio.Queue(maxsize=4)` creates backpressure: DuckDB stops reading if the client is slow to consume.

#### Metrics

```python
metrics.snapshot()  # returns:
{
    "total_requests":   ...,
    "total_executed":   ...,   # actual DuckDB queries run
    "total_coalesced":  ...,   # requests served from in-flight dedup
    "total_cached":     ...,   # requests served from TTL cache
    "total_rejected":   ...,   # 503s due to queue overflow
    "total_timeouts":   ...,
    "current_waiting":  ...,   # requests waiting for semaphore
    "current_running":  ...,   # DuckDB queries executing right now
    "cache": { "entries": ..., "hits": ..., "hit_rate": ... }
}
```

---

### 4.4 Config Loader (`config_loader.py`)

**File:** [app/core/config_loader.py](app/core/config_loader.py)

Parses `config/queries.yaml` and builds a typed registry of `EndpointSpec` objects.

#### YAML Schema

```yaml
endpoints:
  - id: trial_balance_summary         # unique ID — also used in URL
    path: /trial-balance/summary      # URL path under /api/query/
    method: GET                       # GET | POST
    tags: [trial-balance]             # OpenAPI grouping
    summary: "Summarised trial balance"
    description: "Returns …"

    sources:                          # named data sources
      tb_accounts:
        type: local                   # local | s3 | iceberg
        path: data/tb_accounts.parquet
      tb_transactions:
        type: s3
        path: s3://bucket/tb_transactions.parquet

    parameters:
      - name: fiscal_year
        type: integer                 # integer | float | boolean | string
        required: false
        default: 2024
        description: "Fiscal year filter"
        enum: [2022, 2023, 2024]      # optional allowlist

    query: |
      SELECT a.account_id, SUM(t.debit_amount)
      FROM read_parquet('{tb_accounts}') AS a
      JOIN read_parquet('{tb_transactions}') AS t
        ON a.account_id = t.account_id
      WHERE t.fiscal_year = {fiscal_year}
      GROUP BY a.account_id

    pagination: true
    cache: true
    cache_ttl: 300
```

#### Key classes

**`SourceSpec`** — resolves paths at load time:
- `local` → absolute path relative to project root
- `s3` → returned as-is (DuckDB handles `s3://` URIs via httpfs)
- `iceberg` → stores namespace/table; resolved lazily at query time

**`ParamSpec`** — typed parameter with validation:
- `python_type` property maps YAML type strings → Python types for FastAPI query param generation
- SQL injection protection in `_safe_value()`: numerics unquoted, strings have `'` escaped

**`EndpointSpec.render_query(param_values)`** — substitutes `{source_name}` and `{param_name}` into the SQL template using Python `str.format(**ctx)`.

**`EndpointRegistry`** — singleton dict of `id → EndpointSpec`. Loaded once at startup.

---

### 4.5 SQL Analyzer (`sql_analyzer.py`)

**File:** [app/core/sql_analyzer.py](app/core/sql_analyzer.py)

Inspects SQL **before** DuckDB executes it to prevent accidents on large tables.

#### Checks performed (in order)

| Check | Action | Configurable |
|---|---|---|
| Dangerous keywords (`COPY`, `DROP`, `INSERT`, `ATTACH`, `shell(`) | Block → 400 | No |
| `SELECT *` in column list | Block (or warn) → 400 | `BLOCK_SELECT_STAR` |
| Column count > `MAX_COLUMNS_IN_QUERY` | Block → 400 | `MAX_COLUMNS_IN_QUERY` |
| No `WHERE` clause | Warning (soft) | No |
| No `LIMIT` clause (non-aggregation) | Warning (soft) | No |
| `LIMIT` value > `MAX_PAGE_SIZE` | Block → 400 | `MAX_PAGE_SIZE` |
| Queue routing | Suggests `high/normal/low` based on query characteristics | Thresholds configurable |

#### `SQLAnalysis` result

```python
@dataclass
class SQLAnalysis:
    original_sql:      str
    safe_sql:          str          # same as original (or rewritten if applicable)
    is_safe:           bool
    errors:            List[str]    # hard blocks (caller raises 400)
    warnings:          List[str]    # soft warnings (included in response)
    has_select_star:   bool
    estimated_columns: Optional[int]
    has_where:         bool
    has_limit:         bool
    limit_value:       Optional[int]
    suggested_queue:   str          # "high" | "normal" | "low"
```

#### Queue routing logic

```
If row_hint provided:
    row_hint <= 500k  → "high"
    row_hint <= 3M    → "normal"
    row_hint > 3M     → "low"

Otherwise (from SQL patterns):
    Aggregation (GROUP BY / COUNT / SUM)  → "normal"
    Has WHERE + LIMIT                     → "high"
    No WHERE                              → "low"
    Default                               → "normal"
```

---

### 4.6 Job Queue (`job_queue.py`)

**File:** [app/core/job_queue.py](app/core/job_queue.py)

Redis-backed distributed job queue with shared result caching.

#### Redis key schema

```
job:{id}:status        → "queued" | "running" | "done" | "failed" | "cancelled"
job:{id}:meta          → JSON: sql, timestamps, priority, worker_id, tags, etc.
job:{id}:result        → JSON pointer: {"_cache_ref": "cache:{hash}:result"}
cache:{hash}:result    → Shared result JSON (1 copy regardless of N identical jobs)
jobs:high              → Redis list (LPUSH/BRPOP) of job_ids
jobs:normal            → Redis list
jobs:low               → Redis list
worker:{id}:heartbeat  → "alive" (20s TTL — expires if worker crashes)
job:{id}:lock          → worker_id (20s TTL — used by watchdog)
```

#### `JobQueueClient.submit(job)` — cache check at submit time

```python
# 1. Check shared result cache (same SQL + page + page_size)
cached = await r.get(_key_cache(job.sql_hash))
if cached:
    # Mark job DONE immediately — no worker involved
    pipe.setex(_key_status, TTL, "done")
    pipe.setex(_key_result, TTL, json({"_cache_ref": cache_key}))
    return job.job_id   # returns in <5ms

# 2. No cache hit — push to priority queue
pipe.lpush(_key_queue(job.priority), job.job_id)
```

#### `JobQueueClient.get_result(job_id)` — follows cache pointer

```python
result_raw = await r.get(_key_result(job_id))
result = json.loads(result_raw)

if "_cache_ref" in result:
    # Follow shared cache pointer — don't copy data
    shared_raw = await r.get(result["_cache_ref"])
    result = json.loads(shared_raw)
    result["cache_hit"] = True
```

This means 50 identical queries = 1 copy of data in Redis, not 50.

---

### 4.7 Streaming (`streaming.py`)

**File:** [app/core/streaming.py](app/core/streaming.py)

```python
async def stream_query_ndjson(sql, chunk_size=None) -> AsyncGenerator[bytes, None]:
```

**Memory model:**
- DuckDB reads Parquet in row groups (~1GB page cache maximum)
- This module fetches `chunk_size` rows at a time (default 10,000)
- Each chunk serialised to NDJSON bytes (~25MB for 10k rows × 50 cols)
- Bounded `asyncio.Queue(maxsize=4)` provides backpressure
- **Total memory at any time:** ≤ 5 chunks × ~25MB = ~125MB, regardless of table size

**Producer/consumer pattern:**

```
Thread pool (producer)              Event loop (consumer)
─────────────────────               ─────────────────────
DuckDB.fetchmany(10000)
    → serialize to NDJSON bytes
    → queue.put(chunk_bytes)  ─────► await queue.get()
                                         yield chunk_bytes → HTTP response
DuckDB.fetchmany(10000) ...              ...
    → None sentinel           ─────► break
```

**Last line** is always the completion sentinel:
```json
{"_stream_complete": true, "total_rows": 9000000, "elapsed_ms": 45231}
```

The streaming connection uses a **dedicated thread pool** (`_stream_pool`) separate from the regular query thread pool, so long-running streams don't starve interactive queries.

---

### 4.8 S3 Exporter (`s3_exporter.py`)

**File:** [app/core/s3_exporter.py](app/core/s3_exporter.py)

For results too large for JSON (> `RESULT_SIZE_THRESHOLD_MB`), the worker exports directly to S3 as partitioned Parquet using DuckDB's `COPY TO` statement:

```sql
COPY (
    SELECT ...
) TO 's3://bucket/exports/job-id/'
(
    FORMAT         PARQUET,
    PER_THREAD_OUTPUT TRUE,    -- each DuckDB thread writes its own part file
    ROW_GROUP_SIZE 100000,
    COMPRESSION    SNAPPY
)
```

`PER_THREAD_OUTPUT TRUE` means 4 DuckDB threads write 4 part files simultaneously — no serialisation bottleneck.

After writing, `_list_and_sign()` lists the S3 objects and generates presigned URLs (default 4-hour TTL) for direct client download.

**Result response:**
```json
{
  "export_id": "abc-123",
  "total_rows": 9000000,
  "total_mb": 1840.5,
  "part_count": 4,
  "parts": [
    { "part": 0, "size_mb": 487.3, "url": "https://...", "expires_at": "..." }
  ],
  "how_to_read": {
    "pandas":  "pd.read_parquet('s3://bucket/exports/abc-123/')",
    "duckdb":  "SELECT * FROM read_parquet('s3://bucket/exports/abc-123/*.parquet')"
  }
}
```

---

### 4.9 Iceberg Catalog (`iceberg.py`)

**File:** [app/core/iceberg.py](app/core/iceberg.py)

Bridges Apache Iceberg table metadata → DuckDB `read_parquet()` expressions.

#### Supported catalog types

| Type | Use case | Required setting |
|---|---|---|
| `hadoop` | Read-only from S3 (no catalog service) | `ICEBERG_HADOOP_WAREHOUSE` |
| `glue` | AWS Glue Data Catalog | IAM permissions |
| `rest` | REST catalog (Polaris, Tabular, Nessie REST) | `ICEBERG_REST_URI` |
| `hive` | Hive Metastore | `ICEBERG_HIVE_URI` |
| `nessie` | Project Nessie | `ICEBERG_NESSIE_URI` |

#### Resolution flow

```
IcebergTableResolver.build_duckdb_sql(namespace, table, alias, snapshot_id)
    │
    1. get_iceberg_catalog()           → PyIceberg catalog (LRU-cached)
    │
    2. catalog.load_table(full_name)   → reads v*.metadata.json from S3
    │
    3. table.current_snapshot()        → reads snap-<id>.avro (manifest list)
    │
    4. manifest.fetch_manifest_entry() → reads manifest files → data file paths
    │
    5. Returns:
       read_parquet([
           's3://bucket/data/part-00000.parquet',
           's3://bucket/data/part-00001.parquet'
       ], union_by_name=true)
```

`union_by_name=true` is critical — after schema evolution, files may have columns in different order. DuckDB aligns them by name, not position.

---

### 4.10 Middleware (`middleware.py`)

**File:** [app/core/middleware.py](app/core/middleware.py)

Four middleware layers applied in order:

1. **Request ID** — assigns `X-Request-ID` (from header or generated UUID). Bound to structlog context so every log line for this request carries it.
2. **Access log** — logs method, path, status code, duration_ms. Skips passthrough paths (`/docs`, `/health`, etc.).
3. **API key** (optional) — checks `X-API-Key` header or `?api_key=` query param. Only active if `API_KEY_ENABLED=true`.
4. **Global exception handler** — catches unhandled exceptions, returns structured JSON with `request_id` for correlation.

---

### 4.11 Structured Logging (`logging.py`)

**File:** [app/core/logging.py](app/core/logging.py)

Uses `structlog` for structured, machine-readable logging.

**Production output (JSON):**
```json
{"event":"query_executed","query_id":"a3f9b2","total_rows":50000,"execution_ms":243.7,"level":"info","timestamp":"2024-01-15T10:30:00Z","request_id":"f3a9b2"}
```

**Development output (`DEBUG=true`):**
```
2024-01-15 10:30:00 [info     ] query_executed  query_id=a3f9b2 total_rows=50000 execution_ms=243.7
```

Every log line automatically carries: `request_id`, `method`, `path`, `timestamp`, `level`, `event`.

**Useful grep patterns:**
```bash
# All errors
docker logs api | jq 'select(.level=="error")'

# Slow queries (>5s)
docker logs worker | jq 'select(.execution_ms > 5000)'

# Full trace for one request
docker logs api | jq 'select(.request_id=="f3a9b2")'
```

---

## 5. API Routers

### 5.1 Admin Router (`/api/admin`)

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/admin/health` | Service health + feature flags + concurrency metrics |
| `GET` | `/api/admin/metrics` | Live concurrency and cache counters |
| `GET` | `/api/admin/endpoints` | List all config-driven endpoints from registry |
| `GET` | `/api/admin/cache` | Cache entry count |
| `DELETE` | `/api/admin/cache` | Clear all cached results |

**Health response:**
```json
{
  "status": "ok",
  "version": "1.0.0",
  "features": {
    "s3": false, "iceberg": false, "graphql": true, "generic_sql": true
  },
  "concurrency": {
    "max_concurrent_queries": 2,
    "current_running": 1,
    "current_waiting": 5,
    "total_cached": 1240,
    "cache": { "entries": 42, "hit_rate": 0.83 }
  }
}
```

---

### 5.2 Generic SQL Executor (`/api/execute`)

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/execute/sql` | Execute any SELECT/WITH/EXPLAIN on Parquet |
| `POST` | `/api/execute/sql/stream` | Stream results as NDJSON |
| `POST` | `/api/execute/sql/explain` | Return DuckDB execution plan |
| `POST` | `/api/execute/parquet/schema` | Inspect Parquet file column schema |
| `POST` | `/api/execute/parquet/sample` | Sample N rows from a Parquet file |

**Request body** (`/sql`): plain text SQL string.

**Response** (`/sql`):
```json
{
  "meta": {
    "query_id": "a3f9b2c1",
    "columns": ["account_id", "total_debits"],
    "total_rows": 50000,
    "page": 1,
    "page_size": 1000,
    "total_pages": 50,
    "execution_ms": 243.7,
    "cached": false,
    "coalesced": false
  },
  "data": [
    { "account_id": "ACC-001", "total_debits": 1234567.89 }
  ],
  "warnings": ["No WHERE clause detected..."]
}
```

**Security:** Only `SELECT`, `WITH`, `EXPLAIN` allowed. DDL, DML, `COPY`, `INSTALL`, `LOAD`, shell calls are blocked.

---

### 5.3 Config-Driven Query Router (`/api/query`)

Dynamically generated from `config/queries.yaml`. Each endpoint in the YAML becomes an HTTP route.

**Route generation:**
```python
def register_all_endpoints(app_router: APIRouter) -> None:
    for ep in registry.all():
        handler = _build_handler(ep)   # dynamic function with correct signature
        app_router.add_api_route(path=ep.path, endpoint=handler, ...)
```

`_build_handler()` uses `inspect.Signature` to dynamically inject per-endpoint query parameters into the function signature, so FastAPI generates correct OpenAPI docs for each endpoint.

**Example generated endpoint:**
```
GET /api/query/trial-balance/summary
    ?fiscal_year=2024   (from ParamSpec)
    &page=1
    &pageSize=1000
    &cache=true
    &explain=false
```

---

### 5.4 Distributed Job Router (`/api/jobs`)

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/jobs/submit` | Submit query to Redis queue |
| `GET` | `/api/jobs/{job_id}` | Poll job status |
| `GET` | `/api/jobs/{job_id}/result` | Fetch result (once done) |
| `DELETE` | `/api/jobs/{job_id}` | Cancel queued job |
| `GET` | `/api/jobs/admin/queue-depths` | Jobs waiting in each queue |
| `GET` | `/api/jobs/admin/memory` | Redis memory usage |
| `GET` | `/api/jobs/admin/list` | Recent jobs list |
| `POST` | `/api/jobs/admin/submit-batch` | Submit multiple jobs |

**Submit parameters:**
```
?sql=SELECT ...
&priority=high|normal|low    (default: auto-detected from SQL analyzer)
&page=1
&pageSize=1000
&cache=true
&wait=false                  (wait=true blocks up to 30s)
&callback_url=https://...    (webhook on completion)
&estimated_rows=9000000      (hint for queue routing)
```

**Job statuses:**
- `queued` — waiting in Redis for a worker
- `running` — worker is executing DuckDB query
- `done` — complete, result available
- `failed` — check `error` field
- `cancelled` — cancelled before worker picked it up

---

### 5.5 Streaming & Export Router (`/api/stream`)

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/stream/sql` | Stream query as NDJSON (no SELECT *, max 50 cols) |
| `POST` | `/api/stream/export` | Export as S3 Parquet via job queue (SELECT * allowed) |

**Streaming response format:**
```
{"account_id":"ACC-001","fiscal_year":2024,"debit_amount":1234.56}
{"account_id":"ACC-002","fiscal_year":2024,"debit_amount":2345.67}
...
{"_stream_complete":true,"total_rows":9000000,"elapsed_ms":45231}
```

Headers set for streaming:
```
Content-Type: application/x-ndjson
X-Accel-Buffering: no          (disables nginx buffering)
Transfer-Encoding: chunked
Cache-Control: no-cache
```

**Export** submits a job tagged `mode=export`. The worker detects this tag and uses `S3Exporter.export()` instead of the normal paginated query path. SELECT * is allowed for exports.

---

### 5.6 Iceberg Catalog Router (`/api/iceberg`)

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/iceberg/test-connection` | Step-by-step connection diagnostic |
| `GET` | `/api/iceberg/namespaces` | List all namespaces |
| `GET` | `/api/iceberg/namespaces/{ns}/tables` | List tables in namespace |
| `GET` | `/api/iceberg/namespaces/{ns}/tables/{table}` | Describe table (schema, partitions, snapshot) |
| `GET` | `/api/iceberg/namespaces/{ns}/tables/{table}/snapshots` | List snapshot history |
| `POST` | `/api/iceberg/query` | Execute SQL on Iceberg table |

All endpoints return 503 if `ICEBERG_ENABLED=false`.

**Query endpoint:** SQL uses `{table}` as placeholder, auto-replaced with `read_parquet([...], union_by_name=true)`:
```json
{
  "namespace": "finance",
  "table": "tb_transactions",
  "sql": "SELECT account_id, SUM(debit_amount) FROM {table} GROUP BY account_id",
  "snapshot_id": null,
  "page": 1,
  "page_size": 1000
}
```

---

### 5.7 GraphQL Endpoint (optional) `/graphql`

Only mounted if `strawberry-graphql` is installed (`pip install strawberry-graphql[fastapi]`).

Provides a full GraphQL API with:
- `Query.accounts` — list/filter Chart of Accounts
- `Query.account` — fetch single account by ID
- `Query.transactions` — list/filter journal entries
- `Query.trial_balance` — 3-way JOIN (accounts + transactions + balances)
- `Query.account_with_detail` — nested account + full history
- `Query.pl_rollup` — P&L by entity/period
- `Query.raw_sql` — execute SELECT directly
- `Mutation.clear_cache` / `Mutation.warm_cache`
- `Subscription.stream_query` — WebSocket row streaming

**Column pushdown:** GraphQL resolvers inspect the selected fields and build `SELECT col1, col2` — only the requested columns are read from Parquet.

---

## 6. Worker Process (`worker.py`)

**File:** [worker.py](worker.py)

A standalone asyncio process that polls Redis for jobs and executes them with DuckDB.

### Startup

```bash
python worker.py
```

Environment variables:
```bash
REDIS_URL=redis://localhost:6379/0
WORKER_ID=my-worker-1            # auto-generated if not set
WORKER_QUEUES=jobs:high,jobs:normal,jobs:low   # default: all three
DUCKDB_THREADS=4
DUCKDB_MEMORY_LIMIT=4GB
```

### Main loop

```python
while not _shutdown_requested:
    item = await r.brpop(QUEUES, timeout=5)   # blocking pop (no CPU spin)
    job_id = item[1]

    # Load job metadata
    job = json.loads(await r.get(f"job:{job_id}:meta"))

    # Skip cancelled jobs
    if await r.get(f"job:{job_id}:status") == "cancelled": continue

    # Claim with lock (watchdog uses this to detect dead workers)
    await r.setex(f"job:{job_id}:lock", 20, WORKER_ID)

    # Execute
    if job["tags"].get("mode") == "export":
        result = s3_exporter.export(job_id, job["sql"])
    else:
        result = execute_query(job)   # paginated DuckDB query

    # Store result in shared Redis cache
    await r.setex(f"cache:{sql_hash}:result", CACHE_TTL, json(result))
    await r.setex(f"job:{job_id}:result", JOB_TTL, json({"_cache_ref": ...}))
    await r.setex(f"job:{job_id}:status", JOB_TTL, "done")
```

### Heartbeat & Watchdog

**Heartbeat** (`heartbeat_loop`): every 5s sets `worker:{id}:heartbeat = "alive"` with 20s TTL. If the worker crashes, the key expires after 20s.

**Watchdog** (`watchdog_loop`): every 15s scans all `job:*:lock` keys. If a lock's worker heartbeat has expired, the job is requeued to its original priority queue.

### Graceful shutdown

```python
def _handle_sigterm(signum, frame):
    _shutdown_requested = True

signal.signal(signal.SIGTERM, _handle_sigterm)
signal.signal(signal.SIGINT, _handle_sigterm)
```

When `SIGTERM` received (Kubernetes pod termination, `docker-compose down`), the worker finishes its current query then exits cleanly. If killed mid-query, the watchdog requeues after 20s.

---

## 7. Configuration Reference

All settings are in [app/core/settings.py](app/core/settings.py) and loaded from `.env` via `pydantic-settings`.

### Server

| Variable | Default | Description |
|---|---|---|
| `HOST` | `0.0.0.0` | Bind address |
| `PORT` | `8000` | Listen port |
| `WORKERS` | `4` | Gunicorn worker processes |
| `DEBUG` | `false` | Enable debug mode + coloured console logging |
| `LOG_LEVEL` | `INFO` | Log level (DEBUG/INFO/WARNING/ERROR) |

### DuckDB

| Variable | Default | Description |
|---|---|---|
| `DUCKDB_THREADS` | `4` | Threads per DuckDB query |
| `DUCKDB_MEMORY_LIMIT` | `8GB` | Memory cap per DuckDB connection |
| `DUCKDB_TEMP_DIR` | `/tmp/duckdb` | Spill-to-disk directory |
| `QUERY_TIMEOUT_SECONDS` | `300` | Max query execution time |

### Concurrency

| Variable | Default | Description |
|---|---|---|
| `MAX_CONCURRENT_QUERIES` | `2` | DuckDB queries running simultaneously per worker |
| `THREAD_POOL_SIZE` | `4` | Thread pool workers for DuckDB execution |
| `MAX_QUEUE_DEPTH` | `200` | Max async requests waiting before 503 |

### Pagination & Results

| Variable | Default | Description |
|---|---|---|
| `DEFAULT_PAGE_SIZE` | `1000` | Default rows per page |
| `MAX_PAGE_SIZE` | `10000` | Maximum allowed page size |
| `RESULT_SIZE_THRESHOLD_MB` | `1.0` | Results larger than this go to S3 |
| `RESULT_INLINE_MAX_ROWS` | `5000` | Row count above which result goes to S3 |

### Caching

| Variable | Default | Description |
|---|---|---|
| `CACHE_ENABLED` | `true` | Enable TTL result cache |
| `CACHE_TTL_SECONDS` | `300` | Cache entry lifetime (5 minutes) |

### Large-Data Guards

| Variable | Default | Description |
|---|---|---|
| `BLOCK_SELECT_STAR` | `true` | Block `SELECT *` on query/stream endpoints |
| `MAX_COLUMNS_IN_QUERY` | `50` | Maximum columns allowed in SELECT clause |

### Storage: S3

| Variable | Default | Description |
|---|---|---|
| `S3_ENABLED` | `false` | Enable S3 data source and export |
| `S3_BUCKET` | `` | Default S3 bucket |
| `S3_REGION` | `us-east-1` | AWS region |
| `S3_ENDPOINT_URL` | `` | Custom endpoint (MinIO, LocalStack) |
| `AWS_ACCESS_KEY_ID` | `` | AWS credentials (leave blank for IAM role) |
| `AWS_SECRET_ACCESS_KEY` | `` | AWS credentials |
| `AWS_SESSION_TOKEN` | `` | Temporary credentials token |

### Distributed Mode (Redis)

| Variable | Default | Description |
|---|---|---|
| `DISTRIBUTED_MODE` | `false` | Enable Redis job queue |
| `REDIS_URL` | `redis://localhost:6379/0` | Redis connection URL |
| `JOB_TTL_SECONDS` | `3600` | Job metadata/result retention time |
| `QUEUE_HIGH` | `jobs:high` | High-priority queue name |
| `QUEUE_NORMAL` | `jobs:normal` | Normal queue name |
| `QUEUE_LOW` | `jobs:low` | Low-priority queue name |

### Streaming

| Variable | Default | Description |
|---|---|---|
| `STREAM_CHUNK_SIZE` | `10000` | Rows per NDJSON chunk |
| `MAX_CONCURRENT_STREAMS` | `4` | Parallel streams |

### Iceberg

| Variable | Default | Description |
|---|---|---|
| `ICEBERG_ENABLED` | `false` | Enable Iceberg catalog |
| `ICEBERG_CATALOG_TYPE` | `rest` | Catalog type: `hadoop\|glue\|rest\|hive\|nessie` |
| `ICEBERG_HADOOP_WAREHOUSE` | `` | S3 warehouse path (hadoop catalog) |
| `ICEBERG_REST_URI` | `` | REST catalog URL |
| `ICEBERG_REST_TOKEN` | `` | REST catalog auth token |
| `ICEBERG_GLUE_REGION` | `` | AWS Glue region (defaults to S3_REGION) |
| `ICEBERG_NESSIE_URI` | `` | Nessie API URL |

### Security

| Variable | Default | Description |
|---|---|---|
| `API_KEY_ENABLED` | `false` | Enable API key authentication |
| `API_KEY` | `` | The required API key value |
| `GENERIC_ENDPOINT_ENABLED` | `true` | Enable `/api/execute/sql` endpoint |

---

## 8. Data Flow Diagrams

### Paginated query (cache miss)

```
Client → POST /api/execute/sql
           │
           ▼
     SQL safety check
     (sql_analyzer.analyze)
           │ safe
           ▼
     QueryExecutor.execute(sql, page=1, page_size=1000)
           │
           ├── TTL cache miss
           ├── queue_depth check ok
           ├── _in_flight miss → create Future
           ├── semaphore.acquire() (wait if full)
           │
           ▼
     ThreadPoolExecutor._run_sync()
           │
           ├── SELECT COUNT(*) FROM (...) __count__
           ├── SELECT * FROM (...) __paged__ LIMIT 1000 OFFSET 0
           │
           └── DuckDB reads Parquet columns from disk/S3
           │
           ▼
     QueryResult(columns, rows, total_rows, ...)
           │
           ├── Store in TTL cache (5 min)
           ├── future.set_result(result)
           └── semaphore.release()
           │
           ▼
     {"meta": {...}, "data": [...]}  → HTTP 200
```

### Distributed query (async job)

```
Client → POST /api/jobs/submit?sql=SELECT ...
           │
           ▼
     SQL safety check + queue routing
           │
           ▼
     Redis cache check (sql_hash)
     HIT? → job marked DONE immediately → return job_id
     MISS? → push job_id to jobs:normal (or high/low)
           │
           ▼
     Return {"job_id": "abc-123", "status": "queued"}
           │
     (client polls)
           │
           ▼
     Worker picks up job_id via BRPOP
           │
           ├── execute_query() → DuckDB
           ├── Store result in cache:{hash}:result
           └── Set job:{id}:status = "done"
           │
     Client → GET /api/jobs/abc-123/result
           │
           ▼
     Follow _cache_ref pointer → return JSON
```

---

## 9. Concurrency Model

```
One Gunicorn worker process contains:

  ┌─────────────────────────────────────────────────┐
  │  Event Loop (asyncio)                           │
  │                                                 │
  │  Request 1 ──────────────────────────────────►  │
  │  Request 2 ──── cache hit ──────────────────►  │
  │  Request 3 ──── coalesced ──────────────────►  │
  │  Request 4 ──── semaphore wait ─────────────►  │
  │  ...                                            │
  │  Request 200 ─── semaphore wait ────────────►  │
  │                                                 │
  │  ┌─── Semaphore (max=2) ───────────────────┐   │
  │  │                                         │   │
  │  │  ┌─── Thread Pool (4 threads) ───────┐  │   │
  │  │  │                                   │  │   │
  │  │  │  DuckDB #1: SELECT ... (running)  │  │   │
  │  │  │  DuckDB #2: SELECT ... (running)  │  │   │
  │  │  │  Thread 3: idle                   │  │   │
  │  │  │  Thread 4: idle                   │  │   │
  │  │  └───────────────────────────────────┘  │   │
  │  └─────────────────────────────────────────┘   │
  └─────────────────────────────────────────────────┘
```

**Key insight:** 200 requests can be "in flight" with only 2 DuckDB queries actually running. The other 198 are waiting cheaply in asyncio — no threads, no CPU.

**Capacity formula (for N Gunicorn workers):**

- True parallel DuckDB queries: `N × MAX_CONCURRENT_QUERIES`
- Max queued before 503: `N × MAX_QUEUE_DEPTH`
- Typical deployment (4 workers): 8 parallel + 800 queued

---

## 10. Caching Strategy

Three levels of caching:

### Level 1: In-process TTL cache (TTLCache)
- **Location:** Each API worker process (in-memory Python dict)
- **Scope:** Per-process — not shared between Gunicorn workers
- **TTL:** `CACHE_TTL_SECONDS` (default 5 min)
- **Key:** `SHA256(sql + page + page_size)`
- **Cost:** ~1µs lookup

### Level 2: Redis shared result cache
- **Location:** Redis server (shared by all workers)
- **Scope:** Global — 50 workers, 1 copy of each result
- **Key:** `cache:{sql_hash}:result`
- **TTL:** `CACHE_TTL_SECONDS`
- **Cost:** ~1ms Redis round-trip

### Level 3: Request coalescing
- **Mechanism:** If 10 identical requests arrive while DuckDB is running one, they all await the same `asyncio.Future`. When DuckDB finishes, all 10 receive the result simultaneously.
- **Cost:** 0 extra DuckDB executions

### Cache key design

The cache key includes `sql + page + page_size` — different pages of the same query are cached independently. This allows partial cache warming:

```python
# Warm page 1 only
executor.execute(sql, page=1, page_size=1000, cache=True)

# Future requests for page 1 hit cache
# Future requests for page 2 go to DuckDB
```

---

## 11. Large-Data Protection

### Why it's needed

A table with 9M rows × 1000 columns:
- `SELECT *` → DuckDB reads 72GB from S3 before returning anything
- No LIMIT → result JSON could be 180GB
- 50 concurrent such queries → OOM

### Protection layers (in order)

| Layer | Mechanism | Where |
|---|---|---|
| 1. SQL analysis | Block `SELECT *`, enforce LIMIT, warn on missing WHERE | sql_analyzer.py |
| 2. Column pruning | Explicit column list → DuckDB reads only those cols from Parquet | SQL design in queries.yaml |
| 3. Pagination | All results paginated; max page size `MAX_PAGE_SIZE` (10k) | query_executor.py |
| 4. Semaphore | Max `MAX_CONCURRENT_QUERIES` DuckDB queries at once | query_executor.py |
| 5. Queue depth | Reject with 503 if `MAX_QUEUE_DEPTH` exceeded | query_executor.py |
| 6. Result routing | Results > 1MB → S3 Parquet; Redis only stores pointer | worker.py / job_queue.py |
| 7. Queue priority | Large scans go to `jobs:low` queue; interactive to `jobs:high` | sql_analyzer.py + jobs_router.py |

### Column pruning in Parquet

Parquet is a columnar format. DuckDB reads **only the columns specified in SELECT**:

```sql
-- Reads only 3 columns from a 1000-column file:
SELECT account_id, fiscal_year, debit_amount
FROM read_parquet('s3://bucket/data/transactions.parquet')

-- DuckDB skips the other 997 columns entirely at the I/O level
```

This is why `BLOCK_SELECT_STAR=true` is critical — `SELECT *` forces DuckDB to read all 1000 columns.

---

## 12. Deployment

### Development (single process)

```bash
# Install dependencies
pip install -r requirements.txt

# Copy and configure environment
cp .env.example .env
# Edit .env as needed

# Generate sample Parquet data (optional)
python scripts/generate_sample_data.py

# Run
python app/main.py
# or
uvicorn app.main:app --reload
```

Access at: `http://localhost:8000/docs`

### Production (Docker Compose)

```bash
# Start all services
docker-compose up -d

# Scale workers (zero-downtime)
docker-compose up --scale worker=8 -d

# Scale API servers
docker-compose up --scale api=4 -d

# View logs
docker-compose logs -f worker

# Graceful shutdown (waits for in-flight queries, max 60s)
docker-compose down
```

**Services:**

| Service | Port | Replicas | Description |
|---|---|---|---|
| `nginx` | 80 | 1 | Load balancer |
| `api` | 8000 | 2-4 | FastAPI + Gunicorn |
| `worker` | — | 4-16 | DuckDB query workers |
| `redis` | 6379 | 1 | Job queue + result cache |
| `minio` | 9000/9001 | 1 (dev only) | Local S3 emulation |

### Production (Kubernetes)

```yaml
# Scale workers
kubectl scale deployment query-worker --replicas=10

# Worker env vars
env:
  - name: WORKER_ID
    valueFrom:
      fieldRef:
        fieldPath: metadata.name    # pod name = unique worker ID
  - name: REDIS_URL
    value: redis://redis-service:6379/0
  - name: WORKER_QUEUES
    value: "jobs:high,jobs:normal,jobs:low"
```

Workers are stateless — can be scaled to 0 and back without data loss (jobs persist in Redis).

---

## 13. Adding New Endpoints

The entire API surface is driven by `config/queries.yaml`. No Python code changes needed for new endpoints.

### Step 1: Add to queries.yaml

```yaml
endpoints:
  - id: revenue_by_month            # unique snake_case ID
    path: /revenue/by-month         # URL: /api/query/revenue/by-month
    method: GET
    tags: [revenue]
    summary: "Monthly Revenue Summary"
    description: "Aggregates revenue by entity and fiscal period."

    sources:
      transactions:
        type: local                  # local | s3 | iceberg
        path: data/tb_transactions.parquet
      accounts:
        type: local
        path: data/tb_accounts.parquet

    parameters:
      - name: fiscal_year
        type: integer
        required: false
        default: 2024
        description: "Filter by fiscal year"
      - name: entity
        type: string
        required: false
        default: ""
        description: "Filter by entity code"

    query: |
      SELECT
          t.entity,
          t.period,
          SUM(t.credit_amount - t.debit_amount) AS net_revenue
      FROM read_parquet('{transactions}') AS t
      JOIN read_parquet('{accounts}') AS a ON t.account_id = a.account_id
      WHERE a.account_type = 'Revenue'
        AND t.fiscal_year = {fiscal_year}
        {%- if entity %}
        AND t.entity = '{entity}'
        {%- endif %}
      GROUP BY t.entity, t.period
      ORDER BY t.period

    pagination: true
    cache: true
    cache_ttl: 600              # 10 min cache
```

### Step 2: Restart (or hot-reload)

```bash
# Development (auto-reload on file change):
uvicorn app.main:app --reload

# Production:
docker-compose restart api
```

The new endpoint is immediately available at `GET /api/query/revenue/by-month` with full OpenAPI documentation.

### Tips

- **Use `{source_name}`** in SQL to reference sources — they are resolved to full paths at query time.
- **Numeric parameters** are injected without quotes: `{fiscal_year}` → `2024`
- **String parameters** have single quotes escaped: `{entity}` → the value with `'` → `''`
- **Test SQL first** via `POST /api/execute/sql` before adding to YAML.
- **Check query plan** via `POST /api/execute/sql/explain` to verify column pruning is working.

---

*Generated: 2026-03-06 | Smart Parquet Query API v1.0.0*
