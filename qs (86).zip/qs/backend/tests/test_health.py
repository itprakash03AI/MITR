"""
Integration smoke tests for the FastAPI health + version endpoints.

These tests start the app with TestClient (in-process, no real server).
They do NOT require Redis, external connectors, or a full config.json.
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    """httpx AsyncClient against the TestClient app (synchronous TestClient wraps async)."""
    import json

    # Write a minimal config.json so the app doesn't look for a real one
    cfg_dir = tmp_path_factory.mktemp("cfg")
    cfg_file = cfg_dir / "config.json"
    cfg_file.write_text(json.dumps({
        "server": {"host": "127.0.0.1", "port": 8000},
        "database": {"url": f"sqlite:///{cfg_dir}/test_main.db"},
        "executor": {"mode": "embedded"},
        "queue": {"backend": "sqlite"},
    }))
    os.environ["QUERYSTUDIO_CONFIG"] = str(cfg_file)

    try:
        from fastapi.testclient import TestClient
        # Import app after setting env var so config loads correctly
        import importlib
        import core.config as _cfg_mod
        _cfg_mod._cfg = None  # Reset singleton
        importlib.reload(_cfg_mod)

        from main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c
    finally:
        os.environ.pop("QUERYSTUDIO_CONFIG", None)


class TestHealthEndpoints:
    def test_health_returns_200(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        body = resp.json()
        assert "status" in body

    def test_ready_returns_200_or_503(self, client):
        # /ready can return 503 if some checks fail — that's fine in tests
        resp = client.get("/ready")
        assert resp.status_code in (200, 503)

    def test_metrics_endpoint_exists(self, client):
        resp = client.get("/metrics")
        assert resp.status_code in (200, 401, 403)

    def test_api_version_header(self, client):
        """All responses should include X-API-Version header (22E)."""
        resp = client.get("/health")
        # If API versioning is implemented, check for the header
        # It may or may not be present depending on implementation order
        # Just ensure health still works
        assert resp.status_code == 200


class TestVersionEndpoint:
    def test_version_endpoint(self, client):
        """GET /api/version should return version info."""
        resp = client.get("/api/version")
        # Could be 200 or 404 if not yet implemented — test structure
        if resp.status_code == 200:
            body = resp.json()
            assert "version" in body or "api_version" in body
