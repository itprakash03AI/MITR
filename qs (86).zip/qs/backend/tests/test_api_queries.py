"""
Integration tests for query/file/execution endpoints.

Covers:
  GET  /api/files
  POST /api/queries  (save a query)
  GET  /api/queries
  GET  /api/queries/{id}
  DELETE /api/queries/{id}
  GET  /api/executions
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

# Minimal saved-query payload (no actual file needed)
_QUERY_PAYLOAD = {
    "name": "test_query",
    "description": "integration test query",
    "query_config": {
        "files": [],
        "joins": [],
        "columns": [],
        "filters": [],
        "sort": [],
        "limit": 100,
    },
    "connection_id": None,
    "is_favorite": False,
}


class TestFilesEndpoint:
    def test_list_files_returns_list(self, api_client):
        """GET /api/files returns a list (may be empty)."""
        resp = api_client.get("/api/files")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestSavedQueries:
    def test_list_queries_empty(self, api_client):
        """GET /api/queries returns a list."""
        resp = api_client.get("/api/queries")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_save_query(self, api_client):
        """POST /api/queries saves a query and returns id + name."""
        resp = api_client.post("/api/queries", json=_QUERY_PAYLOAD)
        assert resp.status_code == 200
        body = resp.json()
        assert "id" in body
        assert body["name"] == "test_query"

    def test_save_query_missing_name(self, api_client):
        """POST /api/queries without name → 422."""
        resp = api_client.post("/api/queries", json={"query_config": {}})
        assert resp.status_code == 422

    def test_get_saved_query(self, api_client):
        """POST then GET /api/queries/{id} returns the saved query."""
        create_resp = api_client.post(
            "/api/queries", json={**_QUERY_PAYLOAD, "name": "get_test"}
        )
        assert create_resp.status_code == 200
        qid = create_resp.json()["id"]

        get_resp = api_client.get(f"/api/queries/{qid}")
        assert get_resp.status_code == 200
        assert get_resp.json()["id"] == qid

    def test_get_query_not_found(self, api_client):
        """GET /api/queries/99999 → 404."""
        resp = api_client.get("/api/queries/99999")
        assert resp.status_code == 404

    def test_delete_query(self, api_client):
        """DELETE /api/queries/{id} succeeds (soft-delete: marks inactive)."""
        create_resp = api_client.post(
            "/api/queries", json={**_QUERY_PAYLOAD, "name": "delete_test"}
        )
        qid = create_resp.json()["id"]

        del_resp = api_client.delete(f"/api/queries/{qid}")
        assert del_resp.status_code == 200

    def test_update_query(self, api_client):
        """PUT /api/queries/{id} updates the query name."""
        create_resp = api_client.post(
            "/api/queries", json={**_QUERY_PAYLOAD, "name": "before_update"}
        )
        qid = create_resp.json()["id"]

        put_resp = api_client.put(
            f"/api/queries/{qid}",
            json={**_QUERY_PAYLOAD, "name": "after_update"},
        )
        assert put_resp.status_code == 200
        assert put_resp.json()["name"] == "after_update"

    def test_list_queries_contains_saved(self, api_client):
        """A saved query appears in GET /api/queries."""
        create_resp = api_client.post(
            "/api/queries", json={**_QUERY_PAYLOAD, "name": "list_test_unique_xyz"}
        )
        qid = create_resp.json()["id"]

        list_resp = api_client.get("/api/queries")
        ids = [q["id"] for q in list_resp.json()]
        assert qid in ids


class TestExecutions:
    def test_list_executions_returns_list(self, api_client):
        """GET /api/executions returns a list (may be empty)."""
        resp = api_client.get("/api/executions")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_execution_not_found(self, api_client):
        """GET /api/executions/nonexistent → 404."""
        resp = api_client.get("/api/executions/nonexistent-id-00000")
        assert resp.status_code == 404
