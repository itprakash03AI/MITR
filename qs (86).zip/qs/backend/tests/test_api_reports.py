"""
Integration tests for /api/reports/* endpoints.

Uses api_client (auth.type=none — guest admin, all accessible).
Reports require a saved_query_id — we create one as a module-level fixture.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

_QUERY_PAYLOAD = {
    "name": "_report_test_base_query",
    "query_config": {"files": [], "joins": [], "columns": [], "filters": [], "sort": [], "limit": 100},
    "connection_id": None,
    "is_favorite": False,
}


@pytest.fixture(scope="module")
def saved_query_id(api_client):
    """Create a saved query (visual query) for use as report source."""
    resp = api_client.post("/api/queries", json=_QUERY_PAYLOAD)
    assert resp.status_code == 200, f"Failed to create base query: {resp.text}"
    return resp.json()["id"]


def _report_payload(saved_query_id: int, name: str = "Test Report") -> dict:
    return {
        "name": name,
        "description": "Created by integration test",
        "saved_query_id": saved_query_id,
        "is_public": True,
        "parameters": [],
    }


class TestListReports:
    def test_list_reports_returns_list(self, api_client):
        """GET /api/reports returns a list."""
        resp = api_client.get("/api/reports")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestCreateReport:
    def test_create_report(self, api_client, saved_query_id):
        """POST /api/reports creates a report with status 201."""
        resp = api_client.post("/api/reports", json=_report_payload(saved_query_id))
        assert resp.status_code == 201
        body = resp.json()
        assert "id" in body
        assert body["name"] == "Test Report"

    def test_create_report_missing_name(self, api_client):
        """POST /api/reports without name → 422."""
        resp = api_client.post("/api/reports", json={"saved_query_id": 1})
        assert resp.status_code == 422

    def test_create_report_no_source(self, api_client):
        """POST /api/reports without query ID → 400."""
        resp = api_client.post("/api/reports", json={"name": "NoSource"})
        assert resp.status_code == 400


class TestGetReport:
    def test_get_report_not_found(self, api_client):
        """GET /api/reports/99999 → 404."""
        resp = api_client.get("/api/reports/99999")
        assert resp.status_code == 404

    def test_create_then_get(self, api_client, saved_query_id):
        """POST then GET /api/reports/{id} returns the report."""
        create_resp = api_client.post(
            "/api/reports",
            json=_report_payload(saved_query_id, "Get Test Report"),
        )
        assert create_resp.status_code == 201
        rid = create_resp.json()["id"]

        get_resp = api_client.get(f"/api/reports/{rid}")
        assert get_resp.status_code == 200
        assert get_resp.json()["id"] == rid
        assert get_resp.json()["name"] == "Get Test Report"


class TestUpdateReport:
    def test_update_report_name(self, api_client, saved_query_id):
        """PUT /api/reports/{id} updates the name."""
        create_resp = api_client.post(
            "/api/reports",
            json=_report_payload(saved_query_id, "Before Update"),
        )
        rid = create_resp.json()["id"]

        put_resp = api_client.put(
            f"/api/reports/{rid}",
            json={"name": "After Update"},
        )
        assert put_resp.status_code == 200
        assert put_resp.json()["name"] == "After Update"

    def test_update_report_not_found(self, api_client):
        """PUT /api/reports/99999 → 404."""
        resp = api_client.put("/api/reports/99999", json={"name": "x"})
        assert resp.status_code == 404


class TestDeleteReport:
    def test_delete_report(self, api_client, saved_query_id):
        """DELETE /api/reports/{id} succeeds."""
        create_resp = api_client.post(
            "/api/reports",
            json=_report_payload(saved_query_id, "To Delete"),
        )
        assert create_resp.status_code == 201
        rid = create_resp.json()["id"]

        del_resp = api_client.delete(f"/api/reports/{rid}")
        assert del_resp.status_code == 200

    def test_delete_report_not_found(self, api_client):
        """DELETE /api/reports/99999 → 404."""
        resp = api_client.delete("/api/reports/99999")
        assert resp.status_code == 404


class TestReportSourceInfo:
    def test_source_info_endpoint(self, api_client, saved_query_id):
        """GET /api/reports/{id}/source-info returns info."""
        create_resp = api_client.post(
            "/api/reports",
            json=_report_payload(saved_query_id, "Source Info Test"),
        )
        rid = create_resp.json()["id"]

        resp = api_client.get(f"/api/reports/{rid}/source-info")
        assert resp.status_code in (200, 400, 404)


class TestConnectorMatrix:
    def test_connector_matrix(self, api_client):
        """GET /api/reports/connector-matrix returns matrix info."""
        resp = api_client.get("/api/reports/connector-matrix")
        assert resp.status_code == 200


class TestReportHistory:
    def test_report_history_endpoint(self, api_client, saved_query_id):
        """GET /api/reports/{id}/history returns list."""
        create_resp = api_client.post(
            "/api/reports",
            json=_report_payload(saved_query_id, "History Test"),
        )
        rid = create_resp.json()["id"]

        resp = api_client.get(f"/api/reports/{rid}/history")
        assert resp.status_code == 200
        body = resp.json()
        # Response may be a list or a dict with an "executions" key
        assert isinstance(body, list) or isinstance(body.get("executions"), list)
