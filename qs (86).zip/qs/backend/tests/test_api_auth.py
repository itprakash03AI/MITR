"""
Integration tests for /auth/* endpoints (auth.type=none — guest admin).

Uses api_client only. authed_local_client tests are in test_api_auth_local.py
to avoid global config state conflicts between the two fixture types.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


class TestAuthConfig:
    def test_auth_config_none(self, api_client):
        """GET /auth/config returns type=none when auth is disabled."""
        resp = api_client.get("/auth/config")
        assert resp.status_code == 200
        body = resp.json()
        assert body["type"] == "none"
        assert "domain" in body


class TestWhoami:
    def test_me_guest_no_auth(self, api_client):
        """GET /auth/me with no auth header returns guest user when auth.type=none."""
        resp = api_client.get("/auth/me")
        assert resp.status_code == 200
        body = resp.json()
        assert "username" in body or "is_admin" in body


class TestLogout:
    def test_logout_no_token(self, api_client):
        """POST /auth/logout without a token still returns 200 (idempotent)."""
        resp = api_client.post("/auth/logout")
        assert resp.status_code == 200
