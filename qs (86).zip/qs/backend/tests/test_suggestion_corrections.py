"""
Tests for Suggestion Corrections — Smart Agg + Join Feedback.

Tests both database-level CRUD and API endpoints.
"""
import json
import pytest


# ── Database-level tests (using api_client fixture to get a running app) ──────


class TestSuggestionCorrectionModel:
    """Test SuggestionCorrection DB model and DatabaseManager methods."""

    def test_save_agg_correction_creates_row(self, api_client):
        """POST a new agg correction, verify it appears in GET."""
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "agg",
            "context_key": "trade_amount",
            "corrected_value": "AVG",
            "original_value": "SUM",
            "context_extra": "DOUBLE",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["saved"] is True
        assert data["correction"]["context_key"] == "trade_amount"
        assert data["correction"]["corrected_value"] == "AVG"
        assert data["correction"]["use_count"] == 1

    def test_save_agg_correction_upserts(self, api_client):
        """Saving same context_key again should increment use_count."""
        # First save
        api_client.post("/api/suggest/correction", json={
            "correction_type": "agg",
            "context_key": "interest_rate",
            "corrected_value": "MAX",
            "original_value": "AVG",
        })
        # Second save with different corrected_value
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "agg",
            "context_key": "interest_rate",
            "corrected_value": "MIN",
            "original_value": "AVG",
        })
        data = resp.json()
        assert data["saved"] is True
        assert data["correction"]["corrected_value"] == "MIN"
        assert data["correction"]["use_count"] == 2

    def test_save_join_correction(self, api_client):
        """Save a join correction with JSON conditions."""
        conditions = [{"leftColumn": "customer_id", "rightColumn": "id"}]
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "join",
            "context_key": "customers||orders",
            "corrected_value": json.dumps(conditions),
            "original_value": "auto-matched",
            "context_extra": "1",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["saved"] is True
        parsed = json.loads(data["correction"]["corrected_value"])
        assert parsed[0]["leftColumn"] == "customer_id"

    def test_invalid_correction_type_rejected(self, api_client):
        """correction_type must be 'agg' or 'join'."""
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "invalid",
            "context_key": "foo",
            "corrected_value": "bar",
        })
        assert resp.status_code == 422

    def test_get_agg_corrections(self, api_client):
        """GET /api/suggest/corrections/agg returns agg corrections."""
        # Ensure at least one exists
        api_client.post("/api/suggest/correction", json={
            "correction_type": "agg",
            "context_key": "test_balance",
            "corrected_value": "SUM",
        })
        resp = api_client.get("/api/suggest/corrections/agg")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data["corrections"], list)
        assert any(c["context_key"] == "test_balance" for c in data["corrections"])

    def test_get_join_corrections(self, api_client):
        """GET /api/suggest/corrections/join returns join corrections."""
        resp = api_client.get("/api/suggest/corrections/join")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data["corrections"], list)

    def test_agg_corrections_not_in_join_results(self, api_client):
        """Agg corrections should not appear in join results and vice versa."""
        resp_agg = api_client.get("/api/suggest/corrections/agg")
        resp_join = api_client.get("/api/suggest/corrections/join")
        agg_keys = {c["context_key"] for c in resp_agg.json()["corrections"]}
        join_keys = {c["context_key"] for c in resp_join.json()["corrections"]}
        assert agg_keys.isdisjoint(join_keys) or len(agg_keys) == 0 or len(join_keys) == 0


class TestSuggestionCorrectionAdmin:
    """Test admin endpoints for suggestion corrections."""

    def test_get_config(self, api_client):
        """GET /api/admin/suggestion-corrections/config returns config."""
        resp = api_client.get("/api/admin/suggestion-corrections/config")
        assert resp.status_code == 200
        data = resp.json()
        assert "enabled" in data
        assert "max_corrections" in data
        assert "agg_pattern_priority" in data
        assert "join_correction_priority" in data
        assert "retention_days" in data

    def test_set_config(self, api_client):
        """PUT /api/admin/suggestion-corrections/config updates a flag."""
        resp = api_client.put("/api/admin/suggestion-corrections/config", json={
            "max_corrections": 500,
        })
        assert resp.status_code == 200
        assert resp.json()["updated"]["max_corrections"] == 500

    def test_set_config_rejects_invalid_keys(self, api_client):
        """PUT with unknown keys returns 400."""
        resp = api_client.put("/api/admin/suggestion-corrections/config", json={
            "unknown_key": True,
        })
        assert resp.status_code == 400

    def test_list_all_corrections(self, api_client):
        """GET /api/admin/suggestion-corrections returns all corrections."""
        resp = api_client.get("/api/admin/suggestion-corrections")
        assert resp.status_code == 200
        data = resp.json()
        assert "corrections" in data
        assert "total" in data

    def test_list_corrections_by_type(self, api_client):
        """GET /api/admin/suggestion-corrections?correction_type=agg filters."""
        resp = api_client.get("/api/admin/suggestion-corrections?correction_type=agg")
        assert resp.status_code == 200
        for c in resp.json()["corrections"]:
            assert c["correction_type"] == "agg"

    def test_delete_correction(self, api_client):
        """Create then delete a correction."""
        # Create
        create_resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "agg",
            "context_key": "delete_me_col",
            "corrected_value": "MAX",
        })
        corr_id = create_resp.json()["correction"]["id"]
        # Delete
        del_resp = api_client.delete(f"/api/admin/suggestion-corrections/{corr_id}")
        assert del_resp.status_code == 200
        assert del_resp.json()["deleted"] is True
        # Verify gone
        del_resp2 = api_client.delete(f"/api/admin/suggestion-corrections/{corr_id}")
        assert del_resp2.status_code == 404

    def test_delete_nonexistent_returns_404(self, api_client):
        """Deleting a non-existent correction returns 404."""
        resp = api_client.delete("/api/admin/suggestion-corrections/99999")
        assert resp.status_code == 404
