"""
Integration tests for /api/connections/* endpoints.

Uses api_client (auth.type=none — all endpoints accessible as guest admin).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

# Minimal local connection config for creation tests
_LOCAL_CONN = {
    "name": "test_local_conn",
    "connection_type": "local",
    "config": {"base_path": "/tmp"},
}

_S3_CONN = {
    "name": "test_s3_conn",
    "connection_type": "s3",
    "config": {
        "bucket_name": "my-test-bucket",
        "region_name": "us-east-1",
        "auth_mode": "keys",
        "aws_access_key_id": "AKIAIOSFODNN7EXAMPLE",
        "aws_secret_access_key": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    },
}


class TestListConnections:
    def test_list_connections_returns_list(self, api_client):
        """GET /api/connections returns a JSON list."""
        resp = api_client.get("/api/connections")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestCreateConnection:
    def test_create_local_connection(self, api_client):
        """POST /api/connections creates a local connection."""
        resp = api_client.post("/api/connections", json=_LOCAL_CONN)
        assert resp.status_code == 200
        body = resp.json()
        assert "id" in body
        assert body["name"] == "test_local_conn"
        assert body["connection_type"] == "local"

    def test_create_connection_missing_name(self, api_client):
        """POST /api/connections without name → 422."""
        resp = api_client.post(
            "/api/connections",
            json={"connection_type": "local", "config": {}},
        )
        assert resp.status_code == 422

    def test_create_connection_invalid_type(self, api_client):
        """POST /api/connections with invalid type → 422."""
        resp = api_client.post(
            "/api/connections",
            json={"name": "x", "connection_type": "invalid_type", "config": {}},
        )
        assert resp.status_code == 422


class TestGetConnection:
    def test_get_connection_not_found(self, api_client):
        """GET /api/connections/{id} for non-existent id → 404."""
        resp = api_client.get("/api/connections/99999")
        assert resp.status_code == 404

    def test_create_then_get(self, api_client):
        """POST then GET /api/connections/{id} round-trips correctly."""
        create_resp = api_client.post(
            "/api/connections",
            json={**_LOCAL_CONN, "name": "get_test_conn"},
        )
        assert create_resp.status_code == 200
        conn_id = create_resp.json()["id"]

        get_resp = api_client.get(f"/api/connections/{conn_id}")
        assert get_resp.status_code == 200
        assert get_resp.json()["id"] == conn_id
        assert get_resp.json()["name"] == "get_test_conn"


class TestUpdateConnection:
    def test_update_connection_name(self, api_client):
        """PUT /api/connections/{id} updates name."""
        create_resp = api_client.post(
            "/api/connections",
            json={**_LOCAL_CONN, "name": "update_me"},
        )
        conn_id = create_resp.json()["id"]

        put_resp = api_client.put(
            f"/api/connections/{conn_id}",
            json={**_LOCAL_CONN, "name": "updated_name"},
        )
        assert put_resp.status_code == 200
        assert put_resp.json()["name"] == "updated_name"

    def test_update_connection_not_found(self, api_client):
        """PUT /api/connections/99999 → 404."""
        resp = api_client.put(
            "/api/connections/99999",
            json=_LOCAL_CONN,
        )
        assert resp.status_code == 404


class TestDeleteConnection:
    def test_delete_connection(self, api_client):
        """DELETE /api/connections/{id} removes the connection."""
        create_resp = api_client.post(
            "/api/connections",
            json={**_LOCAL_CONN, "name": "delete_me"},
        )
        conn_id = create_resp.json()["id"]

        del_resp = api_client.delete(f"/api/connections/{conn_id}")
        assert del_resp.status_code == 200

        # Verify gone
        get_resp = api_client.get(f"/api/connections/{conn_id}")
        assert get_resp.status_code == 404

    def test_delete_not_found(self, api_client):
        """DELETE /api/connections/99999 → 404."""
        resp = api_client.delete("/api/connections/99999")
        assert resp.status_code == 404


class TestTestConnection:
    def test_test_connection_endpoint_exists(self, api_client):
        """POST /api/connections/test returns 200 or connection error (not 404/405)."""
        resp = api_client.post(
            "/api/connections/test",
            json=_LOCAL_CONN,
        )
        # May succeed (local) or fail (missing path) — never 404/405
        assert resp.status_code in (200, 400, 422, 500)
