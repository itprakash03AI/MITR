"""
Phase 60 — Delivery & Alerts tests

Tests for:
  - ReportSubscription / SubscriptionDelivery models
  - Subscription CRUD (DB methods)
  - Delivery engine (unit tests with mocks)
  - Subscription API endpoints (integration)
  - Alert auto-evaluation
  - Config defaults
"""
from __future__ import annotations

import secrets
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch

import pytest

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def db():
    """Create a fresh temp-file DatabaseManager for each test."""
    from core.database import DatabaseManager
    import tempfile, os
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    mgr = DatabaseManager(db_url=f"sqlite:///{path}")
    yield mgr
    try:
        os.unlink(path)
    except OSError:
        pass


@pytest.fixture
def sample_sub(db):
    """Create a sample subscription and return it."""
    return db.create_subscription(
        report_id=1,
        report_type="business_report",
        name="Daily Sales Report",
        created_by="alice",
        recipient_emails=["alice@corp.com", "bob@corp.com"],
        frequency="0 8 * * *",
        timezone="UTC",
        output_format="csv",
        is_active=True,
        next_send_at=datetime.now(timezone.utc) + timedelta(hours=1),
        unsubscribe_token=secrets.token_urlsafe(32),
    )


# ── Database Model Tests ─────────────────────────────────────────────────────


class TestSubscriptionCRUD:
    """Test DatabaseManager subscription methods."""

    def test_create_subscription(self, db):
        sub = db.create_subscription(
            report_id=42,
            report_type="report",
            name="Weekly Finance",
            created_by="admin",
            recipient_emails=["finance@corp.com"],
            frequency="0 8 * * 1",
            timezone="US/Eastern",
            output_format="excel",
            is_active=True,
            next_send_at=datetime(2026, 4, 1, 12, 0, tzinfo=timezone.utc),
            unsubscribe_token="test-token-123",
        )
        assert sub["id"] is not None
        assert sub["report_id"] == 42
        assert sub["name"] == "Weekly Finance"
        assert sub["created_by"] == "admin"
        assert len(sub["recipient_emails"]) == 1
        assert sub["output_format"] == "excel"
        assert sub["is_active"] is True
        assert sub["unsubscribe_token"] == "test-token-123"

    def test_get_subscription(self, db, sample_sub):
        fetched = db.get_subscription(sample_sub["id"])
        assert fetched is not None
        assert fetched["name"] == "Daily Sales Report"
        assert fetched["created_by"] == "alice"

    def test_get_subscription_not_found(self, db):
        assert db.get_subscription(9999) is None

    def test_list_subscriptions_by_creator(self, db, sample_sub):
        subs = db.list_subscriptions(created_by="alice")
        assert len(subs) == 1
        assert subs[0]["name"] == "Daily Sales Report"

    def test_list_subscriptions_by_report(self, db, sample_sub):
        subs = db.list_subscriptions(report_id=1)
        assert len(subs) == 1

    def test_list_subscriptions_empty(self, db):
        subs = db.list_subscriptions(created_by="nobody")
        assert len(subs) == 0

    def test_update_subscription(self, db, sample_sub):
        updated = db.update_subscription(sample_sub["id"], name="Updated Name", output_format="csv")
        assert updated["name"] == "Updated Name"
        assert updated["output_format"] == "csv"

    def test_update_subscription_not_found(self, db):
        assert db.update_subscription(9999, name="X") is None

    def test_delete_subscription(self, db, sample_sub):
        assert db.delete_subscription(sample_sub["id"]) is True
        assert db.get_subscription(sample_sub["id"]) is None

    def test_delete_subscription_not_found(self, db):
        assert db.delete_subscription(9999) is False

    def test_get_by_unsubscribe_token(self, db, sample_sub):
        token = sample_sub["unsubscribe_token"]
        fetched = db.get_subscription_by_unsubscribe_token(token)
        assert fetched is not None
        assert fetched["id"] == sample_sub["id"]

    def test_get_by_unsubscribe_token_not_found(self, db):
        assert db.get_subscription_by_unsubscribe_token("invalid-token") is None


class TestPendingSubscriptions:
    """Test the get_pending_subscriptions query."""

    def test_get_pending_before_cutoff(self, db):
        now = datetime.now(timezone.utc)
        # Sub 1: due in the past → should be returned
        db.create_subscription(
            report_id=1, report_type="report", name="Past Due",
            created_by="admin", recipient_emails=["a@b.com"],
            frequency="0 * * * *", output_format="csv", is_active=True,
            next_send_at=now - timedelta(minutes=5),
            unsubscribe_token=secrets.token_urlsafe(16),
        )
        # Sub 2: due in the future → should NOT be returned
        db.create_subscription(
            report_id=2, report_type="report", name="Future",
            created_by="admin", recipient_emails=["b@b.com"],
            frequency="0 * * * *", output_format="csv", is_active=True,
            next_send_at=now + timedelta(hours=2),
            unsubscribe_token=secrets.token_urlsafe(16),
        )
        # Sub 3: inactive → should NOT be returned
        db.create_subscription(
            report_id=3, report_type="report", name="Inactive",
            created_by="admin", recipient_emails=["c@b.com"],
            frequency="0 * * * *", output_format="csv", is_active=False,
            next_send_at=now - timedelta(minutes=10),
            unsubscribe_token=secrets.token_urlsafe(16),
        )

        pending = db.get_pending_subscriptions(before=now)
        assert len(pending) == 1
        assert pending[0]["name"] == "Past Due"


class TestSubscriptionDeliveryRecords:
    """Test delivery record creation and listing."""

    def test_record_and_list_deliveries(self, db, sample_sub):
        sub_id = sample_sub["id"]
        db.record_subscription_delivery(
            subscription_id=sub_id,
            recipient_email="alice@corp.com",
            status="sent",
            sent_at=datetime.now(timezone.utc),
            file_size_bytes=12345,
        )
        db.record_subscription_delivery(
            subscription_id=sub_id,
            recipient_email="bob@corp.com",
            status="failed",
            error_message="SMTP timeout",
        )

        records = db.list_subscription_deliveries(sub_id)
        assert len(records) == 2
        statuses = {r["status"] for r in records}
        assert "sent" in statuses
        assert "failed" in statuses


# ── Delivery Engine Tests ────────────────────────────────────────────────────


class TestDeliveryEngine:
    """Test delivery engine with mocked dependencies."""

    def test_compute_next_send(self):
        from core.delivery_engine import compute_next_send
        next_ts = compute_next_send("0 8 * * *", "UTC")
        assert next_ts is not None
        assert next_ts > datetime.now(timezone.utc)

    def test_compute_next_send_invalid_cron(self):
        from core.delivery_engine import compute_next_send
        result = compute_next_send("invalid cron", "UTC")
        assert result is None

    def test_deliver_subscription_success(self, db, sample_sub):
        import pandas as pd
        from core.delivery_engine import init_delivery_engine, deliver_subscription

        mock_email = MagicMock(return_value=True)
        mock_execute = MagicMock(return_value=pd.DataFrame({"a": [1, 2, 3]}))

        init_delivery_engine(
            db_manager=db,
            email_send_fn=mock_email,
            report_execute_fn=mock_execute,
        )

        result = deliver_subscription(sample_sub["id"])
        assert result["sent"] == 2  # alice + bob
        assert result["failed"] == 0
        assert mock_email.call_count == 2
        assert mock_execute.call_count == 1

    def test_deliver_subscription_email_failure(self, db, sample_sub):
        import pandas as pd
        from core.delivery_engine import init_delivery_engine, deliver_subscription

        mock_email = MagicMock(return_value=False)
        mock_execute = MagicMock(return_value=pd.DataFrame({"a": [1]}))

        init_delivery_engine(
            db_manager=db,
            email_send_fn=mock_email,
            report_execute_fn=mock_execute,
        )

        result = deliver_subscription(sample_sub["id"])
        assert result["sent"] == 0
        assert result["failed"] == 2

    def test_deliver_subscription_not_found(self, db):
        from core.delivery_engine import init_delivery_engine, deliver_subscription
        init_delivery_engine(db_manager=db, email_send_fn=MagicMock(), report_execute_fn=MagicMock())
        result = deliver_subscription(9999)
        assert "error" in result

    def test_process_pending_subscriptions(self, db):
        from core.delivery_engine import init_delivery_engine, process_pending_subscriptions
        import pandas as pd

        now = datetime.now(timezone.utc)
        db.create_subscription(
            report_id=1, report_type="report", name="Due Now",
            created_by="admin", recipient_emails=["a@b.com"],
            frequency="0 * * * *", output_format="csv", is_active=True,
            next_send_at=now - timedelta(minutes=1),
            unsubscribe_token=secrets.token_urlsafe(16),
        )

        mock_email = MagicMock(return_value=True)
        mock_execute = MagicMock(return_value=pd.DataFrame({"x": [1]}))
        init_delivery_engine(db_manager=db, email_send_fn=mock_email, report_execute_fn=mock_execute)

        result = process_pending_subscriptions()
        assert result["processed"] == 1


# ── Alert Evaluation Tests ────────────────────────────────────────────────────


class TestAlertEvaluation:

    def test_check_condition(self):
        from core.delivery_engine import _check_condition
        assert _check_condition(100, ">", 50) is True
        assert _check_condition(50, ">", 100) is False
        assert _check_condition(50, ">=", 50) is True
        assert _check_condition(30, "<", 50) is True
        assert _check_condition(50, "==", 50) is True
        assert _check_condition(50, "!=", 50) is False

    def test_extract_metric_from_rows(self):
        from core.delivery_engine import _extract_metric
        result = {"rows": [{"amount": 10}, {"amount": 20}, {"amount": 30}]}
        assert _extract_metric(result, "amount", "SUM") == 60.0
        assert _extract_metric(result, "amount", "AVG") == 20.0
        assert _extract_metric(result, "amount", "MAX") == 30.0
        assert _extract_metric(result, "amount", "MIN") == 10.0
        assert _extract_metric(result, "amount", "COUNT") == 3.0

    def test_extract_metric_missing_column(self):
        from core.delivery_engine import _extract_metric
        result = {"rows": [{"x": 1}]}
        assert _extract_metric(result, "missing", "SUM") is None


# ── Config Tests ──────────────────────────────────────────────────────────────


class TestDeliveryConfig:

    def test_defaults(self):
        from core.config import delivery
        assert delivery.enabled is True
        assert delivery.max_subscriptions_per_user == 50
        assert delivery.max_recipients_per_subscription == 20
        assert delivery.retry_max_attempts == 3
        assert delivery.batch_size == 20
        assert delivery.check_interval_minutes == 5

    def test_max_pdf_rows(self):
        from core.config import delivery
        assert delivery.max_pdf_rows == 10000


# ── Schedule Model Test ───────────────────────────────────────────────────────


class TestScheduleAutoEvaluate:

    def test_schedule_has_auto_evaluate_alerts(self, db):
        """The Schedule model should have auto_evaluate_alerts field."""
        from core.database import Schedule
        # Just verify the column exists on the model
        assert hasattr(Schedule, "auto_evaluate_alerts")

    def test_schedule_to_dict_includes_field(self, db):
        """Schedule.to_dict() should include auto_evaluate_alerts."""
        schedule = db.create_schedule(
            name="test-schedule",
            source_type="saved_query",
            source_id=1,
            trigger_config={"type": "interval", "hours": 1},
        )
        assert "auto_evaluate_alerts" in schedule
        assert schedule["auto_evaluate_alerts"] is False
