"""
Tests for S3 handler cache TTL-based eviction (credential auto-refresh).

Covers:
- TTL-based handler expiry for assume_role/profile/iam_role auth modes
- Static-key handlers never expire
- Cache invalidation and get_cache_info()
- Admin S3 config + cache monitoring endpoints
- Per-connection refresh-credentials endpoint
"""
from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest


# ── Unit tests for ConnectionManager TTL cache ──────────────────────────────

class TestS3HandlerCacheTTL:
    """Test TTL-based eviction in ConnectionManager._s3_handlers."""

    @pytest.fixture(autouse=True)
    def setup(self, db_manager):
        from core.connection_manager import ConnectionManager
        self.cm = ConnectionManager(db_manager)

    def _make_mock_handler(self, auth_mode="keys"):
        handler = MagicMock()
        handler.config = MagicMock()
        handler.config.auth_mode = auth_mode
        handler.config.bucket_name = "test-bucket"
        handler.s3_client = MagicMock()
        return handler

    def test_handler_cached_on_first_access(self):
        """Second call returns the same handler (not recreated)."""
        handler = self._make_mock_handler("keys")
        with patch("core.connection_manager.S3StorageHandler", return_value=handler):
            h1 = self.cm._get_s3_handler(999, {"bucket_name": "b", "auth_mode": "keys"})
            h2 = self.cm._get_s3_handler(999, {"bucket_name": "b", "auth_mode": "keys"})
        assert h1 is h2

    def test_keys_auth_not_expired(self):
        """Static key handlers should never expire regardless of age."""
        handler = self._make_mock_handler("keys")
        # Insert with a very old timestamp (1 hour ago)
        self.cm._s3_handlers[100] = (handler, time.monotonic() - 7200)
        assert not self.cm._is_handler_expired(100)

    def test_assume_role_expires_after_ttl(self):
        """assume_role handlers should expire after TTL."""
        handler = self._make_mock_handler("assume_role")
        # Insert with timestamp older than default TTL (2700s)
        self.cm._s3_handlers[200] = (handler, time.monotonic() - 3000)
        assert self.cm._is_handler_expired(200)

    def test_assume_role_not_expired_within_ttl(self):
        """assume_role handlers should NOT expire if within TTL."""
        handler = self._make_mock_handler("assume_role")
        self.cm._s3_handlers[201] = (handler, time.monotonic() - 100)
        assert not self.cm._is_handler_expired(201)

    def test_profile_expires_after_ttl(self):
        """profile auth handlers should expire after TTL."""
        handler = self._make_mock_handler("profile")
        self.cm._s3_handlers[300] = (handler, time.monotonic() - 3000)
        assert self.cm._is_handler_expired(300)

    def test_iam_role_expires_after_ttl(self):
        """iam_role auth handlers should expire after TTL."""
        handler = self._make_mock_handler("iam_role")
        self.cm._s3_handlers[400] = (handler, time.monotonic() - 3000)
        assert self.cm._is_handler_expired(400)

    def test_handler_recreated_after_expiry(self):
        """Expired handler should be replaced with a new one."""
        old_handler = self._make_mock_handler("assume_role")
        new_handler = self._make_mock_handler("assume_role")

        # Insert old handler with expired timestamp
        self.cm._s3_handlers[500] = (old_handler, time.monotonic() - 3000)

        with patch("core.connection_manager.S3StorageHandler", return_value=new_handler):
            result = self.cm._get_s3_handler(500, {"bucket_name": "b", "auth_mode": "assume_role"})
        assert result is new_handler
        assert result is not old_handler

    def test_invalidate_cache_works(self):
        """Explicit invalidation removes handler from cache."""
        handler = self._make_mock_handler("keys")
        self.cm._s3_handlers[600] = (handler, time.monotonic())
        self.cm.invalidate_cache(600)
        assert 600 not in self.cm._s3_handlers

    def test_get_cache_info(self):
        """get_cache_info returns correct metadata."""
        handler = self._make_mock_handler("assume_role")
        self.cm._s3_handlers[700] = (handler, time.monotonic() - 100)
        info = self.cm.get_cache_info()
        entry = [i for i in info if i["connection_id"] == 700]
        assert len(entry) == 1
        assert entry[0]["auth_mode"] == "assume_role"
        assert entry[0]["bucket"] == "test-bucket"
        assert entry[0]["age_seconds"] >= 99  # at least ~100s
        assert entry[0]["expired"] is False  # 100s < 2700s TTL

    def test_missing_entry_is_expired(self):
        """Non-existent connection_id should be considered expired."""
        assert self.cm._is_handler_expired(99999)


# ── API integration tests ────────────────────────────────────────────────────

class TestS3AdminEndpoints:
    """Test admin S3 config and handler cache endpoints."""

    def test_get_s3_config(self, api_client):
        resp = api_client.get("/api/admin/s3/config")
        assert resp.status_code == 200
        data = resp.json()
        assert "handler_cache_ttl_seconds" in data
        assert data["handler_cache_ttl_seconds"] == 2700

    def test_set_s3_config_ttl(self, api_client):
        resp = api_client.put("/api/admin/s3/config", json={"handler_cache_ttl_seconds": 1800})
        assert resp.status_code == 200
        # Verify persisted
        resp2 = api_client.get("/api/admin/s3/config")
        assert resp2.json()["handler_cache_ttl_seconds"] == 1800
        # Restore default
        api_client.put("/api/admin/s3/config", json={"handler_cache_ttl_seconds": 2700})

    def test_get_handler_cache(self, api_client):
        resp = api_client.get("/api/admin/s3/handler-cache")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_clear_handler_cache(self, api_client):
        resp = api_client.post("/api/admin/s3/clear-cache")
        assert resp.status_code == 200
        assert "cleared" in resp.json()


class TestRefreshCredentials:
    """Test per-connection credential refresh endpoint."""

    def test_refresh_nonexistent_connection(self, api_client):
        resp = api_client.post("/api/connections/99999/refresh-credentials")
        assert resp.status_code == 404

    def test_refresh_local_connection_400(self, api_client):
        """Local connections should return 400 (not S3)."""
        import tempfile, os
        tmp = tempfile.mkdtemp()
        try:
            # Create a local connection
            create_resp = api_client.post("/api/connections", json={
                "name": "test-local-refresh",
                "connection_type": "local",
                "config": {"base_path": tmp},
            })
            assert create_resp.status_code == 200
            conn_id = create_resp.json().get("id")
            if conn_id:
                resp = api_client.post(f"/api/connections/{conn_id}/refresh-credentials")
                assert resp.status_code == 400
        finally:
            os.rmdir(tmp)
