"""
Phase 58 — Report Catalog & Certified Templates Tests

Tests:
  - Certification: certify/uncertify, admin-only, category filter, list templates
  - Clone: from certified template, sets cloned_from_id
  - Unified catalog: folder/tag/favorite/view with report_type, unified search
  - Share tokens: create, public access, expiry, revoke, access counter
  - Embed tokens: create with report_type=business, public access
  - Config: GET/PUT admin endpoints
"""
from __future__ import annotations

import pytest
from datetime import datetime, timedelta, timezone


# ── DB-level tests (session-scoped db_manager from conftest) ──────────────────

class TestCertificationDB:
    """Certification DB methods."""

    def _make_report(self, db, name="Test Report", owner="admin"):
        return db.create_business_report(
            name=name, owner=owner, dataset_id=1,
            column_ids=[1, 2], filter_specs=[], section_definitions=[],
        )

    def test_certify_business_report(self, db_manager):
        r = self._make_report(db_manager, "Cert Test 1")
        updated = db_manager.certify_business_report(r["id"], "admin", "Sales")
        assert updated["is_certified"] is True
        assert updated["certified_by"] == "admin"
        assert updated["template_category"] == "Sales"
        assert updated["certified_at"] is not None

    def test_uncertify_business_report(self, db_manager):
        r = self._make_report(db_manager, "Cert Test 2")
        db_manager.certify_business_report(r["id"], "admin", "Finance")
        updated = db_manager.uncertify_business_report(r["id"])
        assert updated["is_certified"] is False
        assert updated["certified_by"] is None
        assert updated["template_category"] is None

    def test_list_certified_templates(self, db_manager):
        r1 = self._make_report(db_manager, "Template A")
        r2 = self._make_report(db_manager, "Template B")
        r3 = self._make_report(db_manager, "Not Certified")
        db_manager.certify_business_report(r1["id"], "admin", "Sales")
        db_manager.certify_business_report(r2["id"], "admin", "Finance")

        all_templates = db_manager.list_certified_templates()
        ids = [t["id"] for t in all_templates]
        assert r1["id"] in ids
        assert r2["id"] in ids
        assert r3["id"] not in ids

        sales_only = db_manager.list_certified_templates(category="Sales")
        assert all(t["template_category"] == "Sales" for t in sales_only)

    def test_list_template_categories(self, db_manager):
        cats = db_manager.list_template_categories()
        assert isinstance(cats, list)
        # Should contain at least Sales and Finance from earlier tests
        assert "Sales" in cats
        assert "Finance" in cats


class TestShareTokensDB:
    """Share token DB methods."""

    def _make_report(self, db, name="Share Test"):
        return db.create_business_report(
            name=name, owner="admin", dataset_id=1,
            column_ids=[1], filter_specs=[], section_definitions=[],
        )

    def test_create_share_token(self, db_manager):
        r = self._make_report(db_manager)
        expires = datetime.now(timezone.utc) + timedelta(hours=720)
        share = db_manager.create_business_report_share(r["id"], "admin", expires)
        assert share["token"]
        assert share["report_id"] == r["id"]
        assert share["created_by"] == "admin"
        assert share["is_active"] is True
        assert share["access_count"] == 0

    def test_get_share_by_token(self, db_manager):
        r = self._make_report(db_manager, "Share Get Test")
        share = db_manager.create_business_report_share(r["id"], "admin")
        fetched = db_manager.get_business_report_share_by_token(share["token"])
        assert fetched is not None
        assert fetched["report_id"] == r["id"]

    def test_list_shares(self, db_manager):
        r = self._make_report(db_manager, "Share List Test")
        db_manager.create_business_report_share(r["id"], "admin")
        db_manager.create_business_report_share(r["id"], "admin")
        shares = db_manager.list_business_report_shares(r["id"])
        assert len(shares) >= 2

    def test_deactivate_share(self, db_manager):
        r = self._make_report(db_manager, "Share Deactivate")
        share = db_manager.create_business_report_share(r["id"], "admin")
        assert db_manager.deactivate_business_report_share(share["token"]) is True
        fetched = db_manager.get_business_report_share_by_token(share["token"])
        assert fetched["is_active"] is False

    def test_increment_access(self, db_manager):
        r = self._make_report(db_manager, "Share Access")
        share = db_manager.create_business_report_share(r["id"], "admin")
        db_manager.increment_business_report_share_access(share["token"])
        db_manager.increment_business_report_share_access(share["token"])
        fetched = db_manager.get_business_report_share_by_token(share["token"])
        assert fetched["access_count"] == 2


class TestEmbedTokensDB:
    """Embed token DB methods with report_type support."""

    def test_create_embed_token_business(self, db_manager):
        # Create a business report first
        r = db_manager.create_business_report(
            name="Embed Test", owner="admin", dataset_id=1,
            column_ids=[1], filter_specs=[], section_definitions=[],
        )
        tok = db_manager.create_report_embed_token(
            report_id=r["id"],
            created_by="admin",
            report_type="business",
        )
        assert tok["report_type"] == "business"
        assert tok["token"]
        assert tok["is_active"] is True

    def test_list_embed_tokens_filters_by_type(self, db_manager):
        r = db_manager.create_business_report(
            name="Embed Filter Test", owner="admin", dataset_id=1,
            column_ids=[1], filter_specs=[], section_definitions=[],
        )
        db_manager.create_report_embed_token(r["id"], "admin", report_type="business")
        db_manager.create_report_embed_token(r["id"], "admin", report_type="parametric")

        biz_tokens = db_manager.list_embed_tokens(r["id"], report_type="business")
        param_tokens = db_manager.list_embed_tokens(r["id"], report_type="parametric")
        assert len(biz_tokens) == 1
        assert len(param_tokens) == 1
        assert biz_tokens[0]["report_type"] == "business"
        assert param_tokens[0]["report_type"] == "parametric"


class TestCatalogFavoritesDB:
    """Favorite/view/tag with report_type support."""

    def test_toggle_favorite_with_report_type(self, db_manager):
        added = db_manager.toggle_report_favorite(999, "testuser", report_type="business")
        assert added is True
        favs = db_manager.get_user_favorites("testuser", report_type="business")
        assert any(f["report_id"] == 999 and f["report_type"] == "business" for f in favs)

        # Toggle off
        removed = db_manager.toggle_report_favorite(999, "testuser", report_type="business")
        assert removed is False

    def test_record_view_with_report_type(self, db_manager):
        db_manager.record_report_view(888, "testuser", report_type="business")
        recent = db_manager.get_recently_viewed("testuser", limit=5, report_type="business")
        assert any(r["report_id"] == 888 and r["report_type"] == "business" for r in recent)

    def test_get_all_favorites_no_filter(self, db_manager):
        db_manager.toggle_report_favorite(777, "mixuser", report_type="parametric")
        db_manager.toggle_report_favorite(778, "mixuser", report_type="business")
        all_favs = db_manager.get_user_favorites("mixuser", report_type=None)
        ids = [(f["report_id"], f["report_type"]) for f in all_favs]
        assert (777, "parametric") in ids
        assert (778, "business") in ids


class TestUnifiedSearchDB:
    """Unified search across parametric + business reports."""

    def test_search_finds_business_reports(self, db_manager):
        r = db_manager.create_business_report(
            name="Searchable Sales Dashboard", owner="admin", dataset_id=1,
            column_ids=[1], filter_specs=[], section_definitions=[],
        )
        results = db_manager.search_reports_unified("Searchable Sales")
        types = [r.get("report_type") for r in results]
        assert "business" in types


class TestClonedFromDB:
    """Clone tracking via cloned_from_id."""

    def test_cloned_from_id_set(self, db_manager):
        source = db_manager.create_business_report(
            name="Clone Source", owner="admin", dataset_id=1,
            column_ids=[1, 2], filter_specs=[], section_definitions=[],
        )
        db_manager.certify_business_report(source["id"], "admin", "HR")

        clone = db_manager.create_business_report(
            name="Clone Source (My Copy)", owner="user1", dataset_id=1,
            column_ids=[1, 2], filter_specs=[], section_definitions=[],
        )
        db_manager.update_business_report(clone["id"], cloned_from_id=source["id"])

        fetched = db_manager.get_business_report(clone["id"])
        assert fetched["cloned_from_id"] == source["id"]


# ── API-level tests (module-scoped api_client from conftest) ──────────────────

class TestCertificationAPI:
    """Certification endpoints (admin only)."""

    def _create_report(self, client):
        """Helper to create a business report via API."""
        # We need a dataset first — create one
        r = client.post("/api/business-reports", json={
            "name": "API Cert Test",
            "dataset_id": 1,
            "column_ids": [1],
        })
        if r.status_code == 200:
            return r.json()
        # Dataset might not exist, try to create inline
        return None

    def test_certify_endpoint(self, api_client):
        r = api_client.post("/api/business-reports", json={
            "name": "API Certify Test", "dataset_id": 1, "column_ids": [1],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report (dataset_id=1 doesn't exist)")
        report_id = r.json()["id"]

        resp = api_client.post(f"/api/business-reports/{report_id}/certify",
                               json={"template_category": "Sales"})
        assert resp.status_code == 200
        assert resp.json()["is_certified"] is True

    def test_uncertify_endpoint(self, api_client):
        r = api_client.post("/api/business-reports", json={
            "name": "API Uncertify Test", "dataset_id": 1, "column_ids": [1],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report")
        report_id = r.json()["id"]

        api_client.post(f"/api/business-reports/{report_id}/certify",
                        json={"template_category": "Finance"})
        resp = api_client.delete(f"/api/business-reports/{report_id}/certify")
        assert resp.status_code == 200
        assert resp.json()["is_certified"] is False

    def test_list_templates(self, api_client):
        resp = api_client.get("/api/business-reports/templates")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_template_categories(self, api_client):
        resp = api_client.get("/api/business-reports/template-categories")
        assert resp.status_code == 200
        assert "categories" in resp.json()


class TestShareAPI:
    """Share token endpoints."""

    def test_share_lifecycle(self, api_client):
        r = api_client.post("/api/business-reports", json={
            "name": "Share Lifecycle Test", "dataset_id": 1, "column_ids": [1],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report")
        report_id = r.json()["id"]

        # Create share
        resp = api_client.post(f"/api/business-reports/{report_id}/share",
                               json={"expires_hours": 48})
        assert resp.status_code == 200
        token = resp.json()["token"]

        # List shares
        resp = api_client.get(f"/api/business-reports/{report_id}/shares")
        assert resp.status_code == 200
        assert len(resp.json()["shares"]) >= 1

        # Public access
        resp = api_client.get(f"/api/shared-business-report/{token}")
        assert resp.status_code == 200
        assert resp.json()["report"]["id"] == report_id

        # Revoke
        resp = api_client.delete(f"/api/business-reports/{report_id}/shares/{token}")
        assert resp.status_code == 200

        # After revoke, public access should fail
        resp = api_client.get(f"/api/shared-business-report/{token}")
        assert resp.status_code == 404

    def test_share_not_found(self, api_client):
        resp = api_client.get("/api/shared-business-report/nonexistent_token_12345")
        assert resp.status_code == 404


class TestEmbedAPI:
    """Embed token endpoints for business reports."""

    def test_embed_lifecycle(self, api_client):
        r = api_client.post("/api/business-reports", json={
            "name": "Embed Lifecycle Test", "dataset_id": 1, "column_ids": [1],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report")
        report_id = r.json()["id"]

        # Create embed token
        resp = api_client.post(f"/api/business-reports/{report_id}/embed-tokens",
                               json={"expires_in_days": 30})
        assert resp.status_code == 200
        token = resp.json()["token"]
        assert resp.json()["report_type"] == "business"

        # List embed tokens
        resp = api_client.get(f"/api/business-reports/{report_id}/embed-tokens")
        assert resp.status_code == 200
        assert len(resp.json()["tokens"]) >= 1

        # Public metadata
        resp = api_client.get(f"/api/embedded-business-report/{token}")
        assert resp.status_code == 200
        assert resp.json()["report"]["id"] == report_id

        # Revoke
        resp = api_client.delete(f"/api/business-reports/embed-tokens/{token}")
        assert resp.status_code == 200

    def test_embed_not_found(self, api_client):
        resp = api_client.get("/api/embedded-business-report/nonexistent_token_12345")
        assert resp.status_code == 404


class TestCloneAPI:
    """Clone from certified template endpoint."""

    def test_clone_certified_template(self, api_client):
        # Create + certify
        r = api_client.post("/api/business-reports", json={
            "name": "Clone Template", "dataset_id": 1, "column_ids": [1, 2],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report")
        report_id = r.json()["id"]

        api_client.post(f"/api/business-reports/{report_id}/certify",
                        json={"template_category": "Operations"})

        # Clone
        resp = api_client.post(f"/api/business-reports/{report_id}/clone")
        assert resp.status_code == 200
        clone = resp.json()
        assert clone["name"].endswith("(My Copy)")
        assert clone["cloned_from_id"] == report_id

    def test_clone_non_certified_fails(self, api_client):
        r = api_client.post("/api/business-reports", json={
            "name": "Not Certified Clone", "dataset_id": 1, "column_ids": [1],
        })
        if r.status_code != 200:
            pytest.skip("Cannot create business report")
        report_id = r.json()["id"]

        resp = api_client.post(f"/api/business-reports/{report_id}/clone")
        assert resp.status_code == 400
        assert "certified" in resp.json()["detail"].lower()


class TestUnifiedCatalogAPI:
    """Unified catalog endpoint."""

    def test_catalog_returns_both_types(self, api_client):
        resp = api_client.get("/api/report-catalog")
        assert resp.status_code == 200
        data = resp.json()
        assert "parametric_reports" in data
        assert "business_reports" in data
        assert "folders" in data
        assert "tags" in data
        assert "favorites" in data

    def test_unified_search(self, api_client):
        resp = api_client.get("/api/reports/search?q=test")
        assert resp.status_code == 200
        assert "results" in resp.json()
        assert "count" in resp.json()


class TestAdminConfigAPI:
    """Report catalog admin config endpoints."""

    def test_get_config(self, api_client):
        resp = api_client.get("/api/admin/report-catalog/config")
        assert resp.status_code == 200
        data = resp.json()
        assert "enabled" in data
        assert "certification_enabled" in data
        assert "sharing_enabled" in data
        assert "embed_enabled" in data
        assert "template_categories" in data

    def test_update_config(self, api_client):
        resp = api_client.put("/api/admin/report-catalog/config", json={
            "max_shares_per_report": 20,
            "template_categories": ["Sales", "Finance", "HR", "Custom"],
        })
        assert resp.status_code == 200
        assert resp.json()["max_shares_per_report"] == 20
        assert "Custom" in resp.json()["template_categories"]
