"""
Unit tests for core.date_resolver — dynamic date variable expansion.

Tests rely only on core.date_resolver; no DB or HTTP required.
"""
from __future__ import annotations

import sys
from datetime import date, datetime, timezone, timedelta
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


# Try to import; skip entire module if not present
try:
    from core.date_resolver import resolve_date_variables
    _HAS_DATE_RESOLVER = True
except ImportError:
    _HAS_DATE_RESOLVER = False

pytestmark = pytest.mark.skipif(
    not _HAS_DATE_RESOLVER,
    reason="core.date_resolver not available"
)


class TestResolveDateVariables:
    """Basic variable substitution."""

    def _resolve(self, sql: str, ref_date: date = None) -> str:
        if ref_date is None:
            ref_date = date(2024, 6, 15)
        return resolve_date_variables(sql, reference_date=ref_date)

    def test_today_substituted(self):
        ref = date(2024, 6, 15)
        result = self._resolve("SELECT * FROM t WHERE d = '{{today}}'", ref)
        assert "2024-06-15" in result

    def test_yesterday_substituted(self):
        ref = date(2024, 6, 15)
        result = self._resolve("SELECT * FROM t WHERE d = '{{yesterday}}'", ref)
        assert "2024-06-14" in result

    def test_unknown_variable_unchanged(self):
        sql = "SELECT '{{unknown_var}}'"
        result = self._resolve(sql)
        assert "{{unknown_var}}" in result

    def test_no_variables_unchanged(self):
        sql = "SELECT 1 + 1"
        result = self._resolve(sql)
        assert result == sql

    def test_multiple_variables(self):
        ref = date(2024, 6, 15)
        sql = "WHERE start = '{{yesterday}}' AND end = '{{today}}'"
        result = self._resolve(sql, ref)
        assert "2024-06-14" in result
        assert "2024-06-15" in result

    def test_month_start(self):
        ref = date(2024, 6, 15)
        result = self._resolve("'{{month_start}}'", ref)
        assert "2024-06-01" in result

    def test_month_end(self):
        ref = date(2024, 6, 15)
        result = self._resolve("'{{month_end}}'", ref)
        assert "2024-06-30" in result
