"""Tests for core/sql_lineage_parser.py — Phase 49 table-level lineage extraction."""
import pytest
from core.sql_lineage_parser import extract_table_refs, TableRef, dialect_for_connection_type


class TestDialectMapping:
    def test_s3_maps_to_duckdb(self):
        assert dialect_for_connection_type("s3") == "duckdb"

    def test_trino(self):
        assert dialect_for_connection_type("trino") == "trino"

    def test_snowflake(self):
        assert dialect_for_connection_type("snowflake") == "snowflake"

    def test_unknown_defaults_to_duckdb(self):
        assert dialect_for_connection_type("unknown") == "duckdb"


class TestSimpleFrom:
    def test_single_table(self):
        refs = extract_table_refs("SELECT * FROM orders")
        assert len(refs) == 1
        assert refs[0].table == "orders"
        assert refs[0].access_type == "read"

    def test_schema_qualified(self):
        refs = extract_table_refs("SELECT * FROM public.orders")
        assert len(refs) == 1
        assert refs[0].schema == "public"
        assert refs[0].table == "orders"

    def test_fully_qualified(self):
        refs = extract_table_refs("SELECT * FROM my_catalog.my_schema.my_table")
        assert len(refs) == 1
        assert refs[0].catalog == "my_catalog"
        assert refs[0].schema == "my_schema"
        assert refs[0].table == "my_table"


class TestJoins:
    def test_inner_join(self):
        sql = "SELECT * FROM orders o JOIN customers c ON o.cust_id = c.id"
        refs = extract_table_refs(sql)
        tables = {r.table for r in refs}
        assert "orders" in tables
        assert "customers" in tables

    def test_multiple_joins(self):
        sql = """
        SELECT *
        FROM orders o
        INNER JOIN customers c ON o.cust_id = c.id
        LEFT JOIN products p ON o.product_id = p.id
        """
        refs = extract_table_refs(sql)
        tables = {r.table for r in refs}
        assert tables == {"orders", "customers", "products"}


class TestCTE:
    def test_cte_excluded_from_physical_tables(self):
        sql = """
        WITH recent_orders AS (
            SELECT * FROM orders WHERE created_at > '2024-01-01'
        )
        SELECT * FROM recent_orders ro JOIN customers c ON ro.cust_id = c.id
        """
        refs = extract_table_refs(sql)
        tables = {r.table for r in refs}
        # "recent_orders" is a CTE and should NOT appear as a physical table
        assert "recent_orders" not in tables
        assert "orders" in tables
        assert "customers" in tables


class TestSubquery:
    def test_subquery_table_extracted(self):
        sql = """
        SELECT * FROM (
            SELECT id, name FROM products WHERE active = true
        ) sub
        JOIN categories c ON sub.id = c.product_id
        """
        refs = extract_table_refs(sql)
        tables = {r.table for r in refs}
        assert "products" in tables
        assert "categories" in tables


class TestWriteAccess:
    def test_insert_into(self):
        sql = "INSERT INTO target_table SELECT * FROM source_table"
        refs = extract_table_refs(sql)
        target = [r for r in refs if r.table == "target_table"]
        source = [r for r in refs if r.table == "source_table"]
        assert len(target) == 1
        assert target[0].access_type == "write"
        assert len(source) == 1
        assert source[0].access_type == "read"

    def test_create_table_as(self):
        sql = "CREATE TABLE new_table AS SELECT * FROM old_table"
        refs = extract_table_refs(sql)
        new = [r for r in refs if r.table == "new_table"]
        old = [r for r in refs if r.table == "old_table"]
        assert len(new) == 1
        assert new[0].access_type == "write"
        assert len(old) == 1
        assert old[0].access_type == "read"


class TestDeduplication:
    def test_same_table_mentioned_twice(self):
        sql = """
        SELECT * FROM orders o1
        JOIN orders o2 ON o1.parent_id = o2.id
        """
        refs = extract_table_refs(sql)
        # Should be deduplicated to one entry
        assert len(refs) == 1
        assert refs[0].table == "orders"


class TestGracefulFailure:
    def test_empty_string(self):
        refs = extract_table_refs("")
        assert refs == []

    def test_invalid_sql(self):
        refs = extract_table_refs("THIS IS NOT SQL AT ALL !!!")
        # Should not crash — returns empty or whatever it can extract
        assert isinstance(refs, list)

    def test_partial_sql(self):
        refs = extract_table_refs("SELECT * FROM")
        assert isinstance(refs, list)


class TestDialectSpecific:
    def test_snowflake_quoted(self):
        sql = 'SELECT * FROM "MY_DB"."MY_SCHEMA"."MY_TABLE"'
        refs = extract_table_refs(sql, dialect="snowflake")
        assert len(refs) >= 1
        # Should find the table regardless of quoting

    def test_trino_dialect(self):
        sql = "SELECT * FROM hive.default.events"
        refs = extract_table_refs(sql, dialect="trino")
        assert len(refs) == 1
        assert refs[0].table == "events"
