"""
Phase 57 — Enhanced NL Chatbot: unit tests for new patterns and SemanticSchemaContext.

Tests: 12 new patterns, SemanticSchemaContext construction, column resolution,
time intelligence, analytical patterns, pre-defined conditions, pipeline priority.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure backend/ on sys.path
_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from core.nl_to_sql import (
    nl_to_sql, SchemaContext, SemanticSchemaContext, NLToSQLResult,
    build_semantic_context, enrich_from_schema_cache,
    apply_glossary, result_to_dict,
    _best_column_match, _date_cols, _numeric_cols,
    _match_condition_name, _match_ytd, _match_mtd, _match_sply,
    _match_period_over_period, _match_running_total,
    _match_percent_of_total, _match_growth_rate, _match_moving_average,
    _match_rank, _match_conditional_aggregate, _match_ratio,
)


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture()
def basic_ctx():
    """Plain SchemaContext for backward compatibility tests."""
    return SchemaContext(
        tables=["orders"],
        columns={"orders": ["order_id", "customer", "revenue", "order_date", "region", "cost"]},
        connection_type="duckdb",
    )


@pytest.fixture()
def semantic_ctx():
    """SemanticSchemaContext with full metadata."""
    return SemanticSchemaContext(
        tables=["sales"],
        columns={"sales": ["sale_amount", "order_date", "country", "region", "quantity", "unit_cost"]},
        connection_type="duckdb",
        friendly_names={"sales": {
            "revenue": "sale_amount",
            "total revenue": "sale_amount",
            "country": "country",
            "order date": "order_date",
        }},
        synonyms={"sales": {
            "net rev": "sale_amount",
            "sales": "sale_amount",
            "qty": "quantity",
        }},
        column_data_types={"sales": {
            "sale_amount": "number",
            "order_date": "date",
            "country": "string",
            "region": "string",
            "quantity": "number",
            "unit_cost": "number",
        }},
        column_aggregations={"sales": {
            "sale_amount": "sum",
            "quantity": "sum",
            "unit_cost": "avg",
        }},
        conditions=[
            {"name": "This Year", "label": "Current Year Data", "where_clause": "YEAR(order_date) = YEAR(CURRENT_DATE)"},
            {"name": "Active Customers", "label": "Active Customers Only", "where_clause": "status = 'active'"},
        ],
        dataset_name="Sales Dataset",
    )


# ── Group 1: SemanticSchemaContext construction ──────────────────────────────

class TestBuildSemanticContext:

    def test_basic_build(self):
        ds = {
            "name": "Test DS",
            "source_tables": [{"connection_id": 1, "table": "s3://bucket/data.parquet", "alias": "data"}],
            "columns": [
                {"physical_name": "revenue", "friendly_name": "Total Revenue", "data_type": "number",
                 "aggregation": "sum", "synonyms": ["sales", "rev"], "is_hidden": False},
                {"physical_name": "event_date", "friendly_name": "Event Date", "data_type": "date",
                 "synonyms": [], "is_hidden": False},
            ],
            "conditions": [
                {"name": "This Year", "label": "Current Year", "where_clause": "YEAR(event_date) = YEAR(CURRENT_DATE)"},
            ],
        }
        ctx = build_semantic_context(ds)
        assert ctx.tables == ["data"]
        assert "revenue" in ctx.columns["data"]
        assert "event_date" in ctx.columns["data"]
        assert ctx.friendly_names["data"]["total revenue"] == "revenue"
        assert ctx.synonyms["data"]["sales"] == "revenue"
        assert ctx.synonyms["data"]["rev"] == "revenue"
        assert ctx.column_data_types["data"]["revenue"] == "number"
        assert ctx.column_data_types["data"]["event_date"] == "date"
        assert ctx.column_aggregations["data"]["revenue"] == "sum"
        assert len(ctx.conditions) == 1
        assert ctx.dataset_name == "Test DS"

    def test_hidden_cols_excluded(self):
        ds = {
            "name": "Test",
            "source_tables": [{"alias": "t"}],
            "columns": [
                {"physical_name": "visible", "friendly_name": "Visible", "is_hidden": False},
                {"physical_name": "hidden", "friendly_name": "Hidden", "is_hidden": True},
            ],
            "conditions": [],
        }
        ctx = build_semantic_context(ds)
        assert "visible" in ctx.columns["t"]
        assert "hidden" not in ctx.columns["t"]

    def test_no_source_tables_fallback(self):
        ds = {"name": "Fallback", "source_tables": [], "columns": [], "conditions": []}
        ctx = build_semantic_context(ds)
        assert ctx.tables == ["Fallback"]

    def test_enrich_from_schema_cache(self):
        base = SchemaContext(tables=["orders"], columns={"orders": ["id", "created_at", "amount"]})
        cache_rows = [{
            "table_name": "orders",
            "schema_data": {
                "columns": [
                    {"name": "id", "type": "BIGINT"},
                    {"name": "created_at", "type": "TIMESTAMP"},
                    {"name": "amount", "type": "DOUBLE"},
                ]
            }
        }]
        ctx = enrich_from_schema_cache(base, cache_rows)
        assert isinstance(ctx, SemanticSchemaContext)
        assert ctx.column_data_types["orders"]["id"] == "number"
        assert ctx.column_data_types["orders"]["created_at"] == "date"
        assert ctx.column_data_types["orders"]["amount"] == "number"

    def test_enrich_from_schema_cache_varchar(self):
        base = SchemaContext(tables=["t"], columns={"t": ["name", "flag"]})
        cache_rows = [{
            "table_name": "t",
            "schema_data": {"columns": [
                {"name": "name", "type": "VARCHAR"},
                {"name": "flag", "type": "BOOLEAN"},
            ]}
        }]
        ctx = enrich_from_schema_cache(base, cache_rows)
        assert ctx.column_data_types["t"]["name"] == "string"
        assert ctx.column_data_types["t"]["flag"] == "boolean"


# ── Group 2: Column resolution with semantic context ─────────────────────────

class TestSemanticColumnResolution:

    def test_friendly_name_resolution(self, semantic_ctx):
        result = _best_column_match("revenue", "sales", semantic_ctx)
        assert result == "sale_amount"

    def test_synonym_resolution(self, semantic_ctx):
        result = _best_column_match("net rev", "sales", semantic_ctx)
        assert result == "sale_amount"

    def test_semantic_date_cols(self, semantic_ctx):
        dates = _date_cols("sales", semantic_ctx)
        assert dates == ["order_date"]

    def test_semantic_numeric_cols(self, semantic_ctx):
        nums = _numeric_cols("sales", semantic_ctx)
        assert "sale_amount" in nums
        assert "quantity" in nums
        assert "unit_cost" in nums
        assert "order_date" not in nums


# ── Group 3: Time intelligence patterns ──────────────────────────────────────

class TestTimeIntelligence:

    def test_ytd_with_group(self, semantic_ctx):
        r = _match_ytd("YTD sale_amount by country", semantic_ctx)
        assert r is not None
        assert r.pattern_matched == "year-to-date"
        assert "DATE_TRUNC('year', CURRENT_DATE)" in r.sql
        assert "GROUP BY" in r.sql
        assert r.confidence == 0.88

    def test_ytd_no_group(self, semantic_ctx):
        r = _match_ytd("YTD sale_amount", semantic_ctx)
        assert r is not None
        assert "DATE_TRUNC('year', CURRENT_DATE)" in r.sql
        assert "GROUP BY" not in r.sql

    def test_mtd_basic(self, semantic_ctx):
        r = _match_mtd("MTD sale_amount by region", semantic_ctx)
        assert r is not None
        assert r.pattern_matched == "month-to-date"
        assert "DATE_TRUNC('month', CURRENT_DATE)" in r.sql

    def test_sply_basic(self, semantic_ctx):
        r = _match_sply("same period last year sale_amount by country", semantic_ctx)
        assert r is not None
        assert r.pattern_matched == "SPLY comparison"
        assert "current_period" in r.sql
        assert "prior_period" in r.sql
        assert "yoy_change" in r.sql

    def test_sply_yoy_alias(self, semantic_ctx):
        r = _match_sply("yoy sale_amount", semantic_ctx)
        assert r is not None
        assert r.confidence == 0.85

    def test_pop_month(self, basic_ctx):
        r = _match_period_over_period("revenue this month vs last month", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "period-over-period"
        assert "DATE_TRUNC('month'" in r.sql
        assert "change_pct" in r.sql

    def test_pop_year(self, basic_ctx):
        r = _match_period_over_period("revenue this year vs last year", basic_ctx)
        assert r is not None
        assert "DATE_TRUNC('year'" in r.sql


# ── Group 4: Analytical patterns ─────────────────────────────────────────────

class TestAnalyticalPatterns:

    def test_running_total(self, basic_ctx):
        r = _match_running_total("running total of revenue by order_date", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "running total"
        assert "SUM(revenue) OVER" in r.sql
        assert "UNBOUNDED PRECEDING" in r.sql

    def test_percent_of_total(self, basic_ctx):
        r = _match_percent_of_total("percentage of total revenue by region", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "percent of total"
        assert "pct_of_total" in r.sql
        assert "NULLIF" in r.sql

    def test_growth_rate(self, basic_ctx):
        r = _match_growth_rate("month over month growth of revenue", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "growth rate"
        assert "LAG(" in r.sql
        assert "growth_pct" in r.sql

    def test_moving_average(self, basic_ctx):
        r = _match_moving_average("3 month moving average of revenue", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "moving average"
        assert "ROWS BETWEEN 2 PRECEDING AND CURRENT ROW" in r.sql
        assert "moving_avg_3_revenue" in r.sql

    def test_rank(self, basic_ctx):
        r = _match_rank("rank customer by revenue", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "rank"
        assert "RANK() OVER" in r.sql

    def test_conditional_aggregate(self, basic_ctx):
        r = _match_conditional_aggregate("sum of revenue where region = North", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "conditional aggregate"
        assert "CASE WHEN" in r.sql
        assert "'North'" in r.sql

    def test_ratio(self, basic_ctx):
        r = _match_ratio("ratio of revenue to cost", basic_ctx)
        assert r is not None
        assert r.pattern_matched == "ratio"
        assert "NULLIF" in r.sql
        assert "ratio_revenue_to_cost" in r.sql


# ── Group 5: Pre-defined condition matching ──────────────────────────────────

class TestConditionMatching:

    def test_condition_exact_match(self, semantic_ctx):
        r = _match_condition_name("show This Year data", semantic_ctx)
        assert r is not None
        assert r.matched_condition == "This Year"
        assert "YEAR(order_date) = YEAR(CURRENT_DATE)" in r.sql
        assert r.confidence == 0.90

    def test_condition_label_match(self, semantic_ctx):
        r = _match_condition_name("Active Customers Only", semantic_ctx)
        assert r is not None
        assert r.matched_condition == "Active Customers"
        assert "status = 'active'" in r.sql

    def test_condition_no_match_plain_ctx(self, basic_ctx):
        r = _match_condition_name("show This Year data", basic_ctx)
        assert r is None

    def test_condition_with_metric(self, semantic_ctx):
        r = _match_condition_name("sum of sale_amount This Year", semantic_ctx)
        assert r is not None
        assert "SUM(" in r.sql
        assert "YEAR(order_date)" in r.sql


# ── Group 6: End-to-end pipeline priority ────────────────────────────────────

class TestPipelinePriority:

    def test_ytd_beats_recent(self, semantic_ctx):
        """YTD should match _match_ytd, not fall through to _match_recent."""
        r = nl_to_sql("YTD sale_amount", semantic_ctx)
        assert r.pattern_matched == "year-to-date"
        assert r.confidence == 0.88

    def test_condition_highest_priority(self, semantic_ctx):
        """Condition name should fire first if it matches."""
        r = nl_to_sql("show This Year sale_amount", semantic_ctx)
        assert "pre-defined condition" in r.pattern_matched

    def test_fallback_unchanged(self, basic_ctx):
        """Unrecognized phrase still returns fallback with low confidence."""
        r = nl_to_sql("xyzzy foobar baz", basic_ctx)
        assert r.pattern_matched == "fallback template"
        assert r.confidence == 0.20

    def test_backward_compat_plain_context(self, basic_ctx):
        """Original 11 patterns still work with plain SchemaContext."""
        r = nl_to_sql("top 5 orders by revenue", basic_ctx)
        assert r.pattern_matched == "top N by column"
        assert "ORDER BY revenue DESC" in r.sql
        assert "LIMIT 5" in r.sql


# ── Group 7: Glossary + synonym integration ──────────────────────────────────

class TestGlossaryIntegration:

    def test_apply_glossary_longest_first(self):
        glossary = {"net rev": "net_revenue", "rev": "revenue_col"}
        result = apply_glossary("show net rev", glossary)
        assert "net_revenue" in result

    def test_result_to_dict_includes_new_fields(self):
        r = NLToSQLResult(
            sql="SELECT 1", pattern_matched="test", confidence=0.9,
            explanation="test", matched_condition="This Year",
            semantic_rewrites=["glossary: 'rev' → 'revenue'"],
        )
        d = result_to_dict(r)
        assert d["matched_condition"] == "This Year"
        assert d["semantic_rewrites"] == ["glossary: 'rev' → 'revenue'"]

    def test_result_to_dict_omits_empty_fields(self):
        r = NLToSQLResult(sql="SELECT 1", pattern_matched="test", confidence=0.5, explanation="test")
        d = result_to_dict(r)
        assert "matched_condition" not in d
        assert "semantic_rewrites" not in d
