"""
Unit tests for core.config — three-level resolution, defaults, env-var overrides.
"""
from __future__ import annotations

import os
import sys
import json
import tempfile
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


def _fresh_config(monkeypatch, overrides: dict = None):
    """Return a fresh Settings instance isolated from real config.json."""
    import importlib
    import core.config as cfg_mod

    # Temporarily clear the module singleton so we get a fresh load
    monkeypatch.setattr(cfg_mod, "_cfg", None, raising=False)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json",
                                     delete=False) as f:
        json.dump(overrides or {}, f)
        cfg_path = f.name

    try:
        monkeypatch.setenv("QUERYSTUDIO_CONFIG", cfg_path)
        importlib.reload(cfg_mod)
        return cfg_mod
    finally:
        os.unlink(cfg_path)


class TestQueueConfig:
    def test_default_backend_is_sqlite(self):
        from core.config import queue as _q
        assert _q.backend == "sqlite"

    def test_default_key_prefix(self):
        from core.config import queue as _q
        assert _q.key_prefix == "qs"

    def test_default_task_ttl(self):
        from core.config import queue as _q
        assert _q.task_ttl_hours == 24


class TestServerConfig:
    def test_default_host(self):
        from core.config import server as _s
        assert _s.host == "0.0.0.0"

    def test_default_port(self):
        from core.config import server as _s
        assert isinstance(_s.port, int)
        assert _s.port > 0


class TestExecutorConfig:
    def test_default_mode_is_embedded(self):
        from core.config import executor as _e
        assert _e.mode == "embedded"


class TestRateLimiter:
    def test_allows_within_limit(self):
        from core.rate_limiter import check_rate_limit, _local_windows
        # Use a unique identity to avoid cross-test contamination
        remaining = check_rate_limit("test_allow", "_pytest_user", limit=5, window_seconds=60)
        assert remaining >= 0

    def test_raises_on_exceeded(self):
        from core.rate_limiter import check_rate_limit, RateLimitExceededError, _local_windows, _local_lock
        from collections import deque

        action = "test_exceed"
        identity = "_pytest_exceed"
        # Pre-fill the window to simulate being at the limit
        key = (action, identity)
        import time
        with _local_lock:
            _local_windows[key] = deque([time.monotonic()] * 3)

        with pytest.raises(RateLimitExceededError) as exc_info:
            check_rate_limit(action, identity, limit=3, window_seconds=60)

        err = exc_info.value
        assert err.action == action
        assert err.limit == 3
        assert err.retry_after >= 1

    def test_window_expires(self):
        from core.rate_limiter import check_rate_limit, RateLimitExceededError, _local_windows, _local_lock
        from collections import deque
        import time

        action = "test_expire"
        identity = "_pytest_expire"
        # Pre-fill with old timestamps (window of 1s, timestamps 5s ago)
        key = (action, identity)
        old_ts = time.monotonic() - 10
        with _local_lock:
            _local_windows[key] = deque([old_ts, old_ts, old_ts])

        # Should NOT raise — old entries evicted
        remaining = check_rate_limit(action, identity, limit=3, window_seconds=1)
        assert remaining >= 0
