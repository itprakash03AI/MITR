"""
Integration tests for /api/admin/* endpoints.

Uses api_client (auth.type=none — guest is admin, all endpoints accessible).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


class TestStorage:
    def test_storage_returns_200(self, api_client):
        """GET /api/admin/storage returns storage stats."""
        resp = api_client.get("/api/admin/storage")
        assert resp.status_code == 200
        body = resp.json()
        # Should contain some size/usage info
        assert isinstance(body, dict)

    def test_storage_cleanup_endpoint(self, api_client):
        """POST /api/admin/storage/cleanup returns 200."""
        resp = api_client.post("/api/admin/storage/cleanup")
        assert resp.status_code == 200


class TestActiveQueries:
    def test_active_queries_returns_list(self, api_client):
        """GET /api/admin/active-queries returns a list."""
        resp = api_client.get("/api/admin/active-queries")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestUsers:
    def test_list_users_returns_200(self, api_client):
        """GET /api/admin/users returns 200 (list or info message when auth disabled)."""
        resp = api_client.get("/api/admin/users")
        assert resp.status_code == 200
        # With auth.type=none, may return a message dict instead of a list
        assert isinstance(resp.json(), (list, dict))

    def test_create_user(self, api_client):
        """POST /api/admin/users creates a user (auth.type=none, so no real auth needed)."""
        resp = api_client.post(
            "/api/admin/users",
            json={
                "username": "newuser_test",
                "password": "P@ssw0rd123",
                "role": "viewer",
                "display_name": "Test New User",
            },
        )
        # May be 201 (created) or 400 (already exists in session) or 422
        assert resp.status_code in (200, 201, 400, 422, 501)

    def test_lookup_user_endpoint(self, api_client):
        """GET /api/admin/users/lookup/{username} — 400 when auth=none, 404 when not found."""
        resp = api_client.get("/api/admin/users/lookup/nobody_xyz_000")
        assert resp.status_code in (200, 400, 404)


class TestWorkerPool:
    def test_worker_pool_status(self, api_client):
        """GET /api/admin/worker-pool returns pool info."""
        resp = api_client.get("/api/admin/worker-pool")
        assert resp.status_code == 200

    def test_worker_pool_tasks(self, api_client):
        """GET /api/admin/worker-pool/tasks returns list."""
        resp = api_client.get("/api/admin/worker-pool/tasks")
        assert resp.status_code == 200

    def test_worker_pool_config(self, api_client):
        """GET /api/admin/worker-pool/config returns config dict."""
        resp = api_client.get("/api/admin/worker-pool/config")
        assert resp.status_code == 200


class TestAuditLog:
    def test_audit_log_endpoint(self, api_client):
        """GET /api/admin/audit-log returns list."""
        resp = api_client.get("/api/admin/audit-log")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestCache:
    def test_cache_stats(self, api_client):
        """GET /api/cache/stats returns stats."""
        resp = api_client.get("/api/cache/stats")
        assert resp.status_code == 200

    def test_delete_cache(self, api_client):
        """DELETE /api/cache returns 200."""
        resp = api_client.delete("/api/cache")
        assert resp.status_code == 200


class TestAppSettings:
    def test_app_settings(self, api_client):
        """GET /api/app-settings returns settings dict."""
        resp = api_client.get("/api/app-settings")
        assert resp.status_code == 200
        assert isinstance(resp.json(), dict)

    def test_admin_app_config(self, api_client):
        """GET /api/admin/app-config returns config dict."""
        resp = api_client.get("/api/admin/app-config")
        assert resp.status_code == 200


class TestScheduler:
    def test_scheduler_status(self, api_client):
        """GET /api/admin/scheduler returns scheduler status."""
        resp = api_client.get("/api/admin/scheduler")
        assert resp.status_code == 200
