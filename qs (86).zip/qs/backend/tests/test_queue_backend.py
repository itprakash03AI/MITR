"""
Unit tests for core.queue_backend — SQLite implementation.

Tests use the session-scoped db_manager fixture from conftest.py.
Redis tests are skipped automatically if redis is not available.
"""
from __future__ import annotations

import time
import uuid
from typing import Optional

import pytest


# ── SQLite queue backend tests ────────────────────────────────────────────────

class TestSqliteEnqueue:
    def test_enqueue_returns_task(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        task = sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query",
            payload={"sql": "SELECT 1"}, created_by="pytest",
        )
        assert task["task_id"] == tid
        assert task["status"] == "pending"
        assert task["task_type"] == "parquet_query"

    def test_enqueue_with_retry_fields(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        task = sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query",
            payload={}, created_by="pytest",
            retry_count=2, max_retries=5,
        )
        assert task["retry_count"] == 2
        assert task["max_retries"] == 5

    def test_enqueue_with_delay(self, sqlite_task_queue):
        """Tasks with delay_seconds should not be claimable immediately."""
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query",
            payload={}, created_by="pytest",
            delay_seconds=3600,  # 1 hour — should NOT be claimable
        )
        # Attempt to claim should return a different task (or None)
        worker = "test-worker-delay"
        claimed = sqlite_task_queue.claim_next_task(worker_id=worker)
        if claimed:
            assert claimed["task_id"] != tid, "Delayed task should not be claimed yet"


class TestSqliteClaim:
    def test_claim_returns_task(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="test_claim", payload={}, created_by="pytest"
        )
        task = sqlite_task_queue.claim_next_task(worker_id="w1")
        assert task is not None
        assert task["status"] == "claimed"

    def test_same_task_not_claimed_twice(self, sqlite_task_queue, db_manager):
        """Two concurrent workers must not both claim the same task."""
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="unique_claim_test", payload={"unique": tid}
        )

        # Both workers try to claim; at most one should get it
        w1 = sqlite_task_queue.claim_next_task(worker_id="w-a")
        w2 = sqlite_task_queue.claim_next_task(worker_id="w-b")

        same_task_claims = sum(
            1 for t in [w1, w2]
            if t is not None and t.get("task_id") == tid
        )
        assert same_task_claims <= 1


class TestSqliteLifecycle:
    def test_complete_task(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="lifecycle_test", payload={}, created_by="pytest"
        )
        sqlite_task_queue.claim_next_task(worker_id="w1")
        sqlite_task_queue.complete_task(tid, result={"rows": 42})

        task = sqlite_task_queue.get_task(tid)
        assert task is not None
        assert task["status"] == "completed"

    def test_fail_task(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="fail_test", payload={}, created_by="pytest"
        )
        sqlite_task_queue.claim_next_task(worker_id="w1")
        sqlite_task_queue.fail_task(tid, error_message="test error")

        task = sqlite_task_queue.get_task(tid)
        assert task is not None
        assert task["status"] == "failed"
        assert "test error" in (task.get("error_message") or "")

    def test_update_progress(self, sqlite_task_queue):
        tid = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="progress_test", payload={}, created_by="pytest"
        )
        sqlite_task_queue.claim_next_task(worker_id="w1")
        sqlite_task_queue.update_task_progress(tid, progress_pct=50, progress_detail="halfway")

        task = sqlite_task_queue.get_task(tid)
        assert task is not None
        assert task["progress_pct"] == 50


class TestSqliteCancellation:
    def test_cancel_pending_task(self, sqlite_task_queue, db_manager):
        tid = str(uuid.uuid4())
        exec_id = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="cancel_test",
            payload={}, execution_id=exec_id,
        )
        result = sqlite_task_queue.request_task_cancel(exec_id)
        assert result is True

    def test_is_task_cancelled(self, sqlite_task_queue, db_manager):
        tid = str(uuid.uuid4())
        exec_id = str(uuid.uuid4())
        sqlite_task_queue.enqueue_task(
            task_id=tid, task_type="cancel_check",
            payload={}, execution_id=exec_id,
        )
        # Claim it so it's not in pending (cancel of pending auto-cancels)
        sqlite_task_queue.claim_next_task(worker_id="w1")
        db_manager.request_task_cancel(exec_id)
        assert sqlite_task_queue.is_task_cancelled(tid) is True


# ── Dead-Letter Queue tests ────────────────────────────────────────────────────

class TestDeadLetterQueue:
    def test_push_and_list(self, db_manager):
        task = {
            "task_id": str(uuid.uuid4()),
            "task_type": "parquet_query",
            "payload": {"sql": "SELECT fail"},
            "execution_id": str(uuid.uuid4()),
            "created_by": "pytest",
            "retry_count": 3,
        }
        db_manager.push_dead_letter(task, error="deliberate test failure")
        entries = db_manager.list_dead_letter(resolved=False)
        ids = [e["task_id"] for e in entries]
        assert task["task_id"] in ids

    def test_resolve(self, db_manager):
        task_id = str(uuid.uuid4())
        db_manager.push_dead_letter(
            {"task_id": task_id, "task_type": "test", "payload": {},
             "execution_id": None, "created_by": "pytest", "retry_count": 3},
            error="test",
        )
        ok = db_manager.resolve_dead_letter(task_id, resolved_by="admin")
        assert ok is True

        entries = db_manager.list_dead_letter(resolved=True)
        resolved = [e for e in entries if e["task_id"] == task_id]
        assert resolved
        assert resolved[0]["resolved"] in (True, 1)

    def test_resolve_nonexistent_returns_false(self, db_manager):
        ok = db_manager.resolve_dead_letter("nonexistent-task-id", resolved_by="admin")
        assert ok is False


# ── Redis backend tests (skip if Redis not available) ────────────────────────

@pytest.fixture(scope="module")
def redis_task_queue():
    """RedisTaskQueue connected to localhost:6379. Skip if unavailable."""
    try:
        from core.queue_backend import RedisTaskQueue
        q = RedisTaskQueue("redis://localhost:6379/15", key_prefix="qs_test")
        # Flush the test DB to start clean
        q._r.flushdb()
        yield q
        q._r.flushdb()
    except Exception:
        pytest.skip("Redis not available")


class TestRedisEnqueue:
    def test_enqueue_returns_task(self, redis_task_queue):
        tid = str(uuid.uuid4())
        task = redis_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query", payload={"sql": "SELECT 1"}
        )
        assert task["task_id"] == tid
        assert task["status"] == "pending"

    def test_delayed_task_not_claimed_immediately(self, redis_task_queue):
        tid = str(uuid.uuid4())
        redis_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query",
            payload={}, delay_seconds=3600,
        )
        task = redis_task_queue._r.hgetall(redis_task_queue._task_key(tid))
        assert task.get("status") == "delayed"
        # Should not be in pending set
        score = redis_task_queue._r.zscore(redis_task_queue._key("pending"), tid)
        assert score is None

    def test_retry_fields_stored(self, redis_task_queue):
        tid = str(uuid.uuid4())
        redis_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query", payload={},
            retry_count=1, max_retries=3,
        )
        raw = redis_task_queue._r.hgetall(redis_task_queue._task_key(tid))
        assert int(raw.get("retry_count", 0)) == 1
        assert int(raw.get("max_retries", 0)) == 3


class TestRedisLifecycle:
    def test_claim_and_complete(self, redis_task_queue):
        tid = str(uuid.uuid4())
        redis_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query", payload={}
        )
        task = redis_task_queue.claim_next_task(worker_id="w-redis-1")
        assert task is not None
        redis_task_queue.complete_task(task["task_id"])

    def test_promote_delayed_tasks(self, redis_task_queue):
        """A delayed task with elapsed time should be moved to pending."""
        import redis as _redis
        tid = str(uuid.uuid4())
        redis_task_queue.enqueue_task(
            task_id=tid, task_type="parquet_query",
            payload={}, delay_seconds=1,
        )
        # Manually set the score to past time so it's "due"
        past = time.time() - 10
        redis_task_queue._r.zadd(redis_task_queue._key("delayed"), {tid: past})
        # Now promote should move it
        redis_task_queue._promote_delayed_tasks()
        score = redis_task_queue._r.zscore(redis_task_queue._key("pending"), tid)
        assert score is not None
