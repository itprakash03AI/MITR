"""
Phase 59 — Business Portal Tests

Tests:
  - DB: count_user_reports, count_executions_today
  - API: GET /api/portal/summary (structure, KPI, lists, role)
  - Config: GET/PUT /api/admin/business-portal/config
  - Component visibility: business_portal in KNOWN_COMPONENTS
"""
from __future__ import annotations

import pytest


# ── DB-level tests ────────────────────────────────────────────────────────────

class TestPortalDB:
    """Portal DB helper methods."""

    def test_count_user_reports_empty(self, db_manager):
        counts = db_manager.count_user_reports("nonexistent_user", "viewer")
        assert isinstance(counts, dict)
        assert "parametric" in counts
        assert "business" in counts
        assert "total" in counts
        assert counts["total"] == counts["parametric"] + counts["business"]

    def test_count_user_reports_admin(self, db_manager):
        counts = db_manager.count_user_reports("admin", "admin")
        assert counts["total"] >= 0

    def test_count_executions_today(self, db_manager):
        count = db_manager.count_executions_today("test_user")
        assert isinstance(count, int)
        assert count >= 0

    def test_count_executions_today_all(self, db_manager):
        count = db_manager.count_executions_today()
        assert isinstance(count, int)
        assert count >= 0


# ── API-level tests ───────────────────────────────────────────────────────────

class TestPortalSummaryAPI:
    """GET /api/portal/summary endpoint."""

    def test_portal_summary_200(self, api_client):
        resp = api_client.get("/api/portal/summary")
        assert resp.status_code == 200
        data = resp.json()
        assert "kpi" in data
        assert "recent_reports" in data
        assert "favorites" in data
        assert "certified_templates" in data
        assert "welcome_message" in data
        assert "welcome_subtitle" in data
        assert "role" in data

    def test_portal_summary_kpi_structure(self, api_client):
        data = api_client.get("/api/portal/summary").json()
        kpi = data["kpi"]
        assert "total_reports" in kpi
        assert "favorites_count" in kpi
        assert "executions_today" in kpi
        assert "unread_notifications" in kpi
        assert "dashboards_count" in kpi

    def test_portal_summary_lists_are_lists(self, api_client):
        data = api_client.get("/api/portal/summary").json()
        assert isinstance(data["recent_reports"], list)
        assert isinstance(data["favorites"], list)
        assert isinstance(data["certified_templates"], list)
        assert isinstance(data["dashboards"], list)

    def test_portal_summary_has_role(self, api_client):
        data = api_client.get("/api/portal/summary").json()
        assert data["role"] in ("admin", "analyst", "viewer")

    def test_portal_summary_has_flags(self, api_client):
        data = api_client.get("/api/portal/summary").json()
        assert "quick_actions_enabled" in data
        assert "kpi_cards_enabled" in data
        assert isinstance(data["quick_actions_enabled"], bool)
        assert isinstance(data["kpi_cards_enabled"], bool)

    def test_portal_summary_active_queries(self, api_client):
        """Admin user should get active_queries field."""
        data = api_client.get("/api/portal/summary").json()
        assert "active_queries" in data
        assert isinstance(data["active_queries"], int)


class TestPortalConfigAdmin:
    """GET/PUT /api/admin/business-portal/config."""

    def test_get_portal_config(self, api_client):
        resp = api_client.get("/api/admin/business-portal/config")
        assert resp.status_code == 200
        data = resp.json()
        assert "enabled" in data
        assert "welcome_message" in data
        assert "welcome_subtitle" in data
        assert "recent_reports_limit" in data
        assert "favorites_limit" in data
        assert "certified_templates_limit" in data
        assert "recent_activity_limit" in data
        assert "quick_actions_enabled" in data
        assert "kpi_cards_enabled" in data

    def test_set_portal_config_message(self, api_client):
        resp = api_client.put("/api/admin/business-portal/config",
                              json={"welcome_message": "Hello Test Portal"})
        assert resp.status_code == 200
        assert resp.json()["welcome_message"] == "Hello Test Portal"

    def test_set_portal_config_limits(self, api_client):
        resp = api_client.put("/api/admin/business-portal/config",
                              json={"recent_reports_limit": 5, "favorites_limit": 8})
        assert resp.status_code == 200
        assert resp.json()["recent_reports_limit"] == 5
        assert resp.json()["favorites_limit"] == 8

    def test_set_portal_config_toggles(self, api_client):
        resp = api_client.put("/api/admin/business-portal/config",
                              json={"quick_actions_enabled": False, "kpi_cards_enabled": False})
        assert resp.status_code == 200
        assert resp.json()["quick_actions_enabled"] is False
        assert resp.json()["kpi_cards_enabled"] is False
        # Restore
        api_client.put("/api/admin/business-portal/config",
                       json={"quick_actions_enabled": True, "kpi_cards_enabled": True})


class TestPortalKnownComponents:
    """business_portal should be in KNOWN_COMPONENTS."""

    def test_business_portal_in_known_components(self, api_client):
        resp = api_client.get("/api/admin/ui-visibility")
        assert resp.status_code == 200
        components = resp.json().get("components", [])
        keys = [c[0] for c in components]
        assert "business_portal" in keys
