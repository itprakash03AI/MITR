"""
Shared pytest fixtures for QueryStudio backend tests.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Generator

import pytest

# Ensure backend/ is on sys.path so core.* imports work
_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


@pytest.fixture(scope="session")
def tmp_db_path(tmp_path_factory) -> Path:
    """Return a per-session temporary SQLite file path."""
    return tmp_path_factory.mktemp("db") / "test.db"


@pytest.fixture(scope="session")
def db_manager(tmp_db_path):
    """DatabaseManager backed by a temp SQLite file.
    Tables are created automatically in DatabaseManager.__init__()."""
    from core.database import DatabaseManager
    return DatabaseManager(f"sqlite:///{tmp_db_path}")


@pytest.fixture()
def sqlite_task_queue(db_manager):
    """SqliteTaskQueue instance wrapping the session-scoped DatabaseManager."""
    from core.queue_backend import SqliteTaskQueue
    return SqliteTaskQueue(db_manager)


# ── API integration test fixtures ────────────────────────────────────────────

def _reload_config(cfg_file: Path) -> None:
    """Reload core.config singleton from a given config file."""
    import importlib
    import core.config as _cfg_mod
    os.environ["QUERYSTUDIO_CONFIG"] = str(cfg_file)
    _cfg_mod._cfg = None
    importlib.reload(_cfg_mod)


def _restore_config() -> None:
    """Restore core.config to the real config.json after a test module completes."""
    import importlib
    import core.config as _cfg_mod
    os.environ.pop("QUERYSTUDIO_CONFIG", None)
    _cfg_mod._cfg = None
    importlib.reload(_cfg_mod)


@pytest.fixture(scope="module")
def api_client(tmp_path_factory):
    """
    FastAPI TestClient with auth.type=none (guest admin).
    All endpoints are accessible — no credentials needed.
    Reused across all tests in the module (module scope = one app instance per file).
    """
    cfg_dir = tmp_path_factory.mktemp("api_cfg")
    db_file = cfg_dir / "api_test.db"
    cfg_file = cfg_dir / "config.json"
    cfg_file.write_text(json.dumps({
        "auth": {"type": "none"},
        "server": {"host": "127.0.0.1", "port": 8000},
        "database": {"url": f"sqlite:///{db_file}"},
        "executor": {"mode": "embedded"},
        "queue": {"backend": "sqlite"},
        "paths": {
            "data_dir": str(cfg_dir / "data"),
            "parquet_dir": str(cfg_dir / "data/parquet"),
            "downloads_dir": str(cfg_dir / "data/downloads"),
            "upload_dir": str(cfg_dir / "data/uploads"),
            "db_file": str(db_file),
        },
    }))
    # ensure all data dirs exist
    (cfg_dir / "data" / "parquet").mkdir(parents=True, exist_ok=True)
    (cfg_dir / "data" / "downloads").mkdir(parents=True, exist_ok=True)
    (cfg_dir / "data" / "uploads").mkdir(parents=True, exist_ok=True)

    _reload_config(cfg_file)
    try:
        from fastapi.testclient import TestClient
        from main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c
    finally:
        _restore_config()


@pytest.fixture(scope="module")
def authed_local_client(tmp_path_factory):
    """
    FastAPI TestClient with auth.type=local and a test user.
    Use for testing auth-protected endpoints with real credentials.
    Test user: testuser / TestPass123 with admin role.
    NOTE: Do NOT use in the same test module as api_client — they share global state.
    """
    from core.ad_auth import hash_password
    cfg_dir = tmp_path_factory.mktemp("local_auth_cfg")
    db_file = cfg_dir / "local_test.db"
    cfg_file = cfg_dir / "config.json"
    hashed = hash_password("TestPass123")
    cfg_file.write_text(json.dumps({
        "auth": {
            "type": "local",
            "local_users": f"testuser:{hashed}",
            "user_roles": "testuser:admin",
        },
        "server": {"host": "127.0.0.1", "port": 8000},
        "database": {"url": f"sqlite:///{db_file}"},
        "executor": {"mode": "embedded"},
        "queue": {"backend": "sqlite"},
        "paths": {
            "data_dir": str(cfg_dir / "data"),
            "parquet_dir": str(cfg_dir / "data/parquet"),
            "downloads_dir": str(cfg_dir / "data/downloads"),
            "upload_dir": str(cfg_dir / "data/uploads"),
            "db_file": str(db_file),
        },
    }))
    (cfg_dir / "data" / "parquet").mkdir(parents=True, exist_ok=True)
    (cfg_dir / "data" / "downloads").mkdir(parents=True, exist_ok=True)
    (cfg_dir / "data" / "uploads").mkdir(parents=True, exist_ok=True)

    _reload_config(cfg_file)
    try:
        from fastapi.testclient import TestClient
        from main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c
    finally:
        _restore_config()
