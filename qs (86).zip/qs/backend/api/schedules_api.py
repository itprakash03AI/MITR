"""
Schedules API — CRUD + control for scheduled query/report downloads.

Endpoints:
  GET    /api/schedules                  — list schedules
  POST   /api/schedules                  — create + register with APScheduler
  GET    /api/schedules/{id}             — get schedule detail
  PUT    /api/schedules/{id}             — update (re-registers trigger)
  DELETE /api/schedules/{id}             — remove from scheduler + DB
  POST   /api/schedules/{id}/pause       — pause (keeps trigger, stops firing)
  POST   /api/schedules/{id}/resume      — resume a paused schedule
  POST   /api/schedules/{id}/run-now     — trigger an immediate run
  GET    /api/schedules/scheduler-status — APScheduler health info
"""

from __future__ import annotations

import asyncio
import functools
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query as QParam, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager  = None
_ws_manager  = None
_main_loop   = None
_auth_cfg    = None   # core.config.auth singleton
_sched_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_api")  # legacy, phasing out


def set_schedule_dependencies(db_manager, ws_manager, loop):
    global _db_manager, _ws_manager, _main_loop
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop


def set_schedules_auth(auth_cfg):
    global _auth_cfg
    _auth_cfg = auth_cfg


def _get_current_user_sched(request: Request) -> Optional[dict]:
    """Local version of _get_current_user for the schedules router."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True, "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    # Session token (Bearer) — look up server-side session
    if auth_header.startswith("Bearer "):
        from main import _get_session
        user = _get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user
    # Basic auth fallback
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _is_owner_or_shared_sched(item: dict, user: dict) -> bool:
    if not user or user.get("is_admin"):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
    )


async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        from core.worker_pool import get_pool
        _exec = get_pool().executor
    except RuntimeError:
        _exec = _sched_executor
    if kwargs:
        return await loop.run_in_executor(_exec, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_exec, fn, *args)


def _is_external_scheduler() -> bool:
    """True when the scheduler runs in a separate process."""
    try:
        from core.config import scheduler as _sched_cfg
        return _sched_cfg.mode == "external"
    except Exception:
        return False


async def _scheduler_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Forward a request to the scheduler worker's internal HTTP API."""
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")


# ── Pydantic models ───────────────────────────────────────────────────────────

class TriggerConfig(BaseModel):
    type: str                        # "cron" | "interval"
    cron_expr: Optional[str] = None  # for type="cron": "0 8 * * 1-5"
    minutes: Optional[int]   = None  # for type="interval"
    hours:   Optional[int]   = None
    seconds: Optional[int]   = None


class CreateScheduleRequest(BaseModel):
    name:                    str
    description:             Optional[str] = None
    source_type:             str             # saved_query | sql_query | report
    source_id:               int
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          TriggerConfig
    output_filename_template: Optional[str] = None
    created_by:              Optional[str] = None
    notify_emails:           Optional[str] = None   # comma-separated email addresses
    notify_webhook:          Optional[str] = None   # Slack/Teams/generic webhook URL


class UpdateScheduleRequest(BaseModel):
    name:                    Optional[str] = None
    description:             Optional[str] = None
    source_type:             Optional[str] = None
    source_id:               Optional[int] = None
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          Optional[TriggerConfig] = None
    output_filename_template: Optional[str] = None
    is_active:               Optional[bool] = None
    notify_emails:           Optional[str] = None   # comma-separated email addresses
    notify_webhook:          Optional[str] = None   # Slack/Teams/generic webhook URL


# ── Helper: validate trigger config ──────────────────────────────────────────

def _validate_trigger(tc: TriggerConfig):
    if tc.type == "cron":
        if not tc.cron_expr:
            raise HTTPException(400, "cron_expr is required for type='cron'")
        # Validate the cron expression is parsable
        try:
            from apscheduler.triggers.cron import CronTrigger
            CronTrigger.from_crontab(tc.cron_expr, timezone="UTC")
        except Exception as e:
            raise HTTPException(400, f"Invalid cron expression '{tc.cron_expr}': {e}")
    elif tc.type == "interval":
        if not any([tc.minutes, tc.hours, tc.seconds]):
            raise HTTPException(400, "Specify at least one of: minutes, hours, seconds for type='interval'")
    else:
        raise HTTPException(400, f"Unknown trigger type '{tc.type}'. Use 'cron' or 'interval'.")


def _validate_source(source_type: str, source_id: int):
    if source_type == "saved_query":
        if not _db_manager.get_query(source_id):
            raise HTTPException(404, f"Saved query {source_id} not found")
    elif source_type == "sql_query":
        if not _db_manager.get_sql_query(source_id):
            raise HTTPException(404, f"SQL query {source_id} not found")
    elif source_type == "report":
        if not _db_manager.get_report(source_id):
            raise HTTPException(404, f"Report {source_id} not found")
    else:
        raise HTTPException(400, f"Unknown source_type '{source_type}'. Use: saved_query, sql_query, report")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/schedules/scheduler-status")
async def get_scheduler_status():
    """APScheduler health: running state, active jobs, next fire times."""
    if _is_external_scheduler():
        return await _scheduler_proxy("GET", "/control/status")
    from core.scheduler import get_scheduler_status as _get_status
    return await _run_in_executor(_get_status)


@router.get("/api/schedules")
async def list_schedules(
    request: Request,
    active_only: bool = False,
    limit: int = QParam(200, ge=1, le=1000),
    offset: int = QParam(0, ge=0),
):
    if active_only:
        items = await _run_in_executor(_db_manager.list_schedules, True, limit, offset)
    else:
        items = await _run_in_executor(_db_manager.list_all_schedules, limit, offset)
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sched(request)
        items = [i for i in items if _is_owner_or_shared_sched(i, user)]
    return items


@router.post("/api/schedules", status_code=201)
async def create_schedule(req: CreateScheduleRequest, request: Request):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    _validate_trigger(req.trigger_config)
    await _run_in_executor(_validate_source, req.source_type, req.source_id)

    # Create DB record
    record = await _run_in_executor(
        _db_manager.create_schedule,
        name=req.name,
        description=req.description,
        source_type=req.source_type,
        source_id=req.source_id,
        param_values=req.param_values,
        trigger_config=req.trigger_config.dict(exclude_none=True),
        output_filename_template=req.output_filename_template,
        created_by=(user or {}).get("username") or req.created_by or "guest",
        notify_emails=req.notify_emails,
        notify_webhook=req.notify_webhook,
    )

    # Register with APScheduler
    try:
        if _is_external_scheduler():
            result = await _scheduler_proxy("POST", "/control/add-job", json_body={
                "schedule_id": record["id"],
                "trigger_config": req.trigger_config.dict(exclude_none=True),
                "name": req.name,
            })
            job_id = result.get("job_id")
        else:
            from core.scheduler import add_schedule
            job_id = await _run_in_executor(add_schedule, record)
        record = await _run_in_executor(
            _db_manager.update_schedule, record["id"], apscheduler_job_id=job_id
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to register schedule %s with APScheduler: %s", record["id"], e)
        raise HTTPException(500, f"Schedule saved but APScheduler registration failed: {e}")

    return record


@router.get("/api/schedules/{schedule_id}")
async def get_schedule(schedule_id: int, request: Request):
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    # RLS: non-admins can only see own or shared schedules
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sched(request)
        if not _is_owner_or_shared_sched(s, user):
            raise HTTPException(404, f"Schedule {schedule_id} not found")
    return s


def _require_schedule_owner(user: dict, schedule: dict):
    """Raise 403 if the user is not the owner or admin."""
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        if schedule.get("created_by") != (user or {}).get("username"):
            raise HTTPException(403, "Permission denied")


@router.put("/api/schedules/{schedule_id}")
async def update_schedule(schedule_id: int, req: UpdateScheduleRequest, request: Request):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, existing)

    updates: Dict[str, Any] = {}
    if req.name           is not None: updates["name"]           = req.name
    if req.description    is not None: updates["description"]    = req.description
    if req.source_type    is not None: updates["source_type"]    = req.source_type
    if req.source_id      is not None: updates["source_id"]      = req.source_id
    if req.param_values   is not None: updates["param_values"]   = req.param_values
    if req.is_active      is not None: updates["is_active"]      = req.is_active
    if req.output_filename_template is not None:
        updates["output_filename_template"] = req.output_filename_template
    if req.notify_emails    is not None: updates["notify_emails"]  = req.notify_emails
    if req.notify_webhook   is not None: updates["notify_webhook"] = req.notify_webhook
    if req.trigger_config is not None:
        _validate_trigger(req.trigger_config)
        updates["trigger_config"] = req.trigger_config.dict(exclude_none=True)

    if req.source_type and req.source_id:
        await _run_in_executor(_validate_source, req.source_type, req.source_id)

    record = await _run_in_executor(_db_manager.update_schedule, schedule_id, **updates)

    # Re-register with APScheduler if trigger or active state changed
    if "trigger_config" in updates or "is_active" in updates:
        try:
            if _is_external_scheduler():
                if existing.get("apscheduler_job_id"):
                    await _scheduler_proxy("POST", f"/control/remove-job/{existing['apscheduler_job_id']}")
                if record.get("is_active"):
                    result = await _scheduler_proxy("POST", "/control/add-job", json_body={
                        "schedule_id": schedule_id,
                        "trigger_config": record.get("trigger_config", {}),
                        "name": record.get("name", ""),
                    })
                    job_id = result.get("job_id")
                    record = await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=job_id
                    )
                else:
                    await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=None
                    )
            else:
                from core.scheduler import add_schedule, remove_schedule
                if existing.get("apscheduler_job_id"):
                    await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
                if record.get("is_active"):
                    job_id = await _run_in_executor(add_schedule, record)
                    record = await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=job_id
                    )
                else:
                    await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=None
                    )
        except HTTPException:
            raise
        except Exception as e:
            logger.error("APScheduler update failed for schedule %s: %s", schedule_id, e)

    return record


@router.delete("/api/schedules/{schedule_id}")
async def delete_schedule(schedule_id: int, request: Request):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, existing)

    # Remove from APScheduler first
    if existing.get("apscheduler_job_id"):
        try:
            if _is_external_scheduler():
                await _scheduler_proxy("POST", f"/control/remove-job/{existing['apscheduler_job_id']}")
            else:
                from core.scheduler import remove_schedule
                await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
        except Exception as e:
            logger.warning("APScheduler remove failed for schedule %s: %s", schedule_id, e)

    success = await _run_in_executor(_db_manager.delete_schedule, schedule_id)
    if not success:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    return {"message": "Deleted", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/pause")
async def pause_schedule(schedule_id: int, request: Request):
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        if _is_external_scheduler():
            await _scheduler_proxy("POST", f"/control/pause-job/{s['apscheduler_job_id']}")
        else:
            from core.scheduler import pause_schedule as _pause
            await _run_in_executor(_pause, s["apscheduler_job_id"])
        await _run_in_executor(_db_manager.update_schedule, schedule_id, is_active=False)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Pause failed: {e}")
    return {"message": "Paused", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/resume")
async def resume_schedule(schedule_id: int, request: Request):
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        if _is_external_scheduler():
            result = await _scheduler_proxy("POST", f"/control/resume-job/{s['apscheduler_job_id']}")
            next_run = result.get("next_run")
        else:
            from core.scheduler import resume_schedule as _resume
            next_run = await _run_in_executor(_resume, s["apscheduler_job_id"])
        await _run_in_executor(
            _db_manager.update_schedule, schedule_id, is_active=True, next_run_at=next_run
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Resume failed: {e}")
    return {"message": "Resumed", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/run-now")
async def run_schedule_now(schedule_id: int, request: Request):
    """Trigger an immediate out-of-schedule run. Does not affect the regular trigger."""
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    try:
        if _is_external_scheduler():
            await _scheduler_proxy("POST", f"/control/run-now/{schedule_id}")
        else:
            from core.scheduler import run_now
            await _run_in_executor(run_now, schedule_id)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Immediate run failed: {e}")
    return {"message": "Triggered", "schedule_id": schedule_id}


# -- Schedule run stats (Phase 38 anomaly detection) ---------------------------

@router.get("/api/schedules/{schedule_id}/run-stats")
async def get_schedule_run_stats(schedule_id: int, request: Request, limit: int = 20):
    """Get historical run statistics for a schedule (for anomaly detection charts)."""
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    stats = await _run_in_executor(_db_manager.get_schedule_run_stats, schedule_id, limit)
    return {"run_stats": stats}
