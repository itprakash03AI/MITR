"""
Report Bursting API (Phase 23E)

The #1 enterprise reporting differentiator — run one report per distinct value
of a dimension column and deliver each slice to the right recipient.

Workflow:
  1. POST /api/reports/{id}/burst — define burst job (column, recipients, format)
  2. System queries distinct values of burst_column from the report's source
  3. One BurstTask is created per value
  4. Each task runs the report filtered to its value, generates output, delivers it
  5. GET /api/reports/burst/{job_id} — check progress

Delivery options:
  - email:  attach PDF/Excel to per-value email
  - s3:     write to s3_prefix/{value}/filename.ext

Example: Burst "Monthly Sales" by "region" column
  → APAC team gets APAC-only PDF
  → EMEA team gets EMEA-only PDF
  → Each delivered to their email automatically
"""
from __future__ import annotations

import logging
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query as QParam, Request
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager     = None
_auth_cfg       = None
_execute_report = None   # callable(report_id, param_values, username, limit) -> DataFrame
_email_svc      = None


def set_burst_dependencies(db_manager, auth_cfg, execute_report_fn,
                            email_service=None):
    global _db_manager, _auth_cfg, _execute_report, _email_svc
    _db_manager     = db_manager
    _auth_cfg       = auth_cfg
    _execute_report = execute_report_fn
    _email_svc      = email_service


def _get_user(request: Request) -> dict:
    import base64
    hdr = request.headers.get("authorization", "")
    if hdr.startswith("Basic "):
        try:
            decoded = base64.b64decode(hdr[6:]).decode()
            return {"username": decoded.split(":")[0], "role": "analyst"}
        except Exception:
            pass
    return {"username": "anonymous", "role": "viewer"}


# ── Pydantic ──────────────────────────────────────────────────────────────────

class BurstJobRequest(BaseModel):
    burst_column:      str
    base_params:       Dict[str, Any] = {}
    output_format:     str = Field(default="pdf", pattern="^(pdf|excel|csv)$")
    delivery_type:     str = Field(default="email", pattern="^(email|s3)$")
    recipient_map:     Optional[Dict[str, str]] = None   # {"APAC": "apac@co.com", ...}
    default_recipient: Optional[str] = None
    s3_prefix:         Optional[str] = None


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/reports/{report_id}/burst-jobs")
async def list_burst_jobs(report_id: int,
                          limit: int = QParam(default=20, ge=1, le=100)):
    return {"jobs": _db_manager.list_burst_jobs(report_id, limit=limit)}


@router.post("/api/reports/{report_id}/burst", status_code=202)
async def trigger_burst(report_id: int, body: BurstJobRequest, request: Request):
    """Create a burst job and start processing in the background."""
    user = _get_user(request)

    if body.delivery_type == "email" and not body.default_recipient and not body.recipient_map:
        raise HTTPException(status_code=400,
                            detail="Provide default_recipient or recipient_map for email delivery")
    if body.delivery_type == "s3" and not body.s3_prefix:
        raise HTTPException(status_code=400, detail="Provide s3_prefix for S3 delivery")

    job = _db_manager.create_burst_job(
        report_id=report_id, burst_column=body.burst_column,
        output_format=body.output_format, delivery_type=body.delivery_type,
        base_params=body.base_params, recipient_map=body.recipient_map,
        default_recipient=body.default_recipient, s3_prefix=body.s3_prefix,
        created_by=user["username"],
    )

    threading.Thread(
        target=_run_burst_job,
        args=(job["id"], report_id, body, user["username"]),
        daemon=True,
    ).start()

    return {"job_id": job["id"], "status": "started",
            "message": "Burst job queued. Poll GET /api/reports/burst/{job_id} for progress."}


@router.get("/api/reports/burst/{job_id}")
async def get_burst_job(job_id: int):
    job = _db_manager.get_burst_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Burst job not found")
    tasks = _db_manager.list_burst_tasks(job_id)
    return {"job": job, "tasks": tasks}


@router.post("/api/reports/burst/{job_id}/cancel")
async def cancel_burst_job(job_id: int):
    job = _db_manager.get_burst_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Burst job not found")
    if job["status"] not in ("pending", "running"):
        raise HTTPException(status_code=409, detail=f"Cannot cancel job in status '{job['status']}'")
    _db_manager.update_burst_job(job_id, status="cancelled")
    return {"job_id": job_id, "status": "cancelled"}


# ── Background burst runner ───────────────────────────────────────────────────

def _run_burst_job(job_id: int, report_id: int, body: BurstJobRequest,
                   username: str) -> None:
    """Execute burst job in background thread."""
    try:
        _db_manager.update_burst_job(job_id, status="running",
                                     started_at=datetime.now(timezone.utc))

        # Step 1: Get distinct values of burst_column from unfiltered report
        try:
            full_df = _execute_report(report_id, body.base_params, username,
                                      limit=100000)
        except Exception as exc:
            _db_manager.update_burst_job(job_id, status="failed",
                                         error_message=f"Failed to fetch distinct values: {exc}",
                                         completed_at=datetime.now(timezone.utc))
            return

        if body.burst_column not in full_df.columns:
            _db_manager.update_burst_job(job_id, status="failed",
                                         error_message=f"Column '{body.burst_column}' not found in report",
                                         completed_at=datetime.now(timezone.utc))
            return

        distinct_values = [str(v) for v in full_df[body.burst_column].dropna().unique()
                           if str(v).strip()]
        if not distinct_values:
            _db_manager.update_burst_job(job_id, status="done",
                                         total_tasks=0,
                                         completed_at=datetime.now(timezone.utc))
            return

        # Step 2: Create one BurstTask per distinct value
        recipient_map = body.recipient_map or {}
        task_defs = []
        for val in distinct_values:
            recipient = (recipient_map.get(val)
                         or body.default_recipient
                         or (f"{val.lower().replace(' ', '_')}@{body.s3_prefix or 'output'}"
                             if body.delivery_type == "s3" else None))
            task_defs.append({"dimension_value": val, "recipient": recipient})

        tasks = _db_manager.create_burst_tasks(job_id, task_defs)
        _db_manager.update_burst_job(job_id, total_tasks=len(tasks))

        done = 0
        failed = 0

        # Step 3: Run each task
        for task in tasks:
            # Check if job was cancelled
            current = _db_manager.get_burst_job(job_id)
            if current and current.get("status") == "cancelled":
                break

            task_id = task["id"]
            val = task["dimension_value"]
            recipient = task["recipient"]

            _db_manager.update_burst_task(task_id, status="running",
                                           started_at=datetime.now(timezone.utc))
            try:
                # Run report filtered to this dimension value
                task_params = {**body.base_params, body.burst_column: val}
                slice_df = _execute_report(report_id, task_params, username,
                                           limit=100000)

                # Generate output file
                output_path = _generate_output(job_id, task_id, val, slice_df,
                                                body.output_format)

                # Deliver
                _deliver_burst_task(task_id, output_path, recipient,
                                    body.delivery_type, body.output_format,
                                    body.s3_prefix, val)

                _db_manager.update_burst_task(task_id, status="done",
                                               output_file=output_path,
                                               completed_at=datetime.now(timezone.utc))
                done += 1
            except Exception as exc:
                error_str = str(exc)
                logger.error("Burst task %s failed: %s", task_id, error_str)
                _db_manager.update_burst_task(task_id, status="failed",
                                               error_message=error_str,
                                               completed_at=datetime.now(timezone.utc))
                failed += 1

            _db_manager.update_burst_job(job_id, done_tasks=done, failed_tasks=failed)

        final_status = "done" if failed == 0 else ("failed" if done == 0 else "partial")
        _db_manager.update_burst_job(job_id, status=final_status,
                                     completed_at=datetime.now(timezone.utc))

    except Exception as exc:
        logger.error("Burst job %s crashed: %s", job_id, exc, exc_info=True)
        _db_manager.update_burst_job(job_id, status="failed",
                                     error_message=str(exc),
                                     completed_at=datetime.now(timezone.utc))


def _generate_output(job_id: int, task_id: int, value: str,
                     df, fmt: str) -> str:
    """Write DataFrame to a temp file in the requested format. Returns file path."""
    import tempfile, os
    safe_val = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(value))
    suffix = f".{fmt}" if fmt != "excel" else ".xlsx"
    fd, path = tempfile.mkstemp(
        prefix=f"burst_{job_id}_{task_id}_{safe_val}_",
        suffix=suffix,
    )
    os.close(fd)

    if fmt == "csv":
        df.to_csv(path, index=False)
    elif fmt in ("excel", "xlsx"):
        df.to_excel(path, index=False)
    elif fmt == "pdf":
        try:
            import weasyprint as _wp
            from api.pdf_export_api import _build_pdf_html, _build_pdf_css
            cfg = _db_manager.get_pdf_config(
                # job → report_id not directly available here; use defaults
                0
            ) if _db_manager else {}
            fmt_rules = []
            html = _build_pdf_html(df, f"Burst: {value}", {}, cfg, fmt_rules)
            css  = _build_pdf_css(cfg)
            pdf_bytes = _wp.HTML(string=html).write_pdf(
                stylesheets=[_wp.CSS(string=css)]
            )
            with open(path, "wb") as f:
                f.write(pdf_bytes)
        except Exception as exc:
            logger.warning("PDF generation failed for burst task, falling back to CSV: %s", exc)
            csv_path = path.replace(".pdf", ".csv")
            df.to_csv(csv_path, index=False)
            return csv_path
    return path


def _deliver_burst_task(task_id: int, output_path: str, recipient: Optional[str],
                        delivery_type: str, fmt: str, s3_prefix: Optional[str],
                        dimension_value: str) -> None:
    """Deliver the generated file to email or S3."""
    if delivery_type == "email" and recipient and _email_svc:
        try:
            subject = f"Report: {dimension_value}"
            body_text = f"Please find your report for {dimension_value} attached."
            _email_svc.send_email_with_attachment(
                to=recipient, subject=subject, body=body_text,
                attachment_path=output_path,
            )
            _db_manager.record_delivery(
                delivery_type="email", destination=recipient, status="delivered",
                burst_task_id=task_id, file_format=fmt,
            )
        except Exception as exc:
            _db_manager.record_delivery(
                delivery_type="email", destination=recipient or "", status="failed",
                burst_task_id=task_id, error_message=str(exc),
            )
            raise

    elif delivery_type == "s3" and s3_prefix:
        import os
        filename = os.path.basename(output_path)
        safe_val = "".join(c if c.isalnum() or c in "-_" else "_"
                           for c in str(dimension_value))
        s3_key = s3_prefix.rstrip("/") + f"/{safe_val}/{filename}"
        try:
            import boto3
            s3 = boto3.client("s3")
            bucket = s3_prefix.split("/")[0] if "/" in s3_prefix else s3_prefix
            s3.upload_file(output_path, bucket, s3_key)
            _db_manager.record_delivery(
                delivery_type="s3", destination=s3_key, status="delivered",
                burst_task_id=task_id, file_format=fmt,
            )
        except Exception as exc:
            _db_manager.record_delivery(
                delivery_type="s3", destination=s3_key, status="failed",
                burst_task_id=task_id, error_message=str(exc),
            )
            raise
