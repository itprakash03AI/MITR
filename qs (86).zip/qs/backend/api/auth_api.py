"""
Authentication endpoints — login / logout / me / config.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_auth_dependencies(limiter, auth_cfg)`` once at startup
    (in main.py after config is loaded).
"""
from __future__ import annotations

import os
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from api.deps import get_current_user
from core.sessions import create_session, destroy_session

logger = logging.getLogger(__name__)

router = APIRouter(tags=["auth"])

# ── Module-level singletons set by main.py at startup ─────────────────────────
_limiter   = None   # slowapi.Limiter
_auth_cfg  = None   # core.config.auth singleton


def set_auth_dependencies(limiter, auth_cfg) -> None:
    """Called once from main.py after config + limiter are created."""
    global _limiter, _auth_cfg
    _limiter  = limiter
    _auth_cfg = auth_cfg


# ── Pydantic models ───────────────────────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    password: str


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_container_env() -> bool:
    """Detect if running inside Docker/OpenShift/Kubernetes."""
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/auth/login")
async def login(request: Request, req: _LoginRequest):
    """
    Authenticate and return a session token + user info.

    Password is verified once, then discarded — only the opaque token is
    persisted server-side.  Clients send the token as ``Bearer <token>``
    on subsequent requests.

    Rate-limited to 10 attempts/minute per IP.
    """
    # Per-IP rate check using the custom sliding-window limiter
    if _limiter is not None:
        try:
            from core.rate_limiter import check_rate_limit
            ip = (request.client.host if request.client else "unknown")
            check_rate_limit("auth_login", ip, limit=10, window_seconds=60)
        except Exception as exc:
            from core.rate_limiter import RateLimitExceededError
            if isinstance(exc, RateLimitExceededError):
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many login attempts. Retry after {exc.retry_after}s.",
                    headers={"Retry-After": str(exc.retry_after)},
                )

    from core.ad_auth import authenticate_user
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = create_session(user)
    return {**user, "session_token": token}


@router.post("/auth/logout")
async def logout_endpoint(request: Request):
    """Destroy the server-side session associated with the caller's Bearer token."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        destroy_session(auth_header[7:])
    return {"message": "Logged out"}


@router.get("/auth/me")
async def whoami(request: Request):
    """Return the current user's identity (or guest when auth is disabled)."""
    return get_current_user(request)


@router.get("/auth/config")
async def auth_config():
    """Return auth configuration visible to the frontend (type only — no secrets)."""
    auth_type = _auth_cfg.type if _auth_cfg else "none"
    ad_domain  = _auth_cfg.ad_domain if _auth_cfg else ""
    return {
        "type": auth_type,
        "domain": ad_domain,
        "upload_enabled": _is_container_env(),
    }
