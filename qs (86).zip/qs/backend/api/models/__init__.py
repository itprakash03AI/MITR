# API Pydantic models — extracted from main.py for maintainability
