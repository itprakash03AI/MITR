"""
Pydantic request/response models for the QueryStudio API.

Extracted from main.py to keep the main module focused on app wiring,
middleware, and startup/shutdown logic.
"""
from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional, Union


# ── Connection type pattern (shared constant) ────────────────────────────────
ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle)$"


# ── S3 / Connection models ───────────────────────────────────────────────────

class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# ── Query builder models ─────────────────────────────────────────────────────

class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None


# ── Save / Execute request models ────────────────────────────────────────────

class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cache strategy: auto = use cache if available; bypass = skip cache (no store);
    #                 refresh = skip cache lookup but store fresh result
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None
    # Async control fields
    wait: bool = False                     # Block until complete (external executor mode only)
    wait_timeout: int = Field(default=30, ge=1, le=300)  # Max seconds to wait
    callback_url: Optional[str] = None    # Webhook POST on completion/failure
    idempotency_key: Optional[str] = None  # Client-generated UUID to prevent duplicate submissions


class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None


class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


# ── Streaming (DuckDB httpfs) models ─────────────────────────────────────────

class StreamQueryRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    limit: int = Field(default=500, ge=1, le=5000)


class StreamPaginateRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=100, ge=1, le=5000)
    sort_column: Optional[str] = None
    sort_direction: str = Field(default="asc")
    adv_filters: Optional[str] = None
    columns: Optional[str] = None


class StreamSchemaRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    sample_rows: int = Field(default=100, ge=0, le=1000)


class StreamChartRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    x_col: str
    y_col: str
    agg: str = "sum"
    top_n: int = 50
    series_col: Optional[str] = None
    max_series: int = 10


class StreamPivotRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    row_fields: str          # comma-separated
    values: str              # JSON array
    col_field: Optional[str] = None
    top_n: int = 50


class EstimateRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


# ── Preview / Join models ────────────────────────────────────────────────────

class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"


# ── Batch execution models ───────────────────────────────────────────────────

class BatchQueryItem(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    callback_url: Optional[str] = None
    priority: int = Field(default=5, ge=0, le=9)
    label: Optional[str] = None   # caller-defined label for tracking


class BatchSubmitRequest(BaseModel):
    queries: List[BatchQueryItem] = Field(..., min_length=1, max_length=50)


# ── Worker pool / Admin config models ────────────────────────────────────────

class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent: Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue: Optional[int] = None
    report_max_concurrent: Optional[int] = None
    report_default_timeout: Optional[int] = None
    report_max_queue: Optional[int] = None
    scheduled_max_concurrent: Optional[int] = None
    scheduled_default_timeout: Optional[int] = None
    scheduled_max_queue: Optional[int] = None
    export_max_concurrent: Optional[int] = None
    export_default_timeout: Optional[int] = None
    export_max_queue: Optional[int] = None
    system_max_concurrent: Optional[int] = None
    system_default_timeout: Optional[int] = None
    system_max_queue: Optional[int] = None


class AppConfigUpdateRequest(BaseModel):
    limits: Optional[dict] = None
    features: Optional[dict] = None


class QueueConfigUpdateRequest(BaseModel):
    backend: Optional[str] = None
    redis_url: Optional[str] = None
    redis_password: Optional[str] = None
    redis_db: Optional[int] = None
    redis_ssl: Optional[bool] = None
    key_prefix: Optional[str] = None
    task_ttl_hours: Optional[int] = None


# ── Cache invalidation ───────────────────────────────────────────────────────

class CacheInvalidateSourceRequest(BaseModel):
    table_name:    Optional[str] = None   # registered table name (e.g. "orders")
    file_prefix:   Optional[str] = None   # S3/local prefix (e.g. "data/orders/")
    connection_id: Optional[int] = None   # invalidate all queries for a connection


# ── Registered table model ───────────────────────────────────────────────────

class RegisteredTableModel(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""


# ── Materialized view models ─────────────────────────────────────────────────

class MaterializedViewCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    connection_id: int
    table_name: str
    table_format: str = "parquet"
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None


class MaterializedViewUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    is_active: Optional[bool] = None


# ── Local table models ───────────────────────────────────────────────────────

class LocalTableCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


class LocalTableUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    visibility: Optional[str] = None
    auto_discard_days: Optional[int] = None
    is_active: Optional[bool] = None


class LocalTablePromoteModel(BaseModel):
    file_id: str
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


# ── Auth / User models (used in main.py auth section) ────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class SubjectExportRequest(BaseModel):
    username: str


class UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"
