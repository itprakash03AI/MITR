"""
Report Catalog API (Phase 23A + Phase 58 unified catalog)

Endpoints:
  GET    /api/report-catalog            — unified catalog (parametric + business reports)
  GET    /api/report-folders            — list folders (optionally by parent)
  POST   /api/report-folders            — create folder
  PUT    /api/report-folders/{id}       — rename / recolor
  DELETE /api/report-folders/{id}       — delete (re-parents children)

  POST   /api/reports/{id}/folder       — assign report to folder (or None to un-assign)
  GET    /api/report-tags               — list all tags
  POST   /api/report-tags               — create tag
  DELETE /api/report-tags/{id}          — delete tag + remove assignments
  POST   /api/reports/{id}/tags         — replace tag assignments for a report
  GET    /api/reports/{id}/tags         — get tags for a report

  POST   /api/reports/{id}/favorite     — toggle user favorite
  GET    /api/reports/favorites         — user's favorited report ids
  POST   /api/reports/{id}/view         — record a report view (recently viewed)
  GET    /api/reports/recent            — recently viewed report ids
  GET    /api/reports/search            — unified search (parametric + business)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as QParam
from pydantic import BaseModel

from api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None


def set_catalog_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Catalog API not initialised")
    return _db_manager


# ── Pydantic models ───────────────────────────────────────────────────────────

class FolderCreate(BaseModel):
    name:        str
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        str = "folder"
    color:       str = "#1976d2"


class FolderUpdate(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None
    parent_id:   Optional[int] = None
    icon:        Optional[str] = None
    color:       Optional[str] = None


class TagCreate(BaseModel):
    name:  str
    color: str = "#666666"


class TagAssignRequest(BaseModel):
    tag_ids: List[int]


class FolderAssignRequest(BaseModel):
    folder_id: Optional[int] = None   # None = remove from folder
    report_type: str = "parametric"    # "parametric" | "business"


# ── Main catalog endpoint ────────────────────────────────────────────────────

@router.get("/api/report-catalog")
async def get_report_catalog(user: dict = Depends(get_current_user)):
    """Return unified catalog: folder tree + tags + favorites + recent for both report types."""
    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    folders_all = db.list_folders(all_folders=True)
    tags_all    = db.list_tags()

    # Favorites and recent across both types
    favorites   = db.get_user_favorites(username, report_type=None)
    recent_ids  = db.get_recently_viewed(username, limit=10, report_type=None)

    # Parametric reports
    try:
        parametric = db.list_reports(active_only=True)
    except Exception:
        parametric = []

    # Business reports (user sees own + published, admin sees all)
    try:
        if role == "admin":
            business = db.list_business_reports()
        else:
            own = db.list_business_reports(owner=username)
            published = db.list_business_reports(is_published=True)
            seen_ids = {r["id"] for r in own}
            business = list(own)
            for r in published:
                if r["id"] not in seen_ids:
                    business.append(r)
    except Exception:
        business = []

    # Tag each with report_type for the frontend
    for r in parametric:
        r["report_type"] = "parametric"
    for r in business:
        r["report_type"] = "business"

    # Build folder tree
    def _build_tree(parent_id):
        children = [f for f in folders_all if f["parent_id"] == parent_id]
        for c in children:
            c["children"] = _build_tree(c["id"])
        return children

    return {
        "folders":   _build_tree(None),
        "tags":      tags_all,
        "favorites": favorites,
        "recent":    recent_ids,
        "parametric_reports": parametric,
        "business_reports":   business,
    }


# ── Folder endpoints ──────────────────────────────────────────────────────────

@router.get("/api/report-folders")
async def list_folders(parent_id: Optional[int] = None,
                       user: dict = Depends(get_current_user)):
    db = _require_db()
    return {"folders": db.list_folders(parent_id=parent_id)}


@router.post("/api/report-folders", status_code=201)
async def create_folder(body: FolderCreate, user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    folder = db.create_folder(
        name=body.name, description=body.description,
        parent_id=body.parent_id, created_by=username,
        icon=body.icon, color=body.color,
    )
    return folder


@router.put("/api/report-folders/{folder_id}")
async def update_folder(folder_id: int, body: FolderUpdate,
                        user: dict = Depends(get_current_user)):
    db = _require_db()
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = db.update_folder(folder_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Folder not found")
    return result


@router.delete("/api/report-folders/{folder_id}")
async def delete_folder(folder_id: int, user: dict = Depends(get_current_user)):
    db = _require_db()
    ok = db.delete_folder(folder_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Folder not found")
    return {"deleted": True, "folder_id": folder_id}


@router.post("/api/reports/{report_id}/folder")
async def assign_report_folder(report_id: int, body: FolderAssignRequest,
                               user: dict = Depends(get_current_user)):
    db = _require_db()
    db.set_report_folder(report_id, body.folder_id, report_type=body.report_type)
    return {"report_id": report_id, "folder_id": body.folder_id,
            "report_type": body.report_type}


# ── Tag endpoints ─────────────────────────────────────────────────────────────

@router.get("/api/report-tags")
async def list_tags(user: dict = Depends(get_current_user)):
    db = _require_db()
    return {"tags": db.list_tags()}


@router.post("/api/report-tags", status_code=201)
async def create_tag(body: TagCreate, user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    tag = db.create_tag(name=body.name, color=body.color,
                        created_by=username)
    return tag


@router.delete("/api/report-tags/{tag_id}")
async def delete_tag(tag_id: int, user: dict = Depends(get_current_user)):
    db = _require_db()
    ok = db.delete_tag(tag_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Tag not found")
    return {"deleted": True, "tag_id": tag_id}


@router.post("/api/reports/{report_id}/tags")
async def assign_tags(report_id: int, body: TagAssignRequest,
                      report_type: str = QParam(default="parametric"),
                      user: dict = Depends(get_current_user)):
    db = _require_db()
    db.assign_report_tags(report_id, body.tag_ids, report_type=report_type)
    return {"report_id": report_id, "tag_ids": body.tag_ids,
            "report_type": report_type}


@router.get("/api/reports/{report_id}/tags")
async def get_report_tags(report_id: int,
                          report_type: str = QParam(default="parametric"),
                          user: dict = Depends(get_current_user)):
    db = _require_db()
    return {"tags": db.get_report_tags(report_id, report_type=report_type)}


# ── Favorites & Recently Viewed ───────────────────────────────────────────────

@router.post("/api/reports/{report_id}/favorite")
async def toggle_favorite(report_id: int,
                          report_type: str = QParam(default="parametric"),
                          user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    added = db.toggle_report_favorite(report_id, username, report_type=report_type)
    return {"report_id": report_id, "favorited": added, "report_type": report_type}


@router.get("/api/reports/favorites")
async def get_favorites(report_type: Optional[str] = QParam(default=None),
                        user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    return {"favorites": db.get_user_favorites(username, report_type=report_type)}


@router.post("/api/reports/{report_id}/view")
async def record_view(report_id: int,
                      report_type: str = QParam(default="parametric"),
                      user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    db.record_report_view(report_id, username, report_type=report_type)
    return {"recorded": True}


@router.get("/api/reports/recent")
async def get_recent(report_type: Optional[str] = QParam(default=None),
                     limit: int = QParam(default=10, ge=1, le=50),
                     user: dict = Depends(get_current_user)):
    db = _require_db()
    username = (user or {}).get("username", "")
    return {"recent": db.get_recently_viewed(username, limit, report_type=report_type)}


# ── Search (unified) ────────────────────────────────────────────────────────

@router.get("/api/reports/search")
async def search_reports(q: str = QParam(min_length=1),
                         limit: int = QParam(default=30, ge=1, le=100),
                         user: dict = Depends(get_current_user)):
    """Unified search across both parametric and business reports."""
    db = _require_db()
    results = db.search_reports_unified(q, limit=limit)
    return {"results": results, "count": len(results)}
