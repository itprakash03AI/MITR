"""
S3 Streaming execution endpoints — DuckDB httpfs direct queries.

5 endpoints:
- POST /api/execute/stream          — full streaming query
- POST /api/execute/stream/schema   — lightweight column discovery
- POST /api/execute/stream/paginate — paginated S3 streaming
- POST /api/execute/stream/chart-data — chart aggregation on S3
- POST /api/execute/stream/pivot-data — pivot aggregation on S3

Extracted from main.py for maintainability.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time

from fastapi import APIRouter, HTTPException, Depends, Request

from api.deps import get_current_user
from api.models.query_models import (
    StreamQueryRequest, StreamSchemaRequest, StreamPaginateRequest,
    StreamChartRequest, StreamPivotRequest,
)
from core.query_converter import (
    convert_query_config_to_engine, translate_join_columns,
    rewrite_registered_refs, strip_sql_limit,
)
from core.error_detection import jsonify_value, jsonify_rows, raise_if_s3_auth_error, classify_duckdb_error
from core.s3_utilities import extract_partition_filters_from_query
from core.s3_storage import build_s3_config
from core.parquet_engine_v2 import ParquetQueryEngine

logger = logging.getLogger(__name__)

router = APIRouter(tags=["streaming"])

# ── Module-level singletons — populated by set_stream_dependencies() ──────
_db_manager = None
_paths = None
_qe_cfg = None
_limits_cfg = None
_register_s3_views_fn = None
_get_light_executor_fn = None


def set_stream_dependencies(db_manager, paths, qe_cfg, limits_cfg,
                            register_s3_views_fn, get_light_executor_fn):
    """Call once from main.py after all components are initialised."""
    global _db_manager, _paths, _qe_cfg, _limits_cfg
    global _register_s3_views_fn, _get_light_executor_fn
    _db_manager = db_manager
    _paths = paths
    _qe_cfg = qe_cfg
    _limits_cfg = limits_cfg
    _register_s3_views_fn = register_s3_views_fn
    _get_light_executor_fn = get_light_executor_fn


# ── Helper: fix stale EXCLUDE columns from Iceberg schema evolution ──────
def _fix_stale_excludes(con, sql: str) -> str:
    """Remove EXCLUDE columns that don't exist in actual DuckDB views.

    Handles Iceberg schema evolution: a saved query config may reference
    columns (via right_column_aliases) that have since been dropped.
    Pattern: (SELECT * EXCLUDE ("col1", "col2"), "col1" AS "a1", "col2" AS "a2" FROM "viewname")
    """
    _EXCL_PATTERN = re.compile(
        r'\(SELECT \* EXCLUDE \(([^)]+)\)'       # group 1: exclude list
        r'((?:\s*,\s*"[^"]+"\s+AS\s+"[^"]+")*)'  # group 2: rename list
        r'\s+FROM\s+"([^"]+)"\)'                  # group 3: view/table name
    )

    def _fix_match(m):
        exclude_str = m.group(1)
        renames_str = m.group(2)
        table_name = m.group(3)
        try:
            cols_result = con.execute(f'SELECT * FROM "{table_name}" LIMIT 0')
            actual_cols = {desc[0] for desc in cols_result.description}
        except Exception:
            return m.group(0)  # can't validate, leave as-is

        exclude_cols = [c.strip().strip('"') for c in exclude_str.split(',')]
        valid_excludes = [c for c in exclude_cols if c in actual_cols]

        if len(valid_excludes) == len(exclude_cols):
            return m.group(0)  # all columns exist, no change

        if not valid_excludes:
            logger.warning("Stripped all EXCLUDE columns for '%s' (schema evolution): %s",
                           table_name, exclude_cols)
            return f'(SELECT * FROM "{table_name}")'

        valid_set = set(valid_excludes)
        new_excludes = ", ".join(f'"{c}"' for c in valid_excludes)
        _REN_RE = re.compile(r'"([^"]+)"\s+AS\s+"[^"]+"')
        new_renames = [rm.group(0) for rm in _REN_RE.finditer(renames_str) if rm.group(1) in valid_set]
        renames_part = (", " + ", ".join(new_renames)) if new_renames else ""
        logger.warning("Stripped stale EXCLUDE columns for '%s': %s",
                       table_name, [c for c in exclude_cols if c not in valid_set])
        return f'(SELECT * EXCLUDE ({new_excludes}){renames_part} FROM "{table_name}")'

    return _EXCL_PATTERN.sub(_fix_match, sql)


# ── Common helper: build inner SQL from request ─────────────────────────
def _build_inner_sql(request, cfg, registered_tables, bucket, conn_id):
    """Build inner SQL from raw_sql or query_config. Returns (sql, partition_filters)."""
    if request.raw_sql:
        pf = None
        return request.raw_sql, pf

    if request.query_config:
        engine_config = convert_query_config_to_engine(request.query_config)
        translate_join_columns(engine_config)
        s3_engine = ParquetQueryEngine(
            base_path=str(_paths.parquet_dir),
            chunk_size=_qe_cfg.chunk_size,
            s3_config=build_s3_config(cfg),
        )
        if registered_tables:
            s3_engine._registered_tables = registered_tables
            s3_engine._s3_conn_config = cfg
            s3_engine._s3_bucket = bucket
            s3_engine._s3_conn_id = conn_id
        inner_sql = s3_engine.get_duckdb_sql(engine_config)
        inner_sql = rewrite_registered_refs(inner_sql, registered_tables)
        pf = extract_partition_filters_from_query(request.query_config)
        return inner_sql, pf

    raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")


def _resolve_connection(request, endpoint_name: str):
    """Resolve connection_id and validate it's an S3 connection."""
    conn_id = getattr(request, 'connection_id', None)
    if not conn_id and hasattr(request, 'query_config') and request.query_config:
        conn_id = request.query_config.connection_id
    if not conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required")

    conn = _db_manager.get_connection_raw(conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail=f"Streaming {endpoint_name} only supported for S3 connections")

    return conn_id, conn, conn.get("config", {})


def _get_refs(registered_tables, sql):
    """Extract referenced table names from SQL for selective view registration."""
    refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in sql}
    if ('"__mv__' in sql or '"__lt__' in sql) and refs:
        refs = None  # MV/local refs present — register all views
    return refs


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream — DuckDB httpfs streaming (direct S3 query)
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream")
async def stream_query(request: StreamQueryRequest, _user: dict = Depends(get_current_user)):
    """Stream query results directly from S3 via DuckDB httpfs."""
    try:
        from core.aws_portal_auth import _current_portal_user
        _current_portal_user.set(_user.get("username", ""))
    except Exception:
        pass

    t0 = time.monotonic()
    conn_id, conn, cfg = _resolve_connection(request, "query")

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()
        inner_sql, pf = _build_inner_sql(request, cfg, registered_tables, bucket, conn_id)

        stripped_sql = strip_sql_limit(inner_sql)
        stream_sql = f"SELECT * FROM ({stripped_sql}) _stream LIMIT {request.limit}"

        loop = asyncio.get_running_loop()

        def _run_stream():
            nonlocal stream_sql
            con = _duckdb_con_with_s3(cfg, connection_id=conn_id)
            try:
                _refs = _get_refs(registered_tables, stream_sql)
                _register_s3_views_fn(con, registered_tables, bucket, conn_id, cfg,
                                      referenced_tables=_refs or None, partition_filters=pf)
                if "EXCLUDE" in stream_sql:
                    stream_sql = _fix_stale_excludes(con, stream_sql)
                result = con.execute(stream_sql)
                columns = [desc[0] for desc in result.description]
                rows = result.fetchall()
                return {"columns": columns, "rows": [list(r) for r in rows]}
            finally:
                con.close()

        try:
            data = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor_fn(), _run_stream),
                timeout=600.0,
            )
        except asyncio.TimeoutError:
            logger.error("Stream query: timed out after 600s")
            raise HTTPException(status_code=504, detail="S3 streaming query timed out after 10 minutes")

        elapsed = time.monotonic() - t0
        rows_safe = [[jsonify_value(c) for c in row] for row in data["rows"]]

        logger.info("Stream query: rows=%d, cols=%d, elapsed=%.2fs",
                     len(rows_safe), len(data["columns"]), elapsed)
        return {
            "columns": data["columns"],
            "rows": rows_safe,
            "total_rows": len(rows_safe),
            "streaming": True,
            "limit": request.limit,
            "elapsed_seconds": round(elapsed, 2),
            "connection_id": conn_id,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream query error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Streaming query failed: {classify_duckdb_error(e)}")


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/schema — lightweight column discovery
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/schema")
async def stream_schema(request: StreamSchemaRequest, _user: dict = Depends(get_current_user)):
    """Lightweight column discovery for S3 streaming."""
    t0 = time.monotonic()
    conn_id, conn, cfg = _resolve_connection(request, "schema")

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()
        inner_sql, pf = _build_inner_sql(request, cfg, registered_tables, bucket, conn_id)
        stripped_sql = strip_sql_limit(inner_sql)

        loop = asyncio.get_running_loop()
        _refs = _get_refs(registered_tables, stripped_sql)

        def _run_schema():
            nonlocal stripped_sql
            con = _duckdb_con_with_s3(cfg, connection_id=conn_id)
            try:
                _register_s3_views_fn(con, registered_tables, bucket, conn_id, cfg,
                                      referenced_tables=_refs or None, partition_filters=pf)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                # Step 1: Schema via LIMIT 0 (reads parquet footer only — fast)
                schema_result = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                columns = [{"name": desc[0], "type": desc[1]} for desc in schema_result.description]

                # Step 2: Sample to detect empty columns
                empty_set = set()
                if request.sample_rows > 0 and len(columns) > 0:
                    try:
                        sample_sql = f"SELECT * FROM ({stripped_sql}) _sample LIMIT {request.sample_rows}"
                        sample_result = con.execute(sample_sql)
                        sample_rows = sample_result.fetchall()
                        if sample_rows:
                            col_names = [desc[0] for desc in sample_result.description]
                            for i, cname in enumerate(col_names):
                                if all(row[i] is None for row in sample_rows):
                                    empty_set.add(cname)
                    except Exception as e:
                        logger.warning("Stream schema: empty detection failed: %s", e)

                for col in columns:
                    col["empty"] = col["name"] in empty_set

                # Step 3: Estimate total rows
                estimated_rows = -1
                try:
                    count_result = con.execute(f"SELECT COUNT(*) FROM ({stripped_sql}) _c")
                    estimated_rows = int(count_result.fetchone()[0])
                except Exception:
                    pass

                return {"columns": columns, "total_columns": len(columns), "estimated_rows": estimated_rows}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_schema),
            timeout=60.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 2)
        logger.info("Stream schema: %d columns, %d estimated rows, %.2fs",
                     result["total_columns"], result["estimated_rows"], result["elapsed_seconds"])
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Schema discovery timed out after 60 seconds")
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream schema error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema discovery failed: {classify_duckdb_error(e)}")


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/paginate — paginated S3 streaming via DuckDB
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/paginate")
async def stream_paginate(request: StreamPaginateRequest, http_request: Request = None,
                          _user: dict = Depends(get_current_user)):
    """Paginated query results directly from S3 via DuckDB httpfs."""
    t0 = time.monotonic()
    conn_id, conn, cfg = _resolve_connection(request, "pagination")

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _build_where

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()
        inner_sql, pf = _build_inner_sql(request, cfg, registered_tables, bucket, conn_id)

        stripped_sql = strip_sql_limit(inner_sql)
        if request.query_config and hasattr(convert_query_config_to_engine(request.query_config), 'joins'):
            engine_config = convert_query_config_to_engine(request.query_config)
            if engine_config.joins:
                logger.info("Stream paginate: JOIN query detected, tables=%d, sql_preview=%.200s",
                            1 + len(engine_config.joins), inner_sql)

        loop = asyncio.get_running_loop()
        _refs = _get_refs(registered_tables, stripped_sql)

        def _run_paginated():
            _p0 = time.monotonic()
            logger.info("STREAM-DIAG: _run_paginated START (conn=%s, refs=%s)", conn_id, _refs)
            con = _duckdb_con_with_s3(cfg, connection_id=conn_id)
            logger.info("STREAM-DIAG: DuckDB connection ready (%.2fs)", time.monotonic() - _p0)
            try:
                _p1 = time.monotonic()
                _iceberg_total = _register_s3_views_fn(con, registered_tables, bucket, conn_id, cfg,
                                   referenced_tables=_refs or None, partition_filters=pf)
                logger.info("STREAM-DIAG: views registered (%.2fs), iceberg_records=%d",
                            time.monotonic() - _p1, _iceberg_total)

                nonlocal stripped_sql
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                def _sq(n):
                    return '"' + str(n).replace('"', '""') + '"'

                # Build WHERE clause from adv_filters
                where_clause = ""
                where_params = []
                if request.adv_filters:
                    _schema_r = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                    _valid = [desc[0] for desc in _schema_r.description]
                    where_clause, where_params = _build_where(request.adv_filters, _valid)

                # Build ORDER BY
                order_clause = ""
                if request.sort_column:
                    direction = "ASC" if request.sort_direction == "asc" else "DESC"
                    order_clause = f' ORDER BY {_sq(request.sort_column)} {direction}'

                offset = (request.page - 1) * request.page_size
                data_sql = f"SELECT * FROM ({stripped_sql}) _s{where_clause}{order_clause} LIMIT {request.page_size} OFFSET {offset}"

                _p4 = time.monotonic()
                logger.info("STREAM-DIAG: page=%d, offset=%d, SQL=%.300s", request.page, offset, data_sql)
                result = con.execute(data_sql, where_params) if where_params else con.execute(data_sql)
                all_columns = [desc[0] for desc in result.description]
                raw_rows = result.fetchall()

                columns = all_columns
                rows = [dict(zip(columns, row)) for row in raw_rows] if raw_rows else []
                logger.info("STREAM-DIAG: OK, %d rows, %d/%d cols (%.2fs)",
                            len(raw_rows), len(columns), len(all_columns), time.monotonic() - _p4)

                # Total rows from Iceberg metadata
                rows_returned = len(raw_rows)
                if rows_returned < request.page_size:
                    total_rows = (request.page - 1) * request.page_size + rows_returned
                elif _iceberg_total > 0:
                    total_rows = _iceberg_total
                else:
                    total_rows = -1
                    if request.query_config and not (request.query_config.joins and len(request.query_config.joins) > 0):
                        _qt_names = []
                        for _qf in (request.query_config.files or []):
                            if _qf.startswith("__registered__:"):
                                _qt_names.append(_qf.replace("__registered__:", ""))
                        if len(_qt_names) == 1:
                            try:
                                _sc = _db_manager.get_schema_cache(conn_id, _qt_names[0])
                                if _sc and _sc.get("schema_data", {}).get("num_rows"):
                                    total_rows = int(_sc["schema_data"]["num_rows"])
                            except Exception:
                                pass
                filtered_rows = total_rows
                logger.info("STREAM-DIAG: total_rows=%d (iceberg_metadata=%d)", total_rows, _iceberg_total)

                total_pages = max(1, (filtered_rows + request.page_size - 1) // request.page_size) if filtered_rows > 0 else -1

                return {
                    "columns": columns,
                    "rows": rows,
                    "total_rows": total_rows,
                    "filtered_rows": filtered_rows,
                    "page": request.page,
                    "page_size": request.page_size,
                    "total_pages": total_pages,
                    "streaming": True,
                    "elapsed_seconds": round(time.monotonic() - _p0, 3),
                }
            finally:
                con.close()

        # Check if client already disconnected
        if http_request and await http_request.is_disconnected():
            logger.info("Stream paginate: client disconnected before execution, skipping")
            return {"columns": [], "rows": [], "total_rows": 0, "page": 1,
                    "page_size": request.page_size, "total_pages": 0}

        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor_fn(), _run_paginated),
                timeout=600.0,
            )
        except asyncio.TimeoutError:
            logger.error("Stream paginate: timed out after 600s for page=%d", request.page)
            raise HTTPException(status_code=504, detail="S3 query timed out after 10 minutes")

        jsonify_rows(result["rows"])

        elapsed = time.monotonic() - t0
        logger.info("Stream paginate: page=%d, rows=%d, cols=%d, elapsed=%.2fs",
                     request.page, len(result["rows"]), len(result.get("columns", [])), elapsed)
        return result

    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream paginate error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Streaming pagination failed: {classify_duckdb_error(e)}")


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/chart-data — Chart aggregation on full S3 dataset
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/chart-data")
async def stream_chart_data(request: StreamChartRequest, _user: dict = Depends(get_current_user)):
    """Chart aggregation directly from S3 — runs GROUP BY on the full dataset."""
    t0 = time.monotonic()
    conn_id, conn, cfg = _resolve_connection(request, "chart")

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()
        inner_sql, pf = _build_inner_sql(request, cfg, registered_tables, bucket, conn_id)

        stripped_sql = strip_sql_limit(inner_sql)
        _refs = _get_refs(registered_tables, stripped_sql)
        loop = asyncio.get_running_loop()

        def _run_chart():
            nonlocal stripped_sql
            con = _duckdb_con_with_s3(cfg, connection_id=conn_id)
            try:
                _register_s3_views_fn(con, registered_tables, bucket, conn_id, cfg,
                                      referenced_tables=_refs or None, partition_filters=pf)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                source = f"({stripped_sql}) _src"
                agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(request.agg, "SUM")
                _eff_top_n = min(request.top_n, _limits_cfg.stream_chart_top_n) if request.top_n else _limits_cfg.stream_chart_top_n
                _eff_max_series = min(request.max_series, _limits_cfg.stream_chart_max_series) if request.max_series else _limits_cfg.stream_chart_max_series

                if request.series_col:
                    # Multi-series chart
                    top_series_sql = f"""
                        SELECT COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)'),
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS total
                        FROM {source} GROUP BY 1 ORDER BY total DESC NULLS LAST LIMIT {_eff_max_series}
                    """
                    top_series = [str(r[0]) for r in con.execute(top_series_sql).fetchall()]

                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)') AS series,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value
                        FROM {source} GROUP BY 1, 2
                    """
                    import pandas as pd
                    raw_df = con.execute(agg_sql).fetchdf()
                    raw_df.columns = ["label", "series", "value"]
                    raw_df = raw_df[raw_df["series"].isin(top_series)]
                    pivot = raw_df.pivot_table(index="label", columns="series", values="value", aggfunc="sum")
                    pivot = pivot.head(_eff_top_n)
                    grand_total = float(pivot.values[~pd.isna(pivot.values)].sum()) if pivot.size > 0 else 0.0
                    data = []
                    for label in pivot.index:
                        row_dict = {"label": str(label)}
                        for s in top_series:
                            v = pivot.loc[label, s] if s in pivot.columns else None
                            row_dict[s] = None if (v is None or pd.isna(v)) else float(v)
                        data.append(row_dict)
                    return {"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "series_col": request.series_col, "series": top_series, "multi": True,
                            "grand_total": grand_total, "data": data}
                else:
                    # Single-series chart
                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value,
                               COUNT(*) AS cnt
                        FROM {source} GROUP BY {_q(request.x_col)}
                        ORDER BY value DESC NULLS LAST LIMIT {_eff_top_n}
                    """
                    rows = con.execute(agg_sql).fetchall()
                    grand_total = sum(r[1] for r in rows if r[1] is not None)
                    data = [{"label": str(r[0]), "value": float(r[1]) if r[1] is not None else 0, "count": int(r[2])} for r in rows]
                    return {"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "multi": False, "grand_total": grand_total, "data": data}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_chart),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 3)
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Chart query timed out")
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream chart error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Stream chart failed: {classify_duckdb_error(e)}")


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/pivot-data — Pivot aggregation on full S3 dataset
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/pivot-data")
async def stream_pivot_data(request: StreamPivotRequest, _user: dict = Depends(get_current_user)):
    """Pivot aggregation directly from S3 — runs GROUP BY on the full dataset."""
    t0 = time.monotonic()
    conn_id, conn, cfg = _resolve_connection(request, "pivot")

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q, _AGG_MAP

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()
        inner_sql, pf = _build_inner_sql(request, cfg, registered_tables, bucket, conn_id)

        stripped_sql = strip_sql_limit(inner_sql)
        _refs = _get_refs(registered_tables, stripped_sql)

        row_fields = [f.strip() for f in request.row_fields.split(",") if f.strip()]
        values = json.loads(request.values)
        loop = asyncio.get_running_loop()

        def _run_pivot():
            nonlocal stripped_sql
            con = _duckdb_con_with_s3(cfg, connection_id=conn_id)
            try:
                _register_s3_views_fn(con, registered_tables, bucket, conn_id, cfg,
                                      referenced_tables=_refs or None, partition_filters=pf)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                source = f"({stripped_sql}) _src"

                # Build aggregation expressions
                agg_exprs = []
                agg_aliases = []
                for i, v in enumerate(values):
                    alias = f"val_{i}"
                    fn = v["function"]
                    col = v.get("column", "*")
                    if fn == "count_rows":
                        agg_exprs.append(f"COUNT(*) AS {alias}")
                    elif fn == "count_distinct":
                        agg_exprs.append(f'COUNT(DISTINCT {_q(col)}) AS {alias}')
                    else:
                        sql_fn = _AGG_MAP.get(fn, "SUM")
                        agg_exprs.append(f'{sql_fn}(TRY_CAST({_q(col)} AS DOUBLE)) AS {alias}')
                    agg_aliases.append(alias)

                if not request.col_field:
                    # Simple pivot: GROUP BY row_fields
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    sql = f"SELECT {group_cols}, {', '.join(agg_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} ORDER BY {agg_aliases[0]} DESC NULLS LAST LIMIT {request.top_n}"
                    rows = con.execute(sql).fetchall()
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows:
                        d = {}
                        for j, rf in enumerate(row_fields):
                            d[rf] = str(row[j]) if row[j] is not None else "(blank)"
                        for j, alias in enumerate(agg_aliases):
                            d[alias] = float(row[len(row_fields) + j]) if row[len(row_fields) + j] is not None else 0
                        result_rows.append(d)
                    return {"row_fields": row_fields, "col_field": None, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": [],
                            "grand_totals": grand_totals}
                else:
                    # Cross-tab pivot
                    col_vals_sql = f"SELECT DISTINCT CAST({_q(request.col_field)} AS VARCHAR) FROM {source} ORDER BY 1 LIMIT 20"
                    col_values = [str(r[0]) for r in con.execute(col_vals_sql).fetchall() if r[0] is not None]
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    ct_exprs = []
                    for cv in col_values:
                        cv_esc = cv.replace("'", "''")
                        for i, v in enumerate(values):
                            fn = v["function"]
                            col = v.get("column", "*")
                            alias = f"val_{i}__{cv.replace(' ', '_')}"
                            if fn == "count_rows":
                                ct_exprs.append(f"COUNT(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN 1 END) AS \"{alias}\"")
                            else:
                                sql_fn = _AGG_MAP.get(fn, "SUM")
                                ct_exprs.append(f"{sql_fn}(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN TRY_CAST({_q(col)} AS DOUBLE) END) AS \"{alias}\"")
                    sql = f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT {request.top_n}"
                    rows_data = con.execute(sql).fetchall()
                    desc = [d[0] for d in con.execute(f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT 0").description]
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows_data:
                        d = {desc[j]: (str(row[j]) if j < len(row_fields) else (float(row[j]) if row[j] is not None else 0)) for j in range(len(row))}
                        result_rows.append(d)
                    return {"row_fields": row_fields, "col_field": request.col_field, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": col_values,
                            "grand_totals": grand_totals}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_pivot),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 3)
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Pivot query timed out")
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream pivot error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Stream pivot failed: {classify_duckdb_error(e)}")
