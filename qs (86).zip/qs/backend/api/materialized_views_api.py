"""
Materialized Views API — CRUD + refresh + scheduling for local parquet caches.

Endpoints:
  GET    /api/materialized-views                   — list all materialized views
  GET    /api/materialized-views/storage           — storage usage summary (admin)
  GET    /api/materialized-views/{id}              — get single view
  POST   /api/materialized-views                   — create a new view
  PUT    /api/materialized-views/{id}              — update view metadata / schedule
  DELETE /api/materialized-views/{id}              — delete view + local files
  POST   /api/materialized-views/{id}/refresh      — trigger a manual refresh
  GET    /api/materialized-views/{id}/status       — lightweight status poll
  GET    /api/materialized-views/{id}/schema       — read parquet schema from disk
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(tags=["materialized-views"])

# ── Module-level singletons — populated by set_mv_dependencies() at startup ───
_db_manager   = None
_engine       = None
_conn_manager = None
_ws_manager   = None
_mv_cfg       = None

# _register_s3_views is defined in the connections section of main.py (line ~4274).
# main.py sets this reference after importing the module so the helper is
# reachable from _refresh_materialized_view_sync without a circular import.
_register_s3_views = None


def set_mv_dependencies(db_manager, engine, conn_manager, ws_manager, mv_cfg):
    global _db_manager, _engine, _conn_manager, _ws_manager, _mv_cfg
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _ws_manager   = ws_manager
    _mv_cfg       = mv_cfg


# ── Pydantic models ────────────────────────────────────────────────────────────

class MaterializedViewCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    connection_id: int
    table_name: str
    table_format: str = "parquet"
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None


class MaterializedViewUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    is_active: Optional[bool] = None


# ── Helper functions ───────────────────────────────────────────────────────────

def _refresh_materialized_view_sync(mv_id: int):
    """Core refresh logic — downloads S3 data to local parquet files."""
    import time as _t
    import shutil
    import pyarrow as pa
    import pyarrow.parquet as pq

    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        logger.error("MV refresh: view %d not found", mv_id)
        return

    _db_manager.update_materialized_view(mv_id, status="refreshing", last_error=None)
    _start = _t.monotonic()

    try:
        # Load connection
        conn = _db_manager.get_connection(mv["connection_id"])
        if not conn:
            raise ValueError(f"Connection {mv['connection_id']} not found")
        cfg = conn["config"]
        bucket = cfg.get("bucket_name", "")

        # Get registered tables for this connection
        registered_tables = cfg.get("registered_tables", [])
        target_table = None
        for rt in registered_tables:
            if rt["name"] == mv["table_name"]:
                target_table = rt
                break
        if not target_table:
            raise ValueError(f"Registered table '{mv['table_name']}' not found in connection")

        # Open DuckDB connection with S3 credentials
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg)

        # Register only the target table
        if _register_s3_views is None:
            raise RuntimeError("_register_s3_views not wired — check main.py startup")
        _register_s3_views(con, [target_table], bucket, mv["connection_id"], cfg,
                          referenced_tables={mv["table_name"]})

        # Build query
        tname_safe = '"' + mv["table_name"].replace('"', '""') + '"'
        sql = f"SELECT * FROM {tname_safe}"
        where_parts = []

        # Apply partition filter
        pf = mv.get("partition_filter")
        if pf and pf.get("date_col"):
            date_col = pf["date_col"].replace('"', '""')
            if pf.get("from"):
                where_parts.append(f'"{date_col}" >= \'{pf["from"]}\'')
            if pf.get("to"):
                where_parts.append(f'"{date_col}" <= \'{pf["to"]}\'')

        # Apply query filter
        if mv.get("query_filter"):
            where_parts.append(f"({mv['query_filter']})")

        if where_parts:
            sql += " WHERE " + " AND ".join(where_parts)

        logger.info("MV refresh %d '%s': SQL = %s", mv_id, mv["name"], sql[:500])

        # Execute and write to local parquet
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
        # Clear old data
        if os.path.exists(mv_dir):
            shutil.rmtree(mv_dir)
        os.makedirs(mv_dir, exist_ok=True)

        chunk_size = _mv_cfg.chunk_size
        total_rows = 0
        file_idx = 0
        total_size = 0

        # Use Arrow record batch streaming — avoids slow Python row-by-row conversion
        reader = con.execute(sql).fetch_record_batch(chunk_size)
        for batch in reader:
            if len(batch) == 0:
                continue
            out_path = os.path.join(mv_dir, f"part_{file_idx:04d}.parquet")
            pq.write_table(pa.Table.from_batches([batch]), out_path, compression="snappy")
            total_rows += len(batch)
            total_size += os.path.getsize(out_path)
            file_idx += 1

        con.close()

        elapsed = _t.monotonic() - _start
        _db_manager.update_materialized_view(mv_id,
            status="ready",
            row_count=total_rows,
            file_count=file_idx,
            size_bytes=total_size,
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
            last_error=None,
        )
        logger.info("MV refresh %d '%s': %d rows, %d files, %.1f MB in %.1fs",
                    mv_id, mv["name"], total_rows, file_idx, total_size / 1048576, elapsed)

        # WebSocket notification
        try:
            _ws_manager.broadcast_sync({
                "type": "materialized_view_refreshed",
                "mv_id": mv_id,
                "name": mv["name"],
                "row_count": total_rows,
                "size_bytes": total_size,
            })
        except Exception:
            pass

    except Exception as e:
        elapsed = _t.monotonic() - _start
        logger.error("MV refresh %d failed after %.1fs: %s", mv_id, elapsed, e, exc_info=True)
        _db_manager.update_materialized_view(mv_id,
            status="failed",
            last_error=str(e),
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
        )
        try:
            _ws_manager.broadcast_sync({
                "type": "materialized_view_failed",
                "mv_id": mv_id,
                "name": mv.get("name", ""),
                "error": str(e)[:500],
            })
        except Exception:
            pass


def _setup_mv_schedule(mv_id: int, schedule_config: dict, mv_name: str = ""):
    """Register or update APScheduler job for MV auto-refresh."""
    from core.scheduler import _build_trigger
    import uuid as _uuid
    # Get global scheduler
    try:
        from core.scheduler import _scheduler
        if not _scheduler or not _scheduler.running:
            logger.warning("Scheduler not running — MV schedule not set for %d", mv_id)
            return None
    except Exception:
        return None

    job_id = f"mv_{mv_id}_{_uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_config)
    _scheduler.add_job(
        func=_refresh_materialized_view_sync,
        trigger=trigger,
        id=job_id,
        args=[mv_id],
        name=f"MV: {mv_name or mv_id}",
        replace_existing=True,
    )
    job = _scheduler.get_job(job_id)
    next_run = job.next_run_time if job else None
    _db_manager.update_materialized_view(mv_id, apscheduler_job_id=job_id,
                                         next_refresh_at=next_run)
    return job_id


def _remove_mv_schedule(job_id: str):
    """Remove APScheduler job for MV."""
    try:
        from core.scheduler import _scheduler
        if _scheduler and job_id and _scheduler.get_job(job_id):
            _scheduler.remove_job(job_id)
    except Exception:
        pass


# ── Endpoints ──────────────────────────────────────────────────────────────────

from api.deps import get_current_user, require_admin, require_role, get_workspace_id


@router.get("/api/materialized-views")
async def list_materialized_views(connection_id: Optional[int] = None,
                                   request: Request = None,
                                   _user: dict = Depends(get_current_user)):
    try:
        workspace_id = get_workspace_id(request) if request else None
        mvs = _db_manager.list_materialized_views(connection_id=connection_id, workspace_id=workspace_id)
        return mvs
    except Exception as e:
        logger.error("List MVs failed: %s", e, exc_info=True)
        raise HTTPException(500, str(e))


@router.get("/api/materialized-views/storage")
async def get_mv_storage(_user: dict = Depends(require_admin)):
    try:
        mvs = _db_manager.list_materialized_views(active_only=False)
        total_size = sum(mv.get("size_bytes", 0) for mv in mvs)
        max_bytes = _mv_cfg.max_size_mb * 1024 * 1024
        return {
            "total_views": len(mvs),
            "max_views": _mv_cfg.max_views,
            "total_size_bytes": total_size,
            "max_size_bytes": max_bytes,
            "usage_pct": round(total_size / max_bytes * 100, 1) if max_bytes else 0,
        }
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/api/materialized-views/{mv_id}")
async def get_materialized_view(mv_id: int, _user: dict = Depends(get_current_user)):
    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    return mv


@router.post("/api/materialized-views")
async def create_materialized_view(body: MaterializedViewCreateModel,
                                    request: Request = None,
                                    _user: dict = Depends(get_current_user)):
    try:
        # Validate connection exists
        conn = _db_manager.get_connection(body.connection_id)
        if not conn:
            raise HTTPException(404, "Connection not found")

        # Check max views
        existing = _db_manager.list_materialized_views(active_only=False)
        if len(existing) >= _mv_cfg.max_views:
            raise HTTPException(400, f"Maximum {_mv_cfg.max_views} materialized views reached")

        # Check name uniqueness
        if _db_manager.get_materialized_view_by_name(body.name):
            raise HTTPException(400, f"Materialized view '{body.name}' already exists")

        # Validate table exists in connection
        reg_tables = conn.get("config", {}).get("registered_tables", [])
        if not any(rt["name"] == body.table_name for rt in reg_tables):
            raise HTTPException(400, f"Table '{body.table_name}' not found in connection")

        mv = _db_manager.create_materialized_view(
            name=body.name,
            description=body.description,
            connection_id=body.connection_id,
            table_name=body.table_name,
            table_format=body.table_format,
            partition_filter=body.partition_filter,
            query_filter=body.query_filter,
            schedule_config=body.schedule_config,
            created_by=_user.get("username", ""),
            workspace_id=get_workspace_id(request) if request else None,
        )

        # Set up schedule if provided
        if body.schedule_config:
            _setup_mv_schedule(mv["id"], body.schedule_config, mv["name"])

        return mv
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Create MV failed: %s", e, exc_info=True)
        raise HTTPException(500, str(e))


@router.put("/api/materialized-views/{mv_id}")
async def update_materialized_view(mv_id: int, body: MaterializedViewUpdateModel,
                                    _user: dict = Depends(get_current_user)):
    try:
        mv = _db_manager.get_materialized_view(mv_id)
        if not mv:
            raise HTTPException(404, "Materialized view not found")

        updates = body.dict(exclude_unset=True)

        # Handle name uniqueness
        if "name" in updates and updates["name"] != mv["name"]:
            if _db_manager.get_materialized_view_by_name(updates["name"]):
                raise HTTPException(400, f"Name '{updates['name']}' already taken")

        # Handle schedule change
        if "schedule_config" in updates:
            # Remove old schedule
            if mv.get("apscheduler_job_id"):
                _remove_mv_schedule(mv["apscheduler_job_id"])
                updates["apscheduler_job_id"] = None
                updates["next_refresh_at"] = None

            # Set new schedule
            if updates["schedule_config"]:
                _setup_mv_schedule(mv_id, updates["schedule_config"],
                                  updates.get("name", mv["name"]))

        result = _db_manager.update_materialized_view(mv_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Update MV %d failed: %s", mv_id, e, exc_info=True)
        raise HTTPException(500, str(e))


@router.delete("/api/materialized-views/{mv_id}")
async def delete_materialized_view(mv_id: int, _user: dict = Depends(get_current_user)):
    try:
        mv = _db_manager.get_materialized_view(mv_id)
        if not mv:
            raise HTTPException(404, "Materialized view not found")

        # Remove scheduler job
        if mv.get("apscheduler_job_id"):
            _remove_mv_schedule(mv["apscheduler_job_id"])

        # Remove local files
        import shutil
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
        if os.path.exists(mv_dir):
            shutil.rmtree(mv_dir)

        _db_manager.delete_materialized_view(mv_id)
        return {"status": "deleted", "id": mv_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Delete MV %d failed: %s", mv_id, e, exc_info=True)
        raise HTTPException(500, str(e))


@router.post("/api/materialized-views/{mv_id}/refresh")
async def refresh_materialized_view(mv_id: int, _user: dict = Depends(get_current_user)):
    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    if mv["status"] == "refreshing":
        raise HTTPException(409, "Refresh already in progress")

    # Run in background thread
    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, _refresh_materialized_view_sync, mv_id)
    return {"status": "refresh_started", "id": mv_id}


@router.get("/api/materialized-views/{mv_id}/status")
async def get_mv_status(mv_id: int, _user: dict = Depends(get_current_user)):
    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    return {
        "id": mv["id"],
        "name": mv["name"],
        "status": mv["status"],
        "row_count": mv["row_count"],
        "file_count": mv["file_count"],
        "size_bytes": mv["size_bytes"],
        "last_refresh_at": mv["last_refresh_at"],
        "last_refresh_duration": mv["last_refresh_duration"],
        "last_error": mv["last_error"],
    }


@router.get("/api/materialized-views/{mv_id}/schema")
async def get_mv_schema(mv_id: int, _user: dict = Depends(get_current_user)):
    """Read schema from local parquet files of a materialized view."""
    mv = _db_manager.get_materialized_view(mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    if mv["status"] != "ready":
        raise HTTPException(400, "Materialized view not ready — refresh first")

    mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
    import glob as _glob_mod
    pq_files = sorted(_glob_mod.glob(os.path.join(mv_dir, "*.parquet")))
    if not pq_files:
        raise HTTPException(400, "No parquet files found — refresh needed")

    try:
        import pyarrow.parquet as pq
        schema = pq.read_schema(pq_files[0])
        columns = []
        for i, field in enumerate(schema):
            columns.append({
                "name": field.name,
                "type": str(field.type),
                "nullable": field.nullable,
            })
        return {"columns": columns, "source": mv["name"], "file_count": len(pq_files)}
    except Exception as e:
        logger.error("MV schema read failed for %d: %s", mv_id, e)
        raise HTTPException(500, f"Failed to read schema: {e}")
