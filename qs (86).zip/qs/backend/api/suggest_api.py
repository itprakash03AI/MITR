"""
Suggest / Intelligence API (Phases 46, 47, 48)

Endpoints:
  GET  /api/suggest/tables          — ranked table suggestions (Phase 46)
  GET  /api/suggest/columns         — ranked column suggestions (Phase 46)
  GET  /api/suggest/top-tables      — most-used tables (Phase 46)
  GET  /api/suggest/schema          — column schema for a table (cache + usage stats)
  GET  /api/suggest/last-result     — schema + stats of last completed execution
  GET  /api/suggest/docs            — keyword search over user_guide + architecture HTML
  GET  /api/suggest/chatbot-patterns — column classification patterns for the AI Assistant
  POST /api/analyze-query           — pre-execution rule analysis (Phase 47)
  POST /api/nl-to-sql               — pattern-based NL→SQL generation (Phase 48)
"""
from __future__ import annotations

import logging
import re as _re
from pathlib import Path as _Path
from html.parser import HTMLParser as _HTMLParser
from typing import List, Optional, Any, Dict, Tuple

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from api.deps import get_current_user, require_role

logger = logging.getLogger(__name__)
router = APIRouter()

# Injected from main.py _startup()
_db_manager = None


def set_suggest_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


# ── Phase 46 — Table / Column Suggestions ─────────────────────────────────────

@router.get("/api/suggest/tables")
async def suggest_tables(
    prefix: str = "",
    connection_id: Optional[int] = None,
    limit: int = 20,
    _user: dict = Depends(get_current_user),
):
    """Return tables ranked by historical usage frequency."""
    return _db_manager.get_table_suggestions(
        prefix=prefix, connection_id=connection_id, limit=min(limit, 50)
    )


@router.get("/api/suggest/columns")
async def suggest_columns(
    table_name: str = "",
    connection_id: Optional[int] = None,
    limit: int = 30,
    _user: dict = Depends(get_current_user),
):
    """Return columns for a table ranked by usage frequency."""
    return _db_manager.get_column_suggestions(
        table_name=table_name, connection_id=connection_id, limit=min(limit, 100)
    )


@router.get("/api/suggest/top-tables")
async def top_tables(
    connection_id: Optional[int] = None,
    limit: int = 50,
    _user: dict = Depends(get_current_user),
):
    """Return most-used tables overall."""
    return _db_manager.get_top_tables(connection_id=connection_id, limit=min(limit, 100))


# ── Phase 47 — Query Analysis ─────────────────────────────────────────────────

class AnalyzeQueryRequest(BaseModel):
    sql: str
    connection_type: str = "duckdb"
    partition_columns: List[str] = []


@router.post("/api/analyze-query")
async def analyze_query(body: AnalyzeQueryRequest, _user: dict = Depends(get_current_user)):
    """Analyze SQL for common anti-patterns and return warnings."""
    from core.query_analyzer import analyze_query as _analyze, warnings_to_dicts
    warnings = _analyze(
        sql=body.sql,
        connection_type=body.connection_type,
        partition_columns=body.partition_columns,
    )
    return {
        "warnings": warnings_to_dicts(warnings),
        "warning_count": len(warnings),
        "has_errors": any(w.severity == "error" for w in warnings),
    }


# ── Phase 48 — Natural Language to SQL ───────────────────────────────────────

class NLToSQLRequest(BaseModel):
    question: str
    connection_id: Optional[int] = None
    tables: List[str] = []                       # available table names
    columns: Dict[str, List[str]] = {}           # table → [col, ...]
    connection_type: str = "duckdb"
    default_schema: Optional[str] = None
    dataset_id: Optional[int] = None             # Phase 57: semantic dataset context
    use_schema_cache: bool = True                 # Phase 57: enrich from schema_cache


@router.post("/api/nl-to-sql")
async def nl_to_sql(body: NLToSQLRequest, _user: dict = Depends(get_current_user)):
    """Convert a natural language question to SQL using pattern matching.

    Phase 57 enhancement: When dataset_id is provided, uses semantic layer metadata
    (friendly names, synonyms, pre-defined conditions) for higher accuracy.
    When only connection_id + tables are available, enriches from schema_cache
    for accurate column type detection (esp. Iceberg tables).
    """
    from core.nl_to_sql import (
        nl_to_sql as _convert, SchemaContext, SemanticSchemaContext,
        result_to_dict, apply_glossary, build_semantic_context,
        enrich_from_schema_cache,
    )
    from core import config as _cfg

    semantic_rewrites = []

    # ── Path A: dataset_id → full semantic context ────────────────────────
    if body.dataset_id and _cfg.chatbot.semantic_context_enabled:
        ds = _db_manager.get_dataset_full(body.dataset_id)
        if not ds:
            raise HTTPException(status_code=404, detail=f"Dataset {body.dataset_id} not found.")
        ctx = build_semantic_context(ds)
        if body.connection_type and body.connection_type != "duckdb":
            ctx.connection_type = body.connection_type
        if body.default_schema:
            ctx.default_schema = body.default_schema
        # Merge caller-supplied extra tables/columns
        for t in body.tables:
            if t not in ctx.tables:
                ctx.tables.append(t)
        for t, cols in body.columns.items():
            if t not in ctx.columns:
                ctx.columns[t] = cols

    # ── Path B: schema_cache enrichment (connection + tables, no dataset) ─
    elif body.connection_id and body.tables and body.use_schema_cache and _cfg.chatbot.semantic_context_enabled:
        base_ctx = SchemaContext(
            tables=body.tables, columns=body.columns,
            connection_type=body.connection_type, default_schema=body.default_schema,
        )
        cache_rows = []
        for t in body.tables[:10]:
            cached = _db_manager.get_schema_cache(body.connection_id, t)
            if cached:
                cache_rows.append(cached)
        if cache_rows:
            ctx = enrich_from_schema_cache(base_ctx, cache_rows)
        else:
            ctx = base_ctx

    # ── Path C: plain context (no semantic data) ──────────────────────────
    else:
        ctx = SchemaContext(
            tables=body.tables, columns=body.columns,
            connection_type=body.connection_type, default_schema=body.default_schema,
        )

    # Apply config glossary substitution (existing)
    question = apply_glossary(body.question, _cfg.chatbot.glossary)
    if question != body.question:
        semantic_rewrites.append(f"glossary: '{body.question}' → '{question}'")

    # Apply dataset synonym glossary (Phase 57 — only in semantic path)
    if isinstance(ctx, SemanticSchemaContext) and _cfg.semantic_layer.synonym_matching_enabled:
        flat_synonyms = {}
        for table_syns in ctx.synonyms.values():
            flat_synonyms.update(table_syns)
        flat_friendly = {}
        for table_fn in ctx.friendly_names.values():
            flat_friendly.update(table_fn)
        combined = {**flat_synonyms, **flat_friendly}
        rewritten = apply_glossary(question, combined)
        if rewritten != question:
            semantic_rewrites.append(f"semantic: '{question}' → '{rewritten}'")
            question = rewritten

    result = _convert(question, ctx)
    if semantic_rewrites:
        result.semantic_rewrites = semantic_rewrites
    if question != body.question and not result.semantic_rewrites:
        result.explanation = f"[Glossary applied] " + result.explanation

    response = result_to_dict(result)
    # Include dataset context metadata for frontend display
    if isinstance(ctx, SemanticSchemaContext) and ctx.dataset_name:
        response["semantic_mode"] = True
        response["dataset_name"] = ctx.dataset_name
    return response


@router.post("/api/nl-to-sql/semantic")
async def nl_to_sql_semantic(body: NLToSQLRequest, _user: dict = Depends(get_current_user)):
    """Semantic-aware NL→SQL. Requires dataset_id. Alias of /api/nl-to-sql with semantic path."""
    if not body.dataset_id:
        raise HTTPException(status_code=400, detail="dataset_id is required for /api/nl-to-sql/semantic")
    return await nl_to_sql(body, _user)


@router.get("/api/suggest/schema")
async def suggest_schema(
    q: str = "",
    connection_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """
    Return column schema for a table name.
    Resolution order:
      1. Exact match in DB schema cache (fast, populated after schema browser opens)
      2. Column usage stats (populated after queries run against the table)
      3. Fuzzy/prefix table match → repeat steps 1–2 for best match
    """
    if not q:
        return {"table": "", "columns": [], "message": "Provide ?q=table_name"}

    # 1 — exact schema cache hit
    if connection_id:
        cached = _db_manager.get_schema_cache(connection_id, q)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            return {"table": q, "connection_id": connection_id, "source": "schema_cache", "columns": cols}

    # 2 — column usage stats (exact table name)
    col_stats = _db_manager.get_column_suggestions(table_name=q, connection_id=connection_id, limit=60)
    if col_stats:
        return {
            "table": q,
            "connection_id": col_stats[0].get("connection_id"),
            "source": "usage_stats",
            "columns": [
                {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
                for c in col_stats
            ],
        }

    # 3 — fuzzy prefix match
    matches = _db_manager.get_table_suggestions(prefix=q, connection_id=connection_id, limit=3)
    if not matches:
        return {
            "table": q, "columns": [],
            "message": f"No schema found for '{q}'. Open the schema browser for this table first, or run a query that references it.",
        }

    best = matches[0]
    best_name = best.get("object_name", q)
    best_conn  = best.get("connection_id")

    if best_conn:
        cached = _db_manager.get_schema_cache(best_conn, best_name)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
            return {"table": best_name, "connection_id": best_conn, "source": "schema_cache",
                    "columns": cols, "message": hint}

    col_stats = _db_manager.get_column_suggestions(table_name=best_name, connection_id=best_conn, limit=60)
    hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
    return {
        "table": best_name,
        "connection_id": best_conn,
        "source": "usage_stats",
        "message": hint,
        "columns": [
            {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
            for c in col_stats
        ],
    }


@router.get("/api/suggest/last-result")
async def last_result_info(_user: dict = Depends(get_current_user)):
    """
    Return schema and row count for the most recent completed execution.
    Reads the stored parquet output via DuckDB — no LLM required.
    """
    import duckdb as _duckdb
    import os as _os

    try:
        with _db_manager.get_session() as session:
            from core.database import QueryExecution as _QE
            row = (
                session.query(_QE)
                .filter(_QE.status == "completed", _QE.output_file.isnot(None))
                .order_by(_QE.started_at.desc())
                .first()
            )
            if not row:
                return {"found": False, "message": "No completed executions with result files found."}
            output_file = row.output_file
            execution_id = row.execution_id
            total_rows   = row.total_rows or 0
            started_at   = row.started_at.isoformat() if row.started_at else None
            sql_preview  = (row.sql or "")[:300]

        if not _os.path.exists(output_file):
            return {"found": False, "message": "Result file has been deleted from disk."}

        con = _duckdb.connect(":memory:")
        try:
            desc_rows = con.execute(
                f"DESCRIBE SELECT * FROM read_parquet('{output_file}') LIMIT 0"
            ).fetchall()
            columns = [{"name": r[0], "type": r[1]} for r in desc_rows]
        finally:
            con.close()

        return {
            "found": True,
            "execution_id": execution_id,
            "columns": columns,
            "total_rows": total_rows,
            "executed_at": started_at,
            "sql_preview": sql_preview,
        }
    except Exception as exc:
        logger.warning("last-result: %s", exc)
        return {"found": False, "message": str(exc)}


# ── Docs knowledge base ───────────────────────────────────────────────────────

# Module-level cache: list of {"heading", "text", "source", "keywords": set}
_docs_sections: Optional[List[Dict[str, Any]]] = None
_DOCS_STOPWORDS = {
    "the","a","an","is","are","was","were","be","been","being","have","has","had",
    "do","does","did","will","would","could","should","may","might","must","can",
    "to","of","in","on","at","by","for","with","from","and","or","not","this",
    "that","it","its","as","i","you","we","they","what","how","when","where",
    "which","who","all","any","if","so","but","more","also","use","using","used",
}

class _SectionParser(_HTMLParser):
    """Extract heading+body sections from HTML."""
    def __init__(self):
        super().__init__()
        self.sections: List[Dict[str, str]] = []
        self._heading = ""
        self._body: List[str] = []
        self._in_head = False
        self._in_script = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._in_script = True
        elif tag in ("h1", "h2", "h3", "h4"):
            self._flush()
            self._in_head = True

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._in_script = False
        elif tag in ("h1", "h2", "h3", "h4"):
            self._in_head = False

    def handle_data(self, data):
        if self._in_script:
            return
        data = data.strip()
        if not data:
            return
        if self._in_head:
            self._heading = data
        else:
            self._body.append(data)

    def _flush(self):
        text = " ".join(self._body).strip()
        # Remove CSS noise (lines with lots of { : ; })
        text = _re.sub(r'[^\s]+\s*:\s*[^;]+;', '', text)
        text = _re.sub(r'\s+', ' ', text).strip()
        if self._heading and len(text) > 20:
            self.sections.append({"heading": self._heading, "text": text[:800]})
        self._body = []


def _tokenize(text: str) -> set:
    """Extract lowercase tokens (3+ chars) including uppercase sigils like S3, SQL, CSV."""
    lc = text.lower()
    tokens = set(_re.findall(r'\b[a-z][a-z0-9]{2,}\b', lc))          # normal words
    # Also capture short uppercase acronyms from original: S3, SQL, CSV, API, LLM …
    tokens |= set(w.lower() for w in _re.findall(r'\b[A-Z][A-Z0-9]{1,4}\b', text))
    tokens -= _DOCS_STOPWORDS
    return tokens


# ── Built-in knowledge base for features not covered by HTML docs ─────────────
_BUILTIN_KB: List[Dict[str, str]] = [
    {
        "heading": "Circuit Breaker",
        "text": (
            "The circuit breaker protects connections from cascade failures. "
            "It has three states: CLOSED (normal), OPEN (blocking requests after repeated failures), "
            "and HALF_OPEN (testing recovery). Configure thresholds in config.json under 'circuit_breaker'. "
            "View live state at Admin → Circuit Breakers. The breaker opens after N consecutive failures "
            "and resets after a cool-down window. WebSocket events broadcast state changes in real time."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Cache",
        "text": (
            "Query results are cached as parquet files to avoid re-running identical queries. "
            "The cache key includes file modification times so stale data is never served. "
            "A 'base-data cache' reuses the same parquet when only the SELECT list changes. "
            "Cache entries are invalidated when the underlying connection or file changes. "
            "Manage cache at Admin → Cache. Use DELETE /api/admin/cache to clear manually."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Anomaly Detection",
        "text": (
            "Anomaly detection runs z-score analysis on scheduled query results. "
            "When a scheduled run produces a metric value more than N standard deviations "
            "from the historical mean, an anomaly alert is raised and sent as a notification. "
            "Configure sensitivity in config.json under 'anomaly_detection'. "
            "View detected anomalies at Admin → Anomalies."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Connection Pooling",
        "text": (
            "Per-connection pools manage DuckDB and file-based connections to avoid overhead "
            "from creating a new connection on every query. Idle connections are evicted after "
            "a configurable timeout. Pool stats are visible at Admin → Connection Pools. "
            "Configure pool sizes in config.json under 'connection_pool'."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Arrow IPC Streaming",
        "text": (
            "Large query results can be streamed in Apache Arrow IPC format for high-throughput "
            "data transfer to BI tools or Python clients. Use GET /api/executions/{id}/results/arrow "
            "with Accept: application/vnd.apache.arrow.stream. Arrow format avoids JSON serialization "
            "overhead and is ideal for datasets with millions of rows."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Idempotency & Deduplication",
        "text": (
            "Executions support idempotency keys to prevent duplicate runs. If the same query "
            "is submitted twice within 10 minutes with the same key, the second request returns "
            "the first result without re-executing. Shadow executions wait on an asyncio.Event "
            "for in-flight identical queries, saving server resources."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "NL-to-SQL (Natural Language to SQL)",
        "text": (
            "The NL-to-SQL engine converts plain English to SQL using 11 built-in patterns "
            "(no LLM required). Patterns include: top N by column, average/sum per group, "
            "distinct values, min/max, date range, recent rows, filter equals, count, group-by count, "
            "show all. Use the chat assistant or the NL panel in the SQL editor. "
            "Example: 'top 10 customers by revenue', 'average salary by department', "
            "'orders where status is pending', 'sales between 2025-01-01 and 2025-12-31'."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Analyzer",
        "text": (
            "The query analyzer checks SQL for performance and correctness issues before execution. "
            "It detects: SELECT_STAR (missing column list), S3_LIMIT_NO_PUSHDOWN (LIMIT won't speed up S3 scans), "
            "MISSING_PARTITION_FILTER (no partition column in WHERE), CROSS_JOIN (cartesian product), "
            "UNBOUNDED_GROUP_BY, FULL_TABLE_SCAN, and DDL_DML_STATEMENT. "
            "Warnings appear as a banner above query results. "
            "API: POST /api/analyze-query."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Table & Column Lineage",
        "text": (
            "QueryStudio tracks which tables and columns each saved query reads from and writes to. "
            "Table lineage shows an interactive DAG (directed acyclic graph) with table → query edges. "
            "Column lineage shows how each output column is derived (direct copy, renamed, computed, "
            "aggregated, casted, star_expansion). View lineage at the Lineage page. "
            "Lineage is extracted automatically when queries are saved using sqlglot AST parsing."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Materialized Views",
        "text": (
            "Materialized views pre-compute and store query results as parquet files for fast access. "
            "They can be refreshed manually or on a schedule. Create at Data → Materialized Views. "
            "A materialized view stores the output of any SQL query and serves it from disk "
            "on subsequent reads, bypassing re-execution. Useful for slow aggregation queries."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Scheduled Queries",
        "text": (
            "Queries can be scheduled to run automatically using cron expressions or simple intervals. "
            "Go to a saved query → Schedule tab to set up a schedule. "
            "The scheduler uses APScheduler and supports: every N minutes, hourly, daily, weekly, cron. "
            "Results are stored as executions and can trigger anomaly detection alerts. "
            "Scheduled runs respect the same RBAC permissions as manual runs."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "S3 Connections & Live Streaming",
        "text": (
            "S3 connections query data directly from S3 using DuckDB's httpfs extension. "
            "IMPORTANT: SELECT * LIMIT 500 does NOT speed up S3 — a full scan is still required "
            "because LIMIT is not pushed down to S3. Use partition filters (WHERE year=2024) to reduce scans. "
            "S3 live streaming streams results row-by-row as they are read. "
            "Configure S3 credentials (access_key, secret_key, region, endpoint) in Connections."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "DuckDB Connections",
        "text": (
            "DuckDB is the default local analytics engine. It can query parquet, CSV, JSON, and Iceberg files. "
            "DuckDB runs in a subprocess to isolate crashes from the FastAPI server. "
            "Use file paths or S3 URIs directly in SQL: SELECT * FROM read_parquet('data/*.parquet'). "
            "Multiple files: read_parquet(['file1.parquet', 'file2.parquet']). "
            "Glob patterns: read_parquet('s3://bucket/prefix/**/*.parquet')."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Snowflake, Trino, Databricks, Oracle Connectors",
        "text": (
            "QueryStudio supports external connectors: Snowflake (account + credentials), "
            "Trino (host + catalog + schema), Databricks (server hostname + HTTP path + token), "
            "Oracle (host + port + service name + credentials). "
            "Configure at Connections → New Connection → choose type. "
            "Each connector runs queries in the target system and streams results back."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Exporting Results",
        "text": (
            "Query results can be exported from the data grid. Click the Export button (↓) in the results toolbar. "
            "Supported formats: CSV, Parquet, Excel (XLSX), JSON. "
            "Large exports run as background downloads. Exported files appear in the Downloads panel. "
            "S3-backed files can be promoted to local tables for repeated querying."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Builder (Visual)",
        "text": (
            "The visual Query Builder lets you construct queries without writing SQL. "
            "Select tables, choose join conditions, pick columns, add filters and sort. "
            "The builder generates SQL which can be previewed and executed. "
            "Use Query Builder → New Query. Supports multi-table joins, aggregations, and GROUP BY."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "SQL Editor",
        "text": (
            "The SQL Editor provides a Monaco-based code editor for writing queries. "
            "Features: syntax highlighting, auto-complete (Ctrl+Space), multi-tab support, "
            "run selected text (Ctrl+Enter), query history, NL-to-SQL panel (right drawer). "
            "Tabs are preserved across page reloads. Stale tabs show a placeholder after 5 minutes of inactivity. "
            "Use the NL toggle button to open the natural language assistant inline."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Workspaces",
        "text": (
            "Workspaces let you organise queries, connections, and views into named groups. "
            "Create workspaces at the top navigation bar. Switching workspaces filters the "
            "query list, connections, and materialized views to that workspace. "
            "Queries can be shared across workspaces."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "RBAC — Roles and Permissions",
        "text": (
            "QueryStudio has three built-in roles: admin, analyst, viewer. "
            "Admin: full access including user management, config, and admin endpoints. "
            "Analyst: can create/run/schedule queries and manage connections. "
            "Viewer: read-only access to results and shared queries. "
            "Assign roles at Admin → Users. Auth supports LDAP/AD and local password."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Audit Log & Compliance",
        "text": (
            "All query executions, login events, config changes, and admin actions are recorded "
            "in the audit log. View at Admin → Audit Log. "
            "Compliance reports can be exported as CSV. "
            "The audit log captures: user, action, resource, timestamp, IP address, and outcome."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "How to Execute a Query",
        "text": (
            "To run a query: 1) Go to SQL Editor or Query Builder. "
            "2) Type or build your SQL. 3) Press Ctrl+Enter or click the Run button (▶). "
            "Results appear in the Data Grid below the editor. "
            "You can also run from the assistant: type your question, generate SQL, then click 'Use in SQL Editor'. "
            "For scheduled runs, open the query → Schedule tab."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Data Grid — Sort, Filter, Chart, Pivot",
        "text": (
            "The data grid supports: column sorting (click header), advanced filters (funnel icon), "
            "column visibility toggle, freeze/pin columns, export (CSV/Parquet/Excel). "
            "Switch to Chart view to visualise data as bar, line, pie, or scatter chart. "
            "Switch to Pivot view for Excel-style cross-tabulation with row/column/value fields. "
            "Column stats (min, max, avg, null count) are available per column."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Auto-Suggest (Table & Column Suggestions)",
        "text": (
            "As you write SQL, QueryStudio tracks table and column usage. "
            "The assistant can suggest the most-used tables (say 'what tables are available?') "
            "and columns for any table (say 'columns in orders'). "
            "Suggestions are ranked by usage frequency. Schema cache is populated when you "
            "open the schema browser or run queries."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Parametric Reports",
        "text": (
            "Parametric reports are saved queries with named parameters (e.g. :start_date, :end_date). "
            "Consumers fill in the parameters at run-time without editing the SQL. "
            "Create a parametric report by using :param_name placeholders in your SQL. "
            "Reports can be shared with viewers who only see the parameter form."
        ),
        "source": "Built-in KB",
    },
]


def _load_docs() -> List[Dict[str, Any]]:
    global _docs_sections
    if _docs_sections is not None:
        return _docs_sections

    docs_root = _Path(__file__).parent.parent.parent  # c:/DEV/outputs
    html_files = [
        (docs_root / "user_guide.html",              "User Guide"),
        (docs_root / "ARCHITECTURE.html",            "Architecture"),
        (docs_root / "technical-learning-guide.html","Tech Guide"),
        (docs_root / "feature-tracking.html",        "Feature Tracking"),
        (docs_root / "plan.html",                    "Plan"),
    ]
    sections: List[Dict[str, Any]] = []

    # 1. Parse HTML files
    for path, source in html_files:
        if not path.exists():
            continue
        try:
            html = path.read_text(encoding="utf-8", errors="replace")
            parser = _SectionParser()
            parser.feed(html)
            for s in parser.sections:
                full_text = s["heading"] + " " + s["text"]
                kw = _tokenize(full_text)
                sections.append({
                    "heading":        s["heading"],
                    "text":           s["text"],
                    "source":         source,
                    "keywords":       kw,
                    "heading_tokens": _tokenize(s["heading"]),
                })
        except Exception as exc:
            logger.warning("docs: failed to load %s — %s", path, exc)

    # 2. Add built-in knowledge base entries
    for entry in _BUILTIN_KB:
        full_text = entry["heading"] + " " + entry["text"]
        kw = _tokenize(full_text)
        sections.append({
            "heading":        entry["heading"],
            "text":           entry["text"],
            "source":         entry["source"],
            "keywords":       kw,
            "heading_tokens": _tokenize(entry["heading"]),
        })

    _docs_sections = sections  # cache — cleared only on module reload
    logger.info("Docs knowledge base loaded: %d sections (%d HTML + %d built-in)",
                len(sections), len(sections) - len(_BUILTIN_KB), len(_BUILTIN_KB))
    return _docs_sections


def _search_docs(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """
    Score sections by token overlap + phrase matching.
    Scoring weights:
      • heading exact-phrase match   ×10
      • heading token overlap        ×4 each
      • body exact-phrase match      ×5
      • body token overlap           ×1 each
      • substring bonus (4+ chars)   ×1.5 each
      • built-in KB section          ×1.2 multiplier (freshest docs)
    """
    sections = _load_docs()
    q_tokens = _tokenize(query)
    if not q_tokens:
        return []

    query_lc = query.strip().lower()
    # Build 2-word phrases from the query for phrase matching
    q_words = [w for w in _re.split(r'\s+', query_lc) if len(w) >= 3]

    scored = []
    for s in sections:
        full_lc = (s["heading"] + " " + s["text"]).lower()
        head_lc = s["heading"].lower()

        heading_overlap = len(q_tokens & s["heading_tokens"])
        body_overlap    = len(q_tokens & s["keywords"])

        # Phrase match: query as a whole or as bigrams in heading / body
        phrase_score = 0.0
        if query_lc in head_lc:
            phrase_score += 10
        elif query_lc in full_lc:
            phrase_score += 5
        else:
            for i in range(len(q_words) - 1):
                bigram = q_words[i] + " " + q_words[i + 1]
                if bigram in head_lc:
                    phrase_score += 4
                elif bigram in full_lc:
                    phrase_score += 2

        # Substring bonus for tokens not already counted
        substr_bonus = sum(
            1.5 for t in q_tokens
            if len(t) >= 4 and t in full_lc and t not in s["keywords"]
        )

        score = heading_overlap * 4 + body_overlap + substr_bonus + phrase_score
        # Freshness boost for built-in KB
        if s["source"] == "Built-in KB":
            score *= 1.2

        if score >= 1:
            scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    seen_headings: set = set()
    for score, s in scored:
        if len(results) >= top_k:
            break
        # Deduplicate near-identical headings
        hkey = s["heading"].lower()[:40]
        if hkey in seen_headings:
            continue
        seen_headings.add(hkey)
        results.append({
            "heading": s["heading"],
            "excerpt": s["text"][:500] + ("…" if len(s["text"]) > 500 else ""),
            "source":  s["source"],
            "score":   round(score, 1),
        })
    return results


@router.get("/api/suggest/docs")
async def suggest_docs(
    q: str = "",
    _user: dict = Depends(get_current_user),
):
    """
    Keyword search over the QueryStudio user guide and architecture docs.
    Returns the top matching sections (heading + excerpt) — no LLM needed.
    """
    if not q or len(q.strip()) < 3:
        return {"results": [], "message": "Provide ?q=your+question"}

    results = _search_docs(q.strip(), top_k=3)
    return {
        "query": q,
        "results": results,
        "found": len(results) > 0,
    }


# ── Phase: Grid Data Query ────────────────────────────────────────────────────

# Negative lookahead: prevent capturing prepositions/articles as column names.
# E.g. "average by month" must NOT capture "by" as the column.
_NO_PREP    = r'(?!(?:by|the|a|an|in|from|for|to|of|all|each|per|and|or|my)\b)'
_MAX_RE     = _re.compile(r'\bmax(?:imum)?\s+(?:of\s+)?' + _NO_PREP + r'(\w+)', _re.I)
_MIN_RE     = _re.compile(r'\bmin(?:imum)?\s+(?:of\s+)?' + _NO_PREP + r'(\w+)', _re.I)
_AVG_RE     = _re.compile(r'\b(?:avg|average|mean)\s+(?:of\s+)?' + _NO_PREP + r'(\w+)', _re.I)
# SUM + TOTAL handled together; preposition guard prevents "sum by col" = bad
_SUM_RE     = _re.compile(r'\b(?:sum|total)\s+(?:of\s+)?' + _NO_PREP + r'(\w+)', _re.I)
_TOPN_RE    = _re.compile(r'\btop\s+(\d+)\s+(?:rows?\s+)?(?:by\s+)?(\w+)', _re.I)
# Distinct: accept both "in" and "of" as separators → "distinct values in status"
_DIST_RE    = _re.compile(r'\bdistinct(?:\s+values?)?\s+(?:(?:of|in)\s+)?' + _NO_PREP + r'(\w+)', _re.I)
_COUNTW_RE  = _re.compile(r'\bcount\s+where\s+([\w]+)\s*(?:=|is|equals?)\s*["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_GROUPBY_RE = _re.compile(r'\b(?:count|group)\s+by\s+([\w]+)', _re.I)
_FILTER_RE  = _re.compile(r'\b(?:show|where|filter|rows?\s+where)\s+([\w]+)\s*(?:=|is|equals?)\s*["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_FIRSTN_RE  = _re.compile(r'\b(?:first|top)\s+(\d+)\b', _re.I)
_TREND_RE   = _re.compile(
    r'\b(?:trend(?:ing)?|over\s+time|by\s+(?:month|week|day|year|quarter|date)'
    r'|monthly|weekly|daily|yearly|quarterly|growth|change\s+over|time\s+series)\b', _re.I)
_SUMMARY_RE = _re.compile(
    r'\b(?:summar(?:y|ize|ise)|overview|describe(\s+(?:this|the)\s+data)?'
    r'|profile|insights?|whats?\s+interesting|analyze\s+(this\s+)?data|quick\s+(look|stats?)'
    r'|tell\s+me\s+about\s+(this|the)\s+data)\b', _re.I)
_OUTLIER_RE = _re.compile(
    r'\b(?:outlier|anomal|unusual|extreme\s+values?|spikes?|dips?|weird|suspicious)\b', _re.I)
_XBYY_RE    = _re.compile(
    r'\b(\w+)\s+by\s+(\w+)\b', _re.I)  # "revenue by entity", "sum of X by Y"
_XBYY_AGG_RE = _re.compile(
    r'\b(sum|total|avg|average|count|min|max)\s+(?:of\s+)?(\w+)\s+by\s+(\w+)\b', _re.I)
_BOTTOMN_RE   = _re.compile(r'\bbottom\s+(\d+)\s+(?:rows?\s+)?(?:by\s+)?(\w+)', _re.I)
_MEDIAN_RE    = _re.compile(r'\bmedian\s+(?:of\s+)?(\w+)', _re.I)
_PERCENTILE_RE = _re.compile(r'\bpercentile\s+(\d+)\s+(?:of\s+)?(\w+)', _re.I)
_STDDEV_RE    = _re.compile(r'\b(?:std\s*dev(?:iation)?|variance)\s+(?:of\s+)?(\w+)', _re.I)
_CORR_RE      = _re.compile(r'\bcorrelation\s+between\s+(\w+)\s+and\s+(\w+)', _re.I)
_NULLCOL_RE   = _re.compile(r'count\s+null[s]?\s+per\s+column|null[s]?\s+per\s+col|null\s+count', _re.I)
_NULLIN_RE    = _re.compile(r'\bnull[s]?\s+in\s+(\w+)|\bshow\s+null[s]?\s+(?:in\s+)?(\w+)', _re.I)
_ANYNULL_RE   = _re.compile(r'\brows?\s+with\s+any\s+null\b|missing\s+values?\s+in\s+any', _re.I)
_DUPES_RE     = _re.compile(r'\bduplicat(?:es?|ion)?\s+(?:in\s+|by\s+|of\s+)?(\w+)', _re.I)
_SAMPLE_RE    = _re.compile(r'\brandom\s+sample\s+(?:of\s+)?(\d+)', _re.I)
_PIVOT_RE     = _re.compile(r'\bpivot\s+(\w+)\s+by\s+(\w+)', _re.I)
_FREQDIST_RE  = _re.compile(r'\bfrequency\s+distribution\s+(?:of\s+)?(\w+)', _re.I)
_MOSTCOMMON_RE = _re.compile(r'\bmost\s+common\s+(?:values?\s+in\s+)?(\w+)', _re.I)
_SORTBY_RE    = _re.compile(r'\bsort(?:ed)?\s+by\s+(\w+)(?:\s+(asc(?:ending)?|desc(?:ending)?))?', _re.I)
_RUNNING_RE   = _re.compile(
    r'\b(?:running\s+total|cumulative\s+sum?)\s+(?:of\s+)?(\w+)(?:\s+(?:by|over|order(?:ed)?\s+by)\s+(\w+))?', _re.I)
_YTD_RE       = _re.compile(r'\b(?:this\s+year|year[\s-]to[\s-]date|ytd)\b', _re.I)
_MTD_RE       = _re.compile(r'\b(?:this\s+month|month[\s-]to[\s-]date|mtd)\b', _re.I)
_LASTMONTH_RE = _re.compile(r'\blast\s+month\b', _re.I)
_LAST7_RE     = _re.compile(r'\blast\s+7\s+days?\b', _re.I)
_LAST30_RE    = _re.compile(r'\blast\s+30\s+days?\b', _re.I)
_LAST90_RE    = _re.compile(r'\blast\s+90\s+days?\b', _re.I)
_LASTQUARTER_RE = _re.compile(r'\blast\s+quarter\b', _re.I)
_THISQUARTER_RE = _re.compile(r'\b(?:this\s+quarter|quarter[\s-]to[\s-]date|qtd)\b', _re.I)


# ── Helpers for smart column detection ────────────────────────────────────────

_DATE_COL_PATTERNS  = _re.compile(
    r'^(date|time|day|month|year|period|quarter|fiscal|posted|created|updated|entry|timestamp)', _re.I)
# Word-boundary-aware patterns: terms must appear as whole tokens separated by
# _ - . or start/end of string, so "sap_account" ≠ "count" and "corporate" ≠ "rate".
_NUM_COL_PATTERNS   = _re.compile(
    r'(?:(?:^|(?<=[_\-\. ]))'
    r'(amount|price|total|revenue|qty|quantity|count|metric|rate|value|balance'
    r'|debit|credit|cost|profit|salary|score|weight|volume|fee|charge)'
    r'(?=$|[_\-\. ]))', _re.I)
_CAT_COL_PATTERNS   = _re.compile(
    r'(?:(?:^|(?<=[_\-\. ]))'
    r'(status|type|category|entity|source|currency|country|region|code|flag'
    r'|class|group|segment|channel|brand|product|dept|division)'
    r'(?=$|[_\-\. ]))', _re.I)


def _pick_date_col(cols: List[str]) -> Optional[str]:
    """Find the most likely date/time column."""
    for c in cols:
        if _DATE_COL_PATTERNS.search(c):
            return c
    # Fallback: anything ending in _at, _date, _time
    for c in cols:
        if c.lower().endswith(('_at', '_date', '_time', '_dt')):
            return c
    return None


def _pick_num_col(cols: List[str]) -> Optional[str]:
    """Find the most likely numeric measure column (excluding date columns)."""
    for c in cols:
        if _NUM_COL_PATTERNS.search(c) and not _DATE_COL_PATTERNS.search(c):
            return c
    return None


def _pick_cat_col(cols: List[str]) -> Optional[str]:
    """Find the most likely categorical column."""
    for c in cols:
        if _CAT_COL_PATTERNS.search(c):
            return c
    return None


def _resolve_column(col: str, available: List[str]) -> str:
    """Best-match a user-typed column name against the real column list.
    Priority: exact (case-insensitive) → prefix → substring → as-is.
    """
    if not available:
        return col
    cl = col.lower()
    for c in available:
        if c.lower() == cl:
            return c
    for c in available:
        if c.lower().startswith(cl):
            return c
    for c in available:
        if cl in c.lower():
            return c
    return col


class DataQueryRequest(BaseModel):
    question: str
    execution_id: Optional[str] = None   # from a completed query execution
    file_id: Optional[str] = None        # from a downloaded S3 / upload file
    columns: List[str] = []


@router.post("/api/suggest/data-query")
async def data_query(body: DataQueryRequest, _user: dict = Depends(get_current_user)):
    """Run a natural-language aggregate query against an execution output or downloaded file."""
    import duckdb as _duckdb
    import os as _os

    if not body.execution_id and not body.file_id:
        return {"found": False, "message": "Provide execution_id or file_id."}

    output_file: Optional[str] = None

    try:
        with _db_manager.get_session() as session:
            if body.execution_id:
                from core.database import QueryExecution as _QE
                row = (
                    session.query(_QE)
                    .filter(_QE.execution_id == body.execution_id,
                            _QE.status == "completed",
                            _QE.output_file.isnot(None))
                    .first()
                )
                if row:
                    output_file = row.output_file
            if not output_file and body.file_id:
                from core.database import DownloadFile as _DF
                drow = (
                    session.query(_DF)
                    .filter(_DF.file_id == body.file_id)
                    .first()
                )
                if drow:
                    output_file = drow.file_path
    except Exception as exc:
        return {"found": False, "message": str(exc)}

    if not output_file:
        return {"found": False, "message": "File not found. Run a query first or check the file ID."}
    if not _os.path.exists(output_file):
        return {"found": False, "message": "Result file has been deleted from disk."}

    q   = body.question.strip()
    ql  = q.lower()
    sp  = output_file.replace("'", "''")   # safe path for DuckDB string literal

    sql = None
    answer_prefix = ""

    avail = body.columns  # known column names for fuzzy resolution

    # ── Check grouped agg FIRST so "sum of X by Y" beats plain "sum of X" ──────
    if m := _XBYY_AGG_RE.search(ql):
        agg_fn_map = {"sum": "SUM", "total": "SUM", "avg": "AVG", "average": "AVG",
                      "count": "COUNT", "min": "MIN", "max": "MAX"}
        agg_fn  = agg_fn_map.get(m.group(1).lower(), "SUM")
        val_col = _resolve_column(m.group(2), avail)
        grp_col = _resolve_column(m.group(3), avail)
        # Detect likely non-numeric (ID / text) columns when a numeric agg is requested
        _ID_COL_RE = _re.compile(
            r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', _re.I)
        _numeric_agg = agg_fn in ("SUM", "AVG")
        if _numeric_agg and _ID_COL_RE.search(val_col):
            return {
                "found": False,
                "message": (
                    f"'{val_col}' looks like a text/ID column — {agg_fn.lower()} is not meaningful on it.\n"
                    f"Try: **count {val_col} by {grp_col}** to count rows per group, "
                    f"or pick a numeric column like debit_amount or balance."
                ),
                "sql": None,
            }
        agg_expr = "COUNT(*)" if agg_fn == "COUNT" else f"ROUND({agg_fn}(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2)"
        sql = (
            f"SELECT \"{grp_col}\", {agg_expr} AS {agg_fn.lower()}_{val_col} "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{grp_col}\" ORDER BY {agg_fn.lower()}_{val_col} DESC NULLS LAST LIMIT 50"
        )
        answer_prefix = f"{agg_fn.title()} of {val_col} by {grp_col}"
    elif m := _MAX_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT MAX(\"{col}\") AS max_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Maximum of {col}"
    elif m := _MIN_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT MIN(\"{col}\") AS min_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Minimum of {col}"
    elif m := _AVG_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        if _re.search(r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', col, _re.I):
            return {"found": False, "message": f"'{col}' looks like a text/ID column — avg is not meaningful on it. Try a numeric column like debit_amount or balance.", "sql": None}
        sql = f"SELECT ROUND(TRY_CAST(AVG(TRY_CAST(\"{col}\" AS DOUBLE)) AS DOUBLE), 4) AS avg_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Average of {col}"
    elif m := _SUM_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        if _re.search(r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', col, _re.I):
            return {"found": False, "message": f"'{col}' looks like a text/ID column — sum is not meaningful on it. Try a numeric column like debit_amount or balance.", "sql": None}
        sql = f"SELECT ROUND(SUM(TRY_CAST(\"{col}\" AS DOUBLE)), 2) AS sum_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Sum of {col}"
    elif m := _BOTTOMN_RE.search(ql):
        n = min(int(m.group(1)), 100)
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY TRY_CAST(\"{col}\" AS DOUBLE) ASC NULLS LAST LIMIT {n}"
        answer_prefix = f"Bottom {n} by {col}"
    elif m := _MEDIAN_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT ROUND(MEDIAN(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS median_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Median of {col}"
    elif m := _PERCENTILE_RE.search(ql):
        pct = max(1, min(int(m.group(1)), 99))
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT ROUND(QUANTILE_CONT(TRY_CAST(\"{col}\" AS DOUBLE), {pct/100}), 4) AS p{pct}_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"{pct}th percentile of {col}"
    elif m := _TOPN_RE.search(ql):
        n = min(int(m.group(1)), 100)
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY \"{col}\" DESC NULLS LAST LIMIT {n}"
        answer_prefix = f"Top {n} by {col}"
    elif m := _DIST_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT DISTINCT \"{col}\" FROM read_parquet('{sp}') ORDER BY 1 LIMIT 100"
        answer_prefix = f"Distinct values of {col}"
    elif m := _COUNTW_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        val = m.group(2).strip()
        sql = f"SELECT COUNT(*) AS count FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}')"
        answer_prefix = f"Count where {col} = {val}"
    elif m := _GROUPBY_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT \"{col}\", COUNT(*) AS count FROM read_parquet('{sp}') GROUP BY \"{col}\" ORDER BY count DESC LIMIT 50"
        answer_prefix = f"Count by {col}"
    elif m := _FILTER_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        val = m.group(2).strip()
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}') LIMIT 50"
        answer_prefix = f"Rows where {col} = {val}"

    # ── Trend / time-series ───────────────────────────────────────────────────
    elif _TREND_RE.search(ql):
        date_col = _pick_date_col(avail)
        num_col  = _pick_num_col(avail)
        # Allow user to specify columns: "trend of amount by month"
        if m2 := _re.search(r'trend\s+(?:of\s+)?(\w+)', ql):
            num_col = _resolve_column(m2.group(1), avail) or num_col
        if m2 := _re.search(r'by\s+(month|week|day|year|quarter)', ql, _re.I):
            granularity = m2.group(1).lower()
        else:
            granularity = "month"
        trunc_map = {"day": "day", "week": "week", "month": "month",
                     "quarter": "quarter", "year": "year"}
        gran = trunc_map.get(granularity, "month")
        if date_col and num_col:
            sql = (
                f"SELECT DATE_TRUNC('{gran}', TRY_CAST(\"{date_col}\" AS DATE)) AS period, "
                f"COUNT(*) AS row_count, "
                f"ROUND(SUM(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS total_{num_col}, "
                f"ROUND(AVG(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS avg_{num_col} "
                f"FROM read_parquet('{sp}') "
                f"WHERE \"{date_col}\" IS NOT NULL "
                f"GROUP BY 1 ORDER BY 1"
            )
            answer_prefix = f"Trend of {num_col} by {gran} (via {date_col})"
        elif date_col:
            sql = (
                f"SELECT DATE_TRUNC('{gran}', TRY_CAST(\"{date_col}\" AS DATE)) AS period, "
                f"COUNT(*) AS row_count "
                f"FROM read_parquet('{sp}') "
                f"WHERE \"{date_col}\" IS NOT NULL "
                f"GROUP BY 1 ORDER BY 1"
            )
            answer_prefix = f"Row count by {gran}"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "No date column detected — showing sample"

    # ── Summary / profile ─────────────────────────────────────────────────────
    elif _SUMMARY_RE.search(ql):
        # DuckDB SUMMARIZE gives min/max/avg/std/q25/q50/q75/null% per column
        sql = f"SUMMARIZE SELECT * FROM read_parquet('{sp}')"
        answer_prefix = "Dataset summary (all columns)"

    # ── Outlier / extreme values ──────────────────────────────────────────────
    elif _OUTLIER_RE.search(ql):
        num_col = _pick_num_col(avail)
        if m2 := _re.search(r'outlier[s]?\s+(?:in\s+)?(\w+)', ql):
            num_col = _resolve_column(m2.group(1), avail) or num_col
        if num_col:
            sql = (
                f"WITH stats AS ("
                f"  SELECT AVG(TRY_CAST(\"{num_col}\" AS DOUBLE)) AS mu, "
                f"         STDDEV(TRY_CAST(\"{num_col}\" AS DOUBLE)) AS sigma "
                f"  FROM read_parquet('{sp}')"
                f") "
                f"SELECT * FROM read_parquet('{sp}'), stats "
                f"WHERE ABS(TRY_CAST(\"{num_col}\" AS DOUBLE) - mu) > 2 * sigma "
                f"ORDER BY ABS(TRY_CAST(\"{num_col}\" AS DOUBLE) - mu) DESC NULLS LAST "
                f"LIMIT 50"
            )
            answer_prefix = f"Outliers in {num_col} (>2σ from mean)"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "No numeric column detected — showing sample"

    # ── Std dev / variance ───────────────────────────────────────────────────
    elif m := _STDDEV_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        label = "variance" if "variance" in ql else "std_dev"
        fn = "VARIANCE" if "variance" in ql else "STDDEV"
        sql = (
            f"SELECT ROUND({fn}(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS {label}_{col}, "
            f"ROUND(AVG(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS mean_{col}, "
            f"ROUND(MIN(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS min_{col}, "
            f"ROUND(MAX(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS max_{col} "
            f"FROM read_parquet('{sp}')"
        )
        answer_prefix = f"{label.replace('_',' ').title()} of {col}"

    # ── Correlation ──────────────────────────────────────────────────────────
    elif m := _CORR_RE.search(ql):
        colA = _resolve_column(m.group(1), avail)
        colB = _resolve_column(m.group(2), avail)
        sql = (
            f"SELECT ROUND(CORR(TRY_CAST(\"{colA}\" AS DOUBLE), TRY_CAST(\"{colB}\" AS DOUBLE)), 4) AS correlation, "
            f"COUNT(*) AS n FROM read_parquet('{sp}')"
        )
        answer_prefix = f"Correlation between {colA} and {colB}"

    # ── Null checks ──────────────────────────────────────────────────────────
    elif _NULLCOL_RE.search(ql):
        # Build a query counting nulls per column dynamically
        if avail:
            null_exprs = ", ".join(
                f"SUM(CASE WHEN \"{c}\" IS NULL THEN 1 ELSE 0 END) AS null_{c}" for c in avail[:30]
            )
            sql = f"SELECT {null_exprs} FROM read_parquet('{sp}')"
            answer_prefix = "Null count per column"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 5"
            answer_prefix = "Sample (no column info)"
    elif m := _NULLIN_RE.search(ql):
        col = _resolve_column(m.group(1) or m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE \"{col}\" IS NULL LIMIT 50"
        answer_prefix = f"Rows where {col} is null"
    elif _ANYNULL_RE.search(ql):
        if avail:
            cond = " OR ".join(f"\"{c}\" IS NULL" for c in avail[:30])
            sql = f"SELECT * FROM read_parquet('{sp}') WHERE {cond} LIMIT 50"
            answer_prefix = "Rows with any null value"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "Sample rows"

    # ── Duplicates ───────────────────────────────────────────────────────────
    elif m := _DUPES_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = (
            f"SELECT \"{col}\", COUNT(*) AS occurrences "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{col}\" HAVING COUNT(*) > 1 "
            f"ORDER BY occurrences DESC LIMIT 50"
        )
        answer_prefix = f"Duplicate values in {col}"

    # ── Random sample ────────────────────────────────────────────────────────
    elif m := _SAMPLE_RE.search(ql):
        n = min(int(m.group(1)), 500)
        sql = f"SELECT * FROM read_parquet('{sp}') USING SAMPLE {n}"
        answer_prefix = f"Random sample of {n} rows"

    # ── Pivot ────────────────────────────────────────────────────────────────
    elif m := _PIVOT_RE.search(ql):
        val_col = _resolve_column(m.group(1), avail)
        grp_col = _resolve_column(m.group(2), avail)
        # Use GROUP BY aggregation (works for any schema without knowing pivot values upfront)
        sql = (
            f"SELECT \"{grp_col}\", "
            f"COUNT(*) AS row_count, "
            f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2) AS sum_{val_col}, "
            f"ROUND(AVG(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2) AS avg_{val_col} "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{grp_col}\" ORDER BY sum_{val_col} DESC NULLS LAST LIMIT 50"
        )
        answer_prefix = f"Pivot of {val_col} by {grp_col}"

    # ── Frequency distribution / most common ─────────────────────────────────
    elif m := (_FREQDIST_RE.search(ql) or _MOSTCOMMON_RE.search(ql)):
        col = _resolve_column(m.group(1), avail)
        total_expr = f"COUNT(*) OVER ()"
        sql = (
            f"SELECT \"{col}\", COUNT(*) AS frequency, "
            f"ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{col}\" ORDER BY frequency DESC LIMIT 30"
        )
        answer_prefix = f"Frequency distribution of {col}"

    # ── Running total / cumulative sum ───────────────────────────────────────
    elif m := _RUNNING_RE.search(ql):
        val_col  = _resolve_column(m.group(1), avail)
        sort_raw = m.group(2)
        sort_col = _resolve_column(sort_raw, avail) if sort_raw else (_pick_date_col(avail) or None)
        if sort_col:
            sql = (
                f"WITH t AS (SELECT *, ROW_NUMBER() OVER () AS _rn FROM read_parquet('{sp}')) "
                f"SELECT \"{sort_col}\", \"{val_col}\", "
                f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)) OVER (ORDER BY \"{sort_col}\" ROWS UNBOUNDED PRECEDING), 2) "
                f"AS cumulative_{val_col} FROM t ORDER BY \"{sort_col}\" LIMIT 200"
            )
            answer_prefix = f"Running total of {val_col} by {sort_col}"
        else:
            sql = (
                f"WITH t AS (SELECT ROW_NUMBER() OVER () AS row_num, \"{val_col}\" FROM read_parquet('{sp}')) "
                f"SELECT row_num, \"{val_col}\", "
                f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)) OVER (ORDER BY row_num ROWS UNBOUNDED PRECEDING), 2) "
                f"AS cumulative_{val_col} FROM t LIMIT 200"
            )
            answer_prefix = f"Running total of {val_col} (row order)"

    # ── Date-relative filters ─────────────────────────────────────────────────
    elif _YTD_RE.search(ql) or _MTD_RE.search(ql) or _LASTMONTH_RE.search(ql) or \
         _LAST7_RE.search(ql) or _LAST30_RE.search(ql) or _LAST90_RE.search(ql) or \
         _LASTQUARTER_RE.search(ql) or _THISQUARTER_RE.search(ql):
        date_col = _pick_date_col(avail)
        if not date_col:
            return {"found": False, "message": "No date column detected in the current result. "
                    "Date filters need a column whose name contains date, time, created, posted, etc.",
                    "sql": None}
        if _YTD_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('year', CURRENT_DATE)"
            label  = "Year-to-date"
        elif _MTD_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('month', CURRENT_DATE)"
            label  = "Month-to-date"
        elif _LASTMONTH_RE.search(ql):
            where  = (f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month') "
                      f"AND TRY_CAST(\"{date_col}\" AS DATE) < DATE_TRUNC('month', CURRENT_DATE)")
            label  = "Last month"
        elif _LAST7_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '7 days'"
            label  = "Last 7 days"
        elif _LAST30_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '30 days'"
            label  = "Last 30 days"
        elif _LAST90_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '90 days'"
            label  = "Last 90 days"
        elif _THISQUARTER_RE.search(ql):
            where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('quarter', CURRENT_DATE)"
            label  = "This quarter"
        else:  # last quarter
            where  = (f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('quarter', CURRENT_DATE - INTERVAL '3 months') "
                      f"AND TRY_CAST(\"{date_col}\" AS DATE) < DATE_TRUNC('quarter', CURRENT_DATE)")
            label  = "Last quarter"
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE {where} LIMIT 500"
        answer_prefix = f"{label} rows (filtered by {date_col})"

    # ── Sort by column ────────────────────────────────────────────────────────
    elif m := _SORTBY_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        direction = "ASC" if (m.group(2) or "desc").lower().startswith("asc") else "DESC"
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY \"{col}\" {direction} NULLS LAST LIMIT 100"
        answer_prefix = f"Sorted by {col} {direction.lower()}"

    elif _re.search(r'\bcount\b', ql):
        sql = f"SELECT COUNT(*) AS total_rows FROM read_parquet('{sp}')"
        answer_prefix = "Total row count"
    else:
        limit = 10
        if m2 := _FIRSTN_RE.search(ql):
            limit = min(int(m2.group(1)), 100)
        sql = f"SELECT * FROM read_parquet('{sp}') LIMIT {limit}"
        answer_prefix = f"Sample of {limit} rows"

    try:
        con = _duckdb.connect(":memory:")
        try:
            df = con.execute(sql).fetchdf()
            columns = list(df.columns)
            # Sanitize NaN/Inf — not JSON-serializable (SUMMARIZE returns them for non-numeric cols)
            import math as _math
            rows = []
            for record in df.to_dict(orient="records"):
                clean = {}
                for k, v in record.items():
                    if isinstance(v, float) and (_math.isnan(v) or _math.isinf(v)):
                        clean[k] = None
                    else:
                        clean[k] = v
                rows.append(clean)
        finally:
            con.close()
        return {
            "found": True,
            "answer": answer_prefix,
            "sql": sql,
            "columns": columns,
            "rows": rows[:100],
            "row_count": len(rows),
        }
    except Exception as exc:
        logger.warning("data-query failed: %s | sql=%s", exc, sql)
        return {"found": False, "message": f"Query failed: {exc}", "sql": sql}


# ── NL Feedback (Learning Loop) ───────────────────────────────────────────────

class NLFeedbackRequest(BaseModel):
    question: str
    sql: str
    connection_type: str = "duckdb"
    tables_hint: Optional[str] = None
    rating: int = 1   # 1 = thumbs-up, -1 = thumbs-down


@router.post("/api/suggest/feedback")
async def save_nl_feedback(body: NLFeedbackRequest, _user: dict = Depends(get_current_user)):
    """Save user thumbs-up/down rating for a NL→SQL pair (learning loop)."""
    _db_manager.save_nl_feedback(
        question=body.question,
        sql=body.sql,
        connection_type=body.connection_type,
        tables_hint=body.tables_hint,
        rating=body.rating,
    )
    return {"saved": True, "rating": body.rating}


# ── Suggestion Corrections (Smart Agg + Join Learning) ────────────────────────

class SuggestionCorrectionRequest(BaseModel):
    correction_type: str            # "agg" | "join"
    context_key: str                # column name (agg) or "left||right" (join)
    corrected_value: str            # function name (agg) or JSON conditions (join)
    original_value: Optional[str] = None
    context_extra: Optional[str] = None


@router.post("/api/suggest/correction")
async def save_suggestion_correction(
    body: SuggestionCorrectionRequest,
    _user: dict = Depends(get_current_user),
):
    """Save user correction for aggregation function or join columns."""
    from core import config as _cfg
    if not _cfg.suggestion_corrections.enabled:
        return {"saved": False, "reason": "suggestion_corrections disabled"}
    if body.correction_type not in ("agg", "join"):
        raise HTTPException(status_code=422, detail="correction_type must be 'agg' or 'join'")
    username = (_user or {}).get("username")
    result = _db_manager.save_suggestion_correction(
        correction_type=body.correction_type,
        context_key=body.context_key,
        corrected_value=body.corrected_value,
        original_value=body.original_value,
        context_extra=body.context_extra,
        username=username,
    )
    return {"saved": True, "correction": result}


@router.get("/api/suggest/corrections/agg")
async def get_agg_corrections(_user: dict = Depends(get_current_user)):
    """Return all aggregation corrections for client-side cache."""
    corrections = _db_manager.get_all_agg_corrections()
    return {"corrections": corrections}


@router.get("/api/suggest/corrections/join")
async def get_join_corrections(_user: dict = Depends(get_current_user)):
    """Return all join corrections for client-side cache."""
    corrections = _db_manager.get_all_join_corrections()
    return {"corrections": corrections}


@router.get("/api/nl-to-sql/examples")
async def nl_to_sql_examples(
    dataset_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """Return example prompts. When dataset_id provided, includes semantic + time intelligence examples."""
    from core import config as _cfg
    examples = [
        {"prompt": "top 10 customers by revenue",        "pattern": "top N by column"},
        {"prompt": "count orders",                        "pattern": "count rows"},
        {"prompt": "average salary by department",        "pattern": "average per group"},
        {"prompt": "total revenue by region",             "pattern": "sum per group"},
        {"prompt": "show all products",                   "pattern": "show all rows"},
        {"prompt": "orders where status is pending",      "pattern": "filter equals"},
        {"prompt": "distinct values of category in products", "pattern": "distinct values"},
        {"prompt": "min and max price in products",       "pattern": "min/max"},
        {"prompt": "orders grouped by status",            "pattern": "group by count"},
        {"prompt": "sales between 2026-01-01 and 2026-03-31", "pattern": "date range"},
        {"prompt": "recent 7 days of events",             "pattern": "recent rows"},
    ]
    # Phase 57 — time intelligence examples
    if _cfg.chatbot.time_intelligence_enabled:
        examples += [
            {"prompt": "YTD revenue by region",                    "pattern": "year-to-date"},
            {"prompt": "MTD sales by product",                     "pattern": "month-to-date"},
            {"prompt": "same period last year revenue by region",  "pattern": "SPLY comparison"},
            {"prompt": "revenue this month vs last month",         "pattern": "period-over-period"},
            {"prompt": "running total of revenue by date",         "pattern": "running total"},
            {"prompt": "percentage of total revenue by region",    "pattern": "percent of total"},
            {"prompt": "3 month moving average of sales",          "pattern": "moving average"},
            {"prompt": "month over month growth of revenue",       "pattern": "growth rate"},
            {"prompt": "rank customers by revenue",                "pattern": "rank"},
        ]
    # Phase 57 — dataset condition examples
    if dataset_id:
        ds = _db_manager.get_dataset_full(dataset_id)
        if ds:
            for cond in (ds.get("conditions") or []):
                examples.append({
                    "prompt": f"show {cond.get('label') or cond['name']}",
                    "pattern": "pre-defined condition",
                    "condition_name": cond["name"],
                })
    return {"examples": examples}


@router.get("/api/suggest/chatbot-patterns")
async def chatbot_patterns(_user: dict = Depends(get_current_user)):
    """
    Return the full chatbot configuration:
    - Column classification patterns (numeric/category/date/id)
    - FAQ keyword→answer map
    - Business glossary (term→SQL fragment) for NL-to-SQL substitution
    All values are read from config.json under the 'chatbot' section.
    """
    from core import config as _cfg
    return {
        "numeric_patterns":  _cfg.chatbot.numeric_patterns,
        "category_patterns": _cfg.chatbot.category_patterns,
        "date_patterns":     _cfg.chatbot.date_patterns,
        "id_patterns":       _cfg.chatbot.id_patterns,
        "faq":               _cfg.chatbot.faq,
        "glossary":          _cfg.chatbot.glossary,
    }
