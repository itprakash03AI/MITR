"""
Notification history endpoints.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_notification_dependencies(db_manager)`` once at startup.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Notifications"])

# ── Module-level singletons ───────────────────────────────────────────────────
_db_manager = None   # DatabaseManager singleton


def set_notification_dependencies(db_manager) -> None:
    """Called once from main.py after db_manager is created."""
    global _db_manager
    _db_manager = db_manager


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/notifications")
async def list_notifications(
    unread_only: bool = False,
    limit: int = 50,
    offset: int = 0,
    _user: dict = Depends(get_current_user),
):
    """Paginated notification history for the current user."""
    username = (_user or {}).get("username", "guest")
    items = _db_manager.list_notifications(username, unread_only=unread_only,
                                           limit=limit, offset=offset)
    unread = _db_manager.count_unread_notifications(username)
    return {"items": items, "unread_count": unread}


@router.get("/api/notifications/unread-count")
async def notifications_unread_count(_user: dict = Depends(get_current_user)):
    """Unread notification count for badge display."""
    username = (_user or {}).get("username", "guest")
    return {"count": _db_manager.count_unread_notifications(username)}


# NOTE: static /read-all MUST be declared before parameterised /{notif_id}/read
@router.put("/api/notifications/read-all")
async def mark_all_notifications_read(_user: dict = Depends(get_current_user)):
    """Mark all notifications as read for the current user."""
    username = (_user or {}).get("username", "guest")
    count = _db_manager.mark_all_notifications_read(username)
    return {"ok": True, "count": count}


@router.put("/api/notifications/{notif_id}/read")
async def mark_notification_read(
    notif_id: int,
    _user: dict = Depends(get_current_user),
):
    """Mark a single notification as read."""
    _db_manager.mark_notification_read(notif_id)
    return {"ok": True}
