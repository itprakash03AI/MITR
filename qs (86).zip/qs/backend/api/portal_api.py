"""
Business Portal API (Phase 59)

Endpoints:
  GET /api/portal/summary  — aggregated portal landing page data
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException

from api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(tags=["portal"])

_db_manager = None
_auth_cfg = None


def set_portal_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Portal API not initialised")
    return _db_manager


# ── Portal summary endpoint ──────────────────────────────────────────────────

@router.get("/api/portal/summary")
async def get_portal_summary(user: dict = Depends(get_current_user)):
    """Aggregated portal data for the landing page."""
    from core import config as _cfg

    portal_cfg = _cfg.business_portal
    if not portal_cfg.enabled:
        raise HTTPException(status_code=403, detail="Business portal is disabled")

    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    # --- KPI counts ---
    report_counts = db.count_user_reports(username, role)
    favorites_all = db.get_user_favorites(username, report_type=None)
    exec_today = db.count_executions_today(username)
    unread = db.count_unread_notifications(username)
    dashboards = db.list_dashboards(
        created_by=username if role != "admin" else None,
        is_admin=(role == "admin"),
    )

    kpi = {
        "total_reports": report_counts["total"],
        "favorites_count": len(favorites_all),
        "executions_today": exec_today,
        "unread_notifications": unread,
        "dashboards_count": len(dashboards),
    }

    # --- Recent reports (with full metadata) ---
    recent_ids = db.get_recently_viewed(
        username, limit=portal_cfg.recent_reports_limit, report_type=None,
    )
    recent_reports = _enrich_report_ids(db, recent_ids, role, username)

    # --- Favorites (with full metadata) ---
    fav_reports = _enrich_report_ids(
        db, favorites_all[:portal_cfg.favorites_limit], role, username,
    )

    # --- Certified templates ---
    try:
        templates = db.list_certified_templates(
            limit=portal_cfg.certified_templates_limit,
        )
    except Exception:
        templates = []

    # --- Recent activity (analyst/admin only) ---
    recent_activity: List[Dict[str, Any]] = []
    if role in ("admin", "analyst"):
        try:
            recent_activity = db.list_audit_log(
                username=username if role == "analyst" else None,
                limit=portal_cfg.recent_activity_limit,
            )
        except Exception:
            recent_activity = []

    # --- Admin-only: active queries ---
    active_queries = 0
    if role == "admin":
        try:
            from core.execution_state import running_tasks
            active_queries = sum(1 for t in running_tasks.values()
                                 if not t.done())
        except Exception:
            active_queries = 0

    return {
        "welcome_message":       portal_cfg.welcome_message,
        "welcome_subtitle":      portal_cfg.welcome_subtitle,
        "kpi":                   kpi,
        "recent_reports":        recent_reports,
        "favorites":             fav_reports,
        "certified_templates":   templates,
        "recent_activity":       recent_activity,
        "dashboards":            [_slim_dashboard(d) for d in dashboards[:6]],
        "quick_actions_enabled": portal_cfg.quick_actions_enabled,
        "kpi_cards_enabled":     portal_cfg.kpi_cards_enabled,
        "active_queries":        active_queries,
        "role":                  role,
    }


# ── Helpers ──────────────────────────────────────────────────────────────────

def _enrich_report_ids(db, id_list, role, username):
    """Given list of {report_id, report_type}, fetch full metadata."""
    results: List[Dict[str, Any]] = []
    for item in id_list:
        rid = item.get("report_id")
        rtype = item.get("report_type", "parametric")
        try:
            if rtype == "business":
                r = db.get_business_report(rid)
            else:
                r = db.get_report(rid)
            if r:
                r["report_type"] = rtype
                results.append(r)
        except Exception:
            pass  # skip deleted/inaccessible reports
    return results


def _slim_dashboard(d):
    """Return minimal dashboard info for portal cards."""
    return {
        "id": d.get("id"),
        "name": d.get("name"),
        "widget_count": len(d.get("widgets") or []),
        "updated_at": d.get("updated_at"),
    }
