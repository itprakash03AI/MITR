"""
Embedded Reports API (Phase 27)

Endpoints:
  POST   /api/reports/{id}/embed-tokens          — create embed token (admin/analyst)
  GET    /api/reports/{id}/embed-tokens          — list embed tokens
  DELETE /api/reports/embed-tokens/{token}       — revoke token
  GET    /api/embedded-report/{token}            — PUBLIC: report metadata
  POST   /api/embedded-report/{token}/execute    — PUBLIC: run report (no auth)
"""

from __future__ import annotations

import asyncio
import functools
import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()
_db = None
_auth_cfg = None
_executor = ThreadPoolExecutor(max_workers=4)

# ── Dependency injection ───────────────────────────────────────────────────────

def set_embed_dependencies(db_manager, auth_cfg):
    global _db, _auth_cfg
    _db = db_manager
    _auth_cfg = auth_cfg


def _require_db():
    if not _db:
        raise HTTPException(503, "Database not available")
    return _db


async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_executor, functools.partial(fn, *args, **kwargs))


def _get_user(request: Request) -> Optional[Dict[str, Any]]:
    """Resolve the current user including role — same pattern as reports_api."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        try:
            from main import _get_session
            return _get_session(auth_header[7:])
        except Exception:
            return None
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        return authenticate_user(username, password)
    except Exception:
        return None


def _require_analyst(request: Request) -> Dict[str, Any]:
    """Raise 403 if auth is enabled and user lacks analyst or admin role."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    role = (user or {}).get("role", "viewer")
    if role not in ("admin", "analyst"):
        raise HTTPException(403, "Requires role: admin or analyst")
    return user or {"username": "guest", "role": "admin", "is_admin": True}


# ── Pydantic models ────────────────────────────────────────────────────────────

class CreateEmbedTokenRequest(BaseModel):
    expires_in_days: Optional[int] = None  # None = never


class EmbedExecuteRequest(BaseModel):
    param_values: Optional[Dict[str, Any]] = None
    limit: Optional[int] = 1000


# ── Token management endpoints ─────────────────────────────────────────────────

@router.post("/api/reports/{report_id}/embed-tokens")
async def create_embed_token(report_id: int, req: CreateEmbedTokenRequest, request: Request):
    """Create an embed token for a report."""
    db = _require_db()
    user = _require_analyst(request)
    report = await _run_in_executor(db.get_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")

    expires_at = None
    if req.expires_in_days:
        from datetime import timedelta
        expires_at = datetime.now(timezone.utc) + timedelta(days=req.expires_in_days)

    token = await _run_in_executor(
        db.create_report_embed_token,
        report_id,
        (user or {}).get("username"),
        expires_at,
        None,
    )
    return token


@router.get("/api/reports/{report_id}/embed-tokens")
async def list_embed_tokens(report_id: int, request: Request):
    """List all embed tokens for a report."""
    db = _require_db()
    _require_analyst(request)
    tokens = await _run_in_executor(db.list_embed_tokens, report_id)
    return {"tokens": tokens}


@router.delete("/api/reports/embed-tokens/{token}")
async def revoke_embed_token(token: str, request: Request):
    """Revoke an embed token."""
    db = _require_db()
    _require_analyst(request)
    success = await _run_in_executor(db.revoke_embed_token, token)
    if not success:
        raise HTTPException(404, "Token not found")
    return {"message": "Token revoked"}


# ── Public embed endpoints ─────────────────────────────────────────────────────

def _validate_token(db, token: str) -> Dict[str, Any]:
    """Validate token is active and not expired. Raises 404/410 on failure."""
    t = db.get_embed_token(token)
    if not t or not t.get("is_active"):
        raise HTTPException(404, "Embed token not found or revoked")
    if t.get("expires_at"):
        expires = t["expires_at"]
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(410, "Embed token has expired")
    return t


@router.get("/api/embedded-report/{token}")
async def get_embedded_report(token: str):
    """PUBLIC — return report metadata for an embed token (no auth required)."""
    db = _require_db()
    t = _validate_token(db, token)
    report = await _run_in_executor(db.get_report, t["report_id"])
    if not report:
        raise HTTPException(404, "Report not found")
    # Increment access counter asynchronously
    await _run_in_executor(db.increment_embed_token_access, token)
    return {
        "token": token,
        "report": {
            "id": report["id"],
            "name": report["name"],
            "description": report.get("description"),
            "parameters": report.get("parameters", []),
        },
    }


@router.post("/api/embedded-report/{token}/execute")
async def execute_embedded_report(token: str, req: EmbedExecuteRequest):
    """PUBLIC — execute a report via embed token (no auth required)."""
    db = _require_db()
    t = _validate_token(db, token)
    report_id = t["report_id"]

    try:
        from api.reports_api import _execute_report_sync
    except ImportError:
        raise HTTPException(503, "Report execution not available")

    param_values = req.param_values or {}
    limit = min(req.limit or 1000, 5000)

    try:
        df = await _run_in_executor(
            _execute_report_sync, report_id, param_values, f"embed:{token[:8]}", limit
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.exception("Embedded report execution failed: %s", e)
        raise HTTPException(500, "Report execution failed")

    columns = list(df.columns)
    rows = df.head(limit).values.tolist()
    # Convert non-serialisable types
    safe_rows = []
    for row in rows:
        safe_rows.append([
            v if isinstance(v, (str, int, float, bool, type(None))) else str(v)
            for v in row
        ])

    return {"columns": columns, "rows": safe_rows, "total_rows": len(df)}
