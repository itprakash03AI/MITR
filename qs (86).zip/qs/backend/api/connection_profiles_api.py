"""
Connection Profiles API (Phase 24B)

Endpoints:
  GET    /api/connection-profiles                — list all profiles
  POST   /api/connection-profiles                — create profile (admin)
  GET    /api/connection-profiles/active         — active profile + its mappings
  PUT    /api/connection-profiles/{id}           — update name/description (admin)
  DELETE /api/connection-profiles/{id}           — delete profile + mappings (admin)
  POST   /api/connection-profiles/{id}/activate  — activate (deactivates all others) (admin)
  POST   /api/connection-profiles/deactivate     — clear active profile (admin)
  GET    /api/connection-profiles/{id}/mappings  — list mappings for a profile
  PUT    /api/connection-profiles/{id}/mappings  — replace all mappings atomically (admin)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None


def set_profile_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Connection profiles API not initialised")
    return _db_manager


def _get_user(request: Request) -> Optional[dict]:
    """Resolve the current user including role — same pattern as reports_api."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        try:
            from main import _get_session
            return _get_session(auth_header[7:])
        except Exception:
            return None
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        return authenticate_user(username, password)
    except Exception:
        return None


def _require_admin(request: Request) -> dict:
    """Raise 403 if auth is enabled and the user is not admin."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    if not user or user.get("role") != "admin":
        raise HTTPException(403, "Requires admin role")
    return user


# ── Pydantic models ────────────────────────────────────────────────────────────

class CreateProfileRequest(BaseModel):
    name:        str
    description: Optional[str] = None


class UpdateProfileRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None


class ProfileMappingItem(BaseModel):
    source_connection_id: int
    target_connection_id: int
    description:          Optional[str] = None


class SetMappingsRequest(BaseModel):
    mappings: List[ProfileMappingItem] = []


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/api/connection-profiles")
async def list_connection_profiles():
    """List all connection profiles."""
    db = _require_db()
    return {"profiles": db.list_connection_profiles()}


@router.get("/api/connection-profiles/active")
async def get_active_profile():
    """Return the currently active profile and its mappings, or null."""
    db = _require_db()
    profile = db.get_active_profile()
    if not profile:
        return {"profile": None, "mappings": []}
    mappings = db.get_profile_mappings(profile["id"])
    return {"profile": profile, "mappings": mappings}


@router.post("/api/connection-profiles")
async def create_connection_profile(req: CreateProfileRequest, request: Request):
    """Create a new connection profile (admin only)."""
    _require_admin(request)
    db = _require_db()
    user = _get_user(request)
    profile = db.create_connection_profile(
        name=req.name,
        description=req.description,
        is_active=False,
        created_by=user.get("username"),
    )
    return profile


@router.put("/api/connection-profiles/{profile_id}")
async def update_connection_profile(profile_id: int, req: UpdateProfileRequest, request: Request):
    """Update a profile's name or description (admin only)."""
    _require_admin(request)
    db = _require_db()
    updates = req.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(400, "No fields to update")
    result = db.update_connection_profile(profile_id, **updates)
    if not result:
        raise HTTPException(404, f"Profile {profile_id} not found")
    return result


@router.delete("/api/connection-profiles/{profile_id}")
async def delete_connection_profile(profile_id: int, request: Request):
    """Delete a profile and all its mappings (admin only)."""
    _require_admin(request)
    db = _require_db()
    ok = db.delete_connection_profile(profile_id)
    if not ok:
        raise HTTPException(404, f"Profile {profile_id} not found")
    return {"deleted": True}


@router.post("/api/connection-profiles/{profile_id}/activate")
async def activate_connection_profile(profile_id: int, request: Request):
    """Activate this profile (deactivates all others). Admin only."""
    _require_admin(request)
    db = _require_db()
    ok = db.activate_connection_profile(profile_id)
    if not ok:
        raise HTTPException(404, f"Profile {profile_id} not found")
    profile = db.get_active_profile()
    return {"activated": True, "profile": profile}


@router.post("/api/connection-profiles/deactivate")
async def deactivate_all_profiles(request: Request):
    """Clear the active profile (no-profile mode). Admin only."""
    _require_admin(request)
    db = _require_db()
    db.deactivate_all_profiles()
    return {"deactivated": True}


@router.get("/api/connection-profiles/{profile_id}/mappings")
async def get_profile_mappings(profile_id: int):
    """List all connection mappings for a profile."""
    db = _require_db()
    return {"mappings": db.get_profile_mappings(profile_id)}


@router.put("/api/connection-profiles/{profile_id}/mappings")
async def set_profile_mappings(profile_id: int, req: SetMappingsRequest, request: Request):
    """Replace all mappings for a profile atomically (admin only)."""
    _require_admin(request)
    db = _require_db()
    mappings = [m.model_dump() for m in req.mappings]
    result = db.set_profile_mappings(profile_id, mappings)
    return {"mappings": result}
