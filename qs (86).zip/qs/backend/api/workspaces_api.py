"""
Workspaces API (Phase 25)

Endpoints:
  GET    /api/workspaces                           — list workspaces user belongs to
  POST   /api/workspaces                           — create workspace (admin)
  GET    /api/workspaces/{id}                      — get workspace details + members
  PUT    /api/workspaces/{id}                      — update name/description
  DELETE /api/workspaces/{id}                      — soft delete (admin)
  GET    /api/workspaces/{id}/members              — list members
  POST   /api/workspaces/{id}/members              — add member
  PUT    /api/workspaces/{id}/members/{username}   — update member role
  DELETE /api/workspaces/{id}/members/{username}   — remove member
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None


def set_workspace_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Workspaces API not initialised")
    return _db_manager


def _get_user(request: Request) -> Optional[Dict[str, Any]]:
    """Resolve the current user including role — same pattern as reports_api."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        try:
            from main import _get_session
            return _get_session(auth_header[7:])
        except Exception:
            return None
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        return authenticate_user(username, password)
    except Exception:
        return None


def _require_admin(request: Request) -> Dict[str, Any]:
    """Raise 403 if auth is enabled and the user is not admin."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    if not user or user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def _slugify(name: str) -> str:
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    slug = slug.strip("-")
    return slug[:100] or "workspace"


# ── Pydantic models ──────────────────────────────────────────────────────────

class CreateWorkspaceRequest(BaseModel):
    name:        str
    description: Optional[str] = None
    slug:        Optional[str] = None


class UpdateWorkspaceRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None


class AddMemberRequest(BaseModel):
    username: str
    role:     str = "member"   # owner / admin / member


class UpdateMemberRoleRequest(BaseModel):
    role: str


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.get("/api/workspaces")
def list_workspaces(request: Request):
    db = _require_db()
    user = _get_user(request)
    username = user["username"] if user else None
    # Admin sees all workspaces; others see their own
    if user and user.get("role") == "admin":
        workspaces = db.list_workspaces(username=None)
    else:
        workspaces = db.list_workspaces(username=username)
    # Enrich with member count
    result = []
    for ws in workspaces:
        members = db.list_workspace_members(ws["id"])
        ws["member_count"] = len(members)
        result.append(ws)
    return {"workspaces": result}


@router.post("/api/workspaces", status_code=201)
def create_workspace(request: Request, body: CreateWorkspaceRequest):
    _require_admin(request)
    db = _require_db()
    user = _get_user(request)
    slug = body.slug or _slugify(body.name)
    try:
        ws = db.create_workspace(
            name=body.name,
            slug=slug,
            description=body.description,
            created_by=user["username"] if user else None,
        )
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            raise HTTPException(status_code=409,
                                detail="Workspace name or slug already exists")
        raise HTTPException(status_code=400, detail=str(exc))
    return ws


@router.get("/api/workspaces/{workspace_id}")
def get_workspace(workspace_id: int, request: Request):
    db = _require_db()
    ws = db.get_workspace(workspace_id)
    if not ws:
        raise HTTPException(status_code=404, detail="Workspace not found")
    ws["members"] = db.list_workspace_members(workspace_id)
    return ws


@router.put("/api/workspaces/{workspace_id}")
def update_workspace(workspace_id: int, request: Request,
                     body: UpdateWorkspaceRequest):
    db = _require_db()
    kwargs = {k: v for k, v in body.model_dump().items() if v is not None}
    ws = db.update_workspace(workspace_id, **kwargs)
    if not ws:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return ws


@router.delete("/api/workspaces/{workspace_id}", status_code=204)
def delete_workspace(workspace_id: int, request: Request):
    _require_admin(request)
    db = _require_db()
    ok = db.delete_workspace(workspace_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Workspace not found")


@router.get("/api/workspaces/{workspace_id}/members")
def list_workspace_members(workspace_id: int, request: Request):
    db = _require_db()
    if not db.get_workspace(workspace_id):
        raise HTTPException(status_code=404, detail="Workspace not found")
    return {"members": db.list_workspace_members(workspace_id)}


@router.post("/api/workspaces/{workspace_id}/members", status_code=201)
def add_workspace_member(workspace_id: int, request: Request,
                         body: AddMemberRequest):
    db = _require_db()
    user = _get_user(request)
    if not db.get_workspace(workspace_id):
        raise HTTPException(status_code=404, detail="Workspace not found")
    member = db.add_workspace_member(
        workspace_id=workspace_id,
        username=body.username,
        role=body.role,
        added_by=user["username"] if user else None,
    )
    return member


@router.put("/api/workspaces/{workspace_id}/members/{username}")
def update_workspace_member_role(workspace_id: int, username: str,
                                 request: Request,
                                 body: UpdateMemberRoleRequest):
    db = _require_db()
    ok = db.update_workspace_member_role(workspace_id, username, body.role)
    if not ok:
        raise HTTPException(status_code=404, detail="Member not found")
    return {"workspace_id": workspace_id, "username": username, "role": body.role}


@router.delete("/api/workspaces/{workspace_id}/members/{username}",
               status_code=204)
def remove_workspace_member(workspace_id: int, username: str,
                            request: Request):
    db = _require_db()
    ok = db.remove_workspace_member(workspace_id, username)
    if not ok:
        raise HTTPException(status_code=404, detail="Member not found")
