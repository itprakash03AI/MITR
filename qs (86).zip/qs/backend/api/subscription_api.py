"""
Subscription API — Phase 60 (Delivery & Alerts)

CRUD + lifecycle endpoints for report delivery subscriptions.
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin
from core import config
from core.delivery_engine import compute_next_send, deliver_subscription

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Injected dependencies ─────────────────────────────────────────────────────

_db_manager = None


def set_subscription_dependencies(db_manager):
    global _db_manager
    _db_manager = db_manager
    logger.info("SubscriptionAPI dependencies injected")


# ── Pydantic models ───────────────────────────────────────────────────────────

class SubscriptionCreate(BaseModel):
    report_id: int
    report_type: str = "business_report"
    name: str = Field(..., min_length=1, max_length=255)
    recipient_emails: List[str] = Field(..., min_length=1)
    frequency: str = Field(..., min_length=1)          # cron expression
    timezone: str = "UTC"
    output_format: str = "pdf"                          # pdf | excel | csv
    param_values: Optional[dict] = None


class SubscriptionUpdate(BaseModel):
    name: Optional[str] = None
    recipient_emails: Optional[List[str]] = None
    frequency: Optional[str] = None
    timezone: Optional[str] = None
    output_format: Optional[str] = None
    param_values: Optional[dict] = None
    is_active: Optional[bool] = None


# ── CRUD endpoints ────────────────────────────────────────────────────────────

@router.post("/api/subscriptions")
async def create_subscription(body: SubscriptionCreate, user=get_current_user):
    cfg = config.delivery
    if not cfg.enabled:
        raise HTTPException(status_code=403, detail="Delivery feature is disabled")

    username = user.get("username", "anonymous")

    # Validate limits
    existing = _db_manager.list_subscriptions(created_by=username)
    if len(existing) >= cfg.max_subscriptions_per_user:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_subscriptions_per_user} subscriptions per user")
    if len(body.recipient_emails) > cfg.max_recipients_per_subscription:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_recipients_per_subscription} recipients per subscription")
    if body.output_format not in ("pdf", "excel", "csv"):
        raise HTTPException(status_code=400, detail="Invalid output_format (pdf|excel|csv)")

    # Compute first send time
    next_send = compute_next_send(body.frequency, body.timezone)
    if not next_send:
        raise HTTPException(status_code=400, detail="Invalid cron expression or timezone")

    token = secrets.token_urlsafe(32)

    sub = _db_manager.create_subscription(
        report_id=body.report_id,
        report_type=body.report_type,
        name=body.name,
        created_by=username,
        recipient_emails=body.recipient_emails,
        frequency=body.frequency,
        timezone=body.timezone,
        output_format=body.output_format,
        param_values=body.param_values,
        is_active=True,
        next_send_at=next_send,
        unsubscribe_token=token,
    )
    return sub


@router.get("/api/subscriptions")
async def list_subscriptions(report_id: Optional[int] = None,
                             report_type: Optional[str] = None,
                             user=get_current_user):
    username = user.get("username", "anonymous")
    role = user.get("role", "viewer")
    # Admins see all; others see own
    created_by = None if role == "admin" else username
    return _db_manager.list_subscriptions(
        created_by=created_by, report_id=report_id, report_type=report_type,
    )


@router.get("/api/subscriptions/{sub_id}")
async def get_subscription(sub_id: int, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    return sub


@router.put("/api/subscriptions/{sub_id}")
async def update_subscription(sub_id: int, body: SubscriptionUpdate, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)

    cfg = config.delivery
    updates = {k: v for k, v in body.model_dump().items() if v is not None}

    if "recipient_emails" in updates and len(updates["recipient_emails"]) > cfg.max_recipients_per_subscription:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_recipients_per_subscription} recipients")

    if "output_format" in updates and updates["output_format"] not in ("pdf", "excel", "csv"):
        raise HTTPException(status_code=400, detail="Invalid output_format")

    # Recompute next_send if frequency or timezone changed
    freq = updates.get("frequency", sub["frequency"])
    tz = updates.get("timezone", sub.get("timezone", "UTC"))
    if "frequency" in updates or "timezone" in updates:
        next_send = compute_next_send(freq, tz)
        if not next_send:
            raise HTTPException(status_code=400, detail="Invalid cron expression or timezone")
        updates["next_send_at"] = next_send

    result = _db_manager.update_subscription(sub_id, **updates)
    return result


@router.delete("/api/subscriptions/{sub_id}")
async def delete_subscription(sub_id: int, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    _db_manager.delete_subscription(sub_id)
    return {"detail": "Subscription deleted"}


# ── Lifecycle endpoints ───────────────────────────────────────────────────────

@router.post("/api/subscriptions/{sub_id}/test-send")
async def test_send(sub_id: int, user=get_current_user):
    """Execute the subscription immediately (test delivery)."""
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)

    try:
        result = deliver_subscription(sub_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Delivery failed: {exc}")

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/api/subscriptions/{sub_id}/pause")
async def pause_subscription(sub_id: int, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    _db_manager.update_subscription(sub_id, is_active=False)
    return {"detail": "Subscription paused"}


@router.post("/api/subscriptions/{sub_id}/resume")
async def resume_subscription(sub_id: int, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    next_send = compute_next_send(sub["frequency"], sub.get("timezone", "UTC"))
    _db_manager.update_subscription(sub_id, is_active=True, next_send_at=next_send)
    return {"detail": "Subscription resumed", "next_send_at": next_send.isoformat() if next_send else None}


@router.get("/api/subscriptions/{sub_id}/history")
async def subscription_history(sub_id: int, limit: int = 50, user=get_current_user):
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    return _db_manager.list_subscription_deliveries(sub_id, limit=limit)


# ── One-click unsubscribe (no auth required) ─────────────────────────────────

@router.get("/api/unsubscribe/{token}")
async def unsubscribe(token: str):
    sub = _db_manager.get_subscription_by_unsubscribe_token(token)
    if not sub:
        raise HTTPException(status_code=404, detail="Invalid or expired unsubscribe link")
    _db_manager.update_subscription(sub["id"], is_active=False)
    return {"detail": f"Successfully unsubscribed from '{sub['name']}'"}


# ── Admin: delivery config ────────────────────────────────────────────────────

@router.get("/api/admin/delivery/config")
async def get_delivery_config(user=require_admin):
    return config.get_section("delivery")


@router.put("/api/admin/delivery/config")
async def update_delivery_config(body: dict, user=require_admin):
    current = config.get_section("delivery")
    for k, v in body.items():
        if k in current:
            config.set("delivery", k, v)
    return config.get_section("delivery")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _check_ownership(sub: dict, user: dict):
    """Ensure user owns the subscription or is admin."""
    role = user.get("role", "viewer")
    username = user.get("username", "")
    if role != "admin" and sub.get("created_by") != username:
        raise HTTPException(status_code=403, detail="Not authorised to access this subscription")
