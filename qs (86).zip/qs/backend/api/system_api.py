"""
System health, metrics, version, and observability endpoints.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_system_dependencies(db_manager, engine, paths, qe_cfg)`` once at startup.
"""
from __future__ import annotations

import logging
import platform
from datetime import datetime, timezone

from fastapi import APIRouter

from core.execution_state import get_queue_count, running_tasks

logger = logging.getLogger(__name__)

router = APIRouter(tags=["System"])

# ── Module-level singletons ───────────────────────────────────────────────────
_db_manager = None   # DatabaseManager
_engine     = None   # ParquetQueryEngine
_paths      = None   # core.config.paths
_qe_cfg     = None   # core.config.query_engine

# Prometheus counters — injected from main.py so all routers share the same registry
_prom_pool_active = None
_prom_pool_queued = None

API_VERSION = "2.0.0"
API_MAJOR   = "v2"


def set_system_dependencies(db_manager, engine, paths, qe_cfg,
                             prom_pool_active=None, prom_pool_queued=None) -> None:
    """Called once from main.py after components are created."""
    global _db_manager, _engine, _paths, _qe_cfg
    global _prom_pool_active, _prom_pool_queued
    _db_manager        = db_manager
    _engine            = engine
    _paths             = paths
    _qe_cfg            = qe_cfg
    _prom_pool_active  = prom_pool_active
    _prom_pool_queued  = prom_pool_queued


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/version", tags=["System"])
async def api_version():
    """Return API version information. Useful for clients to detect server capabilities."""
    return {
        "version": API_VERSION,
        "api_version": API_MAJOR,
        "name": "QueryStudio",
        "python": platform.python_version(),
    }


@router.get("/metrics", include_in_schema=False)
async def prometheus_metrics():
    """Prometheus scrape endpoint — no auth required (standard practice)."""
    from starlette.responses import Response as _StarletteResponse
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

    # Update worker pool gauges before scrape
    try:
        from core.worker_pool import get_pool
        pool = get_pool()
        if pool and _prom_pool_active and _prom_pool_queued:
            stats = pool.get_stats()
            for wtype, info in stats.get("by_type", {}).items():
                _prom_pool_active.labels(work_type=wtype).set(info.get("running", 0))
                _prom_pool_queued.labels(work_type=wtype).set(info.get("queued", 0))
    except Exception:
        pass  # metrics must never crash
    return _StarletteResponse(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@router.get("/health")
async def health_check():
    """Health check — DB connectivity, disk space, active queries."""
    import shutil as _shutil
    from core.config import query_engine as _qe

    # Database ping
    db_ok = False
    try:
        if _db_manager:
            _db_manager.get_execution("__health_probe__")   # returns None, never raises
            db_ok = True
    except Exception as exc:
        logger.warning("Health DB check failed: %s", exc)

    # Disk usage for data directory
    disk_free_gb = disk_used_pct = -1
    disk_warn = False
    if _paths:
        try:
            _du = _shutil.disk_usage(str(_paths.data_dir))
            disk_free_gb  = round(_du.free  / (1024 ** 3), 2)
            disk_used_pct = round(_du.used  / _du.total * 100, 1)
            disk_warn     = disk_free_gb < 5.0
        except Exception:
            pass

    # S3 connectivity (non-blocking, best-effort)
    s3_status = "not_configured"
    if _engine and _engine.s3_handler:
        try:
            s3_status = "connected" if _engine.s3_handler.test_connection().get("connected") else "error"
        except Exception:
            s3_status = "error"

    # Pool-aware query stats
    qe = _qe_cfg or _qe
    try:
        from core.worker_pool import get_pool
        _pool_stats = get_pool().get_stats()
        active_queries = _pool_stats.get("active_total", 0)
        queue_waiting  = _pool_stats.get("queued_total", 0)
    except RuntimeError:
        active_queries = len([t for t in running_tasks.values() if not t.done()])
        queue_waiting  = get_queue_count()

    overall = "healthy" if db_ok and not disk_warn else "degraded"

    return {
        "status":    overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database":  {"ok": db_ok},
        "disk":      {"free_gb": disk_free_gb, "used_pct": disk_used_pct, "warning": disk_warn},
        "queries":   {
            "active":               active_queries,
            "max_workers":          qe.max_workers,
            "per_user_limit":       qe.max_concurrent_per_user,
            "max_concurrent_global": qe.max_concurrent_global,
            "queue_waiting":        queue_waiting,
            "max_queue_size":       qe.max_queue_size,
        },
        "s3":        {"status": s3_status},
    }
