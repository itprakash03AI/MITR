"""
Enterprise Reports API (Phases 23B, 23C, 23F, 23G, 23H)

23B — Report Bookmarks (saved parameter sets)
23C — Conditional Formatting rules
23F — Threshold Alert rules + evaluation
23G — Row-Level Security policies
23H — Cloud Delivery config + delivery history
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as QParam, Request
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None
_email_svc  = None


def set_enterprise_dependencies(db_manager, auth_cfg, email_service=None):
    global _db_manager, _auth_cfg, _email_svc
    _db_manager = db_manager
    _auth_cfg   = auth_cfg
    _email_svc  = email_service


def _get_user(request: Request) -> dict:
    import base64
    auth_header = request.headers.get("authorization", "")
    if auth_header.startswith("Basic "):
        try:
            decoded = base64.b64decode(auth_header[6:]).decode()
            parts = decoded.split(":", 1)
            return {"username": parts[0], "role": "analyst"}
        except Exception:
            pass
    return {"username": "anonymous", "role": "viewer"}


def _require_admin(request: Request) -> dict:
    user = _get_user(request)
    if _auth_cfg and getattr(_auth_cfg, "enabled", False):
        if user.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Admin required")
    return user


# ═══════════════════════════════════════════════════════════════════════════════
# 23G — Row-Level Security
# ═══════════════════════════════════════════════════════════════════════════════

class RLSPolicyCreate(BaseModel):
    column_name:    str
    operator:       str = Field(default="=", pattern="^(=|!=|IN|NOT IN|LIKE|>|<|>=|<=)$")
    value_template: str
    description:    Optional[str] = None


class RLSPolicyUpdate(BaseModel):
    column_name:    Optional[str] = None
    operator:       Optional[str] = None
    value_template: Optional[str] = None
    description:    Optional[str] = None
    is_enabled:     Optional[bool] = None


@router.get("/api/reports/{report_id}/rls")
async def list_rls_policies(report_id: int, _user: dict = Depends(_require_admin)):
    return {"policies": _db_manager.list_rls_policies(report_id)}


@router.post("/api/reports/{report_id}/rls", status_code=201)
async def create_rls_policy(report_id: int, body: RLSPolicyCreate,
                             _user: dict = Depends(_require_admin)):
    policy = _db_manager.create_rls_policy(
        report_id=report_id, column_name=body.column_name,
        operator=body.operator, value_template=body.value_template,
        description=body.description, created_by=_user["username"],
    )
    return policy


@router.put("/api/reports/rls/{policy_id}")
async def update_rls_policy(policy_id: int, body: RLSPolicyUpdate,
                             _user: dict = Depends(_require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _db_manager.update_rls_policy(policy_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="RLS policy not found")
    return result


@router.delete("/api/reports/rls/{policy_id}")
async def delete_rls_policy(policy_id: int, _user: dict = Depends(_require_admin)):
    ok = _db_manager.delete_rls_policy(policy_id)
    if not ok:
        raise HTTPException(status_code=404, detail="RLS policy not found")
    return {"deleted": True, "policy_id": policy_id}


@router.post("/api/reports/{report_id}/rls/preview")
async def preview_rls(report_id: int, request: Request):
    """Preview what WHERE clauses would be injected for the current user."""
    user = _get_user(request)
    # Build user attribute dict from auth info
    user_attrs = {"username": user["username"], "role": user.get("role", "")}
    clauses = _db_manager.build_rls_where_clauses(report_id, user_attrs)
    return {"report_id": report_id, "username": user["username"],
            "where_clauses": clauses}


# ═══════════════════════════════════════════════════════════════════════════════
# 23B — Report Bookmarks
# ═══════════════════════════════════════════════════════════════════════════════

class BookmarkCreate(BaseModel):
    name:         str
    param_values: Dict[str, Any] = {}


@router.get("/api/reports/{report_id}/bookmarks")
async def list_bookmarks(report_id: int, request: Request):
    user = _get_user(request)
    return {"bookmarks": _db_manager.list_bookmarks(report_id, user["username"])}


@router.post("/api/reports/{report_id}/bookmarks", status_code=201)
async def save_bookmark(report_id: int, body: BookmarkCreate, request: Request):
    user = _get_user(request)
    bm = _db_manager.save_bookmark(
        report_id=report_id, username=user["username"],
        name=body.name, param_values=body.param_values,
    )
    return bm


@router.delete("/api/reports/bookmarks/{bookmark_id}")
async def delete_bookmark(bookmark_id: int, request: Request):
    user = _get_user(request)
    ok = _db_manager.delete_bookmark(bookmark_id, user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="Bookmark not found")
    return {"deleted": True, "bookmark_id": bookmark_id}


# ═══════════════════════════════════════════════════════════════════════════════
# 23C — Conditional Formatting
# ═══════════════════════════════════════════════════════════════════════════════

class ConditionalFormatRuleIn(BaseModel):
    column_name:     str
    rule_order:      int = 0
    condition_type:  str  # value_range | equals | contains | not_null | is_null | top_n | bottom_n
    condition_value: Optional[Any] = None
    bg_color:        Optional[str] = None
    text_color:      Optional[str] = None
    icon:            str = "none"
    bold:            bool = False
    is_enabled:      bool = True


class ConditionalFormatsRequest(BaseModel):
    rules: List[ConditionalFormatRuleIn]


@router.get("/api/reports/{report_id}/formatting")
async def get_formatting(report_id: int):
    return {"rules": _db_manager.get_conditional_formats(report_id)}


@router.put("/api/reports/{report_id}/formatting")
async def save_formatting(report_id: int, body: ConditionalFormatsRequest):
    _db_manager.save_conditional_formats(
        report_id, [r.model_dump() for r in body.rules]
    )
    return {"report_id": report_id, "count": len(body.rules)}


# ═══════════════════════════════════════════════════════════════════════════════
# 23F — Threshold Alert Rules
# ═══════════════════════════════════════════════════════════════════════════════

class AlertRuleCreate(BaseModel):
    name:              str
    column_name:       str
    aggregation:       str = "last"
    operator:          str
    threshold_value:   float
    channels:          List[str] = ["email"]
    recipients:        Optional[str] = None
    slack_webhook:     Optional[str] = None
    cooldown_minutes:  int = 60


class AlertRuleUpdate(BaseModel):
    name:             Optional[str] = None
    column_name:      Optional[str] = None
    aggregation:      Optional[str] = None
    operator:         Optional[str] = None
    threshold_value:  Optional[float] = None
    channels:         Optional[List[str]] = None
    recipients:       Optional[str] = None
    slack_webhook:    Optional[str] = None
    cooldown_minutes: Optional[int] = None
    is_enabled:       Optional[bool] = None


@router.get("/api/reports/{report_id}/alerts")
async def list_alert_rules(report_id: int):
    return {"rules": _db_manager.list_alert_rules(report_id)}


@router.post("/api/reports/{report_id}/alerts", status_code=201)
async def create_alert_rule(report_id: int, body: AlertRuleCreate, request: Request):
    user = _get_user(request)
    rule = _db_manager.create_alert_rule(
        report_id=report_id, name=body.name, column_name=body.column_name,
        operator=body.operator, threshold_value=body.threshold_value,
        aggregation=body.aggregation, channels=body.channels,
        recipients=body.recipients, slack_webhook=body.slack_webhook,
        cooldown_minutes=body.cooldown_minutes, created_by=user["username"],
    )
    return rule


@router.put("/api/reports/alerts/{rule_id}")
async def update_alert_rule(rule_id: int, body: AlertRuleUpdate):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _db_manager.update_alert_rule(rule_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    return result


@router.delete("/api/reports/alerts/{rule_id}")
async def delete_alert_rule(rule_id: int):
    ok = _db_manager.delete_alert_rule(rule_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    return {"deleted": True, "rule_id": rule_id}


@router.get("/api/reports/alerts/{rule_id}/history")
async def get_alert_history(rule_id: int,
                             limit: int = QParam(default=50, ge=1, le=500)):
    return {"history": _db_manager.list_alert_history(rule_id, limit)}


@router.post("/api/reports/{report_id}/alerts/evaluate")
async def evaluate_alerts(report_id: int, request: Request):
    """Manually trigger alert evaluation against latest execution result.
    Normally called automatically after each report execution."""
    body = await request.json()
    rows = body.get("rows", [])
    triggered = _db_manager.evaluate_alert_rules(report_id, rows)

    notifications = []
    for rule in triggered:
        # Fire notifications
        _fire_alert_notifications(rule, rule.get("actual_value"))
        notifications.append({
            "rule_id":   rule["id"],
            "rule_name": rule["name"],
            "actual":    rule.get("actual_value"),
            "threshold": rule["threshold_value"],
        })

    return {"triggered": len(triggered), "notifications": notifications}


def _fire_alert_notifications(rule: dict, actual_value: float) -> None:
    """Send alert notifications via email and/or Slack (best-effort)."""
    import threading

    def _send():
        try:
            report_name = f"Report #{rule['report_id']}"
            msg = (f"Alert '{rule['name']}' triggered on {report_name}.\n"
                   f"Column '{rule['column_name']}': actual={actual_value}, "
                   f"threshold={rule['threshold_value']} ({rule['operator']})")

            channels = rule.get("channels") or []
            if "email" in channels and rule.get("recipients") and _email_svc:
                for addr in rule["recipients"].split(","):
                    addr = addr.strip()
                    if addr:
                        try:
                            _email_svc.send_email(
                                to=addr,
                                subject=f"[QueryStudio Alert] {rule['name']}",
                                body=msg,
                            )
                        except Exception as e:
                            logger.warning("Alert email failed to %s: %s", addr, e)

            if "slack" in channels and rule.get("slack_webhook"):
                import urllib.request as _urlreq
                import json as _json
                payload = {"text": f":warning: *QueryStudio Alert*\n{msg}"}
                req = _urlreq.Request(
                    rule["slack_webhook"],
                    data=_json.dumps(payload).encode(),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with _urlreq.urlopen(req, timeout=10):
                    pass

            # Record in history
            for ch in channels:
                _db_manager.record_alert(
                    rule_id=rule["id"], actual_value=actual_value,
                    threshold_value=rule["threshold_value"],
                    channel=ch, sent_to=rule.get("recipients") or rule.get("slack_webhook") or "",
                )
        except Exception as e:
            logger.error("Alert notification failed for rule %s: %s", rule.get("id"), e)

    threading.Thread(target=_send, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
# 23H — Cloud Delivery
# ═══════════════════════════════════════════════════════════════════════════════

class CloudDeliveryConfigIn(BaseModel):
    provider:         str = Field(pattern="^(s3|azure|gcs)$")
    bucket:           Optional[str] = None
    prefix_template:  Optional[str] = None
    formats:          List[str] = ["pdf"]
    zip_bundle:       bool = False
    connection_id:    Optional[int] = None
    is_enabled:       bool = True


@router.get("/api/schedules/{schedule_id}/cloud-delivery")
async def get_cloud_delivery(schedule_id: int,
                              _user: dict = Depends(_require_admin)):
    cfg = _db_manager.get_cloud_delivery_config(schedule_id)
    if not cfg:
        raise HTTPException(status_code=404, detail="No cloud delivery config found")
    return cfg


@router.put("/api/schedules/{schedule_id}/cloud-delivery")
async def save_cloud_delivery(schedule_id: int, body: CloudDeliveryConfigIn,
                               _user: dict = Depends(_require_admin)):
    cfg = _db_manager.save_cloud_delivery_config(schedule_id, **body.model_dump())
    return cfg


@router.get("/api/schedules/{schedule_id}/delivery-history")
async def get_delivery_history(schedule_id: int,
                                limit: int = QParam(default=100, ge=1, le=1000),
                                _user: dict = Depends(_require_admin)):
    history = _db_manager.list_delivery_history(schedule_id=schedule_id, limit=limit)
    return {"history": history, "count": len(history)}
