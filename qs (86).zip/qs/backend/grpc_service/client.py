"""
Phase 22G — gRPC Client.

Used by the webserver to dispatch query execution tasks to remote executor
workers via gRPC instead of the Redis/DB polling queue.

Usage:
    from grpc_service.client import GrpcExecutorClient

    client = GrpcExecutorClient("executor-host:50051")
    result = client.submit_task(execution_id, query_config, ...)
    client.close()
"""

from __future__ import annotations

import json
import logging
import time
from typing import Optional, Callable

logger = logging.getLogger(__name__)


class GrpcExecutorClient:
    """Thin wrapper around the gRPC ExecutorService stub."""

    def __init__(self, target: str, timeout: float = 300.0):
        """
        Args:
            target: gRPC endpoint, e.g. "executor-svc:50051"
            timeout: default RPC deadline in seconds (5 min for long queries)
        """
        try:
            import grpc
            from grpc_service import querystudio_pb2 as pb2
            from grpc_service import querystudio_pb2_grpc as pb2_grpc
        except ImportError as exc:
            raise RuntimeError(
                "gRPC client requires grpcio + generated stubs. "
                "Run: pip install grpcio && cd backend/grpc_service && "
                "python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. querystudio.proto"
            ) from exc

        self._grpc = grpc
        self._pb2 = pb2
        self._pb2_grpc = pb2_grpc
        self._target = target
        self._timeout = timeout

        self._channel = grpc.insecure_channel(
            target,
            options=[
                ("grpc.max_send_message_length", 100 * 1024 * 1024),    # 100 MB
                ("grpc.max_receive_message_length", 100 * 1024 * 1024),
                ("grpc.keepalive_time_ms", 30000),
                ("grpc.keepalive_timeout_ms", 10000),
                ("grpc.keepalive_permit_without_calls", 1),
            ],
        )
        self._executor_stub = pb2_grpc.ExecutorServiceStub(self._channel)
        self._health_stub = pb2_grpc.HealthServiceStub(self._channel)
        logger.info("gRPC client connected to %s", target)

    def close(self):
        if self._channel:
            self._channel.close()
            logger.info("gRPC channel closed: %s", self._target)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── Health ────────────────────────────────────────────────────────────────

    def health_check(self, service: str = "") -> bool:
        """Return True if the remote service is SERVING."""
        try:
            resp = self._health_stub.Check(
                self._pb2.HealthCheckRequest(service=service),
                timeout=5.0,
            )
            return resp.status == self._pb2.SERVING
        except Exception as exc:
            logger.warning("Health check failed for %s: %s", self._target, exc)
            return False

    # ── Task submission ───────────────────────────────────────────────────────

    def submit_task(
        self,
        execution_id: str,
        query_config: dict,
        connection_type: str = "s3",
        connection_id: int = 0,
        username: str = "",
        row_limit: int = 0,
        output_dir: str = "",
        metadata: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> dict:
        """
        Submit a task and wait for completion.

        Returns:
            dict with keys: execution_id, success, total_rows, file_size_bytes,
                            output_file, error_message, duration_ms
        """
        request = self._pb2.TaskRequest(
            execution_id=execution_id,
            query_config_json=json.dumps(query_config),
            connection_type=connection_type,
            connection_id=connection_id,
            username=username,
            row_limit=row_limit,
            output_dir=output_dir,
            metadata=metadata or {},
        )

        result = self._executor_stub.SubmitTask(
            request, timeout=timeout or self._timeout,
        )

        return {
            "execution_id": result.execution_id,
            "success": result.success,
            "total_rows": result.total_rows,
            "file_size_bytes": result.file_size_bytes,
            "output_file": result.output_file,
            "error_message": result.error_message,
            "duration_ms": result.duration_ms,
        }

    def submit_task_stream(
        self,
        execution_id: str,
        query_config: dict,
        connection_type: str = "s3",
        connection_id: int = 0,
        username: str = "",
        row_limit: int = 0,
        output_dir: str = "",
        on_progress: Optional[Callable] = None,
        timeout: Optional[float] = None,
    ) -> dict:
        """
        Submit a task with streaming progress callbacks.

        Args:
            on_progress: callback(execution_id, rows_processed, progress_pct, message)

        Returns:
            dict — last progress update as a dict
        """
        request = self._pb2.TaskRequest(
            execution_id=execution_id,
            query_config_json=json.dumps(query_config),
            connection_type=connection_type,
            connection_id=connection_id,
            username=username,
            row_limit=row_limit,
            output_dir=output_dir,
        )

        last_update = {}
        for progress in self._executor_stub.SubmitTaskStream(
            request, timeout=timeout or self._timeout,
        ):
            last_update = {
                "execution_id": progress.execution_id,
                "rows_processed": progress.rows_processed,
                "chunks_completed": progress.chunks_completed,
                "progress_pct": progress.progress_pct,
                "message": progress.message,
            }
            if on_progress:
                on_progress(
                    progress.execution_id,
                    progress.rows_processed,
                    progress.progress_pct,
                    progress.message,
                )

        return last_update

    def cancel_task(self, execution_id: str) -> dict:
        """Cancel a running execution on the remote executor."""
        resp = self._executor_stub.CancelTask(
            self._pb2.CancelRequest(execution_id=execution_id),
            timeout=10.0,
        )
        return {"cancelled": resp.cancelled, "message": resp.message}

    def get_worker_status(self) -> dict:
        """Get remote executor worker status."""
        resp = self._executor_stub.GetStatus(
            self._pb2.WorkerStatusRequest(),
            timeout=10.0,
        )
        return {
            "worker_id": resp.worker_id,
            "active_tasks": resp.active_tasks,
            "max_tasks": resp.max_tasks,
            "uptime_seconds": resp.uptime_seconds,
            "cpu_usage_pct": resp.cpu_usage_pct,
            "memory_used_bytes": resp.memory_used_bytes,
        }
