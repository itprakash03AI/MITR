"""
Phase 22G — gRPC inter-service communication.

Provides protobuf-based communication between webserver ↔ executor workers.
Replaces polling-based task distribution with bidirectional streaming gRPC
when ``queue.backend = "grpc"`` (optional — Redis and DB backends still work).

Structure:
    grpc_service/
        __init__.py          ← this file
        querystudio.proto    ← protobuf IDL
        server.py            ← gRPC servicer implementation
        client.py            ← gRPC client (used by webserver to talk to executors)
        querystudio_pb2.py   ← generated (run: python -m grpc_tools.protoc ...)
        querystudio_pb2_grpc.py ← generated

Generate stubs:
    cd backend/grpc_service
    python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. querystudio.proto
"""
