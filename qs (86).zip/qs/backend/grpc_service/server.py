"""
Phase 22G — gRPC Server Implementation.

Implements ExecutorService and HealthService servicers.
Run standalone:  python -m grpc_service.server --port 50051
Or embed in executor_worker.py alongside the REST health endpoint.
"""

from __future__ import annotations

import logging
import os
import time
import json
import uuid
import asyncio
from concurrent import futures
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Lazy gRPC imports (fail gracefully if not installed) ─────────────────────

_grpc = None
_pb2 = None
_pb2_grpc = None


def _ensure_grpc():
    global _grpc, _pb2, _pb2_grpc
    if _grpc is not None:
        return True
    try:
        import grpc as _g
        _grpc = _g
    except ImportError:
        logger.error("grpcio not installed — run: pip install grpcio grpcio-tools")
        return False
    try:
        from grpc_service import querystudio_pb2 as _p2
        from grpc_service import querystudio_pb2_grpc as _p2g
        _pb2 = _p2
        _pb2_grpc = _p2g
    except ImportError:
        logger.error(
            "gRPC stubs not generated — run:\n"
            "  cd backend/grpc_service && "
            "python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. querystudio.proto"
        )
        return False
    return True


# ══════════════════════════════════════════════════════════════════════════════
# HealthService Servicer
# ══════════════════════════════════════════════════════════════════════════════

class HealthServicer:
    """Standard gRPC health check (compatible with K8s grpc-health-probe)."""

    def __init__(self):
        self._status = {}  # service_name → ServingStatus
        self._start_time = time.time()

    def set_status(self, service: str, serving: bool):
        self._status[service] = serving

    def Check(self, request, context):
        svc = request.service or ""
        is_serving = self._status.get(svc, True)
        return _pb2.HealthCheckResponse(
            status=_pb2.SERVING if is_serving else _pb2.NOT_SERVING,
        )

    def Watch(self, request, context):
        svc = request.service or ""
        while context.is_active():
            is_serving = self._status.get(svc, True)
            yield _pb2.HealthCheckResponse(
                status=_pb2.SERVING if is_serving else _pb2.NOT_SERVING,
            )
            time.sleep(5)


# ══════════════════════════════════════════════════════════════════════════════
# ExecutorService Servicer
# ══════════════════════════════════════════════════════════════════════════════

class ExecutorServicer:
    """Handles task submission from webserver → executor."""

    def __init__(self, db_manager=None, execute_fn=None, max_concurrent: int = 4):
        self._db_manager = db_manager
        self._execute_fn = execute_fn  # callable(execution_id, query_config, connection_id, ...)
        self._max_concurrent = max_concurrent
        self._active_tasks: dict[str, dict] = {}
        self._start_time = time.time()
        self._worker_id = os.environ.get(
            "QUERYSTUDIO_WORKER_ID",
            f"executor-{uuid.uuid4().hex[:8]}",
        )

    def SubmitTask(self, request, context):
        """Execute a task synchronously and return the result."""
        eid = request.execution_id
        logger.info("gRPC SubmitTask: %s", eid)

        if len(self._active_tasks) >= self._max_concurrent:
            context.set_code(_grpc.StatusCode.RESOURCE_EXHAUSTED)
            context.set_details(f"Executor at capacity ({self._max_concurrent} tasks)")
            return _pb2.TaskResult(
                execution_id=eid, success=False,
                error_message="Executor at capacity",
            )

        self._active_tasks[eid] = {"started": time.time()}
        start = time.time()

        try:
            query_config = json.loads(request.query_config_json)
            if self._execute_fn:
                result = self._execute_fn(
                    execution_id=eid,
                    query_config=query_config,
                    connection_id=request.connection_id,
                    username=request.username,
                    row_limit=request.row_limit,
                    output_dir=request.output_dir,
                )
            else:
                result = self._execute_fallback(eid, query_config, request)

            duration_ms = int((time.time() - start) * 1000)
            return _pb2.TaskResult(
                execution_id=eid,
                success=True,
                total_rows=result.get("total_rows", 0),
                file_size_bytes=result.get("file_size_bytes", 0),
                output_file=result.get("output_file", ""),
                duration_ms=duration_ms,
            )
        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000)
            logger.exception("gRPC task %s failed", eid)
            return _pb2.TaskResult(
                execution_id=eid, success=False,
                error_message=str(exc), duration_ms=duration_ms,
            )
        finally:
            self._active_tasks.pop(eid, None)

    def SubmitTaskStream(self, request, context):
        """Execute with streaming progress updates."""
        eid = request.execution_id
        self._active_tasks[eid] = {"started": time.time()}
        try:
            # Emit initial progress
            yield _pb2.TaskProgress(
                execution_id=eid, rows_processed=0,
                chunks_completed=0, progress_pct=0.0,
                message="Task accepted",
            )

            query_config = json.loads(request.query_config_json)

            if self._execute_fn:
                result = self._execute_fn(
                    execution_id=eid,
                    query_config=query_config,
                    connection_id=request.connection_id,
                    username=request.username,
                    row_limit=request.row_limit,
                    output_dir=request.output_dir,
                )
            else:
                result = self._execute_fallback(eid, query_config, request)

            yield _pb2.TaskProgress(
                execution_id=eid,
                rows_processed=result.get("total_rows", 0),
                chunks_completed=result.get("chunks", 1),
                progress_pct=100.0,
                message="Completed",
            )
        except Exception as exc:
            yield _pb2.TaskProgress(
                execution_id=eid, rows_processed=0,
                progress_pct=0.0, message=f"Failed: {exc}",
            )
        finally:
            self._active_tasks.pop(eid, None)

    def CancelTask(self, request, context):
        eid = request.execution_id
        if eid in self._active_tasks:
            # Signal cancellation via the shared cancellation_flags dict
            try:
                from core.execution_state import cancellation_flags
                cancellation_flags[eid] = True
            except ImportError:
                pass
            return _pb2.CancelResponse(cancelled=True, message="Cancellation signalled")
        return _pb2.CancelResponse(cancelled=False, message="Execution not found on this worker")

    def GetStatus(self, request, context):
        import psutil
        proc = psutil.Process() if _has_psutil() else None
        return _pb2.WorkerStatus(
            worker_id=self._worker_id,
            active_tasks=len(self._active_tasks),
            max_tasks=self._max_concurrent,
            uptime_seconds=int(time.time() - self._start_time),
            cpu_usage_pct=proc.cpu_percent() if proc else 0.0,
            memory_used_bytes=proc.memory_info().rss if proc else 0,
        )

    def _execute_fallback(self, eid, query_config, request):
        """Fallback when no execute_fn is provided — uses DuckDB directly."""
        logger.warning("gRPC executor: no execute_fn provided — using stub result for %s", eid)
        return {"total_rows": 0, "file_size_bytes": 0, "output_file": ""}


def _has_psutil():
    try:
        import psutil
        return True
    except ImportError:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Server bootstrap
# ══════════════════════════════════════════════════════════════════════════════

def create_server(
    port: int = 50051,
    db_manager=None,
    execute_fn=None,
    max_workers: int = 10,
    max_concurrent_tasks: int = 4,
):
    """Create and return a gRPC server (not yet started)."""
    if not _ensure_grpc():
        raise RuntimeError("gRPC dependencies not available")

    server = _grpc.server(futures.ThreadPoolExecutor(max_workers=max_workers))

    # Register services
    health = HealthServicer()
    health.set_status("", True)
    health.set_status("querystudio.ExecutorService", True)
    _pb2_grpc.add_HealthServiceServicer_to_server(health, server)

    executor = ExecutorServicer(
        db_manager=db_manager,
        execute_fn=execute_fn,
        max_concurrent=max_concurrent_tasks,
    )
    _pb2_grpc.add_ExecutorServiceServicer_to_server(executor, server)

    server.add_insecure_port(f"[::]:{port}")
    logger.info("gRPC server configured on port %d (max_workers=%d)", port, max_workers)
    return server, health, executor


def serve(port: int = 50051, **kwargs):
    """Blocking entry point — start gRPC server and wait for termination."""
    server, health, executor = create_server(port=port, **kwargs)
    server.start()
    logger.info("gRPC server started on port %d", port)
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        logger.info("gRPC server shutting down…")
        server.stop(grace=5)


# ── CLI entry point ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="QueryStudio gRPC Executor Server")
    parser.add_argument("--port", type=int, default=50051, help="gRPC listen port")
    parser.add_argument("--max-workers", type=int, default=10, help="Thread pool size")
    parser.add_argument("--max-tasks", type=int, default=4, help="Max concurrent executions")
    args = parser.parse_args()
    serve(port=args.port, max_workers=args.max_workers, max_concurrent_tasks=args.max_tasks)
