"""
QueryStudio CLI — Airflow-style unified entry point.

Usage:
    python -m querystudio standalone        Run webserver + scheduler in one process
    python -m querystudio webserver         Run HTTP/WebSocket server only
    python -m querystudio scheduler         Run scheduler worker only
    python -m querystudio executor          Run executor worker only
    python -m querystudio db init           Initialize database and directories
    python -m querystudio db migrate        Apply pending schema migrations
    python -m querystudio db check          Verify database connectivity
    python -m querystudio version           Show version information
    python -m querystudio info              System and environment info
    python -m querystudio config show       Print resolved configuration
    python -m querystudio config validate   Validate config.json
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from pathlib import Path

# Ensure the backend directory is on sys.path so core.* imports work
_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))


def _print_banner():
    from querystudio import __version__
    v = __version__
    py = platform.python_version()
    osname = platform.system()
    d = "\033[2m"   # dim
    r = "\033[0m"   # reset
    b = "\033[1m"   # bold
    c = "\033[36m"  # cyan
    print(f"""{c}
   ___                       ___ _           _ _
  / _ \\ _  _ ___ _ _ _  _  / __| |_ _  _ __| (_)___
 | (_) | || / -_) '_| || | \\__ \\  _| || / _` | / _ \\
  \\__\\_\\\\_,_\\___|_|  \\_, | |___/\\__|\\_,_\\__,_|_\\___/
                     |__/{r}
  {d}v{v}  |  Python {py}  |  {osname}{r}
""")


# ── Subcommands ──────────────────────────────────────────────────────────────

def cmd_standalone(args):
    """Run webserver + scheduler in one process (embedded mode)."""
    _print_banner()
    print("[standalone] Starting webserver + scheduler in one process")

    # Force embedded mode so APScheduler runs in-process
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "embedded"

    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


def cmd_webserver(args):
    """Run FastAPI HTTP server only (external scheduler mode)."""
    _print_banner()
    print("[webserver] Starting HTTP server (scheduler.mode=external)")
    print("[webserver] Make sure scheduler worker is running separately\n")

    # Force external mode so APScheduler does NOT start here
    os.environ["QUERYSTUDIO_SCHEDULER_MODE"] = "external"

    from main import run_server
    run_server(
        host=args.host,
        port=args.port,
        workers=args.workers,
    )


def cmd_scheduler(args):
    """Run scheduler worker only."""
    _print_banner()
    print("[scheduler] Starting scheduler worker\n")

    # Override port if provided
    if args.port:
        os.environ["QUERYSTUDIO_SCHEDULER_WORKER_PORT"] = str(args.port)

    from scheduler_worker import main as scheduler_main
    scheduler_main()


def cmd_executor(args):
    """Run executor worker only (heavy query execution)."""
    _print_banner()
    print("[executor] Starting executor worker\n")

    # Override port if provided
    if args.port:
        os.environ["QUERYSTUDIO_EXECUTOR_WORKER_PORT"] = str(args.port)

    from executor_worker import main as executor_main
    executor_main()


def cmd_db_init(args):
    """Create database, tables, and data directories."""
    os.chdir(str(_backend_dir))
    from core.config import paths as _paths

    # Create all data directories
    dirs = [
        Path(_paths.data_dir),
        Path(_paths.parquet_dir),
        Path(_paths.downloads_dir),
        Path(_paths.data_dir) / "cache",
        Path(_paths.data_dir) / "uploads",
    ]
    created = []
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        created.append(d)

    # Initialise database (create_all + migrations)
    db_file = Path(_paths.db_file).resolve()
    db_url = f"sqlite:///{db_file.as_posix()}"

    from core.database import DatabaseManager
    db_manager = DatabaseManager(db_url=db_url)

    # Count tables
    from sqlalchemy import inspect
    inspector = inspect(db_manager.engine)
    tables = inspector.get_table_names()

    print("Database initialized successfully")
    print(f"  DB file:  {db_file}")
    print(f"  Tables:   {len(tables)}")
    print(f"  Dirs:     {len(created)} data directories ready")
    for d in created:
        print(f"            {d}")


def cmd_db_migrate(args):
    """Apply pending schema migrations."""
    os.chdir(str(_backend_dir))
    from core.config import paths as _paths

    db_file = Path(_paths.db_file).resolve()
    db_url = f"sqlite:///{db_file.as_posix()}"

    from core.database import DatabaseManager
    db_manager = DatabaseManager(db_url=db_url)

    print("Schema migrations applied successfully")
    print(f"  DB file: {db_file}")


def cmd_db_check(args):
    """Verify database connectivity and schema."""
    os.chdir(str(_backend_dir))
    from core.config import paths as _paths

    db_file = Path(_paths.db_file).resolve()
    if not db_file.exists():
        print(f"FAIL: Database file not found: {db_file}")
        print("  Run: python -m querystudio db init")
        sys.exit(1)

    db_url = f"sqlite:///{db_file.as_posix()}"

    try:
        from core.database import DatabaseManager
        db_manager = DatabaseManager(db_url=db_url)
    except Exception as exc:
        print(f"FAIL: Cannot connect to database: {exc}")
        sys.exit(1)

    from sqlalchemy import inspect, text
    inspector = inspect(db_manager.engine)
    tables = inspector.get_table_names()

    expected = [
        "saved_queries", "query_executions", "download_files",
        "connections", "schedules", "pending_notifications",
    ]
    missing = [t for t in expected if t not in tables]

    # Get DB file size
    size_mb = db_file.stat().st_size / (1024 * 1024)

    # Count key records
    session = db_manager.SessionLocal()
    try:
        counts = {}
        for t in ["saved_queries", "connections", "schedules"]:
            if t in tables:
                result = session.execute(text(f"SELECT COUNT(*) FROM {t}"))
                counts[t] = result.scalar()
    finally:
        session.close()

    print("Database health check")
    print(f"  File:     {db_file} ({size_mb:.1f} MB)")
    print(f"  Tables:   {len(tables)}")
    if missing:
        print(f"  Missing:  {', '.join(missing)}")
    else:
        print(f"  Schema:   OK (all expected tables present)")
    for t, c in counts.items():
        print(f"  {t}: {c} rows")

    if missing:
        print("\nWARNING: Some tables are missing. Run: python -m querystudio db init")
        sys.exit(1)
    else:
        print("\nAll checks passed")


def cmd_version(args):
    """Print version + key dependency versions."""
    from querystudio import __version__

    print(f"QueryStudio v{__version__}")
    print(f"Python {platform.python_version()}")

    deps = {
        "fastapi": "fastapi",
        "uvicorn": "uvicorn",
        "duckdb": "duckdb",
        "APScheduler": "apscheduler",
        "SQLAlchemy": "sqlalchemy",
        "PyArrow": "pyarrow",
        "Pandas": "pandas",
        "Boto3": "boto3",
        "Pydantic": "pydantic",
    }
    parts = []
    for label, pkg in deps.items():
        try:
            mod = __import__(pkg)
            ver = getattr(mod, "__version__", getattr(mod, "version", "?"))
            parts.append(f"{label} {ver}")
        except ImportError:
            parts.append(f"{label} (not installed)")

    # Print in rows of 3
    for i in range(0, len(parts), 3):
        print("  " + " | ".join(parts[i:i + 3]))


def cmd_info(args):
    """Print full system info."""
    from querystudio import __version__
    os.chdir(str(_backend_dir))

    print(f"QueryStudio v{__version__}")
    print("-" * 40)
    print(f"  Platform:    {platform.system()} {platform.release()} ({sys.platform})")
    print(f"  Python:      {platform.python_version()}")
    print(f"  Backend dir: {_backend_dir}")

    try:
        from core.config import paths as _paths, scheduler as _sched_cfg, auth as _auth_cfg, executor as _exec_cfg

        config_file = _backend_dir / "config.json"
        print(f"  Config file: {config_file} ({'exists' if config_file.exists() else 'NOT FOUND'})")

        db_file = Path(_paths.db_file).resolve()
        if db_file.exists():
            size_mb = db_file.stat().st_size / (1024 * 1024)
            print(f"  Database:    {db_file} ({size_mb:.1f} MB)")
        else:
            print(f"  Database:    {db_file} (not created)")

        data_dir = Path(_paths.data_dir).resolve()
        if data_dir.exists():
            total = sum(f.stat().st_size for f in data_dir.rglob("*") if f.is_file())
            print(f"  Data dir:    {data_dir} ({total / (1024 * 1024):.0f} MB)")
        else:
            print(f"  Data dir:    {data_dir} (not created)")

        print(f"  Auth mode:   {_auth_cfg.type}")
        print(f"  Scheduler:   {_sched_cfg.mode}")
        print(f"  Executor:    {_exec_cfg.mode}")

        # Queue backend info
        try:
            from core.config import queue as _queue_cfg
            backend = _queue_cfg.backend
            print(f"  Queue:       {backend}", end="")
            if backend == "redis":
                print(f" ({_queue_cfg.redis_url})", end="")
                # Test Redis connectivity
                try:
                    import redis
                    r = redis.from_url(_queue_cfg.redis_url, socket_connect_timeout=2)
                    r.ping()
                    print(" [connected]")
                except Exception:
                    print(" [NOT reachable]")
            else:
                print()
        except Exception:
            print(f"  Queue:       sqlite (default)")

        # Count DB records if DB exists
        if db_file.exists():
            try:
                from core.database import DatabaseManager
                db_manager = DatabaseManager(db_url=f"sqlite:///{db_file.as_posix()}")
                from sqlalchemy import text
                session = db_manager.SessionLocal()
                try:
                    for table, label in [
                        ("connections", "Connections"),
                        ("saved_queries", "Saved queries"),
                        ("schedules", "Schedules"),
                    ]:
                        try:
                            count = session.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                            print(f"  {label}:{' ' * (13 - len(label))}{count}")
                        except Exception:
                            pass
                finally:
                    session.close()
            except Exception:
                pass

    except Exception as exc:
        print(f"  Config load error: {exc}")


def cmd_config_show(args):
    """Print resolved configuration (secrets masked)."""
    os.chdir(str(_backend_dir))

    from core.config import _cfg

    # Deep copy and mask secrets
    import copy
    cfg = copy.deepcopy(_cfg)

    secret_keys = {"password", "secret", "key", "token", "credential", "local_users"}

    def _mask(d, parent_key=""):
        if isinstance(d, dict):
            for k, v in d.items():
                if any(s in k.lower() for s in secret_keys) and isinstance(v, str) and v:
                    d[k] = "***masked***"
                else:
                    _mask(v, k)
        elif isinstance(d, list):
            for item in d:
                _mask(item)

    _mask(cfg)
    print(json.dumps(cfg, indent=2, default=str))


def cmd_config_validate(args):
    """Validate config.json syntax and values."""
    os.chdir(str(_backend_dir))

    config_file = _backend_dir / "config.json"
    if not config_file.exists():
        print(f"Config file not found: {config_file}")
        print("Using built-in defaults (this is OK for development)")
        sys.exit(0)

    # Parse JSON
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except json.JSONDecodeError as exc:
        print(f"FAIL: Invalid JSON in {config_file}")
        print(f"  {exc}")
        sys.exit(1)

    print(f"Config file: {config_file}")
    print(f"  JSON syntax: OK")

    warnings = []
    errors = []

    # Validate server section
    server = cfg.get("server", {})
    port = server.get("port")
    if port is not None and not isinstance(port, int):
        errors.append(f"server.port must be integer, got {type(port).__name__}")
    workers = server.get("workers")
    if workers is not None and not isinstance(workers, int):
        errors.append(f"server.workers must be integer, got {type(workers).__name__}")

    # Validate scheduler section
    sched = cfg.get("scheduler", {})
    mode = sched.get("mode")
    if mode and mode not in ("embedded", "external"):
        errors.append(f"scheduler.mode must be 'embedded' or 'external', got '{mode}'")

    # Validate executor section
    executor = cfg.get("executor", {})
    exec_mode = executor.get("mode")
    if exec_mode and exec_mode not in ("embedded", "external"):
        errors.append(f"executor.mode must be 'embedded' or 'external', got '{exec_mode}'")

    # Validate auth section
    auth = cfg.get("auth", {})
    auth_type = auth.get("type")
    if auth_type and auth_type not in ("none", "local", "ad"):
        errors.append(f"auth.type must be 'none', 'local', or 'ad', got '{auth_type}'")
    if auth_type == "none":
        warnings.append("auth.type is 'none' — no authentication (fine for development)")

    # Validate queue section
    queue = cfg.get("queue", {})
    q_backend = queue.get("backend")
    if q_backend and q_backend not in ("sqlite", "redis"):
        errors.append(f"queue.backend must be 'sqlite' or 'redis', got '{q_backend}'")
    if q_backend == "redis":
        redis_url = queue.get("redis_url", "")
        if not redis_url:
            errors.append("queue.redis_url is required when queue.backend = 'redis'")
        elif not redis_url.startswith(("redis://", "rediss://")):
            errors.append(f"queue.redis_url must start with 'redis://' or 'rediss://', got '{redis_url}'")
        ttl = queue.get("task_ttl_hours")
        if ttl is not None and (not isinstance(ttl, (int, float)) or ttl < 1):
            errors.append(f"queue.task_ttl_hours must be a positive number, got {ttl}")

    # Validate database section
    db = cfg.get("database", {})
    db_type = db.get("type")
    if db_type and db_type not in ("sqlite", "oracle"):
        errors.append(f"database.type must be 'sqlite' or 'oracle', got '{db_type}'")

    # Report
    sections = [k for k in cfg.keys()]
    print(f"  Sections:    {', '.join(sections)}")

    if errors:
        print(f"\n  ERRORS ({len(errors)}):")
        for e in errors:
            print(f"    - {e}")

    if warnings:
        print(f"\n  WARNINGS ({len(warnings)}):")
        for w in warnings:
            print(f"    - {w}")

    if not errors and not warnings:
        print("  Validation:  OK")

    if errors:
        sys.exit(1)


# ── Main CLI dispatcher ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="querystudio",
        description="QueryStudio — Enterprise Parquet Query Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  standalone    Run webserver + scheduler in one process (default)
  webserver     Run HTTP/WebSocket server only
  scheduler     Run scheduler worker only
  executor      Run executor worker only (heavy queries)
  db            Database management (init, migrate, check)
  version       Show version info
  info          System and environment info
  config        Configuration management (show, validate)
""",
    )
    subparsers = parser.add_subparsers(dest="command")

    # standalone
    p = subparsers.add_parser("standalone", help="Run all components in one process")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=1, help="Number of workers (default: 1)")
    p.set_defaults(func=cmd_standalone)

    # webserver
    p = subparsers.add_parser("webserver", help="Run HTTP server only (external scheduler)")
    p.add_argument("--host", default=None, help="Bind address (default: from config)")
    p.add_argument("--port", type=int, default=None, help="Port (default: from config)")
    p.add_argument("--workers", type=int, default=1, help="Number of workers (default: 1)")
    p.set_defaults(func=cmd_webserver)

    # scheduler
    p = subparsers.add_parser("scheduler", help="Run scheduler worker only")
    p.add_argument("--port", type=int, default=None, help="Control API port (default: 8001)")
    p.set_defaults(func=cmd_scheduler)

    # executor
    p = subparsers.add_parser("executor", help="Run executor worker only")
    p.add_argument("--port", type=int, default=None, help="Control API port (default: 8002)")
    p.set_defaults(func=cmd_executor)

    # db
    db_parser = subparsers.add_parser("db", help="Database management")
    db_sub = db_parser.add_subparsers(dest="db_command")
    p_init = db_sub.add_parser("init", help="Initialize database and directories")
    p_init.set_defaults(func=cmd_db_init)
    p_migrate = db_sub.add_parser("migrate", help="Apply schema migrations")
    p_migrate.set_defaults(func=cmd_db_migrate)
    p_check = db_sub.add_parser("check", help="Verify database health")
    p_check.set_defaults(func=cmd_db_check)

    # version
    p = subparsers.add_parser("version", help="Show version info")
    p.set_defaults(func=cmd_version)

    # info
    p = subparsers.add_parser("info", help="System and environment info")
    p.set_defaults(func=cmd_info)

    # config
    cfg_parser = subparsers.add_parser("config", help="Configuration management")
    cfg_sub = cfg_parser.add_subparsers(dest="config_command")
    p_show = cfg_sub.add_parser("show", help="Print resolved config")
    p_show.set_defaults(func=cmd_config_show)
    p_validate = cfg_sub.add_parser("validate", help="Validate config.json")
    p_validate.set_defaults(func=cmd_config_validate)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "db" and not getattr(args, "db_command", None):
        db_parser.print_help()
        sys.exit(0)

    if args.command == "config" and not getattr(args, "config_command", None):
        cfg_parser.print_help()
        sys.exit(0)

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    # cd to backend dir for all commands
    os.chdir(str(_backend_dir))
    args.func(args)
