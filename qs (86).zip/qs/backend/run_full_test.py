"""Comprehensive phase-by-phase test for QueryStudio (all 29 phases)."""
import sys, os, uuid

sys.path.insert(0, os.path.dirname(__file__))
os.chdir(os.path.dirname(__file__))

passed, failed = [], []

def ok(label):
    passed.append(label)

def fail(label, e):
    failed.append((label, str(e)))

def check(label, fn):
    try:
        r = fn()
        ok(label)
        return r
    except Exception as e:
        fail(label, str(e))
        return None

# ════════════════════════════════════════════════════════
# SECTION 1 — Critical backend file presence
# ════════════════════════════════════════════════════════
print("\n=== [1/10] File presence ===")
root = os.path.join(os.path.dirname(__file__), '..')
files = {
    'core/config.py': 'Core config',
    'core/database.py': 'Database',
    'core/parquet_engine.py': 'Parquet engine v1',
    'core/parquet_engine_v2.py': 'Parquet engine v2',
    'core/scheduler.py': 'Scheduler (8A)',
    'core/worker_pool.py': 'Worker pool (17J)',
    'core/websocket_manager.py': 'WebSocket mgr (16E)',
    'core/cache.py': 'TTL cache (4A)',
    'core/ad_auth.py': 'AD/LDAP auth (9A)',
    'core/crypto.py': 'Encryption (9F)',
    'core/email_service.py': 'Email service (8D)',
    'core/webhook_service.py': 'Webhook service (8E)',
    'core/date_resolver.py': 'Date resolver (8F)',
    'core/rate_limiter.py': 'Rate limiter (22B)',
    'core/queue_backend.py': 'Queue backend (19A)',
    'core/connectors/trino_connector.py': 'Trino (6A)',
    'core/connectors/snowflake_connector.py': 'Snowflake (6B)',
    'core/connectors/databricks_connector.py': 'Databricks (6C)',
    'core/connectors/oracle_connector.py': 'Oracle (6D)',
    'api/data_grid_api.py': 'Data grid API',
    'api/reports_api.py': 'Reports API (10F)',
    'api/schedules_api.py': 'Schedules API (8B)',
    'api/dashboards_api.py': 'Dashboards API (11A)',
    'api/sql_query_api.py': 'SQL editor API (13B)',
    'api/catalog_api.py': 'Catalog API (23A)',
    'api/enterprise_reports_api.py': 'Enterprise rpts (23C-H)',
    'api/pdf_export_api.py': 'PDF export (23D)',
    'api/burst_api.py': 'Burst API (23E)',
    'api/connection_profiles_api.py': 'Conn profiles (24B)',
    'api/workspaces_api.py': 'Workspaces API (25B)',
    'api/lineage_api.py': 'Lineage API (26A)',
    'api/embed_api.py': 'Embed API (27B)',
    # Phase 29: domain routers
    'core/sessions.py': 'Sessions store (29A)',
    'core/execution_state.py': 'Execution state (29A)',
    'api/deps.py': 'Auth deps (29A)',
    'api/auth_api.py': 'Auth API (29B)',
    'api/notifications_api.py': 'Notifications API (29B)',
    'api/system_api.py': 'System API (29B)',
    'api/admin_api.py': 'Admin API (29C)',
    'api/connections_api.py': 'Connections API (29D)',
    'api/queries_api.py': 'Queries API (29E)',
    'api/materialized_views_api.py': 'Materialized views API (29F)',
    'api/local_tables_api.py': 'Local tables API (29G)',
    'executor_worker.py': 'Executor worker (17A)',
    'scheduler_worker.py': 'Scheduler worker (17E)',
    'main.py': 'FastAPI main',
    'tests/conftest.py': 'Test fixtures (22D)',
    'tests/test_config.py': 'Config tests (22D)',
    'tests/test_health.py': 'Health tests (22D)',
    'tests/test_date_resolver.py': 'Date resolver tests (22D)',
}
for path, label in files.items():
    if os.path.exists(path):
        ok(f'FILE: {label}')
    else:
        fail(f'FILE: {label}', f'MISSING {path}')

# Deployment files (at project root, not backend/)
root_files = {
    '../k8s/helm/Chart.yaml': 'Helm Chart.yaml (20A)',
    '../k8s/helm/values.yaml': 'Helm values.yaml (20A)',
    '../monitoring/grafana': 'Grafana dashboards dir (21B)',
    '../docker-compose.yml': 'Docker Compose standalone (18B)',
    '../docker-compose.production.yml': 'Docker Compose production (18C)',
    '../docker-compose.scale.yml': 'Docker Compose scale (19E)',
    '../nginx/nginx.conf': 'Nginx config (19C)',
    '../Dockerfile': 'Dockerfile (18A)',
}
for path, label in root_files.items():
    fullpath = os.path.normpath(os.path.join(os.path.dirname(__file__), path))
    if os.path.exists(fullpath):
        ok(f'FILE: {label}')
    else:
        fail(f'FILE: {label}', f'MISSING {fullpath}')

# Frontend key files
fe_root = os.path.normpath(os.path.join(os.path.dirname(__file__), '../frontend/src'))
frontend_files = {
    'App.tsx': 'App.tsx',
    'components/ReportsManagerPage.tsx': 'Reports manager (10G)',
    'components/AdminPage.tsx': 'Admin page (12A)',
    'components/Layout.tsx': 'Layout (0C)',
    'components/LineagePage.tsx': 'Lineage page (26B)',
    'components/EmbeddedReportPage.tsx': 'Embedded report page (27C)',
    'components/ReportCatalogPage.tsx': 'Report catalog page (23A)',
    'components/ReportConnectorsPage.tsx': 'Connectors page (24C)',
    'context/WorkspaceContext.tsx': 'Workspace context (25C)',
    'context/AppSettingsContext.tsx': 'App settings context',
    'services/api.ts': 'API service',
    'services/columnIntelligence.ts': 'Column intelligence (15C)',
}
for rel, label in frontend_files.items():
    fullpath = os.path.join(fe_root, rel)
    if os.path.exists(fullpath):
        ok(f'FE: {label}')
    else:
        fail(f'FE: {label}', f'MISSING {fullpath}')

print(f"  done: {sum(1 for p in passed if p.startswith('FILE:') or p.startswith('FE:'))} files OK")

# ════════════════════════════════════════════════════════
# SECTION 2 — Python imports (all API routers)
# ════════════════════════════════════════════════════════
print("\n=== [2/10] Module imports ===")
modules = [
    ('core.config', 'Core config'),
    ('core.database', 'Database'),
    ('core.parquet_engine', 'Parquet engine v1'),
    ('core.scheduler', 'Scheduler'),
    ('core.worker_pool', 'Worker pool'),
    ('core.websocket_manager', 'WebSocket manager'),
    ('core.rate_limiter', 'Rate limiter (22B)'),
    ('core.queue_backend', 'Queue backend (19A)'),
    ('api.reports_api', 'Reports API'),
    ('api.data_grid_api', 'Data grid API'),
    ('api.workspaces_api', 'Workspaces API (25B)'),
    ('api.lineage_api', 'Lineage API (26A)'),
    ('api.embed_api', 'Embed API (27B)'),
    ('api.connection_profiles_api', 'Connection profiles API (24B)'),
    ('api.catalog_api', 'Catalog API (23A)'),
    ('api.enterprise_reports_api', 'Enterprise reports (23C-H)'),
    ('api.burst_api', 'Burst API (23E)'),
    ('api.schedules_api', 'Schedules API (8B)'),
    ('api.dashboards_api', 'Dashboards API (11A)'),
    ('api.sql_query_api', 'SQL query API (13B)'),
    # Phase 29: domain routers
    ('core.sessions', 'Sessions store (29A)'),
    ('core.execution_state', 'Execution state (29A)'),
    ('api.deps', 'Auth deps (29A)'),
    ('api.auth_api', 'Auth API (29B)'),
    ('api.notifications_api', 'Notifications API (29B)'),
    ('api.system_api', 'System API (29B)'),
    ('api.admin_api', 'Admin API (29C)'),
    ('api.connections_api', 'Connections API (29D)'),
    ('api.queries_api', 'Queries API (29E)'),
    ('api.materialized_views_api', 'Materialized views API (29F)'),
    ('api.local_tables_api', 'Local tables API (29G)'),
]
for mod, label in modules:
    try:
        __import__(mod)
        ok(f'IMPORT: {label}')
    except Exception as e:
        fail(f'IMPORT: {label}', e)
print(f"  done: {sum(1 for p in passed if p.startswith('IMPORT:'))} modules OK")

# ════════════════════════════════════════════════════════
# SECTION 3 — ORM models
# ════════════════════════════════════════════════════════
print("\n=== [3/10] ORM models ===")
try:
    from core.database import (
        Base, SavedQuery, QueryExecution, DownloadFile, Connection, Schedule,
        AuditLog, SqlSavedQuery, Dashboard, DashboardWidget, QueryShare,
        DashboardShare, MaterializedView, LocalTable, SchemaCache,
        Report, QueryVersion, TaskQueue, DeadLetterQueue,
        ReportFolder, ReportTag, ReportTagAssignment, ReportFavorite, ReportView,
        ReportBookmark, ConditionalFormatRule, AlertRule, AlertHistory,
        BurstJob, BurstTask, RLSPolicy, CloudDeliveryConfig, DeliveryHistory,
        ConnectionProfile, ConnectionProfileMapping,
        Workspace, WorkspaceMember, ReportEmbedToken,
    )
    ok('ORM: all 37 models importable')
    assert Workspace.__tablename__ == 'workspaces'
    assert WorkspaceMember.__tablename__ == 'workspace_members'
    assert ReportEmbedToken.__tablename__ == 'report_embed_tokens'
    ok('ORM: Phase 25+27 table names correct')
except Exception as e:
    fail('ORM: models import', e)

# ════════════════════════════════════════════════════════
# SECTION 4 — DB migrations (all columns present)
# ════════════════════════════════════════════════════════
print("\n=== [4/10] DB migrations ===")
from core.database import DatabaseManager
import sqlite3

db = DatabaseManager('sqlite:///data/querystudio.db')
con = sqlite3.connect('data/querystudio.db')
cur = con.cursor()

def table_cols(tname):
    cur.execute(f'PRAGMA table_info({tname})')
    return {r[1] for r in cur.fetchall()}

# reports table columns
r_cols = table_cols('reports')
for col in ['cache_ttl_minutes', 'schedule_config', 'connection_override_id',
            'workspace_id', 'sql_saved_query_id', 'sql_override', 'last_executed_at']:
    if col in r_cols:
        ok(f'MIG: reports.{col}')
    else:
        fail(f'MIG: reports.{col}', 'MISSING')

# workspace_id on 8 entity tables (Phase 25)
for tname in ['connections', 'saved_queries', 'sql_saved_queries',
              'dashboards', 'schedules', 'materialized_views', 'local_tables']:
    if 'workspace_id' in table_cols(tname):
        ok(f'MIG: {tname}.workspace_id (P25)')
    else:
        fail(f'MIG: {tname}.workspace_id (P25)', 'MISSING')

# New tables for Phase 25, 27
for tname in ['workspaces', 'workspace_members', 'report_embed_tokens']:
    if table_cols(tname):
        ok(f'MIG: table {tname} exists')
    else:
        fail(f'MIG: table {tname}', 'NOT CREATED')

con.close()

# ════════════════════════════════════════════════════════
# SECTION 5 — Phase 25: Workspaces CRUD
# ════════════════════════════════════════════════════════
print("\n=== [5/10] Phase 25: Workspaces ===")
check('P25: ensure_default_workspace', lambda: db.ensure_default_workspace())
wss = check('P25: list_workspaces', lambda: db.list_workspaces('test'))

# Clean up any stale test workspaces from previous runs before creating
import sqlite3 as _s3
_c = _s3.connect('data/querystudio.db')
_c.execute("DELETE FROM workspace_members WHERE workspace_id IN (SELECT id FROM workspaces WHERE slug LIKE '__test-%')")
_c.execute("DELETE FROM workspaces WHERE slug LIKE '__test-%'")
_c.commit(); _c.close()

ws = check('P25: create_workspace', lambda: db.create_workspace(
    name='__test_ws__', slug='__test-ws__', description='test', created_by='test'))
if ws:
    wid = ws['id']
    check('P25: get_workspace',           lambda: db.get_workspace(wid))
    check('P25: update_workspace name',   lambda: db.update_workspace(wid, name='__test_ws_upd__'))
    check('P25: list_workspace_members',  lambda: db.list_workspace_members(wid))
    check('P25: add_workspace_member',    lambda: db.add_workspace_member(wid, 'u1', 'member', 'admin'))
    check('P25: update_member_role',      lambda: db.update_workspace_member_role(wid, 'u1', 'admin'))
    check('P25: remove_workspace_member', lambda: db.remove_workspace_member(wid, 'u1'))
    check('P25: delete_workspace',        lambda: db.delete_workspace(wid))

# ════════════════════════════════════════════════════════
# SECTION 6 — Phase 26: Lineage API routes + smoke tests
# ════════════════════════════════════════════════════════
print("\n=== [6/10] Phase 26: Lineage ===")
import api.lineage_api as lin
lin.set_lineage_dependencies(db)
routes_lin = [r.path for r in lin.router.routes if hasattr(r, 'path')]
for expected in ['/api/lineage/connection/{connection_id}', '/api/lineage/report/{report_id}',
                 '/api/lineage/query/{query_id}', '/api/lineage/graph']:
    if expected in routes_lin:
        ok(f'P26: route {expected}')
    else:
        fail(f'P26: route {expected}', 'MISSING')
check('P26: _build_connection_downstream(999) graceful',
      lambda: lin._build_connection_downstream(db, 999))
g = check('P26: get_full_lineage_graph() graceful',
          lambda: lin.get_full_lineage_graph.__wrapped__(db) if hasattr(lin.get_full_lineage_graph, '__wrapped__') else None)
# Smoke test the lineage graph by calling the internal builder directly
try:
    with db.get_session() as s:
        from core.database import Connection as Conn, Report as Rpt
        conn_count = s.query(Conn).count()
        rpt_count = s.query(Rpt).count()
    ok(f'P26: lineage graph smoke test (connections={conn_count}, reports={rpt_count})')
except Exception as e:
    fail('P26: lineage smoke test', e)

# ════════════════════════════════════════════════════════
# SECTION 7 — Phase 27: Embed tokens CRUD + route check
# ════════════════════════════════════════════════════════
print("\n=== [7/10] Phase 27: Embed tokens ===")
import api.embed_api as emb
routes_emb = [r.path for r in emb.router.routes if hasattr(r, 'path')]
for expected in ['/api/reports/{report_id}/embed-tokens',
                 '/api/reports/embed-tokens/{token}',
                 '/api/embedded-report/{token}',
                 '/api/embedded-report/{token}/execute']:
    if expected in routes_emb:
        ok(f'P27: route {expected}')
    else:
        fail(f'P27: route {expected}', 'MISSING')

tok = check('P27: create_embed_token', lambda: db.create_report_embed_token(
    report_id=999, created_by='test', expires_at=None, allowed_params=None))
if tok:
    t = tok['token']
    assert len(t) == 32, 'token not 32-char hex'
    ok('P27: token is 32-char hex (uuid4.hex)')
    check('P27: get_embed_token',     lambda: db.get_embed_token(t))
    check('P27: list_embed_tokens',   lambda: db.list_embed_tokens(999))
    check('P27: increment_access',    lambda: db.increment_embed_token_access(t))
    tok2 = db.get_embed_token(t)
    if tok2 and tok2['access_count'] == 1:
        ok('P27: access_count incremented to 1')
    else:
        fail('P27: access_count check', f'got {tok2}')
    check('P27: revoke_embed_token',  lambda: db.revoke_embed_token(t))
    tok3 = db.get_embed_token(t)
    if tok3 and tok3['is_active'] == False:
        ok('P27: token correctly revoked')
    else:
        fail('P27: revoke check', f'got {tok3}')

# ════════════════════════════════════════════════════════
# SECTION 8 — Phase 28: Audit & Compliance DB methods
# ════════════════════════════════════════════════════════
print("\n=== [8/10] Phase 28: Audit & Compliance ===")
check('P28: list_audit_log',            lambda: db.list_audit_log(limit=5))
check('P28: get_audit_log_filtered',    lambda: db.get_audit_log_filtered(limit=5))
check('P28: get_audit_log_filtered(username)', lambda: db.get_audit_log_filtered(
    username='test', resource_type='report', limit=5))
check('P28: get_data_access_summary',   lambda: db.get_data_access_summary())
export = check('P28: get_user_data_export', lambda: db.get_user_data_export('prakash'))
if export:
    for key in ['username', 'saved_queries', 'sql_queries', 'executions',
                'downloads', 'schedules', 'audit_log']:
        if key in export:
            ok(f'P28: export[{key!r}] present')
        else:
            fail(f'P28: export[{key!r}]', 'KEY MISSING')

# ════════════════════════════════════════════════════════
# SECTION 9 — reports_api route ordering + column loading
# ════════════════════════════════════════════════════════
print("\n=== [9/10] Reports API route ordering + column loading ===")
import api.reports_api as rapi
from api.reports_api import _get_parquet_schema_columns, _normalise_cols

routes_r = [(list(r.methods), r.path) for r in rapi.router.routes if hasattr(r, 'path')]
param_idx = next((i for i, (m, p) in enumerate(routes_r)
                  if '{report_id}' in p and 'GET' in m), None)
for static in ['preview-columns', 'connector-matrix']:
    idx = next((i for i, (m, p) in enumerate(routes_r) if static in p), None)
    if idx is None:
        fail(f'ROUTE: {static} exists', 'MISSING')
    elif param_idx is not None and idx > param_idx:
        fail(f'ROUTE: {static} before {{report_id}}',
             f'ordering bug: static [{idx}] after param [{param_idx}]')
    else:
        ok(f'ROUTE: {static} correctly before {{report_id}}')

# Column loading for all prefix types
for label, files_arg in [
    ('__local__: graceful miss',         ['__local__:no_such_table']),
    ('__materialized__: graceful miss',  ['__materialized__:no_such_mv']),
    ('__registered__: graceful miss',    ['__registered__:no_such_tbl']),
    ('s3://: skipped gracefully',        ['s3://bucket/file.parquet']),
    ('empty list',                       []),
    ('None input',                       None),
]:
    check(f'COLS: {label}', lambda f=files_arg: _get_parquet_schema_columns(f, db))

# _normalise_cols
def test_normalise():
    assert _normalise_cols([{'name': 'a', 'type': 'INT'}]) == [{'name': 'a', 'type': 'INT'}]
    assert _normalise_cols(['col1']) == [{'name': 'col1', 'type': 'unknown'}]
    assert _normalise_cols([{'column_name': 'x', 'column_type': 'VARCHAR'}]) == [{'name': 'x', 'type': 'VARCHAR'}]
    assert _normalise_cols([]) == []
    assert _normalise_cols(None) == []
    return True
check('COLS: _normalise_cols all variants', test_normalise)

# Reports CRUD (the core feature that broke with cache_ttl_minutes)
r = check('RPT: create_report', lambda: db.create_report(
    name='__test_rpt__', description=None, saved_query_id=None,
    sql_saved_query_id=None,
    parameters='[{"name":"p","type":"string","label":"P","required":false,"default_value":"","description":"","options":null}]',
    sql_override=None, created_by='test'
))
if r:
    rid = r['id']
    assert r.get('cache_ttl_minutes') == 0, 'cache_ttl_minutes default wrong'
    ok('RPT: cache_ttl_minutes default=0 in create response')
    check('RPT: get_report',    lambda: db.get_report(rid))
    check('RPT: update_report', lambda: db.update_report(rid, name='__test_rpt_upd__'))
    check('RPT: list_reports',  lambda: db.list_reports())
    check('RPT: delete_report', lambda: db.delete_report(rid))

# ════════════════════════════════════════════════════════
# SECTION 10 — Connection profiles (Phase 24B)
# ════════════════════════════════════════════════════════
print("\n=== [10/10] Phase 24B: Connection profiles ===")
import api.connection_profiles_api as cp
routes_cp = [r.path for r in cp.router.routes if hasattr(r, 'path')]
for expected in ['/api/connection-profiles',
                 '/api/connection-profiles/{profile_id}',
                 '/api/connection-profiles/active',
                 '/api/connection-profiles/{profile_id}/activate',
                 '/api/connection-profiles/{profile_id}/mappings']:
    if expected in routes_cp:
        ok(f'CP: route {expected}')
    else:
        fail(f'CP: route {expected}', 'MISSING')

prof = check('CP: create_connection_profile', lambda: db.create_connection_profile(
    name='__test_prof__', description='test', created_by='test'))
if prof:
    pid = prof['id']
    profs = check('CP: list_connection_profiles', lambda: db.list_connection_profiles())
    check('CP: get_profile_mappings',     lambda: db.get_profile_mappings(pid))
    check('CP: update_connection_profile', lambda: db.update_connection_profile(pid, name='__test_prof_upd__'))
    check('CP: get_active_profile',        lambda: db.get_active_profile())
    check('CP: delete_connection_profile', lambda: db.delete_connection_profile(pid))

# ════════════════════════════════════════════════════════
# SECTION 11 — Phase 29: Domain router routes + auth deps
# ════════════════════════════════════════════════════════
print("\n=== [11/11] Phase 29: Domain routers ===")

# auth_api routes
import api.auth_api as _auth_mod
_auth_routes = [r.path for r in _auth_mod.router.routes if hasattr(r, 'path')]
for ep in ['/auth/login', '/auth/logout', '/auth/me', '/auth/config']:
    if ep in _auth_routes:
        ok(f'P29-auth: route {ep}')
    else:
        fail(f'P29-auth: route {ep}', 'MISSING')

# notifications_api routes
import api.notifications_api as _notif_mod
_notif_routes = [r.path for r in _notif_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/notifications', '/api/notifications/unread-count',
           '/api/notifications/read-all', '/api/notifications/{notif_id}/read']:
    if ep in _notif_routes:
        ok(f'P29-notif: route {ep}')
    else:
        fail(f'P29-notif: route {ep}', 'MISSING')

# Check static read-all route comes before parameterised {notif_id}
_ra_idx = next((i for i, r in enumerate(_notif_mod.router.routes)
                if hasattr(r, 'path') and r.path == '/api/notifications/read-all'), None)
_ri_idx = next((i for i, r in enumerate(_notif_mod.router.routes)
                if hasattr(r, 'path') and '{notif_id}' in r.path), None)
if _ra_idx is not None and _ri_idx is not None and _ra_idx < _ri_idx:
    ok('P29-notif: read-all before {notif_id} (route order OK)')
else:
    fail('P29-notif: read-all before {notif_id}', f'ra={_ra_idx} ri={_ri_idx}')

# system_api routes
import api.system_api as _sys_mod
_sys_routes = [r.path for r in _sys_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/version', '/metrics', '/health']:
    if ep in _sys_routes:
        ok(f'P29-sys: route {ep}')
    else:
        fail(f'P29-sys: route {ep}', 'MISSING')

# admin_api — spot-check key routes
import api.admin_api as _admin_mod
_admin_routes = [r.path for r in _admin_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/admin/storage', '/api/admin/active-queries', '/api/admin/users',
           '/api/cache', '/api/admin/audit-log', '/api/admin/audit-log/export',
           '/api/admin/compliance/subject-export']:
    if ep in _admin_routes:
        ok(f'P29-admin: route {ep}')
    else:
        fail(f'P29-admin: route {ep}', 'MISSING')

# connections_api — spot-check
import api.connections_api as _conn_mod
_conn_routes = [r.path for r in _conn_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/connections', '/api/connections/{connection_id}',
           '/api/connections/{connection_id}/test',
           '/api/connections/{connection_id}/tables']:
    if ep in _conn_routes:
        ok(f'P29-conn: route {ep}')
    else:
        fail(f'P29-conn: route {ep}', 'MISSING')

# queries_api — spot-check
import api.queries_api as _qry_mod
_qry_routes = [r.path for r in _qry_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/files', '/api/queries', '/api/joins/preview',
           '/api/execute/preview-sql', '/api/downloads', '/api/executions']:
    if ep in _qry_routes:
        ok(f'P29-qry: route {ep}')
    else:
        fail(f'P29-qry: route {ep}', 'MISSING')

# mv_api — spot-check
import api.materialized_views_api as _mv_mod
_mv_routes = [r.path for r in _mv_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/materialized-views', '/api/materialized-views/{mv_id}',
           '/api/materialized-views/{mv_id}/refresh']:
    if ep in _mv_routes:
        ok(f'P29-mv: route {ep}')
    else:
        fail(f'P29-mv: route {ep}', 'MISSING')

# local_tables_api — spot-check
import api.local_tables_api as _lt_mod
_lt_routes = [r.path for r in _lt_mod.router.routes if hasattr(r, 'path')]
for ep in ['/api/local-tables', '/api/local-tables/{lt_id}',
           '/api/tables/preview', '/api/tables/favorites']:
    if ep in _lt_routes:
        ok(f'P29-lt: route {ep}')
    else:
        fail(f'P29-lt: route {ep}', 'MISSING')

# api/deps — init_deps, get_current_user functions present
import api.deps as _deps_mod
for fn in ['init_deps', 'get_current_user', 'require_admin', 'require_role',
           'require_execute_access', 'is_owner_or_shared']:
    if hasattr(_deps_mod, fn):
        ok(f'P29-deps: {fn} exported')
    else:
        fail(f'P29-deps: {fn}', 'MISSING')

# core/sessions — key functions present
import core.sessions as _sess_mod
for fn in ['create_session', 'get_session', 'destroy_session']:
    if hasattr(_sess_mod, fn):
        ok(f'P29-sessions: {fn} exported')
    else:
        fail(f'P29-sessions: {fn}', 'MISSING')

# core/execution_state — key items present
import core.execution_state as _es_mod
for attr in ['running_tasks', 'cancellation_flags', 'inflight_queries',
             'set_global_sem', 'get_global_sem', 'get_queue_count']:
    if hasattr(_es_mod, attr):
        ok(f'P29-execstate: {attr} exported')
    else:
        fail(f'P29-execstate: {attr}', 'MISSING')

# main.py size check — should be ~5,500 lines post-refactor (was 9,405)
_main_lines = len(open('main.py', encoding='utf-8').readlines())
if _main_lines < 7000:
    ok(f'P29-main: main.py reduced to {_main_lines} lines (was 9,405)')
else:
    fail('P29-main: main.py line count', f'still {_main_lines} lines — cleanup may be incomplete')

print(f"  done: Phase 29 checks complete")

# ════════════════════════════════════════════════════════
# FINAL SUMMARY
# ════════════════════════════════════════════════════════
print("\n" + "="*60)
print("FULL TEST RESULTS")
print("="*60)
for p in passed:
    print(f"  PASS  {p}")

if failed:
    print()
    for f, e in failed:
        print(f"  FAIL  {f}: {e}")
    print(f"\n{len(passed)} passed, {len(failed)} FAILED")
    sys.exit(1)
else:
    print(f"\nAll {len(passed)} checks PASSED. Product is clean.")
