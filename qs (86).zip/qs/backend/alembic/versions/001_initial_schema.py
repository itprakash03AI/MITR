"""Initial schema — baseline of all existing QueryStudio tables.

This migration represents the schema as it exists after Phases 0–35.
For databases that already have all tables (via create_all), this migration
is a no-op: it only creates tables/columns that are missing.

Revision ID: 001_initial
Revises: None
Create Date: 2026-03-23

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── saved_queries ─────────────────────────────────────────────────────
    op.create_table(
        "saved_queries",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False, index=True),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("query_config", sa.JSON, nullable=False),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("is_favorite", sa.Boolean, default=False),
        sa.Column("is_shared", sa.Boolean, default=False),
        sa.Column("execution_count", sa.Integer, default=0),
        sa.Column("last_executed_at", sa.DateTime, nullable=True),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── query_executions ──────────────────────────────────────────────────
    op.create_table(
        "query_executions",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("query_id", sa.Integer, nullable=True),
        sa.Column("execution_id", sa.String(100), unique=True, nullable=False, index=True),
        sa.Column("query_config", sa.JSON, nullable=False),
        sa.Column("status", sa.String(50), default="pending"),
        sa.Column("started_at", sa.DateTime),
        sa.Column("completed_at", sa.DateTime, nullable=True),
        sa.Column("total_rows", sa.Integer, default=0),
        sa.Column("chunks_processed", sa.Integer, default=0),
        sa.Column("output_file", sa.String(500), nullable=True),
        sa.Column("file_size_bytes", sa.Integer, default=0),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("executed_by", sa.String(100), nullable=True),
        if_not_exists=True,
    )

    # ── download_files ────────────────────────────────────────────────────
    op.create_table(
        "download_files",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("file_id", sa.String(100), unique=True, nullable=False, index=True),
        sa.Column("execution_id", sa.String(100), nullable=True),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("file_path", sa.String(500), nullable=False),
        sa.Column("file_size_bytes", sa.Integer, default=0),
        sa.Column("status", sa.String(50), default="available"),
        sa.Column("created_at", sa.DateTime),
        sa.Column("expires_at", sa.DateTime, nullable=True),
        sa.Column("download_count", sa.Integer, default=0),
        sa.Column("last_downloaded_at", sa.DateTime, nullable=True),
        sa.Column("created_by", sa.String(100), nullable=True),
        if_not_exists=True,
    )

    # ── connections ───────────────────────────────────────────────────────
    op.create_table(
        "connections",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("connection_type", sa.String(50), nullable=False),
        sa.Column("config", sa.JSON, nullable=False),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("is_shared", sa.Boolean, default=False),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── audit_log ─────────────────────────────────────────────────────────
    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("timestamp", sa.DateTime),
        sa.Column("username", sa.String(100), nullable=False),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("resource_type", sa.String(50), nullable=True),
        sa.Column("resource_id", sa.String(100), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("user_agent", sa.String(500), nullable=True),
        sa.Column("details", sa.JSON, nullable=True),
        if_not_exists=True,
    )

    # ── reports ───────────────────────────────────────────────────────────
    op.create_table(
        "reports",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("query_config", sa.JSON, nullable=False),
        sa.Column("parameters", sa.JSON, nullable=True),
        sa.Column("display_config", sa.JSON, nullable=True),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("report_type", sa.String(50), nullable=True),
        sa.Column("sql_saved_query_id", sa.Integer, nullable=True),
        sa.Column("sql_override", sa.Text, nullable=True),
        sa.Column("last_executed_at", sa.DateTime, nullable=True),
        sa.Column("cache_ttl_minutes", sa.Integer, default=0),
        sa.Column("schedule_config", sa.Text, nullable=True),
        sa.Column("connection_override_id", sa.Integer, nullable=True),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── schedules ─────────────────────────────────────────────────────────
    op.create_table(
        "schedules",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("report_id", sa.Integer, nullable=True),
        sa.Column("cron_expression", sa.String(100), nullable=True),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("next_run_at", sa.DateTime, nullable=True),
        sa.Column("last_run_at", sa.DateTime, nullable=True),
        sa.Column("last_status", sa.String(50), nullable=True),
        sa.Column("notify_emails", sa.Text, nullable=True),
        sa.Column("notify_webhook", sa.Text, nullable=True),
        sa.Column("is_shared", sa.Boolean, default=False),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── dashboards ────────────────────────────────────────────────────────
    op.create_table(
        "dashboards",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("layout", sa.JSON, nullable=True),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── sql_saved_queries ─────────────────────────────────────────────────
    op.create_table(
        "sql_saved_queries",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("sql_text", sa.Text, nullable=False),
        sa.Column("connection_id", sa.Integer, nullable=True),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("is_shared", sa.Boolean, default=False),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── materialized_views ────────────────────────────────────────────────
    op.create_table(
        "materialized_views",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("source_connection_id", sa.Integer, nullable=True),
        sa.Column("source_table", sa.String(255), nullable=True),
        sa.Column("query_config", sa.JSON, nullable=True),
        sa.Column("status", sa.String(50), default="pending"),
        sa.Column("row_count", sa.Integer, default=0),
        sa.Column("file_size_bytes", sa.Integer, default=0),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("last_refreshed_at", sa.DateTime, nullable=True),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── local_tables ──────────────────────────────────────────────────────
    op.create_table(
        "local_tables",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("file_path", sa.String(500), nullable=True),
        sa.Column("file_format", sa.String(50), nullable=True),
        sa.Column("row_count", sa.Integer, default=0),
        sa.Column("file_size_bytes", sa.Integer, default=0),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("workspace_id", sa.Integer, nullable=True),
        if_not_exists=True,
    )

    # ── workspaces ────────────────────────────────────────────────────────
    op.create_table(
        "workspaces",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("slug", sa.String(100), nullable=False, unique=True),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("is_default", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        if_not_exists=True,
    )

    # ── notifications ─────────────────────────────────────────────────────
    op.create_table(
        "notifications",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("username", sa.String(100), nullable=True),
        sa.Column("type", sa.String(50), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("message", sa.Text, nullable=True),
        sa.Column("data", sa.JSON, nullable=True),
        sa.Column("is_read", sa.Boolean, default=False),
        sa.Column("created_at", sa.DateTime),
        if_not_exists=True,
    )

    # ── query_shares ──────────────────────────────────────────────────────
    op.create_table(
        "query_shares",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("query_id", sa.Integer, nullable=False),
        sa.Column("shared_with", sa.String(100), nullable=False),
        sa.Column("permission", sa.String(50), default="view"),
        sa.Column("created_at", sa.DateTime),
        sa.Column("created_by", sa.String(100), nullable=True),
        if_not_exists=True,
    )

    # ── dashboard_shares ──────────────────────────────────────────────────
    op.create_table(
        "dashboard_shares",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("dashboard_id", sa.Integer, nullable=False),
        sa.Column("shared_with", sa.String(100), nullable=False),
        sa.Column("permission", sa.String(50), default="view"),
        sa.Column("created_at", sa.DateTime),
        sa.Column("created_by", sa.String(100), nullable=True),
        if_not_exists=True,
    )

    # ── embed_tokens ──────────────────────────────────────────────────────
    op.create_table(
        "embed_tokens",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("token", sa.String(255), unique=True, nullable=False),
        sa.Column("report_id", sa.Integer, nullable=False),
        sa.Column("created_by", sa.String(100), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("expires_at", sa.DateTime, nullable=True),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("access_count", sa.Integer, default=0),
        if_not_exists=True,
    )

    # ── registered_tables (S3/Iceberg table registry) ─────────────────────
    op.create_table(
        "registered_tables",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("connection_id", sa.Integer, nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("s3_prefix", sa.String(500), nullable=True),
        sa.Column("format", sa.String(50), default="parquet"),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("schema_cache", sa.JSON, nullable=True),
        if_not_exists=True,
    )

    # ── task_queue (DB-based queue backend) ───────────────────────────────
    op.create_table(
        "task_queue",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("task_id", sa.String(100), unique=True, nullable=False),
        sa.Column("task_type", sa.String(50), nullable=False),
        sa.Column("payload", sa.JSON, nullable=False),
        sa.Column("status", sa.String(50), default="pending"),
        sa.Column("priority", sa.Integer, default=0),
        sa.Column("created_at", sa.DateTime),
        sa.Column("claimed_at", sa.DateTime, nullable=True),
        sa.Column("completed_at", sa.DateTime, nullable=True),
        sa.Column("claimed_by", sa.String(100), nullable=True),
        sa.Column("result", sa.JSON, nullable=True),
        sa.Column("error", sa.Text, nullable=True),
        if_not_exists=True,
    )

    # ── lineage_edges ─────────────────────────────────────────────────────
    op.create_table(
        "lineage_edges",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("source_type", sa.String(50), nullable=False),
        sa.Column("source_id", sa.String(255), nullable=False),
        sa.Column("target_type", sa.String(50), nullable=False),
        sa.Column("target_id", sa.String(255), nullable=False),
        sa.Column("edge_type", sa.String(50), nullable=True),
        sa.Column("created_at", sa.DateTime),
        sa.Column("metadata", sa.JSON, nullable=True),
        if_not_exists=True,
    )


def downgrade() -> None:
    # Reverse order — drop all tables (destructive!)
    tables = [
        "lineage_edges", "task_queue", "registered_tables", "embed_tokens",
        "dashboard_shares", "query_shares", "notifications", "workspaces",
        "local_tables", "materialized_views", "sql_saved_queries",
        "dashboards", "schedules", "reports", "audit_log", "connections",
        "download_files", "query_executions", "saved_queries",
    ]
    for t in tables:
        op.drop_table(t)
