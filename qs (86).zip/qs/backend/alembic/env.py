"""
Phase 35D — Alembic environment configuration.

Reads the database URL from QueryStudio's config system (config.json / env vars)
so migrations work against the same database the application uses.

Supports both SQLite and PostgreSQL.

Usage:
    cd backend
    alembic upgrade head         # apply all migrations
    alembic revision --autogenerate -m "description"   # create new migration
    alembic history              # show migration history
"""

from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool, create_engine
from alembic import context
import os
import sys

# Add backend dir to path so core.* imports work
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.database import Base

# Alembic Config object
config = context.config

# Logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Target metadata for --autogenerate
target_metadata = Base.metadata


def _get_database_url() -> str:
    """Resolve DB URL from QueryStudio's layered config system."""
    # 1. Environment variable (highest priority — used in Docker/K8s)
    env_url = os.environ.get("QUERYSTUDIO_DB_URL")
    if env_url:
        return env_url

    # 2. Alembic INI sqlalchemy.url (if manually set for one-off migrations)
    ini_url = config.get_main_option("sqlalchemy.url")
    if ini_url and ini_url != "driver://user:pass@localhost/dbname":
        return ini_url

    # 3. QueryStudio config.json → paths.db_file
    try:
        from core.config import paths as _paths_cfg
        db_file = _paths_cfg.db_file
        if db_file:
            return f"sqlite:///{db_file}"
    except Exception:
        pass

    # 4. Default fallback — same as database.py
    default_db = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "querystudio.db",
    )
    return f"sqlite:///{default_db}"


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode — generate SQL script without connecting."""
    url = _get_database_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,  # Required for SQLite ALTER TABLE support
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode — connect to the database."""
    url = _get_database_url()
    connectable = create_engine(url)

    with connectable.connect() as connection:
        is_sqlite = url.startswith("sqlite")
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=is_sqlite,  # batch mode required for SQLite
            compare_type=True,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
