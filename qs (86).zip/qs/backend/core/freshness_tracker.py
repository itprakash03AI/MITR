"""
Freshness Tracker (Phase 52) — per-table data freshness monitoring.

Computes whether a table is fresh/stale based on how long ago it was last
observed in a lineage snapshot. Updates freshness records after each
execution snapshot is captured.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Freshness status values
FRESH   = "fresh"
STALE   = "stale"
UNKNOWN = "unknown"


def compute_freshness_status(last_observed_at: Optional[datetime],
                              stale_threshold_hours: int) -> str:
    """Return 'fresh', 'stale', or 'unknown' based on last observation time."""
    if last_observed_at is None:
        return UNKNOWN
    # Ensure timezone-aware
    if last_observed_at.tzinfo is None:
        last_observed_at = last_observed_at.replace(tzinfo=timezone.utc)
    age = datetime.now(timezone.utc) - last_observed_at
    return FRESH if age <= timedelta(hours=stale_threshold_hours) else STALE


def recompute_all_freshness_statuses(db_manager) -> int:
    """Recompute freshness_status for every DataFreshness row based on current time.

    Called periodically (e.g. on app startup or admin trigger) to update stale flags
    without needing a new execution to arrive.
    Returns number of records updated.
    """
    from core.database import DataFreshness  # local import to avoid circular

    updated = 0
    rows = db_manager.get_data_freshness()
    for row in rows:
        last_obs_str = row.get("last_observed_at")
        threshold    = row.get("stale_threshold_hours", 24)
        table_fqn    = row.get("table_fqn")
        if not table_fqn:
            continue
        if last_obs_str:
            try:
                last_obs = datetime.fromisoformat(last_obs_str.replace("Z", "+00:00"))
            except Exception:
                last_obs = None
        else:
            last_obs = None

        new_status = compute_freshness_status(last_obs, threshold)
        if new_status != row.get("freshness_status"):
            try:
                with db_manager.get_session() as session:
                    rec = session.query(DataFreshness).filter(
                        DataFreshness.table_fqn == table_fqn
                    ).first()
                    if rec:
                        rec.freshness_status = new_status
                        updated += 1
            except Exception as e:
                logger.warning("Failed to update freshness for %s: %s", table_fqn, e)
    return updated


def get_stale_tables(db_manager) -> List[Dict[str, Any]]:
    """Return all tables currently marked stale, recomputing statuses first."""
    recompute_all_freshness_statuses(db_manager)
    all_rows = db_manager.get_data_freshness()
    return [r for r in all_rows if r.get("freshness_status") == STALE]


def update_freshness_from_snapshot(db_manager, snapshot: Dict[str, Any],
                                    default_threshold_hours: int = 24) -> None:
    """After saving a lineage snapshot, mark all referenced tables as observed now.

    For each table in the snapshot, upsert a DataFreshness row with
    last_observed_at = now and status = 'fresh'.
    """
    if not snapshot:
        return
    data = snapshot.get("snapshot_data", {})
    tables = data.get("tables", [])
    connection_id = data.get("connection_id")

    for tbl in tables:
        table_fqn = _build_fqn(tbl)
        if not table_fqn:
            continue
        try:
            db_manager.upsert_data_freshness(
                table_fqn=table_fqn,
                connection_id=connection_id,
                stale_threshold_hours=default_threshold_hours,
            )
        except Exception as e:
            logger.warning("Failed to upsert freshness for %s: %s", table_fqn, e)


def _build_fqn(table_entry: Dict[str, Any]) -> str:
    """Build a fully-qualified table name from a lineage entry dict."""
    parts = []
    for key in ("table_catalog", "table_schema", "table_name"):
        v = table_entry.get(key)
        if v:
            parts.append(v)
    return ".".join(parts) if parts else ""
