"""
S3 utility functions — file listing, pre-signed URLs, hive partition extraction,
partition pruning, and S3 client factory.

Extracted from main.py for maintainability.

Usage:
    from core.s3_utilities import init_s3_utilities, list_s3_parquet_files, ...
    init_s3_utilities(conn_manager)   # call once at startup
"""
from __future__ import annotations

import logging
import time
from urllib.parse import urlparse, unquote, urlunparse

logger = logging.getLogger(__name__)

# ── Module-level dependency (set via init_s3_utilities) ──────────────────────
_conn_manager = None


def init_s3_utilities(conn_manager):
    """Inject the connection manager for S3 client factory."""
    global _conn_manager
    _conn_manager = conn_manager


# ── Hive partition helpers ───────────────────────────────────────────────────

def extract_hive_parts(path_str):
    """Extract hive partition key=value pairs from a path, excluding the filename.

    For 's3://bucket/data/year=2024/month=01/file.parquet' returns {'year':'2024','month':'01'}.
    Excludes the last segment (filename) to avoid misinterpreting filenames with '='.
    Skips protocol prefix segments (e.g. 's3:').
    """
    segments = path_str.split("/")
    # Exclude last segment (the filename, e.g. 'data.parquet')
    dirs = segments[:-1] if len(segments) > 1 else []
    parts = {}
    for seg in dirs:
        if "=" in seg and not seg.endswith(":"):  # skip 's3:'
            k, v = seg.split("=", 1)
            parts[k] = v
    return parts


def filter_iceberg_files_by_partitions(data_files, partition_filters):
    """Filter Iceberg data files by partition values found in S3 key paths.

    Each file key has hive-style paths like .../year=2024/month=01/file.parquet.
    Matches query filters against those partition segments.
    """
    if not partition_filters or not data_files:
        return data_files

    # Detect which filter columns are actual hive partition columns by
    # inspecting the first file's path segments.
    _sample_key = data_files[0]["key"] if isinstance(data_files[0], dict) else data_files[0]
    _partition_cols = set(extract_hive_parts(_sample_key).keys())
    _filter_hits_partition = any(pf["col"] in _partition_cols for pf in partition_filters)

    filtered = []
    for f in data_files:
        key = f["key"] if isinstance(f, dict) else f
        parts = extract_hive_parts(key)
        match = True
        for pf in partition_filters:
            col = pf["col"]
            if col not in parts:
                continue
            fv = parts[col]
            op = pf["op"]
            val = pf["val"]
            if op == "equals" and str(fv) != str(val):
                match = False; break
            elif op == "not_equals" and str(fv) == str(val):
                match = False; break
            elif op == "in" and str(fv) not in [str(v) for v in val]:
                match = False; break
            elif op == "greater_than" and not (str(fv) > str(val)):
                match = False; break
            elif op == "less_than" and not (str(fv) < str(val)):
                match = False; break
            elif op == "greater_equals" and not (str(fv) >= str(val)):
                match = False; break
            elif op == "less_equals" and not (str(fv) <= str(val)):
                match = False; break
        if match:
            filtered.append(f)

    if not filtered and _filter_hits_partition:
        _matched_cols = [pf["col"] for pf in partition_filters if pf["col"] in _partition_cols]
        logger.info("Partition pruning: 0/%d files match filter on partition column(s) %s — "
                     "no data exists for the requested values",
                     len(data_files), _matched_cols)
        return []

    return filtered if filtered else data_files


def extract_partition_filters_from_query(query_config):
    """Extract partition filter dicts from a query config's filters list."""
    if not query_config or not hasattr(query_config, "filters") or not query_config.filters:
        return None
    _OP_MAP = {
        "equals": "equals", "eq": "equals", "=": "equals",
        "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
        "greater_than": "greater_than", "gt": "greater_than", ">": "greater_than",
        "less_than": "less_than", "lt": "less_than", "<": "less_than",
        "greater_equals": "greater_equals", "gte": "greater_equals", ">=": "greater_equals",
        "less_equals": "less_equals", "lte": "less_equals", "<=": "less_equals",
    }
    pf = []
    for flt in query_config.filters:
        f_op = flt["operator"] if isinstance(flt, dict) else flt.operator
        f_col = flt["column"] if isinstance(flt, dict) else flt.column
        f_val = flt["value"] if isinstance(flt, dict) else flt.value
        if f_op == "in" and isinstance(f_val, list) and len(f_val) > 0:
            pf.append({"col": f_col, "op": "in", "val": f_val})
        else:
            mapped = _OP_MAP.get(f_op)
            if mapped and f_val is not None:
                pf.append({"col": f_col, "op": mapped, "val": f_val})
    return pf or None


# ── S3 file listing ──────────────────────────────────────────────────────────

def list_s3_parquet_files(s3_client, bucket: str, prefix: str, max_files: int = 5000) -> list:
    """Recursively list all .parquet files under an S3 prefix using boto3.

    Uses boto3 paginator (robust, no C-level crash risk) instead of DuckDB's
    httpfs glob ('**/*.parquet') which can crash on on-prem S3 with many partitions.
    Returns list of 's3://bucket/key' strings.
    """
    files = []
    paginator = s3_client.get_paginator("list_objects_v2")
    clean_prefix = prefix.rstrip("/") + "/" if prefix else ""
    for page in paginator.paginate(Bucket=bucket, Prefix=clean_prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.lower().endswith(".parquet") and not key.split("/")[-1].startswith("."):
                files.append(f"s3://{bucket}/{key}")
                if len(files) >= max_files:
                    logger.warning("list_s3_parquet_files: hit %d file cap for %s/%s",
                                   max_files, bucket, prefix)
                    return files
    return files


def s3_urls_to_presigned(s3_client, file_urls, conn_config, expiry=3600):
    """Convert s3:// URLs to pre-signed HTTPS URLs for on-prem S3 connections.

    On-prem S3 servers (MinIO, NetApp, Ceph) may reject DuckDB httpfs requests
    where '=' in hive partition paths gets URL-encoded to '%3D', causing
    SignatureDoesNotMatch errors.

    Pre-signed URLs embed auth in query parameters, so DuckDB reads them
    as plain HTTPS — bypassing S3 auth and the encoding issue entirely.

    Only converts when path_style=True (on-prem indicator).
    Returns URLs unchanged for standard AWS S3.
    """
    if not conn_config.get("path_style", False):
        return file_urls
    if not file_urls:
        return file_urls
    if s3_client is None:
        logger.warning("s3_urls_to_presigned: s3_client is None — returning original URLs")
        return file_urls

    presigned = []
    _converted = 0
    _failed = 0
    for url in file_urls:
        if not url.startswith("s3://"):
            presigned.append(url)
            continue
        parts = url[5:].split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else ""
        if not key:
            logger.warning("s3_urls_to_presigned: empty key in URL %s — skipping", url)
            presigned.append(url)
            _failed += 1
            continue
        try:
            ps_url = s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": key},
                ExpiresIn=expiry,
            )
            # boto3 URL-encodes '=' to '%3D' in the URL path.  DuckDB's
            # hive_partitioning=true needs literal '=' in path segments
            # (e.g. year=2024/month=01/) to detect partition columns.
            # Decode the path portion only — leave query string untouched.
            # SigV4 verification is safe: the server re-encodes the path
            # to canonical form before checking the signature.
            parsed = urlparse(ps_url)
            decoded_path = unquote(parsed.path)
            if decoded_path != parsed.path:
                ps_url = urlunparse((parsed.scheme, parsed.netloc, decoded_path,
                                     parsed.params, parsed.query, parsed.fragment))
            presigned.append(ps_url)
            _converted += 1
        except Exception as _ps_exc:
            logger.warning("s3_urls_to_presigned: signing failed for %s: %s", url, _ps_exc)
            presigned.append(url)
            _failed += 1

    if _failed:
        logger.warning("Pre-signed URL conversion: %d succeeded, %d failed out of %d",
                        _converted, _failed, len(file_urls))
    else:
        logger.info("Converted %d s3:// URLs to pre-signed HTTPS for on-prem S3", _converted)
    return presigned


# ── S3 client factory ────────────────────────────────────────────────────────

def make_s3_client_for_conn(conn_raw: dict, portal_username: str = ""):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.

    AWS portal credentials are injected automatically if the portal is
    enabled and the user has cached creds (via context var or explicit param).
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # ── Inject AWS portal credentials if available ────────────────────────
    _portal_user = portal_username
    if not _portal_user:
        try:
            from core.aws_portal_auth import _current_portal_user
            _portal_user = _current_portal_user.get("")
        except Exception:
            pass
    if _portal_user:
        try:
            from core.aws_portal_auth import inject_portal_creds
            cfg = inject_portal_creds(cfg, _portal_user)
        except Exception as _pe:
            logger.debug("Portal creds injection skipped: %s", _pe)

    # Try the cached handler first — same client the file browser uses
    # Skip cache when portal creds are injected (they're per-user + ephemeral)
    if conn_id is not None and not _portal_user:
        try:
            handler = _conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler and cache it to avoid leaking clients
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        # Cache in connection manager so subsequent calls reuse it
        # Don't cache portal-injected handlers (per-user, ephemeral creds)
        if conn_id is not None and not _portal_user:
            try:
                _conn_manager._s3_handlers[conn_id] = (handler, time.monotonic())
            except Exception:
                pass
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise
