"""
Iceberg file cache, schema cache, and partition cache.

All three caches use L1 in-memory (short TTL) + optional L2 SQLite (long TTL).
Extracted from main.py for maintainability.

Usage:
    from core.iceberg_cache import init_iceberg_cache, ice_cache_get, ...
    init_iceberg_cache(db_manager)   # call once at startup
"""
from __future__ import annotations

import json as _json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

from core.config import partition_cache as _pcache_cfg

logger = logging.getLogger(__name__)

# ── Module-level db_manager (set via init_iceberg_cache) ─────────────────────
_db_manager = None


def init_iceberg_cache(db_manager):
    """Inject the database manager for L2 cache operations."""
    global _db_manager
    _db_manager = db_manager


# ══════════════════════════════════════════════════════════════════════════════
# Iceberg data-file cache: L1 in-memory (5 min) + L2 SQLite (5 hours)
# Avoids re-scanning S3 manifests.  L2 survives server restarts.
# Key: (connection_id, table_name, filters_hash)  →  (active_files, metadata, ts)
# ══════════════════════════════════════════════════════════════════════════════

ICE_FILE_CACHE: Dict[tuple, dict] = {}
ICE_FILE_CACHE_TTL = 300       # L1: 5 minutes (in-memory hot cache)
ICE_FILE_CACHE_L2_TTL = 18000  # L2: 5 hours (persistent SQLite cache)


def ice_cache_key(connection_id, tname, partition_filters):
    pf_str = _json.dumps(partition_filters, sort_keys=True, default=str) if partition_filters else ""
    return (connection_id, tname, pf_str)


def ice_cache_get(key):
    """L1 + L2 lookup.  Returns dict or None."""
    # L1 check — fast in-memory
    entry = ICE_FILE_CACHE.get(key)
    if entry and (time.monotonic() - entry["ts"]) < ICE_FILE_CACHE_TTL:
        return entry
    if entry:
        del ICE_FILE_CACHE[key]

    # L2 check — persistent SQLite
    connection_id, table_name, filters_hash = key
    try:
        db_entry = _db_manager.get_iceberg_file_cache(connection_id, table_name, filters_hash)
        if db_entry:
            updated = datetime.fromisoformat(db_entry["updated_at"]).replace(tzinfo=timezone.utc) \
                      if isinstance(db_entry["updated_at"], str) else db_entry["updated_at"]
            if updated and (datetime.now(timezone.utc) - updated).total_seconds() < ICE_FILE_CACHE_L2_TTL:
                # Promote to L1
                result = {"files": db_entry["file_list"], "metadata": None, "ts": time.monotonic()}
                ICE_FILE_CACHE[key] = result
                logger.debug("Iceberg file cache L2 hit: %s/%s (%d files)",
                             table_name, filters_hash[:30], len(db_entry["file_list"]))
                return result
    except Exception as exc:
        logger.warning("Iceberg file cache L2 read error: %s", exc)

    return None


def ice_cache_set(key, active_files, metadata, record_count=0):
    """Store in L1 + L2."""
    # L1 store
    ICE_FILE_CACHE[key] = {"files": active_files, "metadata": metadata, "ts": time.monotonic(), "record_count": record_count}
    # Evict stale L1 entries (max 200)
    if len(ICE_FILE_CACHE) > 200:
        now = time.monotonic()
        stale = [k for k, v in ICE_FILE_CACHE.items() if now - v["ts"] > ICE_FILE_CACHE_TTL]
        for k in stale:
            ICE_FILE_CACHE.pop(k, None)

    # L2 store — persistent SQLite
    connection_id, table_name, filters_hash = key
    try:
        _db_manager.set_iceberg_file_cache(connection_id, table_name, filters_hash, active_files)
    except Exception as exc:
        logger.warning("Iceberg file cache L2 write error: %s", exc)


# ══════════════════════════════════════════════════════════════════════════════
# Schema cache: L1 in-memory only (10 min TTL)
# ══════════════════════════════════════════════════════════════════════════════

_schema_cache: Dict[str, Tuple[float, dict]] = {}
_schema_cache_lock = threading.Lock()
SCHEMA_L1_TTL = 600   # 10 minutes


def schema_cache_get(key: str) -> Optional[dict]:
    with _schema_cache_lock:
        if key in _schema_cache:
            ts, result = _schema_cache[key]
            if time.time() - ts < SCHEMA_L1_TTL:
                return result
    return None


def schema_cache_set(key: str, result: dict):
    with _schema_cache_lock:
        if len(_schema_cache) > 200:
            oldest = min(_schema_cache, key=lambda k: _schema_cache[k][0])
            del _schema_cache[oldest]
        _schema_cache[key] = (time.time(), result)


# ══════════════════════════════════════════════════════════════════════════════
# Partition cache: L1 in-memory (configurable) + L2 SQLite (configurable)
# ══════════════════════════════════════════════════════════════════════════════

_partition_cache: Dict[str, Tuple[float, dict]] = {}
_partition_cache_lock = threading.Lock()


def _partition_l1_ttl() -> int:
    return _pcache_cfg.l1_ttl_seconds


def _partition_l2_ttl() -> int:
    return _pcache_cfg.l2_ttl_seconds


def _partition_cache_max() -> int:
    return _pcache_cfg.max_entries


def partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns (hit, result)."""
    with _partition_cache_lock:
        if cache_key in _partition_cache:
            ts, result = _partition_cache[cache_key]
            if time.time() - ts < _partition_l1_ttl():
                return True, result
    return False, None


def partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    with _partition_cache_lock:
        if len(_partition_cache) >= _partition_cache_max():
            oldest = min(_partition_cache, key=lambda k: _partition_cache[k][0])
            del _partition_cache[oldest]
        _partition_cache[cache_key] = (time.time(), result)


def partition_l2_get(connection_id: int, table_name: str, scan_type: str):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = _db_manager.get_partition_cache(connection_id, table_name, scan_type)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _partition_l2_ttl():
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def partition_store(connection_id: int, table_name: str, scan_type: str,
                    cache_key: str, result: dict):
    """Store in both L1 + L2.  Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    partition_l1_set(cache_key, stamped)
    _db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped)
