"""
SQL Lineage Parser (Phase 49) — AST-based table/column extraction via sqlglot.

Extracts physical table references from SQL text, with fallback to regex
when sqlglot fails. Supports DuckDB, Trino, Snowflake, Databricks, Oracle dialects.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, asdict
from typing import List, Optional

logger = logging.getLogger(__name__)

# ── Data classes ─────────────────────────────────────────────────────────────

@dataclass
class TableRef:
    catalog: Optional[str]
    schema: Optional[str]
    table: str
    access_type: str = "read"   # "read" | "write"
    alias: Optional[str] = None


@dataclass
class ColumnRef:
    """Column-level lineage entry (Phase 51 — stubbed here for forward compat)."""
    source_table: Optional[str]
    source_column: Optional[str]
    target_column: str
    transform_type: str = "direct"  # direct|renamed|computed|aggregated|casted|star_expansion
    transform_expr: Optional[str] = None


# ── Dialect mapping ──────────────────────────────────────────────────────────

_DIALECT_MAP = {
    "s3": "duckdb",
    "local": "duckdb",
    "duckdb": "duckdb",
    "trino": "trino",
    "snowflake": "snowflake",
    "databricks": "databricks",
    "oracle": "oracle",
}


def dialect_for_connection_type(connection_type: str) -> str:
    return _DIALECT_MAP.get((connection_type or "").lower(), "duckdb")


# ── Regex fallback (from reports_api.py) ─────────────────────────────────────

_REGEX_TABLE_PATTERN = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?\s*\.\s*"?(\w+)"?\s*\.\s*"?(\w+)"?',
    re.IGNORECASE,
)

_REGEX_TABLE_2PART = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?\s*\.\s*"?(\w+)"?'
    r'(?!\s*\.)',  # negative lookahead to skip 3-part matches
    re.IGNORECASE,
)

_REGEX_TABLE_1PART = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'"?(\w+)"?'
    r'(?!\s*\.)',
    re.IGNORECASE,
)


def _extract_table_refs_regex(sql: str) -> List[TableRef]:
    """Regex-based fallback extraction of table references."""
    refs: List[TableRef] = []
    seen = set()
    # 3-part: catalog.schema.table
    for m in _REGEX_TABLE_PATTERN.finditer(sql):
        key = (m.group(1), m.group(2), m.group(3))
        if key not in seen:
            seen.add(key)
            refs.append(TableRef(catalog=m.group(1), schema=m.group(2), table=m.group(3)))
    # 2-part: schema.table
    for m in _REGEX_TABLE_2PART.finditer(sql):
        key = (None, m.group(1), m.group(2))
        if key not in seen:
            seen.add(key)
            refs.append(TableRef(catalog=None, schema=m.group(1), table=m.group(2)))
    return refs


# ── sqlglot-based extraction ─────────────────────────────────────────────────

def extract_table_refs(sql: str, dialect: str = "duckdb") -> List[TableRef]:
    """Parse SQL via sqlglot AST and return all physical table references.

    Handles FROM, JOIN, CTE (excluded from results), subqueries,
    INSERT INTO (write), CREATE TABLE AS (write).
    Falls back to regex on parse failure.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        logger.warning("sqlglot not installed — using regex fallback")
        return _extract_table_refs_regex(sql)

    try:
        parsed = sqlglot.parse(sql, dialect=dialect, error_level=sqlglot.ErrorLevel.WARN)
    except Exception as e:
        logger.debug("sqlglot parse failed (%s), falling back to regex: %s", dialect, e)
        return _extract_table_refs_regex(sql)

    refs: List[TableRef] = []
    seen = set()

    for statement in parsed:
        if statement is None:
            continue

        # Collect CTE names so we can exclude them from physical table refs
        cte_names = set()
        for cte in statement.find_all(exp.CTE):
            alias_node = cte.args.get("alias")
            if alias_node:
                cte_names.add(alias_node.name.lower())

        # Determine write targets
        write_tables = set()
        for insert in statement.find_all(exp.Insert):
            tbl = insert.find(exp.Table)
            if tbl:
                write_tables.add(_table_key(tbl))
        for create in statement.find_all(exp.Create):
            tbl = create.find(exp.Table)
            if tbl:
                write_tables.add(_table_key(tbl))

        # Walk all Table nodes
        for tbl in statement.find_all(exp.Table):
            name = tbl.name
            if not name or name.lower() in cte_names:
                continue

            catalog = tbl.catalog or None
            schema = tbl.db or None
            alias = tbl.alias or None
            key = (catalog, schema, name)

            if key in seen:
                continue
            seen.add(key)

            access = "write" if _table_key(tbl) in write_tables else "read"
            refs.append(TableRef(
                catalog=catalog,
                schema=schema,
                table=name,
                access_type=access,
                alias=alias,
            ))

    return refs


def _table_key(tbl) -> str:
    parts = [tbl.catalog or "", tbl.db or "", tbl.name or ""]
    return ".".join(p.lower() for p in parts)


def extract_column_refs(sql: str, dialect: str = "duckdb") -> List[ColumnRef]:
    """Extract column-level lineage using sqlglot.lineage (Phase 51).

    For each SELECT output column, determines:
      - source table + source column
      - transformation type (direct, renamed, computed, aggregated, casted, star_expansion)
      - transform expression (for computed / casted columns)

    Falls back to best-effort AST walking when sqlglot.lineage is unavailable.
    Returns empty list on any parse failure.
    """
    if not sql or not sql.strip():
        return []
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return []

    refs: List[ColumnRef] = []

    try:
        # ── Try sqlglot.lineage (available in sqlglot >= 18) ──────────────────
        try:
            from sqlglot import lineage as sg_lineage

            parsed = sqlglot.parse_one(sql, dialect=dialect,
                                       error_level=sqlglot.ErrorLevel.WARN)
            if parsed is None:
                return []

            # Walk SELECT expressions
            select_exprs = parsed.find(exp.Select)
            if select_exprs is None:
                return []

            for sel_col in select_exprs.expressions:
                target_col = _alias_or_name(sel_col)
                if not target_col:
                    continue

                # Determine transform type
                transform_type, transform_expr = _classify_transform(sel_col)

                # For star expansions
                if isinstance(sel_col, exp.Star):
                    refs.append(ColumnRef(
                        source_table=None,
                        source_column="*",
                        target_column="*",
                        transform_type="star_expansion",
                        transform_expr=None,
                    ))
                    continue

                # Try to resolve the column source via lineage node
                try:
                    node = sg_lineage.lineage(
                        target_col, parsed,
                        dialect=dialect,
                    )
                    _walk_lineage_node(node, target_col, transform_type, transform_expr, refs)
                except Exception:
                    # Fallback: extract column references directly from the expression
                    _extract_col_from_expr(sel_col, target_col, transform_type, transform_expr, refs)

        except (ImportError, AttributeError):
            # sqlglot.lineage not available — use AST walk fallback
            _extract_cols_ast_fallback(sql, dialect, refs)

    except Exception as e:
        logger.debug("Column lineage extraction failed: %s", e, exc_info=True)

    # Deduplicate by (source_table, source_column, target_column)
    seen: set = set()
    deduped: List[ColumnRef] = []
    for r in refs:
        key = (r.source_table, r.source_column, r.target_column)
        if key not in seen:
            seen.add(key)
            deduped.append(r)
    return deduped


def _alias_or_name(expr) -> Optional[str]:
    """Return alias if present, otherwise column name."""
    from sqlglot import expressions as exp
    if hasattr(expr, 'alias') and expr.alias:
        return expr.alias
    if isinstance(expr, exp.Column):
        return expr.name
    if hasattr(expr, 'name') and expr.name:
        return expr.name
    return None


def _classify_transform(expr) -> tuple:
    """Classify an expression as direct/renamed/computed/aggregated/casted/star_expansion."""
    from sqlglot import expressions as exp

    has_alias = bool(getattr(expr, 'alias', None))
    inner = expr.this if hasattr(expr, 'this') and has_alias else expr

    if isinstance(inner, exp.Star):
        return "star_expansion", None
    if isinstance(inner, (exp.Avg, exp.Sum, exp.Max, exp.Min, exp.Count,
                          exp.Stddev, exp.Variance, exp.ApproxDistinct)):
        return "aggregated", inner.sql()
    if isinstance(inner, exp.Cast):
        return "casted", inner.sql()
    if isinstance(inner, exp.Column):
        return ("renamed" if has_alias else "direct"), None
    if isinstance(inner, exp.Anonymous):
        return "computed", inner.sql()
    # Any other expression with operations
    if inner and inner.find(exp.Add, exp.Sub, exp.Mul, exp.Div, exp.Concat):
        return "computed", inner.sql()
    if has_alias:
        return "renamed", None
    return "direct", None


def _walk_lineage_node(node, target_col: str, transform_type: str,
                        transform_expr: Optional[str], refs: List[ColumnRef]) -> None:
    """Recursively walk a sqlglot lineage node tree to find leaf sources."""
    try:
        # Leaf node with a table source
        if not node.downstream:
            table = getattr(node, 'table', None)
            col = getattr(node, 'name', None) or target_col
            refs.append(ColumnRef(
                source_table=table,
                source_column=col,
                target_column=target_col,
                transform_type=transform_type,
                transform_expr=transform_expr,
            ))
        else:
            for child in node.downstream:
                _walk_lineage_node(child, target_col, transform_type, transform_expr, refs)
    except Exception:
        refs.append(ColumnRef(
            source_table=None,
            source_column=None,
            target_column=target_col,
            transform_type=transform_type,
            transform_expr=transform_expr,
        ))


def _extract_col_from_expr(expr, target_col: str, transform_type: str,
                             transform_expr: Optional[str], refs: List[ColumnRef]) -> None:
    """AST fallback: find Column nodes inside expression."""
    from sqlglot import expressions as exp
    col_nodes = list(expr.find_all(exp.Column))
    if col_nodes:
        for col_node in col_nodes:
            table_ref = col_node.table or None
            refs.append(ColumnRef(
                source_table=table_ref,
                source_column=col_node.name,
                target_column=target_col,
                transform_type=transform_type,
                transform_expr=transform_expr,
            ))
    else:
        refs.append(ColumnRef(
            source_table=None,
            source_column=None,
            target_column=target_col,
            transform_type=transform_type,
            transform_expr=transform_expr,
        ))


def _extract_cols_ast_fallback(sql: str, dialect: str, refs: List[ColumnRef]) -> None:
    """Full fallback: walk SELECT AST and extract all column references."""
    try:
        import sqlglot
        from sqlglot import expressions as exp
        parsed = sqlglot.parse_one(sql, dialect=dialect,
                                    error_level=sqlglot.ErrorLevel.WARN)
        if parsed is None:
            return
        select_node = parsed.find(exp.Select)
        if select_node is None:
            return
        for sel_col in select_node.expressions:
            target = _alias_or_name(sel_col) or "unknown"
            transform_type, transform_expr = _classify_transform(sel_col)
            _extract_col_from_expr(sel_col, target, transform_type, transform_expr, refs)
    except Exception:
        pass


# ── Persistence helper ───────────────────────────────────────────────────────

def extract_and_store_lineage(
    db_manager,
    query_type: str,
    query_id: int,
    sql_text: str,
    connection_id: Optional[int] = None,
    connection_type: str = "duckdb",
) -> None:
    """Parse SQL, extract table refs, persist to DB. Fire-and-forget (swallows errors)."""
    try:
        from core.config import lineage as _lineage_cfg
        if not _lineage_cfg.auto_extract:
            return
    except Exception:
        pass  # config not available — proceed with extraction

    try:
        dialect = dialect_for_connection_type(connection_type)
        refs = extract_table_refs(sql_text, dialect)

        entries = []
        for r in refs:
            entries.append({
                "query_type": query_type,
                "query_id": query_id,
                "connection_id": connection_id,
                "table_catalog": r.catalog,
                "table_schema": r.schema,
                "table_name": r.table,
                "access_type": r.access_type,
                "extraction_method": "sqlglot",
            })

        if entries:
            db_manager.upsert_table_lineage(query_type, query_id, entries)
        else:
            # No refs found — try regex fallback
            try:
                from core.config import lineage as _lineage_cfg
                if not _lineage_cfg.fallback_regex:
                    return
            except Exception:
                pass

            regex_refs = _extract_table_refs_regex(sql_text)
            fallback_entries = []
            for r in regex_refs:
                fallback_entries.append({
                    "query_type": query_type,
                    "query_id": query_id,
                    "connection_id": connection_id,
                    "table_catalog": r.catalog,
                    "table_schema": r.schema,
                    "table_name": r.table,
                    "access_type": r.access_type,
                    "extraction_method": "regex_fallback",
                })
            if fallback_entries:
                db_manager.upsert_table_lineage(query_type, query_id, fallback_entries)

        # ── Phase 51: column-level lineage (best-effort) ──────────────────────
        if query_type == "sql_query":
            try:
                col_refs = extract_column_refs(sql_text, dialect)
                if col_refs:
                    col_entries = [
                        {
                            "source_table": r.source_table,
                            "source_column": r.source_column,
                            "target_column": r.target_column,
                            "transform_type": r.transform_type,
                            "transform_expr": r.transform_expr,
                        }
                        for r in col_refs
                    ]
                    db_manager.upsert_column_lineage(query_type, query_id, col_entries)
            except Exception:
                logger.debug("Column lineage extraction failed for %s:%s", query_type, query_id, exc_info=True)

    except Exception:
        logger.debug("Lineage extraction failed for %s:%s", query_type, query_id, exc_info=True)


def table_ref_to_dict(ref: TableRef) -> dict:
    return asdict(ref)


def capture_execution_lineage_snapshot(
    db_manager,
    execution_id: str,
    query_type: str,
    query_id: int,
    connection_id: Optional[int] = None,
) -> Optional[dict]:
    """Capture a point-in-time lineage snapshot for an execution (Phase 52).

    Reads the current table + column lineage entries for this query and saves
    them as an immutable snapshot. Also updates DataFreshness for all tables.

    Returns the saved snapshot dict, or None if disabled / nothing to snapshot.
    """
    try:
        from core import config as _cfg
        if not _cfg.lineage.snapshots_enabled:
            return None

        tables = db_manager.get_table_lineage_for_query(query_type, query_id)
        columns: list = []
        if query_type == "sql_query":
            columns = db_manager.get_column_lineage_for_query(query_type, query_id)

        if not tables and not columns:
            return None

        snapshot_data = {
            "query_type": query_type,
            "query_id": query_id,
            "connection_id": connection_id,
            "tables": tables,
            "columns": columns,
            "table_count": len(tables),
            "column_count": len(columns),
        }
        snapshot = db_manager.save_lineage_snapshot(
            execution_id=execution_id,
            query_type=query_type,
            query_id=query_id,
            snapshot_data=snapshot_data,
        )

        # Update freshness for all tables seen in this execution
        if _cfg.lineage.freshness_enabled:
            from core.freshness_tracker import update_freshness_from_snapshot
            update_freshness_from_snapshot(
                db_manager, snapshot,
                default_threshold_hours=_cfg.lineage.default_stale_threshold_hours,
            )

        # Prune old snapshots
        retention = _cfg.lineage.snapshot_retention_days
        if retention > 0:
            db_manager.delete_old_lineage_snapshots(older_than_days=retention)

        return snapshot

    except Exception:
        logger.debug("Lineage snapshot capture failed for execution %s", execution_id, exc_info=True)
        return None
