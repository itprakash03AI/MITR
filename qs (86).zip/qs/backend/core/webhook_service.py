"""
Webhook Notification Service — stdlib urllib only, zero extra dependencies.

Supports:
  - Slack Incoming Webhooks (attachment format)
  - Microsoft Teams (MessageCard / Adaptive Card format)
  - Generic HTTP POST (JSON body)

Called by scheduler.py on schedule completion/failure.
"""
from __future__ import annotations

import ipaddress
import json
import logging
import socket
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


def _is_ssrf_safe(url: str) -> bool:
    """Block requests to private/internal networks (SSRF protection)."""
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname
        if not hostname:
            return False
        # Resolve hostname to IP and check against private ranges
        for info in socket.getaddrinfo(hostname, parsed.port or 443, proto=socket.IPPROTO_TCP):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                logger.warning("[ssrf] Blocked request to internal IP %s (host: %s)", ip, hostname)
                return False
        return True
    except (socket.gaierror, ValueError, OSError) as exc:
        logger.warning("[ssrf] DNS resolution failed for %s: %s", url[:80], exc)
        return False


# ── Payload builders ───────────────────────────────────────────────────────────

def _slack_payload(
    schedule_name: str,
    status: str,
    output_file: Optional[str],
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
    run_at: Optional[str],
) -> dict:
    ok     = status == "completed"
    color  = "#36a64f" if ok else "#dc3545"
    emoji  = ":white_check_mark:" if ok else ":x:"
    title  = f"{emoji} Schedule *{schedule_name}* — {'Completed' if ok else 'Failed'}"

    fields = []
    if run_at:
        fields.append({"title": "Run At",   "value": run_at[:19].replace("T", " "), "short": True})
    if row_count is not None:
        fields.append({"title": "Rows",     "value": f"{row_count:,}", "short": True})
    if duration_seconds is not None:
        fields.append({"title": "Duration", "value": f"{duration_seconds:.1f}s", "short": True})
    if output_file:
        fname = output_file.replace("\\", "/").rsplit("/", 1)[-1]
        fields.append({"title": "Output",   "value": fname, "short": False})
    if not ok and error_message:
        fields.append({"title": "Error",    "value": error_message[:300], "short": False})

    return {
        "text": title,
        "attachments": [{
            "color":    color,
            "fields":   fields,
            "footer":   "QueryStudio",
            "ts":       int(datetime.now(timezone.utc).timestamp()),
        }],
    }


def _teams_payload(
    schedule_name: str,
    status: str,
    output_file: Optional[str],
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
    run_at: Optional[str],
) -> dict:
    ok    = status == "completed"
    color = "00b050" if ok else "dc3545"
    facts = []
    if run_at:
        facts.append({"name": "Run At",   "value": run_at[:19].replace("T", " ")})
    if row_count is not None:
        facts.append({"name": "Rows",     "value": str(row_count)})
    if duration_seconds is not None:
        facts.append({"name": "Duration", "value": f"{duration_seconds:.1f}s"})
    if output_file:
        fname = output_file.replace("\\", "/").rsplit("/", 1)[-1]
        facts.append({"name": "Output",   "value": fname})
    if not ok and error_message:
        facts.append({"name": "Error",    "value": error_message[:300]})

    return {
        "@type":    "MessageCard",
        "@context": "http://schema.org/extensions",
        "themeColor": color,
        "summary":  f"QueryStudio: {schedule_name} {status}",
        "sections": [{
            "activityTitle":    f"Schedule **{schedule_name}** {'✅ Completed' if ok else '❌ Failed'}",
            "activitySubtitle": "QueryStudio Automated Notification",
            "facts":            facts,
        }],
    }


def _detect_platform(url: str) -> str:
    """Heuristic: 'slack' | 'teams' | 'generic'."""
    lower = url.lower()
    if "hooks.slack.com" in lower or "slack.com/services" in lower:
        return "slack"
    if "webhook.office.com" in lower or "outlook.office.com" in lower:
        return "teams"
    return "generic"


# ── Public API ─────────────────────────────────────────────────────────────────

def fire_webhook(
    webhook_url: str,
    schedule_name: str,
    status: str,
    output_file: Optional[str] = None,
    row_count: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    error_message: Optional[str] = None,
    run_at: Optional[str] = None,
    timeout: int = 10,
    max_retries: int = 3,
    retry_delay: float = 1.0,
) -> bool:
    """POST webhook payload with exponential-backoff retry.

    Handles HTTP 429 (rate-limit) with Retry-After header.
    Returns True on success, False after all retries exhausted. Never raises.
    """
    import time as _time

    if not webhook_url or not webhook_url.startswith(("http://", "https://")):
        logger.warning("[webhook] Invalid URL — skipping")
        return False

    if not _is_ssrf_safe(webhook_url):
        logger.warning("[webhook] SSRF blocked for URL: %s", webhook_url[:80])
        return False

    platform = _detect_platform(webhook_url)
    kwargs   = dict(schedule_name=schedule_name, status=status, output_file=output_file,
                    row_count=row_count, duration_seconds=duration_seconds,
                    error_message=error_message, run_at=run_at)

    if platform == "teams":
        payload = _teams_payload(**kwargs)
    else:
        payload = _slack_payload(**kwargs)  # Slack format works as generic JSON too

    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        webhook_url, data=body,
        headers={"Content-Type": "application/json", "User-Agent": "QueryStudio/2.0"},
        method="POST",
    )

    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                logger.info("[webhook] %s → HTTP %d (%s) (attempt %d/%d)",
                            webhook_url[:60], resp.status, platform, attempt + 1, max_retries)
                return True
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                # Rate-limited — respect Retry-After header
                retry_after = retry_delay * (2 ** attempt)
                try:
                    retry_after = min(float(exc.headers.get("Retry-After", retry_after)), 30)
                except (ValueError, TypeError):
                    pass
                logger.warning("[webhook] 429 rate-limited, retrying in %.1fs (attempt %d/%d)",
                               retry_after, attempt + 1, max_retries)
                _time.sleep(retry_after)
                continue
            if exc.code >= 500 and attempt < max_retries - 1:
                delay = retry_delay * (2 ** attempt)
                logger.warning("[webhook] HTTP %d, retrying in %.1fs (attempt %d/%d)",
                               exc.code, delay, attempt + 1, max_retries)
                _time.sleep(delay)
                continue
            # 4xx (not 429) — don't retry, it's a permanent error
            logger.warning("[webhook] HTTP %d from %s: %s (attempt %d/%d)",
                           exc.code, webhook_url[:60], exc.reason, attempt + 1, max_retries)
            return False
        except urllib.error.URLError as exc:
            if attempt < max_retries - 1:
                delay = retry_delay * (2 ** attempt)
                logger.warning("[webhook] URL error, retrying in %.1fs (attempt %d/%d): %s",
                               delay, attempt + 1, max_retries, exc.reason)
                _time.sleep(delay)
                continue
            logger.warning("[webhook] URL error after %d attempts: %s", max_retries, exc.reason)
        except Exception as exc:
            if attempt < max_retries - 1:
                delay = retry_delay * (2 ** attempt)
                _time.sleep(delay)
                continue
            logger.warning("[webhook] Failed after %d attempts: %s", max_retries, exc)

    return False


def test_webhook(webhook_url: str) -> dict:
    """Send a test notification. Returns {success, message}."""
    ok = fire_webhook(
        webhook_url,
        schedule_name="Test Schedule",
        status="completed",
        row_count=42,
        duration_seconds=1.5,
        run_at=datetime.now(timezone.utc).isoformat(),
    )
    return {
        "success": ok,
        "message": "Test notification sent successfully" if ok else "Failed to reach webhook URL",
    }
