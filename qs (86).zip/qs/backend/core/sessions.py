"""
Session store — server-side opaque token cache.

Extracted from main.py so that any module (auth router, deps, embed API)
can create/validate/destroy sessions without importing main.py.

Sessions are held in memory with a TTL.  No passwords are ever stored —
only the resolved user-info dict from the initial AD/local authenticate_user call.
"""
import secrets
import time
import threading
from typing import Optional, Dict

_SESSION_TTL = 8 * 60 * 60   # 8 hours
_SESSION_MAX = 10_000          # max concurrent sessions (DoS guard)

_sessions: Dict[str, dict] = {}   # token → {"user": dict, "expires": float}
_lock = threading.Lock()


def create_session(user_info: dict) -> str:
    """Create an opaque token and store user_info.  Returns the token."""
    with _lock:
        _prune_locked()
        if len(_sessions) >= _SESSION_MAX:
            oldest = min(_sessions, key=lambda t: _sessions[t]["expires"])
            del _sessions[oldest]
        token = secrets.token_urlsafe(48)
        _sessions[token] = {"user": user_info, "expires": time.time() + _SESSION_TTL}
    return token


def get_session(token: str) -> Optional[dict]:
    """Return user_info for a valid token, or None if expired/missing."""
    with _lock:
        entry = _sessions.get(token)
        if not entry:
            return None
        if time.time() > entry["expires"]:
            _sessions.pop(token, None)
            return None
        return entry["user"]


def destroy_session(token: str) -> None:
    """Remove a session (logout)."""
    with _lock:
        _sessions.pop(token, None)


def _prune_locked() -> None:
    now = time.time()
    expired = [t for t, e in _sessions.items() if now > e["expires"]]
    for t in expired:
        del _sessions[t]


# ── Backwards-compat aliases used by existing routers that did:
#    from main import _get_session, _create_session, _destroy_session
# These will be removed once all routers are migrated.
_create_session  = create_session
_get_session     = get_session
_destroy_session = destroy_session
