"""
Shared execution state — module-level dicts/locks used by both the
execute engine and admin/monitoring endpoints.

Extracting here breaks the circular import between main.py endpoints and
admin router that both need access to in-flight execution tracking.

Usage:
    from core.execution_state import (
        running_tasks, cancellation_flags, inflight_queries,
        user_query_counts, user_query_lock,
        get_global_sem, set_global_sem,
        get_queue_count, increment_queue_count, decrement_queue_count,
        global_queue_lock,
    )
"""
from __future__ import annotations

import asyncio
import threading
from typing import Dict, Optional

# ── Per-execution cancellation registry ───────────────────────────────────────
running_tasks:      Dict[str, "asyncio.Task"] = {}  # execution_id → asyncio.Task
cancellation_flags: Dict[str, threading.Event] = {}  # execution_id → threading.Event

# ── In-flight query deduplication ─────────────────────────────────────────────
# Maps cache_key → (primary_execution_id, asyncio.Event)
inflight_queries: Dict[str, tuple] = {}

# ── Per-user concurrency tracking ─────────────────────────────────────────────
user_query_counts: Dict[str, int] = {}   # username → active query count
user_query_lock = threading.Lock()

# ── Global concurrency gate ────────────────────────────────────────────────────
# asyncio.Semaphore is event-loop-bound; initialised at startup via set_global_sem()
_global_query_sem: Optional[asyncio.Semaphore] = None
_global_queue_count = 0
global_queue_lock = threading.Lock()


def set_global_sem(sem: asyncio.Semaphore) -> None:
    """Called once from startup after the event loop is running."""
    global _global_query_sem
    _global_query_sem = sem


def get_global_sem() -> Optional[asyncio.Semaphore]:
    return _global_query_sem


def get_queue_count() -> int:
    return _global_queue_count


def increment_queue_count() -> int:
    global _global_queue_count
    with global_queue_lock:
        _global_queue_count += 1
        return _global_queue_count


def decrement_queue_count() -> int:
    global _global_queue_count
    with global_queue_lock:
        _global_queue_count = max(0, _global_queue_count - 1)
        return _global_queue_count


# ── Idempotency key registry ────────────────────────────────────────────────
# Maps client-provided idempotency key → (execution_id, timestamp)
# Entries expire after 10 minutes to avoid unbounded growth.
_idempotency_keys: Dict[str, tuple] = {}
_idempotency_lock = threading.Lock()
_IDEMPOTENCY_TTL = 600  # 10 minutes

def check_idempotency(key: str) -> Optional[str]:
    """Return execution_id if this key was recently used, else None."""
    if not key:
        return None
    with _idempotency_lock:
        _prune_idempotency()
        entry = _idempotency_keys.get(key)
        if entry:
            return entry[0]  # execution_id
    return None

def register_idempotency(key: str, execution_id: str) -> None:
    """Register an idempotency key → execution_id mapping."""
    if not key:
        return
    import time
    with _idempotency_lock:
        _idempotency_keys[key] = (execution_id, time.time())

def _prune_idempotency() -> None:
    """Remove expired idempotency entries (called under lock)."""
    import time
    now = time.time()
    expired = [k for k, (_, ts) in _idempotency_keys.items() if now - ts > _IDEMPOTENCY_TTL]
    for k in expired:
        del _idempotency_keys[k]
