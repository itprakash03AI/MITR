"""
Query configuration conversion and SQL rewriting utilities.

- convert_query_config_to_engine: API Pydantic model → engine QueryConfig
- translate_join_columns: frontend-style table.col → alias t0.col
- rewrite_registered_refs: __registered__:name → DuckDB view references
- strip_sql_limit: remove trailing LIMIT/OFFSET from SQL

Extracted from main.py for maintainability.
"""
from __future__ import annotations

import re
from typing import Dict

from api.models.query_models import QueryConfigModel
from core.parquet_engine_v2 import AggregationConfig, JoinConfig, QueryConfig


def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig."""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how,
                right_column_aliases=j.right_column_aliases or {},
            )
            for j in config.joins
        ]

    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]

    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]

    aggregations = None
    if config.aggregations:
        aggregations = [
            AggregationConfig(column=a.column, function=a.function.upper(),
                              alias=a.alias, distinct=a.distinct)
            for a in config.aggregations
        ]

    having = None
    if config.having:
        having = [{"column": h.column, "function": h.function.upper(),
                   "operator": h.operator, "value": h.value}
                  for h in config.having]

    computed_columns = None
    if config.computed_columns:
        computed_columns = [{"expression": c.expression, "alias": c.alias}
                           for c in config.computed_columns]

    case_expressions = None
    if config.case_expressions:
        case_expressions = [
            {"when_clauses": [{"when_column": w.when_column, "when_operator": w.when_operator,
                               "when_value": w.when_value, "then_value": w.then_value}
                              for w in ce.when_clauses],
             "else_value": ce.else_value, "alias": ce.alias}
            for ce in config.case_expressions
        ]

    window_functions = None
    if config.window_functions:
        window_functions = [
            {"function": wf.function.upper(), "alias": wf.alias,
             "column": wf.column,
             "partition_by": wf.partition_by,
             "order_by": [{"column": o.column, "direction": o.direction}
                          for o in wf.order_by] if wf.order_by else None,
             "offset": wf.offset, "default_value": wf.default_value}
            for wf in config.window_functions
        ]

    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by,
        group_by=config.group_by,
        aggregations=aggregations,
        distinct=config.distinct,
        having=having,
        filter_logic=config.filter_logic.upper(),
        computed_columns=computed_columns,
        case_expressions=case_expressions,
        column_aliases=config.column_aliases,
        window_functions=window_functions,
    )


def translate_join_columns(engine_config) -> None:
    """Translate table-name-prefixed columns to alias-prefixed (t0/t1) for join queries.

    Frontend sends 'tableName.col' for join disambiguation; the engine expects 'tN.col'.
    Mutates engine_config in-place.  No-op if there are no joins.
    """
    if not engine_config.joins:
        return
    _strip = lambda s: s.replace("__registered__:", "").replace("__materialized__:", "").replace("__local__:", "")
    alias_map: Dict[str, str] = {}
    primary = _strip(engine_config.files[0] if engine_config.files else "")
    if primary:
        alias_map[primary] = "t0"
    for i, jc in enumerate(engine_config.joins, start=1):
        rt = jc.right_file if isinstance(jc.right_file, str) else jc.right_file.path
        alias_map[_strip(rt)] = f"t{i}"

    def _tr(col: str) -> str:
        if "." not in col:
            return col
        parts = col.split(".", 1)
        a = alias_map.get(parts[0])
        return f"{a}.{parts[1]}" if a else col

    if engine_config.columns:
        engine_config.columns = [_tr(c) for c in engine_config.columns]
    if engine_config.group_by:
        engine_config.group_by = [_tr(c) for c in engine_config.group_by]
    if engine_config.aggregations:
        for ag in engine_config.aggregations:
            if hasattr(ag, "column"):
                ag.column = _tr(ag.column)
            elif isinstance(ag, dict) and "column" in ag:
                ag["column"] = _tr(ag["column"])
    if engine_config.filters:
        for flt in engine_config.filters:
            if isinstance(flt, dict) and "column" in flt:
                flt["column"] = _tr(flt["column"])
            elif hasattr(flt, "column"):
                flt.column = _tr(flt.column)
    if engine_config.order_by:
        for ob in engine_config.order_by:
            if isinstance(ob, dict) and "column" in ob:
                ob["column"] = _tr(ob["column"])
            elif hasattr(ob, "column"):
                ob.column = _tr(ob.column)
    if engine_config.having:
        for hv in engine_config.having:
            if isinstance(hv, dict) and "column" in hv:
                hv["column"] = _tr(hv["column"])
            elif hasattr(hv, "column"):
                hv.column = _tr(hv.column)


def rewrite_registered_refs(sql: str, registered_tables: list) -> str:
    """Replace read_parquet('base/__registered__:name') with view name "name".

    ParquetQueryEngine.get_duckdb_sql() resolves registered tables to local
    paths like read_parquet('.../data/parquet/__registered__:fact_table').
    For S3 streaming we need the SQL to reference the DuckDB views created by
    _register_s3_views() instead.

    Also rewrites __materialized__:name and __local__:name references to the
    corresponding DuckDB views.
    """
    for tbl in (registered_tables or []):
        tname = tbl["name"]
        esc = re.escape(tname)
        tname_safe = '"' + tname.replace('"', '""') + '"'
        for reader in ("read_parquet", "read_csv_auto"):
            sql = re.sub(
                rf"{reader}\('[^']*__registered__:{esc}'\)",
                tname_safe, sql,
            )
            sql = re.sub(
                rf'{reader}\("[^"]*__registered__:{esc}"\)',
                tname_safe, sql,
            )
    # Rewrite __materialized__:name references
    mv_pattern = re.compile(r"""(?:read_parquet|read_csv_auto)\(['"][^'"]*__materialized__:([^'"]+)['"]\)""")
    for match in mv_pattern.finditer(sql):
        mv_name = match.group(1)
        mv_view = '"__mv__' + mv_name.replace('"', '""') + '"'
        sql = sql.replace(match.group(0), mv_view)
    # Rewrite __local__:name references
    lt_pattern = re.compile(r"""(?:read_parquet|read_csv_auto)\(['"][^'"]*__local__:([^'"]+)['"]\)""")
    for match in lt_pattern.finditer(sql):
        lt_name = match.group(1)
        lt_view = '"__lt__' + lt_name.replace('"', '""') + '"'
        sql = sql.replace(match.group(0), lt_view)
    return sql


def strip_sql_limit(sql: str) -> str:
    """Remove trailing LIMIT [N] [OFFSET N] from a SQL statement.

    Handles optional trailing semicolons and whitespace.
    Only strips the outermost LIMIT — inner subquery LIMITs are preserved.
    """
    cleaned = sql.rstrip().rstrip(';').rstrip()
    return re.sub(
        r'\s+LIMIT\s+(\d+|ALL)(\s+OFFSET\s+\d+)?\s*$', '',
        cleaned, flags=re.IGNORECASE,
    )
