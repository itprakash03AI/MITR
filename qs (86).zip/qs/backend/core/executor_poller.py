"""
Executor task-completion poller — runs inside the FastAPI process as an ``asyncio`` task.

Polls the ``task_queue`` table every *interval* seconds for tasks whose status
has changed (processing progress, completed, failed) and broadcasts updates
via the WebSocket manager.

Used when ``executor.mode = "external"`` (executor runs in a separate process
and updates the DB instead of calling ``ws_manager`` directly).
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


async def run_executor_poller(
    db_manager,
    ws_manager,
    interval: float = 1.0,
):
    """Infinite loop: poll task_queue → broadcast WS → cleanup → sleep.

    Parameters
    ----------
    db_manager : DatabaseManager
        The app-wide database manager instance.
    ws_manager : WebSocketManager
        The app-wide WebSocket manager instance.
    interval : float
        Seconds between poll cycles (default 1.0 s).
    """
    # Track which task_ids we've already broadcast final notifications for
    _notified_final: set = set()
    # Track last progress broadcast per task (throttle to avoid WS spam)
    _last_progress: dict = {}
    cleanup_counter = 0

    while True:
        try:
            tasks = db_manager.poll_active_tasks()

            for task in tasks:
                task_id = task["task_id"]
                execution_id = task.get("execution_id")
                status = task["status"]

                if status == "processing":
                    # Throttle progress broadcasts to ~2 seconds per task
                    import time
                    now = time.monotonic()
                    last = _last_progress.get(task_id, 0)
                    if now - last < 2.0:
                        continue
                    _last_progress[task_id] = now

                    try:
                        await ws_manager.broadcast({
                            "type": "execution_progress",
                            "execution_id": execution_id,
                            "data": {
                                "status": "processing",
                                "progress_pct": task.get("progress_pct", 0),
                                "log": task.get("progress_detail", ""),
                            },
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        })
                    except Exception as exc:
                        logger.warning("WS broadcast failed for task %s: %s", task_id, exc)

                elif status in ("completed", "failed") and task_id not in _notified_final:
                    _notified_final.add(task_id)
                    _last_progress.pop(task_id, None)

                    result = task.get("result") or {}
                    try:
                        if status == "completed":
                            await ws_manager.broadcast({
                                "type": "execution_completed",
                                "execution_id": execution_id,
                                "data": {
                                    "status": "completed",
                                    "total_rows": result.get("total_rows", 0),
                                    "file_size_bytes": result.get("file_size_bytes", 0),
                                    "file_id": result.get("file_id"),
                                },
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                            })
                        else:
                            await ws_manager.broadcast({
                                "type": "execution_failed",
                                "execution_id": execution_id,
                                "data": {
                                    "status": "failed",
                                    "error": task.get("error_message", "Unknown error"),
                                },
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                            })
                    except Exception as exc:
                        logger.warning("WS broadcast failed for task %s: %s", task_id, exc)

            # Periodic cleanup + health check (~once per minute at 1s interval)
            cleanup_counter += 1

            # Executor liveness check every 60 seconds
            if cleanup_counter % 60 == 0:
                try:
                    from core.config import executor as _exec_cfg
                    import urllib.request
                    url = f"{_exec_cfg.worker_url}/health"
                    req = urllib.request.Request(url, method="GET")
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        if resp.status == 200:
                            pass  # healthy
                except Exception as _hc_exc:
                    logger.warning("Executor health check failed (%s): %s",
                                   _exec_cfg.worker_url, _hc_exc)
                    # Broadcast warning to connected clients
                    try:
                        await ws_manager.broadcast({
                            "type": "executor_unhealthy",
                            "data": {"message": f"Executor not responding: {_hc_exc}"},
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        })
                    except Exception:
                        pass

            if cleanup_counter >= 3600:
                try:
                    from core.config import executor as _exec_cfg
                    deleted = db_manager.cleanup_old_tasks(
                        max_age_hours=_exec_cfg.task_retention_hours
                    )
                    if deleted:
                        logger.info("Cleaned up %d old task(s)", deleted)
                    # Prune notified set to avoid memory leak
                    _notified_final.clear()
                except Exception as exc:
                    logger.warning("Task cleanup failed: %s", exc)
                cleanup_counter = 0

        except asyncio.CancelledError:
            logger.info("Executor poller cancelled — shutting down")
            return
        except Exception as exc:
            logger.warning("Executor poller error: %s", exc)

        await asyncio.sleep(interval)


async def run_executor_subscriber(
    task_queue,
    ws_manager,
):
    """Event-driven executor event relay using Redis pub/sub.

    Replaces polling when queue.backend = "redis".
    Subscribes to task events and broadcasts them via WebSocket.
    """
    _notified_final: set = set()

    try:
        async for event in task_queue.subscribe_task_events():
            event_type = event.get("type")
            execution_id = event.get("execution_id", "")
            data = event.get("data", {})

            try:
                if event_type == "task_progress":
                    await ws_manager.broadcast({
                        "type": "execution_progress",
                        "execution_id": execution_id,
                        "data": {
                            "status": "processing",
                            "progress_pct": data.get("progress_pct", 0),
                            "log": data.get("detail", ""),
                        },
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })

                elif event_type == "task_completed" and event.get("task_id") not in _notified_final:
                    _notified_final.add(event["task_id"])
                    await ws_manager.broadcast({
                        "type": "execution_completed",
                        "execution_id": execution_id,
                        "data": {
                            "status": "completed",
                            "total_rows": data.get("total_rows", 0),
                            "file_size_bytes": data.get("file_size_bytes", 0),
                            "file_id": data.get("file_id"),
                        },
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })

                elif event_type == "task_failed" and event.get("task_id") not in _notified_final:
                    _notified_final.add(event["task_id"])
                    await ws_manager.broadcast({
                        "type": "execution_failed",
                        "execution_id": execution_id,
                        "data": {
                            "status": "failed",
                            "error": data.get("error", "Unknown error"),
                        },
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
            except Exception as exc:
                logger.warning("WS broadcast failed: %s", exc)

            # Prune notified set periodically
            if len(_notified_final) > 10000:
                _notified_final.clear()

    except asyncio.CancelledError:
        logger.info("Executor subscriber cancelled — shutting down")
        return
    except Exception as exc:
        logger.error("Executor subscriber error: %s", exc)
