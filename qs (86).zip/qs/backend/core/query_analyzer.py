"""
Query Analyzer (Phase 47) — Rule-based pre-execution query analysis.

Detects common patterns that cause slow, expensive, or incorrect results
and returns human-readable warnings. Zero external dependencies.
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

logger = logging.getLogger(__name__)

# ── Warning severity levels ───────────────────────────────────────────────────

SEVERITY_INFO    = "info"
SEVERITY_WARNING = "warning"
SEVERITY_ERROR   = "error"


@dataclass
class QueryWarning:
    code: str           # machine-readable code e.g. "SELECT_STAR"
    severity: str       # "info" | "warning" | "error"
    message: str        # human-readable short description
    detail: str = ""    # optional longer explanation
    suggestion: str = ""  # actionable fix


# ── Rule helpers ──────────────────────────────────────────────────────────────

def _strip_comments(sql: str) -> str:
    """Remove single-line and block comments."""
    sql = re.sub(r'--[^\n]*', ' ', sql)
    sql = re.sub(r'/\*.*?\*/', ' ', sql, flags=re.DOTALL)
    return sql


def _upper(sql: str) -> str:
    return _strip_comments(sql).upper()


# ── Individual rule checks ────────────────────────────────────────────────────

def _check_select_star(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """SELECT * on wide tables wastes bandwidth and memory."""
    u = _upper(sql)
    # Exclude SELECT COUNT(*) and similar
    if re.search(r'\bSELECT\s+\*\s*(?!,)', u):
        # Allow SELECT * if there's a LIMIT small enough
        limit_match = re.search(r'\bLIMIT\s+(\d+)', u)
        if limit_match and int(limit_match.group(1)) <= 100:
            return None  # SELECT * LIMIT 100 is fine
        return QueryWarning(
            code="SELECT_STAR",
            severity=SEVERITY_INFO,
            message="SELECT * selects all columns",
            detail="Selecting all columns transfers unnecessary data and may be slow on wide tables.",
            suggestion="Specify only the columns you need: SELECT col1, col2, col3 FROM ...",
        )
    return None


def _check_s3_limit(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """LIMIT does not push down to S3 — full scan still occurs."""
    if conn_type not in ("s3", "local"):
        return None
    u = _upper(sql)
    if re.search(r'\bLIMIT\s+\d+', u) and re.search(r'\bFROM\s+', u):
        # Only warn if no WHERE clause — LIMIT without a WHERE is the expensive case
        if not re.search(r'\bWHERE\b', u):
            return QueryWarning(
                code="S3_LIMIT_NO_PUSHDOWN",
                severity=SEVERITY_WARNING,
                message="LIMIT does not speed up S3 scans",
                detail="DuckDB must read all S3 partitions before applying LIMIT. "
                       "Without a WHERE clause, the full dataset is scanned.",
                suggestion="Add a WHERE clause to filter partitions "
                           "(e.g. WHERE date >= '2026-01-01') before relying on LIMIT.",
            )
    return None


def _check_missing_partition_filter(sql: str, conn_type: str,
                                     partition_cols: List[str]) -> Optional[QueryWarning]:
    """Warn when querying S3/partitioned tables without filtering on partition columns."""
    if conn_type not in ("s3",) or not partition_cols:
        return None
    u = _upper(sql)
    if not re.search(r'\bWHERE\b', u):
        cols_str = ", ".join(partition_cols[:3])
        return QueryWarning(
            code="MISSING_PARTITION_FILTER",
            severity=SEVERITY_WARNING,
            message=f"No partition filter — full S3 scan",
            detail=f"This query has no WHERE clause and will scan all partitions. "
                   f"Known partition columns: {cols_str}.",
            suggestion=f"Add a WHERE filter on a partition column "
                       f"(e.g. WHERE {partition_cols[0]} >= '2026-01-01') to limit the scan.",
        )
    # Check if WHERE exists but doesn't reference any partition column
    where_match = re.search(r'\bWHERE\b(.+?)(?:\bGROUP\b|\bHAVING\b|\bORDER\b|\bLIMIT\b|$)',
                             u, re.DOTALL)
    if where_match:
        where_clause = where_match.group(1)
        referenced = any(col.upper() in where_clause for col in partition_cols)
        if not referenced:
            cols_str = ", ".join(partition_cols[:3])
            return QueryWarning(
                code="MISSING_PARTITION_FILTER",
                severity=SEVERITY_INFO,
                message="WHERE clause may not use partition columns",
                detail=f"Partition columns ({cols_str}) not found in WHERE clause. "
                       "All partitions may be scanned.",
                suggestion=f"Consider filtering on partition column(s): {cols_str}",
            )
    return None


def _check_cross_join(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """Detect explicit CROSS JOIN or implicit cartesian joins (comma-separated FROM)."""
    u = _upper(sql)
    if re.search(r'\bCROSS\s+JOIN\b', u):
        return QueryWarning(
            code="CROSS_JOIN",
            severity=SEVERITY_WARNING,
            message="CROSS JOIN detected — cartesian product",
            detail="A CROSS JOIN multiplies every row in the left table with every row "
                   "in the right table. This can produce billions of rows.",
            suggestion="Ensure this is intentional. If you meant a regular join, "
                       "add an ON condition: JOIN table ON a.id = b.id",
        )
    # Detect comma-separated tables in FROM without a WHERE join condition
    from_match = re.search(r'\bFROM\s+([\w\s\.,`"]+?)(?:\bWHERE\b|\bJOIN\b|\bGROUP\b|\bORDER\b|\bLIMIT\b|$)',
                            u, re.DOTALL)
    if from_match:
        from_clause = from_match.group(1)
        # Count comma-separated table references
        tables_in_from = [t.strip() for t in from_clause.split(',') if t.strip()]
        if len(tables_in_from) >= 2:
            return QueryWarning(
                code="IMPLICIT_CROSS_JOIN",
                severity=SEVERITY_WARNING,
                message="Implicit cartesian product (comma-separated FROM tables)",
                detail=f"Using comma-separated tables in FROM ({', '.join(tables_in_from[:3])}) "
                       "without explicit JOIN conditions may produce a cartesian product.",
                suggestion="Use explicit JOIN ... ON syntax instead of comma-separated FROM.",
            )
    return None


def _check_unbounded_group_by(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """GROUP BY without LIMIT or HAVING can return millions of rows."""
    u = _upper(sql)
    if re.search(r'\bGROUP\s+BY\b', u):
        has_limit = bool(re.search(r'\bLIMIT\s+\d+', u))
        has_having = bool(re.search(r'\bHAVING\b', u))
        has_order = bool(re.search(r'\bORDER\s+BY\b', u))
        if not has_limit and not has_having:
            return QueryWarning(
                code="UNBOUNDED_GROUP_BY",
                severity=SEVERITY_INFO,
                message="GROUP BY without LIMIT may return many rows",
                detail="Without a LIMIT or HAVING clause, this aggregation may return "
                       "a very large result set if the grouping column has high cardinality.",
                suggestion="Add LIMIT N or a HAVING clause to cap the result size.",
            )
    return None


def _check_no_where_on_large_table(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """Full table scan without any filter."""
    u = _upper(sql)
    # Only fire for SQL connections (not parquet/S3 — those have their own rule)
    if conn_type in ("trino", "snowflake", "databricks", "oracle"):
        if re.search(r'\bFROM\s+\w', u) and not re.search(r'\bWHERE\b', u):
            has_limit = bool(re.search(r'\bLIMIT\s+\d+', u))
            if not has_limit:
                return QueryWarning(
                    code="FULL_TABLE_SCAN",
                    severity=SEVERITY_INFO,
                    message="Full table scan — no WHERE or LIMIT",
                    detail="This query reads all rows from the table without filtering. "
                           "This may be slow or expensive on large tables.",
                    suggestion="Add a WHERE clause or LIMIT to restrict the result set.",
                )
    return None


def _check_select_into_production(sql: str, conn_type: str) -> Optional[QueryWarning]:
    """Warn on INSERT/UPDATE/DELETE/DROP/CREATE/TRUNCATE in query context."""
    u = _upper(sql).strip()
    ddl_match = re.match(r'\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER)\b', u)
    if ddl_match:
        verb = ddl_match.group(1)
        return QueryWarning(
            code="DDL_DML_STATEMENT",
            severity=SEVERITY_WARNING,
            message=f"{verb} statement detected",
            detail=f"This query contains a {verb} statement which modifies data. "
                   "Ensure this is intentional.",
            suggestion="If this is read-only analysis, use SELECT instead.",
        )
    return None


# ── Public entry point ────────────────────────────────────────────────────────

def analyze_query(
    sql: str,
    connection_type: str = "duckdb",
    partition_columns: Optional[List[str]] = None,
) -> List[QueryWarning]:
    """
    Run all rules against the SQL and return list of QueryWarning objects.

    Args:
        sql: The SQL text to analyze.
        connection_type: Connector type (s3, trino, snowflake, duckdb, etc.)
        partition_columns: Known partition columns for the queried table(s).

    Returns:
        List of QueryWarning (may be empty if no issues detected).
    """
    if not sql or not sql.strip():
        return []

    warnings: List[QueryWarning] = []
    conn = (connection_type or "duckdb").lower()
    pcols = partition_columns or []

    rules = [
        lambda: _check_select_star(sql, conn),
        lambda: _check_s3_limit(sql, conn),
        lambda: _check_missing_partition_filter(sql, conn, pcols),
        lambda: _check_cross_join(sql, conn),
        lambda: _check_unbounded_group_by(sql, conn),
        lambda: _check_no_where_on_large_table(sql, conn),
        lambda: _check_select_into_production(sql, conn),
    ]

    for rule in rules:
        try:
            w = rule()
            if w:
                warnings.append(w)
        except Exception as e:
            logger.debug("Query analysis rule failed: %s", e)

    return warnings


def warnings_to_dicts(warnings: List[QueryWarning]) -> List[Dict[str, Any]]:
    return [
        {
            "code": w.code,
            "severity": w.severity,
            "message": w.message,
            "detail": w.detail,
            "suggestion": w.suggestion,
        }
        for w in warnings
    ]
