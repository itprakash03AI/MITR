"""
Query Checkpointing — survive server restarts during long-running queries.

Records execution intent before a query starts, marks it running, and
on startup recovers any orphaned (incomplete) executions by marking them
as failed so the user knows to retry.

Usage:
    from core.checkpoint import record_intent, mark_started, mark_completed, recover_incomplete
"""
from __future__ import annotations

import logging
import time
from typing import Optional

logger = logging.getLogger(__name__)

# Module-level reference to DatabaseManager — set at startup
_db_manager = None


def init_checkpoint(db_manager) -> None:
    """Set the DatabaseManager reference. Called once at startup."""
    global _db_manager
    _db_manager = db_manager
    logger.info("Checkpoint system initialised")


def record_intent(execution_id: str, query_config: dict,
                  executed_by: str = "", query_id: Optional[int] = None) -> None:
    """
    Record that we INTEND to run this execution.
    Called BEFORE the query actually starts so that if we crash between
    intent and start, recovery will find it.
    """
    if not _db_manager:
        return
    try:
        _db_manager.set_checkpoint(
            execution_id=execution_id,
            state="intent",
            query_config=query_config,
            executed_by=executed_by,
            query_id=query_id,
            timestamp=time.time(),
        )
    except Exception as e:
        logger.warning("Failed to record checkpoint intent for %s: %s", execution_id, e)


def mark_started(execution_id: str) -> None:
    """Mark an execution as actively running."""
    if not _db_manager:
        return
    try:
        _db_manager.update_checkpoint(execution_id, state="running", timestamp=time.time())
    except Exception as e:
        logger.warning("Failed to mark checkpoint started for %s: %s", execution_id, e)


def mark_completed(execution_id: str) -> None:
    """Remove the checkpoint — execution finished (success or failure handled elsewhere)."""
    if not _db_manager:
        return
    try:
        _db_manager.delete_checkpoint(execution_id)
    except Exception as e:
        logger.warning("Failed to clear checkpoint for %s: %s", execution_id, e)


def recover_incomplete() -> int:
    """
    On startup: find all checkpointed executions (intent or running) and
    mark the corresponding execution records as 'failed' with a recovery message.

    Returns the number of recovered executions.
    """
    if not _db_manager:
        return 0
    try:
        orphans = _db_manager.get_all_checkpoints()
        count = 0
        for cp in orphans:
            exec_id = cp["execution_id"]
            state = cp.get("state", "unknown")
            logger.warning("Recovering orphaned execution %s (checkpoint state: %s)", exec_id, state)
            try:
                _db_manager.update_execution(
                    exec_id,
                    status="failed",
                    error_message=f"Server restarted while query was {state}. Please retry.",
                )
            except Exception:
                pass  # execution record may not exist if crash was before DB write
            _db_manager.delete_checkpoint(exec_id)
            count += 1
        if count:
            logger.info("Recovered %d orphaned execution(s) from checkpoint", count)
        return count
    except Exception as e:
        logger.error("Checkpoint recovery failed: %s", e)
        return 0
