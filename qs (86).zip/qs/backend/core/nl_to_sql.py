"""
Natural Language to SQL — Pattern-based (Phases 48 + 57).

No external LLM required. Uses schema context + regex pattern matching
to generate SQL for common analytical query patterns.

Phase 48 (11 patterns):
  - "show/list/get all X"                    → SELECT * FROM X LIMIT 100
  - "count X" / "how many X"                → SELECT COUNT(*) FROM X
  - "top N X by Y"                           → SELECT ... ORDER BY Y DESC LIMIT N
  - "average/avg Y per/by X"                → SELECT X, AVG(Y) FROM ... GROUP BY X
  - "sum/total Y per/by X"                  → SELECT X, SUM(Y) FROM ... GROUP BY X
  - "X where Y is/= Z"                      → SELECT * FROM X WHERE Y = Z
  - "X between DATE1 and DATE2"             → SELECT * FROM X WHERE col BETWEEN ...
  - "X grouped by Y"                         → SELECT Y, COUNT(*) FROM X GROUP BY Y
  - "distinct values of Y in X"             → SELECT DISTINCT Y FROM X
  - "min/max Y in X"                         → SELECT MIN(Y), MAX(Y) FROM X
  - "recent N days of X"                    → SELECT * WHERE date >= CURRENT_DATE - N

Phase 57 (12 new patterns — semantic-layer-aware):
  - Pre-defined condition name match         → injects admin WHERE clause
  - "YTD revenue by region"                 → DATE_TRUNC('year', CURRENT_DATE)
  - "MTD sales by product"                  → DATE_TRUNC('month', CURRENT_DATE)
  - "same period last year" / "YoY"         → two CTEs with year offset
  - "revenue this month vs last month"      → period-over-period comparison
  - "running total of revenue by date"      → SUM() OVER (ORDER BY ...)
  - "percentage of total revenue by region" → agg() / SUM() OVER ()
  - "month over month growth of revenue"    → LAG() window function
  - "3 month moving average of sales"       → AVG() OVER (ROWS N PRECEDING)
  - "rank customers by revenue"             → RANK() OVER (ORDER BY ...)
  - "sum of revenue where status = active"  → SUM(CASE WHEN ...)
  - "ratio of revenue to cost"              → col1 / NULLIF(col2, 0)
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple

logger = logging.getLogger(__name__)


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class NLToSQLResult:
    sql: str
    pattern_matched: str          # human-readable name of matched pattern
    confidence: float             # 0.0–1.0
    explanation: str              # what the query does
    warnings: List[str] = field(default_factory=list)
    alternatives: List[str] = field(default_factory=list)  # alt SQL variants
    matched_condition: Optional[str] = None      # Phase 57: matched PreDefinedCondition name
    semantic_rewrites: List[str] = field(default_factory=list)  # Phase 57: applied rewrites


# ── Schema context ────────────────────────────────────────────────────────────

@dataclass
class SchemaContext:
    """Describes available tables/columns to aid SQL generation."""
    tables: List[str] = field(default_factory=list)             # table names
    columns: Dict[str, List[str]] = field(default_factory=dict) # table → [col, ...]
    connection_type: str = "duckdb"
    default_schema: Optional[str] = None


@dataclass
class SemanticSchemaContext(SchemaContext):
    """
    Phase 57 — extends SchemaContext with semantic layer metadata.

    When available, column matching uses friendly_names / synonyms first,
    then falls back to physical name heuristics. Date/numeric detection
    uses actual data types instead of column-name guessing.
    """
    # {table_alias → {friendly_name_lower → physical_name}}
    friendly_names: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # {table_alias → {synonym_lower → physical_name}}
    synonyms: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # {table_alias → {physical_col → "number"|"date"|"string"|"boolean"}}
    column_data_types: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # {table_alias → {physical_col → "sum"|"avg"|"count"|...}}
    column_aggregations: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # Pre-defined conditions: [{name, label, where_clause}]
    conditions: List[Dict[str, Any]] = field(default_factory=list)
    # Dataset name for display in explanations
    dataset_name: str = ""
    # {table_alias → set(partition_col_names)} — excluded from default numeric measures
    partition_columns: Dict[str, set] = field(default_factory=dict)


def _best_table_match(name: str, ctx: SchemaContext) -> Optional[str]:
    """Find closest table name match (case-insensitive, partial allowed)."""
    name_lower = name.lower().strip()
    # Exact match
    for t in ctx.tables:
        if t.lower() == name_lower:
            return t
    # Prefix / contains match
    for t in ctx.tables:
        if t.lower().startswith(name_lower) or name_lower in t.lower():
            return t
    # Pluralise / singularise naive
    for t in ctx.tables:
        tl = t.lower()
        if tl.rstrip('s') == name_lower.rstrip('s'):
            return t
    return name  # Return as-is if no match — user may know more than schema


def _best_column_match(col: str, table: str, ctx: SchemaContext) -> str:
    """Find best column name for a table (semantic-aware in Phase 57)."""
    col_lower = col.lower().strip()
    # Phase 57: check friendly names and synonyms first
    if isinstance(ctx, SemanticSchemaContext):
        fn_map = ctx.friendly_names.get(table, {})
        if col_lower in fn_map:
            return fn_map[col_lower]
        syn_map = ctx.synonyms.get(table, {})
        if col_lower in syn_map:
            return syn_map[col_lower]
        # Partial friendly name match
        for friendly, physical in fn_map.items():
            if friendly.startswith(col_lower) or col_lower in friendly:
                return physical
    # Original heuristic path
    cols = ctx.columns.get(table, [])
    for c in cols:
        if c.lower() == col_lower:
            return c
    for c in cols:
        if c.lower().startswith(col_lower) or col_lower in c.lower():
            return c
    return col  # Return as-is


def _numeric_cols(table: str, ctx: SchemaContext) -> List[str]:
    """Columns that are numeric — uses semantic types when available, else name heuristic.
    Partition columns are excluded — they don't provide useful aggregation statistics."""
    cols = ctx.columns.get(table, [])
    _part_cols = ctx.partition_columns.get(table, set()) if isinstance(ctx, SemanticSchemaContext) else set()
    if isinstance(ctx, SemanticSchemaContext):
        typed = ctx.column_data_types.get(table, {})
        agged = ctx.column_aggregations.get(table, {})
        semantic = [c for c in cols
                    if c not in _part_cols
                    and (typed.get(c) == "number"
                         or agged.get(c) in ("sum", "avg", "count", "min", "max", "count_distinct"))]
        if semantic:
            return semantic
    # Heuristic fallback (generic terms only — SAP/domain columns resolved via schema types)
    numeric_hints = ('amount', 'total', 'count', 'sum', 'price', 'cost', 'revenue',
                     'value', 'qty', 'quantity', 'num', 'score', 'rate', 'pct', 'percent',
                     'size', 'bytes', 'duration', 'age', 'salary', 'fee', 'balance',
                     'profit', 'margin', 'income', 'expense', 'tax', 'interest',
                     'notional', 'pnl', 'exposure', 'premium', 'units', 'shares',
                     'debit', 'credit', 'nav', 'aum', 'yield', 'coupon', 'spread',
                     'mtm', 'npv', 'nominal', 'multiplier', 'factor', 'consideration')
    return [c for c in cols if any(h in c.lower() for h in numeric_hints)]


def _date_cols(table: str, ctx: SchemaContext) -> List[str]:
    """Date columns — uses semantic types when available, else name heuristic."""
    cols = ctx.columns.get(table, [])
    if isinstance(ctx, SemanticSchemaContext):
        typed = ctx.column_data_types.get(table, {})
        semantic = [c for c in cols if typed.get(c) == "date"]
        if semantic:
            return semantic
    # Heuristic fallback (generic terms only — domain columns resolved via schema types)
    date_hints = ('date', 'time', 'at', 'created', 'updated', 'modified', 'timestamp', 'day', 'month', 'year',
                  'posted', 'effective', 'settlement', 'maturity', 'booked', 'processed',
                  'trade_date', 'value_date', 'expiry', 'inception')
    return [c for c in cols if any(h in c.lower() for h in date_hints)]


def _id_col(table: str, ctx: SchemaContext) -> Optional[str]:
    cols = ctx.columns.get(table, [])
    for c in cols:
        if c.lower() in ('id', f'{table.lower()}_id', 'pk'):
            return c
    return cols[0] if cols else None


def _qualify(table: str, ctx: SchemaContext) -> str:
    """Return schema-qualified table name if a default schema is set."""
    if ctx.default_schema and '.' not in table:
        return f"{ctx.default_schema}.{table}"
    return table


# ── Semantic helpers ──────────────────────────────────────────────────────────

def _get_agg_fn(col: str, table: str, ctx: SchemaContext) -> str:
    """Get the aggregation function for a column from semantic metadata, default SUM."""
    if isinstance(ctx, SemanticSchemaContext):
        aggs = ctx.column_aggregations.get(table, {})
        agg = aggs.get(col, "")
        if agg in ("sum", "avg", "count", "min", "max"):
            return agg.upper()
        if agg == "count_distinct":
            return "COUNT(DISTINCT"  # caller must close paren
    return "SUM"


# ── Phase 57 — New pattern matchers ──────────────────────────────────────────

def _match_condition_name(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """Match a PreDefinedCondition by name/label and inject its WHERE clause."""
    if not isinstance(ctx, SemanticSchemaContext) or not ctx.conditions:
        return None
    nl_lower = nl.lower().strip()
    for cond in ctx.conditions:
        name_lower = cond["name"].lower()
        label_lower = (cond.get("label") or "").lower()
        if name_lower in nl_lower or (label_lower and label_lower in nl_lower):
            table = ctx.tables[0] if ctx.tables else "table"
            tq = _qualify(table, ctx)
            where = cond["where_clause"]
            # Try to extract a metric from the NL question
            metric_hint = re.search(r'\b(?:sum|total|count|avg|average)\s+(?:of\s+)?([\w_]+)', nl, re.I)
            if metric_hint:
                metric = _best_column_match(metric_hint.group(1), table, ctx)
                agg = _get_agg_fn(metric, table, ctx)
                sql = f"SELECT {agg}({metric}) AS value,\n       COUNT(*) AS row_count\nFROM {tq}\nWHERE {where}"
            else:
                sql = f"SELECT *\nFROM {tq}\nWHERE {where}\nLIMIT 1000"
            return NLToSQLResult(
                sql=sql,
                pattern_matched=f"pre-defined condition: {cond['name']}",
                confidence=0.90,
                explanation=f"Applies the '{cond['name']}' pre-defined condition: {where}",
                matched_condition=cond["name"],
            )
    return None


_YTD_RE = re.compile(
    r'\b(?:ytd|year[\s\-]to[\s\-]date|this\s+year(?:\'?s)?)\s+'
    r'(?:of\s+)?([\w_]+)(?:\s+(?:by|per|grouped\s+by)\s+([\w_]+))?'
    r'(?:\s+(?:in|from|for)\s+([\w_]+))?', re.I
)

def _match_ytd(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """YTD revenue, year to date sales by region"""
    m = _YTD_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    group_raw = (m.group(2) or "").strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or (group_raw if group_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    date_col = (_date_cols(table, ctx) or ["date"])[0]
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    if group_raw:
        group_col = _best_column_match(group_raw, table, ctx)
        sql = (f"SELECT {group_col},\n"
               f"       {agg}({metric}) AS ytd_{metric}\n"
               f"FROM {tq}\n"
               f"WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE)\n"
               f"GROUP BY {group_col}\n"
               f"ORDER BY ytd_{metric} DESC")
    else:
        sql = (f"SELECT {agg}({metric}) AS ytd_{metric}\n"
               f"FROM {tq}\n"
               f"WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE)")
    return NLToSQLResult(
        sql=sql, pattern_matched="year-to-date", confidence=0.88,
        explanation=f"Year-to-date {agg.lower()} of {metric} from {table}.",
        warnings=[f"Using date column '{date_col}'."],
    )


_MTD_RE = re.compile(
    r'\b(?:mtd|month[\s\-]to[\s\-]date|this\s+month(?:\'?s)?)\s+'
    r'(?:of\s+)?([\w_]+)(?:\s+(?:by|per|grouped\s+by)\s+([\w_]+))?'
    r'(?:\s+(?:in|from|for)\s+([\w_]+))?', re.I
)

def _match_mtd(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """MTD revenue, month to date sales by product"""
    m = _MTD_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    group_raw = (m.group(2) or "").strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or (group_raw if group_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    date_col = (_date_cols(table, ctx) or ["date"])[0]
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    if group_raw:
        group_col = _best_column_match(group_raw, table, ctx)
        sql = (f"SELECT {group_col},\n"
               f"       {agg}({metric}) AS mtd_{metric}\n"
               f"FROM {tq}\n"
               f"WHERE {date_col} >= DATE_TRUNC('month', CURRENT_DATE)\n"
               f"GROUP BY {group_col}\n"
               f"ORDER BY mtd_{metric} DESC")
    else:
        sql = (f"SELECT {agg}({metric}) AS mtd_{metric}\n"
               f"FROM {tq}\n"
               f"WHERE {date_col} >= DATE_TRUNC('month', CURRENT_DATE)")
    return NLToSQLResult(
        sql=sql, pattern_matched="month-to-date", confidence=0.88,
        explanation=f"Month-to-date {agg.lower()} of {metric} from {table}.",
        warnings=[f"Using date column '{date_col}'."],
    )


_SPLY_RE = re.compile(
    r'\b(?:sply|same[\s\-]period[\s\-]last[\s\-]year|compare.*?last[\s\-]year|'
    r'year[\s\-]over[\s\-]year|yoy)\s+(?:of\s+)?([\w_]+)'
    r'(?:\s+(?:by|per)\s+([\w_]+))?'
    r'(?:\s+(?:in|from|for)\s+([\w_]+))?', re.I
)

def _match_sply(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """Same period last year / year-over-year comparison"""
    m = _SPLY_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    group_raw = (m.group(2) or "").strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or (group_raw if group_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    date_col = (_date_cols(table, ctx) or ["date"])[0]
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    if group_raw:
        group_col = _best_column_match(group_raw, table, ctx)
        sql = (f"WITH current_period AS (\n"
               f"  SELECT {group_col}, {agg}({metric}) AS current_value\n"
               f"  FROM {tq}\n"
               f"  WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE)\n"
               f"  GROUP BY {group_col}\n"
               f"),\n"
               f"prior_period AS (\n"
               f"  SELECT {group_col}, {agg}({metric}) AS prior_value\n"
               f"  FROM {tq}\n"
               f"  WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE - INTERVAL '1 year')\n"
               f"    AND {date_col} < DATE_TRUNC('year', CURRENT_DATE)\n"
               f"  GROUP BY {group_col}\n"
               f")\n"
               f"SELECT c.{group_col},\n"
               f"       c.current_value,\n"
               f"       p.prior_value,\n"
               f"       ROUND(c.current_value - COALESCE(p.prior_value, 0), 2) AS yoy_change,\n"
               f"       CASE WHEN COALESCE(p.prior_value, 0) = 0 THEN NULL\n"
               f"            ELSE ROUND(100.0 * (c.current_value - p.prior_value) / p.prior_value, 1)\n"
               f"       END AS yoy_pct\n"
               f"FROM current_period c\n"
               f"LEFT JOIN prior_period p USING ({group_col})\n"
               f"ORDER BY c.current_value DESC")
    else:
        sql = (f"WITH current_period AS (\n"
               f"  SELECT {agg}({metric}) AS current_value\n"
               f"  FROM {tq}\n"
               f"  WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE)\n"
               f"),\n"
               f"prior_period AS (\n"
               f"  SELECT {agg}({metric}) AS prior_value\n"
               f"  FROM {tq}\n"
               f"  WHERE {date_col} >= DATE_TRUNC('year', CURRENT_DATE - INTERVAL '1 year')\n"
               f"    AND {date_col} < DATE_TRUNC('year', CURRENT_DATE)\n"
               f")\n"
               f"SELECT c.current_value, p.prior_value,\n"
               f"       ROUND(c.current_value - COALESCE(p.prior_value, 0), 2) AS yoy_change\n"
               f"FROM current_period c, prior_period p")
    return NLToSQLResult(
        sql=sql, pattern_matched="SPLY comparison", confidence=0.85,
        explanation=f"Year-over-year comparison of {metric} from {table}.",
        warnings=[f"Using date column '{date_col}'."],
    )


_POP_RE = re.compile(
    r'([\w_]+)\s+(?:this|current)\s+(month|quarter|year|week)\s+'
    r'(?:vs?\.?\s*|compared?\s+to\s+|versus\s+)last\s+\2', re.I
)

def _match_period_over_period(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """revenue this month vs last month, sales this quarter vs last quarter"""
    m = _POP_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    period = m.group(2).lower()
    table = ctx.tables[0] if ctx.tables else metric_raw
    table = _best_table_match(table, ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    date_col = (_date_cols(table, ctx) or ["date"])[0]
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    sql = (f"WITH this_period AS (\n"
           f"  SELECT {agg}({metric}) AS current_value\n"
           f"  FROM {tq}\n"
           f"  WHERE {date_col} >= DATE_TRUNC('{period}', CURRENT_DATE)\n"
           f"),\n"
           f"last_period AS (\n"
           f"  SELECT {agg}({metric}) AS prior_value\n"
           f"  FROM {tq}\n"
           f"  WHERE {date_col} >= DATE_TRUNC('{period}', CURRENT_DATE - INTERVAL '1 {period}')\n"
           f"    AND {date_col} < DATE_TRUNC('{period}', CURRENT_DATE)\n"
           f")\n"
           f"SELECT t.current_value, l.prior_value,\n"
           f"       ROUND(t.current_value - COALESCE(l.prior_value, 0), 2) AS change,\n"
           f"       CASE WHEN COALESCE(l.prior_value, 0) = 0 THEN NULL\n"
           f"            ELSE ROUND(100.0 * (t.current_value - l.prior_value) / l.prior_value, 1)\n"
           f"       END AS change_pct\n"
           f"FROM this_period t, last_period l")
    return NLToSQLResult(
        sql=sql, pattern_matched="period-over-period", confidence=0.87,
        explanation=f"Compares {metric} this {period} vs last {period}.",
        warnings=[f"Using date column '{date_col}'."],
    )


_RUNNING_TOTAL_RE = re.compile(
    r'\b(?:running\s+total|cumulative)\s+(?:of\s+)?([\w_]+)'
    r'(?:\s+(?:by|over|order\s+by)\s+([\w_]+))?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_running_total(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """running total of revenue by date, cumulative sales"""
    m = _RUNNING_TOTAL_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    order_raw = (m.group(2) or "").strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or (order_raw if order_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    order_col = _best_column_match(order_raw, table, ctx) if order_raw else (_date_cols(table, ctx) or ["date"])[0]
    tq = _qualify(table, ctx)
    sql = (f"SELECT {order_col},\n"
           f"       {metric},\n"
           f"       SUM({metric}) OVER (ORDER BY {order_col} ROWS UNBOUNDED PRECEDING)\n"
           f"         AS running_{metric}\n"
           f"FROM {tq}\n"
           f"ORDER BY {order_col}")
    return NLToSQLResult(
        sql=sql, pattern_matched="running total", confidence=0.86,
        explanation=f"Running total of {metric} ordered by {order_col}.",
    )


_PCT_TOTAL_RE = re.compile(
    r'\b(?:percent(?:age)?(?:\s+of\s+total)?|%\s+of\s+(?:total\s+)?|share\s+of)\s+'
    r'([\w_]+)\s+(?:by|per|for\s+each)\s+([\w_]+)'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_percent_of_total(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """percentage of total revenue by region, % of sales per product"""
    m = _PCT_TOTAL_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    group_raw = m.group(2).strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or group_raw, ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    group_col = _best_column_match(group_raw, table, ctx)
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    sql = (f"SELECT {group_col},\n"
           f"       {agg}({metric}) AS total_{metric},\n"
           f"       ROUND(100.0 * {agg}({metric}) / NULLIF(SUM({agg}({metric})) OVER (), 0), 2)\n"
           f"         AS pct_of_total\n"
           f"FROM {tq}\n"
           f"GROUP BY {group_col}\n"
           f"ORDER BY total_{metric} DESC")
    return NLToSQLResult(
        sql=sql, pattern_matched="percent of total", confidence=0.86,
        explanation=f"Percentage of total {metric} by {group_col}.",
    )


_GROWTH_RE = re.compile(
    r'\b(?:(?:month|week|quarter|year)[\s\-]over[\s\-](?:month|week|quarter|year)\s+)?'
    r'(?:growth\s+rate?|growth|change|delta)\s+(?:of\s+)?([\w_]+)'
    r'(?:\s+(?:by|per)\s+([\w_]+))?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_growth_rate(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """month over month growth of revenue, growth rate of sales by product"""
    m = _GROWTH_RE.search(nl)
    if not m:
        return None
    metric_raw = m.group(1).strip()
    group_raw = (m.group(2) or "").strip()
    table_hint = (m.group(3) or "").strip()
    table = _best_table_match(table_hint or (group_raw if group_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    date_col = (_date_cols(table, ctx) or ["date"])[0]
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    group_clause = f", {_best_column_match(group_raw, table, ctx)}" if group_raw else ""
    partition_clause = f"PARTITION BY {_best_column_match(group_raw, table, ctx)}" if group_raw else ""
    sql = (f"WITH ordered AS (\n"
           f"  SELECT {date_col}{group_clause},\n"
           f"         {agg}({metric}) AS period_value\n"
           f"  FROM {tq}\n"
           f"  GROUP BY {date_col}{group_clause}\n"
           f")\n"
           f"SELECT {date_col}{group_clause},\n"
           f"       period_value,\n"
           f"       LAG(period_value) OVER ({partition_clause} ORDER BY {date_col}) AS prior_value,\n"
           f"       ROUND(100.0 * (period_value - LAG(period_value) OVER ({partition_clause} ORDER BY {date_col}))\n"
           f"         / NULLIF(LAG(period_value) OVER ({partition_clause} ORDER BY {date_col}), 0), 2)\n"
           f"         AS growth_pct\n"
           f"FROM ordered\n"
           f"ORDER BY {date_col}")
    return NLToSQLResult(
        sql=sql, pattern_matched="growth rate", confidence=0.82,
        explanation=f"Period-over-period growth rate of {metric}.",
        warnings=[f"Using date column '{date_col}'."],
    )


_MOVING_AVG_RE = re.compile(
    r'(\d+)\s*[\s\-]?(?:day|month|week|quarter|row|period)s?\s+'
    r'(?:moving|rolling|sliding)\s+average\s+(?:of\s+)?([\w_]+)'
    r'(?:\s+(?:by|over|order\s+by)\s+([\w_]+))?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_moving_average(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """3 month moving average of revenue, 7 day rolling average of sales"""
    m = _MOVING_AVG_RE.search(nl)
    if not m:
        return None
    n = int(m.group(1))
    metric_raw = m.group(2).strip()
    order_raw = (m.group(3) or "").strip()
    table_hint = (m.group(4) or "").strip()
    table = _best_table_match(table_hint or (order_raw if order_raw else metric_raw), ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    order_col = _best_column_match(order_raw, table, ctx) if order_raw else (_date_cols(table, ctx) or ["date"])[0]
    tq = _qualify(table, ctx)
    preceding = max(n - 1, 0)
    sql = (f"SELECT {order_col},\n"
           f"       {metric},\n"
           f"       ROUND(AVG({metric}) OVER (\n"
           f"         ORDER BY {order_col}\n"
           f"         ROWS BETWEEN {preceding} PRECEDING AND CURRENT ROW\n"
           f"       ), 2) AS moving_avg_{n}_{metric}\n"
           f"FROM {tq}\n"
           f"ORDER BY {order_col}")
    return NLToSQLResult(
        sql=sql, pattern_matched="moving average", confidence=0.88,
        explanation=f"{n}-period moving average of {metric} ordered by {order_col}.",
    )


_RANK_RE = re.compile(
    r'\b(?:rank|ranking\s+of)\s+([\w_\s]+?)\s+by\s+([\w_]+)'
    r'(?:\s+(desc|asc))?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_rank(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """rank customers by revenue, rank products by sales desc"""
    m = _RANK_RE.search(nl)
    if not m:
        return None
    group_raw = m.group(1).strip().split()[-1]  # last word = dimension
    metric_raw = m.group(2).strip()
    direction = (m.group(3) or "desc").upper()
    table_hint = (m.group(4) or "").strip()
    table = _best_table_match(table_hint or group_raw, ctx)
    group_col = _best_column_match(group_raw, table, ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    agg = _get_agg_fn(metric, table, ctx)
    tq = _qualify(table, ctx)
    sql = (f"SELECT {group_col},\n"
           f"       {agg}({metric}) AS total_{metric},\n"
           f"       RANK() OVER (ORDER BY {agg}({metric}) {direction})\n"
           f"         AS rank_by_{metric}\n"
           f"FROM {tq}\n"
           f"GROUP BY {group_col}\n"
           f"ORDER BY rank_by_{metric}\n"
           f"LIMIT 100")
    return NLToSQLResult(
        sql=sql, pattern_matched="rank", confidence=0.85,
        explanation=f"Ranks {group_col} by {metric} ({direction}).",
    )


_COND_AGG_RE = re.compile(
    r'\b(sum|count|average|avg|total)\s+(?:of\s+)?([\w_]+)'
    r'\s+where\s+([\w_]+)\s+(?:is|=|equals?)\s+["\']?([\w\s\-]+?)["\']?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?\s*$', re.I
)

def _match_conditional_aggregate(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """sum of revenue where status = active, count orders where region = North"""
    m = _COND_AGG_RE.search(nl)
    if not m:
        return None
    agg_word = m.group(1).lower()
    metric_raw = m.group(2).strip()
    filter_col_raw = m.group(3).strip()
    filter_val = m.group(4).strip()
    table_hint = (m.group(5) or "").strip()
    agg_fn = {"sum": "SUM", "total": "SUM", "count": "COUNT", "average": "AVG", "avg": "AVG"}.get(agg_word, "SUM")
    table = _best_table_match(table_hint or filter_col_raw, ctx)
    metric = _best_column_match(metric_raw, table, ctx)
    filter_col = _best_column_match(filter_col_raw, table, ctx)
    tq = _qualify(table, ctx)
    sql = (f"SELECT {agg_fn}(CASE WHEN {filter_col} = '{filter_val}'\n"
           f"                      THEN {metric} END) AS conditional_{agg_fn.lower()}_{metric},\n"
           f"       COUNT(*) AS total_rows,\n"
           f"       COUNT(CASE WHEN {filter_col} = '{filter_val}' THEN 1 END) AS matching_rows\n"
           f"FROM {tq}")
    return NLToSQLResult(
        sql=sql, pattern_matched="conditional aggregate", confidence=0.83,
        explanation=f"Conditional {agg_fn} of {metric} where {filter_col} = '{filter_val}'.",
    )


_RATIO_RE = re.compile(
    r'\b(?:ratio|proportion)\s+(?:of\s+)?([\w_]+)\s+'
    r'(?:to|over|divided?\s+by)\s+([\w_]+)'
    r'(?:\s+(?:by|per)\s+([\w_]+))?'
    r'(?:\s+(?:in|from)\s+([\w_]+))?', re.I
)

def _match_ratio(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """ratio of revenue to cost, ratio of revenue to cost by region"""
    m = _RATIO_RE.search(nl)
    if not m:
        return None
    col1_raw = m.group(1).strip()
    col2_raw = m.group(2).strip()
    group_raw = (m.group(3) or "").strip()
    table_hint = (m.group(4) or "").strip()
    table = _best_table_match(table_hint or (group_raw if group_raw else col1_raw), ctx)
    col1 = _best_column_match(col1_raw, table, ctx)
    col2 = _best_column_match(col2_raw, table, ctx)
    tq = _qualify(table, ctx)
    if group_raw:
        group_col = _best_column_match(group_raw, table, ctx)
        agg1 = _get_agg_fn(col1, table, ctx)
        agg2 = _get_agg_fn(col2, table, ctx)
        sql = (f"SELECT {group_col},\n"
               f"       {agg1}({col1}) AS total_{col1},\n"
               f"       {agg2}({col2}) AS total_{col2},\n"
               f"       ROUND({agg1}({col1}) / NULLIF({agg2}({col2}), 0), 4)\n"
               f"         AS ratio_{col1}_to_{col2}\n"
               f"FROM {tq}\n"
               f"GROUP BY {group_col}\n"
               f"ORDER BY ratio_{col1}_to_{col2} DESC NULLS LAST")
    else:
        sql = (f"SELECT {col1},\n"
               f"       {col2},\n"
               f"       ROUND({col1}::DOUBLE / NULLIF({col2}::DOUBLE, 0), 4)\n"
               f"         AS ratio_{col1}_to_{col2}\n"
               f"FROM {tq}\n"
               f"ORDER BY ratio_{col1}_to_{col2} DESC NULLS LAST\n"
               f"LIMIT 100")
    return NLToSQLResult(
        sql=sql, pattern_matched="ratio", confidence=0.80,
        explanation=f"Ratio of {col1} to {col2}.",
    )


# ── Phase 48 — Original pattern matchers ─────────────────────────────────────

def _match_count(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """count X / how many X / number of X"""
    m = re.search(r'(?:count|how many|number of)\s+([\w\s]+?)(?:\s+(?:where|in|with|that|$))', nl, re.I)
    if not m:
        m = re.search(r'(?:count|how many|number of)\s+([\w]+)', nl, re.I)
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT COUNT(*) AS total_count\nFROM {tq}",
            pattern_matched="count rows",
            confidence=0.85,
            explanation=f"Counts all rows in {table}.",
        )
    return None


def _match_top_n(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """top N X by Y [desc/asc]"""
    m = re.search(
        r'top\s+(\d+)\s+([\w\s]+?)\s+by\s+([\w_]+)(?:\s+(desc|asc))?',
        nl, re.I
    )
    if m:
        n = int(m.group(1))
        table = _best_table_match(m.group(2).strip(), ctx)
        order_col = _best_column_match(m.group(3).strip(), table, ctx)
        direction = (m.group(4) or 'desc').upper()
        tq = _qualify(table, ctx)
        cols = ctx.columns.get(table, [])
        select_cols = ', '.join(cols[:8]) if cols else '*'
        return NLToSQLResult(
            sql=(f"SELECT {select_cols}\nFROM {tq}\n"
                 f"ORDER BY {order_col} {direction}\nLIMIT {n}"),
            pattern_matched="top N by column",
            confidence=0.90,
            explanation=f"Returns top {n} rows from {table} ordered by {order_col} {direction}.",
        )
    return None


def _match_avg_per(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """average/avg Y per/by/for each X"""
    m = re.search(
        r'(?:average|avg|mean)\s+([\w_]+)\s+(?:per|by|for each|grouped by)\s+([\w_]+)\s+(?:in|from)?\s*([\w_]*)',
        nl, re.I
    )
    if m:
        metric = m.group(1).strip()
        group = m.group(2).strip()
        table_hint = m.group(3).strip()
        table = _best_table_match(table_hint or group, ctx)
        metric_col = _best_column_match(metric, table, ctx)
        group_col = _best_column_match(group, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group_col},\n"
                 f"       AVG({metric_col}) AS avg_{metric_col}\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group_col}\n"
                 f"ORDER BY avg_{metric_col} DESC"),
            pattern_matched="average per group",
            confidence=0.82,
            explanation=f"Average of {metric_col} grouped by {group_col} in {table}.",
        )
    return None


def _match_sum_per(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """sum/total Y per/by X"""
    m = re.search(
        r'(?:sum|total|summ?ari[sz]e)\s+(?:of\s+)?([\w_]+)\s+(?:per|by|for each|grouped by)\s+([\w_]+)\s+(?:in|from)?\s*([\w_]*)',
        nl, re.I
    )
    if m:
        metric = m.group(1).strip()
        group = m.group(2).strip()
        table_hint = m.group(3).strip()
        table = _best_table_match(table_hint or group, ctx)
        metric_col = _best_column_match(metric, table, ctx)
        group_col = _best_column_match(group, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group_col},\n"
                 f"       SUM({metric_col}) AS total_{metric_col}\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group_col}\n"
                 f"ORDER BY total_{metric_col} DESC"),
            pattern_matched="sum per group",
            confidence=0.82,
            explanation=f"Sum of {metric_col} grouped by {group_col} in {table}.",
        )
    return None


def _match_show_all(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """show/list/get all X  /  show me X"""
    m = re.search(r'(?:show|list|get|fetch|display|give me|show me)\s+(?:all|me|the)?\s*([\w\s]+)', nl, re.I)
    if m:
        table = _best_table_match(m.group(1).strip().split()[0], ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT *\nFROM {tq}\nLIMIT 100",
            pattern_matched="show all rows",
            confidence=0.70,
            explanation=f"Returns up to 100 rows from {table}.",
            warnings=["SELECT * used — consider specifying columns for better performance."],
        )
    return None


def _match_where_equals(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X where Y is/= Z  /  X with Y = Z"""
    m = re.search(
        r'([\w_]+)\s+(?:where|with|having)\s+([\w_]+)\s+(?:is|=|equals?|==)\s+["\']?([\w\s\-]+?)["\']?(?:\s|$)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        col = _best_column_match(m.group(2).strip(), table, ctx)
        val = m.group(3).strip()
        tq = _qualify(table, ctx)
        # Quote value unless it looks numeric
        quoted_val = val if re.match(r'^\d+(\.\d+)?$', val) else f"'{val}'"
        return NLToSQLResult(
            sql=f"SELECT *\nFROM {tq}\nWHERE {col} = {quoted_val}\nLIMIT 100",
            pattern_matched="filter equals",
            confidence=0.80,
            explanation=f"Rows from {table} where {col} equals {val}.",
        )
    return None


def _match_distinct(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """distinct values of Y in X  /  unique Y from X"""
    m = re.search(
        r'(?:distinct|unique)\s+(?:values?\s+of\s+)?([\w_]+)\s+(?:in|from)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        col = m.group(1).strip()
        table = _best_table_match(m.group(2).strip(), ctx)
        col = _best_column_match(col, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT DISTINCT {col}\nFROM {tq}\nORDER BY {col}",
            pattern_matched="distinct values",
            confidence=0.88,
            explanation=f"Unique values of {col} from {table}.",
        )
    return None


def _match_min_max(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """min/max/minimum/maximum Y in X"""
    m = re.search(
        r'(?:min(?:imum)?|max(?:imum)?)\s+(?:and\s+(?:max(?:imum)?|min(?:imum)?)\s+)?(?:of\s+)?([\w_]+)\s+(?:in|from)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        col = m.group(1).strip()
        table = _best_table_match(m.group(2).strip(), ctx)
        col = _best_column_match(col, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT MIN({col}) AS min_{col},\n"
                 f"       MAX({col}) AS max_{col},\n"
                 f"       AVG({col}) AS avg_{col}\n"
                 f"FROM {tq}"),
            pattern_matched="min/max",
            confidence=0.85,
            explanation=f"Minimum, maximum, and average of {col} in {table}.",
        )
    return None


def _match_group_count(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X grouped by Y  /  count X by Y  /  breakdown of X by Y"""
    m = re.search(
        r'(?:count\s+)?([\w_]+)\s+(?:grouped by|by|breakdown by|breakdown of\s+[\w_]+\s+by)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        group = _best_column_match(m.group(2).strip(), table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group},\n"
                 f"       COUNT(*) AS row_count\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group}\n"
                 f"ORDER BY row_count DESC"),
            pattern_matched="group by count",
            confidence=0.83,
            explanation=f"Row count per {group} in {table}.",
        )
    return None


def _match_between_dates(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X between DATE1 and DATE2"""
    m = re.search(
        r'([\w_]+)\s+between\s+([\d\-/]+)\s+and\s+([\d\-/]+)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        date1 = m.group(2).replace('/', '-')
        date2 = m.group(3).replace('/', '-')
        tq = _qualify(table, ctx)
        date_col = (_date_cols(table, ctx) or ['date'])[0]
        return NLToSQLResult(
            sql=(f"SELECT *\nFROM {tq}\n"
                 f"WHERE {date_col} BETWEEN '{date1}' AND '{date2}'\n"
                 f"ORDER BY {date_col}\nLIMIT 1000"),
            pattern_matched="date range filter",
            confidence=0.80,
            explanation=f"Rows from {table} where {date_col} is between {date1} and {date2}.",
            warnings=[f"Assumed date column is '{date_col}'. Adjust if needed."],
        )
    return None


def _match_recent(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """latest/recent/last N days X"""
    m = re.search(r'(?:latest|recent|last)\s+(\d+)\s+(?:days?|months?|weeks?)\s+(?:of\s+)?([\w_]+)', nl, re.I)
    unit_m = re.search(r'last\s+(\d+)\s+(days?|months?|weeks?)', nl, re.I)
    table_m = re.search(r'(?:for|of|from|in)\s+([\w_]+)', nl, re.I) or re.search(r'([\w_]+)\s+(?:in|from)\s+(?:last|past)', nl, re.I)
    if m:
        n = int(m.group(1))
        table = _best_table_match(m.group(2).strip(), ctx)
        unit = 'DAY'
        tq = _qualify(table, ctx)
        date_col = (_date_cols(table, ctx) or ['created_at'])[0]
        return NLToSQLResult(
            sql=(f"SELECT *\nFROM {tq}\n"
                 f"WHERE {date_col} >= CURRENT_DATE - INTERVAL '{n}' {unit}\n"
                 f"ORDER BY {date_col} DESC\nLIMIT 500"),
            pattern_matched="recent rows",
            confidence=0.78,
            explanation=f"Rows from {table} in the last {n} days.",
            warnings=[f"Assumed date column is '{date_col}'. Adjust if needed."],
        )
    return None


# ── Ordered pattern pipeline ──────────────────────────────────────────────────
# Phase 57 patterns first (higher specificity), then Phase 48 originals.
# Order matters: condition_name has highest priority, then time intelligence
# (must fire before generic _match_recent), then analytical patterns.

_PATTERNS = [
    # Phase 57 — semantic + time intelligence + analytical
    _match_condition_name,
    _match_ytd,
    _match_mtd,
    _match_sply,
    _match_period_over_period,
    _match_running_total,
    _match_percent_of_total,
    _match_growth_rate,
    _match_moving_average,
    _match_rank,
    _match_conditional_aggregate,
    _match_ratio,
    # Phase 48 — original 11 patterns (unchanged)
    _match_top_n,
    _match_avg_per,
    _match_sum_per,
    _match_distinct,
    _match_min_max,
    _match_between_dates,
    _match_recent,
    _match_where_equals,
    _match_count,
    _match_group_count,
    _match_show_all,
]


# ── Public API ────────────────────────────────────────────────────────────────

def nl_to_sql(
    natural_language: str,
    schema_context: Optional[SchemaContext] = None,
) -> NLToSQLResult:
    """
    Convert a natural language question to SQL using pattern matching.

    Args:
        natural_language: Plain-English query description.
        schema_context: Available tables/columns for schema-aware generation.

    Returns:
        NLToSQLResult with generated SQL, or a fallback SELECT template.
    """
    nl = natural_language.strip()
    ctx = schema_context or SchemaContext()

    for pattern_fn in _PATTERNS:
        try:
            result = pattern_fn(nl, ctx)
            if result:
                return result
        except Exception as e:
            logger.debug("NL-to-SQL pattern %s failed: %s", pattern_fn.__name__, e)

    # Fallback — generic template using first available table
    table = ctx.tables[0] if ctx.tables else "your_table"
    tq = _qualify(table, ctx)
    return NLToSQLResult(
        sql=f"SELECT *\nFROM {tq}\nLIMIT 100",
        pattern_matched="fallback template",
        confidence=0.20,
        explanation="No specific pattern matched. Generated a basic SELECT template.",
        warnings=[
            "Could not parse the query. Try phrases like: "
            "'top 10 orders by revenue', 'count customers', "
            "'average salary by department'."
        ],
        alternatives=[
            f"SELECT COUNT(*) FROM {tq}",
            f"SELECT * FROM {tq} WHERE <condition> LIMIT 100",
        ],
    )


def apply_glossary(nl: str, glossary: Dict[str, str]) -> str:
    """
    Substitute business terms with their technical equivalents before pattern matching.

    Example config.json entry:
        "glossary": { "revenue": "sale_amount", "headcount": "emp_count" }

    "show top 10 customers by revenue" becomes
    "show top 10 customers by sale_amount"

    Longer phrases are applied first (most-specific-first) to avoid partial overlaps.
    """
    if not glossary:
        return nl
    result = nl
    # Sort by key length descending so longer phrases replace before shorter ones
    for term in sorted(glossary, key=len, reverse=True):
        replacement = glossary[term]
        result = re.sub(r'\b' + re.escape(term) + r'\b', replacement, result, flags=re.IGNORECASE)
    return result


def result_to_dict(r: NLToSQLResult) -> Dict[str, Any]:
    d = {
        "sql": r.sql,
        "pattern_matched": r.pattern_matched,
        "confidence": r.confidence,
        "explanation": r.explanation,
        "warnings": r.warnings,
        "alternatives": r.alternatives,
    }
    if r.matched_condition:
        d["matched_condition"] = r.matched_condition
    if r.semantic_rewrites:
        d["semantic_rewrites"] = r.semantic_rewrites
    return d


# ── Phase 57 — Context builders ──────────────────────────────────────────────

def build_semantic_context(dataset_dict: Dict[str, Any]) -> SemanticSchemaContext:
    """
    Build a SemanticSchemaContext from a get_dataset_full() response dict.

    The dataset's source_tables list provides the table names/aliases.
    DatasetColumn rows provide friendly_name, synonyms, data_type, aggregation.
    PreDefinedConditions are captured for condition-name matching.
    """
    source_tables = dataset_dict.get("source_tables", [])
    table_aliases = [
        t.get("alias") or t.get("table", "").split("/")[-1].split(".")[0]
        for t in source_tables
    ]
    if not table_aliases:
        table_aliases = [dataset_dict.get("name", "table")]

    columns: Dict[str, List[str]] = {a: [] for a in table_aliases}
    friendly_names: Dict[str, Dict[str, str]] = {a: {} for a in table_aliases}
    synonyms_map: Dict[str, Dict[str, str]] = {a: {} for a in table_aliases}
    col_types: Dict[str, Dict[str, str]] = {a: {} for a in table_aliases}
    col_aggs: Dict[str, Dict[str, str]] = {a: {} for a in table_aliases}

    primary_alias = table_aliases[0]

    for col in dataset_dict.get("columns", []):
        if col.get("is_hidden"):
            continue
        phys = col["physical_name"]
        friendly = col.get("friendly_name", phys)
        alias = primary_alias

        columns.setdefault(alias, []).append(phys)
        friendly_names.setdefault(alias, {})[friendly.lower()] = phys
        for syn in (col.get("synonyms") or []):
            synonyms_map.setdefault(alias, {})[syn.lower()] = phys
        if col.get("data_type"):
            col_types.setdefault(alias, {})[phys] = col["data_type"]
        if col.get("aggregation"):
            col_aggs.setdefault(alias, {})[phys] = col["aggregation"]

    conditions = [
        {"name": c["name"], "label": c.get("label", ""), "where_clause": c["where_clause"]}
        for c in dataset_dict.get("conditions", [])
    ]

    return SemanticSchemaContext(
        tables=table_aliases,
        columns=columns,
        connection_type="duckdb",
        friendly_names=friendly_names,
        synonyms=synonyms_map,
        column_data_types=col_types,
        column_aggregations=col_aggs,
        conditions=conditions,
        dataset_name=dataset_dict.get("name", ""),
    )


def enrich_from_schema_cache(
    ctx: SchemaContext,
    schema_cache_rows: List[Dict[str, Any]],
) -> SemanticSchemaContext:
    """
    Upgrade a plain SchemaContext to SemanticSchemaContext using schema_cache data.

    Each schema_cache row has schema_data.columns[{name, type, nullable}] and
    optionally schema_data.partition_spec[{source_column, ...}].
    Types are Iceberg/DuckDB native (VARCHAR, BIGINT, DATE, TIMESTAMP, etc.)
    and are mapped to semantic types (string, number, date, boolean).
    Partition columns are tracked separately — excluded from default numeric measures.
    """
    col_types: Dict[str, Dict[str, str]] = {}
    part_cols: Dict[str, set] = {}
    for row in schema_cache_rows:
        table = row.get("table_name", "")
        schema_data = row.get("schema_data") or {}
        for col_info in schema_data.get("columns", []):
            raw_type = (col_info.get("type") or "").upper()
            if any(t in raw_type for t in ("DATE", "TIME", "TIMESTAMP")):
                mapped = "date"
            elif any(t in raw_type for t in ("INT", "BIGINT", "DOUBLE", "FLOAT",
                                              "DECIMAL", "NUMERIC", "REAL", "NUMBER")):
                mapped = "number"
            elif "BOOL" in raw_type:
                mapped = "boolean"
            else:
                mapped = "string"
            col_types.setdefault(table, {})[col_info["name"]] = mapped
        # Extract partition columns from partition_spec (Iceberg tables)
        for pf in schema_data.get("partition_spec", []):
            src_col = pf.get("source_column", "")
            if src_col:
                part_cols.setdefault(table, set()).add(src_col)

    return SemanticSchemaContext(
        tables=ctx.tables,
        columns=ctx.columns,
        connection_type=ctx.connection_type,
        default_schema=ctx.default_schema,
        column_data_types=col_types,
        partition_columns=part_cols,
    )
