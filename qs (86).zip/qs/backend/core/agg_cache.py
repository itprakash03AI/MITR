"""
Aggregation Cache Engine -- Pre-computed rollup parquets with smart routing.

Inspired by:
  - BO Aggregate Awareness: transparent routing to coarsest-grain pre-agg table
  - Power BI VertiPaq: pre-loaded compressed columnar data for sub-second queries
  - Tableau Extracts: scheduled refreshes with incremental option

Architecture:
  1. AggCacheEntry DB records define rollup rules (which dims + measures)
  2. build_cache_entry() executes the aggregation query via FederationEngine
  3. check_cache_hit() intercepts federation queries BEFORE live SQL
  4. Smart routing picks the COARSEST grain cache (fewest dims) that satisfies
  5. Scheduled refresh via APScheduler (cron/interval triggers)
  6. Usage analysis generates suggestions from FederationExecution history

Cache lifecycle:  pending -> building -> ready -> stale -> expired
  - stale: past soft TTL but still serveable (serve + trigger background refresh)
  - expired: past hard expiry, must rebuild (never served)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import threading
import time
import uuid
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)

# ── Module-level singletons (populated at startup) ─────────────────────────
_db_manager = None
_federation_engine = None
_cache_dir: Optional[Path] = None
_enabled: bool = True
_build_locks: Dict[int, threading.Lock] = {}   # entry_id -> lock
_global_lock = threading.Lock()                 # protects _build_locks dict


# ═══════════════════════════════════════════════════════════════════════════════
# Initialisation
# ═══════════════════════════════════════════════════════════════════════════════

def init_agg_cache(db_manager, federation_engine, cache_dir: str,
                   enabled: bool = True) -> None:
    """Initialize the aggregation cache engine.  Called once at startup."""
    global _db_manager, _federation_engine, _cache_dir, _enabled
    _db_manager = db_manager
    _federation_engine = federation_engine
    _cache_dir = Path(cache_dir)
    _enabled = enabled
    _cache_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[agg_cache] Initialised -- dir=%s enabled=%s", _cache_dir, _enabled)


# ═══════════════════════════════════════════════════════════════════════════════
# Smart Routing — BO Aggregate Awareness
# ═══════════════════════════════════════════════════════════════════════════════

class CacheHitResult:
    """Result of a successful cache lookup."""

    def __init__(self, entry_id: int, file_path: str, row_count: int,
                 cache_age_seconds: float, was_stale: bool, grain_label: str):
        self.entry_id = entry_id
        self.file_path = file_path
        self.row_count = row_count
        self.cache_age_seconds = cache_age_seconds
        self.was_stale = was_stale
        self.grain_label = grain_label

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "file_path": self.file_path,
            "row_count": self.row_count,
            "cache_age_seconds": round(self.cache_age_seconds, 1),
            "was_stale": self.was_stale,
            "grain_label": self.grain_label,
        }


def check_cache_hit(
    *,
    dataset_id: int,
    requested_dimension_col_ids: List[int],
    requested_measure_col_ids: List[int],
) -> Optional[CacheHitResult]:
    """Check if any pre-computed cache can satisfy this query.

    Smart Routing Algorithm (BO Aggregate Awareness):
      1. All requested measures must be present in the cache entry's measure set
      2. All requested dimensions must be a SUBSET of the cache entry's dimension set
      3. Among matches, pick the COARSEST grain (fewest dimensions = smallest parquet)
      4. If status='stale' and stale_serve is enabled, serve it + trigger background refresh
      5. If status='expired' or no match, return None (fall through to live)
    """
    if not _enabled or not _db_manager:
        return None

    from core import config
    if not config.agg_cache.enabled:
        return None
    if not config.semantic_layer.aggregation_awareness_enabled:
        return None

    now = datetime.now(timezone.utc)
    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)

    req_dims = set(requested_dimension_col_ids)
    req_measures = set(requested_measure_col_ids)

    candidates: List[Tuple[Dict, int]] = []   # (entry_dict, dimension_count)

    for entry in entries:
        if not entry.get("is_enabled"):
            continue
        if entry["status"] not in ("ready", "stale"):
            continue
        if not entry.get("file_path") or not os.path.isfile(entry["file_path"]):
            continue

        cache_dims = set(entry.get("dimension_col_ids") or [])
        cache_measures = set(entry.get("measure_col_ids") or [])

        # All requested measures must be in cache
        if not req_measures.issubset(cache_measures):
            continue

        # All requested dimensions must be in cache (cache can have MORE dims)
        if not req_dims.issubset(cache_dims):
            continue

        # Check hard expiry
        expires_at = entry.get("expires_at")
        if expires_at:
            exp_dt = _parse_dt(expires_at)
            if now > exp_dt:
                _db_manager.increment_agg_cache_miss(entry["id"])
                continue

        candidates.append((entry, len(cache_dims)))

    if not candidates:
        return None

    # Pick coarsest grain (fewest dimensions)
    candidates.sort(key=lambda x: x[1])
    winner, _ = candidates[0]

    # Determine staleness
    was_stale = False
    stale_at = winner.get("stale_at")
    if stale_at:
        stale_dt = _parse_dt(stale_at)
        if now > stale_dt:
            was_stale = True
            if not config.agg_cache.stale_serve_enabled:
                _db_manager.increment_agg_cache_miss(winner["id"])
                return None
            # Trigger background refresh (non-blocking)
            _trigger_background_refresh(winner["id"])

    # Calculate cache age
    built_at = winner.get("last_built_at")
    if built_at:
        built_dt = _parse_dt(built_at)
        cache_age = (now - built_dt).total_seconds()
    else:
        cache_age = 0.0

    _db_manager.increment_agg_cache_hit(winner["id"])

    return CacheHitResult(
        entry_id=winner["id"],
        file_path=winner["file_path"],
        row_count=winner.get("row_count", 0),
        cache_age_seconds=cache_age,
        was_stale=was_stale,
        grain_label=winner.get("grain_label", "custom"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Cache Building — Power BI Import + Tableau Extract
# ═══════════════════════════════════════════════════════════════════════════════

def build_cache_entry(entry_id: int, force: bool = False) -> bool:
    """Build (or rebuild) a single aggregation cache entry.

    1. Lock to prevent concurrent builds of the same entry
    2. Load entry + dataset metadata from DB
    3. Execute aggregation query via FederationEngine
    4. For incremental: merge new data with existing parquet (dedup on dims)
    5. Save parquet to cache dir
    6. Update entry: status=ready, file_path, timestamps, TTL

    Returns True on success, False on failure.
    """
    if not _db_manager or not _federation_engine:
        logger.warning("[agg_cache] Not initialised — cannot build entry %d", entry_id)
        return False

    # Acquire per-entry lock to prevent duplicate concurrent builds
    lock = _get_entry_lock(entry_id)
    if not lock.acquire(blocking=False):
        logger.info("[agg_cache] Build already in progress for entry %d", entry_id)
        return False

    try:
        return _build_cache_entry_locked(entry_id, force)
    finally:
        lock.release()


def _build_cache_entry_locked(entry_id: int, force: bool) -> bool:
    """Internal build logic (called while holding the entry lock)."""
    from core import config

    entry = _db_manager.get_agg_cache_entry(entry_id)
    if not entry:
        logger.warning("[agg_cache] Entry %d not found", entry_id)
        return False

    if not entry.get("is_enabled") and not force:
        logger.info("[agg_cache] Entry %d is disabled, skipping build", entry_id)
        return False

    # Skip if already ready and not forced and not stale/expired
    if entry["status"] == "ready" and not force:
        stale_at = entry.get("stale_at")
        if stale_at:
            stale_dt = _parse_dt(stale_at)
            if datetime.now(timezone.utc) < stale_dt:
                logger.debug("[agg_cache] Entry %d is fresh, skipping build", entry_id)
                return True

    dataset_id = entry["dataset_id"]
    ds = _db_manager.get_dataset_full(dataset_id)
    if not ds:
        _db_manager.update_agg_cache_entry(entry_id, status="failed",
                                            error_message="Dataset not found")
        return False

    # Mark as building
    _db_manager.update_agg_cache_entry(entry_id, status="building", error_message=None)

    t_start = time.monotonic()

    try:
        all_columns = ds.get("columns", [])
        col_map = {c["id"]: c for c in all_columns}

        dim_col_ids = entry.get("dimension_col_ids") or []
        measure_col_ids = entry.get("measure_col_ids") or []

        dim_cols = [col_map[cid] for cid in dim_col_ids if cid in col_map]
        measure_cols = [col_map[cid] for cid in measure_col_ids if cid in col_map]

        if not dim_cols and not measure_cols:
            raise ValueError("No valid dimension or measure columns for cache entry")

        # Build the aggregation SQL
        sql = _build_aggregation_sql(
            dataset=ds,
            dimension_cols=dim_cols,
            measure_cols=measure_cols,
            condition_ids=entry.get("condition_ids") or [],
            incremental_column=entry.get("incremental_column") if entry.get("incremental_enabled") else None,
            incremental_last_value=entry.get("incremental_last_value"),
        )

        logger.info("[agg_cache] Building entry %d (dataset %d): %s",
                     entry_id, dataset_id, sql[:200])

        # Execute via federation engine (leverages DuckDB named secrets, connections)
        build_exec_id = f"agg_cache_{entry_id}_{uuid.uuid4().hex[:8]}"
        result = _federation_engine.execute_dataset_query(
            dataset_id=dataset_id,
            column_ids=dim_col_ids + measure_col_ids,
            condition_ids=entry.get("condition_ids") or [],
            limit=config.federation.max_result_rows,
            execution_id=build_exec_id,
            user_role="admin",
        )

        if not result.output_path or not os.path.isfile(result.output_path):
            raise RuntimeError("Federation engine returned no output file")

        df = pd.read_parquet(result.output_path)

        # Incremental merge if applicable
        if (entry.get("incremental_enabled") and entry.get("file_path")
                and os.path.isfile(entry["file_path"])):
            dim_phys = [c["physical_name"] for c in dim_cols]
            df = _merge_incremental(entry["file_path"], df, dim_phys)

        # Save to cache directory
        ds_cache_dir = _cache_dir / str(dataset_id)
        ds_cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = str(ds_cache_dir / f"entry_{entry_id}.parquet")
        df.to_parquet(cache_path, index=False, engine="pyarrow", compression="snappy")

        file_size = os.path.getsize(cache_path)
        duration = time.monotonic() - t_start

        # Compute TTL timestamps
        now = datetime.now(timezone.utc)
        ttl_hours = config.agg_cache.default_ttl_hours
        hard_hours = config.agg_cache.hard_expiry_hours
        stale_at = now + timedelta(hours=ttl_hours)
        expires_at = now + timedelta(hours=hard_hours)

        # Determine new incremental_last_value
        inc_last = entry.get("incremental_last_value")
        if entry.get("incremental_enabled") and entry.get("incremental_column"):
            inc_col = entry["incremental_column"]
            if inc_col in df.columns and len(df) > 0:
                inc_last = str(df[inc_col].max())

        _db_manager.update_agg_cache_entry(entry_id,
            status="ready",
            file_path=cache_path,
            file_size_bytes=file_size,
            row_count=len(df),
            last_built_at=now,
            stale_at=stale_at,
            expires_at=expires_at,
            build_duration_seconds=round(duration, 3),
            error_message=None,
            incremental_last_value=inc_last,
        )

        # Clean up temporary federation output
        try:
            if result.output_path != cache_path and os.path.isfile(result.output_path):
                os.remove(result.output_path)
        except OSError:
            pass

        logger.info("[agg_cache] Entry %d built: %d rows, %.1fs, %s",
                     entry_id, len(df), duration,
                     _fmt_size(file_size))
        return True

    except Exception as exc:
        duration = time.monotonic() - t_start
        logger.error("[agg_cache] Build failed for entry %d: %s", entry_id, exc)
        _db_manager.update_agg_cache_entry(entry_id,
            status="failed",
            error_message=str(exc)[:2000],
            build_duration_seconds=round(duration, 3),
        )
        return False


def _build_aggregation_sql(
    dataset: Dict[str, Any],
    dimension_cols: List[Dict[str, Any]],
    measure_cols: List[Dict[str, Any]],
    condition_ids: List[int] = None,
    incremental_column: str = None,
    incremental_last_value: str = None,
) -> str:
    """Generate aggregation SQL for a cache entry.

    SELECT dim1, dim2, SUM(measure1) AS measure1, AVG(measure2) AS measure2
    FROM <source>
    [WHERE incremental_col > last_value]
    [AND pre-defined conditions]
    GROUP BY dim1, dim2
    """
    from core.federation_engine import VALID_AGGREGATIONS

    select_parts = []
    group_by_parts = []

    # Dimensions
    for col in dimension_cols:
        phys = f'"{col["physical_name"]}"'
        select_parts.append(phys)
        group_by_parts.append(phys)

    # Measures with aggregation
    for col in measure_cols:
        phys = f'"{col["physical_name"]}"'
        agg = (col.get("aggregation") or "SUM").upper()
        if agg not in VALID_AGGREGATIONS:
            agg = "SUM"
        if agg == "COUNT_DISTINCT":
            select_parts.append(f"COUNT(DISTINCT {phys}) AS {phys}")
        else:
            select_parts.append(f"{agg}({phys}) AS {phys}")

    if not select_parts:
        raise ValueError("No columns to select for aggregation cache")

    # WHERE clauses
    where_parts = []

    # Incremental filter
    if incremental_column and incremental_last_value:
        where_parts.append(f'"{incremental_column}" > \'{incremental_last_value}\'')

    # Pre-defined conditions
    if condition_ids:
        conditions = dataset.get("conditions", [])
        for cond in conditions:
            if cond.get("id") in condition_ids and cond.get("where_clause"):
                where_parts.append(f"({cond['where_clause']})")

    # Build final SQL (the federation engine will wrap this as needed)
    sql = f"SELECT {', '.join(select_parts)}"
    if where_parts:
        sql += f" WHERE {' AND '.join(where_parts)}"
    if group_by_parts:
        sql += f" GROUP BY {', '.join(group_by_parts)}"

    return sql


def _merge_incremental(existing_path: str, new_df: pd.DataFrame,
                       dimension_cols: List[str]) -> pd.DataFrame:
    """Merge incremental refresh data with existing cache.

    New data replaces old for matching dimension keys; new rows are appended.
    """
    try:
        existing_df = pd.read_parquet(existing_path)
        if dimension_cols:
            # Concat and deduplicate, keeping new data
            combined = pd.concat([existing_df, new_df], ignore_index=True)
            combined = combined.drop_duplicates(subset=dimension_cols, keep="last")
            return combined
        else:
            return new_df
    except Exception as exc:
        logger.warning("[agg_cache] Incremental merge failed, using new data only: %s", exc)
        return new_df


def _trigger_background_refresh(entry_id: int) -> None:
    """Schedule a non-blocking background refresh for a stale cache entry."""
    try:
        t = threading.Thread(
            target=build_cache_entry,
            args=(entry_id, True),
            name=f"agg_cache_refresh_{entry_id}",
            daemon=True,
        )
        t.start()
        logger.info("[agg_cache] Background refresh triggered for entry %d", entry_id)
    except Exception as exc:
        logger.warning("[agg_cache] Failed to trigger background refresh for %d: %s",
                       entry_id, exc)


# ═══════════════════════════════════════════════════════════════════════════════
# Usage Analysis — Power BI Auto-Aggregations
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_usage_patterns(dataset_id: int = None) -> List[Dict[str, Any]]:
    """Analyze FederationExecution history to find frequently-used patterns.

    Algorithm:
      1. Fetch completed executions from the analysis window
      2. For each, extract dim/measure column IDs using DatasetColumn metadata
      3. Group by (frozenset(dims), frozenset(measures))
      4. Count occurrences and estimate speedup
      5. For groups >= suggestion_min_queries, create AggCacheSuggestion
    """
    if not _db_manager:
        return []

    from core import config
    if not config.agg_cache.suggestion_enabled:
        return []

    window_days = config.agg_cache.suggestion_analysis_window_days
    min_queries = config.agg_cache.suggestion_min_queries
    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)

    # Fetch recent completed executions
    all_execs = _db_manager.list_federation_executions()
    recent = [
        e for e in all_execs
        if e.get("status") == "completed"
        and e.get("created_at")
        and _parse_dt(e["created_at"]) >= cutoff
    ]

    if dataset_id is not None:
        recent = [e for e in recent if e.get("dataset_id") == dataset_id]

    # Group by (dataset_id, frozenset(column_ids))
    pattern_counter: Dict[Tuple, List[Dict]] = {}
    for ex in recent:
        ds_id = ex.get("dataset_id")
        col_ids = tuple(sorted(ex.get("column_ids") or []))
        key = (ds_id, col_ids)
        pattern_counter.setdefault(key, []).append(ex)

    new_suggestions = []

    for (ds_id, col_ids), executions in pattern_counter.items():
        if len(executions) < min_queries:
            continue

        # Resolve columns into dims vs measures
        ds = _db_manager.get_dataset_full(ds_id)
        if not ds:
            continue

        col_map = {c["id"]: c for c in ds.get("columns", [])}
        dim_ids = []
        measure_ids = []
        for cid in col_ids:
            col = col_map.get(cid)
            if not col:
                continue
            if col.get("column_type") in ("dimension", "detail"):
                dim_ids.append(cid)
            elif col.get("column_type") in ("measure", "kpi") and col.get("aggregation"):
                measure_ids.append(cid)

        if not dim_ids or not measure_ids:
            continue

        # Check if an existing cache entry already covers this pattern
        existing = _db_manager.list_agg_cache_entries(dataset_id=ds_id)
        already_covered = False
        req_dims = set(dim_ids)
        req_measures = set(measure_ids)
        for ent in existing:
            cache_dims = set(ent.get("dimension_col_ids") or [])
            cache_measures = set(ent.get("measure_col_ids") or [])
            if req_measures.issubset(cache_measures) and req_dims.issubset(cache_dims):
                already_covered = True
                break

        if already_covered:
            continue

        # Check if suggestion already exists
        existing_suggestions = _db_manager.list_agg_cache_suggestions(dataset_id=ds_id)
        already_suggested = any(
            set(s.get("dimension_col_ids") or []) == set(dim_ids)
            and set(s.get("measure_col_ids") or []) == set(measure_ids)
            and s.get("status") in ("pending", "approved", "implemented")
            for s in existing_suggestions
        )
        if already_suggested:
            continue

        # Estimate speedup
        avg_duration = sum(e.get("duration_seconds", 0) for e in executions) / len(executions)
        estimated_speedup = round(avg_duration / 0.1, 1) if avg_duration > 0.1 else 1.0

        suggestion = _db_manager.create_agg_cache_suggestion(
            dataset_id=ds_id,
            dimension_col_ids=sorted(dim_ids),
            measure_col_ids=sorted(measure_ids),
            query_count=len(executions),
            estimated_speedup=estimated_speedup,
        )
        new_suggestions.append(suggestion)
        logger.info("[agg_cache] Created suggestion for dataset %d: %d dims, %d measures, "
                     "%d queries, %.1fx estimated speedup",
                     ds_id, len(dim_ids), len(measure_ids), len(executions), estimated_speedup)

    return new_suggestions


def approve_suggestion(suggestion_id: int, schedule_config: dict = None,
                       created_by: str = "admin") -> Optional[Dict[str, Any]]:
    """Convert a suggestion into an AggCacheEntry and trigger initial build."""
    if not _db_manager:
        return None

    suggestion = _db_manager.list_agg_cache_suggestions()
    match = None
    for s in suggestion:
        if s["id"] == suggestion_id:
            match = s
            break
    if not match:
        return None

    # Create the cache entry
    entry = _db_manager.create_agg_cache_entry(
        dataset_id=match["dataset_id"],
        name=f"Auto-suggested rollup #{suggestion_id}",
        description=f"Auto-generated from {match['query_count']} queries "
                    f"(est. {match['estimated_speedup']}x speedup)",
        dimension_col_ids=match["dimension_col_ids"],
        measure_col_ids=match["measure_col_ids"],
        grain_label="custom",
        schedule_config=schedule_config,
        is_enabled=True,
        created_by=created_by,
    )

    # Update suggestion status
    _db_manager.update_agg_cache_suggestion(
        suggestion_id,
        status="approved",
        reviewed_by=created_by,
        reviewed_at=datetime.now(timezone.utc),
    )

    # Trigger initial build in background
    _trigger_background_refresh(entry["id"])

    return entry


def reject_suggestion(suggestion_id: int, reviewed_by: str = "admin") -> Optional[Dict[str, Any]]:
    """Mark a suggestion as rejected."""
    if not _db_manager:
        return None
    return _db_manager.update_agg_cache_suggestion(
        suggestion_id,
        status="rejected",
        reviewed_by=reviewed_by,
        reviewed_at=datetime.now(timezone.utc),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Lifecycle Management
# ═══════════════════════════════════════════════════════════════════════════════

def cleanup_expired() -> int:
    """Remove hard-expired cache entries: delete parquet files, update status."""
    if not _db_manager:
        return 0

    now = datetime.now(timezone.utc)
    entries = _db_manager.list_agg_cache_entries()
    cleaned = 0

    for entry in entries:
        expires_at = entry.get("expires_at")
        if not expires_at:
            continue
        exp_dt = _parse_dt(expires_at)
        if now <= exp_dt:
            continue
        if entry["status"] in ("expired", "pending"):
            continue

        # Remove parquet file
        fp = entry.get("file_path")
        if fp and os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError as exc:
                logger.warning("[agg_cache] Failed to remove expired file %s: %s", fp, exc)

        _db_manager.update_agg_cache_entry(entry["id"], status="expired", file_path=None,
                                            file_size_bytes=0, row_count=0)
        cleaned += 1

    # Also mark stale entries
    for entry in entries:
        if entry["status"] != "ready":
            continue
        stale_at = entry.get("stale_at")
        if not stale_at:
            continue
        stale_dt = _parse_dt(stale_at)
        if now > stale_dt:
            _db_manager.update_agg_cache_entry(entry["id"], status="stale")

    if cleaned:
        logger.info("[agg_cache] Cleaned %d expired entries", cleaned)
    return cleaned


def enforce_storage_quota() -> int:
    """LRU eviction when total cache size exceeds max_storage_mb."""
    if not _db_manager:
        return 0

    from core import config
    max_bytes = config.agg_cache.max_storage_mb * 1024 * 1024

    entries = _db_manager.list_agg_cache_entries()
    total_size = sum(e.get("file_size_bytes") or 0 for e in entries)

    if total_size <= max_bytes:
        return 0

    # Sort by last_served_at ASC (oldest served first = LRU victims)
    eviction_candidates = [
        e for e in entries
        if e.get("file_path") and e.get("file_size_bytes", 0) > 0
    ]
    eviction_candidates.sort(
        key=lambda e: _parse_dt(e["last_served_at"]) if e.get("last_served_at") else datetime.min.replace(tzinfo=timezone.utc)
    )

    evicted = 0
    for entry in eviction_candidates:
        if total_size <= max_bytes:
            break

        fp = entry.get("file_path")
        size = entry.get("file_size_bytes", 0)
        if fp and os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError:
                continue

        _db_manager.update_agg_cache_entry(entry["id"], status="expired",
                                            file_path=None, file_size_bytes=0, row_count=0)
        total_size -= size
        evicted += 1

    if evicted:
        logger.info("[agg_cache] Evicted %d entries for storage quota enforcement", evicted)
    return evicted


def invalidate_by_dataset(dataset_id: int) -> int:
    """Mark all cache entries for a dataset as stale (called when dataset changes)."""
    if not _db_manager:
        return 0

    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)
    count = 0
    for entry in entries:
        if entry["status"] in ("ready", "building"):
            _db_manager.update_agg_cache_entry(entry["id"], status="stale")
            count += 1
    if count:
        logger.info("[agg_cache] Invalidated %d entries for dataset %d", count, dataset_id)
    return count


def get_cache_stats(dataset_id: int = None) -> Dict[str, Any]:
    """Return aggregated cache statistics."""
    if not _db_manager:
        return {}
    from core import config
    stats = _db_manager.get_agg_cache_stats(dataset_id=dataset_id)
    stats["quota_mb"] = config.agg_cache.max_storage_mb
    stats["usage_percent"] = round(
        stats.get("total_size_mb", 0) / config.agg_cache.max_storage_mb * 100, 1
    ) if config.agg_cache.max_storage_mb else 0
    return stats


def maybe_write_through(dataset_id: int, column_ids: List[int],
                        output_path: str, total_rows: int) -> None:
    """Optionally populate an existing cache entry after a live query (write-through).

    Only updates entries that are stale/expired and match the query pattern.
    Does NOT auto-create new entries.
    """
    if not _db_manager:
        return
    from core import config
    if not config.agg_cache.write_through_enabled:
        return

    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)
    col_set = set(column_ids)

    for entry in entries:
        if entry["status"] not in ("stale", "expired", "pending"):
            continue
        cache_cols = set((entry.get("dimension_col_ids") or []) +
                         (entry.get("measure_col_ids") or []))
        if cache_cols == col_set:
            # Exact match — copy the output as cache
            ds_cache_dir = _cache_dir / str(dataset_id)
            ds_cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path = str(ds_cache_dir / f"entry_{entry['id']}.parquet")
            try:
                shutil.copy2(output_path, cache_path)
                file_size = os.path.getsize(cache_path)
                now = datetime.now(timezone.utc)
                ttl_hours = config.agg_cache.default_ttl_hours
                hard_hours = config.agg_cache.hard_expiry_hours
                _db_manager.update_agg_cache_entry(entry["id"],
                    status="ready",
                    file_path=cache_path,
                    file_size_bytes=file_size,
                    row_count=total_rows,
                    last_built_at=now,
                    stale_at=now + timedelta(hours=ttl_hours),
                    expires_at=now + timedelta(hours=hard_hours),
                    error_message=None,
                )
                logger.info("[agg_cache] Write-through populated entry %d (dataset %d)",
                            entry["id"], dataset_id)
            except Exception as exc:
                logger.warning("[agg_cache] Write-through failed for entry %d: %s",
                               entry["id"], exc)
            break


# ═══════════════════════════════════════════════════════════════════════════════
# Scheduler Integration
# ═══════════════════════════════════════════════════════════════════════════════

def register_scheduled_refreshes(scheduler) -> int:
    """Register APScheduler jobs for all enabled entries with schedule_config.

    Called at startup.  Returns count of jobs registered.
    """
    if not _db_manager:
        return 0

    entries = _db_manager.list_agg_cache_entries()
    count = 0
    for entry in entries:
        if not entry.get("is_enabled") or not entry.get("schedule_config"):
            continue
        if register_cache_entry_schedule(scheduler, entry["id"]):
            count += 1

    logger.info("[agg_cache] Registered %d scheduled refresh jobs", count)
    return count


def register_cache_entry_schedule(scheduler, entry_id: int) -> bool:
    """Register/update the APScheduler job for a single cache entry."""
    if not _db_manager:
        return False

    entry = _db_manager.get_agg_cache_entry(entry_id)
    if not entry or not entry.get("schedule_config"):
        return False

    try:
        from core.scheduler import _build_trigger
        trigger = _build_trigger(entry["schedule_config"])
        job_id = f"__agg_cache_refresh_{entry_id}__"

        scheduler.add_job(
            func=build_cache_entry,
            trigger=trigger,
            id=job_id,
            args=[entry_id, True],
            name=f"Agg Cache: {entry.get('name', entry_id)}",
            replace_existing=True,
            misfire_grace_time=300,
            coalesce=True,
            max_instances=1,
        )
        logger.info("[agg_cache] Registered schedule for entry %d: %s",
                     entry_id, entry["schedule_config"])
        return True
    except Exception as exc:
        logger.warning("[agg_cache] Failed to register schedule for entry %d: %s",
                       entry_id, exc)
        return False


def unregister_cache_entry_schedule(scheduler, entry_id: int) -> bool:
    """Remove the APScheduler job for a cache entry."""
    job_id = f"__agg_cache_refresh_{entry_id}__"
    try:
        scheduler.remove_job(job_id)
        return True
    except Exception:
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _parse_dt(val) -> datetime:
    """Parse a datetime value (string or datetime) into timezone-aware datetime."""
    if isinstance(val, str):
        dt = datetime.fromisoformat(val)
    elif isinstance(val, datetime):
        dt = val
    else:
        return datetime.min.replace(tzinfo=timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _get_entry_lock(entry_id: int) -> threading.Lock:
    """Get or create a per-entry build lock."""
    with _global_lock:
        if entry_id not in _build_locks:
            _build_locks[entry_id] = threading.Lock()
        return _build_locks[entry_id]


def _fmt_size(size_bytes: int) -> str:
    """Human-readable file size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
