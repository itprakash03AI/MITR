"""
Connection Pooling — reuse SQL connectors to avoid 200-800ms setup per query.

Each (connection_id) gets its own pool of SqlConnector instances.
Connectors are lazily created, recycled on release, and evicted after idle timeout.

Usage:
    from core.connection_pool import get_pooled_connector

    with get_pooled_connector(connection_id, connection_type, config, name) as conn:
        result = conn.execute_query("SELECT 1")
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Module-level config ──────────────────────────────────────────────────────
_enabled = True
_max_size = 5
_idle_timeout = 300  # seconds


def init_connection_pool(enabled: bool = True, max_size: int = 5,
                         idle_timeout_seconds: int = 300) -> None:
    global _enabled, _max_size, _idle_timeout
    _enabled = enabled
    _max_size = max_size
    _idle_timeout = idle_timeout_seconds
    logger.info("Connection pool: enabled=%s max_size=%d idle_timeout=%ds",
                _enabled, _max_size, _idle_timeout)


@dataclass
class _PoolEntry:
    connector: Any
    last_used: float = field(default_factory=time.time)
    created_at: float = field(default_factory=time.time)


class ConnectorPool:
    """Thread-safe pool of SqlConnector instances for a single connection_id."""

    def __init__(self, connection_id: int, connection_type: str,
                 config: Dict[str, Any], connection_name: str = ""):
        self.connection_id = connection_id
        self.connection_type = connection_type
        self.config = config
        self.connection_name = connection_name
        self._idle: list[_PoolEntry] = []
        self._active_count: int = 0
        self._lock = threading.Lock()

    def acquire(self, timeout: float = 30.0) -> Any:
        """Get a connector from the pool or create a new one."""
        deadline = time.time() + timeout
        while True:
            with self._lock:
                # Evict expired idle connectors
                self._evict_expired()
                # Try to reuse an idle connector
                if self._idle:
                    entry = self._idle.pop()
                    entry.last_used = time.time()
                    self._active_count += 1
                    return entry.connector
                # Create new if under limit
                if self._active_count < _max_size:
                    self._active_count += 1
                    break  # create outside lock
            # Pool full — wait and retry
            if time.time() >= deadline:
                raise TimeoutError(
                    f"Connection pool for '{self.connection_name}' (id={self.connection_id}) "
                    f"exhausted — {_max_size} active connectors, timeout={timeout}s"
                )
            time.sleep(0.1)

        # Create new connector outside lock
        from core.connectors import get_connector
        connector = get_connector(
            self.connection_type, self.config,
            connection_id=self.connection_id,
            connection_name=self.connection_name,
        )
        return connector

    def release(self, connector: Any) -> None:
        """Return a connector to the pool for reuse."""
        with self._lock:
            self._active_count = max(0, self._active_count - 1)
            if len(self._idle) < _max_size:
                self._idle.append(_PoolEntry(connector=connector))
            else:
                # Pool full — close the connector
                self._safe_close(connector)

    def discard(self, connector: Any) -> None:
        """Discard a connector (e.g. after an error) — don't return to pool."""
        with self._lock:
            self._active_count = max(0, self._active_count - 1)
        self._safe_close(connector)

    def invalidate(self) -> None:
        """Close all idle connectors — called when connection config changes."""
        with self._lock:
            for entry in self._idle:
                self._safe_close(entry.connector)
            self._idle.clear()
        logger.info("Pool invalidated for connection %d (%s)",
                    self.connection_id, self.connection_name)

    def stats(self) -> dict:
        with self._lock:
            return {
                "connection_id": self.connection_id,
                "connection_name": self.connection_name,
                "idle": len(self._idle),
                "active": self._active_count,
                "max_size": _max_size,
            }

    def _evict_expired(self) -> None:
        """Remove idle connectors past the timeout (called under lock)."""
        now = time.time()
        still_good = []
        for entry in self._idle:
            if now - entry.last_used > _idle_timeout:
                self._safe_close(entry.connector)
            else:
                still_good.append(entry)
        self._idle = still_good

    @staticmethod
    def _safe_close(connector) -> None:
        try:
            connector.close()
        except Exception as e:
            logger.debug("Error closing pooled connector: %s", e)


class PoolManager:
    """Global registry of per-connection pools."""

    def __init__(self):
        self._pools: Dict[int, ConnectorPool] = {}
        self._lock = threading.Lock()

    def get_pool(self, connection_id: int, connection_type: str,
                 config: Dict[str, Any], connection_name: str = "") -> ConnectorPool:
        with self._lock:
            pool = self._pools.get(connection_id)
            if pool is None:
                pool = ConnectorPool(connection_id, connection_type, config, connection_name)
                self._pools[connection_id] = pool
            return pool

    def invalidate_pool(self, connection_id: int) -> None:
        """Invalidate a pool when connection config changes."""
        with self._lock:
            pool = self._pools.pop(connection_id, None)
        if pool:
            pool.invalidate()

    def get_all_stats(self) -> list:
        with self._lock:
            pools = list(self._pools.values())
        return [p.stats() for p in pools]

    def shutdown(self) -> None:
        """Close all pools — called on app shutdown."""
        with self._lock:
            pools = list(self._pools.values())
            self._pools.clear()
        for pool in pools:
            pool.invalidate()


# Module-level singleton
_pool_manager = PoolManager()


@contextmanager
def get_pooled_connector(connection_id: int, connection_type: str,
                         config: Dict[str, Any], connection_name: str = ""):
    """Context manager that acquires a pooled connector and releases it on exit.

    If pooling is disabled, creates a fresh connector and closes it on exit.
    """
    if not _enabled:
        from core.connectors import get_connector
        connector = get_connector(connection_type, config,
                                  connection_id=connection_id,
                                  connection_name=connection_name)
        try:
            yield connector
        finally:
            try:
                connector.close()
            except Exception:
                pass
        return

    pool = _pool_manager.get_pool(connection_id, connection_type, config, connection_name)
    connector = pool.acquire()
    error_occurred = False
    try:
        yield connector
    except Exception:
        error_occurred = True
        raise
    finally:
        if error_occurred:
            pool.discard(connector)
        else:
            pool.release(connector)


def invalidate_pool(connection_id: int) -> None:
    """Invalidate a pool — called when connection config changes."""
    _pool_manager.invalidate_pool(connection_id)


def get_pool_stats() -> list:
    """Return stats for all pools."""
    return _pool_manager.get_all_stats()


def shutdown_pools() -> None:
    """Shutdown all pools — called on app shutdown."""
    _pool_manager.shutdown()
