"""
Abstract task queue + notification queue backends.

Implementations:
  - SqliteTaskQueue:        wraps existing DatabaseManager methods (default)
  - RedisTaskQueue:         Redis sorted sets + hashes + pub/sub
  - SqliteNotificationQueue: wraps existing notification_queue.py functions
  - RedisNotificationQueue:  Redis pub/sub

Factory:
  - init_queue_backend(db_manager) -> (TaskQueueBackend, NotificationQueueBackend)
  - get_task_queue() -> TaskQueueBackend
  - get_notification_queue() -> NotificationQueueBackend

Config (config.json):
  queue.backend = "sqlite" (default) | "redis"
  queue.redis_url = "redis://localhost:6379/0"
"""

from __future__ import annotations

import abc
import json
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Task Queue ABC
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TaskQueueBackend(abc.ABC):
    """Abstract interface for the task queue."""

    @abc.abstractmethod
    def enqueue_task(self, task_id: str, task_type: str, payload: dict,
                     execution_id: str = None, created_by: str = None,
                     priority: int = 5, timeout_seconds: int = 1800,
                     retry_count: int = 0, max_retries: int = 3,
                     delay_seconds: int = 0) -> Dict[str, Any]:
        """Enqueue a new task. Returns task dict.
        delay_seconds > 0 defers availability (used by exponential backoff retries)."""

    @abc.abstractmethod
    def claim_next_task(self, worker_id: str, task_types: list = None) -> Optional[Dict[str, Any]]:
        """Atomically claim the highest-priority pending task. Returns task dict or None."""

    def wait_and_claim_task(self, worker_id: str, timeout: float = 5.0,
                            task_types: list = None) -> Optional[Dict[str, Any]]:
        """Blocking claim. Default falls back to non-blocking claim_next_task."""
        return self.claim_next_task(worker_id, task_types)

    @abc.abstractmethod
    def update_task_progress(self, task_id: str, progress_pct: int,
                             progress_detail: str = None) -> None:
        """Report progress on a running task."""

    @abc.abstractmethod
    def complete_task(self, task_id: str, result: dict = None) -> None:
        """Mark task completed."""

    @abc.abstractmethod
    def fail_task(self, task_id: str, error_message: str) -> None:
        """Mark task failed."""

    @abc.abstractmethod
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get a single task by task_id."""

    @abc.abstractmethod
    def list_tasks(self, status: str = None, limit: int = 50) -> List[Dict[str, Any]]:
        """List tasks, optionally filtered by status."""

    @abc.abstractmethod
    def poll_active_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks that are processing or recently completed/failed."""

    @abc.abstractmethod
    def request_task_cancel(self, execution_id: str) -> bool:
        """Request cancellation of a task by execution_id."""

    @abc.abstractmethod
    def is_task_cancelled(self, task_id: str) -> bool:
        """Check if cancellation has been requested for this task."""

    @abc.abstractmethod
    def reclaim_stale_tasks(self, stale_seconds: int = 600) -> int:
        """Re-queue tasks stuck in claimed/processing state."""

    @abc.abstractmethod
    def cleanup_old_tasks(self, max_age_hours: int = 24) -> int:
        """Delete/expire completed/failed tasks older than threshold."""

    async def subscribe_task_events(self) -> AsyncIterator[Dict[str, Any]]:
        """Async generator yielding task state-change events (Redis pub/sub).
        Not implemented for SQLite (uses polling instead)."""
        raise NotImplementedError("This backend uses polling, not subscription")
        yield  # noqa — make it an async generator

    @property
    def backend_type(self) -> str:
        return "unknown"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Notification Queue ABC
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class NotificationQueueBackend(abc.ABC):
    """Abstract interface for the notification queue."""

    @abc.abstractmethod
    def enqueue(self, payload: Dict[str, Any]) -> str:
        """Insert a notification. Returns an id."""

    @abc.abstractmethod
    def poll(self, limit: int = 50) -> List[Tuple[str, Dict[str, Any]]]:
        """Fetch undelivered notifications. Returns [(id, payload)]."""

    @abc.abstractmethod
    def mark_delivered(self, ids: List[str]) -> None:
        """Mark notifications as delivered."""

    @abc.abstractmethod
    def cleanup_old(self, max_age_hours: int = 1) -> int:
        """Delete old delivered notifications."""

    async def subscribe(self) -> AsyncIterator[Dict[str, Any]]:
        """Async generator yielding notifications in real time (Redis pub/sub).
        Not implemented for SQLite (uses polling instead)."""
        raise NotImplementedError("This backend uses polling, not subscription")
        yield  # noqa

    @property
    def backend_type(self) -> str:
        return "unknown"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SQLite Implementations (wrappers around existing code)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class SqliteTaskQueue(TaskQueueBackend):
    """SQLite-backed task queue. Delegates to existing DatabaseManager methods."""

    def __init__(self, db_manager):
        self._db = db_manager

    @property
    def backend_type(self) -> str:
        return "sqlite"

    def enqueue_task(self, task_id, task_type, payload, execution_id=None,
                     created_by=None, priority=5, timeout_seconds=1800,
                     retry_count=0, max_retries=3, delay_seconds=0):
        return self._db.enqueue_task(
            task_id=task_id, task_type=task_type, payload=payload,
            execution_id=execution_id, created_by=created_by,
            priority=priority, timeout_seconds=timeout_seconds,
            retry_count=retry_count, max_retries=max_retries,
            delay_seconds=delay_seconds,
        )

    def claim_next_task(self, worker_id, task_types=None):
        return self._db.claim_next_task(worker_id, task_types)

    def update_task_progress(self, task_id, progress_pct, progress_detail=None):
        self._db.update_task_progress(task_id, progress_pct, progress_detail)

    def complete_task(self, task_id, result=None):
        self._db.complete_task(task_id, result)

    def fail_task(self, task_id, error_message):
        self._db.fail_task(task_id, error_message)

    def get_task(self, task_id):
        return self._db.get_task(task_id)

    def list_tasks(self, status=None, limit=50):
        return self._db.list_tasks(status=status, limit=limit)

    def poll_active_tasks(self):
        return self._db.poll_active_tasks()

    def request_task_cancel(self, execution_id):
        return self._db.request_task_cancel(execution_id)

    def is_task_cancelled(self, task_id):
        return self._db.is_task_cancelled(task_id)

    def reclaim_stale_tasks(self, stale_seconds=600):
        return self._db.reclaim_stale_tasks(stale_seconds)

    def cleanup_old_tasks(self, max_age_hours=24):
        return self._db.cleanup_old_tasks(max_age_hours)


class SqliteNotificationQueue(NotificationQueueBackend):
    """SQLite-backed notification queue. Wraps existing notification_queue.py."""

    def __init__(self, session_factory):
        self._sf = session_factory

    @property
    def backend_type(self) -> str:
        return "sqlite"

    def enqueue(self, payload):
        from core.notification_queue import enqueue as _enqueue
        row_id = _enqueue(self._sf, payload)
        return str(row_id)

    def poll(self, limit=50):
        from core.notification_queue import poll as _poll
        return [(str(nid), p) for nid, p in _poll(self._sf, limit)]

    def mark_delivered(self, ids):
        from core.notification_queue import mark_delivered as _mark
        _mark(self._sf, [int(i) for i in ids])

    def cleanup_old(self, max_age_hours=1):
        from core.notification_queue import cleanup_old as _cleanup
        return _cleanup(self._sf, max_age_hours)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Redis Implementations
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class RedisTaskQueue(TaskQueueBackend):
    """Redis-backed task queue using sorted sets + hashes + pub/sub.

    Data model:
      - Sorted set  {prefix}:pending           -- score = priority*1e9 + timestamp
      - Hash        {prefix}:task:{task_id}     -- all task fields
      - Key         {prefix}:cancel:{task_id}   -- exists if cancel requested
      - Set         {prefix}:active             -- task_ids currently processing
      - Pub/Sub     {prefix}:events             -- task state change events
    """

    def __init__(self, redis_url: str, key_prefix: str = "qs",
                 redis_password: str = None, redis_db: int = 0,
                 redis_ssl: bool = False, task_ttl_hours: int = 24):
        import redis as redis_lib
        self._prefix = key_prefix
        self._task_ttl = task_ttl_hours * 3600

        conn_kwargs = dict(
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=10,
            retry_on_timeout=True,
        )
        if redis_password:
            conn_kwargs["password"] = redis_password
        if redis_ssl:
            conn_kwargs["ssl"] = True

        self._r = redis_lib.Redis.from_url(redis_url, db=redis_db, **conn_kwargs)
        self._r.ping()
        logger.info("Redis task queue connected: %s (prefix=%s)", redis_url, key_prefix)

    @property
    def backend_type(self) -> str:
        return "redis"

    def _key(self, *parts) -> str:
        return ":".join([self._prefix] + list(parts))

    def _task_key(self, task_id: str) -> str:
        return self._key("task", task_id)

    def _score(self, priority: int) -> float:
        """Lower priority number = higher priority. Tiebreak on timestamp."""
        return priority * 1_000_000_000 + time.time()

    def _deserialize_task(self, data: dict) -> Dict[str, Any]:
        """Convert Redis hash values back to expected types."""
        if not data:
            return {}
        result = dict(data)
        # Parse JSON fields
        for field in ("payload", "result"):
            val = result.get(field, "")
            if val and isinstance(val, str):
                try:
                    result[field] = json.loads(val)
                except (json.JSONDecodeError, ValueError):
                    pass
        # Parse int fields
        for field in ("priority", "progress_pct", "timeout_seconds",
                      "retry_count", "max_retries", "cancel_requested"):
            val = result.get(field)
            if val is not None:
                try:
                    result[field] = int(val)
                except (ValueError, TypeError):
                    pass
        return result

    def _promote_delayed_tasks(self) -> None:
        """Move any delayed tasks whose available_at has passed into the pending set."""
        now_ts = time.time()
        delayed_key = self._key("delayed")
        due = self._r.zrangebyscore(delayed_key, 0, now_ts, withscores=False)
        if not due:
            return
        # Pre-fetch priorities before building pipeline (pipeline can't return values mid-build)
        priorities = {
            tid: int(self._r.hget(self._task_key(tid), "priority") or 5)
            for tid in due
        }
        pipe = self._r.pipeline()
        for task_id in due:
            pipe.zrem(delayed_key, task_id)
            pipe.zadd(self._key("pending"), {task_id: self._score(priorities[task_id])})
            pipe.hset(self._task_key(task_id), "status", "pending")
        pipe.execute()

    def enqueue_task(self, task_id, task_type, payload, execution_id=None,
                     created_by=None, priority=5, timeout_seconds=1800,
                     retry_count=0, max_retries=3, delay_seconds=0):
        now = datetime.now(timezone.utc).isoformat()
        task_data = {
            "task_id": task_id,
            "task_type": task_type,
            "status": "pending" if delay_seconds <= 0 else "delayed",
            "priority": priority,
            "payload": json.dumps(payload),
            "result": "",
            "error_message": "",
            "progress_pct": 0,
            "progress_detail": "",
            "execution_id": execution_id or "",
            "claimed_by": "",
            "created_by": created_by or "",
            "created_at": now,
            "claimed_at": "",
            "started_at": "",
            "completed_at": "",
            "timeout_seconds": timeout_seconds,
            "retry_count": retry_count,
            "max_retries": max_retries,
            "cancel_requested": 0,
        }
        pipe = self._r.pipeline()
        pipe.hset(self._task_key(task_id), mapping=task_data)
        if delay_seconds > 0:
            available_at = time.time() + delay_seconds
            pipe.zadd(self._key("delayed"), {task_id: available_at})
        else:
            pipe.zadd(self._key("pending"), {task_id: self._score(priority)})
        pipe.execute()
        return self._deserialize_task(task_data)

    def claim_next_task(self, worker_id, task_types=None):
        self._promote_delayed_tasks()
        result = self._r.zpopmin(self._key("pending"), count=1)
        if not result:
            return None
        task_id = result[0][0]
        return self._try_claim(task_id, worker_id, task_types)

    def wait_and_claim_task(self, worker_id, timeout=5.0, task_types=None):
        """Blocking claim using BZPOPMIN — instant delivery, no polling."""
        self._promote_delayed_tasks()
        result = self._r.bzpopmin(self._key("pending"), timeout=timeout)
        if not result:
            return None
        _zset_name, task_id, _score = result
        return self._try_claim(task_id, worker_id, task_types)

    def _try_claim(self, task_id, worker_id, task_types=None):
        now = datetime.now(timezone.utc).isoformat()
        task_data = self._r.hgetall(self._task_key(task_id))
        if not task_data:
            return None

        if task_types and task_data.get("task_type") not in task_types:
            priority = int(task_data.get("priority", 5))
            self._r.zadd(self._key("pending"), {task_id: self._score(priority)})
            return None

        pipe = self._r.pipeline()
        pipe.hset(self._task_key(task_id), mapping={
            "status": "claimed",
            "claimed_by": worker_id,
            "claimed_at": now,
        })
        pipe.sadd(self._key("active"), task_id)
        pipe.execute()

        task_data = self._r.hgetall(self._task_key(task_id))
        return self._deserialize_task(task_data)

    def update_task_progress(self, task_id, progress_pct, progress_detail=None):
        now = datetime.now(timezone.utc).isoformat()
        updates: Dict[str, Any] = {"progress_pct": progress_pct, "status": "processing"}
        if progress_detail is not None:
            updates["progress_detail"] = progress_detail

        current_started = self._r.hget(self._task_key(task_id), "started_at")
        if not current_started:
            updates["started_at"] = now

        self._r.hset(self._task_key(task_id), mapping=updates)

        execution_id = self._r.hget(self._task_key(task_id), "execution_id") or ""
        self._r.publish(self._key("events"), json.dumps({
            "type": "task_progress",
            "task_id": task_id,
            "execution_id": execution_id,
            "data": {"progress_pct": progress_pct, "detail": progress_detail or ""},
        }))

    def complete_task(self, task_id, result=None):
        now = datetime.now(timezone.utc).isoformat()
        execution_id = self._r.hget(self._task_key(task_id), "execution_id") or ""

        pipe = self._r.pipeline()
        pipe.hset(self._task_key(task_id), mapping={
            "status": "completed",
            "progress_pct": 100,
            "result": json.dumps(result) if result else "",
            "completed_at": now,
        })
        pipe.srem(self._key("active"), task_id)
        pipe.zadd(self._key("finished"), {task_id: time.time()})
        pipe.expire(self._task_key(task_id), self._task_ttl)
        pipe.execute()

        self._r.publish(self._key("events"), json.dumps({
            "type": "task_completed",
            "task_id": task_id,
            "execution_id": execution_id,
            "data": result or {},
        }))

    def fail_task(self, task_id, error_message):
        now = datetime.now(timezone.utc).isoformat()
        execution_id = self._r.hget(self._task_key(task_id), "execution_id") or ""

        pipe = self._r.pipeline()
        pipe.hset(self._task_key(task_id), mapping={
            "status": "failed",
            "error_message": error_message,
            "completed_at": now,
        })
        pipe.srem(self._key("active"), task_id)
        pipe.zadd(self._key("finished"), {task_id: time.time()})
        pipe.expire(self._task_key(task_id), self._task_ttl)
        pipe.execute()

        self._r.publish(self._key("events"), json.dumps({
            "type": "task_failed",
            "task_id": task_id,
            "execution_id": execution_id,
            "data": {"error": error_message},
        }))

    def get_task(self, task_id):
        data = self._r.hgetall(self._task_key(task_id))
        return self._deserialize_task(data) if data else None

    def list_tasks(self, status=None, limit=50):
        task_ids = set()
        task_ids.update(self._r.smembers(self._key("active")))
        task_ids.update(self._r.zrange(self._key("pending"), 0, -1))
        task_ids.update(self._r.zrange(self._key("finished"), 0, -1))

        tasks = []
        for tid in task_ids:
            data = self._r.hgetall(self._task_key(tid))
            if data and (status is None or data.get("status") == status):
                tasks.append(self._deserialize_task(data))
        tasks.sort(key=lambda t: t.get("created_at", ""), reverse=True)
        return tasks[:limit]

    def poll_active_tasks(self):
        task_ids = self._r.smembers(self._key("active"))
        tasks = []
        for tid in task_ids:
            data = self._r.hgetall(self._task_key(tid))
            if data:
                tasks.append(self._deserialize_task(data))
        return tasks

    def request_task_cancel(self, execution_id):
        for tid in self._r.smembers(self._key("active")):
            eid = self._r.hget(self._task_key(tid), "execution_id")
            if eid == execution_id:
                self._r.hset(self._task_key(tid), "cancel_requested", 1)
                self._r.set(self._key("cancel", tid), "1", ex=3600)
                return True

        for tid in self._r.zrange(self._key("pending"), 0, -1):
            eid = self._r.hget(self._task_key(tid), "execution_id")
            if eid == execution_id:
                self._r.zrem(self._key("pending"), tid)
                self._r.hset(self._task_key(tid), mapping={
                    "status": "cancelled",
                    "cancel_requested": 1,
                    "error_message": "Cancelled by user",
                    "completed_at": datetime.now(timezone.utc).isoformat(),
                })
                self._r.expire(self._task_key(tid), self._task_ttl)
                return True
        return False

    def is_task_cancelled(self, task_id):
        return self._r.exists(self._key("cancel", task_id)) > 0

    def reclaim_stale_tasks(self, stale_seconds=600):
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=stale_seconds)
        count = 0
        for tid in list(self._r.smembers(self._key("active"))):
            data = self._r.hgetall(self._task_key(tid))
            if not data:
                self._r.srem(self._key("active"), tid)
                continue
            claimed_at = data.get("claimed_at", "")
            if not claimed_at:
                continue
            try:
                claimed_dt = datetime.fromisoformat(claimed_at)
                if claimed_dt.tzinfo is None:
                    claimed_dt = claimed_dt.replace(tzinfo=timezone.utc)
            except ValueError:
                continue
            if claimed_dt < cutoff:
                retry = int(data.get("retry_count", 0))
                max_r = int(data.get("max_retries", 0))
                if retry < max_r:
                    priority = int(data.get("priority", 5))
                    pipe = self._r.pipeline()
                    pipe.hset(self._task_key(tid), mapping={
                        "status": "pending", "claimed_by": "",
                        "claimed_at": "", "retry_count": retry + 1,
                    })
                    pipe.srem(self._key("active"), tid)
                    pipe.zadd(self._key("pending"), {tid: self._score(priority)})
                    pipe.execute()
                else:
                    pipe = self._r.pipeline()
                    pipe.hset(self._task_key(tid), mapping={
                        "status": "failed",
                        "error_message": "Executor timed out — max retries exceeded",
                        "completed_at": datetime.now(timezone.utc).isoformat(),
                    })
                    pipe.srem(self._key("active"), tid)
                    pipe.zadd(self._key("finished"), {tid: time.time()})
                    pipe.expire(self._task_key(tid), self._task_ttl)
                    pipe.execute()
                count += 1
        return count

    def cleanup_old_tasks(self, max_age_hours=24):
        # Prune finished set — remove entries older than max_age
        cutoff = time.time() - (max_age_hours * 3600)
        removed = self._r.zremrangebyscore(self._key("finished"), 0, cutoff)
        return removed

    async def subscribe_task_events(self) -> AsyncIterator[Dict[str, Any]]:
        """Async generator yielding task events via Redis pub/sub."""
        import redis.asyncio as aioredis
        from core.config import queue as _qcfg
        r = aioredis.Redis.from_url(
            _qcfg.redis_url,
            db=_qcfg.redis_db,
            password=_qcfg.redis_password or None,
            ssl=_qcfg.redis_ssl,
            decode_responses=True,
        )
        pubsub = r.pubsub()
        await pubsub.subscribe(self._key("events"))
        try:
            async for message in pubsub.listen():
                if message["type"] != "message":
                    continue
                try:
                    data = json.loads(message["data"])
                    yield data
                except (json.JSONDecodeError, ValueError):
                    continue
        finally:
            await pubsub.unsubscribe(self._key("events"))
            await r.aclose()

    def get_status(self) -> Dict[str, Any]:
        """Return Redis queue health info for admin panel."""
        try:
            info = self._r.info(section="server")
            pending_count = self._r.zcard(self._key("pending"))
            active_count = self._r.scard(self._key("active"))
            return {
                "backend": "redis",
                "connected": True,
                "redis_version": info.get("redis_version", "unknown"),
                "pending_tasks": pending_count,
                "active_tasks": active_count,
                "key_prefix": self._prefix,
            }
        except Exception as exc:
            return {"backend": "redis", "connected": False, "error": str(exc)}


class RedisNotificationQueue(NotificationQueueBackend):
    """Redis-backed notification queue using pub/sub + list backup."""

    def __init__(self, redis_client, key_prefix: str = "qs"):
        self._r = redis_client
        self._prefix = key_prefix

    @property
    def backend_type(self) -> str:
        return "redis"

    def _key(self, *parts) -> str:
        return ":".join([self._prefix] + list(parts))

    def enqueue(self, payload):
        msg = json.dumps(payload)
        self._r.publish(self._key("notifications"), msg)
        # Also push to a list for durability (in case no subscriber is listening)
        msg_id = str(uuid.uuid4().hex[:12])
        self._r.lpush(self._key("notif_queue"), msg)
        self._r.ltrim(self._key("notif_queue"), 0, 999)  # keep last 1000
        return msg_id

    def poll(self, limit=50):
        """Pop from the backup list (for fallback compatibility)."""
        results = []
        for _ in range(limit):
            msg = self._r.rpop(self._key("notif_queue"))
            if not msg:
                break
            try:
                payload = json.loads(msg)
                results.append((str(uuid.uuid4().hex[:8]), payload))
            except (json.JSONDecodeError, ValueError):
                continue
        return results

    def mark_delivered(self, ids):
        pass  # pub/sub is fire-and-forget; list items already popped

    def cleanup_old(self, max_age_hours=1):
        # List is already bounded by ltrim
        return 0

    async def subscribe(self) -> AsyncIterator[Dict[str, Any]]:
        """Async generator yielding notifications via Redis pub/sub."""
        import redis.asyncio as aioredis
        from core.config import queue as _qcfg
        r = aioredis.Redis.from_url(
            _qcfg.redis_url,
            db=_qcfg.redis_db,
            password=_qcfg.redis_password or None,
            ssl=_qcfg.redis_ssl,
            decode_responses=True,
        )
        pubsub = r.pubsub()
        await pubsub.subscribe(self._key("notifications"))
        try:
            async for message in pubsub.listen():
                if message["type"] != "message":
                    continue
                try:
                    data = json.loads(message["data"])
                    yield data
                except (json.JSONDecodeError, ValueError):
                    continue
        finally:
            await pubsub.unsubscribe(self._key("notifications"))
            await r.aclose()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Factory + module-level singletons
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_task_queue: Optional[TaskQueueBackend] = None
_notif_queue: Optional[NotificationQueueBackend] = None


def init_queue_backend(db_manager) -> Tuple[TaskQueueBackend, NotificationQueueBackend]:
    """Initialize queue backend based on config. Falls back to SQLite on Redis failure."""
    global _task_queue, _notif_queue

    from core.config import queue as _qcfg

    backend = _qcfg.backend

    if backend == "redis":
        try:
            tq = RedisTaskQueue(
                redis_url=_qcfg.redis_url,
                key_prefix=_qcfg.key_prefix,
                redis_password=_qcfg.redis_password or None,
                redis_db=_qcfg.redis_db,
                redis_ssl=_qcfg.redis_ssl,
                task_ttl_hours=_qcfg.task_ttl_hours,
            )
            nq = RedisNotificationQueue(tq._r, key_prefix=_qcfg.key_prefix)
            _task_queue = tq
            _notif_queue = nq
            logger.info("Queue backend: Redis (%s)", _qcfg.redis_url)
            return _task_queue, _notif_queue
        except Exception as exc:
            logger.warning(
                "Redis connection failed (%s) — falling back to SQLite queue: %s",
                _qcfg.redis_url, exc,
            )

    # Default / fallback: SQLite
    _task_queue = SqliteTaskQueue(db_manager)
    _notif_queue = SqliteNotificationQueue(db_manager.SessionLocal)
    logger.info("Queue backend: SQLite")
    return _task_queue, _notif_queue


def get_task_queue() -> TaskQueueBackend:
    """Get the initialized task queue backend."""
    if _task_queue is None:
        raise RuntimeError("Queue backend not initialized — call init_queue_backend() first")
    return _task_queue


def get_notification_queue() -> NotificationQueueBackend:
    """Get the initialized notification queue backend."""
    if _notif_queue is None:
        raise RuntimeError("Queue backend not initialized — call init_queue_backend() first")
    return _notif_queue


def get_queue_status() -> Dict[str, Any]:
    """Return queue backend status for admin panel."""
    tq = _task_queue
    if tq is None:
        return {"backend": "not_initialized", "connected": False}
    if isinstance(tq, RedisTaskQueue):
        return tq.get_status()
    return {
        "backend": "sqlite",
        "connected": True,
        "pending_tasks": len(tq.list_tasks(status="pending", limit=100)),
        "active_tasks": len(tq.poll_active_tasks()),
    }
