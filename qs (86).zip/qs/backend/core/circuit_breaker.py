"""
Per-connection circuit breaker -- prevents cascading failures when a
SQL connector (Trino/Snowflake/Databricks/Oracle) is down.

States:
  CLOSED    -> normal operation, failures increment counter
  OPEN      -> fast-fail all requests for this connection
  HALF_OPEN -> allow 1 probe request to test recovery

Transitions:
  CLOSED  -> failure_count >= threshold     -> OPEN
  OPEN    -> cooldown_seconds elapsed       -> HALF_OPEN
  HALF_OPEN -> probe succeeds              -> CLOSED (reset counter)
  HALF_OPEN -> probe fails                 -> OPEN   (reset cooldown)
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# -- Configuration -------------------------------------------------------------
_enabled: bool = True
_failure_threshold: int = 3
_cooldown_seconds: int = 60
_half_open_max_calls: int = 1
_broadcast_fn: Optional[Callable] = None


def init_circuit_breaker(enabled: bool = True, failure_threshold: int = 3,
                         cooldown_seconds: int = 60) -> None:
    global _enabled, _failure_threshold, _cooldown_seconds
    _enabled = enabled
    _failure_threshold = failure_threshold
    _cooldown_seconds = cooldown_seconds
    logger.info("[circuit_breaker] Initialised -- enabled=%s threshold=%d cooldown=%ds",
                _enabled, _failure_threshold, _cooldown_seconds)


def set_broadcast_fn(fn: Callable) -> None:
    global _broadcast_fn
    _broadcast_fn = fn


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitOpenError(Exception):
    """Raised when circuit is open and request is rejected."""
    def __init__(self, connection_id: int, connection_name: str, retry_after: float):
        self.connection_id = connection_id
        self.connection_name = connection_name
        self.retry_after = retry_after
        super().__init__(
            f"Circuit breaker OPEN for connection '{connection_name}' (id={connection_id}). "
            f"Retry after {retry_after:.0f}s."
        )


@dataclass
class CircuitBreaker:
    connection_id: int
    connection_name: str
    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_at: Optional[float] = None
    last_success_at: Optional[float] = None
    last_state_change: float = field(default_factory=time.time)
    last_error: Optional[str] = None
    _half_open_calls: int = 0

    def to_dict(self) -> dict:
        return {
            "connection_id": self.connection_id,
            "connection_name": self.connection_name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "last_failure_at": self.last_failure_at,
            "last_success_at": self.last_success_at,
            "last_state_change": self.last_state_change,
            "last_error": self.last_error,
        }


class CircuitBreakerRegistry:
    def __init__(self):
        self._breakers: Dict[int, CircuitBreaker] = {}
        self._lock = threading.Lock()

    def _get_or_create(self, connection_id: int, connection_name: str = "") -> CircuitBreaker:
        if connection_id not in self._breakers:
            self._breakers[connection_id] = CircuitBreaker(
                connection_id=connection_id,
                connection_name=connection_name,
            )
        return self._breakers[connection_id]

    def check(self, connection_id: int, connection_name: str = "") -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._get_or_create(connection_id, connection_name)
            now = time.time()

            if cb.state == CircuitState.CLOSED:
                return  # allow

            if cb.state == CircuitState.OPEN:
                elapsed = now - cb.last_state_change
                if elapsed >= _cooldown_seconds:
                    # Transition to HALF_OPEN
                    cb.state = CircuitState.HALF_OPEN
                    cb.last_state_change = now
                    cb._half_open_calls = 0
                    logger.info("[circuit_breaker] %s (id=%d): OPEN -> HALF_OPEN (cooldown elapsed)",
                                cb.connection_name, connection_id)
                    self._broadcast_state_change(cb)
                    return  # allow probe
                else:
                    retry_after = _cooldown_seconds - elapsed
                    raise CircuitOpenError(connection_id, cb.connection_name, retry_after)

            if cb.state == CircuitState.HALF_OPEN:
                if cb._half_open_calls >= _half_open_max_calls:
                    raise CircuitOpenError(connection_id, cb.connection_name, _cooldown_seconds)
                cb._half_open_calls += 1

    def record_success(self, connection_id: int) -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._breakers.get(connection_id)
            if not cb:
                return
            cb.success_count += 1
            cb.last_success_at = time.time()

            if cb.state == CircuitState.HALF_OPEN:
                # Recovery confirmed
                cb.state = CircuitState.CLOSED
                cb.failure_count = 0
                cb._half_open_calls = 0
                cb.last_state_change = time.time()
                logger.info("[circuit_breaker] %s (id=%d): HALF_OPEN -> CLOSED (recovery confirmed)",
                            cb.connection_name, connection_id)
                self._broadcast_state_change(cb)
            elif cb.state == CircuitState.CLOSED:
                # Reset failure count on success
                cb.failure_count = 0

    def record_failure(self, connection_id: int, error: str, connection_name: str = "") -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._get_or_create(connection_id, connection_name)
            cb.failure_count += 1
            cb.last_failure_at = time.time()
            cb.last_error = error[:500]  # Truncate long errors

            if cb.state == CircuitState.HALF_OPEN:
                # Probe failed -- back to OPEN
                cb.state = CircuitState.OPEN
                cb.last_state_change = time.time()
                cb._half_open_calls = 0
                logger.warning("[circuit_breaker] %s (id=%d): HALF_OPEN -> OPEN (probe failed: %s)",
                               cb.connection_name, connection_id, error[:100])
                self._broadcast_state_change(cb)
            elif cb.state == CircuitState.CLOSED and cb.failure_count >= _failure_threshold:
                cb.state = CircuitState.OPEN
                cb.last_state_change = time.time()
                logger.warning("[circuit_breaker] %s (id=%d): CLOSED -> OPEN (failures=%d >= threshold=%d: %s)",
                               cb.connection_name, connection_id, cb.failure_count,
                               _failure_threshold, error[:100])
                self._broadcast_state_change(cb)

    def reset(self, connection_id: int) -> Optional[dict]:
        with self._lock:
            cb = self._breakers.get(connection_id)
            if not cb:
                return None
            old_state = cb.state
            cb.state = CircuitState.CLOSED
            cb.failure_count = 0
            cb._half_open_calls = 0
            cb.last_state_change = time.time()
            logger.info("[circuit_breaker] %s (id=%d): %s -> CLOSED (manual reset)",
                        cb.connection_name, connection_id, old_state.value)
            self._broadcast_state_change(cb)
            return cb.to_dict()

    def get_all_states(self) -> List[dict]:
        with self._lock:
            return [cb.to_dict() for cb in self._breakers.values()]

    def get_state(self, connection_id: int) -> Optional[dict]:
        with self._lock:
            cb = self._breakers.get(connection_id)
            return cb.to_dict() if cb else None

    def _broadcast_state_change(self, cb: CircuitBreaker) -> None:
        if _broadcast_fn:
            try:
                from datetime import datetime, timezone
                _broadcast_fn({
                    "type": "circuit_breaker_state_change",
                    "connection_id": cb.connection_id,
                    "connection_name": cb.connection_name,
                    "state": cb.state.value,
                    "failure_count": cb.failure_count,
                    "last_error": cb.last_error,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            except Exception as exc:
                logger.debug("[circuit_breaker] broadcast failed: %s", exc)


# -- Module-level singleton ----------------------------------------------------
_registry = CircuitBreakerRegistry()


def check_circuit(connection_id: int, connection_name: str = "") -> None:
    _registry.check(connection_id, connection_name)

def record_success(connection_id: int) -> None:
    _registry.record_success(connection_id)

def record_failure(connection_id: int, error: str, connection_name: str = "") -> None:
    _registry.record_failure(connection_id, error, connection_name)

def reset_circuit(connection_id: int) -> Optional[dict]:
    return _registry.reset(connection_id)

def get_circuit_states() -> List[dict]:
    return _registry.get_all_states()

def get_circuit_state(connection_id: int) -> Optional[dict]:
    return _registry.get_state(connection_id)
