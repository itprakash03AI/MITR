"""
AWS Portal Credential Provider — automatically fetch temporary AWS credentials
from a corporate credential-provider portal.

Flow:
  1. User provides their portal username + password
  2. POST to JWT endpoint → Bearer token
  3. GET to creds endpoint with Bearer token → AWS temporary credentials
  4. Cache credentials per user (TTL-based auto-refresh)

Config section ``aws_portal`` in config.json controls the portal URLs and behaviour.
"""
from __future__ import annotations

import contextvars
import time
import logging
import threading
from typing import Optional, Dict, Tuple

import requests

from core import config

logger = logging.getLogger(__name__)

# ── Request-scoped context variable for current portal user ───────────────
# Set at the start of each request handler so _make_s3_client_for_conn
# can automatically inject portal credentials without explicit threading.
_current_portal_user: contextvars.ContextVar[str] = contextvars.ContextVar(
    "_current_portal_user", default=""
)

# ── Module-level credential cache ─────────────────────────────────────────
# Key: "<username>"  →  (creds_dict, expiry_epoch)
_cred_cache: Dict[str, Tuple[dict, float]] = {}
_cache_lock = threading.Lock()


def get_cached_credentials(username: str) -> Optional[dict]:
    """Return cached AWS creds for *username* if still valid, else ``None``."""
    with _cache_lock:
        entry = _cred_cache.get(username)
        if entry and time.time() < entry[1]:
            return entry[0]
    return None


def fetch_credentials(username: str, password: str) -> dict:
    """Authenticate against the AWS portal and return temporary AWS credentials.

    Returns dict with keys: ``aws_access_key_id``, ``aws_secret_access_key``,
    ``aws_session_token``, ``expires_at`` (epoch).

    Raises ``PortalAuthError`` on any failure.
    """
    cfg = config.aws_portal
    if not cfg.enabled:
        raise PortalAuthError("AWS portal authentication is not enabled")
    if not cfg.jwt_url:
        raise PortalAuthError("aws_portal.jwt_url is not configured")
    if not cfg.creds_url_template:
        raise PortalAuthError("aws_portal.creds_url_template is not configured")

    verify = cfg.verify_ssl
    timeout = cfg.timeout_seconds

    # ── Step 1: Get JWT token ─────────────────────────────────────────────
    try:
        jwt_resp = requests.post(
            cfg.jwt_url,
            json={"username": username, "password": password},
            verify=verify,
            timeout=timeout,
        )
        jwt_resp.raise_for_status()
        token = jwt_resp.json().get("token")
        if not token:
            raise PortalAuthError("JWT response did not contain a 'token' field")
    except requests.RequestException as exc:
        raise PortalAuthError(f"JWT authentication failed: {exc}") from exc

    # ── Step 2: Get AWS temporary credentials ─────────────────────────────
    creds_url = cfg.creds_url_template.format(
        account_id=cfg.account_id,
        role_name=cfg.role_name,
        session_name=username,
    )
    try:
        creds_resp = requests.get(
            creds_url,
            headers={"Authorization": f"Bearer {token}"},
            verify=verify,
            timeout=timeout,
        )
        creds_resp.raise_for_status()
        raw = creds_resp.json().get("Credentials")
        if not raw:
            raise PortalAuthError("Credentials response did not contain a 'Credentials' field")
    except requests.RequestException as exc:
        raise PortalAuthError(f"Credential fetch failed: {exc}") from exc

    creds = {
        "aws_access_key_id": raw["AccessKeyId"],
        "aws_secret_access_key": raw["SecretAccessKey"],
        "aws_session_token": raw["SessionToken"],
    }

    # ── Cache with TTL ────────────────────────────────────────────────────
    ttl = cfg.creds_ttl_seconds
    expiry = time.time() + ttl
    creds["expires_at"] = expiry
    with _cache_lock:
        _cred_cache[username] = (creds, expiry)

    logger.info("AWS portal credentials fetched for user '%s' (TTL %ds)", username, ttl)
    return creds


def get_or_fetch_credentials(username: str, password: str) -> dict:
    """Return cached credentials if valid, otherwise fetch fresh ones."""
    cached = get_cached_credentials(username)
    if cached:
        return cached
    return fetch_credentials(username, password)


def clear_cache(username: Optional[str] = None) -> int:
    """Clear cached credentials.  Returns number of entries removed."""
    with _cache_lock:
        if username:
            return 1 if _cred_cache.pop(username, None) else 0
        count = len(_cred_cache)
        _cred_cache.clear()
        return count


def cache_stats() -> dict:
    """Return cache statistics."""
    with _cache_lock:
        now = time.time()
        active = sum(1 for _, (_, exp) in _cred_cache.items() if exp > now)
        expired = len(_cred_cache) - active
        return {
            "total_entries": len(_cred_cache),
            "active": active,
            "expired": expired,
            "users": [k for k in _cred_cache.keys()],
        }


def inject_portal_creds(conn_config: dict, username: str) -> dict:
    """If portal auth is enabled, inject AWS creds into the connection config.

    Resolution order:
      1. Connection already has explicit AWS keys → skip (no injection)
      2. User has cached portal creds → inject those (per-user mode)
      3. Service account is configured → auto-fetch + inject (shared mode)
      4. None of the above → return config unchanged

    This is called before building an S3 client so that portal creds are
    used transparently without the user entering AWS keys manually.
    """
    cfg = config.aws_portal
    if not cfg.enabled:
        return conn_config

    # Only inject if the connection doesn't already have explicit keys
    has_explicit = bool(
        (conn_config.get("aws_access_key_id") or "").strip()
        and (conn_config.get("aws_secret_access_key") or "").strip()
    )
    if has_explicit:
        return conn_config

    # Try 1: user has cached portal creds
    cached = get_cached_credentials(username) if username else None

    # Try 2: service account configured → auto-fetch (cached internally)
    if not cached and cfg.service_username and cfg.service_password:
        svc_user = cfg.service_username
        cached = get_cached_credentials(svc_user)
        if not cached:
            try:
                cached = fetch_credentials(svc_user, cfg.service_password)
            except PortalAuthError as exc:
                logger.warning("Service account portal auth failed: %s", exc)
                return conn_config

    if not cached:
        return conn_config

    # Inject portal creds into a COPY of the config (don't mutate original)
    injected = dict(conn_config)
    injected["aws_access_key_id"] = cached["aws_access_key_id"]
    injected["aws_secret_access_key"] = cached["aws_secret_access_key"]
    injected["aws_session_token"] = cached["aws_session_token"]
    injected["auth_mode"] = "keys"  # force keys mode with portal creds
    logger.debug("Injected AWS portal credentials (user='%s')", username or "service-account")
    return injected


class PortalAuthError(Exception):
    """Raised when AWS portal authentication fails."""
    pass
