"""
Cross-process rate limiter (Phase 22B).

Uses Redis sliding-window counters when queue.backend = "redis",
falling back to in-process threading.Lock + dict when SQLite.

Usage:
    from core.rate_limiter import check_rate_limit, RateLimitExceededError

    check_rate_limit("execute", username, limit=10, window_seconds=60)
    # raises RateLimitExceededError if exceeded
"""
from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict, deque
from typing import Optional

logger = logging.getLogger(__name__)


class RateLimitExceededError(Exception):
    """Raised when a rate limit is exceeded."""
    def __init__(self, action: str, limit: int, window: int, retry_after: int):
        self.action = action
        self.limit = limit
        self.window = window
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded for '{action}': {limit} requests per {window}s. "
            f"Retry after {retry_after}s."
        )


# ── In-process fallback (SQLite mode) ────────────────────────────────────────

_local_lock = threading.Lock()
# {(action, identity): deque of timestamps}
_local_windows: dict = defaultdict(deque)


def _check_local(action: str, identity: str, limit: int, window_seconds: int) -> int:
    """Sliding-window rate check using in-process deque. Returns remaining count."""
    key = (action, identity)
    now = time.monotonic()
    cutoff = now - window_seconds
    with _local_lock:
        q = _local_windows[key]
        # Evict expired entries
        while q and q[0] < cutoff:
            q.popleft()
        if len(q) >= limit:
            oldest = q[0]
            retry_after = int(oldest - cutoff) + 1
            raise RateLimitExceededError(action, limit, window_seconds, retry_after)
        q.append(now)
        return limit - len(q)


# ── Redis sliding-window (multi-instance mode) ────────────────────────────────

def _check_redis(action: str, identity: str, limit: int, window_seconds: int,
                 prefix: str = "qs") -> int:
    """Sliding-window rate check via Redis sorted set. Returns remaining count."""
    try:
        from core.queue_backend import get_task_queue
        tq = get_task_queue()
        # Access the underlying Redis client from RedisTaskQueue
        r = getattr(tq, "_r", None)
        if r is None:
            return _check_local(action, identity, limit, window_seconds)

        key = f"{prefix}:ratelimit:{action}:{identity}"
        now_ms = int(time.time() * 1000)
        window_ms = window_seconds * 1000
        cutoff_ms = now_ms - window_ms

        pipe = r.pipeline()
        # Evict old entries, add current, count window, set TTL
        pipe.zremrangebyscore(key, 0, cutoff_ms)
        pipe.zadd(key, {str(now_ms): now_ms})
        pipe.zcard(key)
        pipe.expire(key, window_seconds + 1)
        results = pipe.execute()

        count = results[2]   # zcard result
        if count > limit:
            # Undo the add — we're over limit
            r.zrem(key, str(now_ms))
            # Find oldest entry to compute retry_after
            oldest = r.zrange(key, 0, 0, withscores=True)
            retry_after = 1
            if oldest:
                oldest_ms = oldest[0][1]
                retry_after = max(1, int((oldest_ms + window_ms - now_ms) / 1000) + 1)
            raise RateLimitExceededError(action, limit, window_seconds, retry_after)

        return max(0, limit - count)

    except RateLimitExceededError:
        raise
    except Exception as exc:
        logger.debug("Redis rate limit check failed, using local fallback: %s", exc)
        return _check_local(action, identity, limit, window_seconds)


# ── Public API ────────────────────────────────────────────────────────────────

def check_rate_limit(
    action: str,
    identity: str,
    limit: int,
    window_seconds: int = 60,
) -> int:
    """
    Check a rate limit. Raises RateLimitExceededError if exceeded.
    Returns remaining allowed requests in the current window.

    Uses Redis when available (multi-instance safe), falls back to in-process.

    Args:
        action:         Logical action name (e.g. "execute", "export")
        identity:       Per-identity key (e.g. username or IP)
        limit:          Max requests allowed in the window
        window_seconds: Sliding window duration in seconds
    """
    try:
        from core.config import queue as _qcfg
        if _qcfg.backend == "redis":
            return _check_redis(action, identity, limit, window_seconds,
                                prefix=_qcfg.key_prefix)
    except ImportError:
        pass
    return _check_local(action, identity, limit, window_seconds)
