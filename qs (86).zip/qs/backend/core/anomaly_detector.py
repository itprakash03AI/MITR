"""
Scheduled report anomaly detection — compares current run statistics
against a rolling window of historical runs using z-score analysis.

Detection types:
  zero_rows:        report returned 0 rows (upstream data issue)
  row_count_spike:  row count significantly above historical mean
  row_count_drop:   row count significantly below historical mean
  slow_execution:   execution time significantly above historical mean

Configuration via config.json -> anomaly_detection section:
  z_score_threshold: 2.5
  min_history_runs:  5
  window_size:       20
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, asdict
from typing import List, Optional

logger = logging.getLogger(__name__)

# -- Configuration defaults (overridden by config.json) ------------------------
_z_threshold: float = 2.5
_min_history: int = 5
_window_size: int = 20
_enabled: bool = True


def init_anomaly_detector(enabled: bool = True, z_score_threshold: float = 2.5,
                          min_history_runs: int = 5, window_size: int = 20) -> None:
    global _enabled, _z_threshold, _min_history, _window_size
    _enabled = enabled
    _z_threshold = z_score_threshold
    _min_history = min_history_runs
    _window_size = window_size
    logger.info("[anomaly_detector] Initialised — enabled=%s z=%.1f min_history=%d window=%d",
                _enabled, _z_threshold, _min_history, _window_size)


@dataclass
class AnomalyResult:
    anomaly_type: str       # zero_rows | row_count_spike | row_count_drop | slow_execution
    severity: str           # warning | critical
    current_value: float
    expected_mean: float
    expected_stddev: float
    z_score: float
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


def _compute_stats(values: list) -> tuple:
    """Return (mean, stddev) from a list of numeric values."""
    if not values:
        return 0.0, 0.0
    n = len(values)
    mean = sum(values) / n
    if n < 2:
        return mean, 0.0
    variance = sum((v - mean) ** 2 for v in values) / (n - 1)  # sample stddev
    return mean, math.sqrt(variance)


def check_anomalies(schedule_id: int, current_row_count: int,
                    current_exec_seconds: float, db_manager) -> List[AnomalyResult]:
    """Compare current run to historical stats. Return list of anomalies (may be empty)."""
    if not _enabled:
        return []

    anomalies: List[AnomalyResult] = []

    try:
        history = db_manager.get_schedule_run_stats(schedule_id, limit=_window_size)
    except Exception as exc:
        logger.warning("[anomaly_detector] Failed to get history for schedule %d: %s",
                       schedule_id, exc)
        return []

    if len(history) < _min_history:
        return []  # Not enough data to detect anomalies

    # Extract historical values
    hist_rows = [h["row_count"] for h in history if h.get("row_count") is not None]
    hist_secs = [h["execution_seconds"] for h in history if h.get("execution_seconds") is not None]

    # -- Zero rows check -------------------------------------------------------
    if current_row_count == 0:
        mean_rows, _ = _compute_stats(hist_rows)
        if mean_rows > 0:
            anomalies.append(AnomalyResult(
                anomaly_type="zero_rows",
                severity="critical",
                current_value=0,
                expected_mean=round(mean_rows, 1),
                expected_stddev=0,
                z_score=float('inf'),
                message=f"Report returned 0 rows (historical average: {mean_rows:.0f})",
            ))

    # -- Row count anomaly -----------------------------------------------------
    if hist_rows and len(hist_rows) >= _min_history:
        mean_r, std_r = _compute_stats(hist_rows)
        if std_r > 0:
            z_rows = (current_row_count - mean_r) / std_r
            if z_rows > _z_threshold:
                anomalies.append(AnomalyResult(
                    anomaly_type="row_count_spike",
                    severity="warning",
                    current_value=current_row_count,
                    expected_mean=round(mean_r, 1),
                    expected_stddev=round(std_r, 1),
                    z_score=round(z_rows, 2),
                    message=f"Row count {current_row_count:,} is {z_rows:.1f}x std above mean {mean_r:,.0f}",
                ))
            elif z_rows < -_z_threshold and current_row_count > 0:
                anomalies.append(AnomalyResult(
                    anomaly_type="row_count_drop",
                    severity="warning",
                    current_value=current_row_count,
                    expected_mean=round(mean_r, 1),
                    expected_stddev=round(std_r, 1),
                    z_score=round(z_rows, 2),
                    message=f"Row count {current_row_count:,} is {abs(z_rows):.1f}x std below mean {mean_r:,.0f}",
                ))

    # -- Slow execution check --------------------------------------------------
    if hist_secs and len(hist_secs) >= _min_history and current_exec_seconds > 0:
        mean_s, std_s = _compute_stats(hist_secs)
        if std_s > 0:
            z_secs = (current_exec_seconds - mean_s) / std_s
            if z_secs > _z_threshold:
                anomalies.append(AnomalyResult(
                    anomaly_type="slow_execution",
                    severity="warning",
                    current_value=round(current_exec_seconds, 1),
                    expected_mean=round(mean_s, 1),
                    expected_stddev=round(std_s, 1),
                    z_score=round(z_secs, 2),
                    message=f"Execution took {current_exec_seconds:.1f}s ({z_secs:.1f}x std above mean {mean_s:.1f}s)",
                ))

    return anomalies
