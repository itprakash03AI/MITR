"""
Notification poller — runs inside the FastAPI process as an ``asyncio`` task.

Polls the ``pending_notifications`` table every *interval* seconds and
broadcasts each payload via the WebSocket manager, then marks rows delivered.

Used when ``scheduler.mode = "external"`` (scheduler runs in a separate process
and enqueues notifications via the DB instead of calling ``ws_manager`` directly).
"""

from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)


async def run_notification_poller(
    session_factory,
    ws_manager,
    interval: float = 1.5,
):
    """Infinite loop: poll → broadcast → mark delivered → sleep.

    Parameters
    ----------
    session_factory : sessionmaker
        SQLAlchemy ``SessionLocal`` from :class:`DatabaseManager`.
    ws_manager : WebSocketManager
        The app-wide WebSocket manager instance.
    interval : float
        Seconds between poll cycles (default 1.5 s).
    """
    from core.notification_queue import poll, mark_delivered, cleanup_old

    cleanup_counter = 0

    while True:
        try:
            rows = poll(session_factory, limit=50)
            if rows:
                ids = []
                for nid, payload in rows:
                    try:
                        await ws_manager.broadcast(payload)
                    except Exception as exc:
                        logger.warning("WS broadcast failed for notification %d: %s", nid, exc)
                    ids.append(nid)
                mark_delivered(session_factory, ids)
                logger.debug("Polled and broadcast %d notification(s)", len(ids))

            # Cleanup old delivered rows every ~100 cycles (~2.5 min at 1.5 s interval)
            cleanup_counter += 1
            if cleanup_counter >= 100:
                try:
                    deleted = cleanup_old(session_factory, max_age_hours=1)
                    if deleted:
                        logger.debug("Cleaned up %d old notification(s)", deleted)
                except Exception as exc:
                    logger.warning("Notification cleanup failed: %s", exc)
                cleanup_counter = 0

        except asyncio.CancelledError:
            logger.info("Notification poller cancelled — shutting down")
            return
        except Exception as exc:
            logger.warning("Notification poller error: %s", exc)

        await asyncio.sleep(interval)


async def run_notification_subscriber(
    notif_queue,
    ws_manager,
):
    """Event-driven notification relay using Redis pub/sub.

    Replaces polling when queue.backend = "redis".
    """
    try:
        async for payload in notif_queue.subscribe():
            try:
                await ws_manager.broadcast(payload)
            except Exception as exc:
                logger.warning("WS broadcast failed: %s", exc)
    except asyncio.CancelledError:
        logger.info("Notification subscriber cancelled — shutting down")
        return
    except Exception as exc:
        logger.error("Notification subscriber error: %s", exc)
