"""
WebSocket Manager for real-time notifications
Handles multiple client connections and broadcasting
"""

from fastapi import WebSocket
from typing import List, Dict, Any
import asyncio
import logging
import json
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class WebSocketManager:
    """
    Manages WebSocket connections and broadcasting
    """

    MAX_CONNECTIONS = 500  # Global limit to prevent DoS

    def __init__(self):
        """Initialize WebSocket manager"""
        self.active_connections: List[WebSocket] = []
        self.connection_info: Dict[WebSocket, Dict[str, Any]] = {}

    async def connect(self, websocket: WebSocket):
        """
        Accept and register a new WebSocket connection

        Args:
            websocket: WebSocket connection
        """
        # Reject if at global connection limit
        if len(self.active_connections) >= self.MAX_CONNECTIONS:
            logger.warning("WebSocket connection rejected — max connections (%d) reached", self.MAX_CONNECTIONS)
            await websocket.close(code=1013, reason="Max connections reached")
            return

        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_info[websocket] = {
            "connected_at": datetime.now(timezone.utc),
            "message_count": 0
        }
        
        # Send welcome message
        await self.send_personal_message(
            {
                "type": "connection_established",
                "message": "Connected to Parquet Query Engine",
                "timestamp": datetime.now(timezone.utc).isoformat()
            },
            websocket
        )
        
        logger.info(f"New WebSocket connection. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        """
        Remove a WebSocket connection
        
        Args:
            websocket: WebSocket connection to remove
        """
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        
        if websocket in self.connection_info:
            del self.connection_info[websocket]
        
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        """
        Send a message to a specific client
        
        Args:
            message: Message to send
            websocket: Target WebSocket connection
        """
        try:
            await websocket.send_json(message)
            
            if websocket in self.connection_info:
                self.connection_info[websocket]["message_count"] += 1
                
        except Exception as e:
            logger.error(f"Error sending personal message: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, message: Dict[str, Any]):
        """
        Broadcast a message to all connected clients.

        Snapshots the connection list before iterating so that concurrent
        connects/disconnects (which can happen between await points) do not
        cause RuntimeError from list mutation during iteration.
        """
        # Take a snapshot so mutations during await points don't affect this pass
        connections = list(self.active_connections)
        disconnected = []

        for connection in connections:
            try:
                await connection.send_json(message)

                if connection in self.connection_info:
                    self.connection_info[connection]["message_count"] += 1

            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected.append(connection)

        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)

        if connections:
            logger.debug(f"Broadcast message to {len(connections)} clients")
    
    def get_connection_count(self) -> int:
        """
        Get the number of active connections
        
        Returns:
            Number of active connections
        """
        return len(self.active_connections)
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """
        Get connection statistics

        Returns:
            Connection statistics
        """
        return {
            "active_connections": len(self.active_connections),
            "total_messages_sent": sum(
                info["message_count"] for info in self.connection_info.values()
            ),
            "connections": [
                {
                    "connected_at": info["connected_at"].isoformat(),
                    "message_count": info["message_count"]
                }
                for info in self.connection_info.values()
            ]
        }

    # ── Heartbeat ───────────────────────────────────────────────────────────

    _heartbeat_task: asyncio.Task = None

    async def start_heartbeat(self, interval: int = 30):
        """Start periodic ping to detect dead connections.

        Should be called once during FastAPI startup.  Sends a ``ping``
        message every *interval* seconds.  Clients that fail to receive
        the ping are disconnected so the connection list stays clean.
        """
        if self._heartbeat_task and not self._heartbeat_task.done():
            return  # already running
        self._heartbeat_task = asyncio.ensure_future(self._heartbeat_loop(interval))

    async def stop_heartbeat(self):
        """Cancel the heartbeat background task."""
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

    async def _heartbeat_loop(self, interval: int = 30):
        """Send ping every *interval* seconds, prune dead connections."""
        while True:
            try:
                await asyncio.sleep(interval)
                if not self.active_connections:
                    continue

                ping_msg = {
                    "type": "ping",
                    "ts": datetime.now(timezone.utc).isoformat(),
                }
                dead = []
                for ws in list(self.active_connections):
                    try:
                        await ws.send_json(ping_msg)
                    except Exception:
                        dead.append(ws)

                for ws in dead:
                    self.disconnect(ws)

                if dead:
                    logger.info("Heartbeat: pruned %d dead connection(s)", len(dead))
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.warning("Heartbeat error: %s", exc)
