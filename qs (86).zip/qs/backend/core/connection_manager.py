"""
Connection Manager
Manages data source connections (S3 and local) for the Parquet Query Engine.
Provides per-connection file listing and schema retrieval.
"""

import logging
import re
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

import duckdb
import pyarrow.parquet as pq

from core.s3_storage import S3StorageHandler, S3Config, build_s3_config
from core.database import DatabaseManager

logger = logging.getLogger(__name__)


def _normalize_path(path_str: str) -> Path:
    """
    Normalize a path string to a Path object.

    - **Windows host**: returns Path(path_str) as-is.
    - **Linux / Docker / WSL**: converts Windows-style paths:
        C:\\foo\\bar  →  /mnt/c/foo/bar   (WSL convention)
      UNC paths (\\\\server\\share) → /mnt/shared/server/share
      Native Linux paths (/app/data/...) pass through unchanged.

    In Docker, users should use the container-internal path (e.g. /app/data/parquet)
    in connection configs, matching the volume mount in docker run / docker-compose.
    """
    if sys.platform == "win32":
        return Path(path_str)

    # ── UNC / shared paths: \\server\share\... or //server/share/... ──
    unc_match = re.match(r"^(?:\\\\|//)([\w.\-]+)[/\\]([\w.\-]+)(?:[/\\](.*))?$", path_str)
    if unc_match:
        server = unc_match.group(1)
        share = unc_match.group(2)
        rest = (unc_match.group(3) or "").replace("\\", "/")
        # Try common mount conventions in order
        candidates = [
            Path(f"/mnt/shared/{server}/{share}"),   # explicit shared mount
            Path(f"/mnt/{share}"),                     # direct CIFS mount
        ]
        for base in candidates:
            full = base / rest if rest else base
            if full.exists():
                return full
        # Return first candidate even if not found (clearest error message)
        return (candidates[0] / rest) if rest else candidates[0]

    # ── Windows drive paths: C:\... or C:/... ──
    win_abs = re.match(r"^([a-zA-Z]):[/\\](.*)", path_str)
    if win_abs:
        drive = win_abs.group(1).lower()
        rest = win_abs.group(2).replace("\\", "/")
        return Path(f"/mnt/{drive}/{rest}")

    # ── Already a Linux/native path ──
    return Path(path_str)


class ConnectionManager:
    """
    Manages data source connections and provides file operations
    per connection. Caches S3 handler instances to avoid recreating
    boto3 sessions on every request.
    """

    def __init__(self, db_manager: DatabaseManager):
        """
        Initialize the connection manager.

        Args:
            db_manager: DatabaseManager instance for connection CRUD
        """
        self.db = db_manager
        # Cache: connection_id → (handler, created_at_monotonic)
        self._s3_handlers: Dict[int, Tuple[S3StorageHandler, float]] = {}
        self._s3_lock = threading.Lock()  # guards check-then-set on _s3_handlers

    def test_connection(self, connection_type: str, config: dict) -> dict:
        """
        Test a connection configuration without saving it.

        Args:
            connection_type: 's3', 'local', or 'upload'
            config: Connection configuration dictionary

        Returns:
            Dict with 'success' (bool) and 'message' (str)
        """
        if connection_type == "s3":
            return self._test_s3_connection(config)
        elif connection_type in ("local", "upload"):
            return self._test_local_connection(config)
        else:
            return {
                "success": False,
                "message": f"Unsupported connection type: {connection_type}"
            }

    def _test_s3_connection(self, config: dict) -> dict:
        """Test an S3 connection configuration."""
        try:
            handler = S3StorageHandler(build_s3_config(config))
            result = handler.test_connection()

            if result.get("connected"):
                return {
                    "success": True,
                    "message": f"Successfully connected to S3 bucket '{config['bucket_name']}'"
                }
            else:
                return {
                    "success": False,
                    "message": f"Failed to connect to S3: {result.get('error', 'Unknown error')}"
                }
        except Exception as e:
            logger.error(f"S3 connection test failed: {e}", exc_info=True)
            return {
                "success": False,
                "message": f"S3 connection test failed: {str(e)}"
            }

    def _test_local_connection(self, config: dict) -> dict:
        """Test a local filesystem connection configuration."""
        try:
            base_path = config.get("base_path")
            if not base_path:
                return {
                    "success": False,
                    "message": "Missing 'base_path' in configuration"
                }

            path = _normalize_path(base_path)
            if not path.exists():
                hint = ""
                if sys.platform != "win32" and re.match(r"^[a-zA-Z]:[/\\]", base_path):
                    hint = (
                        ". In Docker, use the container path (e.g. /app/data/parquet) "
                        "matching your volume mount, not the Windows host path"
                    )
                return {
                    "success": False,
                    "message": f"Path does not exist: {base_path} (resolved: {path}){hint}"
                }

            if not path.is_dir():
                return {
                    "success": False,
                    "message": f"Path is not a directory: {base_path}"
                }

            # Count files for a useful success message
            try:
                file_count = sum(1 for f in path.rglob("*.parquet"))
                extra = f" — {file_count} parquet file(s) found" if file_count else " — no parquet files found"
            except Exception:
                extra = ""

            return {
                "success": True,
                "message": f"Successfully connected to local path '{path}'{extra}"
            }
        except Exception as e:
            logger.error(f"Local connection test failed: {e}", exc_info=True)
            return {
                "success": False,
                "message": f"Local connection test failed: {str(e)}"
            }

    def _is_handler_expired(self, connection_id: int) -> bool:
        """Check if a cached handler's credentials have likely expired.

        Only applies to auth modes with temporary credentials (assume_role,
        profile, iam_role).  Static key-based handlers never expire.
        """
        entry = self._s3_handlers.get(connection_id)
        if not entry:
            return True
        handler, created_at = entry
        auth_mode = (handler.config.auth_mode or "keys").lower()
        if auth_mode in ("assume_role", "profile", "iam_role"):
            from core.config import s3 as s3_cfg
            ttl = s3_cfg.handler_cache_ttl_seconds
            if (time.monotonic() - created_at) > ttl:
                return True
        return False

    def _get_s3_handler(self, connection_id: int, config: dict) -> S3StorageHandler:
        """
        Get or create a cached S3StorageHandler for the given connection.

        Uses a lock to prevent check-then-set races when multiple threads
        request the same connection simultaneously.  Handlers for auth modes
        with temporary credentials (assume_role, profile, iam_role) are
        automatically evicted after ``handler_cache_ttl_seconds`` (default 45 min).

        Args:
            connection_id: Database ID of the connection
            config: S3 configuration dictionary

        Returns:
            Cached or newly created S3StorageHandler
        """
        # Fast path: cached and not expired
        if connection_id in self._s3_handlers and not self._is_handler_expired(connection_id):
            return self._s3_handlers[connection_id][0]

        with self._s3_lock:
            # Re-check inside lock
            if connection_id in self._s3_handlers and not self._is_handler_expired(connection_id):
                return self._s3_handlers[connection_id][0]

            # Evict expired entry if present
            if connection_id in self._s3_handlers:
                logger.info("S3 handler expired for connection %d — recreating with fresh credentials", connection_id)
                del self._s3_handlers[connection_id]

            handler = S3StorageHandler(build_s3_config(config))
            self._s3_handlers[connection_id] = (handler, time.monotonic())
        return self._s3_handlers[connection_id][0]

    def list_files(self, connection_id: int, folder: str = "") -> list:
        """
        List parquet files from the specified connection.

        Args:
            connection_id: Database ID of the connection
            folder: Optional subfolder/prefix to filter files

        Returns:
            List of file information dictionaries

        Raises:
            ValueError: If connection is not found
        """
        # Use get_connection_raw so S3 credentials are decrypted — get_connection()
        # returns masked values (e.g. aws_secret_access_key="***") which cause 403s.
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            # Apply root_prefix from connection config to scope browsing
            root_prefix = (conn["config"].get("root_prefix") or "").strip().strip("/")
            if root_prefix:
                effective = f"{root_prefix}/{folder}" if folder else f"{root_prefix}/"
            else:
                effective = folder
            return handler.list_parquet_files(folder_path=effective)
        else:  # local or upload
            return self._list_local_files(conn["config"], folder)

    _PREVIEWABLE_EXTS = {".parquet", ".csv", ".txt"}

    def _list_local_files(self, config: dict, folder: str = "") -> list:
        """
        List previewable files (.parquet, .csv, .txt) in a local directory.

        Args:
            config: Local connection configuration with 'base_path'
            folder: Optional subfolder relative to base_path

        Returns:
            List of file information dictionaries
        """
        base = _normalize_path(config["base_path"]).resolve()
        search_path = base / folder if folder else base
        search_path = search_path.resolve()

        # Prevent path traversal — search_path must stay within base
        if not str(search_path).startswith(str(base)):
            logger.warning("Path traversal blocked: %s escapes %s", search_path, base)
            return []

        if not search_path.exists() or not search_path.is_dir():
            return []

        files = []
        for file_path in sorted(search_path.rglob("*")):
            if file_path.suffix.lower() not in self._PREVIEWABLE_EXTS:
                continue
            try:
                stat = file_path.stat()
                relative_path = file_path.relative_to(base)
                files.append({
                    "name": file_path.name,
                    "path": str(relative_path).replace("\\", "/"),
                    "size_bytes": stat.st_size,
                    "last_modified": stat.st_mtime,
                    "folder": str(relative_path.parent).replace("\\", "/") if relative_path.parent != Path(".") else "",
                })
            except OSError as e:
                logger.warning(f"Could not stat file {file_path}: {e}")
                continue

        logger.info(f"Found {len(files)} previewable files in local path '{search_path}'")
        return files

    def get_schema(self, connection_id: int, file_path: str) -> dict:
        """
        Get schema information for a file within a connection.

        Args:
            connection_id: Database ID of the connection
            file_path: Path to the parquet file (S3 key or local relative path)

        Returns:
            Schema information dictionary

        Raises:
            ValueError: If connection is not found
        """
        # Use get_connection_raw for decrypted credentials (S3 auth requires real creds)
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")

        if conn["connection_type"] == "s3":
            handler = self._get_s3_handler(connection_id, conn["config"])
            # Accept both full S3 URI (s3://bucket/key) and raw S3 key
            s3_key = file_path
            if s3_key.startswith("s3://"):
                s3_key = s3_key[5:].split("/", 1)[1] if "/" in s3_key[5:] else s3_key[5:]
            return handler.get_file_schema(s3_key)
        else:  # local
            return self._get_local_schema(conn["config"], file_path)

    def _get_local_schema(self, config: dict, file_path: str) -> dict:
        """
        Get schema for a local file (.parquet, .csv, .txt) using DuckDB.

        DuckDB uses shared-read access on Windows, avoiding WinError 32
        ("The process cannot access the file because it is being used by
        another process") that PyArrow's exclusive-lock approach causes.
        """
        base = _normalize_path(config["base_path"]).resolve()
        full_path = (base / file_path).resolve()

        # Prevent path traversal — full_path must stay within base
        if not str(full_path).startswith(str(base)):
            raise ValueError(f"Path traversal blocked: {file_path}")

        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        ext = full_path.suffix.lower()
        fp = str(full_path).replace("\\", "/")
        con = duckdb.connect()
        try:
            if ext == ".parquet":
                # DuckDB DESCRIBE gives column name + type
                cols_raw = con.execute(f"DESCRIBE SELECT * FROM read_parquet('{fp}')").fetchall()
                row_count = con.execute(f"SELECT COUNT(*) FROM read_parquet('{fp}')").fetchone()[0]
            elif ext == ".csv":
                cols_raw = con.execute(f"DESCRIBE SELECT * FROM read_csv_auto('{fp}')").fetchall()
                row_count = con.execute(f"SELECT COUNT(*) FROM read_csv_auto('{fp}')").fetchone()[0]
            else:
                # .txt — treat as single-column CSV
                cols_raw = con.execute(f"DESCRIBE SELECT * FROM read_csv_auto('{fp}')").fetchall()
                row_count = con.execute(f"SELECT COUNT(*) FROM read_csv_auto('{fp}')").fetchone()[0]

            columns = [
                {"name": col[0], "type": col[1], "nullable": True}
                for col in cols_raw
            ]
        finally:
            con.close()

        return {
            "file": file_path,
            "columns": columns,
            "num_rows": row_count,
            "num_row_groups": None,
            "size_bytes": full_path.stat().st_size,
        }

    def invalidate_cache(self, connection_id: int):
        """
        Remove cached S3 handler when connection config changes.

        Args:
            connection_id: Database ID of the connection to invalidate
        """
        with self._s3_lock:
            self._s3_handlers.pop(connection_id, None)
        logger.info(f"Invalidated cached handler for connection {connection_id}")

    def get_cache_info(self) -> list:
        """Return info about cached S3 handlers for admin monitoring."""
        now = time.monotonic()
        info = []
        for conn_id, (handler, created_at) in self._s3_handlers.items():
            age = round(now - created_at, 1)
            auth_mode = (handler.config.auth_mode or "keys").lower()
            info.append({
                "connection_id": conn_id,
                "auth_mode": auth_mode,
                "age_seconds": age,
                "bucket": handler.config.bucket_name,
                "expired": self._is_handler_expired(conn_id),
            })
        return info

    # ── Registered Tables ─────────────────────────────────────────────

    def get_registered_tables(self, connection_id: int) -> list:
        """Return the registered_tables list from connection config."""
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        return conn.get("config", {}).get("registered_tables", [])

    def register_table(self, connection_id: int, table: dict) -> dict:
        """Add a registered table to the connection config.

        Args:
            table: {name: str, s3_prefix: str, format: str, description: str}

        Returns:
            The added table dict.
        """
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        config = conn["config"]
        tables = config.get("registered_tables", [])
        if any(t["name"] == table["name"] for t in tables):
            raise ValueError(f"Table '{table['name']}' already registered")
        if table.get("format") not in ("iceberg", "parquet", "csv"):
            raise ValueError(f"Invalid format: {table.get('format')}")
        tables.append(table)
        config["registered_tables"] = tables
        self.db.update_connection(connection_id, config=config)
        logger.info("Registered table '%s' for connection %d", table["name"], connection_id)
        return table

    def unregister_table(self, connection_id: int, table_name: str):
        """Remove a registered table by name."""
        conn = self.db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError("Connection not found")
        config = conn["config"]
        tables = config.get("registered_tables", [])
        config["registered_tables"] = [t for t in tables if t["name"] != table_name]
        self.db.update_connection(connection_id, config=config)
        logger.info("Unregistered table '%s' from connection %d", table_name, connection_id)
