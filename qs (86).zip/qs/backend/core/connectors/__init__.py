"""
SQL Connector factory.

Usage:
    from backend.core.connectors import get_connector

    connector = get_connector(connection_type, config)
    result = connector.execute_query("SELECT 1")
    connector.close()

Supported types:
    "trino"      / "starburst"  – Trino / Starburst on-prem or Galaxy
    "snowflake"                  – Snowflake cloud
    "databricks"                 – Databricks SQL Warehouse
    "oracle"                     – Oracle Database (python-oracledb, thin mode)
"""

from typing import Any, Dict

from .base import SqlConnector

_REGISTRY: Dict[str, str] = {
    "trino":      "trino_connector.TrinoConnector",
    "starburst":  "trino_connector.TrinoConnector",
    "snowflake":  "snowflake_connector.SnowflakeConnector",
    "databricks": "databricks_connector.DatabricksConnector",
    "oracle":     "oracle_connector.OracleConnector",
    "rest_api":   "rest_api_connector.RestApiConnector",
}

# Display-friendly names for the UI
CONNECTOR_DISPLAY_NAMES = {
    "trino":      "Trino",
    "starburst":  "Starburst",
    "snowflake":  "Snowflake",
    "databricks": "Databricks SQL",
    "oracle":     "Oracle Database",
    "rest_api":   "REST API",
}

# Config field definitions for each connector type (used by the frontend form)
CONNECTOR_FIELDS: Dict[str, list] = {
    "trino": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
    ],
    "starburst": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
    ],
    "snowflake": [
        {"key": "account",     "label": "Account",       "type": "text",     "required": True,
         "placeholder": "xy12345.us-east-1"},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["password", "key_pair", "oauth"], "default": "password"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "password"}},
        {"key": "private_key", "label": "Private Key (PEM)", "type": "textarea", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "private_key_passphrase", "label": "Key Passphrase", "type": "password", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "token",       "label": "OAuth Token",   "type": "password", "required": False, "showIf": {"auth_type": "oauth"}},
        {"key": "warehouse",   "label": "Warehouse",     "type": "text",     "required": False},
        {"key": "database",    "label": "Database",      "type": "text",     "required": False},
        {"key": "schema",      "label": "Default Schema", "type": "text",    "required": False},
        {"key": "role",        "label": "Role",          "type": "text",     "required": False},
    ],
    "databricks": [
        {"key": "server_hostname", "label": "Server Hostname", "type": "text",     "required": True,
         "placeholder": "adb-1234567890.12.azuredatabricks.net"},
        {"key": "http_path",       "label": "HTTP Path",       "type": "text",     "required": True,
         "placeholder": "/sql/1.0/warehouses/abc123def456"},
        {"key": "access_token",    "label": "Access Token",    "type": "password", "required": True},
        {"key": "catalog",         "label": "Default Catalog", "type": "text",     "required": False},
        {"key": "schema",          "label": "Default Schema",  "type": "text",     "required": False},
    ],
    "oracle": [
        {"key": "host",            "label": "Host",            "type": "text",     "required": False,
         "placeholder": "oracle.example.com"},
        {"key": "port",            "label": "Port",            "type": "number",   "required": False, "default": 1521},
        {"key": "service_name",    "label": "Service Name",    "type": "text",     "required": False,
         "placeholder": "ORCL or pdb1.example.com"},
        {"key": "sid",             "label": "SID (legacy)",    "type": "text",     "required": False},
        {"key": "dsn",             "label": "DSN (override)",  "type": "text",     "required": False,
         "placeholder": "Leave blank to build from host/port/service"},
        {"key": "user",            "label": "Username",        "type": "text",     "required": True},
        {"key": "password",        "label": "Password",        "type": "password", "required": True},
        {"key": "wallet_location", "label": "Wallet Path",     "type": "text",     "required": False,
         "placeholder": "/path/to/wallet (Autonomous DB / mTLS)"},
        {"key": "wallet_password", "label": "Wallet Password", "type": "password", "required": False},
    ],
    "rest_api": [
        {"key": "base_url",        "label": "Base URL",        "type": "text",     "required": True,
         "placeholder": "https://api.example.com/v2"},
        {"key": "auth_type",       "label": "Auth Type",       "type": "select",   "required": True,
         "options": ["none", "basic", "bearer", "api_key", "oauth2_client_credentials"], "default": "bearer"},
        {"key": "token",           "label": "Bearer Token",    "type": "password", "required": False,
         "showIf": {"auth_type": "bearer"}},
        {"key": "username",        "label": "Username",        "type": "text",     "required": False,
         "showIf": {"auth_type": "basic"}},
        {"key": "password",        "label": "Password",        "type": "password", "required": False,
         "showIf": {"auth_type": "basic"}},
        {"key": "api_key_name",    "label": "API Key Name",    "type": "text",     "required": False,
         "showIf": {"auth_type": "api_key"}, "placeholder": "X-API-Key"},
        {"key": "api_key_value",   "label": "API Key Value",   "type": "password", "required": False,
         "showIf": {"auth_type": "api_key"}},
        {"key": "api_key_location","label": "Key Location",    "type": "select",   "required": False,
         "showIf": {"auth_type": "api_key"}, "options": ["header", "query"], "default": "header"},
        {"key": "client_id",       "label": "Client ID",       "type": "text",     "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"}},
        {"key": "client_secret",   "label": "Client Secret",   "type": "password", "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"}},
        {"key": "token_url",       "label": "Token URL",       "type": "text",     "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"},
         "placeholder": "https://auth.example.com/oauth/token"},
        {"key": "default_headers", "label": "Default Headers (JSON)", "type": "textarea", "required": False,
         "placeholder": '{"Accept": "application/json"}'},
        {"key": "timeout_seconds", "label": "Timeout (sec)",   "type": "number",   "required": False, "default": 30},
        {"key": "verify_ssl",      "label": "Verify SSL",      "type": "boolean",  "required": False, "default": True},
        {"key": "rate_limit_rps",  "label": "Rate Limit (req/sec)", "type": "number", "required": False, "default": 10},
    ],
}


def _wrap_with_circuit_breaker(connector, connection_id: int, connection_name: str):
    """Wrap connector methods with circuit breaker checks."""
    try:
        from core.circuit_breaker import check_circuit, record_success, record_failure, CircuitOpenError
    except ImportError:
        return connector

    original_execute = connector.execute_query
    original_test = getattr(connector, 'test_connection', None)

    def guarded_execute(sql, *args, **kwargs):
        check_circuit(connection_id, connection_name)
        try:
            result = original_execute(sql, *args, **kwargs)
            record_success(connection_id)
            return result
        except Exception as e:
            if not isinstance(e, CircuitOpenError):
                record_failure(connection_id, str(e), connection_name)
            raise

    connector.execute_query = guarded_execute

    if original_test:
        def guarded_test(*args, **kwargs):
            check_circuit(connection_id, connection_name)
            try:
                result = original_test(*args, **kwargs)
                record_success(connection_id)
                return result
            except Exception as e:
                if not isinstance(e, CircuitOpenError):
                    record_failure(connection_id, str(e), connection_name)
                raise
        connector.test_connection = guarded_test

    return connector


def get_connector(connection_type: str, config: Dict[str, Any],
                  connection_id: int | None = None,
                  connection_name: str = "") -> SqlConnector:
    """
    Instantiate and return the correct SqlConnector for `connection_type`.

    Args:
        connection_type: one of "trino", "starburst", "snowflake", "databricks"
        config: the connection-specific configuration dict stored in the DB
        connection_id: optional DB id — when provided, wraps connector with circuit breaker
        connection_name: optional display name for circuit breaker logging

    Returns:
        SqlConnector instance (not yet connected — call test_connection or execute_query)

    Raises:
        ValueError: if connection_type is unsupported
        RuntimeError: if the required driver package is not installed
    """
    entry = _REGISTRY.get(connection_type.lower())
    if not entry:
        supported = ", ".join(sorted(_REGISTRY.keys()))
        raise ValueError(
            f"Unsupported connection type '{connection_type}'. "
            f"Supported: {supported}"
        )

    module_name, class_name = entry.rsplit(".", 1)
    # Lazy import within this package
    import importlib
    module = importlib.import_module(f".{module_name}", package=__name__)
    cls = getattr(module, class_name)
    connector = cls(config)

    # Circuit breaker wrapping
    if connection_id is not None:
        connector = _wrap_with_circuit_breaker(connector, connection_id, connection_name)

    return connector


SQL_CONNECTOR_TYPES = list(_REGISTRY.keys())
