"""
Generic REST API data source connector.

Allows QueryStudio to pull tabular data from any HTTP/REST endpoint
(Salesforce, Jira, internal microservices, etc.) as a data source.

Supports:
    - Auth: none, basic, bearer token, API key (header/query), OAuth2 client credentials
    - Pagination: none, offset, cursor, link_header, page_number
    - JSON response flattening to tabular rows/columns
    - Rate limiting (token bucket)
    - Configurable timeout and SSL verification
"""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import requests

from .base import SqlConnector

logger = logging.getLogger(__name__)

# ── Config defaults ──────────────────────────────────────────────────────────
_DEFAULT_TIMEOUT = 30
_DEFAULT_RATE_LIMIT = 10       # requests per second
_MAX_PAGES = 500               # safety cap on pagination
_MAX_FLATTEN_DEPTH = 5


class RestApiConnector(SqlConnector):
    """
    Generic REST/HTTP API connector.

    Config dict keys:
        base_url          — required, e.g. "https://api.example.com/v2"
        auth_type         — "none" | "basic" | "bearer" | "api_key" | "oauth2_client_credentials"
        username          — for basic auth
        password          — for basic auth
        token             — for bearer auth
        api_key_name      — header/param name for api_key auth
        api_key_value     — the key value
        api_key_location  — "header" (default) or "query"
        client_id         — OAuth2 client credentials
        client_secret     — OAuth2 client credentials
        token_url         — OAuth2 token endpoint
        default_headers   — JSON string or dict of default headers
        timeout_seconds   — request timeout (default 30)
        verify_ssl        — bool (default True)
        rate_limit_rps    — max requests per second (default 10, 0 = unlimited)
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = (config.get("base_url") or "").rstrip("/")
        self.auth_type = (config.get("auth_type") or "none").lower()
        self.timeout = int(config.get("timeout_seconds") or _DEFAULT_TIMEOUT)
        self.verify_ssl = config.get("verify_ssl", True)
        if isinstance(self.verify_ssl, str):
            self.verify_ssl = self.verify_ssl.lower() in ("true", "1", "yes")
        self.rate_limit_rps = float(config.get("rate_limit_rps") or _DEFAULT_RATE_LIMIT)

        # Parse default headers
        raw_headers = config.get("default_headers") or "{}"
        if isinstance(raw_headers, str):
            try:
                self.default_headers = json.loads(raw_headers)
            except (json.JSONDecodeError, TypeError):
                self.default_headers = {}
        else:
            self.default_headers = dict(raw_headers)

        # OAuth2 token cache
        self._oauth2_token: Optional[str] = None
        self._oauth2_expires_at: float = 0

        # Rate limiter state
        self._last_request_time: float = 0

        # Session for connection pooling
        self._session = requests.Session()
        self._session.verify = self.verify_ssl

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        """GET the base_url and check for a 2xx response."""
        try:
            self._rate_limit()
            headers = self._build_headers()
            resp = self._session.get(
                self.base_url,
                headers=headers,
                timeout=self.timeout,
            )
            if resp.status_code < 300:
                return {
                    "success": True,
                    "message": f"Connected: HTTP {resp.status_code}",
                    "details": {
                        "status_code": resp.status_code,
                        "content_type": resp.headers.get("content-type", ""),
                        "response_time_ms": int(resp.elapsed.total_seconds() * 1000),
                    },
                }
            return {
                "success": False,
                "message": f"HTTP {resp.status_code}: {resp.reason}",
                "details": {"status_code": resp.status_code, "body": resp.text[:500]},
            }
        except requests.exceptions.SSLError as e:
            return {"success": False, "message": f"SSL error: {e}", "details": {}}
        except requests.exceptions.ConnectionError as e:
            return {"success": False, "message": f"Connection error: {e}", "details": {}}
        except requests.exceptions.Timeout:
            return {"success": False, "message": f"Timeout after {self.timeout}s", "details": {}}
        except Exception as e:
            return {"success": False, "message": str(e), "details": {}}

    def close(self):
        """Close the requests session."""
        try:
            self._session.close()
        except Exception:
            pass

    # ── Schema browsing (REST has no catalog/schema/table hierarchy) ─────────

    def list_catalogs(self) -> List[str]:
        return ["endpoints"]

    def list_schemas(self, catalog: str) -> List[str]:
        return ["default"]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """
        REST doesn't have tables — this returns saved RestQueryDef names.
        The caller (connections_api.py) handles this via DB lookup.
        """
        return []

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """
        REST doesn't have predefined columns — the caller should execute
        with limit=1 and detect columns from the response.
        """
        return []

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql_or_config: Any, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a REST API query.

        Args:
            sql_or_config: Either a SQL string (ignored for REST) or a dict with:
                http_method       — "GET" or "POST"
                endpoint_path     — "/api/v2/search"
                query_params      — dict of query parameters
                request_body      — dict for POST body
                response_json_path— dot-notation path to array in response
                pagination_type   — "none"|"offset"|"cursor"|"link_header"|"page_number"
                pagination_config — dict with pagination params
                column_mapping    — optional list of {source, name, type}
            limit: max rows to return

        Returns:
            { "columns": [...], "rows": [...], "total_rows": int }
        """
        if isinstance(sql_or_config, str):
            # Plain SQL string — not applicable for REST
            return {"columns": [], "rows": [], "total_rows": 0}

        config = sql_or_config if isinstance(sql_or_config, dict) else {}
        method = (config.get("http_method") or "GET").upper()
        endpoint = config.get("endpoint_path") or "/"
        params = dict(config.get("query_params") or {})
        body = config.get("request_body")
        json_path = config.get("response_json_path") or ""
        pagination_type = (config.get("pagination_type") or "none").lower()
        pagination_cfg = config.get("pagination_config") or {}
        column_mapping = config.get("column_mapping") or []

        url = self._build_url(endpoint)
        all_rows: List[dict] = []
        max_rows = limit or 100000

        try:
            from core.config import rest_api as _ra_cfg
            max_rows = min(max_rows, _ra_cfg.max_rows_per_query)
        except Exception:
            pass

        if pagination_type == "none":
            data = self._single_request(method, url, params, body)
            all_rows = self._extract_rows(data, json_path)
        else:
            all_rows = self._paginated_request(
                method, url, params, body, json_path,
                pagination_type, pagination_cfg, max_rows,
            )

        # Apply limit
        if limit and len(all_rows) > limit:
            all_rows = all_rows[:limit]

        # Flatten nested objects
        flat_rows = [self._flatten_record(row) for row in all_rows]

        # Apply column mapping (rename/type hints)
        if column_mapping:
            flat_rows = self._apply_column_mapping(flat_rows, column_mapping)

        # Detect columns
        columns = self._detect_columns(flat_rows)

        return {
            "columns": columns,
            "rows": flat_rows,
            "total_rows": len(flat_rows),
        }

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _build_url(self, endpoint: str) -> str:
        """Combine base_url with endpoint path."""
        if endpoint.startswith("http://") or endpoint.startswith("https://"):
            return endpoint
        return f"{self.base_url}/{endpoint.lstrip('/')}"

    def _build_headers(self, extra: Optional[dict] = None) -> dict:
        """Build request headers with auth and defaults."""
        headers = {"Accept": "application/json"}
        headers.update(self.default_headers)
        if extra:
            headers.update(extra)

        if self.auth_type == "bearer":
            token = self.config.get("token") or ""
            headers["Authorization"] = f"Bearer {token}"
        elif self.auth_type == "api_key":
            location = (self.config.get("api_key_location") or "header").lower()
            if location == "header":
                key_name = self.config.get("api_key_name") or "X-API-Key"
                headers[key_name] = self.config.get("api_key_value") or ""
        elif self.auth_type == "oauth2_client_credentials":
            token = self._get_oauth2_token()
            headers["Authorization"] = f"Bearer {token}"

        return headers

    def _build_auth(self) -> Optional[tuple]:
        """Return requests auth tuple for basic auth, else None."""
        if self.auth_type == "basic":
            return (self.config.get("username") or "", self.config.get("password") or "")
        return None

    def _build_query_params(self, params: dict) -> dict:
        """Inject API key into query params if api_key_location=query."""
        result = dict(params)
        if self.auth_type == "api_key":
            location = (self.config.get("api_key_location") or "header").lower()
            if location == "query":
                key_name = self.config.get("api_key_name") or "api_key"
                result[key_name] = self.config.get("api_key_value") or ""
        return result

    def _single_request(self, method: str, url: str, params: dict, body: Any) -> Any:
        """Make a single HTTP request and return parsed JSON."""
        self._rate_limit()
        headers = self._build_headers()
        auth = self._build_auth()
        query_params = self._build_query_params(params)

        kwargs: dict = {
            "headers": headers,
            "params": query_params,
            "timeout": self.timeout,
        }
        if auth:
            kwargs["auth"] = auth
        if method == "POST" and body:
            kwargs["json"] = body

        resp = self._session.request(method, url, **kwargs)
        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "")
        if "json" in content_type or resp.text.strip().startswith(("{", "[")):
            return resp.json()
        return {"_raw_text": resp.text}

    def _paginated_request(
        self, method: str, url: str, params: dict, body: Any,
        json_path: str, pagination_type: str, pagination_cfg: dict,
        max_rows: int,
    ) -> List[dict]:
        """Execute paginated requests and accumulate all rows."""
        all_rows: List[dict] = []
        page = 0

        if pagination_type == "offset":
            offset_param = pagination_cfg.get("offset_param", "offset")
            limit_param = pagination_cfg.get("limit_param", "limit")
            limit_value = int(pagination_cfg.get("limit_value", 100))
            offset = 0

            while page < _MAX_PAGES and len(all_rows) < max_rows:
                p = dict(params)
                p[offset_param] = str(offset)
                p[limit_param] = str(limit_value)
                data = self._single_request(method, url, p, body)
                rows = self._extract_rows(data, json_path)
                if not rows:
                    break
                all_rows.extend(rows)
                offset += limit_value
                page += 1

        elif pagination_type == "page_number":
            page_param = pagination_cfg.get("page_param", "page")
            per_page_param = pagination_cfg.get("per_page_param", "per_page")
            per_page_value = int(pagination_cfg.get("per_page_value", 100))
            current_page = int(pagination_cfg.get("start_page", 1))

            while page < _MAX_PAGES and len(all_rows) < max_rows:
                p = dict(params)
                p[page_param] = str(current_page)
                p[per_page_param] = str(per_page_value)
                data = self._single_request(method, url, p, body)
                rows = self._extract_rows(data, json_path)
                if not rows:
                    break
                all_rows.extend(rows)
                current_page += 1
                page += 1

        elif pagination_type == "cursor":
            cursor_field = pagination_cfg.get("cursor_field", "next_cursor")
            cursor_param = pagination_cfg.get("cursor_param", "cursor")
            cursor_value = None

            while page < _MAX_PAGES and len(all_rows) < max_rows:
                p = dict(params)
                if cursor_value:
                    p[cursor_param] = cursor_value
                data = self._single_request(method, url, p, body)
                rows = self._extract_rows(data, json_path)
                if not rows:
                    break
                all_rows.extend(rows)

                # Extract next cursor from response
                if isinstance(data, dict):
                    cursor_value = self._get_nested(data, cursor_field)
                if not cursor_value:
                    break
                page += 1

        elif pagination_type == "link_header":
            next_url: Optional[str] = url
            current_params = dict(params)

            while page < _MAX_PAGES and len(all_rows) < max_rows and next_url:
                self._rate_limit()
                headers = self._build_headers()
                auth = self._build_auth()
                query_params = self._build_query_params(current_params)

                kwargs: dict = {"headers": headers, "params": query_params, "timeout": self.timeout}
                if auth:
                    kwargs["auth"] = auth
                if method == "POST" and body:
                    kwargs["json"] = body

                resp = self._session.request(method, next_url, **kwargs)
                resp.raise_for_status()
                data = resp.json()
                rows = self._extract_rows(data, json_path)
                if not rows:
                    break
                all_rows.extend(rows)

                # Parse Link header for next URL
                link_header = resp.headers.get("Link", "")
                next_url = self._parse_link_next(link_header)
                current_params = {}  # next_url already has params
                page += 1

        return all_rows

    def _extract_rows(self, data: Any, json_path: str) -> List[dict]:
        """Extract array of records from response using json_path."""
        if not data:
            return []

        target = data
        if json_path:
            target = self._get_nested(data, json_path)

        if isinstance(target, list):
            return [row if isinstance(row, dict) else {"value": row} for row in target]
        if isinstance(target, dict):
            return [target]
        return []

    def _get_nested(self, data: Any, path: str) -> Any:
        """Traverse a dot-notation path into nested data."""
        if not path:
            return data
        parts = path.split(".")
        current = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            else:
                return None
            if current is None:
                return None
        return current

    def _flatten_record(self, record: dict, prefix: str = "", depth: int = 0) -> dict:
        """Flatten nested dicts with dot-notation keys. Arrays become JSON strings."""
        flat: dict = {}
        if depth > _MAX_FLATTEN_DEPTH:
            return {prefix.rstrip("."): json.dumps(record, default=str)}

        for key, value in record.items():
            full_key = f"{prefix}{key}" if not prefix else f"{prefix}.{key}"
            if isinstance(value, dict):
                flat.update(self._flatten_record(value, full_key + ".", depth + 1))
            elif isinstance(value, list):
                flat[full_key] = json.dumps(value, default=str)
            else:
                flat[full_key] = value
        return flat

    def _apply_column_mapping(self, rows: List[dict], mapping: List[dict]) -> List[dict]:
        """Rename columns and apply type hints based on column_mapping config."""
        rename_map = {}
        for m in mapping:
            source = m.get("source", "")
            name = m.get("name", source)
            if source and name and source != name:
                rename_map[source] = name

        if not rename_map:
            return rows

        result = []
        for row in rows:
            new_row = {}
            for k, v in row.items():
                new_key = rename_map.get(k, k)
                new_row[new_key] = v
            result.append(new_row)
        return result

    def _detect_columns(self, rows: List[dict]) -> List[Dict[str, str]]:
        """Auto-detect column names and types from row data."""
        if not rows:
            return []

        # Collect all keys across first N rows
        all_keys: dict = {}  # key → python type
        for row in rows[:100]:
            for k, v in row.items():
                if k not in all_keys and v is not None:
                    all_keys[k] = type(v).__name__

        type_map = {
            "str": "VARCHAR",
            "int": "INTEGER",
            "float": "DOUBLE",
            "bool": "BOOLEAN",
            "NoneType": "VARCHAR",
        }

        return [
            {"name": k, "type": type_map.get(v, "VARCHAR")}
            for k, v in all_keys.items()
        ]

    def _get_oauth2_token(self) -> str:
        """Exchange client credentials for an access token (cached)."""
        now = time.time()
        if self._oauth2_token and now < self._oauth2_expires_at:
            return self._oauth2_token

        token_url = self.config.get("token_url") or ""
        client_id = self.config.get("client_id") or ""
        client_secret = self.config.get("client_secret") or ""

        if not token_url:
            raise ValueError("OAuth2 client_credentials requires token_url")

        resp = self._session.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        token_data = resp.json()

        self._oauth2_token = token_data.get("access_token") or ""
        expires_in = int(token_data.get("expires_in", 3600))

        try:
            from core.config import rest_api as _ra_cfg
            cache_seconds = _ra_cfg.oauth2_token_cache_seconds
        except Exception:
            cache_seconds = 3500

        self._oauth2_expires_at = now + min(expires_in - 60, cache_seconds)
        return self._oauth2_token

    def _rate_limit(self):
        """Simple token-bucket rate limiter."""
        if self.rate_limit_rps <= 0:
            return
        min_interval = 1.0 / self.rate_limit_rps
        now = time.time()
        elapsed = now - self._last_request_time
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        self._last_request_time = time.time()

    @staticmethod
    def _parse_link_next(link_header: str) -> Optional[str]:
        """Parse Link header to extract rel="next" URL."""
        if not link_header:
            return None
        for part in link_header.split(","):
            part = part.strip()
            match = re.match(r'<([^>]+)>;\s*rel="next"', part)
            if match:
                return match.group(1)
        return None
