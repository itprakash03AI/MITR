import { createTheme, Theme, alpha } from '@mui/material/styles';

// ── Palette definitions ──────────────────────────────────────────────────────

export type PaletteId = 'cyan' | 'blue' | 'white';

interface PaletteDef {
  name: string;
  main: string;
  dark: string;
  light: string;
  /** selected/hover tint for ListItemButton */
  tintAlpha: string;
  /** dark-mode page background */
  darkDefault: string;
  /** dark-mode paper (card/dialog) background */
  darkPaper: string;
  /** light-mode page background */
  lightDefault: string;
}

export const PALETTES: Record<PaletteId, PaletteDef> = {
  cyan: {
    name: 'Sky',
    main: '#00AFEC', dark: '#0090C4', light: '#40C8F5',
    tintAlpha:    'rgba(0, 175, 236, 0.1)',
    darkDefault:  '#0a1628', darkPaper: '#111f35',
    lightDefault: '#f4f6f8',
  },
  blue: {
    name: 'Blue',
    main: '#1976d2', dark: '#1565c0', light: '#42a5f5',
    tintAlpha:    'rgba(25, 118, 210, 0.1)',
    darkDefault:  '#0a1929', darkPaper: '#0d2137',
    lightDefault: '#f0f4f8',
  },
  white: {
    name: 'Clean',
    main: '#475569', dark: '#334155', light: '#94a3b8',
    tintAlpha:    'rgba(71, 85, 105, 0.1)',
    darkDefault:  '#0f172a', darkPaper: '#1e293b',
    lightDefault: '#f8f9fa',
  },
};

export const DEFAULT_PALETTE: PaletteId = 'cyan';

// ── Theme factory ─────────────────────────────────────────────────────────────

export const createAppTheme = (mode: 'light' | 'dark', paletteId: PaletteId = DEFAULT_PALETTE): Theme => {
  const isLight = mode === 'light';
  const p = PALETTES[paletteId];
  const dividerColor = isLight ? '#dfe3e8' : '#334155';

  return createTheme({
    palette: {
      mode,
      primary:    { main: p.main, dark: p.dark, light: p.light, contrastText: '#ffffff' },
      secondary:  { main: '#64748b', dark: '#475569', light: '#94a3b8' },
      success:    { main: '#10b981', dark: '#059669', light: '#34d399' },
      warning:    { main: '#f59e0b', dark: '#d97706', light: '#fbbf24' },
      error:      { main: '#ef4444', dark: '#dc2626', light: '#f87171' },
      background: isLight
        ? { default: p.lightDefault, paper: '#ffffff' }
        : { default: p.darkDefault,  paper: p.darkPaper },
      text: isLight
        ? { primary: '#1a2027', secondary: '#556a7e' }
        : { primary: '#f1f5f9', secondary: '#94a3b8' },
      divider: dividerColor,
    },
    shape: { borderRadius: 10 },
    typography: {
      fontFamily: [
        '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto',
        '"Helvetica Neue"', 'Arial', 'sans-serif',
      ].join(','),
      h5: { fontWeight: 700 },
      h6: { fontWeight: 600 },
      subtitle2: { fontWeight: 500, color: isLight ? '#556a7e' : '#94a3b8' },
    },
    components: {
      MuiButton: {
        defaultProps: { disableElevation: true as const },
        styleOverrides: {
          root: { textTransform: 'none' as const, fontWeight: 500, borderRadius: 8 },
        },
      },
      MuiListItemButton: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            margin: '2px 8px',
            '&.Mui-selected': {
              backgroundColor: p.tintAlpha,
              borderLeft: `3px solid ${p.main}`,
              paddingLeft: '13px',
              '&:hover': { backgroundColor: alpha(p.main, 0.15) },
            },
            '&:not(.Mui-selected)': {
              borderLeft: '3px solid transparent',
              paddingLeft: '13px',
            },
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            boxShadow: isLight
              ? '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.08)'
              : '0 1px 3px 0 rgb(0 0 0 / 0.3)',
            borderRadius: 12,
            border: isLight ? `1px solid ${dividerColor}` : undefined,
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: { fontWeight: 500 },
        },
      },
      MuiPaper: {
        styleOverrides: {
          rounded: { borderRadius: 12 },
          ...(isLight ? { outlined: { borderColor: dividerColor } } : {}),
        },
      },
      MuiTableCell: {
        styleOverrides: {
          root: {
            borderColor: dividerColor,
          },
          head: {
            fontWeight: 600,
            backgroundColor: isLight ? '#f4f6f8' : undefined,
            color: isLight ? '#1a2027' : undefined,
          },
        },
      },
      MuiTableRow: {
        styleOverrides: {
          root: {
            '&:last-child td': { borderBottom: 0 },
          },
        },
      },
      MuiDrawer: {
        styleOverrides: {
          paper: {
            borderRight: `1px solid ${dividerColor}`,
            backgroundColor: isLight ? '#ffffff' : p.darkPaper,
          },
        },
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            background: isLight
              ? `linear-gradient(135deg, ${p.dark} 0%, ${p.main} 100%)`
              : `linear-gradient(135deg, ${p.darkDefault} 0%, ${p.darkPaper} 100%)`,
            boxShadow: isLight
              ? `0 2px 8px 0 ${alpha(p.main, 0.3)}`
              : '0 2px 8px 0 rgba(0,0,0,0.4)',
          },
        },
      },
      ...(isLight ? {
        MuiDialog: {
          styleOverrides: {
            paper: { border: `1px solid ${dividerColor}` },
          },
        },
      } : {}),
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            fontSize: '0.75rem',
            fontWeight: 500,
          },
        },
      },
    },
  });
};

// Default export for backwards compatibility
const theme = createAppTheme('light');
export default theme;
