import React, { createContext, useContext, useState, useMemo, ReactNode } from 'react';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { createAppTheme, PaletteId, DEFAULT_PALETTE } from '../theme';

type ThemeMode = 'light' | 'dark';

interface ThemeContextValue {
  mode: ThemeMode;
  palette: PaletteId;
  toggleTheme: () => void;
  setPalette: (id: PaletteId) => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  mode: 'light',
  palette: DEFAULT_PALETTE,
  toggleTheme: () => {},
  setPalette: () => {},
});

export const useThemeMode = () => useContext(ThemeContext);

const MODE_KEY    = 'qs_theme_mode';
const PALETTE_KEY = 'qs_theme_palette';

const getInitialMode = (): ThemeMode => {
  const stored = localStorage.getItem(MODE_KEY);
  if (stored === 'light' || stored === 'dark') return stored;
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

const getInitialPalette = (): PaletteId => {
  const stored = localStorage.getItem(PALETTE_KEY) as PaletteId | null;
  if (stored && ['cyan', 'blue', 'white'].includes(stored)) return stored;
  return DEFAULT_PALETTE;
};

export const ThemeContextProvider = ({ children }: { children: ReactNode }) => {
  const [mode,    setMode]    = useState<ThemeMode>(getInitialMode);
  const [palette, setPaletteState] = useState<PaletteId>(getInitialPalette);

  const toggleTheme = () => {
    setMode(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem(MODE_KEY, next);
      return next;
    });
  };

  const setPalette = (id: PaletteId) => {
    localStorage.setItem(PALETTE_KEY, id);
    setPaletteState(id);
  };

  const theme = useMemo(() => createAppTheme(mode, palette), [mode, palette]);

  return (
    <ThemeContext.Provider value={{ mode, palette, toggleTheme, setPalette }}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};
