/**
 * UIVisibilityContext — provides useComponentVisible(key) hook.
 *
 * A component is considered "enabled" unless there is an explicit false entry
 * for the current user's role in component_visibility (from /api/app-settings).
 * Defaults to true for any key not present in the map (safe default = show).
 */
import React, { createContext, useContext } from 'react';
import { useAppSettings } from './AppSettingsContext';

interface UIVisibilityContextValue {
  isVisible: (componentKey: string) => boolean;
}

const UIVisibilityContext = createContext<UIVisibilityContextValue>({
  isVisible: () => true,
});

export const useComponentVisible = (componentKey: string): boolean => {
  const { isVisible } = useContext(UIVisibilityContext);
  return isVisible(componentKey);
};

export const UIVisibilityProvider = ({ children }: { children: React.ReactNode }) => {
  const settings = useAppSettings();

  const isVisible = (componentKey: string): boolean => {
    if (!settings.loaded) return true; // default show until settings load
    const vis = settings.component_visibility;
    if (vis && Object.prototype.hasOwnProperty.call(vis, componentKey)) {
      return vis[componentKey] !== false;
    }
    return true; // not explicitly disabled → show
  };

  return (
    <UIVisibilityContext.Provider value={{ isVisible }}>
      {children}
    </UIVisibilityContext.Provider>
  );
};
