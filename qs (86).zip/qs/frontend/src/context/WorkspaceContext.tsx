import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface WorkspaceContextValue {
  activeWorkspaceId: number | null;
  setActiveWorkspace: (id: number | null) => void;
}

const WorkspaceContext = createContext<WorkspaceContextValue>({
  activeWorkspaceId: null,
  setActiveWorkspace: () => {},
});

export const useWorkspace = () => useContext(WorkspaceContext);

const STORAGE_KEY = 'qs_workspace_id';

export const WorkspaceProvider = ({ children }: { children: ReactNode }) => {
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<number | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? parseInt(saved, 10) : null;
  });

  const setActiveWorkspace = useCallback((id: number | null) => {
    setActiveWorkspaceId(id);
    if (id === null) {
      localStorage.removeItem(STORAGE_KEY);
    } else {
      localStorage.setItem(STORAGE_KEY, String(id));
    }
  }, []);

  return (
    <WorkspaceContext.Provider value={{ activeWorkspaceId, setActiveWorkspace }}>
      {children}
    </WorkspaceContext.Provider>
  );
};
