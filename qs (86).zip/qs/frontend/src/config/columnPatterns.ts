/**
 * columnPatterns.ts — Column classification, FAQ, and glossary for the AI Assistant.
 *
 * All values are loaded at runtime from GET /api/suggest/chatbot-patterns,
 * which reads from backend/config.json under the "chatbot" section.
 *
 * To teach the chatbot — edit backend/config.json:
 *   "chatbot.numeric_patterns"  / "category_patterns" / "date_patterns" / "id_patterns"
 *     → column name substrings for chip suggestions
 *   "chatbot.faq"
 *     → { "keyword phrase": "answer text" } — instant answers for org-specific Q&A
 *   "chatbot.glossary"
 *     → { "business term": "column_name" } — substituted before NL-to-SQL runs
 *
 * Local arrays below are DEFAULT FALLBACKS (active before the API responds or on error).
 */

// ── Default fallback patterns (used before API responds or on error) ──────────

const DEFAULT_NUMERIC: string[] = [
  'amount', 'balance', 'debit', 'credit', 'payment', 'charge',
  'revenue', 'income', 'expense', 'cost', 'price', 'fee', 'tax',
  'profit', 'margin', 'discount', 'interest', 'principal', 'penalty',
  'salary', 'wage', 'bonus', 'commission',
  'total', 'subtotal', 'value', 'rate', 'ratio', 'percentage', 'percent',
  'qty', 'quantity', 'count', 'number', 'num', 'volume', 'weight', 'size',
  'score', 'rank', 'metric', 'measure', 'kpi',
  // Financial (generic, not SAP-specific — SAP columns resolved via schema types)
  'notional', 'pnl', 'exposure', 'premium', 'units', 'shares', 'lots',
  'nav', 'aum', 'yield', 'coupon', 'spread', 'unrealized', 'realized',
  'mtm', 'npv', 'nominal', 'multiplier', 'factor', 'consideration',
  // Common suffixes (anchor patterns)
  '_amt', '_val', '_prc', '_wt', '_npv',
];

const DEFAULT_CATEGORY: string[] = [
  'status', 'state', 'flag', 'indicator', 'active', 'enabled',
  'type', 'category', 'class', 'kind', 'level', 'tier', 'grade', 'segment',
  'dept', 'department', 'division', 'team', 'group', 'unit', 'branch',
  'entity', 'company', 'organisation', 'organization', 'business',
  'country', 'region', 'city', 'zone', 'area', 'location', 'site',
  'currency', 'ccy', 'source', 'channel', 'product',
  'brand', 'vendor', 'supplier', 'customer', 'client',
  // Generic financial (SAP-specific columns resolved via schema types)
  'asset_class', 'instrument', 'counterparty', 'portfolio', 'strategy',
  'benchmark', 'rating', 'account_type', 'cost_center', 'profit_center',
  'ledger', 'document_type', 'exchange', 'market', 'fund_name',
  'classification',
  // Common suffixes (anchor patterns)
  '_ccy', '_curr', '_fx', '_ind', '_desc', '_name', '_marker',
];

const DEFAULT_DATE: string[] = [
  'date', 'dt', 'time', 'ts', 'timestamp',
  'period', 'month', 'year', 'day', 'week', 'quarter',
  'fiscal', 'posted', 'effective', 'settlement', 'maturity', 'created',
  'updated', 'modified', 'processed', 'received', 'booked',
  'trade_date', 'value_date', 'expiry', 'inception', 'redemption',
];

const DEFAULT_ID: string[] = [
  '_id', '_key', '_ref', '_uuid', '_guid', '_code', '_num', '_no',
  '_hash', '_token', '_seq', 'id_', 'key_', 'ref_', 'uuid_',
  'isin', 'cusip', 'sedol', 'ticker',
  '_number', '_account', '_mnemonic',
];

// ── Live stores (populated by fetchChatbotPatterns) ──────────────────────────

let NUMERIC_PATTERNS:   string[] = [...DEFAULT_NUMERIC];
let CATEGORY_PATTERNS:  string[] = [...DEFAULT_CATEGORY];
let DATE_PATTERNS:      string[] = [...DEFAULT_DATE];
let ID_PATTERNS:        string[] = [...DEFAULT_ID];
let FAQ_STORE:          Record<string, string> = {};
let GLOSSARY_STORE:     Record<string, string> = {};

/** Merge API patterns with local defaults (dedup, keep all). */
function mergeUnique(base: string[], extra: string[]): string[] {
  const set = new Set(base.map(s => s.toLowerCase()));
  const result = [...base];
  for (const p of extra) {
    if (!set.has(p.toLowerCase())) {
      result.push(p);
      set.add(p.toLowerCase());
    }
  }
  return result;
}

/** Fetch patterns from backend and merge into live store. Call once on app init. */
export async function fetchChatbotPatterns(): Promise<void> {
  try {
    // Import getAuthHeader lazily to avoid circular dependency issues at module load time
    const { getAuthHeader } = await import('../context/AuthContext');
    const authHeader = getAuthHeader();
    const headers: Record<string, string> = {};
    if (authHeader) headers['Authorization'] = authHeader;
    const res = await fetch('/api/suggest/chatbot-patterns', { headers });
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data.numeric_patterns))  NUMERIC_PATTERNS  = mergeUnique(DEFAULT_NUMERIC,   data.numeric_patterns);
    if (Array.isArray(data.category_patterns)) CATEGORY_PATTERNS = mergeUnique(DEFAULT_CATEGORY, data.category_patterns);
    if (Array.isArray(data.date_patterns))     DATE_PATTERNS     = mergeUnique(DEFAULT_DATE,     data.date_patterns);
    if (Array.isArray(data.id_patterns))       ID_PATTERNS       = mergeUnique(DEFAULT_ID,       data.id_patterns);
    if (data.faq && typeof data.faq === 'object')         FAQ_STORE     = data.faq;
    if (data.glossary && typeof data.glossary === 'object') GLOSSARY_STORE = data.glossary;
  } catch {
    // Network error or auth error — keep defaults, no action needed
  }
}

// ── Exported accessors (always up-to-date after fetchChatbotPatterns resolves) ─

export function getNumericPatterns():  string[] { return NUMERIC_PATTERNS; }
export function getCategoryPatterns(): string[] { return CATEGORY_PATTERNS; }
export function getDatePatterns():     string[] { return DATE_PATTERNS; }
export function getIdPatterns():       string[] { return ID_PATTERNS; }
export function getFaq():              Record<string, string> { return FAQ_STORE; }
export function getGlossary():         Record<string, string> { return GLOSSARY_STORE; }

/**
 * Find a FAQ answer for the user's input.
 * Returns the answer string if any FAQ key is a substring of the input, or null.
 * Longer keys are tried first (most specific match wins).
 */
export function findFaqAnswer(input: string): string | null {
  const q = input.toLowerCase().trim();
  const entries = Object.entries(FAQ_STORE).sort((a, b) => b[0].length - a[0].length);
  for (const [key, answer] of entries) {
    if (q.includes(key.toLowerCase())) return answer;
  }
  return null;
}

// ── Helpers used by GlobalAssistantPanel ──────────────────────────────────────

/**
 * Split a column name into lowercase word tokens.
 * Handles snake_case, kebab-case, dot.case and camelCase.
 * Examples:
 *   "sap_account"       → ["sap", "account"]
 *   "transactionCount"  → ["transaction", "count"]
 *   "BUSINESS_DATE"     → ["business", "date"]
 */
function tokenize(name: string): string[] {
  return name
    .replace(/([a-z])([A-Z])/g, '$1_$2')   // camelCase → snake_case
    .toLowerCase()
    .split(/[\s_\-\.]+/)
    .filter(t => t.length > 0);
}

/**
 * Returns true if col name matches any pattern (word-boundary-aware, case-insensitive).
 *
 * Rules:
 *  - Patterns that start or end with "_" (e.g. "_id", "id_") use plain substring match —
 *    these are anchor-style suffix/prefix patterns.
 *  - All other patterns are tokenized; ALL tokens in the pattern must appear as whole
 *    tokens in the column name.
 *    Examples:
 *      col "sap_account" vs pattern "count"      → tokens ["sap","account"] ∌ "count" → false  ✓
 *      col "transaction_count" vs pattern "count" → tokens ["transaction","count"] ∋ "count" → true ✓
 *      col "sap_account" vs pattern "SAP_ACCOUNT" → tokens ["sap","account"], pattern tokens
 *          ["sap","account"] — both present → true ✓
 */
export function matchesAny(col: string, patterns: string[]): boolean {
  const cl = col.toLowerCase();
  const colTokens = tokenize(col);
  return patterns.some(p => {
    const pl = p.toLowerCase();
    // Anchor patterns (_id, key_, etc.) — keep original substring match
    if (pl.startsWith('_') || pl.endsWith('_')) return cl.includes(pl);
    // Token match: every token in the pattern must appear in the column's token list
    const patternTokens = tokenize(p);
    return patternTokens.every(pt => colTokens.includes(pt));
  });
}

export function isNumericCol(col: string): boolean {
  return matchesAny(col, NUMERIC_PATTERNS) && !isDateCol(col) && !isIdCol(col);
}
export function isCategoryCol(col: string): boolean {
  return matchesAny(col, CATEGORY_PATTERNS) && !isNumericCol(col) && !isDateCol(col);
}
export function isDateCol(col: string): boolean {
  return matchesAny(col, DATE_PATTERNS);
}
export function isIdCol(col: string): boolean {
  return matchesAny(col, ID_PATTERNS);
}
