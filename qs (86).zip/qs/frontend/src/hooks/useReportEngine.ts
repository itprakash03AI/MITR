/**
 * Phase 56 — Client-side Report Engine Hook
 *
 * Takes raw result rows + report definition and produces:
 * - Banded rows (section headers, data rows, subtotal rows, grand totals)
 * - Running calculations (RunningSum, Rank, PercentOfTotal, PreviousValue)
 * - Slicer filtering (client-side cross-filter)
 * - Drill expansion tracking
 */
import { useMemo } from 'react';

// ── Types ────────────────────────────────────────────────────────────────────

export interface SectionDef {
  name: string;
  break_column_id: number;
  break_column_name: string;   // resolved physical/friendly name
  subtotal_measure_ids: number[];
  subtotal_measure_names: string[];  // resolved names
  show_count?: boolean;
}

export interface RunningCalcDef {
  name: string;
  calc_type: 'running_sum' | 'rank' | 'percent_of_total' | 'previous_value';
  measure_col_name: string;    // column to compute on
  partition_col_name?: string; // partition by this column (optional)
  format_pattern?: string;
}

export interface DrillState {
  level: number;
  filters: Array<{ column: string; value: any }>;
  hierarchy_levels?: Array<{ column_name: string; label: string }>;
}

export type BandedRowType = 'header' | 'data' | 'subtotal' | 'grand_total';

export interface BandedRow {
  _rowType: BandedRowType;
  _sectionValue?: string;
  _sectionCount?: number;
  [key: string]: any;
}

export interface ReportEngineInput {
  rows: any[];
  columns: string[];
  sectionDefs: SectionDef[];
  runningCalcs: RunningCalcDef[];
  slicerValues: Record<string, any[]>;  // columnName → selected values
  drillState: DrillState;
}

export interface ReportEngineOutput {
  bandedRows: BandedRow[];
  calculatedColumns: string[];
  grandTotals: Record<string, number>;
  slicerOptions: Record<string, string[]>;
  drillBreadcrumb: string[];
}

// ── Computation helpers ──────────────────────────────────────────────────────

function applySlicerFilters(rows: any[], slicerValues: Record<string, any[]>): any[] {
  let filtered = rows;
  for (const [col, vals] of Object.entries(slicerValues)) {
    if (vals && vals.length > 0) {
      const valSet = new Set(vals.map(String));
      filtered = filtered.filter(r => valSet.has(String(r[col])));
    }
  }
  return filtered;
}

function applyDrillFilters(rows: any[], drillState: DrillState): any[] {
  let filtered = rows;
  for (const df of drillState.filters) {
    filtered = filtered.filter(r => String(r[df.column]) === String(df.value));
  }
  return filtered;
}

function extractSlicerOptions(rows: any[], slicerColumns: string[]): Record<string, string[]> {
  const opts: Record<string, string[]> = {};
  for (const col of slicerColumns) {
    const unique = new Set<string>();
    for (const r of rows) {
      if (r[col] != null) unique.add(String(r[col]));
    }
    opts[col] = Array.from(unique).sort();
  }
  return opts;
}

function computeGrandTotals(rows: any[], measureNames: string[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const m of measureNames) {
    let sum = 0;
    for (const r of rows) {
      const v = Number(r[m]);
      if (!isNaN(v)) sum += v;
    }
    totals[m] = sum;
  }
  return totals;
}

function buildBandedRows(
  rows: any[],
  sectionDefs: SectionDef[],
  grandTotals: Record<string, number>,
): BandedRow[] {
  if (sectionDefs.length === 0) {
    // No sections — just wrap as data rows + grand total
    const banded: BandedRow[] = rows.map(r => ({ ...r, _rowType: 'data' as BandedRowType }));
    if (Object.keys(grandTotals).length > 0) {
      const gt: BandedRow = { _rowType: 'grand_total' };
      for (const [k, v] of Object.entries(grandTotals)) {
        gt[k] = v;
      }
      banded.push(gt);
    }
    return banded;
  }

  // Use first section def for primary break (multi-level breaks: iterate)
  const primary = sectionDefs[0];
  const breakCol = primary.break_column_name;

  // Sort by break column
  const sorted = [...rows].sort((a, b) => {
    const va = a[breakCol] ?? '';
    const vb = b[breakCol] ?? '';
    return String(va).localeCompare(String(vb));
  });

  const banded: BandedRow[] = [];
  let currentVal: any = undefined;
  let sectionRows: any[] = [];

  const flushSection = () => {
    if (sectionRows.length === 0) return;

    // Section header
    banded.push({
      _rowType: 'header',
      _sectionValue: String(currentVal),
      _sectionCount: sectionRows.length,
    });

    // Data rows
    for (const r of sectionRows) {
      banded.push({ ...r, _rowType: 'data' });
    }

    // Subtotal row
    const subtotal: BandedRow = { _rowType: 'subtotal', _sectionValue: String(currentVal) };
    for (const mName of primary.subtotal_measure_names) {
      let sum = 0;
      for (const r of sectionRows) {
        const v = Number(r[mName]);
        if (!isNaN(v)) sum += v;
      }
      subtotal[mName] = sum;
    }
    if (primary.show_count) {
      subtotal['_count'] = sectionRows.length;
    }
    banded.push(subtotal);

    sectionRows = [];
  };

  for (const row of sorted) {
    const val = row[breakCol];
    if (val !== currentVal) {
      flushSection();
      currentVal = val;
    }
    sectionRows.push(row);
  }
  flushSection();

  // Grand total
  if (Object.keys(grandTotals).length > 0) {
    const gt: BandedRow = { _rowType: 'grand_total' };
    for (const [k, v] of Object.entries(grandTotals)) {
      gt[k] = v;
    }
    banded.push(gt);
  }

  return banded;
}

function applyRunningCalculations(
  bandedRows: BandedRow[],
  runningCalcs: RunningCalcDef[],
  grandTotals: Record<string, number>,
): { rows: BandedRow[]; calculatedColumns: string[] } {
  if (runningCalcs.length === 0) return { rows: bandedRows, calculatedColumns: [] };

  const calcCols: string[] = [];
  const result = bandedRows.map(r => ({ ...r }));

  for (const calc of runningCalcs) {
    const colName = calc.name;
    calcCols.push(colName);

    if (calc.calc_type === 'running_sum') {
      let cumSum = 0;
      for (const r of result) {
        if (r._rowType !== 'data') continue;
        const v = Number(r[calc.measure_col_name]);
        if (!isNaN(v)) cumSum += v;
        r[colName] = cumSum;
      }
    } else if (calc.calc_type === 'rank') {
      // Dense rank by measure value (descending)
      const dataRows = result.filter(r => r._rowType === 'data');
      const sorted = [...dataRows].sort((a, b) => {
        const va = Number(a[calc.measure_col_name]) || 0;
        const vb = Number(b[calc.measure_col_name]) || 0;
        return vb - va;
      });
      let rank = 0;
      let prevVal: number | null = null;
      const rankMap = new Map<any, number>();
      for (const r of sorted) {
        const v = Number(r[calc.measure_col_name]) || 0;
        if (v !== prevVal) {
          rank++;
          prevVal = v;
        }
        rankMap.set(r, rank);
      }
      for (const r of result) {
        if (r._rowType === 'data') {
          r[colName] = rankMap.get(r) ?? null;
        }
      }
    } else if (calc.calc_type === 'percent_of_total') {
      const total = grandTotals[calc.measure_col_name] || 0;
      for (const r of result) {
        if (r._rowType !== 'data') continue;
        const v = Number(r[calc.measure_col_name]) || 0;
        r[colName] = total > 0 ? Math.round((v / total) * 10000) / 100 : 0;
      }
    } else if (calc.calc_type === 'previous_value') {
      let prev: number | null = null;
      for (const r of result) {
        if (r._rowType !== 'data') continue;
        r[colName] = prev;
        prev = Number(r[calc.measure_col_name]) || 0;
      }
    }
  }

  return { rows: result, calculatedColumns: calcCols };
}

// ── Main hook ────────────────────────────────────────────────────────────────

export function useReportEngine(input: ReportEngineInput): ReportEngineOutput {
  return useMemo(() => {
    const { rows, sectionDefs, runningCalcs, slicerValues, drillState } = input;

    if (!rows || rows.length === 0) {
      return {
        bandedRows: [],
        calculatedColumns: [],
        grandTotals: {},
        slicerOptions: {},
        drillBreadcrumb: [],
      };
    }

    // 1. Drill filter
    const drilled = applyDrillFilters(rows, drillState);

    // 2. Slicer filter
    const filtered = applySlicerFilters(drilled, slicerValues);

    // 3. Extract slicer options (from drilled but not slicer-filtered — so other slicers show all options)
    const slicerCols = Object.keys(slicerValues);
    const slicerOptions = extractSlicerOptions(drilled, slicerCols);

    // 4. Compute grand totals from all measure columns in sections
    const measureNames = new Set<string>();
    for (const s of sectionDefs) {
      for (const mn of s.subtotal_measure_names) measureNames.add(mn);
    }
    for (const rc of runningCalcs) {
      measureNames.add(rc.measure_col_name);
    }
    const grandTotals = computeGrandTotals(filtered, Array.from(measureNames));

    // 5. Build banded rows
    const banded = buildBandedRows(filtered, sectionDefs, grandTotals);

    // 6. Apply running calculations
    const { rows: finalRows, calculatedColumns } = applyRunningCalculations(
      banded, runningCalcs, grandTotals,
    );

    // 7. Drill breadcrumb
    const drillBreadcrumb = drillState.filters.map(
      f => `${f.column}: ${f.value}`
    );

    return {
      bandedRows: finalRows,
      calculatedColumns,
      grandTotals,
      slicerOptions,
      drillBreadcrumb,
    };
  }, [input.rows, input.sectionDefs, input.runningCalcs, input.slicerValues, input.drillState]);
}

export default useReportEngine;
