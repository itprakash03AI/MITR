/**
 * Phase 56 — Business Report Builder
 *
 * 6-step wizard for creating/editing business reports on top of the semantic layer.
 * Steps: Subject → Columns → Filters → Parameters → Layout → Review & Save
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Stepper, Step, StepLabel, Button, TextField,
  Chip, Checkbox, FormControlLabel, Select, MenuItem, InputLabel, FormControl,
  IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  Alert, CircularProgress, Divider, Tooltip, Switch, Grid,
  Table, TableBody, TableCell, TableHead, TableRow, Autocomplete,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  ArrowForward as ArrowForwardIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  DragIndicator as DragIcon,
} from '@mui/icons-material';
import api from '../services/api';

// ── Constants ────────────────────────────────────────────────────────────────

const WIZARD_STEPS = ['Subject', 'Columns', 'Filters & Conditions', 'Parameters', 'Layout', 'Review & Save'];

const COLUMN_TYPE_COLORS: Record<string, string> = {
  dimension: '#2196f3',
  measure: '#4caf50',
  detail: '#ff9800',
  kpi: '#e91e63',
};

const FILTER_OPERATORS = [
  { value: 'eq', label: '= Equals' },
  { value: 'neq', label: '!= Not Equals' },
  { value: 'gt', label: '> Greater Than' },
  { value: 'gte', label: '>= Greater or Equal' },
  { value: 'lt', label: '< Less Than' },
  { value: 'lte', label: '<= Less or Equal' },
  { value: 'in', label: 'In List' },
  { value: 'not_in', label: 'Not In List' },
  { value: 'between', label: 'Between' },
  { value: 'is_null', label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

const CALC_TYPES = [
  { value: 'running_sum', label: 'Running Sum' },
  { value: 'rank', label: 'Rank' },
  { value: 'percent_of_total', label: '% of Total' },
  { value: 'previous_value', label: 'Previous Value' },
];

const PARAM_TYPES = [
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'multi_select', label: 'Multi-Select' },
  { value: 'text', label: 'Text Input' },
  { value: 'date', label: 'Date Picker' },
  { value: 'date_range', label: 'Date Range' },
  { value: 'numeric', label: 'Numeric Input' },
];

// ── Helper types ─────────────────────────────────────────────────────────────

interface FilterEntry {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
}

interface SectionDef {
  name: string;
  break_column_id: number;
  subtotal_measure_ids: number[];
  show_count: boolean;
}

interface RunningCalcDef {
  name: string;
  calc_type: string;
  measure_col_id: number;
  partition_col_id: number | null;
  format_pattern: string;
}

interface ParamDef {
  id?: number;
  name: string;
  label: string;
  parameter_type: string;
  lov_column_id: number | null;
  depends_on_param_id: number | null;
  cascade_filter_column_id: number | null;
  default_value: string;
  is_required: boolean;
  sort_order: number;
}

// ── Component ────────────────────────────────────────────────────────────────

const BusinessReportBuilder: React.FC = () => {
  const navigate = useNavigate();
  const { id: editId } = useParams<{ id: string }>();
  const isEdit = !!editId;

  // Wizard state
  const [activeStep, setActiveStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Step 0: Subject
  const [datasets, setDatasets] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | null>(null);
  const [dataset, setDataset] = useState<any>(null);

  // Step 1: Columns
  const [allColumns, setAllColumns] = useState<any[]>([]);
  const [allClasses, setAllClasses] = useState<any[]>([]);
  const [selectedColumnIds, setSelectedColumnIds] = useState<number[]>([]);

  // Step 2: Filters & Conditions
  const [filters, setFilters] = useState<FilterEntry[]>([]);
  const [conditions, setConditions] = useState<any[]>([]);
  const [selectedConditionIds, setSelectedConditionIds] = useState<number[]>([]);
  const [orderBy, setOrderBy] = useState<Array<{ column_id: number; direction: string }>>([]);
  const [rowLimit, setRowLimit] = useState(50000);

  // Step 3: Parameters
  const [params, setParams] = useState<ParamDef[]>([]);

  // Step 4: Layout
  const [sections, setSections] = useState<SectionDef[]>([]);
  const [runningCalcs, setRunningCalcs] = useState<RunningCalcDef[]>([]);
  const [slicerColumnIds, setSlicerColumnIds] = useState<number[]>([]);
  const [hierarchies, setHierarchies] = useState<any[]>([]);
  const [drillHierarchyId, setDrillHierarchyId] = useState<number | null>(null);

  // Step 5: Review
  const [reportName, setReportName] = useState('');
  const [reportDescription, setReportDescription] = useState('');

  // ── Load datasets on mount ────────────────────────────────────────────────

  useEffect(() => {
    api.listDatasets().then((data: any) => {
      const published = (Array.isArray(data) ? data : []).filter((d: any) => d.is_published);
      setDatasets(published);
    }).catch(() => {});
  }, []);

  // ── Load existing report for editing ──────────────────────────────────────

  useEffect(() => {
    if (!editId) return;
    setLoading(true);
    api.getBusinessReport(Number(editId)).then((report: any) => {
      setSelectedDatasetId(report.dataset_id);
      setSelectedColumnIds(report.column_ids || []);
      setFilters(report.filter_specs || []);
      setSelectedConditionIds(report.condition_ids || []);
      setOrderBy(report.order_by || []);
      setRowLimit(report.row_limit || 50000);
      setSections(report.section_definitions || []);
      setRunningCalcs(report.running_calculations || []);
      setSlicerColumnIds(report.slicer_column_ids || []);
      setDrillHierarchyId(report.drill_hierarchy_id);
      setReportName(report.name || '');
      setReportDescription(report.description || '');
      if (report.parameters) {
        setParams(report.parameters.map((p: any) => ({
          id: p.id,
          name: p.name,
          label: p.label,
          parameter_type: p.parameter_type,
          lov_column_id: p.lov_column_id,
          depends_on_param_id: p.depends_on_param_id,
          cascade_filter_column_id: p.cascade_filter_column_id,
          default_value: p.default_value || '',
          is_required: p.is_required,
          sort_order: p.sort_order,
        })));
      }
    }).catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [editId]);

  // ── Load dataset detail when selected ─────────────────────────────────────

  useEffect(() => {
    if (!selectedDatasetId) return;
    api.getDataset(selectedDatasetId).then((ds: any) => {
      setDataset(ds);
      setAllColumns(ds.columns || []);
      setAllClasses(ds.classes || []);
      setConditions(ds.conditions || []);
      setHierarchies(ds.hierarchies || []);
    }).catch(() => {});
  }, [selectedDatasetId]);

  // ── Column helpers ────────────────────────────────────────────────────────

  const dimensions = allColumns.filter((c: any) => c.column_type === 'dimension');
  const measures = allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');
  const selectedCols = allColumns.filter((c: any) => selectedColumnIds.includes(c.id));
  const selectedDims = selectedCols.filter((c: any) => c.column_type === 'dimension');
  const selectedMeasures = selectedCols.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');

  const getColName = (colId: number) => {
    const col = allColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  };

  // ── Toggle column selection ───────────────────────────────────────────────

  const toggleColumn = (colId: number) => {
    setSelectedColumnIds(prev =>
      prev.includes(colId) ? prev.filter(id => id !== colId) : [...prev, colId]
    );
  };

  // ── Filter management ─────────────────────────────────────────────────────

  const addFilter = () => {
    if (allColumns.length === 0) return;
    setFilters(prev => [...prev, { column_id: allColumns[0].id, operator: 'eq', value: '' }]);
  };

  const updateFilter = (idx: number, field: string, val: any) => {
    setFilters(prev => prev.map((f, i) => i === idx ? { ...f, [field]: val } : f));
  };

  const removeFilter = (idx: number) => {
    setFilters(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Parameter management ──────────────────────────────────────────────────

  const addParam = () => {
    setParams(prev => [...prev, {
      name: `param_${prev.length + 1}`,
      label: `Parameter ${prev.length + 1}`,
      parameter_type: 'dropdown',
      lov_column_id: null,
      depends_on_param_id: null,
      cascade_filter_column_id: null,
      default_value: '',
      is_required: true,
      sort_order: prev.length,
    }]);
  };

  const updateParam = (idx: number, field: string, val: any) => {
    setParams(prev => prev.map((p, i) => i === idx ? { ...p, [field]: val } : p));
  };

  const removeParam = (idx: number) => {
    setParams(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Section management ────────────────────────────────────────────────────

  const addSection = () => {
    if (selectedDims.length === 0) return;
    setSections(prev => [...prev, {
      name: `Section ${prev.length + 1}`,
      break_column_id: selectedDims[0].id,
      subtotal_measure_ids: [],
      show_count: true,
    }]);
  };

  const updateSection = (idx: number, field: string, val: any) => {
    setSections(prev => prev.map((s, i) => i === idx ? { ...s, [field]: val } : s));
  };

  const removeSection = (idx: number) => {
    setSections(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Running calc management ───────────────────────────────────────────────

  const addRunningCalc = () => {
    if (selectedMeasures.length === 0) return;
    setRunningCalcs(prev => [...prev, {
      name: `Calc ${prev.length + 1}`,
      calc_type: 'running_sum',
      measure_col_id: selectedMeasures[0].id,
      partition_col_id: null,
      format_pattern: '',
    }]);
  };

  const updateCalc = (idx: number, field: string, val: any) => {
    setRunningCalcs(prev => prev.map((c, i) => i === idx ? { ...c, [field]: val } : c));
  };

  const removeCalc = (idx: number) => {
    setRunningCalcs(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Save report ───────────────────────────────────────────────────────────

  const handleSave = async () => {
    if (!reportName.trim()) {
      setError('Report name is required');
      return;
    }
    if (!selectedDatasetId) {
      setError('Please select a dataset');
      return;
    }
    if (selectedColumnIds.length === 0) {
      setError('Please select at least one column');
      return;
    }

    setSaving(true);
    setError('');

    const data = {
      name: reportName.trim(),
      description: reportDescription.trim(),
      dataset_id: selectedDatasetId,
      column_ids: selectedColumnIds,
      filter_specs: filters,
      condition_ids: selectedConditionIds,
      order_by: orderBy,
      row_limit: rowLimit,
      section_definitions: sections,
      running_calculations: runningCalcs,
      slicer_column_ids: slicerColumnIds,
      drill_hierarchy_id: drillHierarchyId,
    };

    try {
      let report: any;
      if (isEdit) {
        report = await api.updateBusinessReport(Number(editId), data);
      } else {
        report = await api.createBusinessReport(data);
      }

      // Save parameters
      if (report && report.id) {
        // For edit mode, delete existing params then re-create
        if (isEdit) {
          const existingParams = await api.listBusinessReportParams(report.id);
          for (const ep of existingParams) {
            await api.deleteBusinessReportParam(ep.id);
          }
        }
        for (const p of params) {
          await api.createBusinessReportParam(report.id, {
            name: p.name,
            label: p.label,
            parameter_type: p.parameter_type,
            lov_column_id: p.lov_column_id,
            depends_on_param_id: p.depends_on_param_id,
            cascade_filter_column_id: p.cascade_filter_column_id,
            default_value: p.default_value,
            is_required: p.is_required,
            sort_order: p.sort_order,
          });
        }
        navigate(`/business-reports/${report.id}`);
      }
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to save report');
    } finally {
      setSaving(false);
    }
  };

  // ── Step validation ───────────────────────────────────────────────────────

  const canProceed = (step: number): boolean => {
    switch (step) {
      case 0: return selectedDatasetId !== null;
      case 1: return selectedColumnIds.length > 0;
      case 5: return reportName.trim().length > 0;
      default: return true;
    }
  };

  // ── Render steps ──────────────────────────────────────────────────────────

  const renderStep0_Subject = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Select Dataset</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Choose a published dataset as the data source for your report.
      </Typography>
      {datasets.length === 0 ? (
        <Alert severity="info">No published datasets available. Ask an admin to publish a dataset first.</Alert>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {datasets.map((ds: any) => (
            <Paper
              key={ds.id}
              elevation={selectedDatasetId === ds.id ? 4 : 1}
              sx={{
                p: 2, cursor: 'pointer',
                border: selectedDatasetId === ds.id ? '2px solid #1976d2' : '2px solid transparent',
                '&:hover': { bgcolor: 'action.hover' },
              }}
              onClick={() => setSelectedDatasetId(ds.id)}
            >
              <Typography variant="subtitle1" fontWeight="bold">{ds.name}</Typography>
              <Typography variant="body2" color="text.secondary">
                {ds.description || 'No description'} — {ds.subject || 'General'}
              </Typography>
            </Paper>
          ))}
        </Box>
      )}
    </Box>
  );

  const renderStep1_Columns = () => {
    // Group columns by class
    const byClass: Record<string, any[]> = { 'Ungrouped': [] };
    for (const cls of allClasses) {
      byClass[cls.label || cls.name] = [];
    }
    for (const col of allColumns) {
      if (col.is_hidden) continue;
      const cls = allClasses.find((c: any) => c.id === col.class_id);
      const key = cls ? (cls.label || cls.name) : 'Ungrouped';
      if (!byClass[key]) byClass[key] = [];
      byClass[key].push(col);
    }

    return (
      <Box>
        <Typography variant="h6" sx={{ mb: 1 }}>Select Columns</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Pick the dimensions and measures to include in your report.
        </Typography>
        <Box sx={{ mb: 2 }}>
          <Chip label={`${selectedColumnIds.length} selected`} size="small" color="primary" />
        </Box>
        {Object.entries(byClass).filter(([, cols]) => cols.length > 0).map(([className, cols]) => (
          <Box key={className} sx={{ mb: 2 }}>
            <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 0.5 }}>{className}</Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {cols.map((col: any) => (
                <Chip
                  key={col.id}
                  label={col.friendly_name || col.physical_name}
                  size="small"
                  variant={selectedColumnIds.includes(col.id) ? 'filled' : 'outlined'}
                  onClick={() => toggleColumn(col.id)}
                  sx={{
                    borderColor: COLUMN_TYPE_COLORS[col.column_type] || '#999',
                    bgcolor: selectedColumnIds.includes(col.id)
                      ? COLUMN_TYPE_COLORS[col.column_type] || '#999' : 'transparent',
                    color: selectedColumnIds.includes(col.id) ? '#fff' : 'inherit',
                    '&:hover': { opacity: 0.85 },
                  }}
                />
              ))}
            </Box>
          </Box>
        ))}
      </Box>
    );
  };

  const renderStep2_Filters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Filters & Conditions</Typography>

      {/* Static filters */}
      <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Default Filters</Typography>
      {filters.map((f, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select value={f.column_id} onChange={e => updateFilter(idx, 'column_id', e.target.value)}>
              {allColumns.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select value={f.operator} onChange={e => updateFilter(idx, 'operator', e.target.value)}>
              {FILTER_OPERATORS.map(op => (
                <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {!['is_null', 'is_not_null'].includes(f.operator) && (
            <TextField size="small" value={f.value || ''} onChange={e => updateFilter(idx, 'value', e.target.value)}
              placeholder="Value" sx={{ minWidth: 120 }} />
          )}
          <IconButton size="small" onClick={() => removeFilter(idx)}><DeleteIcon fontSize="small" /></IconButton>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addFilter}>Add Filter</Button>

      {/* Pre-defined conditions */}
      {conditions.length > 0 && (
        <>
          <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Pre-defined Conditions</Typography>
          {conditions.map((c: any) => (
            <FormControlLabel
              key={c.id}
              control={
                <Checkbox
                  checked={selectedConditionIds.includes(c.id)}
                  onChange={() => {
                    setSelectedConditionIds(prev =>
                      prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
                    );
                  }}
                />
              }
              label={c.label || c.name}
            />
          ))}
        </>
      )}

      {/* Order by */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Sort Order</Typography>
      {orderBy.map((ob, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select value={ob.column_id} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], column_id: Number(e.target.value) };
              setOrderBy(newOb);
            }}>
              {selectedCols.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 100 }}>
            <Select value={ob.direction} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], direction: e.target.value };
              setOrderBy(newOb);
            }}>
              <MenuItem value="asc">Ascending</MenuItem>
              <MenuItem value="desc">Descending</MenuItem>
            </Select>
          </FormControl>
          <IconButton size="small" onClick={() => setOrderBy(prev => prev.filter((_, i) => i !== idx))}>
            <DeleteIcon fontSize="small" />
          </IconButton>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={() => {
        if (selectedCols.length > 0)
          setOrderBy(prev => [...prev, { column_id: selectedCols[0].id, direction: 'asc' }]);
      }}>Add Sort</Button>

      {/* Row limit */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Row Limit</Typography>
      <TextField size="small" type="number" value={rowLimit}
        onChange={e => setRowLimit(Math.max(1, Number(e.target.value)))} sx={{ width: 150 }} />
    </Box>
  );

  const renderStep3_Parameters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Parameters (Cascading Prompts)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Define input controls that users fill in before running the report.
        Dropdown parameters can cascade (e.g., Country selection filters Region list).
      </Typography>

      {params.map((p, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 2, mb: 2 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={p.name}
              onChange={e => updateParam(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Label" value={p.label}
              onChange={e => updateParam(idx, 'label', e.target.value)} sx={{ width: 200 }} />
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>Type</InputLabel>
              <Select value={p.parameter_type} label="Type"
                onChange={e => updateParam(idx, 'parameter_type', e.target.value)}>
                {PARAM_TYPES.map(pt => (
                  <MenuItem key={pt.value} value={pt.value}>{pt.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            {['dropdown', 'multi_select'].includes(p.parameter_type) && (
              <FormControl size="small" sx={{ minWidth: 180 }}>
                <InputLabel>LOV Column</InputLabel>
                <Select value={p.lov_column_id || ''} label="LOV Column"
                  onChange={e => updateParam(idx, 'lov_column_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {allColumns.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {idx > 0 && ['dropdown', 'multi_select'].includes(p.parameter_type) && (
              <FormControl size="small" sx={{ minWidth: 160 }}>
                <InputLabel>Depends On</InputLabel>
                <Select value={p.depends_on_param_id || ''} label="Depends On"
                  onChange={e => updateParam(idx, 'depends_on_param_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {params.slice(0, idx).map((pp, pi) => (
                    <MenuItem key={pi} value={pp.id || pi}>{pp.label}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {p.depends_on_param_id != null && (
              <FormControl size="small" sx={{ minWidth: 160 }}>
                <InputLabel>Cascade Filter Col</InputLabel>
                <Select value={p.cascade_filter_column_id || ''} label="Cascade Filter Col"
                  onChange={e => updateParam(idx, 'cascade_filter_column_id', e.target.value || null)}>
                  <MenuItem value="">None</MenuItem>
                  {allColumns.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            <TextField size="small" label="Default" value={p.default_value}
              onChange={e => updateParam(idx, 'default_value', e.target.value)} sx={{ width: 120 }} />
            <FormControlLabel
              control={<Checkbox checked={p.is_required} onChange={e => updateParam(idx, 'is_required', e.target.checked)} />}
              label="Required"
            />
            <IconButton size="small" onClick={() => removeParam(idx)}><DeleteIcon fontSize="small" /></IconButton>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addParam}>Add Parameter</Button>
    </Box>
  );

  const renderStep4_Layout = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Layout & Calculations</Typography>

      {/* Section Breaks */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Section Breaks (Subtotals)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Group rows by a dimension with section headers and subtotals per group.
      </Typography>
      {sections.map((s, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Section Name" value={s.name}
              onChange={e => updateSection(idx, 'name', e.target.value)} sx={{ width: 160 }} />
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Break Column</InputLabel>
              <Select value={s.break_column_id} label="Break Column"
                onChange={e => updateSection(idx, 'break_column_id', e.target.value)}>
                {selectedDims.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Subtotal Measures</InputLabel>
              <Select multiple value={s.subtotal_measure_ids} label="Subtotal Measures"
                onChange={e => updateSection(idx, 'subtotal_measure_ids', e.target.value)}
                renderValue={(sel: number[]) => sel.map(id => getColName(id)).join(', ')}>
                {selectedMeasures.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControlLabel
              control={<Checkbox checked={s.show_count} onChange={e => updateSection(idx, 'show_count', e.target.checked)} />}
              label="Count"
            />
            <IconButton size="small" onClick={() => removeSection(idx)}><DeleteIcon fontSize="small" /></IconButton>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addSection}
        disabled={selectedDims.length === 0}>Add Section Break</Button>

      <Divider sx={{ my: 3 }} />

      {/* Running Calculations */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Running Calculations</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Post-query computed columns: running sum, rank, % of total, previous value.
      </Typography>
      {runningCalcs.map((c, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={c.name}
              onChange={e => updateCalc(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <FormControl size="small" sx={{ minWidth: 140 }}>
              <InputLabel>Type</InputLabel>
              <Select value={c.calc_type} label="Type"
                onChange={e => updateCalc(idx, 'calc_type', e.target.value)}>
                {CALC_TYPES.map(ct => (
                  <MenuItem key={ct.value} value={ct.value}>{ct.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Measure</InputLabel>
              <Select value={c.measure_col_id} label="Measure"
                onChange={e => updateCalc(idx, 'measure_col_id', e.target.value)}>
                {selectedMeasures.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Partition By</InputLabel>
              <Select value={c.partition_col_id || ''} label="Partition By"
                onChange={e => updateCalc(idx, 'partition_col_id', e.target.value || null)}>
                <MenuItem value="">None (Global)</MenuItem>
                {selectedDims.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <IconButton size="small" onClick={() => removeCalc(idx)}><DeleteIcon fontSize="small" /></IconButton>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addRunningCalc}
        disabled={selectedMeasures.length === 0}>Add Calculation</Button>

      <Divider sx={{ my: 3 }} />

      {/* Slicer Columns */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Slicer Columns (Cross-Filter)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Viewers can filter report results instantly by selecting slicer values.
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
        {selectedDims.map((c: any) => (
          <Chip
            key={c.id}
            label={c.friendly_name || c.physical_name}
            size="small"
            variant={slicerColumnIds.includes(c.id) ? 'filled' : 'outlined'}
            color={slicerColumnIds.includes(c.id) ? 'primary' : 'default'}
            onClick={() => {
              setSlicerColumnIds(prev =>
                prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
              );
            }}
          />
        ))}
      </Box>

      <Divider sx={{ my: 3 }} />

      {/* Drill Hierarchy */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Drill Hierarchy</Typography>
      {hierarchies.length > 0 ? (
        <FormControl size="small" sx={{ minWidth: 250 }}>
          <InputLabel>Drill Hierarchy</InputLabel>
          <Select value={drillHierarchyId || ''} label="Drill Hierarchy"
            onChange={e => setDrillHierarchyId(e.target.value ? Number(e.target.value) : null)}>
            <MenuItem value="">None</MenuItem>
            {hierarchies.map((h: any) => (
              <MenuItem key={h.id} value={h.id}>{h.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
      ) : (
        <Typography variant="body2" color="text.secondary">
          No drill hierarchies defined for this dataset.
        </Typography>
      )}
    </Box>
  );

  const renderStep5_Review = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Review & Save</Typography>

      <TextField
        fullWidth label="Report Name" value={reportName}
        onChange={e => setReportName(e.target.value)}
        sx={{ mb: 2 }} required error={!reportName.trim()}
        helperText={!reportName.trim() ? 'Name is required' : ''}
      />
      <TextField
        fullWidth label="Description" value={reportDescription}
        onChange={e => setReportDescription(e.target.value)}
        multiline rows={2} sx={{ mb: 3 }}
      />

      <Divider sx={{ mb: 2 }} />
      <Typography variant="subtitle2" gutterBottom>Summary</Typography>

      <Table size="small">
        <TableBody>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold', width: 180 }}>Dataset</TableCell>
            <TableCell>{dataset?.name || selectedDatasetId}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Columns</TableCell>
            <TableCell>{selectedColumnIds.length} selected ({selectedDims.length} dims, {selectedMeasures.length} measures)</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Filters</TableCell>
            <TableCell>{filters.length} filters, {selectedConditionIds.length} conditions</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Parameters</TableCell>
            <TableCell>{params.length} input controls</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Section Breaks</TableCell>
            <TableCell>{sections.length} sections</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Running Calculations</TableCell>
            <TableCell>{runningCalcs.length} calculations</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Slicers</TableCell>
            <TableCell>{slicerColumnIds.length} slicer columns</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Drill Hierarchy</TableCell>
            <TableCell>{drillHierarchyId ? hierarchies.find((h: any) => h.id === drillHierarchyId)?.name || 'Selected' : 'None'}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Row Limit</TableCell>
            <TableCell>{rowLimit.toLocaleString()}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </Box>
  );

  // ── Main render ───────────────────────────────────────────────────────────

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  const stepRenderers = [
    renderStep0_Subject,
    renderStep1_Columns,
    renderStep2_Filters,
    renderStep3_Parameters,
    renderStep4_Layout,
    renderStep5_Review,
  ];

  return (
    <Box sx={{ maxWidth: 1000, mx: 'auto', p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <IconButton onClick={() => navigate('/business-reports')} sx={{ mr: 1 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h5">{isEdit ? 'Edit Report' : 'New Business Report'}</Typography>
      </Box>

      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 3 }}>
        {WIZARD_STEPS.map(label => (
          <Step key={label}><StepLabel>{label}</StepLabel></Step>
        ))}
      </Stepper>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <Paper elevation={2} sx={{ p: 3, mb: 3, minHeight: 300 }}>
        {stepRenderers[activeStep]()}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Button
          disabled={activeStep === 0}
          startIcon={<ArrowBackIcon />}
          onClick={() => setActiveStep(prev => prev - 1)}
        >
          Back
        </Button>

        {activeStep < WIZARD_STEPS.length - 1 ? (
          <Button
            variant="contained"
            endIcon={<ArrowForwardIcon />}
            disabled={!canProceed(activeStep)}
            onClick={() => setActiveStep(prev => prev + 1)}
          >
            Next
          </Button>
        ) : (
          <Button
            variant="contained"
            color="primary"
            startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon />}
            disabled={saving || !canProceed(activeStep)}
            onClick={handleSave}
          >
            {saving ? 'Saving...' : (isEdit ? 'Update Report' : 'Create Report')}
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default BusinessReportBuilder;
