/**
 * Phase 56 — Business Report Viewer
 *
 * Executes a saved report and renders results as a banded table with:
 * - Section headers + subtotals (BO breaks)
 * - Running calculations (RunningSum, Rank, %, PreviousValue)
 * - Parameter prompt panel (cascading LOVs)
 * - Slicer bar (cross-filter)
 * - Drill breadcrumb + click-to-drill
 * - Cache hit badge
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  CircularProgress, Alert, TextField, Select, MenuItem, FormControl,
  InputLabel, Collapse, Breadcrumbs, Link, Tooltip, Badge,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  PlayArrow as PlayIcon,
  Edit as EditIcon,
  GetApp as ExportIcon,
  ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon,
  Bolt as BoltIcon,
  NavigateNext as NavNextIcon,
  FilterList as FilterIcon,
  ContentCopy as DuplicateIcon,
  CheckCircle as CertifiedIcon,
  Link as ShareLinkIcon,
  Code as EmbedCodeIcon,
  Email as EmailIcon,
} from '@mui/icons-material';
import api from '../services/api';
import SubscriptionManager from './SubscriptionManager';
import useReportEngine, { SectionDef, RunningCalcDef, DrillState, BandedRow } from '../hooks/useReportEngine';

// ── Constants ────────────────────────────────────────────────────────────────

const RESULTS_PAGE_SIZE = 500;

const ROW_TYPE_STYLES: Record<string, any> = {
  header: { bgcolor: '#e3f2fd', fontWeight: 'bold' },
  subtotal: { bgcolor: '#f5f5f5', fontWeight: 'bold', fontStyle: 'italic' },
  grand_total: { bgcolor: '#e8eaf6', fontWeight: 'bold' },
  data: {},
};

// ── Component ────────────────────────────────────────────────────────────────

const BusinessReportViewer: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const reportId = Number(id);

  // Report state
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Subscription dialog
  const [subOpen, setSubOpen] = useState(false);

  // Execution state
  const [executing, setExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [rawRows, setRawRows] = useState<any[]>([]);
  const [resultColumns, setResultColumns] = useState<string[]>([]);

  // Parameter state
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  const [paramLovs, setParamLovs] = useState<Record<number, string[]>>({});
  const [paramsPanelOpen, setParamsPanelOpen] = useState(true);

  // Slicer state
  const [slicerValues, setSlicerValues] = useState<Record<string, any[]>>({});

  // Drill state
  const [drillState, setDrillState] = useState<DrillState>({ level: 0, filters: [] });

  // Column metadata (for resolving names)
  const [datasetColumns, setDatasetColumns] = useState<any[]>([]);

  // ── Load report ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (!reportId) return;
    setLoading(true);
    api.getBusinessReport(reportId)
      .then((r: any) => {
        setReport(r);
        // Init param values with defaults
        const defaults: Record<string, any> = {};
        for (const p of (r.parameters || [])) {
          defaults[p.name] = p.default_value || '';
        }
        setParamValues(defaults);
        // Init slicer values
        const sv: Record<string, any[]> = {};
        for (const colId of (r.slicer_column_ids || [])) {
          sv[String(colId)] = [];
        }
        setSlicerValues(sv);
        // Load dataset columns for name resolution
        return api.getDataset(r.dataset_id);
      })
      .then((ds: any) => {
        setDatasetColumns(ds?.columns || []);
      })
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [reportId]);

  // ── Load LOVs for dropdown parameters ─────────────────────────────────────

  useEffect(() => {
    if (!report?.parameters) return;
    const loadLovs = async () => {
      for (const p of report.parameters) {
        if (['dropdown', 'multi_select'].includes(p.parameter_type) && p.lov_column_id) {
          try {
            const parentValues: Record<string, any> = {};
            if (p.depends_on_param_id) {
              const parent = report.parameters.find((pp: any) => pp.id === p.depends_on_param_id);
              if (parent) parentValues[parent.name] = paramValues[parent.name];
            }
            const res = await api.getBusinessReportParamValues(reportId, {
              parameter_id: p.id,
              parent_values: parentValues,
            });
            setParamLovs(prev => ({ ...prev, [p.id]: res.values || [] }));
          } catch { /* ignore */ }
        }
      }
    };
    loadLovs();
  }, [report?.parameters, paramValues, reportId]);

  // ── Column name resolver ──────────────────────────────────────────────────

  const getColDisplayName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  }, [datasetColumns]);

  const getColPhysicalName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col?.physical_name || `col_${colId}`;
  }, [datasetColumns]);

  // ── Build engine input ────────────────────────────────────────────────────

  const sectionDefs: SectionDef[] = useMemo(() => {
    if (!report?.section_definitions) return [];
    return report.section_definitions.map((s: any) => ({
      ...s,
      break_column_name: getColPhysicalName(s.break_column_id),
      subtotal_measure_names: (s.subtotal_measure_ids || []).map((id: number) => getColPhysicalName(id)),
    }));
  }, [report?.section_definitions, getColPhysicalName]);

  const runningCalcs: RunningCalcDef[] = useMemo(() => {
    if (!report?.running_calculations) return [];
    return report.running_calculations.map((c: any) => ({
      ...c,
      measure_col_name: getColPhysicalName(c.measure_col_id),
      partition_col_name: c.partition_col_id ? getColPhysicalName(c.partition_col_id) : undefined,
    }));
  }, [report?.running_calculations, getColPhysicalName]);

  // Map slicer column IDs to physical names for the engine
  const slicerByName = useMemo(() => {
    const mapped: Record<string, any[]> = {};
    for (const [colIdStr, vals] of Object.entries(slicerValues)) {
      const physName = getColPhysicalName(Number(colIdStr));
      mapped[physName] = vals;
    }
    return mapped;
  }, [slicerValues, getColPhysicalName]);

  const engineOutput = useReportEngine({
    rows: rawRows,
    columns: resultColumns,
    sectionDefs,
    runningCalcs,
    slicerValues: slicerByName,
    drillState,
  });

  // ── Execute report ────────────────────────────────────────────────────────

  const handleExecute = async () => {
    if (!report) return;
    setExecuting(true);
    setError('');
    try {
      const result = await api.executeBusinessReport(reportId, {
        parameter_values: paramValues,
        extra_filters: [],
      });
      setExecutionResult(result);

      // Fetch result rows
      if (result.execution_id) {
        const data = await api.getFederationExecutionResults(result.execution_id, 0, result.total_rows || 50000);
        setRawRows(data.rows || []);
        setResultColumns(data.columns || result.columns || []);
      }
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Execution failed');
    } finally {
      setExecuting(false);
    }
  };

  // ── Export CSV ────────────────────────────────────────────────────────────

  const handleExport = () => {
    if (engineOutput.bandedRows.length === 0) return;
    const dataRows = engineOutput.bandedRows.filter(r => r._rowType === 'data');
    if (dataRows.length === 0) return;

    const cols = resultColumns.concat(engineOutput.calculatedColumns);
    const lines = [cols.join(',')];
    for (const row of dataRows) {
      lines.push(cols.map(c => {
        const v = row[c];
        if (v == null) return '';
        const s = String(v);
        return s.includes(',') || s.includes('"') ? `"${s.replace(/"/g, '""')}"` : s;
      }).join(','));
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report?.name || 'report'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ── Drill handlers ────────────────────────────────────────────────────────

  const handleDrillDown = (column: string, value: any) => {
    setDrillState(prev => ({
      ...prev,
      level: prev.level + 1,
      filters: [...prev.filters, { column, value }],
    }));
  };

  const handleDrillUp = (toLevel: number) => {
    setDrillState(prev => ({
      ...prev,
      level: toLevel,
      filters: prev.filters.slice(0, toLevel),
    }));
  };

  // ── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  if (!report) {
    return <Alert severity="error" sx={{ mt: 4, mx: 4 }}>Report not found</Alert>;
  }

  const allCols = resultColumns.concat(engineOutput.calculatedColumns);

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <IconButton onClick={() => navigate('/business-reports')}><ArrowBackIcon /></IconButton>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>{report.name}</Typography>
        {report.is_certified && (
          <Chip icon={<CertifiedIcon />} label="Certified" size="small" color="success" variant="outlined" />
        )}
        {report.template_category && (
          <Chip label={report.template_category} size="small" variant="outlined" />
        )}
        <Tooltip title="Subscribe (email delivery)">
          <IconButton onClick={() => setSubOpen(true)}><EmailIcon /></IconButton>
        </Tooltip>
        <Tooltip title="Share link">
          <IconButton onClick={async () => {
            try {
              const share = await api.createBusinessReportShare(reportId);
              const url = `${window.location.origin}/shared-business-report/${share.token}`;
              navigator.clipboard.writeText(url);
              alert('Share link copied to clipboard!');
            } catch (e: any) { alert(e.message); }
          }}><ShareLinkIcon /></IconButton>
        </Tooltip>
        <Tooltip title="Embed code">
          <IconButton onClick={async () => {
            try {
              const tok = await api.createBusinessReportEmbed(reportId);
              const url = `${window.location.origin}/embedded-business-report/${tok.token}`;
              const html = `<iframe src="${url}" width="100%" height="600" frameBorder="0"></iframe>`;
              navigator.clipboard.writeText(html);
              alert('Embed HTML copied to clipboard!');
            } catch (e: any) { alert(e.message); }
          }}><EmbedCodeIcon /></IconButton>
        </Tooltip>
        <Button variant="contained" startIcon={executing ? <CircularProgress size={16} /> : <PlayIcon />}
          onClick={handleExecute} disabled={executing}>
          {executing ? 'Running...' : 'Execute'}
        </Button>
        <Button variant="outlined" startIcon={<ExportIcon />} onClick={handleExport}
          disabled={engineOutput.bandedRows.length === 0}>Export CSV</Button>
        <IconButton onClick={() => navigate(`/business-reports/${reportId}/edit`)}><EditIcon /></IconButton>
        <Tooltip title="Duplicate"><IconButton onClick={async () => {
          try {
            const dup = await api.duplicateBusinessReport(reportId);
            navigate(`/business-reports/${dup.id}/edit`);
          } catch {}
        }}><DuplicateIcon /></IconButton></Tooltip>
      </Box>

      {report.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{report.description}</Typography>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Parameter Prompt Panel */}
      {report.parameters && report.parameters.length > 0 && (
        <Paper elevation={1} sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', px: 2, py: 1, cursor: 'pointer' }}
            onClick={() => setParamsPanelOpen(prev => !prev)}>
            <FilterIcon sx={{ mr: 1, fontSize: 18 }} />
            <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Parameters</Typography>
            {paramsPanelOpen ? <CollapseIcon /> : <ExpandIcon />}
          </Box>
          <Collapse in={paramsPanelOpen}>
            <Box sx={{ px: 2, pb: 2, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              {report.parameters.map((p: any) => {
                if (p.parameter_type === 'dropdown' || p.parameter_type === 'multi_select') {
                  const lovValues = paramLovs[p.id] || [];
                  return (
                    <FormControl key={p.id} size="small" sx={{ minWidth: 180 }}>
                      <InputLabel>{p.label}</InputLabel>
                      <Select
                        value={paramValues[p.name] || (p.parameter_type === 'multi_select' ? [] : '')}
                        label={p.label}
                        multiple={p.parameter_type === 'multi_select'}
                        onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                      >
                        {!p.is_required && <MenuItem value="">All</MenuItem>}
                        {lovValues.map((v: string) => (
                          <MenuItem key={v} value={v}>{v}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  );
                }
                if (p.parameter_type === 'date' || p.parameter_type === 'date_range') {
                  return (
                    <Box key={p.id} sx={{ display: 'flex', gap: 1 }}>
                      <TextField size="small" label={p.label + (p.parameter_type === 'date_range' ? ' From' : '')}
                        type="date" InputLabelProps={{ shrink: true }}
                        value={p.parameter_type === 'date_range' ? (paramValues[p.name]?.from || '') : (paramValues[p.name] || '')}
                        onChange={e => {
                          if (p.parameter_type === 'date_range') {
                            setParamValues(prev => ({
                              ...prev,
                              [p.name]: { ...(prev[p.name] || {}), from: e.target.value },
                            }));
                          } else {
                            setParamValues(prev => ({ ...prev, [p.name]: e.target.value }));
                          }
                        }}
                      />
                      {p.parameter_type === 'date_range' && (
                        <TextField size="small" label={p.label + ' To'}
                          type="date" InputLabelProps={{ shrink: true }}
                          value={paramValues[p.name]?.to || ''}
                          onChange={e => setParamValues(prev => ({
                            ...prev,
                            [p.name]: { ...(prev[p.name] || {}), to: e.target.value },
                          }))}
                        />
                      )}
                    </Box>
                  );
                }
                return (
                  <TextField key={p.id} size="small" label={p.label}
                    type={p.parameter_type === 'numeric' ? 'number' : 'text'}
                    value={paramValues[p.name] || ''}
                    onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                  />
                );
              })}
            </Box>
          </Collapse>
        </Paper>
      )}

      {/* Slicer Bar */}
      {report.slicer_column_ids && report.slicer_column_ids.length > 0 && rawRows.length > 0 && (
        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
          {report.slicer_column_ids.map((colId: number) => {
            const physName = getColPhysicalName(colId);
            const options = engineOutput.slicerOptions[physName] || [];
            const selected = slicerValues[String(colId)] || [];
            return (
              <FormControl key={colId} size="small" sx={{ minWidth: 160 }}>
                <InputLabel>{getColDisplayName(colId)}</InputLabel>
                <Select
                  multiple value={selected} label={getColDisplayName(colId)}
                  onChange={e => setSlicerValues(prev => ({ ...prev, [String(colId)]: e.target.value as string[] }))}
                  renderValue={(sel: string[]) => sel.length === 0 ? 'All' : sel.join(', ')}
                >
                  {options.map((v: string) => (
                    <MenuItem key={v} value={v}>{v}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          })}
        </Box>
      )}

      {/* Drill Breadcrumb */}
      {drillState.level > 0 && (
        <Box sx={{ mb: 2 }}>
          <Breadcrumbs separator={<NavNextIcon fontSize="small" />}>
            <Link component="button" variant="body2" underline="hover"
              onClick={() => handleDrillUp(0)}>All</Link>
            {drillState.filters.map((f, idx) => (
              <Link key={idx} component="button" variant="body2" underline="hover"
                onClick={() => handleDrillUp(idx + 1)}>
                {f.column}: {f.value}
              </Link>
            ))}
          </Breadcrumbs>
        </Box>
      )}

      {/* Execution Result Badges */}
      {executionResult && (
        <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
          <Chip size="small" label={`${executionResult.total_rows?.toLocaleString() || 0} rows`} />
          <Chip size="small" label={`${(executionResult.duration_seconds || 0).toFixed(2)}s`} />
          {executionResult.cache_hit ? (
            <Chip size="small" icon={<BoltIcon />} color="success"
              label={`Cache Hit (${executionResult.cache_grain || 'cached'}) — ${Math.round((executionResult.cache_age_seconds || 0) / 60)}min old`} />
          ) : (
            <Chip size="small" variant="outlined" label="Live Query" />
          )}
        </Box>
      )}

      {/* Results Table */}
      {engineOutput.bandedRows.length > 0 ? (
        <TableContainer component={Paper} sx={{ maxHeight: 'calc(100vh - 380px)' }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {allCols.map(col => (
                  <TableCell key={col} sx={{ fontWeight: 'bold', whiteSpace: 'nowrap' }}>
                    {/* Try to resolve to display name */}
                    {datasetColumns.find((c: any) => c.physical_name === col)?.friendly_name || col}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {engineOutput.bandedRows.map((row, idx) => {
                const style = ROW_TYPE_STYLES[row._rowType] || {};
                if (row._rowType === 'header') {
                  return (
                    <TableRow key={idx} sx={{ ...style }}>
                      <TableCell colSpan={allCols.length} sx={{ fontWeight: 'bold', fontSize: '0.95rem' }}>
                        {row._sectionValue}
                        {row._sectionCount != null && (
                          <Chip size="small" label={`${row._sectionCount} rows`} sx={{ ml: 1 }} />
                        )}
                      </TableCell>
                    </TableRow>
                  );
                }
                return (
                  <TableRow key={idx} sx={{ ...style }} hover={row._rowType === 'data'}>
                    {allCols.map(col => (
                      <TableCell key={col} sx={{
                        whiteSpace: 'nowrap',
                        fontWeight: style.fontWeight,
                        fontStyle: style.fontStyle,
                        cursor: row._rowType === 'data' && report.drill_hierarchy_id ? 'pointer' : 'default',
                      }}
                        onClick={() => {
                          if (row._rowType === 'data' && report.drill_hierarchy_id) {
                            handleDrillDown(col, row[col]);
                          }
                        }}
                      >
                        {row[col] != null ? (
                          typeof row[col] === 'number'
                            ? row[col].toLocaleString(undefined, { maximumFractionDigits: 2 })
                            : String(row[col])
                        ) : ''}
                        {row._rowType === 'subtotal' && col === allCols[0] && row._sectionValue && (
                          <Typography component="span" variant="caption" sx={{ ml: 1 }}>
                            Subtotal: {row._sectionValue}
                          </Typography>
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      ) : !executing && executionResult ? (
        <Alert severity="info" sx={{ mt: 2 }}>No results returned. Try adjusting your parameters or filters.</Alert>
      ) : !executing ? (
        <Paper elevation={1} sx={{ p: 4, textAlign: 'center', mt: 2 }}>
          <Typography variant="h6" color="text.secondary">
            Click Execute to run this report
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            {report.parameters?.length > 0 ? 'Fill in the parameters above, then click Execute.' : 'Results will appear here.'}
          </Typography>
        </Paper>
      ) : null}
      {/* Subscription Manager Dialog */}
      <SubscriptionManager
        open={subOpen}
        onClose={() => setSubOpen(false)}
        reportId={reportId}
        reportType="business_report"
        reportName={report?.name || `Report ${reportId}`}
      />
    </Box>
  );
};

export default BusinessReportViewer;
