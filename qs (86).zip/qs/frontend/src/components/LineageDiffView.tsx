// @ts-nocheck
/**
 * LineageDiffView.tsx — Side-by-side diff of two lineage snapshots (Phase 52).
 *
 * Shows tables/columns added, removed, and unchanged between two executions.
 */
import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Chip, Stack, Alert, CircularProgress,
  Paper, Divider, Select, MenuItem, FormControl, InputLabel,
  Button, Tooltip,
} from '@mui/material';
import {
  Add as AddIcon,
  Remove as RemoveIcon,
  HorizontalRule as SameIcon,
  CompareArrows as DiffIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../services/api';

interface Snapshot {
  id: number;
  execution_id: string;
  query_type: string;
  query_id: number;
  captured_at: string;
  snapshot_data: {
    table_count: number;
    column_count: number;
    tables: any[];
    columns: any[];
  };
}

interface DiffResult {
  snapshot_a: { id: number; captured_at: string };
  snapshot_b: { id: number; captured_at: string };
  tables: { added: string[]; removed: string[]; unchanged: string[] };
  columns: { added: string[]; removed: string[] };
}

interface Props {
  queryType?: string;
  queryId?: number;
}

const fmtDate = (iso: string) =>
  iso ? new Date(iso).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' }) : '—';

export default function LineageDiffView({ queryType, queryId }: Props) {
  const [snapshots, setSnapshots]   = useState<Snapshot[]>([]);
  const [idA, setIdA]               = useState<number | ''>('');
  const [idB, setIdB]               = useState<number | ''>('');
  const [diff, setDiff]             = useState<DiffResult | null>(null);
  const [loading, setLoading]       = useState(false);
  const [loadingSnaps, setLoadingSnaps] = useState(false);
  const [error, setError]           = useState<string | null>(null);

  useEffect(() => {
    setLoadingSnaps(true);
    api.getLineageSnapshots({ query_type: queryType, query_id: queryId, limit: 50 })
      .then(r => {
        const snaps: Snapshot[] = r.snapshots || [];
        setSnapshots(snaps);
        // Auto-select the two most recent
        if (snaps.length >= 2) { setIdB(snaps[0].id); setIdA(snaps[1].id); }
        else if (snaps.length === 1) { setIdA(snaps[0].id); }
      })
      .catch(() => setError('Failed to load snapshots'))
      .finally(() => setLoadingSnaps(false));
  }, [queryType, queryId]);

  const runDiff = async () => {
    if (!idA || !idB || idA === idB) return;
    setLoading(true);
    setError(null);
    try {
      const d = await api.diffLineageSnapshots(Number(idA), Number(idB));
      setDiff(d);
    } catch (e: any) {
      setError(e?.message ?? 'Diff failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (idA && idB && idA !== idB) runDiff();
  }, [idA, idB]);

  if (loadingSnaps) return <CircularProgress size={24} sx={{ m: 2 }} />;
  if (snapshots.length === 0) return (
    <Alert severity="info" sx={{ m: 1 }}>
      No lineage snapshots yet. Execute a query to capture the first snapshot.
    </Alert>
  );

  const DiffSection = ({
    title, added, removed, unchanged, showUnchanged = false,
  }: { title: string; added: string[]; removed: string[]; unchanged?: string[]; showUnchanged?: boolean }) => (
    <Box>
      <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>{title}</Typography>
      {added.length === 0 && removed.length === 0 ? (
        <Typography variant="body2" color="text.secondary" sx={{ pl: 1 }}>
          No changes — {unchanged?.length ?? 0} item(s) unchanged
        </Typography>
      ) : (
        <Stack spacing={0.5}>
          {added.map(s => (
            <Chip key={`add-${s}`} icon={<AddIcon />} label={s} size="small"
              color="success" variant="outlined" sx={{ justifyContent: 'flex-start', maxWidth: '100%' }} />
          ))}
          {removed.map(s => (
            <Chip key={`rem-${s}`} icon={<RemoveIcon />} label={s} size="small"
              color="error" variant="outlined" sx={{ justifyContent: 'flex-start', maxWidth: '100%' }} />
          ))}
          {showUnchanged && unchanged?.map(s => (
            <Chip key={`unc-${s}`} icon={<SameIcon />} label={s} size="small"
              variant="outlined" sx={{ justifyContent: 'flex-start', maxWidth: '100%', opacity: 0.6 }} />
          ))}
        </Stack>
      )}
    </Box>
  );

  return (
    <Box>
      {/* Selector row */}
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Snapshot A (older)</InputLabel>
          <Select value={idA} label="Snapshot A (older)" onChange={e => setIdA(Number(e.target.value))}>
            {snapshots.map(s => (
              <MenuItem key={s.id} value={s.id}>
                #{s.id} — {fmtDate(s.captured_at)} ({s.snapshot_data?.table_count ?? 0}t)
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <DiffIcon color="action" />
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Snapshot B (newer)</InputLabel>
          <Select value={idB} label="Snapshot B (newer)" onChange={e => setIdB(Number(e.target.value))}>
            {snapshots.map(s => (
              <MenuItem key={s.id} value={s.id}>
                #{s.id} — {fmtDate(s.captured_at)} ({s.snapshot_data?.table_count ?? 0}t)
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Tooltip title="Re-run diff">
          <span>
            <Button variant="outlined" size="small" onClick={runDiff}
              disabled={!idA || !idB || idA === idB || loading}
              startIcon={loading ? <CircularProgress size={14} /> : <RefreshIcon />}>
              Diff
            </Button>
          </span>
        </Tooltip>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}

      {diff && (
        <Paper variant="outlined" sx={{ p: 2 }}>
          {/* Header */}
          <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
            <Chip label={`A: ${fmtDate(diff.snapshot_a.captured_at)}`} size="small" color="default" />
            <Chip label={`B: ${fmtDate(diff.snapshot_b.captured_at)}`} size="small" color="primary" />
            <Chip
              label={`${diff.tables.added.length + diff.tables.removed.length} table changes · ${diff.columns.added.length + diff.columns.removed.length} column changes`}
              size="small"
              color={diff.tables.added.length + diff.tables.removed.length > 0 ? 'warning' : 'success'}
            />
          </Stack>
          <Divider sx={{ mb: 2 }} />

          <Stack spacing={2}>
            <DiffSection
              title="Tables"
              added={diff.tables.added}
              removed={diff.tables.removed}
              unchanged={diff.tables.unchanged}
              showUnchanged={false}
            />
            {(diff.columns.added.length > 0 || diff.columns.removed.length > 0) && (
              <DiffSection
                title="Column Flows"
                added={diff.columns.added}
                removed={diff.columns.removed}
              />
            )}
          </Stack>
        </Paper>
      )}
    </Box>
  );
}
