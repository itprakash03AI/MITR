/**
 * LineageGraphView.tsx — Interactive DAG visualization for data lineage (Phase 50).
 * Uses @xyflow/react (React Flow) with dagre auto-layout.
 */
import React, { useMemo, useCallback, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  NodeProps,
  Handle,
  Position,
  useReactFlow,
  ReactFlowProvider,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from 'dagre';
import { Box, Chip, Typography, IconButton, Tooltip } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';

// ---------------------------------------------------------------------------
// Types (mirrors LineagePage graph types)
// ---------------------------------------------------------------------------

interface GraphNode {
  id: string;
  type: string;
  label: string;
}

interface GraphEdge {
  source: string;
  target: string;
}

// ---------------------------------------------------------------------------
// Colour / label maps (kept in sync with LineagePage)
// ---------------------------------------------------------------------------

const NODE_COLOURS: Record<string, string> = {
  connection: '#1976d2',
  table: '#e65100',
  sql_query: '#00897b',
  parquet_query: '#388e3c',
  report: '#f57c00',
  dashboard: '#7b1fa2',
  materialized_view: '#455a64',
  schedule: '#616161',
};

const TYPE_LABELS: Record<string, string> = {
  connection: 'Connection',
  table: 'Table',
  sql_query: 'SQL Query',
  parquet_query: 'Parquet Query',
  report: 'Report',
  dashboard: 'Dashboard',
  materialized_view: 'MV',
  schedule: 'Schedule',
};

const getColour = (t: string) => NODE_COLOURS[t] ?? '#9e9e9e';
const getLabel = (t: string) => TYPE_LABELS[t] ?? t;

// ---------------------------------------------------------------------------
// Custom node component
// ---------------------------------------------------------------------------

const LineageNode: React.FC<NodeProps> = ({ data }) => {
  const colour = getColour(data.nodeType as string);
  const highlighted = data.highlighted as boolean | undefined;
  const dimmed = data.dimmed as boolean | undefined;

  return (
    <Box
      sx={{
        p: 1,
        borderRadius: 1,
        border: '2px solid',
        borderColor: colour,
        bgcolor: 'background.paper',
        minWidth: 130,
        maxWidth: 220,
        opacity: dimmed ? 0.15 : 1,
        transition: 'opacity 0.25s, box-shadow 0.25s',
        boxShadow: highlighted ? `0 0 8px ${colour}` : 'none',
        cursor: 'pointer',
      }}
    >
      <Handle type="target" position={Position.Top} style={{ background: colour, width: 6, height: 6 }} />
      <Chip
        label={getLabel(data.nodeType as string)}
        size="small"
        sx={{ bgcolor: colour, color: '#fff', fontSize: '0.62rem', height: 18, mb: 0.5 }}
      />
      <Typography
        variant="body2"
        sx={{ fontSize: '0.78rem', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
        title={data.label as string}
      >
        {data.label as string}
      </Typography>
      <Handle type="source" position={Position.Bottom} style={{ background: colour, width: 6, height: 6 }} />
    </Box>
  );
};

const nodeTypes = { lineageNode: LineageNode };

// ---------------------------------------------------------------------------
// Dagre layout
// ---------------------------------------------------------------------------

const NODE_WIDTH = 180;
const NODE_HEIGHT = 60;

function layoutGraph(
  graphNodes: GraphNode[],
  graphEdges: GraphEdge[],
): { nodes: Node[]; edges: Edge[] } {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: 'TB', ranksep: 70, nodesep: 40 });

  for (const n of graphNodes) {
    g.setNode(n.id, { width: NODE_WIDTH, height: NODE_HEIGHT });
  }
  for (const e of graphEdges) {
    g.setEdge(e.source, e.target);
  }

  dagre.layout(g);

  const nodes: Node[] = graphNodes.map(n => {
    const pos = g.node(n.id);
    return {
      id: n.id,
      type: 'lineageNode',
      position: { x: (pos?.x ?? 0) - NODE_WIDTH / 2, y: (pos?.y ?? 0) - NODE_HEIGHT / 2 },
      data: { label: n.label, nodeType: n.type, highlighted: false, dimmed: false },
    };
  });

  const edges: Edge[] = graphEdges.map((e, i) => ({
    id: `e-${i}`,
    source: e.source,
    target: e.target,
    animated: false,
    style: { stroke: '#90a4ae', strokeWidth: 1.5 },
    markerEnd: { type: 'arrowclosed' as any, color: '#90a4ae' },
  }));

  return { nodes, edges };
}

// ---------------------------------------------------------------------------
// BFS path highlighter
// ---------------------------------------------------------------------------

function getConnectedIds(nodeId: string, graphEdges: GraphEdge[]): Set<string> {
  const connected = new Set<string>();
  connected.add(nodeId);

  // Upstream BFS
  const upQueue = [nodeId];
  while (upQueue.length > 0) {
    const current = upQueue.shift()!;
    for (const e of graphEdges) {
      if (e.target === current && !connected.has(e.source)) {
        connected.add(e.source);
        upQueue.push(e.source);
      }
    }
  }

  // Downstream BFS
  const downQueue = [nodeId];
  while (downQueue.length > 0) {
    const current = downQueue.shift()!;
    for (const e of graphEdges) {
      if (e.source === current && !connected.has(e.target)) {
        connected.add(e.target);
        downQueue.push(e.target);
      }
    }
  }

  return connected;
}

// ---------------------------------------------------------------------------
// Export helper
// ---------------------------------------------------------------------------

function exportSVG() {
  const svgEl = document.querySelector('.react-flow__viewport')?.closest('svg');
  if (!svgEl) return;
  const clone = svgEl.cloneNode(true) as SVGElement;
  const blob = new Blob([new XMLSerializer().serializeToString(clone)], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'lineage-graph.svg';
  a.click();
  URL.revokeObjectURL(url);
}

// ---------------------------------------------------------------------------
// Inner component (needs ReactFlowProvider wrapper)
// ---------------------------------------------------------------------------

interface InnerGraphProps {
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  onNodeSelect: (node: GraphNode | null) => void;
}

const InnerGraph: React.FC<InnerGraphProps> = ({ graphNodes, graphEdges, onNodeSelect }) => {
  const [highlightedNodeId, setHighlightedNodeId] = useState<string | null>(null);
  const { fitView } = useReactFlow();

  const { nodes: layoutNodes, edges: layoutEdges } = useMemo(
    () => layoutGraph(graphNodes, graphEdges),
    [graphNodes, graphEdges],
  );

  // Apply highlight/dim
  const connectedIds = useMemo(
    () => (highlightedNodeId ? getConnectedIds(highlightedNodeId, graphEdges) : null),
    [highlightedNodeId, graphEdges],
  );

  const displayNodes = useMemo(() => {
    if (!connectedIds) return layoutNodes;
    return layoutNodes.map(n => ({
      ...n,
      data: {
        ...n.data,
        highlighted: connectedIds.has(n.id),
        dimmed: !connectedIds.has(n.id),
      },
    }));
  }, [layoutNodes, connectedIds]);

  const displayEdges = useMemo(() => {
    if (!connectedIds) return layoutEdges;
    return layoutEdges.map(e => {
      const onPath = connectedIds.has(e.source) && connectedIds.has(e.target);
      return {
        ...e,
        animated: onPath,
        style: {
          ...e.style,
          stroke: onPath ? '#1976d2' : '#e0e0e0',
          strokeWidth: onPath ? 2.5 : 1,
          opacity: onPath ? 1 : 0.15,
        },
      };
    });
  }, [layoutEdges, connectedIds]);

  const handleNodeClick = useCallback(
    (_: any, node: Node) => {
      const gn = graphNodes.find(n => n.id === node.id);
      if (highlightedNodeId === node.id) {
        setHighlightedNodeId(null);
        onNodeSelect(null);
      } else {
        setHighlightedNodeId(node.id);
        onNodeSelect(gn || null);
      }
    },
    [highlightedNodeId, graphNodes, onNodeSelect],
  );

  const handlePaneClick = useCallback(() => {
    setHighlightedNodeId(null);
    onNodeSelect(null);
  }, [onNodeSelect]);

  return (
    <Box sx={{ width: '100%', height: '100%', position: 'relative' }}>
      <Box sx={{ position: 'absolute', top: 8, right: 8, zIndex: 10 }}>
        <Tooltip title="Export SVG">
          <IconButton size="small" onClick={exportSVG} sx={{ bgcolor: 'background.paper', boxShadow: 1 }}>
            <DownloadIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
      <ReactFlow
        nodes={displayNodes}
        edges={displayEdges}
        nodeTypes={nodeTypes}
        onNodeClick={handleNodeClick}
        onPaneClick={handlePaneClick}
        fitView
        fitViewOptions={{ padding: 0.15 }}
        minZoom={0.1}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
      >
        <Background />
        <Controls />
        <MiniMap
          nodeColor={(n: Node) => getColour(n.data?.nodeType as string || '')}
          style={{ border: '1px solid #e0e0e0' }}
        />
      </ReactFlow>
    </Box>
  );
};

// ---------------------------------------------------------------------------
// Public component (wraps InnerGraph in provider)
// ---------------------------------------------------------------------------

interface LineageGraphViewProps {
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  onNodeSelect: (node: GraphNode | null) => void;
}

const LineageGraphView: React.FC<LineageGraphViewProps> = (props) => {
  return (
    <ReactFlowProvider>
      <InnerGraph {...props} />
    </ReactFlowProvider>
  );
};

export default LineageGraphView;
