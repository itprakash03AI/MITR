/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-nocheck
/**
 * Materialized Views Management Page
 *
 * CRUD interface for pre-downloaded S3 data (local parquet snapshots).
 * Create, refresh, schedule, and delete materialized views.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControl, IconButton, InputLabel,
  LinearProgress, MenuItem, Paper, Select, TextField, Tooltip,
  Typography, Table, TableBody, TableCell, TableHead, TableRow, TableContainer,
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  Refresh as RefreshIcon, Storage as StorageIcon, Close as CloseIcon,
  CheckCircle as ReadyIcon, Error as FailIcon, HourglassEmpty as PendingIcon,
  Sync as RefreshingIcon, Schedule as ScheduleIcon,
  OpenInNew as OpenInQueryIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';

// ─── Helpers ──────────────────────────────────────────────────────────────

const fmtDate = (iso: string | null) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' }); }
  catch { return iso; }
};

const fmtBytes = (b: number) => {
  if (!b) return '0 B';
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1073741824) return `${(b / 1048576).toFixed(1)} MB`;
  return `${(b / 1073741824).toFixed(2)} GB`;
};

const fmtRows = (n: number) => {
  if (!n) return '0';
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return String(n);
};

const statusChip = (s: string, lastError?: string) => {
  switch (s) {
    case 'ready':
      return <Chip icon={<ReadyIcon sx={{ fontSize: '14px !important' }} />} label="Ready" color="success" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
    case 'refreshing':
      return <Chip icon={<RefreshingIcon sx={{ fontSize: '14px !important', animation: 'spin 1s linear infinite', '@keyframes spin': { from: { transform: 'rotate(0deg)' }, to: { transform: 'rotate(360deg)' } } }} />} label="Refreshing" color="info" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
    case 'failed':
      return (
        <Tooltip title={lastError || 'Unknown error'}>
          <Chip icon={<FailIcon sx={{ fontSize: '14px !important' }} />} label="Failed" color="error" size="small" variant="outlined" sx={{ fontSize: 10 }} />
        </Tooltip>
      );
    default:
      return <Chip icon={<PendingIcon sx={{ fontSize: '14px !important' }} />} label="Pending" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
  }
};

const triggerLabel = (tc: any) => {
  if (!tc) return 'Manual';
  if (tc.type === 'cron') return `Cron: ${tc.cron_expr}`;
  if (tc.type === 'interval') {
    const parts: string[] = [];
    if (tc.hours) parts.push(`${tc.hours}h`);
    if (tc.minutes) parts.push(`${tc.minutes}m`);
    return `Every ${parts.join(' ') || '?'}`;
  }
  return 'Manual';
};

// ─── Component ────────────────────────────────────────────────────────────

const MaterializedViewsPage = () => {
  const { lastMessage } = useWebSocket();
  const navigate = useNavigate();

  const [views, setViews] = useState<any[]>([]);
  const [connections, setConnections] = useState<any[]>([]);
  const [storage, setStorage] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filterConn, setFilterConn] = useState<number | ''>('');
  const [filterStatus, setFilterStatus] = useState<string>('');

  // Dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<any>({
    name: '', description: '', connection_id: '', table_name: '', table_format: 'parquet',
    partition_filter: { date_col: '', from: '', to: '' },
    query_filter: '',
    schedule_type: 'none', cron_expr: '', interval_hours: '', interval_minutes: '',
  });
  const [regTables, setRegTables] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<any>(null);

  // Refresh polling
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Load data ──────────────────────────────────────────────────────────

  const loadAll = useCallback(async () => {
    try {
      const [mvs, conns, stor] = await Promise.all([
        api.listMaterializedViews(),
        api.listConnections(true),
        api.getMaterializedViewsStorage(),
      ]);
      setViews(mvs || []);
      setConnections((conns || []).filter((c: any) => c.connection_type === 's3'));
      setStorage(stor);
      setError('');
    } catch (e: any) {
      setError(e.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  // Poll for refreshing views
  useEffect(() => {
    const refreshing = views.filter(v => v.status === 'refreshing');
    if (refreshing.length > 0 && !pollRef.current) {
      pollRef.current = setInterval(() => loadAll(), 5000);
    } else if (refreshing.length === 0 && pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    return () => { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } };
  }, [views, loadAll]);

  // WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'materialized_view_refreshed' || lastMessage?.type === 'materialized_view_failed') {
      loadAll();
    }
  }, [lastMessage, loadAll]);

  // ─── Dialog helpers ─────────────────────────────────────────────────────

  const openCreate = () => {
    setEditingId(null);
    setForm({
      name: '', description: '', connection_id: '', table_name: '', table_format: 'parquet',
      partition_filter: { date_col: '', from: '', to: '' },
      query_filter: '',
      schedule_type: 'none', cron_expr: '', interval_hours: '', interval_minutes: '',
    });
    setRegTables([]);
    setDialogOpen(true);
  };

  const openEdit = (mv: any) => {
    setEditingId(mv.id);
    const sc = mv.schedule_config;
    setForm({
      name: mv.name,
      description: mv.description || '',
      connection_id: mv.connection_id,
      table_name: mv.table_name,
      table_format: mv.table_format || 'parquet',
      partition_filter: mv.partition_filter || { date_col: '', from: '', to: '' },
      query_filter: mv.query_filter || '',
      schedule_type: sc ? sc.type : 'none',
      cron_expr: sc?.cron_expr || '',
      interval_hours: sc?.hours || '',
      interval_minutes: sc?.minutes || '',
    });
    // Load registered tables for the connection
    const conn = connections.find(c => c.id === mv.connection_id);
    setRegTables(conn?.config?.registered_tables || []);
    setDialogOpen(true);
  };

  const handleConnChange = (connId: number) => {
    setForm((f: any) => ({ ...f, connection_id: connId, table_name: '' }));
    const conn = connections.find(c => c.id === connId);
    setRegTables(conn?.config?.registered_tables || []);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const pf = form.partition_filter;
      const hasPartitionFilter = pf?.date_col && (pf?.from || pf?.to);
      let schedule_config: any = null;
      if (form.schedule_type === 'cron' && form.cron_expr) {
        schedule_config = { type: 'cron', cron_expr: form.cron_expr };
      } else if (form.schedule_type === 'interval' && (form.interval_hours || form.interval_minutes)) {
        schedule_config = { type: 'interval' };
        if (form.interval_hours) schedule_config.hours = Number(form.interval_hours);
        if (form.interval_minutes) schedule_config.minutes = Number(form.interval_minutes);
      }

      const payload: any = {
        name: form.name.trim(),
        description: form.description.trim() || null,
        partition_filter: hasPartitionFilter ? pf : null,
        query_filter: form.query_filter.trim() || null,
        schedule_config,
      };

      if (editingId) {
        await api.updateMaterializedView(editingId, payload);
      } else {
        payload.connection_id = form.connection_id;
        payload.table_name = form.table_name;
        payload.table_format = form.table_format;
        const created = await api.createMaterializedView(payload);
        // Auto-trigger first refresh
        if (created?.id) {
          api.refreshMaterializedView(created.id).catch(() => {});
        }
      }
      setDialogOpen(false);
      loadAll();
    } catch (e: any) {
      setError(e.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleRefresh = async (id: number) => {
    try {
      await api.refreshMaterializedView(id);
      loadAll();
    } catch (e: any) {
      setError(e.message || 'Refresh failed');
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirm) return;
    try {
      await api.deleteMaterializedView(deleteConfirm.id);
      setDeleteConfirm(null);
      loadAll();
    } catch (e: any) {
      setError(e.message || 'Delete failed');
    }
  };

  // ─── Filter views ──────────────────────────────────────────────────────

  const filtered = views.filter(v => {
    if (search && !v.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterConn && v.connection_id !== filterConn) return false;
    if (filterStatus && v.status !== filterStatus) return false;
    return true;
  });

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <StorageIcon color="primary" />
        <Typography variant="h5" fontWeight={700} sx={{ flex: 1 }}>Materialized Views</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} size="small">
          Create View
        </Button>
        <Tooltip title="Refresh list">
          <IconButton size="small" onClick={loadAll}><RefreshIcon /></IconButton>
        </Tooltip>
      </Box>

      {/* Storage summary */}
      {storage && (
        <Box sx={{ display: 'flex', gap: 3, mb: 2, flexWrap: 'wrap' }}>
          <Chip label={`${filtered.length} / ${storage.max_views} views`} size="small" variant="outlined" />
          <Chip label={`${fmtBytes(storage.total_size_bytes)} / ${fmtBytes(storage.max_size_bytes)}`} size="small" variant="outlined"
            color={storage.usage_pct > 80 ? 'warning' : 'default'} />
          {storage.usage_pct > 0 && (
            <Box sx={{ flex: 1, minWidth: 200, maxWidth: 400, display: 'flex', alignItems: 'center', gap: 1 }}>
              <LinearProgress variant="determinate" value={Math.min(storage.usage_pct, 100)}
                sx={{ flex: 1, height: 6, borderRadius: 3 }}
                color={storage.usage_pct > 80 ? 'warning' : 'primary'} />
              <Typography variant="caption" color="text.secondary">{storage.usage_pct}%</Typography>
            </Box>
          )}
        </Box>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Filters */}
      <Box sx={{ display: 'flex', gap: 1.5, mb: 2, flexWrap: 'wrap' }}>
        <TextField size="small" placeholder="Search views..." value={search}
          onChange={e => setSearch(e.target.value)} sx={{ minWidth: 200 }} />
        <FormControl size="small" sx={{ minWidth: 160 }}>
          <InputLabel>Connection</InputLabel>
          <Select value={filterConn} label="Connection" onChange={e => setFilterConn(e.target.value ? Number(e.target.value) : '')}>
            <MenuItem value="">All</MenuItem>
            {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel>Status</InputLabel>
          <Select value={filterStatus} label="Status" onChange={e => setFilterStatus(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="ready">Ready</MenuItem>
            <MenuItem value="refreshing">Refreshing</MenuItem>
            <MenuItem value="pending">Pending</MenuItem>
            <MenuItem value="failed">Failed</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Table */}
      {loading ? <LinearProgress /> : (
        <Paper variant="outlined">
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ '& th': { fontWeight: 700, fontSize: 11, color: 'text.secondary' } }}>
                  <TableCell>Name</TableCell>
                  <TableCell>Source</TableCell>
                  <TableCell align="right">Rows</TableCell>
                  <TableCell align="right">Size</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Last Refresh</TableCell>
                  <TableCell>Schedule</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                      <Typography color="text.secondary">
                        {views.length === 0 ? 'No materialized views yet. Create one to get started.' : 'No views match filters.'}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : filtered.map(mv => {
                  const conn = connections.find(c => c.id === mv.connection_id);
                  return (
                    <TableRow key={mv.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>{mv.name}</Typography>
                        {mv.description && (
                          <Typography variant="caption" color="text.secondary" noWrap sx={{ maxWidth: 200, display: 'block' }}>
                            {mv.description}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption">{conn?.name || `Conn #${mv.connection_id}`}</Typography>
                        <Typography variant="caption" display="block" color="text.secondary">{mv.table_name}</Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">{fmtRows(mv.row_count)}</Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">{fmtBytes(mv.size_bytes)}</Typography>
                      </TableCell>
                      <TableCell>{statusChip(mv.status, mv.last_error)}</TableCell>
                      <TableCell>
                        <Typography variant="caption">{fmtDate(mv.last_refresh_at)}</Typography>
                        {mv.last_refresh_duration != null && (
                          <Typography variant="caption" display="block" color="text.secondary">
                            {mv.last_refresh_duration}s
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption">{triggerLabel(mv.schedule_config)}</Typography>
                        {mv.next_refresh_at && (
                          <Typography variant="caption" display="block" color="text.secondary">
                            Next: {fmtDate(mv.next_refresh_at)}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell align="center">
                        <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                          {mv.status === 'ready' && (
                            <Tooltip title="Open in Query Builder">
                              <IconButton size="small" color="primary"
                                onClick={() => navigate('/', { state: { openMaterializedView: mv.name } })}>
                                <OpenInQueryIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </Tooltip>
                          )}
                          <Tooltip title="Refresh now">
                            <span>
                              <IconButton size="small" onClick={() => handleRefresh(mv.id)}
                                disabled={mv.status === 'refreshing'}>
                                <RefreshIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </span>
                          </Tooltip>
                          <Tooltip title="Edit">
                            <IconButton size="small" onClick={() => openEdit(mv)}>
                              <EditIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton size="small" color="error" onClick={() => setDeleteConfirm(mv)}>
                              <DeleteIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* Create / Edit Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <StorageIcon color="primary" fontSize="small" />
          {editingId ? 'Edit Materialized View' : 'Create Materialized View'}
          <Box sx={{ flex: 1 }} />
          <IconButton size="small" onClick={() => setDialogOpen(false)}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
          <TextField label="Name" size="small" required fullWidth
            value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <TextField label="Description" size="small" fullWidth multiline rows={2}
            value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />

          {!editingId && (
            <>
              <FormControl size="small" fullWidth required>
                <InputLabel>S3 Connection</InputLabel>
                <Select value={form.connection_id} label="S3 Connection"
                  onChange={e => handleConnChange(Number(e.target.value))}>
                  {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl size="small" fullWidth required disabled={!form.connection_id}>
                <InputLabel>Registered Table</InputLabel>
                <Select value={form.table_name} label="Registered Table"
                  onChange={e => {
                    const rt = regTables.find(t => t.name === e.target.value);
                    setForm({ ...form, table_name: e.target.value, table_format: rt?.format || 'parquet' });
                  }}>
                  {regTables.map(rt => (
                    <MenuItem key={rt.name} value={rt.name}>
                      {rt.name}
                      <Chip label={rt.format} size="small" sx={{ ml: 1, fontSize: 9, height: 18 }}
                        color={rt.format === 'iceberg' ? 'success' : rt.format === 'parquet' ? 'info' : 'default'} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </>
          )}

          {/* Partition Filter */}
          <Typography variant="subtitle2" sx={{ mt: 1, mb: -1 }}>Partition Filter (optional)</Typography>
          <Box sx={{ display: 'flex', gap: 1.5 }}>
            <TextField label="Date Column" size="small" sx={{ flex: 1 }}
              value={form.partition_filter?.date_col || ''}
              onChange={e => setForm({ ...form, partition_filter: { ...form.partition_filter, date_col: e.target.value } })}
              placeholder="e.g. dt, date, created_at" />
            <TextField label="From" size="small" type="date" sx={{ flex: 1 }}
              value={form.partition_filter?.from || ''} InputLabelProps={{ shrink: true }}
              onChange={e => setForm({ ...form, partition_filter: { ...form.partition_filter, from: e.target.value } })} />
            <TextField label="To" size="small" type="date" sx={{ flex: 1 }}
              value={form.partition_filter?.to || ''} InputLabelProps={{ shrink: true }}
              onChange={e => setForm({ ...form, partition_filter: { ...form.partition_filter, to: e.target.value } })} />
          </Box>

          {/* Query Filter */}
          <TextField label="WHERE clause (optional)" size="small" fullWidth
            value={form.query_filter}
            onChange={e => setForm({ ...form, query_filter: e.target.value })}
            placeholder='e.g. status = &#39;active&#39; AND amount > 100'
            helperText="Additional SQL filter applied during refresh" />

          {/* Schedule */}
          <Typography variant="subtitle2" sx={{ mt: 1, mb: -1 }}>Auto-Refresh Schedule</Typography>
          <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
            <FormControl size="small" sx={{ minWidth: 140 }}>
              <InputLabel>Type</InputLabel>
              <Select value={form.schedule_type} label="Type"
                onChange={e => setForm({ ...form, schedule_type: e.target.value })}>
                <MenuItem value="none">Manual only</MenuItem>
                <MenuItem value="cron">Cron</MenuItem>
                <MenuItem value="interval">Interval</MenuItem>
              </Select>
            </FormControl>
            {form.schedule_type === 'cron' && (
              <TextField label="Cron expression" size="small" sx={{ flex: 1 }}
                value={form.cron_expr}
                onChange={e => setForm({ ...form, cron_expr: e.target.value })}
                placeholder="0 6 * * *" helperText="e.g. 0 6 * * * = daily at 6am UTC" />
            )}
            {form.schedule_type === 'interval' && (
              <>
                <TextField label="Hours" size="small" type="number" sx={{ width: 80 }}
                  value={form.interval_hours}
                  onChange={e => setForm({ ...form, interval_hours: e.target.value })} />
                <TextField label="Minutes" size="small" type="number" sx={{ width: 80 }}
                  value={form.interval_minutes}
                  onChange={e => setForm({ ...form, interval_minutes: e.target.value })} />
              </>
            )}
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving || !form.name.trim() || (!editingId && (!form.connection_id || !form.table_name))}>
            {saving ? <CircularProgress size={18} /> : editingId ? 'Save Changes' : 'Create & Refresh'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={!!deleteConfirm} onClose={() => setDeleteConfirm(null)} maxWidth="xs">
        <DialogTitle>Delete Materialized View</DialogTitle>
        <DialogContent>
          <Typography>
            Delete <strong>{deleteConfirm?.name}</strong>? This will remove all local data files ({fmtBytes(deleteConfirm?.size_bytes || 0)}).
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteConfirm(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default MaterializedViewsPage;
