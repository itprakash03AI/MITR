// @ts-nocheck
/**
 * NL-to-SQL Chat Panel (Phase 48)
 * Pattern-based natural language to SQL — no LLM required.
 *
 * Props:
 *   onUseSql(sql) — called when user clicks "Use this SQL"
 *   connectionId  — current connection (for schema context)
 *   tables        — available table names from schema browser
 *   columns       — table → column[] map
 *   connectionType — e.g. "trino", "snowflake", "duckdb"
 */
import React, { useState, useRef, useEffect } from 'react';
import {
  Box, Typography, TextField, Button, Paper, Chip, IconButton,
  Tooltip, CircularProgress, Alert, Divider, Stack,
} from '@mui/material';
import {
  Send as SendIcon,
  ContentCopy as CopyIcon,
  PlayArrow as UseIcon,
  LightbulbOutlined as TipIcon,
  AutoAwesome as MagicIcon,
} from '@mui/icons-material';
import api from '../services/api';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sql?: string;
  confidence?: number;
  pattern?: string;
  explanation?: string;
  warnings?: string[];
  alternatives?: string[];
}

interface NLToSQLPanelProps {
  onUseSql?: (sql: string) => void;
  connectionId?: number;
  tables?: string[];
  columns?: Record<string, string[]>;
  connectionType?: string;
  defaultSchema?: string;
  datasetId?: number;
  datasetName?: string;
}

const CONFIDENCE_COLOR = (c: number) => {
  if (c >= 0.8) return 'success';
  if (c >= 0.5) return 'warning';
  return 'error';
};

const EXAMPLE_PROMPTS = [
  'top 10 customers by revenue',
  'count orders',
  'average salary by department',
  'distinct values of status in orders',
  'show all products',
  'orders where status is pending',
];

const NLToSQLPanel: React.FC<NLToSQLPanelProps> = ({
  onUseSql,
  connectionId,
  tables = [],
  columns = {},
  connectionType = 'duckdb',
  defaultSchema,
  datasetId,
  datasetName,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [examples, setExamples] = useState<any[]>(EXAMPLE_PROMPTS.map(p => ({ prompt: p })));
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.getNlToSqlExamples(datasetId).then((r: any) => {
      if (r?.examples) setExamples(r.examples);
    }).catch(() => {});
  }, [datasetId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (question?: string) => {
    const q = (question || input).trim();
    if (!q) return;
    setInput('');
    const msgId = Date.now().toString();
    setMessages(prev => [...prev, { id: msgId + '_u', role: 'user', content: q }]);
    setLoading(true);
    try {
      const result: any = await api.nlToSql({
        question: q,
        connection_id: connectionId,
        tables,
        columns,
        connection_type: connectionType,
        default_schema: defaultSchema,
        dataset_id: datasetId,
      });
      setMessages(prev => [
        ...prev,
        {
          id: msgId + '_a',
          role: 'assistant',
          content: result.explanation || 'SQL generated.',
          sql: result.sql,
          confidence: result.confidence,
          pattern: result.pattern_matched,
          explanation: result.explanation,
          warnings: result.warnings || [],
          alternatives: result.alternatives || [],
        },
      ]);
    } catch (e: any) {
      setMessages(prev => [
        ...prev,
        { id: msgId + '_e', role: 'assistant', content: `Error: ${e.message || 'Failed to generate SQL'}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Header */}
      <Box sx={{ px: 2, py: 1, borderBottom: 1, borderColor: 'divider',
                 display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'background.paper' }}>
        <MagicIcon sx={{ color: 'primary.main', fontSize: 18 }} />
        <Typography variant="subtitle2" fontWeight={700}>Ask in Plain English</Typography>
        {datasetId ? (
          <Chip size="small" label={`Semantic: ${datasetName || `dataset #${datasetId}`}`}
            color="secondary" variant="outlined"
            sx={{ height: 16, fontSize: '0.68rem', ml: 0.5 }} />
        ) : (
          <Typography variant="caption" color="text.secondary">(pattern-based, no AI)</Typography>
        )}
      </Box>

      {/* Messages */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1.5, py: 1, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {messages.length === 0 && (
          <Box>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5, mt: 0.5 }}>
              Describe your query in plain English and get SQL instantly. Try one:
            </Typography>
            <Stack direction="row" flexWrap="wrap" gap={0.75}>
              {examples.slice(0, 6).map((ex: any, i: number) => (
                <Chip key={i} label={ex.prompt} size="small" variant="outlined"
                  sx={{ cursor: 'pointer', fontSize: '0.75rem' }}
                  onClick={() => handleSend(ex.prompt)} />
              ))}
            </Stack>
          </Box>
        )}

        {messages.map(msg => (
          <Box key={msg.id}
            sx={{ display: 'flex', flexDirection: 'column',
                  alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
            {msg.role === 'user' ? (
              <Paper elevation={0} sx={{
                px: 1.5, py: 0.75, bgcolor: 'primary.main', color: 'primary.contrastText',
                borderRadius: '12px 12px 2px 12px', maxWidth: '85%',
              }}>
                <Typography variant="body2">{msg.content}</Typography>
              </Paper>
            ) : (
              <Box sx={{ maxWidth: '100%', width: '100%' }}>
                {/* Explanation */}
                <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5, fontSize: '0.8rem' }}>
                  {msg.explanation}
                </Typography>

                {/* Confidence + pattern */}
                {msg.confidence != null && (
                  <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mb: 0.75 }}>
                    <Chip label={`${Math.round(msg.confidence * 100)}% match`}
                      size="small" color={CONFIDENCE_COLOR(msg.confidence)}
                      sx={{ height: 18, fontSize: '0.7rem' }} />
                    {msg.pattern && (
                      <Chip label={msg.pattern} size="small" variant="outlined"
                        sx={{ height: 18, fontSize: '0.7rem' }} />
                    )}
                  </Stack>
                )}

                {/* SQL block */}
                {msg.sql && (
                  <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, position: 'relative' }}>
                    <Box component="pre" sx={{
                      m: 0, fontFamily: 'monospace', fontSize: '0.78rem',
                      whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                      color: 'text.primary', lineHeight: 1.6,
                    }}>
                      {msg.sql}
                    </Box>
                    <Stack direction="row" spacing={0.5} sx={{ mt: 1 }}>
                      <Button size="small" variant="contained" startIcon={<UseIcon sx={{ fontSize: 14 }} />}
                        sx={{ fontSize: '0.72rem', py: 0.3 }}
                        onClick={() => onUseSql?.(msg.sql!)}>
                        Use this SQL
                      </Button>
                      <Tooltip title="Copy SQL">
                        <IconButton size="small" onClick={() => navigator.clipboard.writeText(msg.sql!)}>
                          <CopyIcon sx={{ fontSize: 14 }} />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </Paper>
                )}

                {/* Warnings */}
                {msg.warnings && msg.warnings.length > 0 && (
                  <Alert severity="warning" icon={<TipIcon fontSize="small" />}
                    sx={{ mt: 0.75, py: 0.25, fontSize: '0.75rem' }}>
                    {msg.warnings.join(' ')}
                  </Alert>
                )}

                {/* Alternatives */}
                {msg.alternatives && msg.alternatives.length > 0 && (
                  <Box sx={{ mt: 0.75 }}>
                    <Typography variant="caption" color="text.secondary">Alternatives:</Typography>
                    {msg.alternatives.map((alt, i) => (
                      <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.25 }}>
                        <Box component="code" sx={{ fontSize: '0.72rem', color: 'text.secondary', flex: 1 }}>
                          {alt}
                        </Box>
                        <Tooltip title="Use alternative">
                          <IconButton size="small" onClick={() => onUseSql?.(alt)}>
                            <UseIcon sx={{ fontSize: 12 }} />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    ))}
                  </Box>
                )}
              </Box>
            )}
          </Box>
        ))}

        {loading && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CircularProgress size={14} />
            <Typography variant="caption" color="text.secondary">Generating SQL…</Typography>
          </Box>
        )}
        <div ref={bottomRef} />
      </Box>

      <Divider />

      {/* Input */}
      <Box sx={{ px: 1.5, py: 1, display: 'flex', gap: 1, alignItems: 'flex-end', bgcolor: 'background.paper' }}>
        <TextField
          multiline maxRows={3} fullWidth size="small"
          placeholder="e.g. top 10 orders by revenue last month"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          sx={{ '& .MuiInputBase-root': { fontSize: '0.82rem' } }}
        />
        <IconButton color="primary" onClick={() => handleSend()} disabled={!input.trim() || loading}
          sx={{ mb: 0.25 }}>
          <SendIcon />
        </IconButton>
      </Box>
    </Box>
  );
};

export default NLToSQLPanel;
