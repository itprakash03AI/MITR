/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-nocheck
/**
 * Report Connectors (Phase 24C)
 *
 * Matrix view showing all reports with their connection assignments.
 * Allows inline per-report connection override and bulk reassignment (admin).
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, FormControl, IconButton, InputAdornment,
  InputLabel, MenuItem, Paper, Select, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  SwapHoriz as SwapIcon,
} from '@mui/icons-material';
import { useAppSettings } from '../context/AppSettingsContext';
import api from '../services/api';

const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 'oracle'];

// ─── BulkReassignDialog ────────────────────────────────────────────────────

function BulkReassignDialog({ open, reportCount, connections, onConfirm, onClose }) {
  const [selected, setSelected] = useState('');
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Change Connection Override — {reportCount} report{reportCount !== 1 ? 's' : ''}</DialogTitle>
      <DialogContent sx={{ pt: 1 }}>
        <FormControl size="small" fullWidth>
          <InputLabel>New Connection Override</InputLabel>
          <Select value={selected} onChange={e => setSelected(e.target.value as string)}
            label="New Connection Override">
            <MenuItem value=""><em>Clear override (use query default)</em></MenuItem>
            {connections.map((c: any) => (
              <MenuItem key={c.id} value={c.id}>{c.name} ({c.connection_type})</MenuItem>
            ))}
          </Select>
        </FormControl>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained"
          onClick={() => { onConfirm(selected ? Number(selected) : null); setSelected(''); }}>
          Apply
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────

export default function ReportConnectorsPage() {
  const appSettings = useAppSettings();
  const isAdmin = appSettings.role === 'admin';

  const [rows, setRows]           = useState<any[]>([]);
  const [connections, setConns]   = useState<any[]>([]);
  const [loading, setLoading]     = useState(false);
  const [searchQ, setSearchQ]     = useState('');
  const [typeFilter, setTypeFilter] = useState('all');   // all | sql | parquet
  const [connFilter, setConnFilter] = useState('');       // connection id or ''
  const [selected, setSelected]   = useState<Set<number>>(new Set());
  const [bulkOpen, setBulkOpen]   = useState(false);
  const [saving, setSaving]       = useState<Set<number>>(new Set());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [matrix, conns]: any[] = await Promise.all([
        api.getReportConnectorMatrix(),
        api.listConnections(true),
      ]);
      setRows(matrix?.reports || []);
      setConns((conns || []).filter((c: any) => SQL_TYPES.includes(c.connection_type)));
    } catch { /* ignore */ } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => rows.filter(r => {
    if (typeFilter !== 'all' && r.source_type !== typeFilter) return false;
    if (connFilter) {
      const cid = Number(connFilter);
      const eff = r.effective_connection;
      if (!eff || eff.id !== cid) return false;
    }
    if (searchQ) {
      const q = searchQ.toLowerCase();
      return (r.name || '').toLowerCase().includes(q) || (r.description || '').toLowerCase().includes(q);
    }
    return true;
  }), [rows, typeFilter, connFilter, searchQ]);

  const toggleSelect = (id: number) => {
    setSelected(s => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  };
  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map(r => r.id)));
  };

  const handleInlineChange = async (reportId: number, connId: number | null) => {
    setSaving(s => new Set(s).add(reportId));
    // Optimistic update
    setRows(rs => rs.map(r => r.id === reportId
      ? { ...r, connection_override_id: connId,
          override_connection: connId ? connections.find(c => c.id === connId) || null : null,
          effective_connection: connId ? connections.find(c => c.id === connId) || r.assigned_connection : r.assigned_connection,
        }
      : r));
    try {
      await api.updateReport(String(reportId), { connection_override_id: connId === null ? 0 : connId });
    } catch {
      // Rollback on error
      load();
    } finally {
      setSaving(s => { const n = new Set(s); n.delete(reportId); return n; });
    }
  };

  const handleBulkConfirm = async (connId: number | null) => {
    setBulkOpen(false);
    await api.bulkSetConnectionOverride([...selected], connId);
    setSelected(new Set());
    load();
  };

  const connLabel = (c: any) => c ? `${c.name} (${c.connection_type})` : '—';

  return (
    <Box sx={{ p: 3, height: '100%', overflow: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Report Connectors</Typography>
          <Typography variant="body2" color="text.secondary">
            Manage which data source each report reads from. Override per report or switch environments via Connection Profiles.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          {appSettings.active_connection_profile && (
            <Chip
              icon={<SwapIcon />}
              label={`Profile: ${appSettings.active_connection_profile.name}`}
              color="warning" size="small"
            />
          )}
          <Tooltip title="Refresh">
            <IconButton onClick={load}><RefreshIcon /></IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Filter bar */}
      <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
        <TextField
          size="small" placeholder="Search reports…" value={searchQ}
          onChange={e => setSearchQ(e.target.value)}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
            endAdornment: searchQ ? (
              <InputAdornment position="end">
                <IconButton size="small" onClick={() => setSearchQ('')}><ClearIcon fontSize="small" /></IconButton>
              </InputAdornment>
            ) : null,
          }}
          sx={{ width: 260 }}
        />
        <FormControl size="small" sx={{ minWidth: 140 }}>
          <InputLabel>Source Type</InputLabel>
          <Select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} label="Source Type">
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="sql">SQL only</MenuItem>
            <MenuItem value="parquet">Parquet only</MenuItem>
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Connection</InputLabel>
          <Select value={connFilter} onChange={e => setConnFilter(e.target.value)} label="Filter by Connection">
            <MenuItem value="">Any connection</MenuItem>
            {connections.map((c: any) => (
              <MenuItem key={c.id} value={String(c.id)}>{c.name} ({c.connection_type})</MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      {/* Bulk action bar */}
      {selected.size > 0 && isAdmin && (
        <Alert severity="info" sx={{ mb: 1 }}
          action={
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button size="small" variant="outlined" onClick={() => setBulkOpen(true)}>
                Set Override ({selected.size})
              </Button>
              <Button size="small" color="error" variant="outlined"
                onClick={() => handleBulkConfirm(null)}>
                Clear Override ({selected.size})
              </Button>
              <Button size="small" onClick={() => setSelected(new Set())}>Deselect</Button>
            </Box>
          }>
          {selected.size} report{selected.size !== 1 ? 's' : ''} selected
        </Alert>
      )}

      {/* Table */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                {isAdmin && (
                  <TableCell padding="checkbox">
                    <input type="checkbox"
                      checked={selected.size > 0 && selected.size === filtered.length}
                      onChange={toggleAll}
                    />
                  </TableCell>
                )}
                <TableCell>Report</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Assigned Connection</TableCell>
                <TableCell>Override</TableCell>
                <TableCell>Effective</TableCell>
                <TableCell>Profile Maps To</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={isAdmin ? 7 : 6} align="center" sx={{ py: 4 }}>
                    {rows.length === 0 ? (
                      <Box>
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          No reports yet.
                        </Typography>
                        <Typography variant="caption" color="text.disabled">
                          Go to <strong>Parametric Reports</strong> to create SQL reports, then return here to manage their connection assignments.
                        </Typography>
                      </Box>
                    ) : (
                      <Typography variant="caption" color="text.disabled">No reports match the current filters</Typography>
                    )}
                  </TableCell>
                </TableRow>
              )}
              {filtered.map((r: any) => {
                const isSaving = saving.has(r.id);
                return (
                  <TableRow key={r.id} hover selected={selected.has(r.id)}>
                    {isAdmin && (
                      <TableCell padding="checkbox">
                        <input type="checkbox" checked={selected.has(r.id)} onChange={() => toggleSelect(r.id)} />
                      </TableCell>
                    )}
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>{r.name}</Typography>
                      {r.description && (
                        <Typography variant="caption" color="text.secondary">{r.description}</Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={r.source_type === 'sql' ? 'SQL' : 'Parquet'}
                        size="small"
                        color={r.source_type === 'sql' ? 'primary' : 'default'}
                        variant="outlined"
                        sx={{ height: 20, fontSize: 10 }}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" color={r.override_connection ? 'text.disabled' : 'text.primary'}>
                        {r.source_type === 'parquet' ? '— (file-based)' : connLabel(r.assigned_connection)}
                      </Typography>
                    </TableCell>
                    {/* Inline override picker (SQL reports + admin only) */}
                    <TableCell>
                      {r.source_type === 'parquet' ? (
                        <Typography variant="caption" color="text.disabled">N/A</Typography>
                      ) : isAdmin ? (
                        <FormControl size="small" sx={{ minWidth: 180 }}>
                          <Select
                            value={r.connection_override_id || ''}
                            disabled={isSaving}
                            onChange={e => handleInlineChange(r.id, e.target.value ? Number(e.target.value) : null)}
                            displayEmpty
                            sx={{ fontSize: 12 }}
                          >
                            <MenuItem value=""><em>Query default</em></MenuItem>
                            {connections.map((c: any) => (
                              <MenuItem key={c.id} value={c.id} sx={{ fontSize: 12 }}>
                                {c.name} ({c.connection_type})
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      ) : (
                        <Typography variant="caption">
                          {r.override_connection ? connLabel(r.override_connection) : '—'}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={600}>
                        {r.source_type === 'parquet' ? '— (file-based)' : connLabel(r.effective_connection)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {r.profile_mapped_connection ? (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <SwapIcon fontSize="small" color="warning" />
                          <Typography variant="caption" color="warning.main">
                            {connLabel(r.profile_mapped_connection)}
                          </Typography>
                        </Box>
                      ) : (
                        <Typography variant="caption" color="text.disabled">—</Typography>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Bulk reassign dialog */}
      <BulkReassignDialog
        open={bulkOpen}
        reportCount={selected.size}
        connections={connections}
        onConfirm={handleBulkConfirm}
        onClose={() => setBulkOpen(false)}
      />
    </Box>
  );
}
