/**
 * BusinessPortalPage — Phase 59: Role-based landing page
 *
 * Aggregates recent reports, favorites, certified templates, KPI summary,
 * quick actions, dashboards, and recent activity into a single portal view.
 * Content is filtered by the caller's role (viewer / analyst / admin).
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import CircularProgress from '@mui/material/CircularProgress';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import SearchIcon from '@mui/icons-material/Search';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BuildIcon from '@mui/icons-material/Build';
import CodeIcon from '@mui/icons-material/Code';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import DescriptionIcon from '@mui/icons-material/Description';
import HistoryIcon from '@mui/icons-material/History';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import AssessmentIcon from '@mui/icons-material/Assessment';
import StarIcon from '@mui/icons-material/Star';
import ScheduleIcon from '@mui/icons-material/Schedule';
import NotificationsIcon from '@mui/icons-material/Notifications';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import RefreshIcon from '@mui/icons-material/Refresh';
import { useAuth } from '../context/AuthContext';
import { useComponentVisible } from '../context/UIVisibilityContext';
import api from '../services/api';

// ── Constants ────────────────────────────────────────────────────────────────

const KPI_CARD_MIN_WIDTH = 200;
const REPORT_CARD_MIN_WIDTH = 280;
const QUICK_ACTION_MIN_WIDTH = 160;
const SECTION_SPACING = 3;
const REFRESH_INTERVAL_MS = 120_000; // 2 min
const SEARCH_DEBOUNCE_MS = 400;

interface QuickAction {
  key: string;
  label: string;
  icon: React.ReactNode;
  path: string;
  roles: string[];
  componentKey?: string;
}

const QUICK_ACTIONS: QuickAction[] = [
  { key: 'catalog',   label: 'Browse Catalog',   icon: <FolderOpenIcon />,          path: '/report-catalog',       roles: ['admin', 'analyst', 'viewer'], componentKey: 'report_catalog' },
  { key: 'create',    label: 'Create Report',     icon: <AddCircleOutlineIcon />,    path: '/business-reports/new', roles: ['admin', 'analyst'],           componentKey: 'business_reports' },
  { key: 'dashboards',label: 'View Dashboards',   icon: <DashboardIcon />,           path: '/dashboards',           roles: ['admin', 'analyst', 'viewer'], componentKey: 'dashboards' },
  { key: 'reports',   label: 'Business Reports',  icon: <DescriptionIcon />,         path: '/business-reports',     roles: ['admin', 'analyst', 'viewer'], componentKey: 'business_reports' },
  { key: 'query',     label: 'Query Builder',     icon: <BuildIcon />,               path: '/query-builder',        roles: ['admin', 'analyst'],           componentKey: 'query_builder' },
  { key: 'sql',       label: 'SQL Editor',        icon: <CodeIcon />,                path: '/sql',                  roles: ['admin', 'analyst'],           componentKey: 'sql_editor' },
  { key: 'saved',     label: 'Saved Queries',     icon: <BookmarkIcon />,            path: '/saved-queries',        roles: ['admin', 'analyst', 'viewer'], componentKey: 'saved_queries' },
  { key: 'executions',label: 'Executions',        icon: <HistoryIcon />,             path: '/executions',           roles: ['admin', 'analyst', 'viewer'], componentKey: 'executions' },
  { key: 'admin',     label: 'Admin Panel',       icon: <AdminPanelSettingsIcon />,  path: '/admin',                roles: ['admin'],                      componentKey: 'admin' },
];

// ── Sub-components ───────────────────────────────────────────────────────────

function KPICard({ title, value, icon, color, onClick }: {
  title: string; value: number; icon: React.ReactNode; color: string; onClick?: () => void;
}) {
  return (
    <Paper elevation={0} sx={{
      p: 2.5, borderRadius: 2, border: '1px solid', borderColor: 'divider',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'box-shadow 0.15s',
      '&:hover': onClick ? { boxShadow: 3 } : {},
    }} onClick={onClick}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Box sx={{
          width: 44, height: 44, borderRadius: 2,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          bgcolor: `${color}22`, color,
        }}>
          {icon}
        </Box>
        <Box>
          <Typography variant="h4" fontWeight={700}>{value.toLocaleString()}</Typography>
          <Typography variant="body2" color="text.secondary">{title}</Typography>
        </Box>
      </Box>
    </Paper>
  );
}

function PortalReportCard({ report, onNavigate }: { report: any; onNavigate: (r: any) => void }) {
  const isBusiness = report.report_type === 'business';
  return (
    <Paper elevation={0} sx={{
      p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider',
      cursor: 'pointer', transition: 'box-shadow 0.15s',
      '&:hover': { boxShadow: 3 },
    }} onClick={() => onNavigate(report)}>
      <Typography variant="subtitle2" fontWeight={600} noWrap>{report.name}</Typography>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }} noWrap>
        {report.description || 'No description'}
      </Typography>
      <Box sx={{ display: 'flex', gap: 0.5, mt: 1, alignItems: 'center', flexWrap: 'wrap' }}>
        <Chip size="small" label={isBusiness ? 'Business' : 'Parametric'}
          sx={{ height: 20, fontSize: 11 }}
          color={isBusiness ? 'success' : 'primary'} variant="outlined" />
        {report.is_certified && (
          <Chip size="small" icon={<CheckCircleIcon sx={{ fontSize: '12px !important' }} />}
            label="Certified" sx={{ height: 20, fontSize: 11 }} color="warning" variant="outlined" />
        )}
        {report.template_category && (
          <Chip size="small" label={report.template_category}
            sx={{ height: 20, fontSize: 11 }} variant="outlined" />
        )}
      </Box>
    </Paper>
  );
}

function QuickActionCard({ action, onClick }: { action: QuickAction; onClick: () => void }) {
  return (
    <Paper elevation={0} sx={{
      p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider',
      cursor: 'pointer', transition: 'box-shadow 0.15s', textAlign: 'center',
      '&:hover': { boxShadow: 3, borderColor: 'primary.main' },
    }} onClick={onClick}>
      <Box sx={{ color: 'primary.main', mb: 1 }}>{action.icon}</Box>
      <Typography variant="body2" fontWeight={500}>{action.label}</Typography>
    </Paper>
  );
}

function SectionHeader({ title, seeAllPath, onSeeAll }: {
  title: string; seeAllPath?: string; onSeeAll?: () => void;
}) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
      <Typography variant="h6" fontWeight={600}>{title}</Typography>
      {seeAllPath && onSeeAll && (
        <Button size="small" endIcon={<ArrowForwardIcon />} onClick={onSeeAll}
          sx={{ textTransform: 'none' }}>
          See all
        </Button>
      )}
    </Box>
  );
}

function ActivityItem({ entry }: { entry: any }) {
  const ts = entry.timestamp ? new Date(entry.timestamp).toLocaleString() : '';
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.75 }}>
      <HistoryIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography variant="body2" noWrap>
          <strong>{entry.action}</strong>{' '}
          {entry.resource_type && <span>on {entry.resource_type}</span>}
          {entry.resource_id && <span> #{entry.resource_id}</span>}
        </Typography>
      </Box>
      <Typography variant="caption" color="text.disabled" sx={{ whiteSpace: 'nowrap' }}>{ts}</Typography>
    </Box>
  );
}

// ── Main component ───────────────────────────────────────────────────────────

export default function BusinessPortalPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const role = (user as any)?.role || 'viewer';
  const username = (user as any)?.username || '';
  const portalVisible = useComponentVisible('business_portal');

  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadPortal = useCallback(async () => {
    try {
      const result = await api.getPortalSummary();
      setData(result);
    } catch {
      // Graceful fallback — show empty portal
      setData({
        welcome_message: 'Welcome to QueryStudio',
        welcome_subtitle: 'Your enterprise data platform',
        kpi: { total_reports: 0, favorites_count: 0, executions_today: 0, unread_notifications: 0, dashboards_count: 0 },
        recent_reports: [], favorites: [], certified_templates: [], recent_activity: [], dashboards: [],
        quick_actions_enabled: true, kpi_cards_enabled: true, active_queries: 0, role: 'viewer',
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPortal();
    const interval = setInterval(loadPortal, REFRESH_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [loadPortal]);

  // Debounced search → navigate to catalog
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const q = e.target.value;
    setSearchQuery(q);
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    searchTimerRef.current = setTimeout(() => {
      if (q.trim().length >= 2) {
        navigate(`/report-catalog?q=${encodeURIComponent(q.trim())}`);
      }
    }, SEARCH_DEBOUNCE_MS);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/report-catalog?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleNavigateReport = useCallback((report: any) => {
    if (report.report_type === 'business') {
      navigate(`/business-reports/${report.id}`);
    } else {
      navigate(`/reports/${report.id}`);
    }
  }, [navigate]);

  // Filter quick actions by role + component visibility
  const visibleActions = useMemo(() =>
    QUICK_ACTIONS.filter(a => a.roles.includes(role)),
    [role],
  );

  if (!portalVisible) return null;

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  const kpi = data?.kpi || {};

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto', p: { xs: 2, sm: 3 } }}>
      {/* ── Hero Banner ──────────────────────────────────────────────────── */}
      <Paper elevation={0} sx={{
        p: { xs: 3, sm: 4 }, mb: SECTION_SPACING, borderRadius: 3,
        background: (theme) => `linear-gradient(135deg, ${theme.palette.primary.main}11, ${theme.palette.primary.main}05)`,
        border: '1px solid', borderColor: 'divider',
      }}>
        <Typography variant="h4" fontWeight={700} gutterBottom>
          {data?.welcome_message || 'Welcome to QueryStudio'}
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
          {data?.welcome_subtitle || 'Your enterprise data platform'}
          {username && <span> — {username}</span>}
        </Typography>
        <Box component="form" onSubmit={handleSearchSubmit} sx={{ display: 'flex', gap: 1, maxWidth: 500 }}>
          <TextField
            size="small" fullWidth placeholder="Search reports, templates..."
            value={searchQuery} onChange={handleSearchChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
              ),
            }}
          />
          <Button variant="contained" size="small" type="submit" sx={{ textTransform: 'none', px: 3 }}>
            Search
          </Button>
        </Box>
      </Paper>

      {/* ── KPI Row ──────────────────────────────────────────────────────── */}
      {data?.kpi_cards_enabled && (
        <Box sx={{
          display: 'grid',
          gridTemplateColumns: `repeat(auto-fill, minmax(${KPI_CARD_MIN_WIDTH}px, 1fr))`,
          gap: 2, mb: SECTION_SPACING,
        }}>
          <KPICard title="Reports" value={kpi.total_reports || 0}
            icon={<AssessmentIcon />} color="#1976d2"
            onClick={() => navigate('/report-catalog')} />
          <KPICard title="Favorites" value={kpi.favorites_count || 0}
            icon={<StarIcon />} color="#ed6c02"
            onClick={() => navigate('/report-catalog')} />
          <KPICard title="Executions Today" value={kpi.executions_today || 0}
            icon={<ScheduleIcon />} color="#2e7d32" />
          <KPICard title="Notifications" value={kpi.unread_notifications || 0}
            icon={<NotificationsIcon />} color="#9c27b0" />
          {role === 'admin' && (data?.active_queries || 0) > 0 && (
            <KPICard title="Active Queries" value={data.active_queries}
              icon={<RefreshIcon />} color="#d32f2f"
              onClick={() => navigate('/admin')} />
          )}
        </Box>
      )}

      {/* ── Quick Actions ────────────────────────────────────────────────── */}
      {data?.quick_actions_enabled && visibleActions.length > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="Quick Actions" />
          <Box sx={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, minmax(${QUICK_ACTION_MIN_WIDTH}px, 1fr))`,
            gap: 1.5,
          }}>
            {visibleActions.map(a => (
              <QuickActionCard key={a.key} action={a} onClick={() => navigate(a.path)} />
            ))}
          </Box>
        </Box>
      )}

      {/* ── Recently Viewed ──────────────────────────────────────────────── */}
      {(data?.recent_reports?.length || 0) > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="Recently Viewed" seeAllPath="/report-catalog"
            onSeeAll={() => navigate('/report-catalog')} />
          <Box sx={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, minmax(${REPORT_CARD_MIN_WIDTH}px, 1fr))`,
            gap: 2,
          }}>
            {data.recent_reports.map((r: any) => (
              <PortalReportCard key={`${r.report_type}-${r.id}`} report={r}
                onNavigate={handleNavigateReport} />
            ))}
          </Box>
        </Box>
      )}

      {/* ── Favorites ────────────────────────────────────────────────────── */}
      {(data?.favorites?.length || 0) > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="My Favorites" seeAllPath="/report-catalog"
            onSeeAll={() => navigate('/report-catalog')} />
          <Box sx={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, minmax(${REPORT_CARD_MIN_WIDTH}px, 1fr))`,
            gap: 2,
          }}>
            {data.favorites.map((r: any) => (
              <PortalReportCard key={`fav-${r.report_type}-${r.id}`} report={r}
                onNavigate={handleNavigateReport} />
            ))}
          </Box>
        </Box>
      )}

      {/* ── Certified Templates ──────────────────────────────────────────── */}
      {(data?.certified_templates?.length || 0) > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="Certified Templates" seeAllPath="/report-catalog"
            onSeeAll={() => navigate('/report-catalog')} />
          <Box sx={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, minmax(${REPORT_CARD_MIN_WIDTH}px, 1fr))`,
            gap: 2,
          }}>
            {data.certified_templates.map((t: any) => (
              <Paper key={`tpl-${t.id}`} elevation={0} sx={{
                p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider',
                cursor: 'pointer', transition: 'box-shadow 0.15s',
                '&:hover': { boxShadow: 3 },
              }} onClick={() => navigate(`/business-reports/${t.id}`)}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                  <CheckCircleIcon sx={{ fontSize: 16, color: 'success.main' }} />
                  <Typography variant="subtitle2" fontWeight={600} noWrap>{t.name}</Typography>
                </Box>
                <Typography variant="caption" color="text.secondary" noWrap>
                  {t.description || 'Certified template'}
                </Typography>
                {t.template_category && (
                  <Chip size="small" label={t.template_category}
                    sx={{ height: 20, fontSize: 11, mt: 1 }} variant="outlined" />
                )}
                <Button size="small" fullWidth variant="outlined" sx={{ mt: 1.5, textTransform: 'none' }}
                  onClick={(e) => { e.stopPropagation(); navigate(`/business-reports/${t.id}`); }}>
                  Use Template
                </Button>
              </Paper>
            ))}
          </Box>
        </Box>
      )}

      {/* ── My Dashboards ────────────────────────────────────────────────── */}
      {(data?.dashboards?.length || 0) > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="My Dashboards" seeAllPath="/dashboards"
            onSeeAll={() => navigate('/dashboards')} />
          <Box sx={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, minmax(${REPORT_CARD_MIN_WIDTH}px, 1fr))`,
            gap: 2,
          }}>
            {data.dashboards.map((d: any) => (
              <Paper key={`dash-${d.id}`} elevation={0} sx={{
                p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider',
                cursor: 'pointer', transition: 'box-shadow 0.15s',
                '&:hover': { boxShadow: 3 },
              }} onClick={() => navigate(`/dashboards`)}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <DashboardIcon sx={{ fontSize: 20, color: 'primary.main' }} />
                  <Typography variant="subtitle2" fontWeight={600} noWrap>{d.name}</Typography>
                </Box>
                <Typography variant="caption" color="text.secondary">
                  {d.widget_count || 0} widget{(d.widget_count || 0) !== 1 ? 's' : ''}
                </Typography>
              </Paper>
            ))}
          </Box>
        </Box>
      )}

      {/* ── Recent Activity (analyst/admin only) ─────────────────────────── */}
      {(data?.recent_activity?.length || 0) > 0 && (
        <Box sx={{ mb: SECTION_SPACING }}>
          <SectionHeader title="Recent Activity" />
          <Paper elevation={0} sx={{
            p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider',
          }}>
            {data.recent_activity.map((entry: any, i: number) => (
              <React.Fragment key={entry.id || i}>
                <ActivityItem entry={entry} />
                {i < data.recent_activity.length - 1 && <Divider />}
              </React.Fragment>
            ))}
          </Paper>
        </Box>
      )}

      {/* ── Empty State ──────────────────────────────────────────────────── */}
      {!data?.recent_reports?.length && !data?.favorites?.length &&
       !data?.certified_templates?.length && !data?.dashboards?.length && (
        <Paper elevation={0} sx={{
          p: 4, borderRadius: 2, border: '1px solid', borderColor: 'divider',
          textAlign: 'center',
        }}>
          <AssessmentIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 1 }} />
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No reports yet
          </Typography>
          <Typography variant="body2" color="text.disabled" sx={{ mb: 2 }}>
            Browse the catalog or create a new report to get started.
          </Typography>
          <Button variant="contained" sx={{ textTransform: 'none' }}
            onClick={() => navigate('/report-catalog')}>
            Browse Catalog
          </Button>
        </Paper>
      )}
    </Box>
  );
}
