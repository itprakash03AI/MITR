// @ts-nocheck
/**
 * QueryWarningBanner (Phase 47)
 * Displays pre-execution query analysis warnings above query results.
 */
import React, { useState } from 'react';
import { Alert, AlertTitle, Box, Chip, Collapse, IconButton, Stack, Typography } from '@mui/material';
import { ExpandMore as ExpandIcon, ExpandLess as CollapseIcon } from '@mui/icons-material';

export interface QueryWarning {
  code: string;
  severity: 'info' | 'warning' | 'error';
  message: string;
  detail?: string;
  suggestion?: string;
}

interface QueryWarningBannerProps {
  warnings: QueryWarning[];
  onDismiss?: () => void;
}

const SEVERITY_ORDER = { error: 0, warning: 1, info: 2 };

const QueryWarningBanner: React.FC<QueryWarningBannerProps> = ({ warnings, onDismiss }) => {
  const [expanded, setExpanded] = useState(false);

  if (!warnings || warnings.length === 0) return null;

  // Show highest severity alert
  const sorted = [...warnings].sort(
    (a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]
  );
  const highest = sorted[0];
  const rest = sorted.slice(1);

  return (
    <Alert
      severity={highest.severity}
      onClose={onDismiss}
      sx={{ mb: 1, py: 0.5, '& .MuiAlert-message': { width: '100%' } }}
      action={
        warnings.length > 1 ? (
          <IconButton size="small" onClick={() => setExpanded(e => !e)}>
            {expanded ? <CollapseIcon fontSize="small" /> : <ExpandIcon fontSize="small" />}
          </IconButton>
        ) : undefined
      }
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
        <Typography variant="body2" fontWeight={600}>{highest.message}</Typography>
        <Chip label={highest.code} size="small"
          sx={{ height: 16, fontSize: '0.65rem', '& .MuiChip-label': { px: 0.75 } }} />
        {warnings.length > 1 && (
          <Typography variant="caption" color="text.secondary">
            +{warnings.length - 1} more warning{warnings.length > 2 ? 's' : ''}
          </Typography>
        )}
      </Box>
      {highest.suggestion && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.25 }}>
          💡 {highest.suggestion}
        </Typography>
      )}

      {/* Expanded list */}
      <Collapse in={expanded}>
        <Stack spacing={0.75} sx={{ mt: 1 }}>
          {rest.map((w, i) => (
            <Alert key={i} severity={w.severity} sx={{ py: 0.25, '& .MuiAlert-icon': { py: 0.5 } }}>
              <Box>
                <Typography variant="caption" fontWeight={600}>{w.message}</Typography>
                {w.suggestion && (
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    💡 {w.suggestion}
                  </Typography>
                )}
              </Box>
            </Alert>
          ))}
        </Stack>
      </Collapse>
    </Alert>
  );
};

export default QueryWarningBanner;
