/**
 * QueryTabManager — Tabbed query editor wrapper (like Starburst / Oracle Toad).
 * Each tab is an independent CompleteQueryBuilder instance.
 * Tabs persist in sessionStorage across page reloads.
 */
// @ts-nocheck
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Chip, IconButton, Tooltip, TextField, Menu, MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  Close as CloseIcon,
  Edit as EditIcon,
  FiberManualRecord as DotIcon,
} from '@mui/icons-material';
import CompleteQueryBuilder from './CompleteQueryBuilder';

// ── Types ────────────────────────────────────────────────────────────────────

interface TabSnapshot {
  connectionId: number | null;
  queryConfig: any;
  queryMode: 'visual' | 'sql';
  rawSql: string;
  enableStreaming: boolean;
  streamBgDownload: boolean;
  editingQueryId: string | null;
  editingQueryName: string;
  resultsExecutionId: string | null;
  streamingSource: any;
}

interface TabState {
  id: string;
  name: string;
  dirty: boolean;
  snapshot: TabSnapshot | null;
}

const STORAGE_KEY = 'qs_query_tabs';
const MAX_TABS = 10;

const makeId = () => `tab-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

const defaultTab = (): TabState => ({
  id: makeId(),
  name: 'New Query',
  dirty: false,
  snapshot: null,
});

// ── Component ────────────────────────────────────────────────────────────────

const QueryTabManager = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [tabs, setTabs] = useState<TabState[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [renameTabId, setRenameTabId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [contextMenu, setContextMenu] = useState<{ anchorEl: HTMLElement; tabId: string } | null>(null);
  const initialized = useRef(false);
  const snapshotRef = useRef<Record<string, TabSnapshot | null>>({});

  // ── Initialize from sessionStorage ────────────────────────────────────
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    try {
      const saved = sessionStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.tabs?.length > 0) {
          setTabs(parsed.tabs);
          setActiveTabId(parsed.activeTabId || parsed.tabs[0].id);
          // Populate snapshot ref
          for (const t of parsed.tabs) {
            snapshotRef.current[t.id] = t.snapshot;
          }
          return;
        }
      }
    } catch {}
    // Default: one empty tab
    const tab = defaultTab();
    setTabs([tab]);
    setActiveTabId(tab.id);
  }, []);

  // ── Persist to sessionStorage on every change ─────────────────────────
  useEffect(() => {
    if (tabs.length === 0) return;
    // Merge latest snapshots into tab state before persisting
    const tabsWithSnapshots = tabs.map(t => ({
      ...t,
      snapshot: snapshotRef.current[t.id] ?? t.snapshot,
    }));
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
      tabs: tabsWithSnapshots,
      activeTabId,
    }));
  }, [tabs, activeTabId]);

  // ── Handle openLocalTable navigation from LocalTablesPage ────────────
  useEffect(() => {
    const tableName = location.state?.openLocalTable;
    if (!tableName) return;
    const path = `__local__:${tableName}`;
    // Check if a tab already has this local table open
    const existing = tabs.find(t =>
      (t.snapshot?.queryConfig?.files || []).includes(path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: tableName,
      dirty: false,
      snapshot: {
        connectionId: null,
        queryConfig: { files: [path], joins: [], columns: [], filters: [], filter_logic: 'AND' },
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: null,
        editingQueryName: '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.openLocalTable]); // eslint-disable-line

  // ── Handle openMaterializedView navigation from MaterializedViewsPage ─
  useEffect(() => {
    const mvName = location.state?.openMaterializedView;
    if (!mvName) return;
    const path = `__materialized__:${mvName}`;
    const existing = tabs.find(t =>
      (t.snapshot?.queryConfig?.files || []).includes(path)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    const newTab: TabState = {
      id: makeId(),
      name: mvName,
      dirty: false,
      snapshot: {
        connectionId: null,
        queryConfig: { files: [path], joins: [], columns: [], filters: [], filter_logic: 'AND' },
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: null,
        editingQueryName: '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.openMaterializedView]); // eslint-disable-line

  // ── Handle loadQuery from SavedQueries navigation ─────────────────────
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    // Check if this query is already open in a tab
    const existing = tabs.find(t =>
      t.snapshot?.editingQueryId === loadQuery.id ||
      t.snapshot?.editingQueryId === String(loadQuery.id)
    );
    if (existing) {
      setActiveTabId(existing.id);
      navigate('/', { replace: true, state: {} });
      return;
    }
    // Open in a new tab
    const newTab: TabState = {
      id: makeId(),
      name: loadQuery.name || 'Loaded Query',
      dirty: false,
      snapshot: {
        connectionId: loadQuery.query_config?.connection_id || null,
        queryConfig: loadQuery.query_config,
        queryMode: 'visual',
        rawSql: '',
        enableStreaming: false,
        streamBgDownload: true,
        editingQueryId: String(loadQuery.id),
        editingQueryName: loadQuery.name || '',
        resultsExecutionId: null,
        streamingSource: null,
      },
    };
    snapshotRef.current[newTab.id] = newTab.snapshot;
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    navigate('/', { replace: true, state: {} });
  }, [location.state?.loadQuery]); // eslint-disable-line

  // ── Tab operations ────────────────────────────────────────────────────
  const createTab = useCallback(() => {
    if (tabs.length >= MAX_TABS) return;
    const tab = defaultTab();
    setTabs(prev => [...prev, tab]);
    setActiveTabId(tab.id);
  }, [tabs.length]);

  const closeTab = useCallback((id: string) => {
    setTabs(prev => {
      const next = prev.filter(t => t.id !== id);
      if (next.length === 0) {
        const tab = defaultTab();
        next.push(tab);
        setActiveTabId(tab.id);
      } else if (activeTabId === id) {
        // Activate adjacent tab
        const idx = prev.findIndex(t => t.id === id);
        const newIdx = idx > 0 ? idx - 1 : 0;
        setActiveTabId(next[newIdx]?.id || next[0].id);
      }
      delete snapshotRef.current[id];
      return next;
    });
  }, [activeTabId]);

  const switchTab = useCallback((id: string) => {
    if (id === activeTabId) return;
    setActiveTabId(id);
  }, [activeTabId]);

  const renameTab = useCallback((id: string, name: string) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, name: name || 'Untitled' } : t));
  }, []);

  // ── Callbacks from CompleteQueryBuilder ────────────────────────────────
  const handleSnapshotChange = useCallback((tabId: string, snapshot: TabSnapshot) => {
    snapshotRef.current[tabId] = snapshot;
  }, []);

  const handleDirtyChange = useCallback((tabId: string, dirty: boolean) => {
    setTabs(prev => prev.map(t => t.id === tabId ? { ...t, dirty } : t));
  }, []);

  const handleNameChange = useCallback((tabId: string, name: string) => {
    if (name) setTabs(prev => prev.map(t => t.id === tabId ? { ...t, name } : t));
  }, []);

  // ── Render ────────────────────────────────────────────────────────────
  const activeTab = tabs.find(t => t.id === activeTabId);

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', flexDirection: 'column' }}>
      {/* ── Tab Bar ── */}
      <Box sx={{
        display: 'flex', alignItems: 'center', gap: 0,
        borderBottom: 1, borderColor: 'divider',
        bgcolor: 'background.paper', px: 0.5, minHeight: 34,
        overflowX: 'auto', flexShrink: 0,
        '&::-webkit-scrollbar': { height: 3 },
        '&::-webkit-scrollbar-thumb': { bgcolor: 'divider', borderRadius: 2 },
      }}>
        {tabs.map(tab => (
          <Box
            key={tab.id}
            onContextMenu={(e) => { e.preventDefault(); setContextMenu({ anchorEl: e.currentTarget, tabId: tab.id }); }}
            sx={{
              display: 'flex', alignItems: 'center', gap: 0.3,
              px: 1.2, py: 0.4, cursor: 'pointer', userSelect: 'none',
              borderBottom: tab.id === activeTabId ? '2px solid' : '2px solid transparent',
              borderBottomColor: tab.id === activeTabId ? 'primary.main' : 'transparent',
              bgcolor: tab.id === activeTabId ? 'action.selected' : 'transparent',
              '&:hover': { bgcolor: 'action.hover' },
              borderRight: 1, borderRightColor: 'divider',
              minWidth: 'fit-content', maxWidth: 200,
              transition: 'background-color 0.15s',
            }}
            onClick={() => switchTab(tab.id)}
          >
            {tab.dirty && (
              <DotIcon sx={{ fontSize: 8, color: 'warning.main', mr: 0.3 }} />
            )}
            {renameTabId === tab.id ? (
              <TextField
                size="small" variant="standard" autoFocus
                value={renameValue}
                onChange={e => setRenameValue(e.target.value)}
                onBlur={() => { renameTab(tab.id, renameValue); setRenameTabId(null); }}
                onKeyDown={e => {
                  if (e.key === 'Enter') { renameTab(tab.id, renameValue); setRenameTabId(null); }
                  if (e.key === 'Escape') setRenameTabId(null);
                }}
                inputProps={{ style: { fontSize: 12, padding: '0 4px', width: 100 } }}
                sx={{ '& .MuiInput-underline:before': { borderBottom: 'none' } }}
              />
            ) : (
              <Typography
                variant="caption" noWrap
                sx={{
                  fontSize: 12, fontWeight: tab.id === activeTabId ? 600 : 400,
                  color: tab.id === activeTabId ? 'text.primary' : 'text.secondary',
                  maxWidth: 150,
                }}
                onDoubleClick={() => { setRenameTabId(tab.id); setRenameValue(tab.name); }}
              >
                {tab.name}
              </Typography>
            )}
            {tabs.length > 1 && (
              <IconButton
                size="small"
                onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                sx={{ p: 0.15, ml: 0.3, opacity: 0.5, '&:hover': { opacity: 1 } }}
              >
                <CloseIcon sx={{ fontSize: 13 }} />
              </IconButton>
            )}
          </Box>
        ))}

        {/* Add tab button */}
        <Tooltip title={tabs.length >= MAX_TABS ? `Max ${MAX_TABS} tabs` : 'New query tab'}>
          <span>
            <IconButton size="small" onClick={createTab} disabled={tabs.length >= MAX_TABS}
              sx={{ mx: 0.5, p: 0.3 }}>
              <AddIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </span>
        </Tooltip>
      </Box>

      {/* ── Context Menu ── */}
      <Menu
        open={!!contextMenu}
        onClose={() => setContextMenu(null)}
        anchorEl={contextMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => {
          if (contextMenu) { setRenameTabId(contextMenu.tabId); setRenameValue(tabs.find(t => t.id === contextMenu.tabId)?.name || ''); }
          setContextMenu(null);
        }}>
          <EditIcon sx={{ fontSize: 14, mr: 1 }} /> Rename
        </MenuItem>
        <MenuItem dense onClick={() => { createTab(); setContextMenu(null); }}>
          <AddIcon sx={{ fontSize: 14, mr: 1 }} /> New Tab
        </MenuItem>
        {tabs.length > 1 && (
          <MenuItem dense onClick={() => { if (contextMenu) closeTab(contextMenu.tabId); setContextMenu(null); }}>
            <CloseIcon sx={{ fontSize: 14, mr: 1 }} /> Close
          </MenuItem>
        )}
      </Menu>

      {/* ── All Tab Contents (kept mounted, stacked via absolute positioning) ── */}
      {/* visibility: hidden (not display: none) keeps full dimensions so             @tanstack/react-virtual can measure rows correctly in hidden tabs */}
      <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {tabs.map(tab => {
          const active = tab.id === activeTabId;
          return (
            <Box
              key={tab.id}
              sx={{
                position: 'absolute',
                top: 0, left: 0, right: 0, bottom: 0,
                visibility: active ? 'visible' : 'hidden',
                zIndex: active ? 1 : 0,
              }}
            >
              <CompleteQueryBuilder
                tabId={tab.id}
                isActive={active}
                initialSnapshot={tab.snapshot || snapshotRef.current[tab.id]}
                onSnapshotChange={(snapshot) => handleSnapshotChange(tab.id, snapshot)}
                onDirtyChange={(dirty) => handleDirtyChange(tab.id, dirty)}
                onNameChange={(name) => handleNameChange(tab.id, name)}
              />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default QueryTabManager;
