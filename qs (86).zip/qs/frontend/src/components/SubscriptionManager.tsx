/**
 * SubscriptionManager — Phase 60 (Delivery & Alerts)
 *
 * Dialog for creating and managing report delivery subscriptions.
 * Shown from ReportPage and BusinessReportViewer via a "Subscribe" button.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, TextField, MenuItem, Box, Typography, Chip,
  IconButton, Tooltip, Divider, Alert, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Switch, FormControlLabel, Tabs, Tab,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Send as SendIcon,
  Pause as PauseIcon, PlayArrow as PlayIcon, History as HistoryIcon,
  Close as CloseIcon, Email as EmailIcon,
} from '@mui/icons-material';
import api from '../services/api';

// ── Constants ────────────────────────────────────────────────────────────────

const FORMATS = [
  { value: 'pdf', label: 'PDF' },
  { value: 'excel', label: 'Excel (XLSX)' },
  { value: 'csv', label: 'CSV' },
];

const FREQUENCY_PRESETS = [
  { label: 'Daily at 8 AM',      cron: '0 8 * * *' },
  { label: 'Weekly (Mon 8 AM)',   cron: '0 8 * * 1' },
  { label: 'Monthly (1st, 8 AM)', cron: '0 8 1 * *' },
  { label: 'Hourly',              cron: '0 * * * *' },
  { label: 'Every 6 hours',       cron: '0 */6 * * *' },
  { label: 'Custom...',           cron: '' },
];

const TIMEZONES = [
  'UTC', 'US/Eastern', 'US/Central', 'US/Mountain', 'US/Pacific',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin',
  'Asia/Tokyo', 'Asia/Shanghai', 'Asia/Kolkata',
  'Australia/Sydney',
];

// ── Types ────────────────────────────────────────────────────────────────────

interface Subscription {
  id: number;
  name: string;
  report_id: number;
  report_type: string;
  recipient_emails: string[];
  frequency: string;
  timezone: string;
  output_format: string;
  is_active: boolean;
  next_send_at: string | null;
  last_sent_at: string | null;
  created_at: string;
}

interface DeliveryRecord {
  id: number;
  recipient_email: string;
  status: string;
  sent_at: string | null;
  attempted_at: string;
  error_message: string | null;
  file_size_bytes: number | null;
}

interface Props {
  open: boolean;
  onClose: () => void;
  reportId: number;
  reportType: string;           // 'business_report' | 'report' | 'query'
  reportName: string;
}

// ── Component ────────────────────────────────────────────────────────────────

const SubscriptionManager: React.FC<Props> = ({ open, onClose, reportId, reportType, reportName }) => {
  const [tab, setTab] = useState(0);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Create form state
  const [name, setName] = useState('');
  const [emails, setEmails] = useState<string[]>([]);
  const [emailInput, setEmailInput] = useState('');
  const [frequency, setFrequency] = useState('0 8 * * *');
  const [customCron, setCustomCron] = useState('');
  const [tz, setTz] = useState('UTC');
  const [format, setFormat] = useState('pdf');

  // History
  const [historySubId, setHistorySubId] = useState<number | null>(null);
  const [history, setHistory] = useState<DeliveryRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const loadSubscriptions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.listSubscriptions(reportId, reportType);
      setSubscriptions(data || []);
    } catch (e: any) {
      setError(e.message || 'Failed to load subscriptions');
    } finally {
      setLoading(false);
    }
  }, [reportId, reportType]);

  useEffect(() => {
    if (open) {
      loadSubscriptions();
      setName(`${reportName} — Daily`);
    }
  }, [open, loadSubscriptions, reportName]);

  const handleAddEmail = () => {
    const trimmed = emailInput.trim();
    if (trimmed && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed) && !emails.includes(trimmed)) {
      setEmails(prev => [...prev, trimmed]);
      setEmailInput('');
    }
  };

  const handleCreate = async () => {
    setError(null);
    const cronExpr = frequency || customCron;
    if (!name.trim()) { setError('Name is required'); return; }
    if (emails.length === 0) { setError('At least one recipient email is required'); return; }
    if (!cronExpr) { setError('Frequency is required'); return; }

    try {
      await api.createSubscription({
        report_id: reportId,
        report_type: reportType,
        name: name.trim(),
        recipient_emails: emails,
        frequency: cronExpr,
        timezone: tz,
        output_format: format,
      });
      setSuccess('Subscription created');
      setEmails([]);
      setEmailInput('');
      setTimeout(() => setSuccess(null), 3000);
      loadSubscriptions();
      setTab(1);
    } catch (e: any) {
      setError(e.message || 'Failed to create subscription');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.deleteSubscription(id);
      loadSubscriptions();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleToggle = async (sub: Subscription) => {
    try {
      if (sub.is_active) {
        await api.pauseSubscription(sub.id);
      } else {
        await api.resumeSubscription(sub.id);
      }
      loadSubscriptions();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleTestSend = async (id: number) => {
    try {
      setSuccess('Sending test...');
      const result = await api.testSendSubscription(id);
      setSuccess(`Test sent: ${result.sent} delivered, ${result.failed} failed`);
      setTimeout(() => setSuccess(null), 5000);
    } catch (e: any) {
      setError(e.message || 'Test send failed');
    }
  };

  const handleViewHistory = async (subId: number) => {
    setHistorySubId(subId);
    setHistoryLoading(true);
    try {
      const data = await api.getSubscriptionHistory(subId);
      setHistory(data || []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setHistoryLoading(false);
    }
  };

  const statusColor = (s: string) => {
    if (s === 'sent') return 'success';
    if (s === 'failed') return 'error';
    if (s === 'pending') return 'warning';
    return 'default';
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, pr: 6 }}>
        <EmailIcon sx={{ color: 'primary.main' }} />
        Report Subscriptions — {reportName}
        <IconButton onClick={onClose} sx={{ position: 'absolute', right: 8, top: 8 }}><CloseIcon /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        {error && <Alert severity="error" sx={{ mb: 1 }} onClose={() => setError(null)}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 1 }}>{success}</Alert>}

        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
          <Tab label="Create" />
          <Tab label={`Active (${subscriptions.length})`} />
          {historySubId && <Tab label="History" />}
        </Tabs>

        {/* ── Tab 0: Create ─────────────────────────────── */}
        {tab === 0 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField label="Subscription Name" size="small" fullWidth
              value={name} onChange={e => setName(e.target.value)} />

            {/* Recipients */}
            <Box>
              <Typography variant="caption" fontWeight={600} color="text.secondary">Recipients</Typography>
              <Box sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
                <TextField size="small" placeholder="email@example.com" fullWidth
                  value={emailInput} onChange={e => setEmailInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleAddEmail(); } }} />
                <Button variant="outlined" size="small" onClick={handleAddEmail} sx={{ minWidth: 40 }}>
                  <AddIcon sx={{ fontSize: 18 }} />
                </Button>
              </Box>
              <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, flexWrap: 'wrap' }}>
                {emails.map((e, i) => (
                  <Chip key={i} label={e} size="small" onDelete={() => setEmails(prev => prev.filter((_, idx) => idx !== i))} />
                ))}
              </Box>
            </Box>

            {/* Frequency */}
            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField select label="Frequency" size="small" sx={{ flex: 1 }}
                value={frequency}
                onChange={e => setFrequency(e.target.value)}>
                {FREQUENCY_PRESETS.map(fp => (
                  <MenuItem key={fp.cron} value={fp.cron}>{fp.label}</MenuItem>
                ))}
              </TextField>
              {!frequency && (
                <TextField label="Cron Expression" size="small" sx={{ flex: 1 }}
                  placeholder="0 8 * * *"
                  value={customCron} onChange={e => setCustomCron(e.target.value)} />
              )}
            </Box>

            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField select label="Timezone" size="small" sx={{ flex: 1 }}
                value={tz} onChange={e => setTz(e.target.value)}>
                {TIMEZONES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
              </TextField>
              <TextField select label="Output Format" size="small" sx={{ flex: 1 }}
                value={format} onChange={e => setFormat(e.target.value)}>
                {FORMATS.map(f => <MenuItem key={f.value} value={f.value}>{f.label}</MenuItem>)}
              </TextField>
            </Box>

            <Button variant="contained" onClick={handleCreate}
              disabled={!name.trim() || emails.length === 0}
              startIcon={<AddIcon />}>
              Create Subscription
            </Button>
          </Box>
        )}

        {/* ── Tab 1: Active ─────────────────────────────── */}
        {tab === 1 && (
          <Box>
            {loading ? (
              <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
            ) : subscriptions.length === 0 ? (
              <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                No subscriptions yet. Create one to get started.
              </Typography>
            ) : (
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Recipients</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Format</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Next Send</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Active</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {subscriptions.map(sub => (
                      <TableRow key={sub.id} hover>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>{sub.name}</Typography>
                          <Typography variant="caption" color="text.secondary">{sub.frequency}</Typography>
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 0.3, flexWrap: 'wrap' }}>
                            {sub.recipient_emails.slice(0, 2).map((e, i) => (
                              <Chip key={i} label={e} size="small" sx={{ fontSize: 10 }} />
                            ))}
                            {sub.recipient_emails.length > 2 && (
                              <Chip label={`+${sub.recipient_emails.length - 2}`} size="small" sx={{ fontSize: 10 }} />
                            )}
                          </Box>
                        </TableCell>
                        <TableCell>{sub.output_format.toUpperCase()}</TableCell>
                        <TableCell>
                          {sub.next_send_at
                            ? new Date(sub.next_send_at).toLocaleString()
                            : '—'}
                        </TableCell>
                        <TableCell>
                          <Switch size="small" checked={sub.is_active}
                            onChange={() => handleToggle(sub)} />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 0.5 }}>
                            <Tooltip title="Test Send">
                              <IconButton size="small" onClick={() => handleTestSend(sub.id)}>
                                <SendIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="History">
                              <IconButton size="small" onClick={() => { handleViewHistory(sub.id); setTab(2); }}>
                                <HistoryIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Delete">
                              <IconButton size="small" color="error" onClick={() => handleDelete(sub.id)}>
                                <DeleteIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </Tooltip>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Box>
        )}

        {/* ── Tab 2: History ─────────────────────────────── */}
        {tab === 2 && historySubId && (
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              Delivery History — Subscription #{historySubId}
            </Typography>
            {historyLoading ? (
              <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
            ) : history.length === 0 ? (
              <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                No delivery records yet.
              </Typography>
            ) : (
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 700 }}>Recipient</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Sent At</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Size</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Error</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {history.map(rec => (
                      <TableRow key={rec.id} hover>
                        <TableCell>{rec.recipient_email}</TableCell>
                        <TableCell>
                          <Chip label={rec.status} size="small"
                            color={statusColor(rec.status) as any}
                            sx={{ fontSize: 10, height: 20 }} />
                        </TableCell>
                        <TableCell>
                          {rec.sent_at ? new Date(rec.sent_at).toLocaleString() : rec.attempted_at ? new Date(rec.attempted_at).toLocaleString() : '—'}
                        </TableCell>
                        <TableCell>
                          {rec.file_size_bytes
                            ? `${(rec.file_size_bytes / 1024).toFixed(1)} KB`
                            : '—'}
                        </TableCell>
                        <TableCell>
                          {rec.error_message && (
                            <Typography variant="caption" color="error">{rec.error_message}</Typography>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default SubscriptionManager;
