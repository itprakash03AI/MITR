/**
 * Dataset Manager — Semantic Layer Admin (Phase 53)
 *
 * Admin page for defining Business Datasets (BO Universe equivalent).
 * Manages: datasets, classes, columns, relationships, drill hierarchies,
 * pre-defined conditions, and aggregation awareness rules.
 *
 * Route: /datasets
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Button, CircularProgress, IconButton,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Dialog, DialogTitle, DialogContent, DialogActions,
  Chip, Alert, Divider, Tooltip, Stack, Switch, FormControlLabel,
  Select, MenuItem, FormControl, InputLabel, Tabs, Tab,
  Accordion, AccordionSummary, AccordionDetails,
  List, ListItem, ListItemText, ListItemSecondaryAction,
  LinearProgress, Checkbox, ListItemIcon,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Refresh as RefreshIcon,
  Publish as PublishIcon,
  AutoFixHigh as AutoDetectIcon,
  ExpandMore as ExpandMoreIcon,
  Settings as SettingsIcon,
  Save as SaveIcon,
  Schema as SchemaIcon,
  Category as ClassIcon,
  ViewColumn as ColumnIcon,
  Link as RelIcon,
  AccountTree as HierarchyIcon,
  FilterAlt as ConditionIcon,
  Speed as AggIcon,
  PlayArrow as QueryIcon,
  Cached as CachedIcon,
  Build as BuildNowIcon,
  Storage as SourceIcon,
  Search as BrowseIcon,
  RemoveCircleOutline as RemoveRowIcon,
} from '@mui/icons-material';
import { alpha } from '@mui/material/styles';
import api from '../services/api';
import { useNotifications } from '../context/NotificationContext';
import { useNavigate } from 'react-router-dom';

/* ── Notification helper ───────────────────────────────────────────────── */
const notify = (addNotification: Function, msg: string, type: 'success' | 'error' | 'info' = 'info') =>
  addNotification({ type, title: type === 'error' ? 'Error' : type === 'success' ? 'Success' : 'Info', message: msg });

/* ── Constants ─────────────────────────────────────────────────────────── */
const COLUMN_TYPES = ['dimension', 'measure', 'detail', 'kpi'] as const;
const DATA_TYPES   = ['string', 'number', 'date', 'boolean'] as const;
const JOIN_TYPES   = ['inner', 'left', 'right', 'full'] as const;
const CARDINALITIES = ['one_to_one', 'one_to_many', 'many_to_one', 'many_to_many'] as const;
const AGGREGATIONS = ['', 'sum', 'avg', 'count', 'min', 'max', 'count_distinct'] as const;
const GRAIN_LABELS = ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'custom'] as const;
const SCHEDULE_TYPES = ['none', 'cron', 'interval'] as const;

/* ── Types ─────────────────────────────────────────────────────────────── */
interface Dataset {
  id: number; name: string; description: string; subject: string;
  owner: string; connection_ids: number[]; source_tables: any[];
  base_query: string; is_published: boolean;
  created_at: string; updated_at: string;
  classes?: any[]; columns?: any[]; relationships?: any[];
  hierarchies?: any[]; conditions?: any[]; agg_awareness?: any[];
}

/* ── Component ─────────────────────────────────────────────────────────── */
export default function DatasetManagerPage() {
  const { addNotification } = useNotifications();
  const navigate = useNavigate();
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [detail, setDetail] = useState<Dataset | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailTab, setDetailTab] = useState(0);
  const [createOpen, setCreateOpen] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);
  const [config, setConfig] = useState<Record<string, any>>({});

  // ── Connections list (shared across create + source tab) ────────────
  const [connections, setConnections] = useState<any[]>([]);
  const [connectionsLoaded, setConnectionsLoaded] = useState(false);

  // ── Create form state ───────────────────────────────────────────────
  const [formName, setFormName] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formConnectionId, setFormConnectionId] = useState<number | ''>('');
  const [formSourceTable, setFormSourceTable] = useState('');
  const [formBaseQuery, setFormBaseQuery] = useState('');

  // ── Source tab state ──────────────────────────────────────────────
  const [sourceTables, setSourceTables] = useState<any[]>([]);
  const [sourceBaseQuery, setSourceBaseQuery] = useState('');
  const [sourceSaving, setSourceSaving] = useState(false);
  const [browseConnId, setBrowseConnId] = useState<number | null>(null);
  const [browseFiles, setBrowseFiles] = useState<any[]>([]);
  const [browseLoading, setBrowseLoading] = useState(false);
  const [browseOpen, setBrowseOpen] = useState(false);
  const [browseTarget, setBrowseTarget] = useState<'create' | 'source'>('source');
  const [browseTargetIndex, setBrowseTargetIndex] = useState(-1);

  // ── Column edit dialog ──────────────────────────────────────────────
  const [colDialogOpen, setColDialogOpen] = useState(false);
  const [editingCol, setEditingCol] = useState<any>(null);

  // ── Agg Cache state ───────────────────────────────────────────────
  const [aggCacheEntries, setAggCacheEntries] = useState<any[]>([]);
  const [aggCacheLoading, setAggCacheLoading] = useState(false);

  // ── Agg Cache Create/Edit dialog ─────────────────────────────────
  const [cacheDialogOpen, setCacheDialogOpen] = useState(false);
  const [cacheEditId, setCacheEditId] = useState<number | null>(null);
  const [cacheName, setCacheName] = useState('');
  const [cacheDesc, setCacheDesc] = useState('');
  const [cacheDimIds, setCacheDimIds] = useState<number[]>([]);
  const [cacheMeasureIds, setCacheMeasureIds] = useState<number[]>([]);
  const [cacheGrain, setCacheGrain] = useState<string>('daily');
  const [cacheConditionIds, setCacheConditionIds] = useState<number[]>([]);
  const [cacheScheduleType, setCacheScheduleType] = useState<string>('none');
  const [cacheCron, setCacheCron] = useState('0 2 * * *');
  const [cacheIntervalHours, setCacheIntervalHours] = useState(6);
  const [cacheIncremental, setCacheIncremental] = useState(false);
  const [cacheIncrementalCol, setCacheIncrementalCol] = useState('');
  const [cacheSaving, setCacheSaving] = useState(false);

  /* ── Data fetching ──────────────────────────────────────────────────── */
  const loadDatasets = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listDatasets();
      setDatasets(Array.isArray(data) ? data : []);
    } catch (e: any) {
      notify(addNotification, 'Failed to load datasets: ' + e.message, 'error');
    } finally { setLoading(false); }
  }, [addNotification]);

  const loadDetail = useCallback(async (id: number) => {
    setDetailLoading(true);
    try {
      const data = await api.getDataset(id);
      setDetail(data);
      setSelectedId(id);
    } catch (e: any) {
      notify(addNotification, 'Failed to load dataset: ' + e.message, 'error');
    } finally { setDetailLoading(false); }
  }, [addNotification]);

  const loadConnections = useCallback(async () => {
    if (connectionsLoaded) return;
    try {
      const data = await api.listConnections(true);
      setConnections(Array.isArray(data) ? data : []);
      setConnectionsLoaded(true);
    } catch { /* ignore */ }
  }, [connectionsLoaded]);

  useEffect(() => { loadDatasets(); }, [loadDatasets]);

  // Load connections on first need (create dialog or source tab)
  useEffect(() => {
    if (createOpen || (detailTab === 0 && detail)) loadConnections();
  }, [createOpen, detailTab, detail, loadConnections]);

  // Sync source tab state when detail loads or source tab selected
  useEffect(() => {
    if (detailTab === 0 && detail) {
      setSourceTables(detail.source_tables || []);
      setSourceBaseQuery(detail.base_query || '');
    }
  }, [detailTab, detail]);

  // Load agg cache entries when the Agg Cache tab is selected
  useEffect(() => {
    if (detailTab === 7 && detail?.id) {
      setAggCacheLoading(true);
      api.listAggCacheEntries(detail.id)
        .then((resp: any) => setAggCacheEntries(resp.entries || []))
        .catch(() => {})
        .finally(() => setAggCacheLoading(false));
    }
  }, [detailTab, detail?.id]);

  /* ── Agg Cache Dialog helpers ────────────────────────────────────────── */
  const openCacheCreateDialog = () => {
    setCacheEditId(null);
    setCacheName('');
    setCacheDesc('');
    setCacheDimIds([]);
    setCacheMeasureIds([]);
    setCacheGrain('daily');
    setCacheConditionIds([]);
    setCacheScheduleType('none');
    setCacheCron('0 2 * * *');
    setCacheIntervalHours(6);
    setCacheIncremental(false);
    setCacheIncrementalCol('');
    setCacheDialogOpen(true);
  };

  const openCacheEditDialog = (entry: any) => {
    setCacheEditId(entry.id);
    setCacheName(entry.name || '');
    setCacheDesc(entry.description || '');
    setCacheDimIds(entry.dimension_col_ids || []);
    setCacheMeasureIds(entry.measure_col_ids || []);
    setCacheGrain(entry.grain_label || 'custom');
    setCacheConditionIds(entry.condition_ids || []);
    const sched = entry.schedule_config;
    if (sched?.type === 'cron') {
      setCacheScheduleType('cron');
      setCacheCron(sched.cron_expr || '0 2 * * *');
    } else if (sched?.type === 'interval') {
      setCacheScheduleType('interval');
      setCacheIntervalHours(sched.hours || 6);
    } else {
      setCacheScheduleType('none');
    }
    setCacheIncremental(entry.incremental_enabled || false);
    setCacheIncrementalCol(entry.incremental_column || '');
    setCacheDialogOpen(true);
  };

  const handleCacheSave = async () => {
    if (!detail?.id || !cacheName.trim() || cacheDimIds.length === 0 || cacheMeasureIds.length === 0) return;
    setCacheSaving(true);
    try {
      const scheduleConfig = cacheScheduleType === 'cron'
        ? { type: 'cron', cron_expr: cacheCron }
        : cacheScheduleType === 'interval'
          ? { type: 'interval', hours: cacheIntervalHours }
          : null;
      const payload: any = {
        name: cacheName.trim(),
        description: cacheDesc.trim(),
        dimension_col_ids: cacheDimIds,
        measure_col_ids: cacheMeasureIds,
        grain_label: cacheGrain,
        condition_ids: cacheConditionIds,
        schedule_config: scheduleConfig,
        incremental_enabled: cacheIncremental,
        incremental_column: cacheIncremental ? cacheIncrementalCol : null,
        is_enabled: true,
      };
      if (cacheEditId) {
        await api.updateAggCacheEntry(cacheEditId, payload);
        notify(addNotification, `Cache entry "${cacheName}" updated`, 'success');
      } else {
        await api.createAggCacheEntry(detail.id, payload);
        notify(addNotification, `Cache entry "${cacheName}" created`, 'success');
      }
      setCacheDialogOpen(false);
      // Refresh list
      const resp = await api.listAggCacheEntries(detail.id);
      setAggCacheEntries(resp.entries || []);
    } catch (e: any) {
      notify(addNotification, `Save failed: ${e.message}`, 'error');
    } finally { setCacheSaving(false); }
  };

  // Helpers: dimension & measure columns from current dataset
  const dimensionCols = (detail?.columns || []).filter((c: any) => c.column_type === 'dimension');
  const measureCols = (detail?.columns || []).filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');
  const dateCols = (detail?.columns || []).filter((c: any) => c.data_type === 'date');
  const conditionsList = detail?.conditions || [];

  /* ── Source helpers ──────────────────────────────────────────────────── */
  const browseForTable = async (connId: number, target: 'create' | 'source', idx = -1) => {
    setBrowseConnId(connId);
    setBrowseTarget(target);
    setBrowseTargetIndex(idx);
    setBrowseLoading(true);
    setBrowseOpen(true);
    try {
      const files = await api.listConnectionFiles(String(connId));
      setBrowseFiles(Array.isArray(files) ? files : []);
    } catch { setBrowseFiles([]); }
    finally { setBrowseLoading(false); }
  };

  const selectBrowseFile = (filePath: string) => {
    if (browseTarget === 'create') {
      setFormSourceTable(filePath);
    } else {
      // Update source table at index
      if (browseTargetIndex >= 0) {
        setSourceTables(prev => prev.map((st, i) =>
          i === browseTargetIndex ? { ...st, table: filePath } : st
        ));
      }
    }
    setBrowseOpen(false);
  };

  const addSourceTable = () => {
    setSourceTables(prev => [...prev, { connection_id: '', table: '', alias: '' }]);
  };

  const removeSourceTable = (idx: number) => {
    setSourceTables(prev => prev.filter((_, i) => i !== idx));
  };

  const updateSourceTable = (idx: number, field: string, value: any) => {
    setSourceTables(prev => prev.map((st, i) =>
      i === idx ? { ...st, [field]: value } : st
    ));
  };

  const saveSourceConfig = async () => {
    if (!detail?.id) return;
    setSourceSaving(true);
    try {
      const connIds = [...new Set(sourceTables.filter(st => st.connection_id).map(st => Number(st.connection_id)))];
      await api.updateDataset(detail.id, {
        connection_ids: connIds,
        source_tables: sourceTables.filter(st => st.connection_id && st.table),
        base_query: sourceBaseQuery.trim(),
      });
      notify(addNotification, 'Source configuration saved', 'success');
      loadDetail(detail.id);
    } catch (e: any) {
      notify(addNotification, `Save failed: ${e.message}`, 'error');
    } finally { setSourceSaving(false); }
  };

  const connName = (id: number) => connections.find(c => c.id === id)?.name || `#${id}`;

  /* ── Dataset CRUD ───────────────────────────────────────────────────── */
  const handleCreate = async () => {
    if (!formName.trim() || !formSubject.trim()) return;
    try {
      const initialSourceTables = (formConnectionId && formSourceTable.trim())
        ? [{ connection_id: Number(formConnectionId), table: formSourceTable.trim(), alias: '' }]
        : [];
      const initialConnIds = formConnectionId ? [Number(formConnectionId)] : [];
      const result = await api.createDataset({
        name: formName.trim(), subject: formSubject.trim(),
        description: formDesc.trim(),
        connection_ids: initialConnIds,
        source_tables: initialSourceTables,
        base_query: formBaseQuery.trim(),
      });
      notify(addNotification, `Dataset "${result.name}" created`, 'success');
      setCreateOpen(false);
      setFormName(''); setFormSubject(''); setFormDesc('');
      setFormConnectionId(''); setFormSourceTable(''); setFormBaseQuery('');
      loadDatasets();
      loadDetail(result.id);
    } catch (e: any) {
      notify(addNotification, 'Create failed: ' + (e.message || e), 'error');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this dataset and all its columns/relationships?')) return;
    try {
      await api.deleteDataset(id);
      notify(addNotification, 'Dataset deleted', 'success');
      if (selectedId === id) { setSelectedId(null); setDetail(null); }
      loadDatasets();
    } catch (e: any) { notify(addNotification, 'Delete failed: ' + e.message, 'error'); }
  };

  const handleTogglePublish = async (id: number) => {
    try {
      const result = await api.toggleDatasetPublish(id);
      notify(addNotification, result.is_published ? 'Dataset published' : 'Dataset unpublished', 'success');
      loadDatasets();
      if (selectedId === id) loadDetail(id);
    } catch (e: any) { notify(addNotification, 'Publish toggle failed: ' + e.message, 'error'); }
  };

  const handleAutoDetect = async (id: number) => {
    try {
      const result = await api.autoDetectColumns(id);
      notify(addNotification, `Auto-detected ${result.created} columns`, 'success');
      loadDetail(id);
    } catch (e: any) { notify(addNotification, 'Auto-detect failed: ' + e.message, 'error'); }
  };

  /* ── Column CRUD ────────────────────────────────────────────────────── */
  const openColumnDialog = (col?: any) => {
    setEditingCol(col || {
      physical_name: '', friendly_name: '', column_type: 'dimension',
      data_type: 'string', aggregation: '', format_pattern: '',
      description: '', synonyms: [], role_whitelist: [], is_hidden: false,
    });
    setColDialogOpen(true);
  };

  const saveColumn = async () => {
    if (!editingCol || !selectedId) return;
    try {
      if (editingCol.id) {
        await api.updateDatasetColumn(editingCol.id, editingCol);
      } else {
        await api.createDatasetColumn(selectedId, editingCol);
      }
      notify(addNotification, 'Column saved', 'success');
      setColDialogOpen(false);
      loadDetail(selectedId);
    } catch (e: any) { notify(addNotification, 'Save failed: ' + e.message, 'error'); }
  };

  const deleteColumn = async (colId: number) => {
    if (!confirm('Delete this column?')) return;
    try {
      await api.deleteDatasetColumn(colId);
      notify(addNotification, 'Column deleted', 'success');
      if (selectedId) loadDetail(selectedId);
    } catch (e: any) { notify(addNotification, 'Delete failed: ' + e.message, 'error'); }
  };

  /* ── Config ─────────────────────────────────────────────────────────── */
  const loadConfig = async () => {
    try {
      const c = await api.getSemanticLayerConfig();
      setConfig(c);
      setConfigOpen(true);
    } catch (e: any) { notify(addNotification, 'Failed to load config', 'error'); }
  };

  const saveConfig = async () => {
    try {
      await api.setSemanticLayerConfig(config);
      notify(addNotification, 'Config saved', 'success');
      setConfigOpen(false);
    } catch (e: any) { notify(addNotification, 'Save failed: ' + e.message, 'error'); }
  };

  /* ── Render ─────────────────────────────────────────────────────────── */
  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <SchemaIcon sx={{ fontSize: 32, color: 'primary.main' }} />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight={700}>Semantic Layer</Typography>
          <Typography variant="body2" color="text.secondary">
            Define business datasets with friendly names, classifications, and relationships
          </Typography>
        </Box>
        <Button startIcon={<SettingsIcon />} onClick={loadConfig} variant="outlined" size="small">
          Config
        </Button>
        <Button startIcon={<AddIcon />} onClick={() => setCreateOpen(true)}
                variant="contained" size="small">
          New Dataset
        </Button>
      </Box>

      {/* Dataset List */}
      <Paper sx={{ mb: 3 }}>
        {loading ? (
          <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
        ) : datasets.length === 0 ? (
          <Box sx={{ p: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">No datasets yet. Create your first business dataset.</Typography>
          </Box>
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Subject</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Owner</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Updated</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {datasets.map(ds => (
                  <TableRow key={ds.id} hover
                    selected={selectedId === ds.id}
                    onClick={() => loadDetail(ds.id)}
                    sx={{ cursor: 'pointer' }}>
                    <TableCell>
                      <Typography fontWeight={600}>{ds.name}</Typography>
                      {ds.description && (
                        <Typography variant="caption" color="text.secondary">{ds.description}</Typography>
                      )}
                    </TableCell>
                    <TableCell><Chip label={ds.subject} size="small" /></TableCell>
                    <TableCell>{ds.owner}</TableCell>
                    <TableCell>
                      <Chip label={ds.is_published ? 'Published' : 'Draft'}
                            color={ds.is_published ? 'success' : 'default'} size="small" />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {ds.updated_at ? new Date(ds.updated_at).toLocaleDateString() : '-'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Query this dataset">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); navigate(`/datasets/${ds.id}/query`); }}>
                          <QueryIcon color="primary" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={ds.is_published ? 'Unpublish' : 'Publish'}>
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); handleTogglePublish(ds.id); }}>
                          <PublishIcon color={ds.is_published ? 'success' : 'disabled'} />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); handleDelete(ds.id); }}>
                          <DeleteIcon color="error" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {/* Detail Panel */}
      {selectedId && (
        <Paper sx={{ p: 0 }}>
          {detailLoading ? (
            <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
          ) : detail ? (
            <>
              <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 2,
                         bgcolor: (t) => alpha(t.palette.primary.main, 0.04) }}>
                <Typography variant="h6" fontWeight={700} sx={{ flex: 1 }}>
                  {detail.name}
                  <Chip label={detail.subject} size="small" sx={{ ml: 1 }} />
                </Typography>
                <Button startIcon={<AutoDetectIcon />} size="small" variant="outlined"
                        onClick={() => handleAutoDetect(detail.id)}>
                  Auto-Detect Columns
                </Button>
                <Button startIcon={<RefreshIcon />} size="small"
                        onClick={() => loadDetail(detail.id)}>
                  Refresh
                </Button>
              </Box>

              <Tabs value={detailTab} onChange={(_, v) => setDetailTab(v)}
                    variant="scrollable" scrollButtons="auto"
                    sx={{ borderBottom: 1, borderColor: 'divider', px: 2 }}>
                <Tab icon={<SourceIcon />} iconPosition="start"
                     label={`Source (${(detail.source_tables || []).length})`} />
                <Tab icon={<ColumnIcon />} iconPosition="start" label={`Columns (${(detail.columns || []).length})`} />
                <Tab icon={<ClassIcon />} iconPosition="start" label={`Classes (${(detail.classes || []).length})`} />
                <Tab icon={<RelIcon />} iconPosition="start" label={`Relationships (${(detail.relationships || []).length})`} />
                <Tab icon={<HierarchyIcon />} iconPosition="start" label={`Hierarchies (${(detail.hierarchies || []).length})`} />
                <Tab icon={<ConditionIcon />} iconPosition="start" label={`Conditions (${(detail.conditions || []).length})`} />
                <Tab icon={<AggIcon />} iconPosition="start" label={`Agg Awareness (${(detail.agg_awareness || []).length})`} />
                <Tab icon={<CachedIcon />} iconPosition="start" label="Agg Cache" />
              </Tabs>

              {/* Tab: Source Configuration */}
              {detailTab === 0 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Connect this dataset to physical data sources — S3 buckets, Snowflake databases, or other connections.
                    The federation engine uses these to build and execute queries.
                  </Alert>

                  {/* Source tables list */}
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Source Tables</Typography>
                  {sourceTables.map((st: any, idx: number) => (
                    <Paper key={idx} variant="outlined" sx={{ p: 1.5, mb: 1 }}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <FormControl size="small" sx={{ minWidth: 200 }}>
                          <InputLabel>Connection</InputLabel>
                          <Select value={st.connection_id || ''} label="Connection"
                                  onChange={e => updateSourceTable(idx, 'connection_id', e.target.value)}>
                            {connections.map(c => (
                              <MenuItem key={c.id} value={c.id}>
                                {c.name} ({c.connection_type})
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                        <TextField size="small" label="Table / Path" value={st.table || ''}
                                   onChange={e => updateSourceTable(idx, 'table', e.target.value)}
                                   sx={{ flex: 1 }}
                                   placeholder="s3://bucket/path/file.parquet or schema.table" />
                        <Tooltip title="Browse files">
                          <span>
                            <IconButton size="small" disabled={!st.connection_id}
                                        onClick={() => browseForTable(Number(st.connection_id), 'source', idx)}>
                              <BrowseIcon fontSize="small" />
                            </IconButton>
                          </span>
                        </Tooltip>
                        <TextField size="small" label="Alias" value={st.alias || ''}
                                   onChange={e => updateSourceTable(idx, 'alias', e.target.value)}
                                   sx={{ width: 120 }}
                                   placeholder="e.g. sales" />
                        <IconButton size="small" color="error" onClick={() => removeSourceTable(idx)}>
                          <RemoveRowIcon fontSize="small" />
                        </IconButton>
                      </Stack>
                    </Paper>
                  ))}

                  <Button startIcon={<AddIcon />} size="small" variant="outlined"
                          onClick={addSourceTable} sx={{ mb: 2 }}>
                    Add Source Table
                  </Button>

                  {/* Base Query override */}
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Base Query (optional — overrides source table auto-resolution)
                  </Typography>
                  <TextField fullWidth multiline rows={4} value={sourceBaseQuery}
                             onChange={e => setSourceBaseQuery(e.target.value)}
                             placeholder="SELECT * FROM sales_fact WHERE year >= 2024"
                             InputProps={{ sx: { fontFamily: 'monospace', fontSize: '0.85rem' } }} />

                  {/* Connection summary */}
                  {sourceTables.length > 0 && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="caption" color="text.secondary">
                        Connections used: {[...new Set(sourceTables.filter(s => s.connection_id).map(s => connName(Number(s.connection_id))))].join(', ') || 'none'}
                      </Typography>
                    </Box>
                  )}

                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                    <Button variant="contained" startIcon={<SaveIcon />}
                            onClick={saveSourceConfig} disabled={sourceSaving}>
                      {sourceSaving ? <CircularProgress size={20} /> : 'Save Source Config'}
                    </Button>
                  </Box>
                </Box>
              )}

              {/* Tab: Columns */}
              {detailTab === 1 && (
                <Box sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 1 }}>
                    <Button startIcon={<AddIcon />} size="small" variant="outlined"
                            onClick={() => openColumnDialog()}>Add Column</Button>
                  </Box>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700 }}>Physical Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Friendly Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Data Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Aggregation</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Synonyms</TableCell>
                          <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(detail.columns || []).map((col: any) => (
                          <TableRow key={col.id} hover>
                            <TableCell>
                              <Typography variant="body2" fontFamily="monospace">{col.physical_name}</Typography>
                            </TableCell>
                            <TableCell>
                              <Typography fontWeight={500}>{col.friendly_name}</Typography>
                            </TableCell>
                            <TableCell>
                              <Chip label={col.column_type} size="small"
                                    color={col.column_type === 'measure' ? 'primary'
                                         : col.column_type === 'kpi' ? 'warning'
                                         : col.column_type === 'detail' ? 'info' : 'default'} />
                            </TableCell>
                            <TableCell>{col.data_type}</TableCell>
                            <TableCell>{col.aggregation || '-'}</TableCell>
                            <TableCell>
                              {(col.synonyms || []).slice(0, 3).map((s: string) => (
                                <Chip key={s} label={s} size="small" sx={{ mr: 0.5 }} variant="outlined" />
                              ))}
                            </TableCell>
                            <TableCell align="right">
                              <IconButton size="small" onClick={() => openColumnDialog(col)}>
                                <EditIcon fontSize="small" />
                              </IconButton>
                              <IconButton size="small" onClick={() => deleteColumn(col.id)}>
                                <DeleteIcon fontSize="small" color="error" />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                        {(detail.columns || []).length === 0 && (
                          <TableRow>
                            <TableCell colSpan={7} align="center" sx={{ py: 3 }}>
                              <Typography color="text.secondary">
                                No columns yet. Click "Auto-Detect Columns" or "Add Column".
                              </Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}

              {/* Tab: Classes */}
              {detailTab === 2 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Classes group columns logically (e.g. "Customer", "Time", "Product") — like BO Universe classes.
                  </Alert>
                  <List>
                    {(detail.classes || []).map((cls: any) => (
                      <ListItem key={cls.id} divider>
                        <ListItemText primary={cls.label || cls.name}
                                      secondary={`Name: ${cls.name} | Sort: ${cls.sort_order}`} />
                        <ListItemSecondaryAction>
                          <IconButton size="small"><EditIcon fontSize="small" /></IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                  {(detail.classes || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No classes defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Relationships */}
              {detailTab === 3 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Define how source tables join within this dataset. Used by the federation engine.
                  </Alert>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700 }}>Left Table</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Join Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Right Table</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Join Keys</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Cardinality</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(detail.relationships || []).map((rel: any) => (
                          <TableRow key={rel.id} hover>
                            <TableCell><Typography fontFamily="monospace" variant="body2">{rel.left_table}</Typography></TableCell>
                            <TableCell><Chip label={rel.join_type.toUpperCase()} size="small" /></TableCell>
                            <TableCell><Typography fontFamily="monospace" variant="body2">{rel.right_table}</Typography></TableCell>
                            <TableCell>
                              {(rel.join_keys || []).map((jk: any, i: number) => (
                                <Typography key={i} variant="caption" fontFamily="monospace">
                                  {jk.left} = {jk.right}{i < rel.join_keys.length - 1 ? ', ' : ''}
                                </Typography>
                              ))}
                            </TableCell>
                            <TableCell>{rel.cardinality.replace(/_/g, ' ')}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  {(detail.relationships || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No relationships defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Hierarchies */}
              {detailTab === 4 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Drill hierarchies define click-to-expand paths (e.g. Year → Quarter → Month → Day).
                  </Alert>
                  {(detail.hierarchies || []).map((h: any) => (
                    <Paper key={h.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>{h.name}</Typography>
                      <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                        {(h.levels || []).map((lvl: any, i: number) => (
                          <React.Fragment key={i}>
                            <Chip label={lvl.label || `Level ${i + 1}`} size="small" color="primary" variant="outlined" />
                            {i < h.levels.length - 1 && <Typography sx={{ alignSelf: 'center' }}>→</Typography>}
                          </React.Fragment>
                        ))}
                      </Stack>
                    </Paper>
                  ))}
                  {(detail.hierarchies || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No drill hierarchies defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Conditions */}
              {detailTab === 5 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Pre-defined conditions are reusable WHERE clauses business users can apply with one click.
                  </Alert>
                  {(detail.conditions || []).map((c: any) => (
                    <Paper key={c.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>{c.label || c.name}</Typography>
                      {c.description && <Typography variant="body2" color="text.secondary">{c.description}</Typography>}
                      <Typography variant="body2" fontFamily="monospace" sx={{ mt: 0.5, color: 'primary.main' }}>
                        WHERE {c.where_clause}
                      </Typography>
                    </Paper>
                  ))}
                  {(detail.conditions || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No pre-defined conditions.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Agg Awareness */}
              {detailTab === 6 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Aggregation awareness maps measures to pre-aggregated tables for faster query routing.
                  </Alert>
                  {(detail.agg_awareness || []).map((a: any) => (
                    <Paper key={a.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>Measure Column ID: {a.measure_col_id}</Typography>
                      <Typography variant="body2" fontFamily="monospace">Table: {a.agg_table}</Typography>
                      <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                        {(a.agg_dimensions || []).map((d: string) => (
                          <Chip key={d} label={d} size="small" variant="outlined" />
                        ))}
                      </Stack>
                    </Paper>
                  ))}
                  {(detail.agg_awareness || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No aggregation awareness rules.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Agg Cache (Phase 55) */}
              {detailTab === 7 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Pre-computed aggregation caches deliver sub-second query results. Define dimension + measure rollups
                    and schedule automatic refreshes.
                  </Alert>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2, gap: 1 }}>
                    <Button size="small" variant="contained" startIcon={<AddIcon />}
                            onClick={openCacheCreateDialog}>
                      Create Rollup
                    </Button>
                    <Button size="small" startIcon={<RefreshIcon />}
                            disabled={aggCacheLoading}
                            onClick={async () => {
                              setAggCacheLoading(true);
                              try {
                                const resp = await api.listAggCacheEntries(detail.id);
                                setAggCacheEntries(resp.entries || []);
                              } catch { /* ignore */ } finally { setAggCacheLoading(false); }
                            }}>
                      Refresh
                    </Button>
                  </Box>
                  {aggCacheLoading && <LinearProgress sx={{ mb: 1 }} />}
                  {aggCacheEntries.length > 0 ? (
                    <TableContainer component={Paper} variant="outlined">
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Grain</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Rows</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Hits</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Last Built</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {aggCacheEntries.map((ce: any) => {
                            const statusColor: Record<string, 'success' | 'warning' | 'error' | 'info' | 'default'> = {
                              ready: 'success', building: 'info', stale: 'warning',
                              expired: 'error', failed: 'error', pending: 'default',
                            };
                            return (
                              <TableRow key={ce.id} hover>
                                <TableCell>
                                  <Typography variant="body2" fontWeight={600}>{ce.name}</Typography>
                                  <Typography variant="caption" color="text.secondary">
                                    {(ce.dimension_col_ids || []).length} dims, {(ce.measure_col_ids || []).length} measures
                                  </Typography>
                                </TableCell>
                                <TableCell><Chip label={ce.grain_label} size="small" variant="outlined" /></TableCell>
                                <TableCell>
                                  <Chip label={ce.status} size="small"
                                        color={statusColor[ce.status] || 'default'}
                                        variant={ce.status === 'ready' ? 'filled' : 'outlined'} />
                                </TableCell>
                                <TableCell>{ce.row_count?.toLocaleString() || '—'}</TableCell>
                                <TableCell>{ce.hit_count || 0}</TableCell>
                                <TableCell sx={{ fontSize: '0.75rem' }}>
                                  {ce.last_built_at ? new Date(ce.last_built_at).toLocaleString() : '—'}
                                </TableCell>
                                <TableCell>
                                  <Tooltip title="Edit">
                                    <IconButton size="small" onClick={() => openCacheEditDialog(ce)}>
                                      <EditIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Build Now">
                                    <IconButton size="small" color="primary"
                                                onClick={async () => {
                                                  try {
                                                    await api.triggerAggCacheBuild(ce.id);
                                                    notify(addNotification, `Build triggered for ${ce.name}`, 'success');
                                                  } catch { notify(addNotification, 'Build trigger failed', 'error'); }
                                                }}>
                                      <BuildNowIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Delete">
                                    <IconButton size="small" color="error"
                                                onClick={async () => {
                                                  try {
                                                    await api.deleteAggCacheEntry(ce.id);
                                                    setAggCacheEntries(prev => prev.filter(e => e.id !== ce.id));
                                                    notify(addNotification, 'Cache entry deleted', 'success');
                                                  } catch { notify(addNotification, 'Delete failed', 'error'); }
                                                }}>
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  ) : (
                    <Typography color="text.secondary" align="center" sx={{ py: 3 }}>
                      No aggregation cache entries. Create rollup definitions to enable sub-second queries.
                    </Typography>
                  )}
                </Box>
              )}
            </>
          ) : null}
        </Paper>
      )}

      {/* ── Create Dataset Dialog ──────────────────────────────────────── */}
      <Dialog open={createOpen} onClose={() => setCreateOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Create Business Dataset</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Dataset Name" fullWidth required value={formName}
                       onChange={e => setFormName(e.target.value)}
                       placeholder="e.g. Sales Analysis" />
            <Stack direction="row" spacing={2}>
              <TextField label="Subject" fullWidth required value={formSubject}
                         onChange={e => setFormSubject(e.target.value)}
                         placeholder="e.g. Sales, HR, Finance" />
            </Stack>
            <TextField label="Description" fullWidth multiline rows={2}
                       value={formDesc} onChange={e => setFormDesc(e.target.value)}
                       placeholder="Brief description for business users" />

            <Divider />
            <Typography variant="subtitle2">Data Source (connect to actual data)</Typography>

            <FormControl fullWidth>
              <InputLabel>Connection</InputLabel>
              <Select value={formConnectionId} label="Connection"
                      onChange={e => setFormConnectionId(e.target.value as number)}>
                <MenuItem value="">— none (configure later in Source tab) —</MenuItem>
                {connections.map(c => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.name} ({c.connection_type})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {formConnectionId && (
              <Stack direction="row" spacing={1} alignItems="center">
                <TextField label="Table / Path" fullWidth value={formSourceTable}
                           onChange={e => setFormSourceTable(e.target.value)}
                           placeholder="s3://bucket/folder/file.parquet  or  catalog.schema.table" />
                <Tooltip title="Browse connection files/tables">
                  <IconButton onClick={() => browseForTable(Number(formConnectionId), 'create')}>
                    <BrowseIcon />
                  </IconButton>
                </Tooltip>
              </Stack>
            )}

            <TextField label="Base Query (optional)" fullWidth multiline rows={3}
                       value={formBaseQuery} onChange={e => setFormBaseQuery(e.target.value)}
                       placeholder="Optional: SELECT * FROM my_table WHERE active = true"
                       InputProps={{ sx: { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                       helperText="Overrides auto-resolution from source table. Leave empty to auto-resolve." />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate}
                  disabled={!formName.trim() || !formSubject.trim()}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* ── Column Edit Dialog ─────────────────────────────────────────── */}
      <Dialog open={colDialogOpen} onClose={() => setColDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingCol?.id ? 'Edit Column' : 'Add Column'}</DialogTitle>
        <DialogContent>
          {editingCol && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="Physical Name" fullWidth value={editingCol.physical_name}
                         onChange={e => setEditingCol({ ...editingCol, physical_name: e.target.value })}
                         placeholder="e.g. cust_rev_net_usd" />
              <TextField label="Friendly Name" fullWidth value={editingCol.friendly_name}
                         onChange={e => setEditingCol({ ...editingCol, friendly_name: e.target.value })}
                         placeholder="e.g. Net Revenue" />
              <Stack direction="row" spacing={2}>
                <FormControl fullWidth>
                  <InputLabel>Column Type</InputLabel>
                  <Select value={editingCol.column_type} label="Column Type"
                          onChange={e => setEditingCol({ ...editingCol, column_type: e.target.value })}>
                    {COLUMN_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                  </Select>
                </FormControl>
                <FormControl fullWidth>
                  <InputLabel>Data Type</InputLabel>
                  <Select value={editingCol.data_type} label="Data Type"
                          onChange={e => setEditingCol({ ...editingCol, data_type: e.target.value })}>
                    {DATA_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                  </Select>
                </FormControl>
              </Stack>
              {(editingCol.column_type === 'measure' || editingCol.column_type === 'kpi') && (
                <FormControl fullWidth>
                  <InputLabel>Default Aggregation</InputLabel>
                  <Select value={editingCol.aggregation || ''} label="Default Aggregation"
                          onChange={e => setEditingCol({ ...editingCol, aggregation: e.target.value })}>
                    {AGGREGATIONS.map(a => <MenuItem key={a} value={a}>{a || '(none)'}</MenuItem>)}
                  </Select>
                </FormControl>
              )}
              <TextField label="Format Pattern" fullWidth value={editingCol.format_pattern || ''}
                         onChange={e => setEditingCol({ ...editingCol, format_pattern: e.target.value })}
                         placeholder="e.g. $#,##0.00" />
              <TextField label="Description" fullWidth multiline rows={2}
                         value={editingCol.description || ''}
                         onChange={e => setEditingCol({ ...editingCol, description: e.target.value })} />
              <TextField label="Synonyms (comma-separated)" fullWidth
                         value={(editingCol.synonyms || []).join(', ')}
                         onChange={e => setEditingCol({
                           ...editingCol,
                           synonyms: e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean),
                         })}
                         placeholder="e.g. revenue, sales_amount, net_rev" />
              <FormControlLabel
                control={<Switch checked={editingCol.is_hidden || false}
                                 onChange={e => setEditingCol({ ...editingCol, is_hidden: e.target.checked })} />}
                label="Hidden from business users" />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setColDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={<SaveIcon />} onClick={saveColumn}
                  disabled={!editingCol?.physical_name || !editingCol?.friendly_name}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* ── Config Dialog ──────────────────────────────────────────────── */}
      <Dialog open={configOpen} onClose={() => setConfigOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Semantic Layer Configuration</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <FormControlLabel control={<Switch checked={config.enabled ?? true}
              onChange={e => setConfig({ ...config, enabled: e.target.checked })} />}
              label="Semantic Layer Enabled" />
            <FormControlLabel control={<Switch checked={config.auto_detect_column_types ?? true}
              onChange={e => setConfig({ ...config, auto_detect_column_types: e.target.checked })} />}
              label="Auto-detect column types on create" />
            <FormControlLabel control={<Switch checked={config.cascading_prompts_enabled ?? true}
              onChange={e => setConfig({ ...config, cascading_prompts_enabled: e.target.checked })} />}
              label="Cascading prompts (report builder)" />
            <FormControlLabel control={<Switch checked={config.drill_hierarchies_enabled ?? true}
              onChange={e => setConfig({ ...config, drill_hierarchies_enabled: e.target.checked })} />}
              label="Drill hierarchies" />
            <FormControlLabel control={<Switch checked={config.aggregation_awareness_enabled ?? true}
              onChange={e => setConfig({ ...config, aggregation_awareness_enabled: e.target.checked })} />}
              label="Aggregation awareness routing" />
            <FormControlLabel control={<Switch checked={config.synonym_matching_enabled ?? true}
              onChange={e => setConfig({ ...config, synonym_matching_enabled: e.target.checked })} />}
              label="NL synonym matching" />
            <TextField label="Max Datasets" type="number" fullWidth
                       value={config.max_datasets ?? 100}
                       onChange={e => setConfig({ ...config, max_datasets: Number(e.target.value) })} />
            <TextField label="Max Columns per Dataset" type="number" fullWidth
                       value={config.max_columns_per_dataset ?? 500}
                       onChange={e => setConfig({ ...config, max_columns_per_dataset: Number(e.target.value) })} />
            <TextField label="Default Row Limit" type="number" fullWidth
                       value={config.default_row_limit ?? 10000}
                       onChange={e => setConfig({ ...config, default_row_limit: Number(e.target.value) })} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfigOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={<SaveIcon />} onClick={saveConfig}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* ── Agg Cache Create/Edit Dialog ────────────────────────────────── */}
      <Dialog open={cacheDialogOpen} onClose={() => setCacheDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{cacheEditId ? 'Edit Cache Rollup' : 'Create Cache Rollup'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Rollup Name" fullWidth required value={cacheName}
                       onChange={e => setCacheName(e.target.value)}
                       placeholder="e.g. Monthly Sales Rollup" />
            <TextField label="Description" fullWidth multiline rows={2} value={cacheDesc}
                       onChange={e => setCacheDesc(e.target.value)}
                       placeholder="What this cache covers" />

            {/* Dimension columns multi-select */}
            <Typography variant="subtitle2" sx={{ mt: 1, mb: 0 }}>
              Dimensions — GROUP BY columns (pick at least 1)
            </Typography>
            <Paper variant="outlined" sx={{ maxHeight: 180, overflow: 'auto' }}>
              {dimensionCols.length > 0 ? (
                <List dense disablePadding>
                  {dimensionCols.map((col: any) => (
                    <ListItem key={col.id} dense disablePadding
                              sx={{ cursor: 'pointer' }}
                              onClick={() => setCacheDimIds(prev =>
                                prev.includes(col.id) ? prev.filter(id => id !== col.id) : [...prev, col.id]
                              )}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <Checkbox edge="start" size="small" checked={cacheDimIds.includes(col.id)} tabIndex={-1} />
                      </ListItemIcon>
                      <ListItemText primary={col.friendly_name || col.physical_name}
                                    secondary={col.physical_name} />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No dimension columns defined. Add columns with type "dimension" first.
                </Typography>
              )}
            </Paper>

            {/* Measure columns multi-select */}
            <Typography variant="subtitle2" sx={{ mt: 1, mb: 0 }}>
              Measures — aggregated values (pick at least 1)
            </Typography>
            <Paper variant="outlined" sx={{ maxHeight: 180, overflow: 'auto' }}>
              {measureCols.length > 0 ? (
                <List dense disablePadding>
                  {measureCols.map((col: any) => (
                    <ListItem key={col.id} dense disablePadding
                              sx={{ cursor: 'pointer' }}
                              onClick={() => setCacheMeasureIds(prev =>
                                prev.includes(col.id) ? prev.filter(id => id !== col.id) : [...prev, col.id]
                              )}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <Checkbox edge="start" size="small" checked={cacheMeasureIds.includes(col.id)} tabIndex={-1} />
                      </ListItemIcon>
                      <ListItemText primary={col.friendly_name || col.physical_name}
                                    secondary={`${col.physical_name} — ${col.aggregation || 'sum'}`} />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No measure/kpi columns defined. Add columns with type "measure" first.
                </Typography>
              )}
            </Paper>

            <Divider />

            {/* Grain + Schedule */}
            <Stack direction="row" spacing={2}>
              <FormControl fullWidth>
                <InputLabel>Grain</InputLabel>
                <Select value={cacheGrain} label="Grain"
                        onChange={e => setCacheGrain(e.target.value)}>
                  {GRAIN_LABELS.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl fullWidth>
                <InputLabel>Refresh Schedule</InputLabel>
                <Select value={cacheScheduleType} label="Refresh Schedule"
                        onChange={e => setCacheScheduleType(e.target.value)}>
                  {SCHEDULE_TYPES.map(s => (
                    <MenuItem key={s} value={s}>
                      {s === 'none' ? 'Manual only' : s === 'cron' ? 'Cron expression' : 'Fixed interval'}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>

            {cacheScheduleType === 'cron' && (
              <TextField label="Cron Expression" fullWidth value={cacheCron}
                         onChange={e => setCacheCron(e.target.value)}
                         helperText="e.g. 0 2 * * * = daily at 2 AM" />
            )}
            {cacheScheduleType === 'interval' && (
              <TextField label="Interval (hours)" type="number" fullWidth
                         value={cacheIntervalHours}
                         onChange={e => setCacheIntervalHours(Number(e.target.value))}
                         inputProps={{ min: 1, max: 168 }}
                         helperText="Refresh every N hours" />
            )}

            {/* Pre-defined conditions */}
            {conditionsList.length > 0 && (
              <>
                <Typography variant="subtitle2">Pre-baked Conditions (optional)</Typography>
                <Paper variant="outlined" sx={{ maxHeight: 120, overflow: 'auto' }}>
                  <List dense disablePadding>
                    {conditionsList.map((cond: any) => (
                      <ListItem key={cond.id} dense disablePadding
                                sx={{ cursor: 'pointer' }}
                                onClick={() => setCacheConditionIds(prev =>
                                  prev.includes(cond.id) ? prev.filter(id => id !== cond.id) : [...prev, cond.id]
                                )}>
                        <ListItemIcon sx={{ minWidth: 36 }}>
                          <Checkbox edge="start" size="small" checked={cacheConditionIds.includes(cond.id)} tabIndex={-1} />
                        </ListItemIcon>
                        <ListItemText primary={cond.name} secondary={cond.where_clause} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </>
            )}

            <Divider />

            {/* Incremental refresh */}
            <FormControlLabel
              control={<Switch checked={cacheIncremental}
                               onChange={e => setCacheIncremental(e.target.checked)} />}
              label="Incremental refresh (Tableau-style)" />
            {cacheIncremental && (
              <FormControl fullWidth>
                <InputLabel>Incremental Column</InputLabel>
                <Select value={cacheIncrementalCol} label="Incremental Column"
                        onChange={e => setCacheIncrementalCol(e.target.value)}>
                  {dateCols.map((col: any) => (
                    <MenuItem key={col.id} value={col.physical_name}>
                      {col.friendly_name || col.physical_name}
                    </MenuItem>
                  ))}
                  {/* Also allow dimension cols */}
                  {dimensionCols.filter((c: any) => c.data_type === 'number').map((col: any) => (
                    <MenuItem key={col.id} value={col.physical_name}>
                      {col.friendly_name || col.physical_name} (numeric)
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCacheDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={cacheEditId ? <SaveIcon /> : <AddIcon />}
                  onClick={handleCacheSave}
                  disabled={cacheSaving || !cacheName.trim() || cacheDimIds.length === 0 || cacheMeasureIds.length === 0}>
            {cacheSaving ? <CircularProgress size={20} /> : cacheEditId ? 'Save Changes' : 'Create & Build'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Browse Files/Tables Dialog ──────────────────────────────────── */}
      <Dialog open={browseOpen} onClose={() => setBrowseOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          Browse {browseConnId ? connName(browseConnId) : 'Connection'} — Select Table/File
        </DialogTitle>
        <DialogContent>
          {browseLoading ? (
            <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
          ) : browseFiles.length === 0 ? (
            <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
              No files or tables found for this connection.
            </Typography>
          ) : (
            <List dense sx={{ maxHeight: 400, overflow: 'auto' }}>
              {browseFiles.map((f: any, i: number) => {
                const label = f.path || f.name || f.key || '';
                return (
                  <ListItem key={i} disablePadding
                            sx={{ cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
                            onClick={() => selectBrowseFile(label)}>
                    <ListItemText
                      primary={f.name || label}
                      secondary={`${f.folder || ''} ${f.num_rows != null ? `— ${f.num_rows} rows` : ''} ${f.table_type || ''}`}
                    />
                  </ListItem>
                );
              })}
            </List>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBrowseOpen(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
