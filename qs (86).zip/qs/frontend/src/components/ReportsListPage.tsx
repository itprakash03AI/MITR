/**
 * Phase 56 — Reports List Page
 *
 * Lists the user's reports + published reports with actions.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Tooltip, CircularProgress,
  Alert, TextField, InputAdornment, Dialog, DialogTitle, DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  ContentCopy as DuplicateIcon,
  Search as SearchIcon,
  Public as PublishIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const ReportsListPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const isAdmin = user?.role === 'admin';
  const username = user?.username || '';

  const loadReports = () => {
    setLoading(true);
    api.listBusinessReports()
      .then((data: any) => setReports(Array.isArray(data) ? data : []))
      .catch(() => setError('Failed to load reports'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadReports(); }, []);

  const filtered = reports.filter(r => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (r.name || '').toLowerCase().includes(q) ||
      (r.description || '').toLowerCase().includes(q) ||
      (r.owner || '').toLowerCase().includes(q);
  });

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.deleteBusinessReport(deleteId);
      setReports(prev => prev.filter(r => r.id !== deleteId));
    } catch { setError('Failed to delete report'); }
    setDeleteId(null);
  };

  const handleDuplicate = async (id: number) => {
    try {
      const dup = await api.duplicateBusinessReport(id);
      if (dup?.id) navigate(`/business-reports/${dup.id}/edit`);
    } catch { setError('Failed to duplicate report'); }
  };

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>Business Reports</Typography>
        <TextField
          size="small" placeholder="Search reports..."
          value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
          sx={{ width: 250 }}
        />
        <Button variant="contained" startIcon={<AddIcon />}
          onClick={() => navigate('/business-reports/new')}>
          New Report
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {filtered.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            {reports.length === 0 ? 'No reports yet. Click "New Report" to create one.' : 'No matching reports.'}
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Owner</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Executions</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Last Executed</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Updated</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.map(r => (
                <TableRow key={r.id} hover sx={{ cursor: 'pointer' }}
                  onClick={() => navigate(`/business-reports/${r.id}`)}>
                  <TableCell>
                    <Typography variant="body2" fontWeight="bold">{r.name}</Typography>
                    {r.description && (
                      <Typography variant="caption" color="text.secondary">{r.description.slice(0, 60)}</Typography>
                    )}
                  </TableCell>
                  <TableCell>{r.owner}</TableCell>
                  <TableCell>
                    {r.is_published ? (
                      <Chip size="small" label="Published" color="success" />
                    ) : (
                      <Chip size="small" label="Draft" variant="outlined" />
                    )}
                  </TableCell>
                  <TableCell>{r.execution_count || 0}</TableCell>
                  <TableCell>
                    {r.last_executed_at ? new Date(r.last_executed_at).toLocaleString() : '-'}
                  </TableCell>
                  <TableCell>
                    {r.updated_at ? new Date(r.updated_at).toLocaleDateString() : '-'}
                  </TableCell>
                  <TableCell align="right" onClick={e => e.stopPropagation()}>
                    <Tooltip title="Open"><IconButton size="small" onClick={() => navigate(`/business-reports/${r.id}`)}>
                      <ViewIcon fontSize="small" />
                    </IconButton></Tooltip>
                    {(r.owner === username || isAdmin) && (
                      <Tooltip title="Edit"><IconButton size="small" onClick={() => navigate(`/business-reports/${r.id}/edit`)}>
                        <EditIcon fontSize="small" />
                      </IconButton></Tooltip>
                    )}
                    <Tooltip title="Duplicate"><IconButton size="small" onClick={() => handleDuplicate(r.id)}>
                      <DuplicateIcon fontSize="small" />
                    </IconButton></Tooltip>
                    {(r.owner === username || isAdmin) && (
                      <Tooltip title="Delete"><IconButton size="small" color="error"
                        onClick={() => setDeleteId(r.id)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton></Tooltip>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Delete confirmation dialog */}
      <Dialog open={deleteId !== null} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Report</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this report? This cannot be undone.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ReportsListPage;
