/**
 * Shared Playwright test fixtures and helpers for QueryStudio E2E tests.
 */
import { test as base, expect, type Page } from '@playwright/test';

const BASE = 'http://localhost:8000';

/** Wait for the backend to be healthy. */
export async function waitForHealth(page: Page) {
  for (let i = 0; i < 10; i++) {
    try {
      const resp = await page.request.get(`${BASE}/health`);
      if (resp.ok()) return;
    } catch { /* retry */ }
    await page.waitForTimeout(1000);
  }
  throw new Error('Backend did not become healthy within 10s');
}

/** Create a local-folder test connection via API and return its id. */
export async function createTestConnection(page: Page, name = 'E2E Test Connection') {
  const resp = await page.request.post(`${BASE}/api/connections`, {
    data: {
      name,
      connection_type: 'local',
      config: { base_path: './data/parquet' },
    },
  });
  expect(resp.ok()).toBeTruthy();
  const body = await resp.json();
  return body.id as number;
}

/** Delete a connection by id. */
export async function deleteConnection(page: Page, id: number) {
  await page.request.delete(`${BASE}/api/connections/${id}`);
}

/** Extended test fixture with helper connection management. */
export const test = base.extend<{ testConnId: number }>({
  testConnId: async ({ page }, use) => {
    const id = await createTestConnection(page);
    await use(id);
    await deleteConnection(page, id);
  },
});

export { expect };
