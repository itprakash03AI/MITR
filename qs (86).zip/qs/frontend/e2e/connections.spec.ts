import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('Connection Management', () => {
  let connId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (connId) {
      await page.request.delete(`${BASE}/api/connections/${connId}`).catch(() => {});
      connId = null;
    }
  });

  test('should create a local folder connection via API', async ({ page }) => {
    const resp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E Local Test',
        connection_type: 'local',
        config: { base_path: './data/parquet' },
      },
    });
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.id).toBeTruthy();
    connId = body.id;
  });

  test('should test a connection successfully', async ({ page }) => {
    // Create connection first
    const createResp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E Test Conn',
        connection_type: 'local',
        config: { base_path: './data/parquet' },
      },
    });
    const conn = await createResp.json();
    connId = conn.id;

    // Test connection
    const testResp = await page.request.post(`${BASE}/api/connections/${connId}/test`);
    expect(testResp.ok()).toBeTruthy();
    const testResult = await testResp.json();
    expect(testResult.success).toBe(true);
  });

  test('should list connections including the created one', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E List Test',
        connection_type: 'local',
        config: { base_path: './data/parquet' },
      },
    });
    const conn = await createResp.json();
    connId = conn.id;

    const listResp = await page.request.get(`${BASE}/api/connections`);
    const conns = await listResp.json();
    const found = conns.find((c: any) => c.id === connId);
    expect(found).toBeTruthy();
    expect(found.name).toBe('E2E List Test');
  });

  test('should delete a connection', async ({ page }) => {
    const createResp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E Delete Test',
        connection_type: 'local',
        config: { base_path: './data/parquet' },
      },
    });
    const conn = await createResp.json();
    const deleteResp = await page.request.delete(`${BASE}/api/connections/${conn.id}`);
    expect(deleteResp.ok()).toBeTruthy();
    connId = null; // already deleted
  });
});
