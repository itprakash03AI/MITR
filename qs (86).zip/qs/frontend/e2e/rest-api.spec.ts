import { test, expect } from '@playwright/test';

const BASE = 'http://localhost:8000';

test.describe('REST API Connector', () => {
  let connId: number | null = null;

  test.afterEach(async ({ page }) => {
    if (connId) {
      await page.request.delete(`${BASE}/api/connections/${connId}`).catch(() => {});
      connId = null;
    }
  });

  test('should create a REST API connection', async ({ page }) => {
    const resp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E REST API Test',
        connection_type: 'rest_api',
        config: {
          base_url: 'https://jsonplaceholder.typicode.com',
          auth_type: 'none',
          timeout_seconds: 10,
          verify_ssl: true,
        },
      },
    });
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.id).toBeTruthy();
    connId = body.id;
  });

  test('should CRUD REST query definitions', async ({ page }) => {
    // Create connection
    const connResp = await page.request.post(`${BASE}/api/connections`, {
      data: {
        name: 'E2E REST QDef Test',
        connection_type: 'rest_api',
        config: {
          base_url: 'https://jsonplaceholder.typicode.com',
          auth_type: 'none',
        },
      },
    });
    const conn = await connResp.json();
    connId = conn.id;

    // Create query definition
    const createResp = await page.request.post(`${BASE}/api/connections/${connId}/rest-queries`, {
      data: {
        name: 'Users',
        endpoint_path: '/users',
        http_method: 'GET',
        response_json_path: '',
        pagination_type: 'none',
      },
    });
    expect(createResp.ok()).toBeTruthy();
    const qdef = await createResp.json();
    expect(qdef.id).toBeTruthy();
    expect(qdef.name).toBe('Users');

    // List query definitions
    const listResp = await page.request.get(`${BASE}/api/connections/${connId}/rest-queries`);
    const qdefs = await listResp.json();
    expect(qdefs.length).toBeGreaterThanOrEqual(1);

    // Update
    const updateResp = await page.request.put(`${BASE}/api/connections/${connId}/rest-queries/${qdef.id}`, {
      data: { name: 'All Users' },
    });
    expect(updateResp.ok()).toBeTruthy();
    const updated = await updateResp.json();
    expect(updated.name).toBe('All Users');

    // Delete
    const delResp = await page.request.delete(`${BASE}/api/connections/${connId}/rest-queries/${qdef.id}`);
    expect(delResp.ok()).toBeTruthy();
  });
});
