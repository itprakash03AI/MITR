# QueryStudio — Feature Tracking & Roadmap

**Last Updated**: 2026-03-27 (Phase 61 COMPLETE; BF-08 duckdb_views.py build_query_sql fix; all 61 phases complete)

---

## Phase 0: Foundation (MUI + Sidebar Layout) — COMPLETE

| # | Task | Status |
|---|------|--------|
| 0A | Install MUI (`@mui/material`, `@mui/icons-material`, `@emotion/*`, `@mui/x-data-grid`) | Done |
| 0B | Create MUI theme (`theme.js`) mapping existing CSS vars | Done |
| 0C | Create sidebar layout (`Layout.tsx`) — permanent drawer, nav groups, collapse | Done |
| 0D | Rewrite `App.tsx` — ThemeProvider + CssBaseline + Layout wrapper | Done |
| 0E | Trim legacy CSS (remove `.main-nav`, `.nav-brand`, etc.) | Done |

---

## Phase 1: Connection Manager — COMPLETE

| # | Task | Status |
|---|------|--------|
| 1A | `Connection` DB model (id, name, type, config JSON, test status) | Done |
| 1B | `ConnectionManager` backend logic (test, list files, get schema, cache) | Done |
| 1C | API endpoints: CRUD + test + browse files + schema | Done |
| 1D | Frontend API service (`api.ts` — connection methods) | Done |
| 1E | Connection Manager UI (`ConnectionManager.tsx`) — table, add/edit dialog, test | Done |

---

## Phase 2: MUI Component Migration — COMPLETE

| # | Component | Status |
|---|-----------|--------|
| 2A | NotificationCenter → MUI Snackbar + Alert | Done |
| 2B | SavedQueries → MUI Card, Dialog, Typography | Done |
| 2C | ExecutionHistory → MUI Table, ToggleButtonGroup, Chip | Done |
| 2D | Downloads → MUI Card, Chip, Button | Done |
| 2E | DataGridViewer → virtual scroll + MUI toolbar | Done |
| 2F | ReportPage → MUI Autocomplete, Card, Accordion | Done |
| 2G | CompleteQueryBuilder → MUI ButtonGroup, Badge, Dialog, Select, TextField | Done |
| 2H | Vite + TypeScript migration (from CRA) | Done |

---

## Phase 3: Wire Connections into Query Workflow — COMPLETE

| # | Task | Status |
|---|------|--------|
| 3A | Connection selector in Query Builder (top dropdown) | Done |
| 3B | `connection_id` in query config (API + frontend) | Done |
| 3C | Backend execution with connection-scoped handlers | Done |
| 3D | `connection_id` persisted on saved queries | Done |

---

## Phase 4: Backend Performance — COMPLETE

| # | Task | Status |
|---|------|--------|
| 4A | TTL cache (`core/cache.py`) — schema + file list caching | Done |
| 4B | Cache integration in optimized engine | Done |
| 4C | Async schema loading (`asyncio.to_thread()`) | Done |
| 4D | Thread pool for query execution (`worker_pool.py`) | Done |
| 4E | Parallel schema loading (frontend `Promise.allSettled`) | Done |

---

## Phase 5: Cleanup — COMPLETE

| # | Task | Status |
|---|------|--------|
| 5A | Delete backup/deprecated `.jsx/.py` files | Done |
| 5B | Delete migrated component `.css` files | Done |
| 5C | Add `ErrorBoundary.tsx` | Done |

---

## Phase 6: Enterprise Connectors — COMPLETE

| # | Task | Status |
|---|------|--------|
| 6A | Trino/Starburst connector (`trino_connector.py`) | Done |
| 6B | Snowflake connector (`snowflake_connector.py`) | Done |
| 6C | Databricks connector (`databricks_connector.py`) | Done |
| 6D | Oracle connector (`oracle_connector.py`) | Done |
| 6E | Base `SqlConnector` abstract class | Done |
| 6F | Cross-source joins (`cross_source_engine.py`) | Done |

---

## Phase 7: S3 Live Streaming — COMPLETE

| # | Task | Status |
|---|------|--------|
| 7A | DuckDB httpfs streaming from S3 | Done |
| 7B | Iceberg metadata reader (`iceberg_reader.py`, `iceberg_service.py`) | Done |
| 7C | Partition discovery + pruning | Done |
| 7D | Streaming pagination endpoint (`/api/execute/stream/paginate`) | Done |
| 7E | Streaming chart-data endpoint (`/api/execute/stream/chart-data`) | Done |
| 7F | Streaming pivot-data endpoint (`/api/execute/stream/pivot-data`) | Done |
| 7G | Frontend streaming toggle + background download | Done |

---

## Phase 8: Scheduled Queries & Notifications — COMPLETE

| # | Task | Status |
|---|------|--------|
| 8A | APScheduler integration (`core/scheduler.py`) | Done |
| 8B | Schedule CRUD API (`api/schedules_api.py`) | Done |
| 8C | `SchedulesPage.tsx` — cron/interval config, params, run-now | Done |
| 8D | Email notifications (`core/email_service.py`) — SMTP, attachments | Done |
| 8E | Webhook service (`core/webhook_service.py`) — Slack, Teams, generic | Done |
| 8F | Date resolver (`core/date_resolver.py`) — `${today}`, `${monthStart-7d}` etc. | Done |

---

## Phase 9: Authentication & RBAC — COMPLETE

| # | Task | Status |
|---|------|--------|
| 9A | AD/LDAP auth (`core/ad_auth.py`) + local password hashing | Done |
| 9B | `AuthContext.tsx` — login/logout, session, `getAuthHeader()` | Done |
| 9C | `LoginPage.tsx` — AD login form | Done |
| 9D | Role-based access (admin, analyst, viewer) | Done |
| 9E | Feature toggles per role (streaming, export, SQL editor, scheduler, etc.) | Done |
| 9F | Credential encryption (`core/crypto.py` — Fernet) | Done |
| 9G | Row-level security (queries/executions filtered to `created_by`) | Done |

---

## Phase 10: Advanced Data Features — COMPLETE

| # | Task | Status |
|---|------|--------|
| 10A | Materialized views — snapshot S3 data locally | Done |
| 10B | Local tables — upload/create parquet tables | Done |
| 10C | Table favorites — bookmark frequently used tables | Done |
| 10D | Query versioning — auto-snapshot on save, restore | Done |
| 10E | Query sharing — public share links (no auth) | Done |
| 10F | Parametric reports (`api/reports_api.py`) | Done |
| 10G | Reports manager page (`ReportsManagerPage.tsx`) | Done |

---

## Phase 11: Dashboards — COMPLETE

| # | Task | Status |
|---|------|--------|
| 11A | Dashboard CRUD (`api/dashboards_api.py`) | Done |
| 11B | `DashboardPage.tsx` — react-grid-layout builder | Done |
| 11C | Widget library (table, bar, line, area, pie, pivot) | Done |
| 11D | Dashboard sharing (public links) | Done |
| 11E | `SharedDashboardPage.tsx` — public view | Done |

---

## Phase 12: Admin & Monitoring — COMPLETE

| # | Task | Status |
|---|------|--------|
| 12A | Admin panel (`AdminPage.tsx`) | Done |
| 12B | Active query monitoring (real-time) | Done |
| 12C | User activity stats | Done |
| 12D | Storage usage dashboard + cleanup | Done |
| 12E | Cache statistics + invalidation | Done |
| 12F | Audit log (immutable trail) | Done |
| 12G | User management CRUD (admin-only) | Done |
| 12H | Config editor (limits + features, live reload) | Done |
| 12I | Worker pool monitoring (tasks, history, config tuning) | Done |
| 12J | Admin page redesign — menu-based two-panel layout | Done |
| 12K | Enterprise reports — auto-partition params, auto-WHERE generation, hybrid cross-source, caching, scheduling, Excel export | Done |

---

## Phase 13: SQL Editor — COMPLETE

| # | Task | Status |
|---|------|--------|
| 13A | SQL query page (`SqlQueryPage.tsx`) | Done |
| 13B | SQL API router (`api/sql_query_api.py`) | Done |
| 13C | Catalog/schema/table/column browser | Done |
| 13D | Cross-source SQL joins | Done |
| 13E | SQL saved queries (separate from visual queries) | Done |

---

## Phase 14: Tabbed Query Editor — COMPLETE

| # | Task | Status |
|---|------|--------|
| 14A | `QueryTabManager.tsx` — tab bar + state management | Done |
| 14B | Tab persistence in sessionStorage | Done |
| 14C | Max 10 tabs, right-click context menu (rename/close) | Done |
| 14D | SavedQueries "Edit" opens in new tab | Done |
| 14E | Smart tab caching — stale placeholder for idle tabs (>5min) | Done |
| 14F | Deferred fetch on reload — only active tab fetches, others show placeholder | Done |

---

## Phase 15: Charts, Pivots & Column Intelligence — COMPLETE

| # | Task | Status |
|---|------|--------|
| 15A | Chart types: bar, line, multi-line, scatter, pie, grouped bar, area | Done |
| 15B | Pivot table (row fields, column field, aggregation values) | Done |
| 15C | `columnIntelligence.ts` — classify columns (numeric/categorical/temporal/boolean/id) | Done |
| 15D | Smart chart suggestion (auto-pick type + axes based on data) | Done |
| 15E | Smart pivot suggestion (auto-pick rows/cols/values) | Done |
| 15F | Smart join suggestion (auto-match columns by name/pattern) | Done |
| 15G | Chart/pivot data cached across view switches (table↔chart↔pivot) | Done |

---

## Phase 16: Modern Notification System — COMPLETE

| # | Task | Status |
|---|------|--------|
| 16A | `NotificationContext.tsx` — global execution tracker (all tabs) | Done |
| 16B | Execution log stream (progress, completed, failed, cancelled) | Done |
| 16C | Persistent notification bell with unread badge | Done |
| 16D | `NotificationDrawer.tsx` — notification detail panel | Done |
| 16E | WebSocket heartbeat (ping/pong, 45s reconnect) | Done |

---

## Phase 17: Distributed Architecture (Executor Service) — COMPLETE

| # | Task | Status |
|---|------|--------|
| 17A | `executor_worker.py` — standalone executor process | Done |
| 17B | `TaskQueue` model (pending→claimed→processing→completed/failed) | Done |
| 17C | `executor_poller.py` — polls task_queue, broadcasts WebSocket | Done |
| 17D | `executor.mode` config: embedded (default) vs external | Done |
| 17E | `scheduler_worker.py` — standalone scheduler process | Done |
| 17F | `scheduler.mode` config: embedded (default) vs external | Done |
| 17G | `notification_queue.py` — DB-backed cross-process notifications | Done |
| 17H | `notification_poller.py` — polls + broadcasts via WebSocket | Done |
| 17I | CLI (`querystudio/cli.py`): standalone, webserver, scheduler, executor | Done |
| 17J | Worker pool (`worker_pool.py`) — 5 work types, per-type limits | Done |

---

## Phase 18: Docker & Deployment — COMPLETE

| # | Task | Status |
|---|------|--------|
| 18A | `Dockerfile` — multi-stage build (Node + Python) | Done |
| 18B | `docker-compose.yml` — standalone mode (all-in-one) | Done |
| 18C | `docker-compose.production.yml` — 3-service split (webserver/scheduler/executor) | Done |
| 18D | Health check endpoint (`/health`) | Done |
| 18E | Non-root container user (UID 1001) | Done |

---

## Phase 19: Full Distributed (Redis + Multi-Instance) — DONE

| # | Task | Status |
|---|------|--------|
| 19A | Redis optional queue backend — Strategy pattern (SQLite/Redis) with sorted-set priority queues, BZPOPMIN blocking claim, pub/sub events, auto-fallback | **DONE** |
| 19B | Admin queue config UI — Admin page section for switching backend, Redis URL/auth, test connectivity, key prefix, TTL. Full API endpoints (GET/PUT/test-redis) | **DONE** |
| 19C | Nginx load balancer config — `nginx/nginx.conf`: least_conn upstream (3 API instances), WebSocket /ws upgrade, JSON access log, gzip, 300s proxy timeouts, /metrics restricted to internal IPs | **DONE** |
| 19D | Multi-API scaling — 3 stateless API instances sharing ReadWriteMany PVC; no DuckDB in API layer (delegated to executor workers) | **DONE** |
| 19E | Multi-worker scaling — `docker-compose.scale.yml`: 3 API + nginx + 1 scheduler + 3 executors + Redis; scale with `--scale executor=N` | **DONE** |
| 19F | S3 result storage — configurable (local/s3/auto), size threshold, admin UI, S3 download fallback | **DONE** |
| 19G | Wait mode — `wait=true` + `wait_timeout` fields on `POST /api/execute`; polls DB until complete or timeout, returns inline result | **DONE** |
| 19H | Batch submit API — `POST /api/jobs/submit-batch`: up to 50 queries in one call, returns array of execution_ids | **DONE** |
| 19I | Webhook callbacks — `callback_url` field on `POST /api/execute`; executor fires HTTP POST on complete/failed/cancelled (daemon thread, best-effort) | **DONE** |
| 19J | Queue depth monitoring — `GET /api/admin/queue/depths`: pending/active/completed/failed totals, by-type breakdown, priority buckets (high/normal/low), oldest task age | **DONE** |

---

## Phase 20: Kubernetes / OpenShift — DONE

| # | Task | Status |
|---|------|--------|
| 20A | Helm chart — `k8s/helm/`: Chart.yaml, values.yaml, _helpers.tpl | **DONE** |
| 20B | Deployments for webserver, scheduler, executor — separate Deployment YAMLs; scheduler uses `strategy: Recreate` (single-instance safe) | **DONE** |
| 20C | PVC definitions — `pvc.yaml`: data volume (ReadWriteMany / NFS), Redis volume (ReadWriteOnce) | **DONE** |
| 20D | Service mesh integration (Istio/Linkerd) — values.yaml config, sidecar annotations, Istio CRDs (PeerAuth/DestinationRule/VirtualService), Linkerd ServiceProfile | **DONE** |
| 20E | Horizontal Pod Autoscaler — `hpa.yaml`: CPU + memory targets, scale-up 2 pods/min, scale-down 1 pod/2min (conservative) | **DONE** |
| 20F | ConfigMap + Secret — `configmap.yaml` (config.json from Helm values), `secret.yaml` (Redis password, placeholder for AD/DB creds) | **DONE** |
| 20G | Liveness/readiness probes on all services — GET /health (webserver), GET /health/live (scheduler/executor), all with appropriate delays | **DONE** |

---

## Phase 21: Observability — DONE

| # | Task | Status |
|---|------|--------|
| 21A | Prometheus `/metrics` endpoint — already wired (Counter, Histogram, Gauge for requests, latency, pool depth, WebSockets) | **DONE** |
| 21B | Grafana dashboard — `monitoring/grafana/querystudio-dashboard.json`: 7 panels (request rate, latency p50/p95/p99, error rate, active/queued tasks, WebSocket connections, throughput) | **DONE** |
| 21C | OpenTelemetry tracing — `_setup_otel()` in main.py; OTLP gRPC exporter to Jaeger/Tempo; config-driven via `server.otel_endpoint`; graceful no-op if SDK not installed | **DONE** |
| 21D | Correlation IDs — X-Request-ID middleware already in `_enterprise_middleware()` (generates UUID if absent, echoes in response header, included in every structured log entry) | **DONE** |
| 21E | Structured JSON logging — `python-json-logger` with field remapping (timestamp, level, logger, file, line, func); already in production | **DONE** |

---

## Phase 22: Enterprise Hardening — DONE

| # | Task | Status |
|---|------|--------|
| 22A | Migrate SQLite → PostgreSQL (for multi-host deployments) | Pending (later) |
| 22B | Cross-process rate limiting — `core/rate_limiter.py`: Redis sliding-window sorted set; in-process deque fallback. Wired into `/api/execute` (60 req/min per user, 429 + Retry-After) | **DONE** |
| 22C | Dead-letter queue with exponential backoff — `DeadLetterQueue` ORM model, `push_dead_letter()`/`list_dead_letter()`/`resolve_dead_letter()`. Executor: retries with `delay_seconds = min(30 * 2^n, 1800)` before DLQ. DLQ admin endpoints (list/resolve/requeue). `delay_seconds` supported in all backends | **DONE** |
| 22D | Comprehensive test suite — `tests/conftest.py`, `test_config.py`, `test_queue_backend.py` (SQLite + Redis), `test_health.py`, `test_date_resolver.py`. Builds on existing `test_worker_pool.py`, `test_database_downloads.py` | **DONE** |
| 22E | API versioning — `API_VERSION = "2.0.0"`, `API_MAJOR = "v2"`. `X-API-Version: v2` header on all responses. `GET /api/version` endpoint returns version, name, python | **DONE** |
| 22F | GraphQL API — Strawberry schema (`api/graphql_api.py`), /graphql endpoint, queries + mutations for all entities | **DONE** |
| 22G | gRPC inter-service communication — protobuf IDL, ExecutorService/QueryService/HealthService, server + client | **DONE** |

---

## Recently Completed (This Session — March 2026)

| Item | File(s) | Description |
|------|---------|-------------|
| Column intelligence | `services/columnIntelligence.ts` | Classify columns, suggest chart/pivot/join defaults |
| Smart chart defaults | `DataGridViewer.tsx` | Auto-pick chart type + axes from column analysis |
| Smart pivot defaults | `DataGridViewer.tsx` | Auto-pick row/col/value fields |
| Smart join matching | `CompleteQueryBuilder.tsx` | Auto-populate join conditions by name/pattern |
| Tab stale caching | `CompleteQueryBuilder.tsx` | Idle tabs show placeholder, preserve executionId |
| Deferred fetch on reload | `CompleteQueryBuilder.tsx` | Only active tab fetches, others show "Load Results" |
| Chart/pivot view caching | `DataGridViewer.tsx` | Switching table↔chart↔pivot no longer resets data |
| Notification bell | `Layout.tsx` | Persistent badge with unread count |
| WebSocket heartbeat | `WebSocketContext.tsx` | Ping/pong + 45s reconnect |
| Admin grid column limit | `DataGridViewer.tsx`, `AdminPage.tsx` | Configurable default visible columns |
| Join cross-tab fix | `CompleteQueryBuilder.tsx` | Auto-suggest only fires when modal is open |
| Join snapshot fix | `CompleteQueryBuilder.tsx` | Multi-condition joins + suffix preserved on restore |
| Table restore fix | `CompleteQueryBuilder.tsx` | Joined tables included in selectedTables on reload |
| Connection race fix | `CompleteQueryBuilder.tsx` | registeredTables populated after connections load |
| DuckDB thread cap | `data_grid_api.py`, `config.py` | Per-query thread limit (default 4) prevents CPU over-subscription |
| DuckDB memory cap | `data_grid_api.py`, `config.py` | Per-query memory limit (default 2GB) prevents OOM |
| Admin query engine settings | `AdminPage.tsx`, `main.py` | DuckDB threads, memory, timeout, concurrency — all admin-configurable |
| Admin page redesign | `AdminPage.tsx` | Two-panel layout: left nav sidebar (4 groups, 10 items) + right content panel. Section-aware polling — only active section polls. Lazy loading on first visit. |
| Enterprise reports | `reports_api.py`, `base.py`, `trino_connector.py`, `snowflake_connector.py`, `cross_source_engine.py`, `database.py`, `ReportsManagerPage.tsx`, `api.ts` | Auto-partition detection (Trino DDL, Snowflake clustering, Hive-style S3). Auto-WHERE generation for SQL reports (unreferenced partition params auto-injected as subquery filter). Hybrid SQL+Parquet cross-source joins. Result caching with TTL. Execution history. Excel export. Scheduled report delivery via APScheduler + email. |
| Connector cursor fixes | `snowflake_connector.py`, `trino_connector.py` | All cursor operations wrapped in try/finally to prevent resource leaks |
| Enterprise reports bug audit | `reports_api.py`, `cross_source_engine.py`, `scheduler.py` | Fixed 5 bugs: get_scheduler() added to scheduler.py, ParquetEngine for get_file_schema, send_email (not send_email_with_attachment), pattern= (not regex=), removed invalid offset param from QueryConfig |
| Redis optional queue backend (19A-19B) | `queue_backend.py` (NEW), `config.py`, `main.py`, `executor_worker.py`, `scheduler_worker.py`, `executor_poller.py`, `notification_poller.py`, `cli.py`, `AdminPage.tsx` | Strategy pattern: TaskQueueBackend ABC with SQLite (passthrough) and Redis (sorted sets + hashes + pub/sub) implementations. BZPOPMIN blocking claim for instant delivery. Priority queues (score = priority*1e9+ts). Event-driven WS broadcast via pub/sub subscribers (replaces DB polling). Graceful fallback to SQLite if Redis unavailable. Admin page queue config section with backend switch, Redis URL/auth/SSL settings, test connectivity button, live status. Config-driven via config.json queue section. CLI info/validation updated. |
| Redis queue audit fixes | `queue_backend.py`, `main.py` | Fixed critical bug: `db_manager.Session` → `db_manager.SessionLocal` (would crash default SQLite path). Added `finished` sorted set for completed/failed task tracking in Redis. Redis test endpoint now closes connection. Removed unused import. |
| Phase 19C-19E: Nginx + multi-scaling | `nginx/nginx.conf`, `docker-compose.scale.yml` | Nginx least_conn LB (3 API instances), WebSocket /ws, JSON logs, 300s timeouts. docker-compose.scale.yml: 3 API + nginx + 1 scheduler + 3 executors + Redis with health checks and named volumes. |
| Phase 19G: Wait mode | `main.py` | `wait=true` + `wait_timeout` fields on POST /api/execute. Polls execution status until done or timeout, returns inline result. Works with external executor mode. |
| Phase 19I: Webhook callbacks | `main.py`, `executor_worker.py` | `callback_url` field on POST /api/execute. Stored in task payload. Executor fires HTTP POST on complete/failed/cancelled via daemon thread (best-effort, 15s timeout). |
| Phase 19J: Queue depth monitoring | `main.py` | GET /api/admin/queue/depths: totals by status, by-type breakdown, priority buckets (high/normal/low), oldest pending task age. Works with both SQLite and Redis backends. |
| Phase 20A-20G: K8s/OpenShift Helm chart | `k8s/helm/` (11 files) | Chart.yaml, values.yaml, _helpers.tpl, deployments (webserver/scheduler/executor), services, OpenShift Route + Ingress alternative, PVCs (ReadWriteMany data + Redis), HPA (CPU+memory, conservative scale-down), Redis StatefulSet, ConfigMap, Secret. |
| Phase 21A-21E: Observability | `main.py`, `requirements.txt`, `core/config.py`, `monitoring/grafana/` | /metrics already wired (confirmed). Grafana dashboard JSON (7 panels). OpenTelemetry OTLP tracing wired in _setup_otel() — config-driven, graceful no-op. Confirmed X-Request-ID middleware + JSON logging already in production. |
| Phase 19H: Batch submit | `main.py` | `POST /api/jobs/submit-batch`: BatchQueryItem + BatchSubmitRequest models, up to 50 queries, returns array of execution_ids with per-query errors. |
| Phase 22B: Rate limiting | `core/rate_limiter.py` (NEW), `main.py` | `check_rate_limit()`: Redis sorted set sliding window + in-process deque fallback. `RateLimitExceededError` with retry_after. Wired into `/api/execute` (60 req/min). |
| Phase 22C: DLQ + backoff | `core/database.py`, `executor_worker.py`, `core/queue_backend.py`, `main.py` | `DeadLetterQueue` ORM model. `push_dead_letter`/`list_dead_letter`/`resolve_dead_letter`. Exponential backoff in executor (30×2^n, max 1800s). `delay_seconds` in all queue backends (SQLite: `next_retry_at`, Redis: `delayed` sorted set + `_promote_delayed_tasks()`). DLQ admin endpoints: list/resolve/requeue. |
| Phase 22D: Test suite | `tests/conftest.py`, `tests/test_config.py`, `tests/test_queue_backend.py`, `tests/test_health.py`, `tests/test_date_resolver.py` | Shared fixtures (db_manager, sqlite_task_queue). Config defaults, rate limiter sliding window, SQLite queue lifecycle (enqueue/claim/complete/fail/progress/cancel/DLQ), Redis tests (skip if unavailable), FastAPI health endpoints, date resolver. |
| Phase 22E: API versioning | `main.py` | `API_VERSION = "2.0.0"`, `API_MAJOR = "v2"`. `X-API-Version: v2` on all responses via middleware. `GET /api/version` endpoint. |
| Phase 23A: Report Catalog | `core/database.py`, `api/catalog_api.py` | 15 new ORM models (ReportFolder, ReportTag, ReportTagAssignment, ReportFavorite, ReportView + 10 more). Folder hierarchy (parent/child), tag management, per-user favorites, recently-viewed tracking (20 max), full-text report search. 12 REST endpoints. |
| Phase 23G: Row-Level Security | `core/database.py`, `api/enterprise_reports_api.py` | RLSPolicy model. Column-level WHERE injection at report execution time. Token resolution ({username}, {department}). IN/NOT IN operators. Admin-only CRUD + preview endpoint. |
| Phase 23B: Report Bookmarks | `core/database.py`, `api/enterprise_reports_api.py` | ReportBookmark model. Save/list/delete named parameter sets per user per report. |
| Phase 23D: PDF Export | `api/pdf_export_api.py`, `api/reports_api.py`, `requirements.txt` | WeasyPrint HTML→PDF. Cover page, header/footer, page numbers, conditional formatting applied to cells. ReportPDFConfig per report (orientation, paper size, font, max rows). Graceful 501 if WeasyPrint not installed. `_execute_report_sync()` bridge function in reports_api. |
| Phase 23E: Report Bursting | `core/database.py`, `api/burst_api.py` | BurstJob + BurstTask models. Auto-detects distinct values of burst_column. One report execution per value, output to email or S3. Background thread runner with cancel support. Progress tracking (total/done/failed). |
| Phase 23F: Threshold Alerts | `core/database.py`, `api/enterprise_reports_api.py` | AlertRule + AlertHistory models. Column aggregations (last/sum/avg/max/min/count). Operators >, <, >=, <=, =, !=. Cooldown suppression. Email (smtp) + Slack webhook channels. `evaluate_alert_rules()` auto-called after execution. |
| Phase 23C: Conditional Formatting | `core/database.py`, `api/enterprise_reports_api.py` | ConditionalFormatRule model. value_range / equals / contains / not_null / is_null rules per column. bg_color, text_color, icon, bold. Applied in DataGridViewer AND PDF export. |
| Phase 23H: Cloud Delivery | `core/database.py`, `api/enterprise_reports_api.py` | CloudDeliveryConfig + DeliveryHistory models. S3/Azure/GCS delivery per schedule. ZIP bundle option. Delivery history with status tracking. Wired into burst delivery. |
| Phase 23 Frontend | `frontend/src/components/ReportCatalogPage.tsx` (NEW), `ReportsManagerPage.tsx`, `AdminPage.tsx`, `Layout.tsx`, `App.tsx`, `api.ts` | **ReportCatalogPage**: folder tree sidebar (recursive, create/rename/delete), tag filter chips, Favorites/Recent/All view modes, debounced full-text search, responsive report card grid (star toggle, tag chips, Run button → auto-selects in manager). **ReportsManagerPage**: PDF download button (WeasyPrint), bookmarks bar (save/load named param sets as chips), BurstDialog (burst column + delivery type + format), AlertRulesDialog (list/create/delete threshold rules per column), ConditionalFormattingDialog (column → bg/text color rules), More ⋮ menu. Auto-selects report from ?reportId URL param (deep-link from catalog). **AdminPage**: RLSAdminSection — report picker + policy table (column, operator, value_template, toggle enable, delete), add-policy inline form. **api.ts**: 35 new Phase 23 endpoint functions (catalog, folders, tags, favorites, PDF, bookmarks, formatting, alerts, burst, RLS). Build verified clean (Vite + TS). |
| Phase 24A | `backend/core/database.py`, `backend/api/reports_api.py`, `frontend/src/components/ReportsManagerPage.tsx` | **DB**: `connection_override_id INTEGER` nullable column on `reports` table + SQLite migration entry. **Backend**: `_resolve_primary_connection(report, sql_q)` helper (priority 1: override, priority 2: query default, then profile mapping). `_run_sql_report` uses helper. `CreateReportRequest`/`UpdateReportRequest` + `connection_override_id`. `0` normalised to `None` on PUT. **Frontend**: connection override Select dropdown in ReportDialog (SQL reports only, SQL-type connections); "Override Active" Chip on selected report header; `connection_override_id` in save payload. |
| Phase 24B | `backend/core/database.py`, `backend/api/connection_profiles_api.py` (NEW), `backend/main.py`, `frontend/src/components/AdminPage.tsx`, `frontend/src/components/ReportsManagerPage.tsx`, `frontend/src/context/AppSettingsContext.tsx`, `frontend/src/services/api.ts` | **DB**: `ConnectionProfile` + `ConnectionProfileMapping` ORM models (new tables, `create_all`). 10 DB manager methods: list, get_active, create, update, activate (exclusive), deactivate_all, delete, get_mappings, set_mappings (atomic replace), resolve_connection_via_profile. **Backend**: 9 REST endpoints (list/create/update/delete/activate/deactivate/active/mappings GET+PUT). `main.py`: router wired, app-settings extended with `active_connection_profile`. **Frontend**: `AppSettings` interface + `active_connection_profile`. Admin ConnectionProfilesAdminSection (profile table, activate/deactivate, new-profile dialog, mapping-editor dialog with source→target rows). Active profile yellow Alert banner in ReportsManagerPage. **api.ts**: 9 new functions. |
| Phase 24C | `backend/api/reports_api.py`, `frontend/src/components/ReportConnectorsPage.tsx` (NEW), `frontend/src/App.tsx`, `frontend/src/components/Layout.tsx`, `frontend/src/services/api.ts` | **Backend**: `GET /api/reports/connector-matrix` (enriched report list: assigned/override/effective/profile_mapped connections). `POST /api/reports/bulk-set-connection-override` (admin only, batch update). **Frontend**: `ReportConnectorsPage.tsx` — matrix table, inline override Select per SQL row (optimistic update + rollback), checkbox multi-select, bulk toolbar (Set/Clear Override), BulkReassignDialog, filter bar (source type / connection / name search), active profile Chip in header. `App.tsx` route + `Layout.tsx` nav (SwapHoriz icon, admin+analyst only). **api.ts**: `getReportConnectorMatrix` + `bulkSetConnectionOverride`. Build verified clean. |
| Phase 25A | `backend/core/database.py` | **DB**: `Workspace` + `WorkspaceMember` ORM models (new tables). 8 `ALTER TABLE ADD COLUMN workspace_id INTEGER` migrations for connections, saved_queries, sql_saved_queries, reports, dashboards, schedules, materialized_views, local_tables. 10 DB manager methods: `ensure_default_workspace`, `list_workspaces`, `get_workspace`, `create_workspace` (auto-adds creator as owner), `update_workspace`, `delete_workspace` (soft), `list_workspace_members`, `add_workspace_member` (upsert), `update_workspace_member_role`, `remove_workspace_member`. |
| Phase 25B | `backend/api/workspaces_api.py` (NEW), `backend/main.py` | **Backend**: 9 REST endpoints (CRUD + member management). `_slugify()` helper. `main.py`: router wired, `set_workspace_dependencies()` + `ensure_default_workspace()` on startup. `GET /api/app-settings` extended with `workspaces: [...]`. |
| Phase 25C | `frontend/src/context/AppSettingsContext.tsx`, `frontend/src/context/WorkspaceContext.tsx` (NEW), `frontend/src/App.tsx`, `frontend/src/components/Layout.tsx`, `frontend/src/components/AdminPage.tsx`, `frontend/src/services/api.ts` | **Frontend**: `WorkspaceInfo` + `workspaces` in `AppSettings`. `WorkspaceContext` with `activeWorkspaceId` (localStorage `qs_workspace_id`). `WorkspaceProvider` wrapping `WebSocketProvider` in App.tsx. Layout AppBar workspace switcher chip + Menu. Admin `WorkspaceAdminSection` (workspace table + new-dialog + member editor). **api.ts**: 8 workspace CRUD + member functions. |
| Phase 26A | `backend/api/lineage_api.py` (NEW), `backend/main.py` | **Backend**: 4 endpoints computing lineage from existing FKs — `GET /api/lineage/connection/{id}`, `/report/{id}`, `/query/{id}?type=sql\|parquet`, `/graph`. Full graph as `{ nodes[], edges[] }` with composite IDs `type:id`. Internal helpers for each entity type. `main.py`: router + `set_lineage_dependencies()` wired on startup. |
| Phase 26B | `frontend/src/components/LineagePage.tsx` (NEW), `frontend/src/App.tsx`, `frontend/src/components/Layout.tsx`, `frontend/src/services/api.ts` | **Frontend**: `LineagePage` — search bar, entity type chips, left node list + right detail panel, recursive tree renderer (MUI Accordion + Box indenting), colour-coded node chips, upstream/downstream toggle tabs. `App.tsx` route `/lineage`. Layout nav item (AccountTreeIcon, DATA SOURCES group, admin+analyst). **api.ts**: 4 lineage functions. |
| Phase 27A | `backend/core/database.py` | **DB**: `ReportEmbedToken` ORM model (new table). 5 DB manager methods: `create_report_embed_token`, `get_embed_token`, `list_embed_tokens`, `revoke_embed_token`, `increment_embed_token_access`. |
| Phase 27B | `backend/api/embed_api.py` (NEW), `backend/main.py` | **Backend**: 5 endpoints — `POST /api/reports/{id}/embed-tokens`, `GET /api/reports/{id}/embed-tokens`, `DELETE /api/reports/embed-tokens/{token}`, `GET /api/embedded-report/{token}` (PUBLIC), `POST /api/embedded-report/{token}/execute` (PUBLIC). HTTP 410 on expired. `_require_execute_access` extended with `x_embed_token` header. Router wired + startup. |
| Phase 27C | `frontend/src/components/EmbeddedReportPage.tsx` (NEW), `frontend/src/App.tsx`, `frontend/src/components/ReportsManagerPage.tsx`, `frontend/src/services/api.ts` | **Frontend**: `EmbeddedReportPage` — no-auth/no-nav iframe page, compact header, param form, inline HTML table, 410/404 error states. `App.tsx` public route `/embed/:token`. `ReportsManagerPage` "Embed Report" option in More menu → `EmbedDialog` (list tokens with status/expiry/views, create with expiry picker, iframe snippet with copy, revoke). **api.ts**: 5 embed functions. |
| Phase 28A | `backend/core/database.py` | **DB**: 3 new DB manager methods — `get_audit_log_filtered` (date_from/to/resource_type params), `get_data_access_summary` (per-user execution+export aggregates), `get_user_data_export` (all user data for GDPR). |
| Phase 28B | `backend/main.py` | **Backend**: Extended `GET /api/admin/audit-log` with `resource_type`, `date_from`, `date_to` params. New endpoints: `GET /api/admin/audit-log/export` (CSV StreamingResponse), `GET /api/admin/audit-log/data-access-summary`, `POST /api/admin/compliance/subject-export` (GDPR ZIP via `zipfile`). |
| Phase 28C | `frontend/src/components/AdminPage.tsx`, `frontend/src/services/api.ts` | **Frontend**: `AuditComplianceAdminSection` with 3 tabs — Audit Log (filters: username/action/resource_type/date range, paginated table, Export CSV), Data Access (per-user stats table), GDPR Export (username input + Generate ZIP). Added to `AdminSection` union, `ADMIN_SECTIONS` SYSTEM group, `GppGoodIcon`. **api.ts**: `getAuditLogFiltered`, `exportAuditLog`, `getDataAccessSummary`, `generateSubjectExport`. Build verified clean. |
| Phase 29A | `backend/core/sessions.py` (NEW), `backend/api/deps.py` (NEW), `backend/core/execution_state.py` (NEW) | **Foundation**: `sessions.py` — standalone session store (token TTL, prune, max-session cap) with backwards-compat aliases `_create_session`, `_get_session`, `_destroy_session`. `deps.py` — unified auth FastAPI dependency module: `init_deps(auth_cfg, db_manager)`, `get_current_user`, `require_admin`, `require_role`, `require_execute_access`, `is_owner_or_shared` — used by all new Phase 29 routers. `execution_state.py` — shared module-level execution state (`running_tasks`, `cancellation_flags`, `inflight_queries`, `user_query_counts`, `user_query_lock`, global semaphore accessors, queue count with thread-safe increment/decrement). |
| Phase 29B | `backend/api/auth_api.py` (NEW), `backend/api/notifications_api.py` (NEW), `backend/api/system_api.py` (NEW) | **Small routers**: `auth_api` — 4 auth endpoints (login, logout, me, config) with sliding-window rate-limit on login. `notifications_api` — 4 notification endpoints (list, unread-count, read-all, read-one; static `read-all` declared before parameterised `{notif_id}` to avoid routing conflict). `system_api` — 3 system endpoints (version, `/metrics` Prometheus scrape, `/health` DB+disk+S3+pool check). All use `set_*_dependencies()` injection pattern. |
| Phase 29C | `backend/api/admin_api.py` (NEW) | **Admin router** (1,425 lines): 40 endpoints — storage stats, active queries, user stats, query ETA, worker pool config, app config, queue config, DLQ, batch submit, app-settings, scheduler proxy, audit log (extended filters), audit CSV export, data-access summary, GDPR subject export, users CRUD, cache stats/clear/invalidate, webhooks CRUD, exports list, executions admin. Pydantic models: `WorkerPoolConfigUpdate`, `AppConfigUpdateRequest`, `QueueConfigUpdateRequest`, `_UserPayload`, `CacheInvalidateSourceRequest`, `_SubjectExportRequest`, `_BatchSubmitRequest`. |
| Phase 29D | `backend/api/connections_api.py` (NEW) | **Connections router** (1,414 lines): 28 endpoints — full connection CRUD, test, files/schema, table CRUD, table schema/refresh, partition management, discover-tables, browse-folders, Iceberg tables/files, connection file upload (POST/GET/DELETE). Schema cache + partition cache helpers. `set_connection_dependencies(db_manager, engine, conn_manager, paths, auth_cfg, lt_cfg)`. |
| Phase 29E | `backend/api/queries_api.py` (NEW) | **Queries router** (~1,000 lines): 34 endpoints — file listing/upload, S3 configure/test/folders/files, query CRUD (save/list/get/update/delete), query versions, shares, dashboard shares, shared-token public pages, joins preview, SQL preview, downloads list/delete, executions list/get/status/cancel. All shared Pydantic models (`QueryConfigModel`, `JoinConfigModel`, `FilterModel`, `OrderByModel`, `AggregationModel`, etc.) + `convert_query_config_to_engine` helper. Note: `/api/queries/execute` streaming engine kept in main.py. |
| Phase 29F | `backend/api/materialized_views_api.py` (NEW) | **Materialized views router** (465 lines): 9 endpoints (CRUD + refresh + preview + stats + partitions). `_refresh_materialized_view_sync`, `_setup_mv_schedule`, `_remove_mv_schedule` helpers. `_register_s3_views` module-level placeholder — wired to main.py function at startup. |
| Phase 29G | `backend/api/local_tables_api.py` (NEW) | **Local tables router** (724 lines): 8 local table CRUD endpoints + 4 table-ops endpoints (preview/profile/favorite/favorites). `_promote_download_sync`, `_upload_file_to_local_table_sync`, `_cleanup_expired_local_tables`, `_resolve_table_duckdb_sql` helpers. |
| Phase 29H | `backend/main.py` | **main.py cleanup**: Added Phase 29 router imports (8 new routers + `execution_state` module). Added `app.include_router()` for all 8 new routers. Added `set_*_dependencies()` calls + `api.deps.init_deps()` in `_startup()`. Removed 3,859 lines of duplicated endpoint code (131 endpoint blocks). main.py reduced from 9,405 → 5,547 lines (41% reduction). Execute engine (`/api/queries/execute` + streaming) kept in main.py. All syntax checks pass. |

---

## Phase 29: Enterprise Architecture Refactoring — DONE

| # | Feature | Status |
|---|---------|--------|
| 29A | Foundation modules: `core/sessions.py`, `api/deps.py`, `core/execution_state.py` | **DONE** |
| 29B | Small routers: `auth_api.py`, `notifications_api.py`, `system_api.py` | **DONE** |
| 29C | Admin router: `admin_api.py` (40 endpoints) | **DONE** |
| 29D | Connections router: `connections_api.py` (28 endpoints) | **DONE** |
| 29E | Queries router: `queries_api.py` (34 endpoints) | **DONE** |
| 29F | Materialized views router: `materialized_views_api.py` (9 endpoints) | **DONE** |
| 29G | Local tables router: `local_tables_api.py` (12 endpoints) | **DONE** |
| 29H | main.py wiring + endpoint removal (9,405 → 5,547 lines, −41%) | **DONE** |

---

## Phase 28: Audit & Compliance — DONE

| # | Feature | Status |
|---|---------|--------|
| 28A | `get_audit_log_filtered` + `get_data_access_summary` + `get_user_data_export` DB methods | **DONE** |
| 28B | Extended audit-log endpoint (date/resource_type filters) + CSV export + data access summary + GDPR ZIP | **DONE** |
| 28C | `AuditComplianceAdminSection` (3 tabs: Audit Log, Data Access, GDPR Export) + api.ts | **DONE** |

---

## Phase 27: Embedded Reports — DONE

| # | Feature | Status |
|---|---------|--------|
| 27A | `ReportEmbedToken` ORM model + 5 DB manager methods | **DONE** |
| 27B | `embed_api.py` (5 endpoints, 2 public) + `_require_execute_access` embed-token support | **DONE** |
| 27C | `EmbeddedReportPage.tsx` (public no-auth) + public route + EmbedDialog in ReportsManagerPage | **DONE** |

---

## Phase 26: Data Lineage — DONE

| # | Feature | Status |
|---|---------|--------|
| 26A | `lineage_api.py` (4 endpoints, computed from existing FKs) | **DONE** |
| 26B | `LineagePage.tsx` (search, colour-coded tree, upstream/downstream tabs) + nav item | **DONE** |

---

## Phase 25: Workspaces — DONE

| # | Feature | Status |
|---|---------|--------|
| 25A | `Workspace` + `WorkspaceMember` ORM models + 8 entity migrations + 10 DB methods | **DONE** |
| 25B | `workspaces_api.py` (9 endpoints) + main.py wiring + ensure_default_workspace startup | **DONE** |
| 25C | `WorkspaceContext` + AppBar switcher + AdminPage WorkspaceAdminSection + api.ts | **DONE** |

---

## Phase 24: Report Connectors — DONE

| # | Feature | Status |
|---|---------|--------|
| 24A | Direct Connection Override — nullable `connection_override_id` on Report; `_resolve_primary_connection()` helper; override picker in ReportDialog; "Override Active" chip | **DONE** |
| 24B | Connection Profiles — named environment groups (dev/staging/prod); one active at a time; source→target mapping; `ConnectionProfile` + `ConnectionProfileMapping` ORM models; 10 DB manager methods; 9 REST endpoints (`connection_profiles_api.py`); Admin section with profile table + mapping editor dialog; active profile banner in ReportsManagerPage; `app-settings` extended | **DONE** |
| 24C | Report Connectors Matrix — enriched report list (assigned/override/effective/profile_mapped connections); `GET /api/reports/connector-matrix`; `POST /api/reports/bulk-set-connection-override`; `ReportConnectorsPage.tsx` (inline override select, checkbox bulk actions, filter bar, active profile chip); nav item + route | **DONE** |

---

## Phase 23: Enterprise Reporting Framework — DONE (Backend + Frontend)

| # | Feature | Status |
|---|---------|--------|
| 23A | Report Catalog — folder hierarchy, tags, favorites, recently viewed, full-text search | **DONE** |
| 23B | Advanced Parameters — cascading (depends_on JSON field), saved bookmarks per user | **DONE** |
| 23C | Conditional Formatting — cell color/icon rules per column, applied in grid + PDF | **DONE** |
| 23D | PDF Export — WeasyPrint, cover page, header/footer, page numbers, conditional styles | **DONE** |
| 23E | Report Bursting — per-dimension slice + delivery (email/S3), progress tracking, cancel | **DONE** |
| 23F | Threshold Alerts — metric rules, email/Slack, cooldown, alert history | **DONE** |
| 23G | Row-Level Security — WHERE clause injection by user attributes, admin CRUD | **DONE** |
| 23H | Cloud Delivery — S3/Azure/GCS output per schedule, ZIP bundle, delivery history | **DONE** |

---

## Post-Phase Bug Fixes (March 2026)

| # | Bug | Fix | Files |
|---|-----|-----|-------|
| BF-01 | `api.getFullLineageGraph is not a function` | Added 4 lineage functions to `api.ts` | `api.ts` |
| BF-02 | 403 on POST `/api/connection-profiles` | `_get_user()` returned no role field | `connection_profiles_api.py` |
| BF-03 | `_auth_cfg.get(...)` AttributeError in new routers | `_AuthCfg` is a class with `.type` property, not a dict | `workspaces_api.py`, `embed_api.py`, `main.py` |
| BF-04 | Parametric report param fields stacked vertically | MUI v7 removed `item`/`xs` props — must use `size={N}` | `ReportsManagerPage.tsx`, `SchedulesPage.tsx` |
| BF-05 | Multiselect source_column picker always empty | `ParquetEngine(data_dir=...)` wrong kwarg (should be `base_path`) → silent TypeError | `reports_api.py` |
| BF-06 | No columns in create-mode param dialog | Fragile file-schema chain in frontend; replaced with new `GET /api/reports/preview-columns` endpoint | `reports_api.py`, `api.ts`, `ReportsManagerPage.tsx` |
| BF-07 | Partition params not auto-detected on query select | Auto-suggest effect added: calls `suggestReportParams` when parquet query selected + no params yet | `ReportsManagerPage.tsx` |
| BF-08 | `build_query_sql() missing 1 required positional argument: 'from_clause'` — on-prem S3 queries crash | Refactoring extraction (A3) lost the `from_clause` arg on `build_query_sql()` call and added extra args to `rewrite_registered_refs()` | `duckdb_views.py` |

---

## Stats Summary

---

## Phases 30–35: Enterprise Completion (March 2026)

| Phase | Feature | Status |
|-------|---------|--------|
| 30 | SSO — LDAP/AD auth (`core/ad_auth.py`, login/logout/me endpoints, Bearer sessions, RBAC group mapping) | **DONE** |
| 31 | OIDC/SAML — Not needed (LDAP-based SSO covers requirements) | **N/A** |
| 32 | Integration test suite (5 new test files, 120+ tests passing, conftest.py with temp DB isolation) | **DONE** |
| 33 | Query federation push-down (Starburst/Trino/Snowflake/Databricks/Oracle already in main.py) | **DONE (pre-existing)** |
| 34 | Frontend bundle splitting (`vite.config.ts` manualChunks, `App.tsx` lazy() for Admin/Lineage/Catalog pages) | **DONE** |
| 35 | Production hardening (SQLAlchemy 2.0 fix, requirements.txt optional extras, OpenAPI tags on all routers) | **DONE** |

### Phases 36–48 — Performance, Robustness, Scalability & Intelligence

| # | Feature | Status |
|---|---------|--------|
| 36 | Query result caching enhancement (`core/query_cache.py` — file_mod_times in cache key, connection-based invalidation, hit_count tracking, admin endpoints) | **DONE** |
| 37 | Circuit breaker per connection (`core/circuit_breaker.py` — CLOSED/OPEN/HALF_OPEN states, auto-recovery, WebSocket broadcast, admin endpoints) | **DONE** |
| 38 | Scheduled report anomaly detection (`core/anomaly_detector.py` — z-score analysis, ScheduleRunStats model, WebSocket alerts, admin/schedule endpoints) | **DONE** |
| 39 | Idempotent execution IDs (`execution_state.py` — client-generated UUID dedup, 10min TTL, frontend `crypto.randomUUID()`) | **DONE** |
| 40 | Connection pooling per connector (`core/connection_pool.py` — pool per connection_id, idle eviction, context manager, admin stats endpoint) | **DONE** |
| 41 | Query checkpointing & resume (`core/checkpoint.py` — intent/running state recording, orphan recovery on startup, all 3 execution paths covered) | **DONE** |
| 42 | Arrow IPC response format (`api/arrow_api.py` — paginated Arrow IPC stream, 3-5x faster transfer, `getExecutionResultsArrow` frontend method) | **DONE** |
| 43 | Read replica separation (SQLite WAL + PostgreSQL read replicas) | Planned |
| 44 | S3 result auto-tiering (auto-upload large results to S3, lazy page download) | Planned |
| 45 | Horizontal query workers (Redis-backed worker scaling, heartbeat, auto-registration) | Planned |
| 46 | Query auto-suggest from usage (table/column co-occurrence tracking) | **DONE** |
| 47 | Smart query analysis — pre-execution rule warnings (anti-pattern detection) | **DONE** |
| 48 | Natural language to SQL — pattern-based engine (no LLM), chat UI | **DONE** |
| 49 | Table-level lineage & SQL parsing (sqlglot AST, impact analysis) | **DONE** |
| 50 | Interactive lineage graph visualization (React Flow + dagre DAG, Graph/List tabs) | **DONE** |
| 51 | Column-level lineage (sqlglot.lineage, transform classification, DetailPanel tab) | **DONE** |
| 52 | Lineage history & data freshness (snapshots, stale monitoring, diff view) | **DONE** |

| 53 | **Semantic Layer** *(BO Universe equivalent)* — `BusinessDataset`, `DatasetColumn` (type: dimension/measure/detail/kpi), `DatasetClass` (logical grouping), `DatasetRelationship`, `DrillHierarchy` (Year→Quarter→Month→Day), pre-defined reusable conditions (drag-in WHERE clauses), aggregation awareness mapping | **PLANNED** |
| 54 | **Cross-Source Federation Engine** — `federation_engine.py`; DuckDB named secrets (S3 cloud + S3 on-prem, separate credentials); multiple data providers (2 datasets merged on shared dimension — not JOIN); `/api/datasets/{id}/execute` | **PLANNED** |
| 55 | **Aggregation Cache & Smart Routing** — `agg_cache.py`; pre-computed rollup parquets on schedule; aggregation awareness auto-routes to correct pre-agg table; admin trigger + status; 100M+ rows → sub-second | **COMPLETE** |
| 56 | **Business Report Builder** *(BO WebI + Tableau + Power BI)* — `BusinessReportBuilder.tsx`; cascading prompts (Country→Region→City LOVs); BO-style breaks/sections/subtotals; post-query running calcs (RunningSum, Rank, Percentage, Previous); Power BI slicer cross-filter; Tableau drill hierarchy; no SQL visible to viewer | **COMPLETE** |
| 57 | **Enhanced NL Chatbot** — 23 patterns (12 new): YTD, MTD, SPLY, period-over-period, running total, % of total, growth rate, moving average, rank, conditional aggregate, ratio, pre-defined condition match; `SemanticSchemaContext` with friendly names, synonyms, typed columns; `build_semantic_context()` + `enrich_from_schema_cache()`; 3 API paths (semantic/schema-cache/plain); admin config; 34 tests | **COMPLETE** |
| 58 | **Report Catalog & Certified Templates** — `ReportCatalog.tsx`; admin ✓ certified badge; clone-to-workspace; shareable links; embed `<iframe>` code | **PLANNED** |
| 59 | **Business User Portal** — `BusinessPortal.tsx`; role-based landing for viewer; My Reports / Catalog / Ask nav; pinned; mobile-responsive | **PLANNED** |
| 60 | **Delivery & Alerts** — `delivery_engine.py`; PDF/Excel/CSV email subscriptions (cron-based); threshold alert evaluation on scheduled job completion; `ReportSubscription` (17 fields) + `SubscriptionDelivery` (8 fields); `SubscriptionManager.tsx` (3-tab dialog); unsubscribe tokens; retry with backoff; admin delivery config; 27 tests | **COMPLETE** |

---

## Extra Features (not part of numbered phases)

| Feature | Status | Summary |
|---------|--------|---------|
| GlobalAssistantPanel — comprehensive intents | **DONE** | 9 intents: greet, help, data, schema, tables, analyze, docs, nl2sql, griddata. Added running total, date filters (YTD/MTD/last 7/30/90d/quarter), Show SQL chip, Copy SQL, Open in Editor, Export CSV. Fixed 6 intent routing & regex bugs. |
| Stale-result fallback | **DONE** | On S3/connection failure, serves last known-good parquet file. `_CONN_ERROR_PATTERNS` + `_is_connection_error()` in main.py; `get_stale_cached_result()` in query_cache.py; `get_last_successful_output_file()` in database.py. Amber alert in UI. |
| Admin UI Component Visibility | **DONE** | `UIComponentVisibility` model in database.py; `GET/PUT /api/admin/ui-visibility` in admin_api.py; `component_visibility` added to `/api/app-settings`; `UIVisibilityContext.tsx` + `useComponentVisible()`; `ComponentDisabledGuard` wraps all routes; Layout sidebar respects visibility; Admin Panel "UI Visibility" section with checkbox grid per role. |
| Column Patterns Config | **DONE** | `frontend/src/config/columnPatterns.ts` — editable per-org patterns for numeric/category/date/ID columns; imported by GlobalAssistantPanel for chip generation and chart suggestions. |
| S3 Iceberg Cache Fix | **DONE** | Fixed cross-contamination between execute and stream code paths storing different formats (dict vs string) in shared Iceberg file cache. All cache reads now normalize format. |
| EXCLUDE Schema Evolution Fix | **DONE** | `_fix_stale_excludes()` validates EXCLUDE columns against actual DuckDB view schema at runtime. Strips columns removed by Iceberg schema evolution. Applied to all 5 stream endpoints. |
| Partition Auto-Load | **DONE** | Iceberg partition filters pre-fetched for ALL registered tables on S3 connection select (not just on table click). Auto-expand panels. Background refinement. Theme-aware header (white on primary). |
| Chatbot Component Visibility | **DONE** | Added `chatbot` to `KNOWN_COMPONENTS` in admin_api.py. FAB button in Layout.tsx gated by `useComponentVisible('chatbot')`. Admin can hide/show chatbot per role. |
| On-Prem S3 (MinIO) Support | **DONE** | `path_style` addressing for DuckDB (`SET s3_url_style='path'`) + boto3 (`addressing_style: 'path'`). Fixed `duckdb_subprocess.py` HTTPS path_style. Fixed S3Config in `s3_storage.py` (build_s3_config, upload, download). |
| Hive-Partitioned Plain Parquet | **DONE** | Browse & Register detects hive-partitioned folders (purple badge in ConnectionManager). `_extract_hive_partition_values()` in connections_api.py scans S3 folder structure → returns Iceberg-compatible shape `{name, source_column, type, transform}`. Partition selector UI works identically for both Iceberg and parquet. |
| boto3 Pre-Listing (DuckDB Glob Crash Fix) | **DONE** | Replaced `read_parquet('s3://…/**/*.parquet')` glob with boto3 `list_objects_v2` paginator in 7 locations (main.py: `_register_s3_views`, `_setup_registered_views`, subprocess, `_fetch_schema_from_s3`, `_resolve_table_source`; connections_api.py: `_fetch_schema_from_s3`; federation_engine.py: `_table_to_expression`). `_list_s3_parquet_files()` helper with 5000-file safety cap. Prevents C-level DuckDB crashes on on-prem S3. |
| Cross-Source Federation Fix | **DONE** | Fixed DuckDB `CREATE SECRET` SCOPE syntax (was outside parentheses — DuckDB 1.4.4 requires inside). Named secrets now scope correctly per bucket for multi-S3-endpoint federation. |
| DataFreshness Connection Scoping | **DONE** | Changed unique constraint from `table_fqn` alone to `(table_fqn, connection_id)` in database.py. Same-named tables on different S3 endpoints no longer clash. |
| Partition Cache Shape Validation | **DONE** | `_valid_partition_shape()` auto-detects old wrong-format cache entries (flat strings instead of objects) and treats them as cache miss → re-fetches correct shape. No manual cache clearing needed. |
| Configurable Partition Cache TTLs | **DONE** | `partition_cache` section in config.json + `_PartitionCacheCfg` in config.py. L1 TTL (default 5min), L2 TTL (default 5h), L1 max entries (default 100). Admin endpoints: `GET/PUT /api/admin/partition-cache/config`. Runtime-changeable, no restart. |
| Light Mode Theme Fix | **DONE** | Removed `action: undefined` from dark palette that crashed MUI's action object. Safe spread patterns for MuiPaper/MuiDialog. DataGridViewer + Layout theme token fixes. |
| Streaming Join Fix | **DONE** | Fixed "binder error" in streaming join mode — prefix handling, alias translation, refs filter. |
| Streaming Row Count | **DONE** | Row count now shown during streaming mode execution. |

---

## Round 1: main.py Refactoring — DONE

Goal: Reduce main.py complexity through safe, incremental extractions. No functional changes — pure refactoring with full test coverage maintained.

| # | Round | Scope | Status | Details |
|---|-------|-------|--------|---------|
| A1 | Low-Risk Extractions | Pydantic models, error detection, Iceberg cache, S3 utilities, query converter | **DONE** | main.py reduced from 6,704 → 5,801 lines (903 lines extracted). 5 new modules created: `api/models/query_models.py` (41 models, 310 lines), `core/error_detection.py` (100 lines), `core/iceberg_cache.py` (170 lines), `core/s3_utilities.py` (250 lines), `core/query_converter.py` (200 lines). External imports updated in federation_engine.py, scheduler.py, admin_api.py, connections_api.py. All 267 tests pass, 0 regressions. |

---

## Round 2: Chart Improvements (B1 + B2) — DONE

Goal: Expand chart capabilities from 10 to 15 chart types and add interactive features (reference lines, zoom, drill-down, enhanced export).

| # | Round | Scope | Status | Details |
|---|-------|-------|--------|---------|
| B1 | 5 New Chart Types | Donut, Horizontal Bar, Dual Axis, Waterfall, KPI Card | **DONE** | Total chart types now 15. **Donut**: Pie with innerRadius + center total display. **Horizontal Bar**: BarChart layout="vertical", auto-height based on item count. **Dual Axis**: ComposedChart with left Y (bars) + right Y (lines), multi-series. **Waterfall**: Cumulative stacked bars (green positive, red negative, indigo total). **KPI Card**: Pure MUI boxes showing Total, Categories, Average, Top item. |
| B2 | Chart Interactivity | Average reference line, zoom/brush, drill-down, PNG export enhancement | **DONE** | **Average reference line**: toggle in sidebar, dashed red line with value label on all bar/line/area charts. **Zoom/brush**: toggle in sidebar, Recharts Brush component on charts with >15 data points. **Drill-down**: click any bar/pie slice to add filter breadcrumb chip (col=value), click × to remove. **PNG export enhancement**: title (AGG(col) by col) + timestamp watermark on exported images. |
| B4 | Column Intelligence Upgrades | 5 new chart presets, preset cap increase | **DONE** | 5 new presets in `columnIntelligence.ts`: donut composition, waterfall cumulative, KPI card, dual-axis (10x range detection), horizontal bar ranking. Preset cap increased from 5 to 7. |

**Files modified**: `frontend/src/components/DataGridViewer.tsx` (15 chart types, interactivity props, drill-down breadcrumbs, enhanced PNG export), `frontend/src/services/columnIntelligence.ts` (5 new presets, smart dual-axis detection).

---

## Round 3: Bundle Optimization — DONE

Goal: Reduce initial JavaScript bundle size for faster first-load performance.

| # | Task | Status | Details |
|---|------|--------|---------|
| C1 | Remove empty vendor-grid chunk | **DONE** | Eliminated unused `vendor-grid` manual chunk from vite.config.ts. |
| C2 | Lazy-load GlobalAssistantPanel | **DONE** | React.lazy() wrapper in Layout.tsx — 44 KB moved off critical path. |
| C3 | Lazy-load 4 more pages | **DONE** | SqlQueryPage, SchedulesPage, MaterializedViewsPage, LocalTablesPage now lazy-loaded in App.tsx. |
| C4 | Separate @xyflow/react into vendor-flow chunk | **DONE** | Dedicated `vendor-flow` manual chunk in vite.config.ts (166 KB, better long-term cache). |

**Result**: Main `index.js` bundle reduced from 457 KB to 341 KB (-25% / -116 KB initial load).

**Files modified**: `frontend/vite.config.ts` (replaced `vendor-grid` with `vendor-flow`), `frontend/src/App.tsx` (lazy-loaded 4 more pages), `frontend/src/components/Layout.tsx` (lazy-loaded GlobalAssistantPanel).

---

## Round 4: main.py Refactoring — Stream, Views, MV, Execute Extraction — DONE

Goal: Continue main.py complexity reduction by extracting the streaming endpoints, DuckDB view registration, materialized view logic, and execute engine into dedicated modules.

| # | Task | Status | Details |
|---|------|--------|---------|
| A3-stream | Extract execute stream endpoints | **DONE** | Created `api/execute_stream_api.py` (~835 lines) with 5 endpoints: POST /api/execute/stream, /stream/schema, /stream/paginate, /stream/chart-data, /stream/pivot-data. Includes `_fix_stale_excludes()` helper and `_build_inner_sql()` / `_resolve_connection()` / `_get_refs()` shared helpers. Uses `set_stream_dependencies()` injection pattern consistent with Phase 29 architecture. `strip_sql_limit()` moved to `core/query_converter.py`. |
| A2 | Extract DuckDB views + MV manager | **DONE** | Created `core/duckdb_views.py` (~877 lines): DuckDB view registration, `_register_s3_views()`, `_setup_registered_views()`, view-related helpers. Created `core/mv_manager.py` (~457 lines): materialized view refresh logic, `_refresh_materialized_view_sync()`, MV scheduling helpers. |
| A3-execute | Extract execute engine | **DONE** | Created `api/execute_api.py` (~1,600 lines): background workers (`execute_query_background`, `execute_sql_connector_background`, `execute_cross_query_background`, `_run_query_and_signal`), helpers (`_audit`, `_log_ws_notification`), endpoints (POST /api/execute, POST /api/execute/estimate), shared state (`_inflight_queries`, `_user_query_counts`, `_user_query_lock`). Uses `set_execute_dependencies()` injection pattern. |

**Result**: main.py reduced from 6,704 to 1,609 lines (5,095 lines extracted across all Round 4 tasks). All 294 tests pass with 0 failures.

**Files created**:
- `backend/api/execute_stream_api.py` (~835 lines) — streaming endpoints
- `backend/core/duckdb_views.py` (~877 lines) — DuckDB view registration
- `backend/core/mv_manager.py` (~457 lines) — materialized view manager
- `backend/api/execute_api.py` (~1,600 lines) — execute engine + background workers

**Files modified**: `backend/main.py` (6,704 → 1,609 lines), `backend/core/query_converter.py` (added `strip_sql_limit()`).

---

## Round 5: Pivot Improvements + Column Intelligence Upgrades (B3 + B4) — DONE

Goal: Enhance pivot table UX with heatmaps, CSV export, frozen columns, and collapsible groups. Fix and extend column intelligence chart presets.

| # | Round | Scope | Status | Details |
|---|-------|-------|--------|---------|
| B3 | Pivot Improvements | Heatmap, CSV export, frozen first column, expand/collapse groups | **DONE** | **Heatmap conditional formatting**: `pivotHeatmap` toggle + `pivotHeatmapColor()` helper computes green-to-red gradient (rgba) based on global min/max across all pivot cells; applied via `hmBg()` to both cross-tab and simple pivot value cells. **CSV export**: `exportPivotCsv()` generates CSV from pivot data (handles cross-tab + simple), Blob URL download; export button (DownloadIcon) in pivot result header. **Frozen first column**: `position: 'sticky', left: 0, zIndex: 1/4` on first row-field cells (header + body + grand total), keeps first grouping column visible on horizontal scroll. **Expand/collapse groups**: when 2+ row fields, first occurrence of each group value shows toggle; `pivotCollapsed: Set<string>` state tracks collapsed groups, child rows hidden. |
| B4 | Column Intelligence Fixes & Upgrades | Bug fixes, simplified dual-axis, high-cardinality handling, 12 presets | **DONE** | Fixed `distinctCount` → `distinctEstimate` property name bugs in presets 8 (donut) and 12 (horizontal_bar). Removed over-complex dual-axis detection (relied on non-existent `.max` property); now always suggests dual-axis when 2+ numerics + categorical exist. Enhanced `suggestChart()`: high-cardinality categoricals (>12 distinct) auto-suggest horizontal_bar instead of bar for better readability. Total presets now 12 (was 7→8 from prior + 5 new: donut, waterfall, KPI, dual-axis, horizontal bar). |

**Files modified**: `frontend/src/components/DataGridViewer.tsx` (pivot heatmap, CSV export, frozen column, expand/collapse groups), `frontend/src/services/columnIntelligence.ts` (property name fixes, simplified dual-axis, high-cardinality detection, 12 total presets).

---

## Phase 61: REST API Connector + PostgreSQL + E2E Tests + Docker Publish — COMPLETE

Goal: Extend QueryStudio with a generic REST API data connector, optional PostgreSQL backend, end-to-end browser tests, and an internal Docker publish script.

| # | Task | Status | Details |
|---|------|--------|---------|
| 61A | REST API Connector | **DONE** | New `core/connectors/rest_api_connector.py`: generic HTTP data source with 5 auth types (none, basic, bearer, api_key, oauth2), 5 pagination strategies (none, offset, cursor, link_header, page_number), JSON response flattening to tabular rows, RestQueryDef Pydantic model, configurable timeout/retry/headers. Admin config: `rest_api` section in config.json, `GET/PUT /api/admin/rest-api/config`. |
| 61B | PostgreSQL Support | **DONE** | Admin-configurable database backend via `database.type` config (`sqlite` or `postgresql`). Auto-fallback to SQLite when PostgreSQL is unavailable. Shared `_MIGRATIONS` dict for both backends. New `_apply_postgresql_migrations()` for PG-specific DDL. Extended `database` config section with `postgresql_host`, `postgresql_port`, `postgresql_db`, `postgresql_user`, `postgresql_password`. New compose file: `docker-compose.postgresql.yml`. Admin endpoint: `GET /api/admin/database/status`. |
| 61C | E2E Tests (Playwright) | **DONE** | 10+ end-to-end test cases using Playwright. Test fixtures with API-based setup/teardown. Config: `frontend/playwright.config.ts`. Tests at `frontend/e2e/`. Covers login flow, connection CRUD, query execution, report builder, admin pages, and portal navigation. |
| 61D | Internal Docker Publish | **DONE** | New `scripts/docker-publish.sh`: configurable registry (env var `DOCKER_REGISTRY`), build + tag + push for both standalone and production images. Supports custom tags, multi-arch builds, and dry-run mode. |

**Files created**:
- `backend/core/connectors/rest_api_connector.py` — REST API connector (5 auth types, 5 pagination strategies, JSON flattening)
- `docker-compose.postgresql.yml` — PostgreSQL-backed deployment compose file
- `scripts/docker-publish.sh` — Internal Docker build/tag/push script
- `frontend/playwright.config.ts` — Playwright E2E test configuration
- `frontend/e2e/` — End-to-end test suite (10+ test cases)

**Files modified**: `backend/core/config.py` (rest_api section, extended database section), `backend/core/database.py` (PostgreSQL engine creation, dual-backend migrations), `backend/api/admin_api.py` (rest-api config endpoints, database status endpoint).

---

## Stats Summary

- **Total Phases**: 61 (35 core + 17 performance/intelligence/lineage + 8 business user portal + 1 infrastructure)  + 18 extra features
- **Completed**: 56/58 phases + 18 extra features  *(43 blocked-PostgreSQL, 44 deferred, 45 deferred)*
- **Phase 53**: COMPLETE — Semantic Layer Foundation (7 models, 33 endpoints, DatasetManagerPage)
- **Phase 54**: COMPLETE — Federation Engine (DuckDB named secrets, query builder, merged datasets, 13 endpoints)
- **Phase 55**: COMPLETE — Aggregation Cache (BO Aggregate Awareness + Power BI Auto-Aggregations + Tableau Extracts; 2 models, 17 endpoints, smart routing, stale serving, incremental refresh, usage suggestions)
- **Phase 56**: COMPLETE — Business Report Builder (BusinessReportBuilder.tsx, cascading LOVs, breaks/subtotals, running calcs, drill hierarchy, slicers)
- **Phase 57**: COMPLETE — Enhanced NL Chatbot (23 patterns, SemanticSchemaContext, schema_cache enrichment, 3 API paths, 34 tests)
- **On-Prem S3 + Hive Parquet**: COMPLETE — MinIO/NetApp/Ceph path_style, hive-partitioned plain parquet with partition UI, boto3 pre-listing (no DuckDB glob crashes), cross-source federation fix, configurable partition cache TTLs
- **Phase 58**: COMPLETE — Report Catalog & Certified Templates (unified catalog, certification, clone from template, share links, embed tokens, template gallery, admin config, 24 tests)
- **Phase 59**: COMPLETE — Business Portal (role-based landing page, KPI cards, quick actions, recent/favorites/templates, portal summary API, admin config, 15 tests)
- **Phase 60**: COMPLETE — Delivery & Alerts (ReportSubscription + SubscriptionDelivery models, delivery_engine.py, subscription_api.py 12 endpoints, SubscriptionManager.tsx 3-tab dialog, cron scheduling, PDF/Excel/CSV output, threshold alerts, unsubscribe tokens, retry backoff, admin config, 27 tests)
- **Phase 61**: COMPLETE — REST API Connector + PostgreSQL + E2E Tests + Docker Publish (rest_api_connector.py with 5 auth types + 5 pagination strategies, PostgreSQL dual-backend with auto-fallback, Playwright E2E 10+ tests, docker-publish.sh build/tag/push script)
- **Planned (Infrastructure)**: Phases 43–45
- **API Endpoints**: 320+ (REST) + GraphQL /graphql + gRPC services
- **Backend Modules**: 44 core + 19 API routers + 1 API model package + gRPC service
- **Database Models**: 56 (dual-backend: SQLite + PostgreSQL)
- **Frontend Components**: 47 (SubscriptionManager added)
- **Test coverage**: 294 pytest tests PASSED + 10+ Playwright E2E tests
- **Connectors**: 7 (S3, Local, Snowflake, Databricks, Trino/Starburst, Oracle, REST API) — all push-down capable; S3 supports AWS + on-prem (MinIO/NetApp/Ceph)
- **Infrastructure**: Docker (standalone + production), Helm chart (K8s/OpenShift), Istio/Linkerd service mesh

### Business User Roadmap — Phase Dependency Chain
```
Phase 53 (Semantic Layer)          ← COMPLETE
       ↓
Phase 54 (Cross-Source Federation) ← COMPLETE
       ↓
Phase 55 (Aggregation Cache)       ← COMPLETE
       ↓
Phase 56 (Report Builder)          ← COMPLETE
       ↓
Phase 57 (NL Chatbot Upgrade)      ← COMPLETE (23 patterns, semantic-aware)
       ↓
Phase 58 (Report Catalog)          ← COMPLETE
       ↓
Phase 59 (Business Portal)         ← COMPLETE
       ↓
Phase 60 (Delivery & Alerts)       ← COMPLETE
       ↓
Phase 61 (REST API + PG + E2E + Docker) ← COMPLETE
```

### Target Business User Scenario
Cross-source joins: **S3 cloud (AWS)** + **S3 on-prem (MinIO)** → federated via DuckDB named secrets.
Heavy aggregations (100M+ rows): pre-computed rollup parquets → sub-second report load.
Business users (viewer role): guided wizard, no SQL, certified report catalog, email delivery with subscriptions and threshold alerts.

### Feature Inspiration Matrix
| Feature | Source |
|---------|--------|
| Universe semantic layer (Dimension/Measure/Detail/Class) | SAP BusinessObjects |
| Cascading prompts / filtered LOVs | SAP BusinessObjects WebI |
| Sections, breaks, subtotals in reports | BO Crystal Reports / WebI |
| Running calcs (RunningSum, Rank, Percentage, Previous) | SAP BusinessObjects |
| Multiple data providers merged on shared dimension | SAP BusinessObjects |
| Smart bursting (per-recipient dimension slice) | SAP BusinessObjects Publications |
| Alerters (threshold + formatting + delivery) | SAP BusinessObjects |
| Drag-and-drop measure/dimension pills | Tableau |
| Show Me / smart chart suggestion | Tableau |
| Drill hierarchies (click Year → Quarter → Month) | Tableau |
| KPI cards with trend arrows | Power BI |
| Slicer / input controls (cross-filter all visuals) | Power BI |
| Date hierarchy auto-expand | Power BI |
