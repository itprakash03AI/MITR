# QueryStudio — Architecture

---

## System Overview

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                          Browser  (React 18 + Vite + TypeScript)            ║
╠═══════════════╦══════════════╦═══════════════╦═══════════════╦══════════════╣
║  Query Builder║  SQL Editor  ║   Dashboards  ║ Saved Queries ║   Reports    ║
║  (visual UI)  ║  (raw DQL)   ║  (drag/drop)  ║ (ver/share)   ║  (params)    ║
╠═══════════════╩══════════════╩═══════════════╩═══════════════╩══════════════╣
║   Schedules · Executions · Downloads · Connections · Login · User Guide     ║
╚═════════════════════════════════╤════════════════════════════════════════════╝
                                  │  REST (HTTP/JSON)  +  WebSocket (ws://)
                                  ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║                   FastAPI  (main.py)  —  single process                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  ┌──────────────────────┐   ┌──────────────────────┐   ┌──────────────────┐ ║
║  │   Auth Middleware    │   │   REST Router        │   │ WebSocket /ws    │ ║
║  │  _get_current_user() │   │  /api/*  /auth/*     │   │  broadcast all   │ ║
║  │  AD Basic or guest   │   │  /api/shared/:token  │   │  connected tabs  │ ║
║  └──────────────────────┘   └──────────────────────┘   └──────────────────┘ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  ┌──────────────────────┐   ┌──────────────────────┐   ┌──────────────────┐ ║
║  │  asyncio.create_task │   │    APScheduler       │   │  ThreadPool      │ ║
║  │  execute_query_bg()  │   │  cron / interval     │   │  query_executor  │ ║
║  │  per-query coroutine │   │  in-process thread   │   │  DuckDB + PyArr  │ ║
║  └──────────────────────┘   └──────────────────────┘   └──────────────────┘ ║
╚═══════════════════╤══════════════════════════╤═══════════════════════════════╝
                    │                          │
       ┌────────────▼────────────┐   ┌─────────▼──────────────────────────────┐
       │  DuckDB Engine          │   │  SQLite  (DatabaseManager)             │
       │  api/data_grid_api.py   │   │  core/database.py                      │
       │  core/parquet_engine_v2 │   ├────────────────────────────────────────┤
       ├─────────────────────────┤   │  saved_queries     query_versions       │
       │  • Local Parquet        │   │  query_executions  query_shares         │
       │  • S3 Parquet (httpfs)  │   │  download_files    dashboards           │
       │  • Iceberg (iceberg_ext)│   │  query_result_cache                     │
       │  • Trino / Snowflake /  │   │  dashboard_widgets schedules            │
       │    Databricks (proxied) │   │  parametric_reports                     │
       │  • read_parquet([list], │   └─────────────────────────────────────────┘
       │    union_by_name=true)  │
       │  • Partition pruning    │         ┌──────────────────────────────┐
       └────────────┬────────────┘         │  File System                 │
                    │                      │  data/parquet/  (source)     │
       ┌────────────▼────────────┐         │  data/downloads/(exports)    │
       │  Query Result Cache     │         │  data/cache/    (results)    │
       │  core/query_cache.py    │         │  data/uploads/  (temp)       │
       ├─────────────────────────┤         └──────────────────────────────┘
       │  Key: sha256(config)    │
       │  No-copy pointer to     │
       │  downloads/ file        │
       │  LRU eviction by TTL    │
       └─────────────────────────┘
```

---

## DuckDB Resource Governance

```
Each query gets its own in-memory DuckDB connection (never shared).
Concurrency is controlled by thread pools, not DuckDB itself.

                FastAPI async event loop
                        │
            ┌───────────┴───────────┐
            ▼                       ▼
     Worker Pool (40 threads)   S3 Connection Pool
     5 types with per-type      (3 warm conns/id, 5min TTL)
     concurrency limits         check-out → use → return
            │                       │
   ┌────────┼────────┐              │
   ▼        ▼        ▼              ▼
Thread A  Thread B  Thread C    Thread D
duckdb     duckdb    duckdb      pooled
:memory:   :memory:  :memory:    S3 conn
   │          │         │           │
   ▼          ▼         ▼           ▼
SET threads = 4              SET threads = 4
SET memory_limit = '2GB'     SET memory_limit = '2GB'
(admin-configurable)         (admin-configurable)

Admin-configurable settings (hot-reload, no restart):
  query_engine.duckdb_threads_per_query  = 4      (0 = auto: cpu_count / 4)
  query_engine.duckdb_memory_limit_mb    = 2048   (0 = unlimited)
  query_engine.query_timeout_seconds     = 1800   (30 min)
  query_engine.max_concurrent_per_user   = 10
  query_engine.max_concurrent_global     = 50

Budget example (20-core machine):
  4 threads/query × 8 concurrent queries = 32 DuckDB threads
  2GB/query × 8 concurrent = 16GB peak (safe on 32GB server)

Crash isolation (S3 streaming):
  core/duckdb_subprocess.py runs DuckDB in a child process.
  If C++ crashes (httpfs segfault), only child dies — main survives.
```

---

## Admin Panel Architecture

```
Two-panel layout: left nav sidebar (220px) + right content area

┌─────────────────┬─────────────────────────────────────────┐
│  MONITORING      │                                         │
│  > Active Queries│  Section Title              [Refresh]   │
│    System Health │  ┌─────────────────────────────────────┐│
│    Worker Pool   │  │                                     ││
│  CONFIGURATION   │  │  Only the active section renders    ││
│    App Config    │  │  Only the active section polls      ││
│    Scheduler     │  │  Non-polling sections load on first ││
│  USERS           │  │  visit, then on manual Refresh      ││
│    User Mgmt     │  │                                     ││
│    User Activity │  └─────────────────────────────────────┘│
│  SYSTEM          │                                         │
│    Storage       │                                         │
│    Cache         │                                         │
│    Audit Log     │                                         │
└─────────────────┴─────────────────────────────────────────┘

Polling sections (only when active):
  activeQueries  → every 10s   (GET /api/admin/active-queries)
  systemHealth   → every 15s   (GET /health)
  workerPool     → every 10s   (GET /api/admin/worker-pool + /tasks)
  scheduler      → every 15s   (GET /api/admin/scheduler)
  userActivity   → every 10s   (GET /api/admin/user-stats)

Non-polling sections (load once on first visit):
  appConfig, userManagement, storage, cache, auditLog
```

---

## Process Flow: Query Execution

```
User clicks "Execute"
        │
        ▼
POST /api/execute
        │
        ├─ resolve saved query (if query_id provided)
        ├─ resolve date expressions in filters   ${today}, ${monthStart}, …
        │
        ▼
  make_cache_key(query_config)  ──►  sha256(canonical JSON)
        │
        ▼
  get_cached_result(key)
        │
   ┌────┴────┐
  HIT?      NO
   │         │
   ▼         ▼
 return    Create QueryExecution  (status = running)
 file_id   Create DownloadFile    (status = internal)
 instantly Return {execution_id, status: "running"}
 (cache_   │
  hit:true) │  asyncio.create_task  ◄── runs concurrently, does NOT
            │                           block other HTTP requests
            ▼  ─────── background ────────────────────────────────────────
  validate_query()  ◄── run_in_executor (non-blocking, ThreadPool)
            │
            ▼
  DuckDB query build
  ┌──────────────────────────────────────────────────┐
  │  Single file:  read_parquet('path.parquet')      │
  │  Multi-file:   read_parquet(['a.parq','b.parq'], │
  │                  union_by_name=true)             │
  │  S3 Parquet:   httpfs + read_parquet('s3://…')  │
  │  Iceberg:      iceberg_scan('s3://…',            │
  │                  allow_moved_paths=true)         │
  │  Mixed:        SELECT … UNION ALL BY NAME        │
  └──────────────────────────────────────────────────┘
            │
            ▼
  Execute → stream chunks → write result.parquet
            │
            ▼
  store_result(key, result.parquet, copy=False)
  ──► cache entry points to same file (no copy)
            │
            ▼
  Update QueryExecution  (status = completed)
  WebSocket broadcast:   execution_completed {execution_id}
            │
            ▼  ──────── frontend ─────────────────────────────────────────
  Frontend receives WS message
  Fetches  GET /api/executions/{id}/status
  Fetches  GET /api/executions/{id}/results  (paginated parquet read)
```

---

## Process Flow: Multi-File UNION (Preview & Execution)

```
User selects multiple source files
        │
        ▼
POST /api/query/preview  (or  POST /api/execute)
        │
   ┌────┴──────────────────────────────────────────────────────────┐
   │  Classify each file                                           │
   │                                                               │
   │  __iceberg__:s3://… ──► iceberg_scan('s3://…')  Iceberg      │
   │  s3://bucket/key.parq ─► read_parquet('s3://…') S3 Parquet   │
   │  /local/file.parquet  ─► read_parquet('/local/…')Local Parq  │
   └────┬──────────────────────────────────────────────────────────┘
        │
   ┌────▼────────────────────────────────────────────────────────────┐
   │  len(files) == 1?                                               │
   │  YES → use source expression directly                           │
   │  NO  →                                                          │
   │   All plain parquet (no Iceberg)?                               │
   │   YES → read_parquet([path1, path2, …], union_by_name=true)     │
   │          ── schema differences filled with NULL automatically   │
   │   NO  → SELECT * FROM src1                                      │
   │          UNION ALL BY NAME                                       │
   │          SELECT * FROM src2  …                                  │
   │          ── columns aligned by name, not position               │
   └─────────────────────────────────────────────────────────────────┘
        │
        ▼
  DuckDB executes unified query
  Filters, column selection, LIMIT applied
```

---

## Process Flow: S3 Iceberg with Partition Pruning

```
GET /api/connections/{id}/iceberg/files
    ?partition_filter=[{"col":"business_date","op":"gte","val":"${today-7d}"}]
        │
        ▼
  resolve date expressions in partition_filter
  "${today-7d}"  ──►  "2026-03-03"   (date_resolver.py)
        │
        ▼
  get_iceberg_data_files(s3, bucket, prefix, partition_filters)
        │
        ▼
  S3: GET table-metadata/v{N}.metadata.json
  ┌──────────────────────────────────────────┐
  │  parse partition spec (v1 or v2)         │
  │  field_name  →  iceberg_type             │
  │  "business_date"  →  "date"              │
  └──────────┬───────────────────────────────┘
             │
             ▼
  S3: GET manifest-list  (Avro)
  for each manifest entry:
  ┌──────────────────────────────────────────────────────────┐
  │  decode lower_bound / upper_bound bytes                  │
  │  date   → 4-byte LE int (days since epoch) → YYYY-MM-DD  │
  │  string → UTF-8                                          │
  │  long   → 8-byte LE signed int                           │
  │  ts     → 8-byte LE µs since epoch → ISO datetime        │
  │                                                          │
  │  _manifest_matches_filters(entry, spec, filters)         │
  │  upper_bound < filter_low  →  SKIP manifest              │
  │  lower_bound > filter_high →  SKIP manifest              │
  │  uncertain                 →  INCLUDE (safe over-approx) │
  └──────────────────────────────────────────────────────────┘
             │  only matching manifests downloaded
             ▼
  S3: GET manifest  (Avro) — list of data files
             │
             ▼
  _batch_s3_metadata(s3, bucket, [key1, key2, …])
  ┌────────────────────────────────────────────────────────┐
  │  Group keys by common prefix                           │
  │  list_objects_v2(prefix)  → sizes for all keys at once │
  │  (1–few API calls, not N HEAD requests)                │
  └────────────────────────────────────────────────────────┘
             │
             ▼
  Return filtered file list  [{key, size_bytes, last_modified}]
```

---

## Process Flow: Scheduled Job

```
APScheduler fires trigger (cron or interval)
        │
        ▼
  Load Schedule record from SQLite
        │
        ├─ source_type = "saved_query" ─► load query_config
        ├─ source_type = "sql_query"   ─► raw SQL string
        └─ source_type = "report"      ─► parametric_report + param_values
        │
        ▼
  resolve date expressions in filters / params
  "${monthStart}" ──► "2026-03-01"
        │
        ▼
  execute_query_to_parquet()  (DuckDB, in thread)
        │
        ▼
  Write  data/downloads/{schedule_name}_{timestamp}.{fmt}
  Create DownloadFile record  (status = available)
        │
        ├─────────────────────────────────────────┐
        ▼                                         ▼
  _send_schedule_email()               _send_schedule_webhook()
  SMTP via email_service.py            webhook_service.py
  if notify_emails configured          if webhook_url configured
        │                                         │
        ▼                                         ▼
  Attach file or link               Slack  ─► attachments JSON
  on success + failure              Teams  ─► MessageCard JSON
                                    Generic─► plain JSON POST
        │
        ▼
  WebSocket broadcast:  scheduled_job_completed
```

---

## Process Flow: Dynamic Date Resolution

```
Filter value arrives from UI or scheduled config:
  "${today-7d}"  "${monthStart}"  "${yearEnd}"  "${now-2h}"

        ▼  resolve_filter_dates(query_config)
        ▼  resolve_adv_filters(adv_filters_json)

  _EXPR_RE scans for  ${...}  tokens
        │
        ├─ today          ─► datetime.now(UTC).date()
        ├─ yesterday      ─► today − 1d
        ├─ tomorrow       ─► today + 1d
        ├─ weekStart      ─► Monday of current ISO week
        ├─ monthStart     ─► 1st of current month
        ├─ monthEnd       ─► last day (monthrange)
        ├─ yearStart      ─► Jan 1
        ├─ yearEnd        ─► Dec 31
        ├─ now            ─► UTC datetime (no microseconds)
        │
        ├─ today ± Nd     ─► timedelta(days=±N)
        ├─ today ± Nw     ─► timedelta(weeks=±N)
        ├─ today ± Nm     ─► calendar-month arithmetic (clamped to EOM)
        ├─ today ± Ny     ─► year replace (Feb-29 → Feb-28 on non-leap)
        ├─ now  ± Nh      ─► timedelta(hours=±N)
        └─ now  ± Nm      ─► timedelta(minutes=±N)

        ▼
  ISO-8601 string injected into filter:
  "${today-7d}"  ──►  "2026-03-03"
```

---

## Process Flow: Authentication

```
Frontend Init
        │
        ▼
  GET /auth/config  ──► { auth_enabled: true|false }
        │
   ┌────┴────┐
  enabled?  NO ──► load app directly (guest user)
   YES
   │
   ▼
  sessionStorage has { header: "Basic base64…" }?
   │
  YES ──► GET /auth/me (with Authorization header)
   │        │
   │       200 ──► { username, display_name, is_admin }
   │        │       app loads
   │       401 ──► clear session → show LoginPage
   │
  NO  ──► show LoginPage
              │
              ▼
        POST /auth/login  { username, password }
              │
              ▼  (backend: core/ad_auth.py)
        ldap3 bind against AD server
              │
         ┌────┴────┐
        OK?       FAIL ──► 401 Unauthorized
         │
         ▼
        { username, display_name, is_admin, email }
        Store Basic header in sessionStorage
        Redirect → app
```

---

## Process Flow: Storage Lifecycle & Quota Enforcement

```
Query executes
        │
        ▼
  result.parquet  →  data/downloads/{exec_id}.parquet
        │
        ▼
  store_result(cache_key, path, copy=False)
  ──► cache DB row points to downloads/ file
      NO file copy made
        │
  ┌─────────────────────────────────────────────────┐
  │  APScheduler — every 30 minutes                 │
  │                                                 │
  │  cleanup_expired()                              │
  │    delete expired cache DB rows                 │
  │    unlink orphan .parquet in data/cache/        │
  │                                                 │
  │  enforce_size_limit(max_cache_size_mb)          │
  │    sort cache entries by expires_at (LRU)       │
  │    evict oldest until total ≤ limit             │
  │    only unlink files inside data/cache/         │
  │                                                 │
  │  _enforce_storage_quotas()                      │
  │    get_downloads_size_bytes()                   │
  │    if > max_downloads_size_mb:                  │
  │      expire_oldest_downloads(keep_count)        │
  │      marks DownloadFile rows as "expired"       │
  └─────────────────────────────────────────────────┘
        │
  ┌─────────────────────────────────────────────────┐
  │  APScheduler — every 24 hours                   │
  │                                                 │
  │  cleanup_old_executions(retention_days=30)      │
  │    DELETE QueryExecution WHERE                  │
  │      status IN (completed, failed, cancelled)   │
  │      AND created_at < now − retention_days      │
  │    never deletes pending/processing rows        │
  └─────────────────────────────────────────────────┘
```

---

## Configuration Resolution

```
Priority (highest → lowest)

  1. Environment variables
     QUERYSTUDIO_SERVER_PORT=9000
     QUERYSTUDIO_AUTH_TYPE=ad
     QUERYSTUDIO_DATABASE_ORACLE_USER=…

  2. config.json  (backend/config.json)
     { "server": { "port": 8000 },
       "auth":   { "type": "ad", "ad_server": "…" } }

  3. Built-in defaults  (core/config.py _DEFAULTS)
     auth.type                              = "none"
     cache.enabled                          = true
     cache.ttl_seconds                      = 3600
     storage.max_cache_size_mb              = 2048
     storage.max_downloads_size_mb          = 10240
     scheduler.execution_retention_days     = 30
     query_engine.duckdb_threads_per_query  = 4      (0 = auto)
     query_engine.duckdb_memory_limit_mb    = 2048   (0 = unlimited)
     query_engine.query_timeout_seconds     = 1800
     query_engine.max_concurrent_per_user   = 10
     query_engine.max_concurrent_global     = 50

Typed accessors:
  from core.config import server, paths, auth, cache, email, storage, scheduler

  auth.type              # "none" | "ad"
  cache.ttl_seconds      # int
  storage.max_cache_size_mb        # int
  scheduler.execution_retention_days  # int
  paths.downloads_dir    # pathlib.Path  (resolved, absolute)
```

---

## Backend Module Map

```
backend/
├── main.py                     All FastAPI endpoints + startup/shutdown
├── config.json                 Runtime config (optional)
│
├── core/
│   ├── config.py               Layered config loader (env > file > defaults)
│   ├── database.py             SQLAlchemy models + DatabaseManager
│   ├── parquet_engine_v2.py    PyArrow streaming engine (multi-file)
│   ├── s3_storage.py           S3StorageHandler (boto3)
│   ├── iceberg_reader.py       Iceberg metadata + partition pruning
│   ├── date_resolver.py        Dynamic ${today}, ${monthStart}, … resolver
│   ├── query_cache.py          Disk-backed result cache (no-copy, LRU)
│   ├── scheduler.py            APScheduler setup + job runners
│   ├── websocket_manager.py    WS broadcast to all connected clients
│   ├── ad_auth.py              LDAP3-based AD authentication
│   ├── email_service.py        SMTP email with attachment support
│   ├── webhook_service.py      Slack / Teams / generic webhook
│   └── connectors/
│       ├── trino_connector.py
│       ├── snowflake_connector.py
│       ├── databricks_connector.py
│       └── oracle_connector.py
│
└── api/
    ├── data_grid_api.py        DuckDB engine (S3/Iceberg/local/preview)
    └── dashboards_api.py       Dashboard + widget CRUD router
```

---

## Frontend Module Map

```
frontend/src/
├── App.tsx                     Routes + AuthProvider wrapper
├── main.tsx                    Vite entry point
├── services/
│   └── api.ts                  Typed API client (Promise<any>, auth header injected)
├── context/
│   ├── AuthContext.tsx          User session + getAuthHeader()
│   ├── WebSocketContext.tsx     WS connection + lastMessage
│   └── NotificationContext.tsx Toast queue
├── components/
│   ├── Layout.tsx              AppBar (user chip, sign-out) + sidebar nav
│   ├── LoginPage.tsx           AD username/password form
│   ├── QueryBuilder.tsx        Visual query builder (file picker, filters, columns)
│   ├── DataGrid.tsx            Result table with virtual scroll + pagination
│   ├── DashboardPage.tsx       react-grid-layout dashboard builder
│   ├── SharedDashboardPage.tsx Public standalone dashboard (no auth)
│   ├── SavedQueries.tsx        Query list (table/grid), version history, share
│   ├── SharedQueryPage.tsx     Public shared query results (/shared/:token)
│   ├── SchedulesPage.tsx       Cron/interval job config + email/webhook
│   ├── ExecutionsPage.tsx      Execution history + cancel + re-run
│   ├── DownloadsPage.tsx       Export file browser + download links
│   ├── ReportsPage.tsx         Parametric report runner
│   ├── ConnectionsPage.tsx     Connection CRUD (S3, Trino, Snowflake, …)
│   └── AdminPage.tsx           Two-panel admin: left nav sidebar + content panel
└── vite.config.ts              Dev proxy → :8000 for /api and /ws
```

---

## Security Model

| Layer | Mechanism |
|---|---|
| **Transport** | HTTP (dev) / HTTPS (prod via reverse proxy) |
| **Authentication** | AD Basic auth → LDAP3 bind verify; `sessionStorage` on client |
| **Authorization** | `_get_current_user()` Depends injected on all protected routes |
| **Row-Level Security** | Non-admin: queries/executions/dashboards filtered to `created_by = user` |
| **Public routes** | `/api/shared/{token}` · `/shared/:token` — no auth dependency |
| **Input validation** | Pydantic v2 models on all request bodies |
| **File path safety** | All paths resolved through `PathsCfg`, no user-controlled traversal |
| **Cache isolation** | Cache key is SHA-256 of full config — different users get different keys |

---

## Deployment

```
OpenShift / Kubernetes — required PVC mounts:

  /app/data/parquet/     Source Parquet files        (BYOS — bring your own)
  /app/data/downloads/   Generated export files      (RW, auto-cleaned)
  /app/data/cache/       Query result cache          (RW, auto-evicted)
  /app/data/*.db         SQLite metadata database    (RW, persistent)

No external stateful services required.
No Redis · No Kafka · No message broker.

Backend:   uvicorn main:app --host 0.0.0.0 --port 8000
Frontend:  static files from frontend/dist/  (Vite build output)
           serve index.html for all routes (SPA)

Scale-out note:
  APScheduler and DuckDB are in-process — horizontal scaling requires
  a shared PVC for data/ and session-affinity (sticky sessions) at the
  load balancer. For active-active, migrate scheduler to a distributed
  backend (Redis/Postgres) and DatabaseManager to PostgreSQL.
```
