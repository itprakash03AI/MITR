/**
 * API Service - TypeScript version
 * Every method maps to an actual backend route.
 */

import { getAuthHeader } from '../context/AuthContext';

const API_BASE_URL = import.meta.env.VITE_API_URL || '';

export class ApiError extends Error {
  errorCode?: string;
  connectionId?: number;
  constructor(message: string, errorCode?: string, connectionId?: number) {
    super(message);
    this.name = 'ApiError';
    this.errorCode = errorCode;
    this.connectionId = connectionId;
  }
}

const RETRY_STATUSES = new Set([502, 503, 504]);
const MAX_RETRIES = 2;
const RETRY_DELAYS = [1000, 3000]; // ms backoff

const _parseError = async (response: Response): Promise<{ detail: string; errorCode?: string; connectionId?: number }> => {
  let detail = `HTTP ${response.status}`;
  let errorCode: string | undefined;
  let connectionId: number | undefined;
  try {
    const e = await response.json() as { detail?: any; message?: string };
    if (typeof e.detail === 'string') {
      detail = e.detail;
    } else if (Array.isArray(e.detail)) {
      detail = (e.detail as { msg?: string; loc?: any[]; input?: any }[]).map(d => {
        let s = d.msg || JSON.stringify(d);
        if (d.loc) s += ` [field: ${d.loc.join('.')}]`;
        if (d.input !== undefined) s += ` [got: ${JSON.stringify(d.input)}]`;
        return s;
      }).join('; ');
    } else if (e.detail && typeof e.detail === 'object') {
      detail = e.detail.message || JSON.stringify(e.detail);
      errorCode = e.detail.error_code;
      connectionId = e.detail.connection_id;
    } else if (e.message) {
      detail = e.message;
    }
  } catch {}
  return { detail, errorCode, connectionId };
};

const safeFetch = async (url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string>),
  };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  // Pass active workspace to backend for scoped list filtering
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  const method = (options.method || 'GET').toUpperCase();
  const canRetry = method === 'GET';

  let lastError: Error | null = null;
  const attempts = canRetry ? MAX_RETRIES + 1 : 1;

  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await fetch(fullUrl, { ...options, headers });
      if (!response.ok) {
        // 401 — check if it's an auth session expiry vs connector token expiry
        if (response.status === 401) {
          const { detail, errorCode, connectionId } = await _parseError(response);
          // Connector token expiry (e.g. S3 STS) — don't log user out
          if (errorCode === 'TOKEN_EXPIRED' && connectionId) {
            throw new ApiError(detail, errorCode, connectionId);
          }
          // Auth session expired or invalid — redirect to login
          sessionStorage.removeItem('qs_auth');
          window.location.reload();
          return new Promise(() => {});
        }
        // Retry on 502/503/504 for GET requests
        if (canRetry && attempt < MAX_RETRIES && RETRY_STATUSES.has(response.status)) {
          await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
          continue;
        }
        const { detail, errorCode, connectionId } = await _parseError(response);
        throw new ApiError(detail, errorCode, connectionId);
      }
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        return null;
      }
      return response.json();
    } catch (err) {
      lastError = err as Error;
      // Retry on network errors (TypeError: Failed to fetch) for GET requests
      if (canRetry && attempt < MAX_RETRIES && err instanceof TypeError) {
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
        continue;
      }
      throw err;
    }
  }
  throw lastError || new ApiError('Request failed after retries');
};

const openDownload = (path: string) =>
  window.open(path.startsWith('http') ? path : `${API_BASE_URL}${path}`, '_blank');

/** Fetch for shared pages — sends X-Share-Token instead of Authorization header. */
const sharedFetch = async (shareToken: string, url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Share-Token': shareToken,
    ...(options.headers as Record<string, string>),
  };
  const response = await fetch(fullUrl, { ...options, headers });
  if (!response.ok) {
    const { detail } = await _parseError(response);
    throw new ApiError(detail);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
}

export const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
  };
};

const api = {
  // ── Utility ──────────────────────────────────────────────────────────────
  healthCheck: () =>
    safeFetch('/health').catch(err => ({ status: 'error', message: (err as Error).message })),

  // ── Files ─────────────────────────────────────────────────────────────────
  listFiles: (storageType: string | null = null, s3Folder = '') => {
    const params = new URLSearchParams();
    if (storageType) params.append('storage_type', storageType);
    if (s3Folder)    params.append('s3_folder', s3Folder);
    const qs = params.toString();
    return safeFetch(`/api/files${qs ? '?' + qs : ''}`);
  },

  getFileSchema: (filePath: string) =>
    safeFetch(`/api/files/${filePath}/schema`).catch(err => {
      console.warn(`Schema failed for ${filePath}:`, (err as Error).message);
      return { file: filePath, columns: [], num_rows: 0 };
    }),

  uploadFile: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    const authHeader = getAuthHeader();
    const headers: Record<string, string> = {};
    if (authHeader) headers['Authorization'] = authHeader;
    return fetch(`${API_BASE_URL}/api/files/upload`, { method: 'POST', body: form, headers })
      .then(r => { if (!r.ok) throw new Error(`Upload failed: ${r.status}`); return r.json(); });
  },

  // ── S3 ────────────────────────────────────────────────────────────────────
  configureS3: (config: object) =>
    safeFetch('/api/s3/configure', { method: 'POST', body: JSON.stringify(config) }),
  testS3Connection: () => safeFetch('/api/s3/test'),
  listS3Folders: (prefix = '') =>
    safeFetch(`/api/s3/folders?prefix=${encodeURIComponent(prefix)}`),
  listS3Files: (folder = '') =>
    safeFetch(`/api/s3/files?folder=${encodeURIComponent(folder)}`),

  // ── Connections ───────────────────────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),
  getConnection: (id: string) => safeFetch(`/api/connections/${id}`),
  createConnection: (data: object) =>
    safeFetch('/api/connections', { method: 'POST', body: JSON.stringify(data) }),
  updateConnection: (id: string, data: object) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnection: (id: string) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),
  testConnection: (data: object) =>
    safeFetch('/api/connections/test', { method: 'POST', body: JSON.stringify(data) }),
  testSavedConnection: (id: string) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),
  listConnectionFiles: (connId: string, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),
  getConnectionFileSchema: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/files/${encodeURIComponent(filePath)}/schema`),

  // ── Upload connection files ─────────────────────────────────────────────────
  uploadConnectionFiles: async (connId: string, files: File[]): Promise<any> => {
    const form = new FormData();
    files.forEach(f => form.append('files', f));
    const fullUrl = `${API_BASE_URL}/api/connections/${connId}/upload-files`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    // Do NOT set Content-Type — browser sets multipart boundary automatically
    const response = await fetch(fullUrl, { method: 'POST', headers, body: form });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    return response.json();
  },
  listUploadedFiles: (connId: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files`),
  deleteUploadedFile: (connId: string, filename: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files/${encodeURIComponent(filename)}`, { method: 'DELETE' }),
  getUploadConnectionsStatus: () =>
    safeFetch('/api/connections/upload-status'),

  // ── Iceberg (S3 connections only) ─────────────────────────────────────────
  listIcebergTables: (connId: string, prefix = '') =>
    safeFetch(`/api/connections/${connId}/iceberg/tables?prefix=${encodeURIComponent(prefix)}`),
  listIcebergFiles: (connId: string, tablePrefix: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/files?table_prefix=${encodeURIComponent(tablePrefix)}`),

  // ── Registered Tables ────────────────────────────────────────────────────
  listRegisteredTables: (connId: string) =>
    safeFetch(`/api/connections/${connId}/tables`),
  registerTable: (connId: string, table: { name: string; s3_prefix: string; format: string; description?: string }) =>
    safeFetch(`/api/connections/${connId}/tables`, { method: 'POST', body: JSON.stringify(table) }),
  unregisterTable: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}`, { method: 'DELETE' }),
  getRegisteredTableSchema: (connId: string, tableName: string, refresh?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema${refresh ? '?refresh=true' : ''}`),
  refreshTableSchema: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema/refresh`, { method: 'POST' }),
  refreshAllSchemas: (connId: string) =>
    safeFetch(`/api/connections/${connId}/schema/refresh-all`, { method: 'POST' }),
  getRegisteredTablePartitions: (connId: string, tableName: string, fullScan?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions${fullScan ? '?full_scan=true' : ''}`),
  refreshPartitionCache: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions/refresh`, { method: 'POST' }),
  refreshAllPartitions: (connId?: string) =>
    safeFetch(`/api/partitions/refresh-all${connId ? `?connection_id=${connId}` : ''}`, { method: 'POST' }),
  discoverTables: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/discover-tables?prefix=${encodeURIComponent(prefix || '')}`),
  browseFolders: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/browse-folders?prefix=${encodeURIComponent(prefix || '')}`),

  // ── Saved Queries ─────────────────────────────────────────────────────────
  listQueries: (activeOnly: boolean | { active_only?: boolean } = true) => {
    const active = typeof activeOnly === 'object'
      ? (activeOnly.active_only ?? true)
      : activeOnly;
    return safeFetch(`/api/queries?active_only=${active}`).catch(() => []);
  },
  getSavedQueries: (activeOnly = true) => api.listQueries(activeOnly),
  getSavedQuery: (id: string) =>
    safeFetch(`/api/queries/${id}`).catch(() => null),
  saveQuery: (data: { name: string; description?: string; query_config: QueryConfig; created_by?: string }) => {
    const payload = {
      name:         data.name,
      description:  data.description || null,
      query_config: toBackendQueryConfig(data.query_config),
      created_by:   data.created_by || null,
    };
    return safeFetch('/api/queries', { method: 'POST', body: JSON.stringify(payload) });
  },
  updateQuery: (id: string, data: { name: string; description?: string; query_config: QueryConfig }) =>
    safeFetch(`/api/queries/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: data.name, description: data.description || null,
        query_config: toBackendQueryConfig(data.query_config),
      }),
    }),
  patchQuery: (id: string | number, data: object) =>
    safeFetch(`/api/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteQuery: (id: string) => safeFetch(`/api/queries/${id}`, { method: 'DELETE' }),
  toggleFavorite: (id: string | number) =>
    safeFetch(`/api/queries/${id}/favorite`, { method: 'POST' }),

  // ── Cost Estimate ────────────────────────────────────────────────────────
  estimateQuery: (queryConfig: QueryConfig, connectionId?: number) =>
    safeFetch('/api/execute/estimate', {
      method: 'POST',
      body: JSON.stringify({
        query_config: toBackendQueryConfig(queryConfig),
        connection_id: connectionId || null,
      }),
    }).catch(() => null),

  // ── Execution ─────────────────────────────────────────────────────────────
  executeQuery: (payload: { query_config?: QueryConfig; query_id?: string; raw_sql?: string; connection_id?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    const idempotencyKey = crypto.randomUUID();
    return safeFetch('/api/execute', { method: 'POST', body: JSON.stringify({ ...body, idempotency_key: idempotencyKey }) });
  },
  /** Execute a query on behalf of a shared-link viewer (no auth header, uses share token). */
  executeSharedQuery: (shareToken: string, payload: { query_config?: any; query_id?: number }) =>
    sharedFetch(shareToken, '/api/execute', { method: 'POST', body: JSON.stringify(payload) }),
  previewSql: (payload: { query_config: any; connection_id?: number }) =>
    safeFetch('/api/execute/preview-sql', { method: 'POST', body: JSON.stringify(payload) }),
  /** Stream first N rows directly from S3 via DuckDB httpfs — no file download. */
  streamQuery: (payload: { query_config?: any; raw_sql?: string; connection_id?: number; limit?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream', { method: 'POST', body: JSON.stringify(body) });
  },
  /** Paginated query directly from S3 via DuckDB httpfs — same response format as getExecutionResults. */
  streamPaginate: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    page?: number; page_size?: number;
    sort_column?: string | null; sort_direction?: string;
    adv_filters?: string;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/paginate', { method: 'POST', body: JSON.stringify(body) });
  },

  /** Lightweight column discovery for S3 streaming — returns column names, types, empty flags. */
  streamSchema: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    sample_rows?: number;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/schema', { method: 'POST', body: JSON.stringify(body) });
  },

  // ── Executions ────────────────────────────────────────────────────────────
  listExecutions: (params: { limit?: number; offset?: number; status?: string } | number = {}) => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  String(p.limit  ?? 50));
    qs.append('offset', String(p.offset ?? 0));
    if (p.status) qs.append('status', p.status);
    return safeFetch(`/api/executions?${qs}`).catch(() => []);
  },
  getExecution: (executionId: string) => safeFetch(`/api/executions/${executionId}`).catch(() => null),
  cancelExecution: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),
  getExecutionStatus: async (executionId: string) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      try {
        const downloads = await api.listDownloads('') as { execution_id: string; file_id: string }[];
        const match = downloads.find(d => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ─────────────────────────────────────────────────────────────
  listDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  getDownloads: (status = 'available') => api.listDownloads(status),
  downloadFile: (fileId: string) => openDownload(`/api/downloads/${fileId}/download`),
  deleteDownload: (fileId: string) => safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),

  // ── Results ───────────────────────────────────────────────────────────────
  getExecutionResults: (
    executionId: string, page = 1, pageSize = 100,
    sortColumn: string | null = null, sortDirection = 'asc', filters: object | null = null,
  ) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', JSON.stringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },
  exportResults: (executionId: string, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),
  getExecutionStats: (executionId: string) => safeFetch(`/api/executions/${executionId}/stats`),
  releaseExecutionResults: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/results`, { method: 'DELETE' }).catch(() => {}),

  /** Fetch execution results as Arrow IPC stream (binary). */
  getExecutionResultsArrow: async (executionId: string, page = 0, pageSize = 10000): Promise<{
    buffer: ArrayBuffer;
    totalRows: number;
    totalColumns: number;
    page: number;
    pageSize: number;
    rowsInPage: number;
  }> => {
    const url = `${API_BASE_URL}/api/executions/${executionId}/results/arrow?page=${page}&page_size=${pageSize}`;
    const headers: Record<string, string> = { Accept: 'application/vnd.apache.arrow.stream' };
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const response = await fetch(url, { headers });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    const buffer = await response.arrayBuffer();
    return {
      buffer,
      totalRows: parseInt(response.headers.get('X-Total-Rows') || '0', 10),
      totalColumns: parseInt(response.headers.get('X-Total-Columns') || '0', 10),
      page: parseInt(response.headers.get('X-Page') || '0', 10),
      pageSize: parseInt(response.headers.get('X-Page-Size') || '0', 10),
      rowsInPage: parseInt(response.headers.get('X-Rows-In-Page') || '0', 10),
    };
  },

  // ── SQL Queries ───────────────────────────────────────────────────────────
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),
  createSqlQuery: (data: object) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: JSON.stringify(data) }),
  getSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`),
  updateSqlQuery: (id: string, data: object) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),
  executeSqlQuery: (payload: object) =>
    safeFetch('/api/sql/execute', { method: 'POST', body: JSON.stringify(payload) }),
  listSqlCatalogs: (connectionId: string) => safeFetch(`/api/sql/connections/${connectionId}/catalogs`),
  listSqlSchemas: (connectionId: string, catalog: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),
  listSqlTables: (connectionId: string, catalog: string, schema: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),
  listSqlColumns: (connectionId: string, catalog: string, schema: string, table: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),
  testSqlConnection: (connectionId: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Reports ───────────────────────────────────────────────────────────────
  listReports: (activeOnly = true) =>
    safeFetch(`/api/reports?active_only=${activeOnly}`).catch(() => []),
  createReport: (data: object) => safeFetch('/api/reports', { method: 'POST', body: JSON.stringify(data) }),
  getReport: (id: string) => safeFetch(`/api/reports/${id}`),
  updateReport: (id: string, data: object) =>
    safeFetch(`/api/reports/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteReport: (id: string) => safeFetch(`/api/reports/${id}`, { method: 'DELETE' }),
  executeReport: (id: string, paramValues: object = {}, rowLimit: number | null = null, executedBy: string | null = null) =>
    safeFetch(`/api/reports/${id}/execute`, {
      method: 'POST',
      body: JSON.stringify({ param_values: paramValues, row_limit: rowLimit, executed_by: executedBy }),
    }),
  getReportSourceInfo: (id: string) => safeFetch(`/api/reports/${id}/source-info`),
  getReportColumns: (id: string) =>
    safeFetch(`/api/reports/${id}/columns`).catch(() => ({ columns: [], date_shortcuts: [] })),
  getPreviewColumns: (savedQueryId?: number) => {
    const qs = savedQueryId ? `?saved_query_id=${savedQueryId}` : '';
    return safeFetch(`/api/reports/preview-columns${qs}`).catch(() => ({ columns: [] }));
  },
  getReportParamValues: (id: string, paramName: string, limit = 1000) =>
    safeFetch(`/api/reports/${id}/param-values?param_name=${encodeURIComponent(paramName)}&limit=${limit}`)
      .catch(() => ({ values: [], total: 0, truncated: false })),
  downloadReportDirect: (id: string, paramValues: Record<string, string> = {}, format = 'csv') => {
    const params = { ...paramValues, format };
    const qs = new URLSearchParams(params).toString();
    openDownload(`/api/reports/${id}/download${qs ? '?' + qs : ''}`);
  },
  suggestReportParams: (data: object) =>
    safeFetch('/api/reports/suggest-params', { method: 'POST', body: JSON.stringify(data) })
      .catch(() => ({ suggested_params: [], raw_partitions: [] })),
  getReportHistory: (id: string, limit = 20) =>
    safeFetch(`/api/reports/${id}/history?limit=${limit}`)
      .catch(() => ({ executions: [], total: 0 })),
  scheduleReport: (id: string, config: object) =>
    safeFetch(`/api/reports/${id}/schedule`, { method: 'POST', body: JSON.stringify(config) }),
  unscheduleReport: (id: string) =>
    safeFetch(`/api/reports/${id}/schedule`, { method: 'DELETE' }),
  previewDownloadFile: (fileId: string, page = 1, pageSize = 100) =>
    safeFetch(`/api/downloads/${fileId}/preview?page=${page}&page_size=${pageSize}`),

  // ── Schedules ─────────────────────────────────────────────────────────────
  listSchedules: (activeOnly = false) =>
    safeFetch(`/api/schedules?active_only=${activeOnly}`).catch(() => []),
  createSchedule: (data: object) =>
    safeFetch('/api/schedules', { method: 'POST', body: JSON.stringify(data) }),
  getSchedule: (id: string) => safeFetch(`/api/schedules/${id}`),
  updateSchedule: (id: string, data: object) =>
    safeFetch(`/api/schedules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSchedule: (id: string) => safeFetch(`/api/schedules/${id}`, { method: 'DELETE' }),
  pauseSchedule: (id: string) => safeFetch(`/api/schedules/${id}/pause`, { method: 'POST' }),
  resumeSchedule: (id: string) => safeFetch(`/api/schedules/${id}/resume`, { method: 'POST' }),
  runScheduleNow: (id: string) => safeFetch(`/api/schedules/${id}/run-now`, { method: 'POST' }),
  getSchedulerStatus: () => safeFetch('/api/schedules/scheduler-status').catch(() => ({ running: false })),
  getScheduleRunStats: (scheduleId: number, limit: number = 20): Promise<any> =>
    safeFetch(`/api/schedules/${scheduleId}/run-stats?limit=${limit}`),
  getAnomalies: (limit: number = 50): Promise<any> =>
    safeFetch(`/api/admin/anomalies?limit=${limit}`),

  // ── Query Version History ─────────────────────────────────────────────────
  listQueryVersions: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions`).catch(() => []),
  restoreQueryVersion: (queryId: string | number, versionId: string | number) =>
    safeFetch(`/api/queries/${queryId}/versions/${versionId}/restore`, { method: 'POST' }),

  // ── Query Sharing ─────────────────────────────────────────────────────────
  shareQuery: (queryId: string | number, opts: { expires_hours?: number } = {}) =>
    safeFetch(`/api/queries/${queryId}/share`, { method: 'POST', body: JSON.stringify(opts) }),
  listQueryShares: (queryId: string | number) =>
    safeFetch(`/api/queries/${queryId}/shares`).catch(() => []),
  revokeShare: (queryId: string | number, token: string) =>
    safeFetch(`/api/queries/${queryId}/shares/${token}`, { method: 'DELETE' }),
  getSharedQuery: (token: string) =>
    safeFetch(`/api/shared/${token}`),
  getSharedDashboard: (token: string) =>
    safeFetch(`/api/shared-dashboard/${token}`),
  createDashboardShare: (dashboardId: string | number, expiresHours?: number) =>
    safeFetch(`/api/dashboards/${dashboardId}/share`, {
      method: 'POST', body: JSON.stringify({ expires_hours: expiresHours ?? null }),
    }),

  // ── Dashboards ────────────────────────────────────────────────────────────
  listDashboards: () => safeFetch('/api/dashboards').catch(() => []),
  createDashboard: (data: object) =>
    safeFetch('/api/dashboards', { method: 'POST', body: JSON.stringify(data) }),
  getDashboard: (id: string | number) => safeFetch(`/api/dashboards/${id}`),
  updateDashboard: (id: string | number, data: object) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDashboard: (id: string | number) =>
    safeFetch(`/api/dashboards/${id}`, { method: 'DELETE' }),
  listDashboardWidgets: (dashId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`).catch(() => []),
  createWidget: (dashId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets`, { method: 'POST', body: JSON.stringify(data) }),
  updateWidget: (dashId: string | number, widgetId: string | number, data: object) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteWidget: (dashId: string | number, widgetId: string | number) =>
    safeFetch(`/api/dashboards/${dashId}/widgets/${widgetId}`, { method: 'DELETE' }),
  updateDashboardLayout: (dashId: string | number, layouts: object[]) =>
    safeFetch(`/api/dashboards/${dashId}/layout`, { method: 'PUT', body: JSON.stringify({ layouts }) }),

  // ── Cache ─────────────────────────────────────────────────────────────────
  getCacheStats: () => safeFetch('/api/cache/stats').catch(() => ({})),
  clearCache: () => safeFetch('/api/cache', { method: 'DELETE' }),

  // ── Webhooks ──────────────────────────────────────────────────────────────
  testWebhook: (url: string) =>
    safeFetch('/api/webhooks/test', { method: 'POST', body: JSON.stringify({ url }) }),

  // ── Join preview ─────────────────────────────────────────────────────────
  joinPreview: (req: { connection_id?: number; left_file: string; right_file: string;
                        left_on: string[]; right_on: string[]; how?: string }) =>
    safeFetch('/api/joins/preview', { method: 'POST', body: JSON.stringify(req) }),

  // ── App Settings (admin-configurable limits & features) ─────────────────
  getAppSettings: () => safeFetch('/api/app-settings'),
  getAdminAppConfig: () => safeFetch('/api/admin/app-config'),
  updateAdminAppConfig: (data: { limits?: Record<string, any>; features?: Record<string, any> }) =>
    safeFetch('/api/admin/app-config', { method: 'PUT', body: JSON.stringify(data) }),

  // ── UI Component Visibility ───────────────────────────────────────────────
  getUIVisibility: () => safeFetch('/api/admin/ui-visibility'),
  setUIVisibility: (rules: Array<{ component_key: string; role: string; enabled: boolean }>) =>
    safeFetch('/api/admin/ui-visibility', { method: 'PUT', body: JSON.stringify({ rules }) }),

  // ── Materialized Views ─────────────────────────────────────────────────
  listMaterializedViews: (connectionId?: number) =>
    safeFetch(`/api/materialized-views${connectionId ? `?connection_id=${connectionId}` : ''}`).catch(() => []),
  getMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`),
  createMaterializedView: (data: object) =>
    safeFetch('/api/materialized-views', { method: 'POST', body: JSON.stringify(data) }),
  updateMaterializedView: (id: number, data: object) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}`, { method: 'DELETE' }),
  refreshMaterializedView: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/refresh`, { method: 'POST' }),
  getMaterializedViewStatus: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/status`),
  getMaterializedViewsStorage: () =>
    safeFetch('/api/materialized-views/storage').catch(() => ({})),
  getMaterializedViewSchema: (id: number) =>
    safeFetch(`/api/materialized-views/${id}/schema`),

  // ── Local Tables ──────────────────────────────────────────────────────────
  listLocalTables: (params?: { visibility?: string; created_by?: string }) =>
    safeFetch(`/api/local-tables${params ? '?' + new URLSearchParams(params as any).toString() : ''}`),
  getLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`),
  createLocalTable: (data: object) =>
    safeFetch('/api/local-tables', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  updateLocalTable: (id: number, data: object) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  deleteLocalTable: (id: number) =>
    safeFetch(`/api/local-tables/${id}`, { method: 'DELETE' }),
  promoteToLocalTable: (data: object) =>
    safeFetch('/api/local-tables/promote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }),
  uploadLocalTable: async (formData: FormData): Promise<any> => {
    const fullUrl = `${API_BASE_URL}/api/local-tables/upload`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const response = await fetch(fullUrl, { method: 'POST', headers, body: formData });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    return response.json();
  },
  appendToLocalTable: async (id: number, formData: FormData): Promise<any> => {
    const fullUrl = `${API_BASE_URL}/api/local-tables/${id}/append`;
    const headers: Record<string, string> = {};
    const authHeader = getAuthHeader();
    if (authHeader) headers['Authorization'] = authHeader;
    const wsId = localStorage.getItem('qs_workspace_id');
    if (wsId) headers['X-Workspace-ID'] = wsId;
    const response = await fetch(fullUrl, { method: 'POST', headers, body: formData });
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    return response.json();
  },
  getLocalTableSchema: (id: number) =>
    safeFetch(`/api/local-tables/${id}/schema`),
  getLocalTablesStorage: () =>
    safeFetch('/api/local-tables/storage').catch(() => ({})),

  // ── Table UX (Preview / Profile / Favorites) ───────────────────────────
  previewTable: (payload: { table_path: string; connection_id?: number; limit?: number }) =>
    safeFetch('/api/tables/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  profileTable: (payload: { table_path: string; connection_id?: number; columns?: string[]; sample_size?: number }) =>
    safeFetch('/api/tables/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  toggleTableFavorite: (payload: { table_path: string; table_name: string; connection_id?: number; table_type?: string }) =>
    safeFetch('/api/tables/favorite', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  listTableFavorites: (connectionId?: number) =>
    safeFetch(`/api/tables/favorites${connectionId ? `?connection_id=${connectionId}` : ''}`),

  // ── Notifications ───────────────────────────────────────────────────────
  listNotifications: (unreadOnly = false, limit = 50, offset = 0) =>
    safeFetch(`/api/notifications?unread_only=${unreadOnly}&limit=${limit}&offset=${offset}`),
  getUnreadCount: () =>
    safeFetch('/api/notifications/unread-count'),
  markNotificationRead: (id: number) =>
    safeFetch(`/api/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () =>
    safeFetch('/api/notifications/read-all', { method: 'PUT' }),

  // ── Report Catalog (23A) ──────────────────────────────────────────────────
  getReportCatalog: () =>
    safeFetch('/api/report-catalog').catch(() => ({ folders: [], tags: [], favorites: [], recent: [] })),
  listReportFolders: (parentId?: number) =>
    safeFetch(`/api/report-folders${parentId != null ? `?parent_id=${parentId}` : ''}`).catch(() => ({ folders: [] })),
  createReportFolder: (data: object) =>
    safeFetch('/api/report-folders', { method: 'POST', body: JSON.stringify(data) }),
  updateReportFolder: (id: number, data: object) =>
    safeFetch(`/api/report-folders/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteReportFolder: (id: number) =>
    safeFetch(`/api/report-folders/${id}`, { method: 'DELETE' }),
  assignReportFolder: (reportId: number, folderId: number | null) =>
    safeFetch(`/api/reports/${reportId}/folder`, { method: 'POST', body: JSON.stringify({ folder_id: folderId }) }),
  listReportTags: () =>
    safeFetch('/api/report-tags').catch(() => ({ tags: [] })),
  createReportTag: (data: object) =>
    safeFetch('/api/report-tags', { method: 'POST', body: JSON.stringify(data) }),
  deleteReportTag: (id: number) =>
    safeFetch(`/api/report-tags/${id}`, { method: 'DELETE' }),
  assignReportTags: (reportId: number, tagIds: number[]) =>
    safeFetch(`/api/reports/${reportId}/tags`, { method: 'POST', body: JSON.stringify({ tag_ids: tagIds }) }),
  getReportTags: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/tags`).catch(() => ({ tags: [] })),
  toggleReportFavorite: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/favorite`, { method: 'POST' }),
  getReportFavorites: () =>
    safeFetch('/api/reports/favorites').catch(() => ({ report_ids: [] })),
  recordReportView: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/view`, { method: 'POST' }).catch(() => {}),
  getRecentReports: (limit = 10) =>
    safeFetch(`/api/reports/recent?limit=${limit}`).catch(() => ({ report_ids: [] })),
  searchReportCatalog: (q: string, limit = 30) =>
    safeFetch(`/api/reports/search?q=${encodeURIComponent(q)}&limit=${limit}`).catch(() => ({ results: [], count: 0 })),

  // ── PDF Export (23D) ──────────────────────────────────────────────────────
  downloadReportPDF: (reportId: number, paramValues: Record<string, string> = {}) => {
    const qs = new URLSearchParams(paramValues).toString();
    openDownload(`/api/reports/${reportId}/download-pdf${qs ? '?' + qs : ''}`);
  },
  getReportPDFConfig: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/pdf-config`).catch(() => ({})),
  updateReportPDFConfig: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/pdf-config`, { method: 'PUT', body: JSON.stringify(data) }),

  // ── Bookmarks (23B) ───────────────────────────────────────────────────────
  listReportBookmarks: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/bookmarks`).catch(() => ({ bookmarks: [] })),
  saveReportBookmark: (reportId: number, name: string, paramValues: object) =>
    safeFetch(`/api/reports/${reportId}/bookmarks`, {
      method: 'POST',
      body: JSON.stringify({ name, param_values: paramValues }),
    }),
  deleteReportBookmark: (bookmarkId: number) =>
    safeFetch(`/api/reports/bookmarks/${bookmarkId}`, { method: 'DELETE' }),

  // ── Conditional Formatting (23C) ──────────────────────────────────────────
  getConditionalFormats: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/formatting`).catch(() => ({ rules: [] })),
  saveConditionalFormats: (reportId: number, rules: object[]) =>
    safeFetch(`/api/reports/${reportId}/formatting`, { method: 'PUT', body: JSON.stringify({ rules }) }),

  // ── Alert Rules (23F) ─────────────────────────────────────────────────────
  listAlertRules: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/alerts`).catch(() => ({ rules: [] })),
  createAlertRule: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/alerts`, { method: 'POST', body: JSON.stringify(data) }),
  updateAlertRule: (ruleId: number, data: object) =>
    safeFetch(`/api/reports/alerts/${ruleId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteAlertRule: (ruleId: number) =>
    safeFetch(`/api/reports/alerts/${ruleId}`, { method: 'DELETE' }),
  getAlertHistory: (ruleId: number, limit = 50) =>
    safeFetch(`/api/reports/alerts/${ruleId}/history?limit=${limit}`).catch(() => ({ history: [] })),

  // ── Report Bursting (23E) ─────────────────────────────────────────────────
  triggerBurst: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/burst`, { method: 'POST', body: JSON.stringify(data) }),
  getBurstJob: (jobId: number) =>
    safeFetch(`/api/reports/burst/${jobId}`),
  cancelBurstJob: (jobId: number) =>
    safeFetch(`/api/reports/burst/${jobId}/cancel`, { method: 'POST' }),
  listBurstJobs: (reportId: number, limit = 20) =>
    safeFetch(`/api/reports/${reportId}/burst-jobs?limit=${limit}`).catch(() => ({ jobs: [] })),

  // ── RLS Policies (23G) ────────────────────────────────────────────────────
  listRLSPolicies: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/rls`).catch(() => ({ policies: [] })),
  createRLSPolicy: (reportId: number, data: object) =>
    safeFetch(`/api/reports/${reportId}/rls`, { method: 'POST', body: JSON.stringify(data) }),
  updateRLSPolicy: (policyId: number, data: object) =>
    safeFetch(`/api/reports/rls/${policyId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteRLSPolicy: (policyId: number) =>
    safeFetch(`/api/reports/rls/${policyId}`, { method: 'DELETE' }),
  previewRLS: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/rls/preview`, { method: 'POST', body: '{}' }).catch(() => ({ where_clauses: [] })),

  // ── Connection Profiles (24B) ─────────────────────────────────────────────
  listConnectionProfiles: () =>
    safeFetch('/api/connection-profiles').catch(() => ({ profiles: [] })),
  getActiveProfile: () =>
    safeFetch('/api/connection-profiles/active').catch(() => null),
  createConnectionProfile: (data: object) =>
    safeFetch('/api/connection-profiles', { method: 'POST', body: JSON.stringify(data) }),
  updateConnectionProfile: (id: number, data: object) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'DELETE' }),
  activateConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/activate`, { method: 'POST' }),
  deactivateAllProfiles: () =>
    safeFetch('/api/connection-profiles/deactivate', { method: 'POST' }),
  getProfileMappings: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`).catch(() => ({ mappings: [] })),
  setProfileMappings: (id: number, mappings: object[]) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`, { method: 'PUT', body: JSON.stringify({ mappings }) }),

  // ── Report Connectors Matrix (24C) ────────────────────────────────────────
  getReportConnectorMatrix: () =>
    safeFetch('/api/reports/connector-matrix').catch(() => ({ reports: [] })),
  bulkSetConnectionOverride: (reportIds: number[], connectionOverrideId: number | null) =>
    safeFetch('/api/reports/bulk-set-connection-override', {
      method: 'POST',
      body: JSON.stringify({ report_ids: reportIds, connection_override_id: connectionOverrideId }),
    }),

  // ── Workspaces (25) ───────────────────────────────────────────────────────
  listWorkspaces: () =>
    safeFetch('/api/workspaces').catch(() => ({ workspaces: [] })),
  createWorkspace: (data: object) =>
    safeFetch('/api/workspaces', { method: 'POST', body: JSON.stringify(data) }),
  updateWorkspace: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteWorkspace: (id: number) =>
    safeFetch(`/api/workspaces/${id}`, { method: 'DELETE' }),
  listWorkspaceMembers: (id: number) =>
    safeFetch(`/api/workspaces/${id}/members`).catch(() => ({ members: [] })),
  addWorkspaceMember: (id: number, data: object) =>
    safeFetch(`/api/workspaces/${id}/members`, { method: 'POST', body: JSON.stringify(data) }),
  updateWorkspaceMemberRole: (id: number, username: string, data: object) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'PUT', body: JSON.stringify(data) }),
  removeWorkspaceMember: (id: number, username: string) =>
    safeFetch(`/api/workspaces/${id}/members/${encodeURIComponent(username)}`, { method: 'DELETE' }),

  // ── Embedded Reports (27) ─────────────────────────────────────────────────
  createEmbedToken: (reportId: number, expiresInDays: number | null = null) =>
    safeFetch(`/api/reports/${reportId}/embed-tokens`, {
      method: 'POST',
      body: JSON.stringify({ expires_in_days: expiresInDays }),
    }),
  listEmbedTokens: (reportId: number) =>
    safeFetch(`/api/reports/${reportId}/embed-tokens`).catch(() => ({ tokens: [] })),
  revokeEmbedToken: (token: string) =>
    safeFetch(`/api/reports/embed-tokens/${token}`, { method: 'DELETE' }),
  getEmbeddedReport: (token: string) =>
    safeFetch(`/api/embedded-report/${token}`),
  executeEmbeddedReport: (token: string, paramValues: object = {}, limit = 1000) =>
    safeFetch(`/api/embedded-report/${token}/execute`, {
      method: 'POST',
      body: JSON.stringify({ param_values: paramValues, limit }),
    }),

  // ── Data Lineage (26) ─────────────────────────────────────────────────────
  getConnectionLineage: (id: number) =>
    safeFetch(`/api/lineage/connection/${id}`),
  getReportLineage: (id: number) =>
    safeFetch(`/api/lineage/report/${id}`),
  getQueryLineage: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}?type=${encodeURIComponent(type)}`),
  getFullLineageGraph: () =>
    safeFetch('/api/lineage/graph').catch(() => ({ nodes: [], edges: [] })),

  // Phase 49: Table-level lineage
  getTableLineage: (catalog: string, schema: string, table: string) =>
    safeFetch(`/api/lineage/table/${encodeURIComponent(catalog)}/${encodeURIComponent(schema)}/${encodeURIComponent(table)}`),
  searchTableLineage: (q: string, limit: number = 50) =>
    safeFetch(`/api/lineage/table/search?q=${encodeURIComponent(q)}&limit=${limit}`),
  getQueryTables: (id: number, type: string = 'sql') =>
    safeFetch(`/api/lineage/query/${id}/tables?type=${encodeURIComponent(type)}`),
  reparseAllLineage: () =>
    safeFetch('/api/lineage/reparse', { method: 'POST' }),

  // ── Audit & Compliance (28) ───────────────────────────────────────────────
  getAuditLogFiltered: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string; limit?: number; offset?: number;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    return safeFetch(`/api/admin/audit-log?${qs.toString()}`);
  },
  exportAuditLog: (params: {
    username?: string; action?: string; resource_type?: string;
    date_from?: string; date_to?: string;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined) qs.set(k, String(v)); });
    const base = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
    const a = document.createElement('a');
    a.href = `${base}/api/admin/audit-log/export?${qs.toString()}`;
    a.download = 'audit_log.csv';
    a.click();
    return Promise.resolve();
  },
  getDataAccessSummary: () =>
    safeFetch('/api/admin/audit-log/data-access-summary').catch(() => ({ summary: [] })),
  generateSubjectExport: (username: string) => {
    const base = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
    return fetch(`${base}/api/admin/compliance/subject-export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(getAuthHeader() ? { Authorization: getAuthHeader() as string } : {}) },
      body: JSON.stringify({ username }),
    }).then(async res => {
      if (!res.ok) throw new Error(await res.text());
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `subject_export_${username}.zip`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    });
  },

  // ── Phase 46: Auto-suggest ─────────────────────────────────────────────────
  getSuggestedTables: (params: { prefix?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.prefix) q.set('prefix', params.prefix);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/tables?${q}`);
  },
  getSuggestedColumns: (params: { table_name?: string; connection_id?: number; limit?: number } = {}) => {
    const q = new URLSearchParams();
    if (params.table_name) q.set('table_name', params.table_name);
    if (params.connection_id != null) q.set('connection_id', String(params.connection_id));
    if (params.limit) q.set('limit', String(params.limit));
    return safeFetch(`/api/suggest/columns?${q}`);
  },
  getTopTables: (connection_id?: number) =>
    safeFetch(`/api/suggest/top-tables${connection_id != null ? `?connection_id=${connection_id}` : ''}`),

  // ── Phase 47: Query analysis ───────────────────────────────────────────────
  analyzeQuery: (sql: string, connection_type = 'duckdb', partition_columns: string[] = []) =>
    safeFetch('/api/analyze-query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, connection_type, partition_columns }),
    }),

  // ── Phase 48: NL-to-SQL ───────────────────────────────────────────────────
  nlToSql: (payload: {
    question: string;
    connection_id?: number;
    tables?: string[];
    columns?: Record<string, string[]>;
    connection_type?: string;
    default_schema?: string;
  }) =>
    safeFetch('/api/nl-to-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  getNlToSqlExamples: () => safeFetch('/api/nl-to-sql/examples'),
  getChatbotPatterns: () => safeFetch('/api/suggest/chatbot-patterns'),

  // ── Assistant smart-context endpoints ─────────────────────────────────────
  getSuggestSchema: (q: string, connection_id?: number) =>
    safeFetch(`/api/suggest/schema?q=${encodeURIComponent(q)}${connection_id != null ? `&connection_id=${connection_id}` : ''}`),
  getLastResultInfo: () => safeFetch('/api/suggest/last-result'),
  getSuggestDocs: (q: string) => safeFetch(`/api/suggest/docs?q=${encodeURIComponent(q)}`),
  dataQuery: (question: string, columns: string[] = [], execution_id?: string, file_id?: string) =>
    safeFetch('/api/suggest/data-query', {
      method: 'POST',
      body: JSON.stringify({ question, columns, execution_id, file_id }),
    }),
  saveNlFeedback: (question: string, sql: string, rating: 1 | -1, connection_type = 'duckdb', tables_hint?: string) =>
    safeFetch('/api/suggest/feedback', {
      method: 'POST',
      body: JSON.stringify({ question, sql, rating, connection_type, tables_hint }),
    }),

  // ── Phase 51: Column lineage ───────────────────────────────────────────────
  getQueryColumnLineage: (query_id: number, query_type = 'sql_query') =>
    safeFetch(`/api/lineage/query/${query_id}/columns?query_type=${query_type}`),
  getColumnImpact: (table: string, column: string) =>
    safeFetch(`/api/lineage/column/impact?table=${encodeURIComponent(table)}&column=${encodeURIComponent(column)}`),

  // ── Phase 52: Lineage snapshots ────────────────────────────────────────────
  getLineageSnapshots: (params?: { query_type?: string; query_id?: number; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.query_type) qs.set('query_type', params.query_type);
    if (params?.query_id != null) qs.set('query_id', String(params.query_id));
    if (params?.limit != null)    qs.set('limit', String(params.limit));
    return safeFetch(`/api/lineage/snapshots?${qs}`);
  },
  getLineageSnapshot: (id: number) =>
    safeFetch(`/api/lineage/snapshots/${id}`),
  diffLineageSnapshots: (a: number, b: number) =>
    safeFetch(`/api/lineage/snapshots/diff?a=${a}&b=${b}`),

  // ── Phase 52: Data freshness ───────────────────────────────────────────────
  getDataFreshness: () =>
    safeFetch('/api/lineage/freshness'),
  getStaleTables: () =>
    safeFetch('/api/lineage/freshness/stale'),
  updateFreshnessThreshold: (table_fqn: string, stale_threshold_hours: number) =>
    safeFetch('/api/lineage/freshness/threshold', {
      method: 'PUT',
      body: JSON.stringify({ table_fqn, stale_threshold_hours }),
    }),
  markTableRefreshed: (table_fqn: string) =>
    safeFetch('/api/lineage/freshness/mark-refreshed', {
      method: 'POST',
      body: JSON.stringify({ table_fqn }),
    }),

  // ── Phase 52: Admin lineage config ────────────────────────────────────────
  getLineageAdminConfig: () =>
    safeFetch('/api/admin/lineage/config'),
  setLineageAdminConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/lineage/config', {
      method: 'PUT',
      body: JSON.stringify(config),
    }),

  // ── Phase 53: Semantic Layer — Business Datasets ─────────────────────────
  listDatasets: (subject?: string) =>
    safeFetch(`/api/datasets${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`),
  createDataset: (data: Record<string, any>) =>
    safeFetch('/api/datasets', { method: 'POST', body: JSON.stringify(data) }),
  getDataset: (id: number) =>
    safeFetch(`/api/datasets/${id}`),
  updateDataset: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDataset: (id: number) =>
    safeFetch(`/api/datasets/${id}`, { method: 'DELETE' }),
  toggleDatasetPublish: (id: number) =>
    safeFetch(`/api/datasets/${id}/publish`, { method: 'POST' }),
  autoDetectColumns: (id: number) =>
    safeFetch(`/api/datasets/${id}/auto-detect`, { method: 'POST' }),

  // Dataset classes
  listDatasetClasses: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/classes`),
  createDatasetClass: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/classes`, { method: 'POST', body: JSON.stringify(data) }),
  updateDatasetClass: (classId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/classes/${classId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDatasetClass: (classId: number) =>
    safeFetch(`/api/datasets/classes/${classId}`, { method: 'DELETE' }),

  // Dataset columns
  listDatasetColumns: (datasetId: number, columnType?: string) =>
    safeFetch(`/api/datasets/${datasetId}/columns${columnType ? `?column_type=${columnType}` : ''}`),
  createDatasetColumn: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/columns`, { method: 'POST', body: JSON.stringify(data) }),
  bulkCreateDatasetColumns: (datasetId: number, columns: Record<string, any>[]) =>
    safeFetch(`/api/datasets/${datasetId}/columns/bulk`, { method: 'POST', body: JSON.stringify({ columns }) }),
  updateDatasetColumn: (columnId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/columns/${columnId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDatasetColumn: (columnId: number) =>
    safeFetch(`/api/datasets/columns/${columnId}`, { method: 'DELETE' }),

  // Dataset relationships
  listDatasetRelationships: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/relationships`),
  createDatasetRelationship: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/relationships`, { method: 'POST', body: JSON.stringify(data) }),
  updateDatasetRelationship: (relId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/relationships/${relId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDatasetRelationship: (relId: number) =>
    safeFetch(`/api/datasets/relationships/${relId}`, { method: 'DELETE' }),

  // Drill hierarchies
  listDrillHierarchies: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/hierarchies`),
  createDrillHierarchy: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/hierarchies`, { method: 'POST', body: JSON.stringify(data) }),
  updateDrillHierarchy: (hierarchyId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/hierarchies/${hierarchyId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDrillHierarchy: (hierarchyId: number) =>
    safeFetch(`/api/datasets/hierarchies/${hierarchyId}`, { method: 'DELETE' }),

  // Pre-defined conditions
  listPreDefinedConditions: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/conditions`),
  createPreDefinedCondition: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/conditions`, { method: 'POST', body: JSON.stringify(data) }),
  updatePreDefinedCondition: (condId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/conditions/${condId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deletePreDefinedCondition: (condId: number) =>
    safeFetch(`/api/datasets/conditions/${condId}`, { method: 'DELETE' }),

  // Aggregation awareness
  listAggAwareness: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/agg-awareness`),
  createAggAwareness: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/agg-awareness`, { method: 'POST', body: JSON.stringify(data) }),
  deleteAggAwareness: (aggId: number) =>
    safeFetch(`/api/datasets/agg-awareness/${aggId}`, { method: 'DELETE' }),

  // Semantic layer admin config
  getSemanticLayerConfig: () =>
    safeFetch('/api/admin/semantic-layer/config'),
  setSemanticLayerConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/semantic-layer/config', { method: 'PUT', body: JSON.stringify(config) }),

  // ── Federation Engine (Phase 54) ─────────────────────────────────────────
  executeDataset: (datasetId: number, body: {
    column_ids: number[];
    filters?: any[];
    condition_ids?: number[];
    order_by?: any[];
    limit?: number;
  }) =>
    safeFetch(`/api/datasets/${datasetId}/execute`, { method: 'POST', body: JSON.stringify(body) }),

  executeMergedDatasets: (body: {
    primary_dataset_id: number;
    secondary_dataset_id: number;
    primary_column_ids: number[];
    secondary_column_ids: number[];
    merge_keys: { left: string; right: string }[];
    merge_type?: string;
    primary_filters?: any[];
    secondary_filters?: any[];
    primary_condition_ids?: number[];
    secondary_condition_ids?: number[];
    limit?: number;
  }) =>
    safeFetch('/api/datasets/federation/execute', { method: 'POST', body: JSON.stringify(body) }),

  previewDataset: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/preview`),

  getColumnValues: (datasetId: number, body: {
    column_id: number;
    parent_filters?: any[];
    limit?: number;
  }) =>
    safeFetch(`/api/datasets/${datasetId}/column-values`, { method: 'POST', body: JSON.stringify(body) }),

  listDatasetExecutions: (datasetId: number, limit?: number) =>
    safeFetch(`/api/datasets/${datasetId}/executions${limit ? `?limit=${limit}` : ''}`),

  getFederationExecutionDetail: (executionId: string) =>
    safeFetch(`/api/datasets/executions/${executionId}`),

  getFederationExecutionResults: (executionId: string, offset?: number, limit?: number) => {
    const params = new URLSearchParams();
    if (offset !== undefined) params.set('offset', String(offset));
    if (limit !== undefined) params.set('limit', String(limit));
    const qs = params.toString();
    return safeFetch(`/api/datasets/executions/${executionId}/results${qs ? `?${qs}` : ''}`);
  },

  // Merged dimensions
  listMergedDimensions: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/merged-dimensions`),

  createMergedDimension: (body: {
    primary_dataset_id: number;
    secondary_dataset_id: number;
    name: string;
    merge_keys: { left: string; right: string }[];
    merge_type?: string;
    is_active?: boolean;
  }) =>
    safeFetch('/api/datasets/merged-dimensions', { method: 'POST', body: JSON.stringify(body) }),

  updateMergedDimension: (mdId: number, body: Record<string, any>) =>
    safeFetch(`/api/datasets/merged-dimensions/${mdId}`, { method: 'PUT', body: JSON.stringify(body) }),

  deleteMergedDimension: (mdId: number) =>
    safeFetch(`/api/datasets/merged-dimensions/${mdId}`, { method: 'DELETE' }),

  // Federation admin config
  getFederationConfig: () =>
    safeFetch('/api/admin/federation/config'),

  setFederationConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/federation/config', { method: 'PUT', body: JSON.stringify(config) }),

  // ── Phase 55: Aggregation Cache ──────────────────────────────────────────
  listAggCacheEntries: (datasetId: number) =>
    safeFetch(`/api/datasets/${datasetId}/agg-cache`),
  createAggCacheEntry: (datasetId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/${datasetId}/agg-cache`, { method: 'POST', body: JSON.stringify(data) }),
  getAggCacheEntry: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`),
  updateAggCacheEntry: (entryId: number, data: Record<string, any>) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteAggCacheEntry: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}`, { method: 'DELETE' }),
  triggerAggCacheBuild: (entryId: number) =>
    safeFetch(`/api/datasets/agg-cache/${entryId}/build`, { method: 'POST' }),

  getAggCacheStats: () =>
    safeFetch('/api/admin/agg-cache/stats'),
  getAggCacheDatasetStats: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/stats/${datasetId}`),

  listAggCacheSuggestions: () =>
    safeFetch('/api/admin/agg-cache/suggestions'),
  triggerAggCacheAnalysis: () =>
    safeFetch('/api/admin/agg-cache/analyze', { method: 'POST' }),
  approveAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/approve`, { method: 'POST' }),
  rejectAggCacheSuggestion: (id: number) =>
    safeFetch(`/api/admin/agg-cache/suggestions/${id}/reject`, { method: 'POST' }),

  getAggCacheConfig: () =>
    safeFetch('/api/admin/agg-cache/config'),
  setAggCacheConfig: (config: Record<string, any>) =>
    safeFetch('/api/admin/agg-cache/config', { method: 'PUT', body: JSON.stringify(config) }),

  triggerAggCacheCleanup: () =>
    safeFetch('/api/admin/agg-cache/cleanup', { method: 'POST' }),
  invalidateAggCache: (datasetId: number) =>
    safeFetch(`/api/admin/agg-cache/invalidate/${datasetId}`, { method: 'POST' }),
};

export default api;
