"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, Float, Index, UniqueConstraint, event as sa_event, text as sa_text
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any
import json
from contextlib import contextmanager
from pathlib import Path

Base = declarative_base()


class SavedQuery(Base):
    """Model for saved queries"""
    __tablename__ = "saved_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    query_config = Column(JSON, nullable=False)  # Stores QueryConfig as JSON
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)
    is_favorite = Column(Boolean, default=False)
    is_shared = Column(Boolean, default=False)
    execution_count = Column(Integer, default=0)
    last_executed_at = Column(DateTime, nullable=True)
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "query_config": self.query_config,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
            "is_favorite": self.is_favorite or False,
            "is_shared": self.is_shared or False,
            "execution_count": self.execution_count,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id": self.workspace_id,
        }


class QueryExecution(Base):
    """Model for tracking query executions"""
    __tablename__ = "query_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, nullable=True)  # Reference to SavedQuery if applicable
    execution_id = Column(String(100), unique=True, nullable=False, index=True)
    query_config = Column(JSON, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    total_rows = Column(Integer, default=0)
    chunks_processed = Column(Integer, default=0)
    output_file = Column(String(500), nullable=True)
    file_size_bytes = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    executed_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "query_id": self.query_id,
            "execution_id": self.execution_id,
            "query_config": self.query_config,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "total_rows": self.total_rows,
            "chunks_processed": self.chunks_processed,
            "output_file": self.output_file,
            "file_size_bytes": self.file_size_bytes,
            "error_message": self.error_message,
            "executed_by": self.executed_by
        }


class AuditLog(Base):
    """Immutable audit trail — who did what, when, from where."""
    __tablename__ = "audit_log"

    id            = Column(Integer, primary_key=True, index=True)
    timestamp     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    username      = Column(String(100), nullable=False, index=True)
    action        = Column(String(100), nullable=False, index=True)  # execute_query, cancel_query, save_query…
    resource_type = Column(String(50),  nullable=True)               # query, execution, dashboard, connection
    resource_id   = Column(String(200), nullable=True)
    ip_address    = Column(String(50),  nullable=True)
    user_agent    = Column(String(500), nullable=True)
    details       = Column(JSON, nullable=True)                      # arbitrary extra context

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "timestamp":     self.timestamp.isoformat() if self.timestamp else None,
            "username":      self.username,
            "action":        self.action,
            "resource_type": self.resource_type,
            "resource_id":   self.resource_id,
            "ip_address":    self.ip_address,
            "details":       self.details,
        }


class DownloadFile(Base):
    """Model for tracking downloadable files"""
    __tablename__ = "download_files"
    
    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String(100), unique=True, nullable=False, index=True)
    execution_id = Column(String(100), nullable=True, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, default=0)
    status = Column(String(50), default="available")  # available, downloaded, expired, deleted
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at = Column(DateTime, nullable=True)
    download_count = Column(Integer, default=0)
    last_downloaded_at = Column(DateTime, nullable=True)
    created_by = Column(String(100), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "execution_id": self.execution_id,
            "filename": self.filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "download_count": self.download_count,
            "last_downloaded_at": self.last_downloaded_at.isoformat() if self.last_downloaded_at else None,
            "created_by": self.created_by
        }


class SqlSavedQuery(Base):
    """Model for SQL queries executed against SQL connectors (Trino, Snowflake, Databricks)."""
    __tablename__ = "sql_saved_queries"

    id                     = Column(Integer,     primary_key=True, index=True)
    name                   = Column(String(255), nullable=False,   index=True)
    description            = Column(Text,        nullable=True)
    # Primary source
    primary_connection_id  = Column(Integer,     nullable=False)
    primary_sql            = Column(Text,        nullable=False)
    # Optional secondary source for cross-source joins
    secondary_connection_id = Column(Integer,    nullable=True)
    secondary_sql          = Column(Text,        nullable=True)
    # Join config: { how, left_on, right_on, suffixes }
    join_config            = Column(JSON,        nullable=True)
    # Metadata
    created_by             = Column(String(100), nullable=True)
    created_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active              = Column(Boolean,     default=True)
    is_shared              = Column(Boolean,     default=False)
    execution_count        = Column(Integer,     default=0)
    last_executed_at       = Column(DateTime,    nullable=True)
    workspace_id           = Column(Integer,     nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "primary_connection_id":   self.primary_connection_id,
            "primary_sql":             self.primary_sql,
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_sql":           self.secondary_sql,
            "join_config":             self.join_config,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "is_active":               self.is_active,
            "is_shared":               self.is_shared or False,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id":            self.workspace_id,
        }


class Connection(Base):
    """Model for data source connections"""
    __tablename__ = "connections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    connection_type = Column(String(50), nullable=False)
    config = Column(JSON, nullable=False)   # sensitive fields stored encrypted
    is_active = Column(Boolean, default=True)
    is_shared = Column(Boolean, default=False)  # shared with all users
    created_by = Column(String(100), nullable=True)
    last_tested_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(50), nullable=True)  # 'success' or 'failed'
    last_test_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary (config may contain encrypted values)."""
        return {
            "id": self.id,
            "name": self.name,
            "connection_type": self.connection_type,
            "config": self.config,
            "is_active": self.is_active,
            "is_shared": self.is_shared or False,
            "created_by": self.created_by,
            "last_tested_at": self.last_tested_at.isoformat() if self.last_tested_at else None,
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id": self.workspace_id,
        }


class Report(Base):
    """Named parametric report — wraps a saved query or SQL query with a parameter schema."""
    __tablename__ = "reports"

    id                 = Column(Integer,     primary_key=True, index=True)
    name               = Column(String(255), nullable=False,   index=True)
    description        = Column(Text,        nullable=True)

    # Exactly one source is set
    saved_query_id     = Column(Integer, nullable=True)        # → SavedQuery (parquet)
    sql_saved_query_id = Column(Integer, nullable=True)        # → SqlSavedQuery

    # Parameter schema: [{ name, label, type, required, default_value, description }]
    # type: string | number | date | boolean | select
    # If type == select, include options: ["val1", "val2", ...]
    parameters         = Column(JSON, nullable=False, default=list)

    # Optional SQL override (replaces source query's SQL at execution time)
    sql_override       = Column(Text, nullable=True)

    is_active          = Column(Boolean,     default=True)
    is_public          = Column(Boolean,     default=True)
    created_by         = Column(String(100), nullable=True)
    created_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    execution_count    = Column(Integer,     default=0)
    last_executed_at   = Column(DateTime,    nullable=True)

    # Enterprise features
    cache_ttl_minutes      = Column(Integer,  default=0)          # 0 = no caching
    schedule_config        = Column(JSON,     nullable=True)      # { cron, recipients, format, enabled }

    # Phase 24A — optional direct connection override (SQL reports only)
    connection_override_id = Column(Integer,  nullable=True)      # → Connection.id; NULL = use query's default
    workspace_id           = Column(Integer,  nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "saved_query_id":          self.saved_query_id,
            "sql_saved_query_id":      self.sql_saved_query_id,
            "parameters":              self.parameters or [],
            "sql_override":            self.sql_override,
            "is_active":               self.is_active,
            "is_public":               self.is_public,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "cache_ttl_minutes":       self.cache_ttl_minutes or 0,
            "schedule_config":         self.schedule_config,
            "connection_override_id":  self.connection_override_id,
            "workspace_id":            self.workspace_id,
        }


class Schedule(Base):
    """Scheduled automatic query/report execution → downloads directory."""
    __tablename__ = "schedules"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    is_active       = Column(Boolean,     default=True)
    is_shared       = Column(Boolean,     default=False)

    # Source type: "saved_query" | "sql_query" | "report"
    source_type     = Column(String(50),  nullable=False)
    source_id       = Column(Integer,     nullable=False)

    # Parameter values to pass to the source at run time
    param_values    = Column(JSON, nullable=True)

    # Trigger config:
    #   { "type": "cron",     "cron_expr": "0 8 * * 1-5" }
    #   { "type": "interval", "minutes": 60 }
    trigger_config  = Column(JSON, nullable=False)

    # Output filename template — {date} is replaced with YYYYMMDD_HHMMSS
    output_filename_template = Column(String(255), nullable=True)

    # APScheduler job ID (stored so we can pause/remove specific jobs)
    apscheduler_job_id = Column(String(100), nullable=True, unique=True)

    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Run tracking
    last_run_at     = Column(DateTime, nullable=True)
    last_run_status = Column(String(50), nullable=True)   # success | failed
    last_run_file_id= Column(String(100), nullable=True)
    last_error      = Column(Text, nullable=True)
    run_count       = Column(Integer, default=0)
    next_run_at     = Column(DateTime, nullable=True)

    # Email notifications — comma-separated list of addresses to notify on completion/failure
    notify_emails   = Column(Text, nullable=True)   # e.g. "alice@corp.com,bob@corp.com"
    # Webhook URL for Slack/Teams/generic HTTP POST notifications
    notify_webhook  = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "description":      self.description,
            "is_active":        self.is_active,
            "is_shared":        self.is_shared or False,
            "source_type":      self.source_type,
            "source_id":        self.source_id,
            "param_values":     self.param_values,
            "trigger_config":   self.trigger_config,
            "output_filename_template": self.output_filename_template,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
            "last_run_at":      self.last_run_at.isoformat() if self.last_run_at else None,
            "last_run_status":  self.last_run_status,
            "last_run_file_id": self.last_run_file_id,
            "last_error":       self.last_error,
            "run_count":        self.run_count,
            "next_run_at":      self.next_run_at.isoformat() if self.next_run_at else None,
            "notify_emails":    self.notify_emails,
            "notify_webhook":   self.notify_webhook,
        }


# ── New enterprise models ─────────────────────────────────────────────────────

class QueryCacheEntry(Base):
    """Disk-backed parquet cache keyed by sha256 of canonical query_config JSON."""
    __tablename__ = "query_result_cache"

    cache_key       = Column(String(64), primary_key=True)
    file_path       = Column(String(500), nullable=False)
    row_count       = Column(Integer, default=0)
    file_size_bytes = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at      = Column(DateTime, nullable=True)
    query_config    = Column(JSON, nullable=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    hit_count       = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cache_key":       self.cache_key,
            "file_path":       self.file_path,
            "row_count":       self.row_count,
            "file_size_bytes": self.file_size_bytes,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "expires_at":      self.expires_at.isoformat() if self.expires_at else None,
            "connection_id":   self.connection_id,
            "hit_count":       self.hit_count or 0,
            "query_config":    self.query_config,
        }


class PartitionCache(Base):
    """Persistent cache for Iceberg partition metadata — survives restarts."""
    __tablename__ = "partition_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    scan_type       = Column(String(10), default="fast")   # "fast" or "full"
    partition_data  = Column(JSON, nullable=False)          # full response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_partition_cache_lookup', 'connection_id', 'table_name', 'scan_type', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "scan_type":      self.scan_type,
            "partition_data": self.partition_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergFileCache(Base):
    """Persistent L2 cache for Iceberg data-file lists — avoids re-scanning S3 manifests."""
    __tablename__ = "iceberg_file_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    filters_hash    = Column(String(512), nullable=False, default="")
    file_list       = Column(JSON, nullable=False)          # list of S3 file paths
    file_count      = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_file_cache_lookup', 'connection_id', 'table_name', 'filters_hash', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "filters_hash":   self.filters_hash,
            "file_list":      self.file_list,
            "file_count":     self.file_count,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class SchemaCache(Base):
    """Persistent cache for registered table schemas — avoids repeated S3 metadata reads."""
    __tablename__ = "schema_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    table_format    = Column(String(20), default="iceberg")     # iceberg, parquet, csv
    schema_data     = Column(JSON, nullable=False)              # full schema response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_schema_cache_lookup', 'connection_id', 'table_name', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "table_format":   self.table_format,
            "schema_data":    self.schema_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class QueryVersion(Base):
    """Immutable snapshot of a SavedQuery before each update."""
    __tablename__ = "query_versions"

    id             = Column(Integer, primary_key=True, index=True)
    query_id       = Column(Integer, nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    name           = Column(String(255), nullable=True)
    description    = Column(Text, nullable=True)
    query_config   = Column(JSON, nullable=True)
    changed_by     = Column(String(100), nullable=True)
    changed_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    change_note    = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "query_id":       self.query_id,
            "version_number": self.version_number,
            "name":           self.name,
            "description":    self.description,
            "query_config":   self.query_config,
            "changed_by":     self.changed_by,
            "changed_at":     self.changed_at.isoformat() if self.changed_at else None,
            "change_note":    self.change_note,
        }


class QueryShare(Base):
    """Share token for a saved query — allows public access via /api/shared/{token}."""
    __tablename__ = "query_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    query_id     = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "query_id":     self.query_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class DashboardShare(Base):
    """Share token for a dashboard — allows public access via /api/shared-dashboard/{token}."""
    __tablename__ = "dashboard_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "dashboard_id": self.dashboard_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class ReportEmbedToken(Base):
    """Embed token for a report — allows iframe embedding in external portals without login."""
    __tablename__ = "report_embed_tokens"

    id             = Column(Integer, primary_key=True, index=True)
    token          = Column(String(64), unique=True, nullable=False, index=True)
    report_id      = Column(Integer, nullable=False, index=True)
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at     = Column(DateTime, nullable=True)
    is_active      = Column(Boolean, default=True)
    access_count   = Column(Integer, default=0)
    allowed_params = Column(Text, nullable=True)  # JSON string

    def to_dict(self) -> Dict[str, Any]:
        import json as _json
        return {
            "id":             self.id,
            "token":          self.token,
            "report_id":      self.report_id,
            "created_by":     self.created_by,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "expires_at":     self.expires_at.isoformat() if self.expires_at else None,
            "is_active":      self.is_active,
            "access_count":   self.access_count,
            "allowed_params": _json.loads(self.allowed_params) if self.allowed_params else None,
        }


class Dashboard(Base):
    """Named canvas that holds multiple report widgets."""
    __tablename__ = "dashboards"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active   = Column(Boolean, default=True)
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "is_active":   self.is_active,
            "workspace_id": self.workspace_id,
        }


class DashboardWidget(Base):
    """Single widget on a dashboard canvas — references a saved query / SQL query / report."""
    __tablename__ = "dashboard_widgets"

    id           = Column(Integer, primary_key=True, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    # "saved_query" | "sql_query" | "report"
    widget_type  = Column(String(50), nullable=False)
    source_id    = Column(Integer, nullable=False)
    title        = Column(String(255), nullable=True)
    # react-grid-layout position: {x, y, w, h}
    layout       = Column(JSON, nullable=True)
    # "grid" | "bar" | "line" | "area" | "pie" | "scatter" | "metric"
    chart_type   = Column(String(50), default="grid")
    # chart config: axis fields, colors, aggregation
    chart_config = Column(JSON, nullable=True)
    # parameter overrides for report widgets
    param_values = Column(JSON, nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "dashboard_id": self.dashboard_id,
            "widget_type":  self.widget_type,
            "source_id":    self.source_id,
            "title":        self.title,
            "layout":       self.layout or {"x": 0, "y": 0, "w": 6, "h": 4},
            "chart_type":   self.chart_type or "grid",
            "chart_config": self.chart_config or {},
            "param_values": self.param_values or {},
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class MaterializedView(Base):
    """Pre-downloaded S3 data for instant local DuckDB queries."""
    __tablename__ = "materialized_views"

    id                    = Column(Integer, primary_key=True, index=True)
    name                  = Column(String(255), nullable=False, unique=True, index=True)
    description           = Column(Text, nullable=True)
    connection_id         = Column(Integer, nullable=False)
    table_name            = Column(String(255), nullable=False)
    table_format          = Column(String(50), default="parquet")      # iceberg/parquet/csv
    partition_filter      = Column(JSON, nullable=True)                # {"date_col":"dt","from":"2025-01-01","to":"2025-12-31"}
    query_filter          = Column(Text, nullable=True)                # optional WHERE clause

    # Refresh state
    status                = Column(String(50), default="pending")      # pending/refreshing/ready/failed
    last_refresh_at       = Column(DateTime, nullable=True)
    last_refresh_duration = Column(Float, nullable=True)               # seconds
    row_count             = Column(Integer, default=0)
    file_count            = Column(Integer, default=0)
    size_bytes            = Column(Integer, default=0)
    last_error            = Column(Text, nullable=True)

    # Schedule (optional auto-refresh)
    schedule_config       = Column(JSON, nullable=True)                # {"type":"cron","cron_expr":"..."} or {"type":"interval","hours":N}
    apscheduler_job_id    = Column(String(100), nullable=True, unique=True)
    next_refresh_at       = Column(DateTime, nullable=True)

    # Metadata
    created_by            = Column(String(100), nullable=True)
    created_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active             = Column(Boolean, default=True)
    workspace_id          = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "name":                  self.name,
            "description":           self.description,
            "connection_id":         self.connection_id,
            "table_name":            self.table_name,
            "table_format":          self.table_format,
            "partition_filter":      self.partition_filter,
            "query_filter":          self.query_filter,
            "status":                self.status,
            "last_refresh_at":       self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "last_refresh_duration": self.last_refresh_duration,
            "row_count":             self.row_count,
            "file_count":            self.file_count,
            "size_bytes":            self.size_bytes,
            "last_error":            self.last_error,
            "schedule_config":       self.schedule_config,
            "apscheduler_job_id":    self.apscheduler_job_id,
            "next_refresh_at":       self.next_refresh_at.isoformat() if self.next_refresh_at else None,
            "created_by":            self.created_by,
            "created_at":            self.created_at.isoformat() if self.created_at else None,
            "updated_at":            self.updated_at.isoformat() if self.updated_at else None,
            "is_active":             self.is_active,
            "workspace_id":          self.workspace_id,
        }


class LocalTable(Base):
    """User-created local tables from downloads or file uploads, stored as parquet."""
    __tablename__ = "local_tables"

    id                = Column(Integer, primary_key=True, index=True)
    name              = Column(String(255), nullable=False, unique=True, index=True)
    description       = Column(Text, nullable=True)
    source_type       = Column(String(50), nullable=False)       # "download_promote" | "file_upload"
    source_file_id    = Column(String(100), nullable=True)       # DownloadFile.file_id if promoted
    original_filename = Column(String(500), nullable=True)

    # Storage
    storage_path      = Column(String(500), nullable=False)      # data/local_tables/{id}
    file_format       = Column(String(50), default="parquet")
    row_count         = Column(Integer, default=0)
    file_count        = Column(Integer, default=0)
    size_bytes        = Column(Integer, default=0)
    schema_json       = Column(JSON, nullable=True)              # cached column names/types

    # Visibility & lifecycle
    visibility        = Column(String(20), default="public")     # "public" | "private"
    is_active         = Column(Boolean, default=True)
    last_accessed_at  = Column(DateTime, nullable=True)
    auto_discard_days = Column(Integer, default=10)              # 0 = never discard

    # Status
    status            = Column(String(50), default="pending")    # pending/processing/ready/failed
    last_error        = Column(Text, nullable=True)

    # Metadata
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id      = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "name":              self.name,
            "description":       self.description,
            "source_type":       self.source_type,
            "source_file_id":    self.source_file_id,
            "original_filename": self.original_filename,
            "storage_path":      self.storage_path,
            "file_format":       self.file_format,
            "row_count":         self.row_count,
            "file_count":        self.file_count,
            "size_bytes":        self.size_bytes,
            "schema_json":       self.schema_json,
            "visibility":        self.visibility,
            "is_active":         self.is_active,
            "last_accessed_at":  self.last_accessed_at.isoformat() if self.last_accessed_at else None,
            "auto_discard_days": self.auto_discard_days,
            "status":            self.status,
            "last_error":        self.last_error,
            "created_by":        self.created_by,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id":      self.workspace_id,
        }


class PendingNotification(Base):
    """Cross-process notification queue.

    The scheduler worker writes notifications here (scheduled job started/completed/failed).
    The FastAPI process polls undelivered rows and broadcasts them via WebSocket,
    then marks them as delivered.  Used when scheduler.mode = "external".
    """
    __tablename__ = "pending_notifications"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    payload      = Column(JSON, nullable=False)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered    = Column(Boolean, default=False, index=True)
    delivered_at = Column(DateTime, nullable=True)


class TaskQueue(Base):
    """Cross-process task queue for executor service.

    FastAPI enqueues tasks here (status='pending').
    Executor worker claims them (status='claimed'), runs them,
    and updates status to 'completed' or 'failed'.
    FastAPI polls for completed tasks and broadcasts WS notifications.
    Only used when executor.mode = "external".
    """
    __tablename__ = "task_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False, index=True)
    status          = Column(String(20), default="pending", nullable=False, index=True)
    priority        = Column(Integer, default=5)
    payload         = Column(JSON, nullable=False)
    result          = Column(JSON, nullable=True)
    error_message   = Column(Text, nullable=True)
    progress_pct    = Column(Integer, default=0)
    progress_detail = Column(Text, nullable=True)
    execution_id    = Column(String(100), nullable=True, index=True)
    claimed_by      = Column(String(100), nullable=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    claimed_at      = Column(DateTime, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)
    timeout_seconds = Column(Integer, default=1800)
    retry_count      = Column(Integer, default=0)
    max_retries      = Column(Integer, default=3)
    next_retry_at    = Column(DateTime, nullable=True, index=True)  # for backoff scheduling
    cancel_requested = Column(Integer, default=0)  # 0=no, 1=cancel requested

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "task_id": self.task_id,
            "task_type": self.task_type, "status": self.status,
            "priority": self.priority,
            "payload": self.payload, "result": self.result,
            "error_message": self.error_message,
            "progress_pct": self.progress_pct,
            "progress_detail": self.progress_detail,
            "execution_id": self.execution_id,
            "claimed_by": self.claimed_by,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "timeout_seconds": self.timeout_seconds,
            "retry_count": self.retry_count, "max_retries": self.max_retries,
            "next_retry_at": self.next_retry_at.isoformat() if self.next_retry_at else None,
            "cancel_requested": bool(self.cancel_requested),
        }


class DeadLetterQueue(Base):
    """Permanently failed tasks that exhausted all retries (Phase 22C)."""
    __tablename__ = "dead_letter_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False)
    payload         = Column(JSON, nullable=False)
    execution_id    = Column(String(100), nullable=True, index=True)
    created_by      = Column(String(100), nullable=True)
    original_error  = Column(Text, nullable=True)
    retry_count     = Column(Integer, default=0)
    first_failed_at = Column(DateTime, nullable=True)
    dead_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    resolved        = Column(Integer, default=0)   # 0=open, 1=resolved/requeued
    resolved_at     = Column(DateTime, nullable=True)
    resolved_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "task_id": self.task_id,
            "task_type": self.task_type,
            "payload": self.payload,
            "execution_id": self.execution_id,
            "created_by": self.created_by,
            "original_error": self.original_error,
            "retry_count": self.retry_count,
            "first_failed_at": self.first_failed_at.isoformat() if self.first_failed_at else None,
            "dead_at": self.dead_at.isoformat() if self.dead_at else None,
            "resolved": bool(self.resolved),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }


class TableFavorite(Base):
    """User's favorited tables (any type: registered, MV, local, file)."""
    __tablename__ = "table_favorites"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_path    = Column(String(500), nullable=False)
    table_name    = Column(String(255), nullable=False)
    table_type    = Column(String(50), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "username": self.username,
            "connection_id": self.connection_id,
            "table_path": self.table_path, "table_name": self.table_name,
            "table_type": self.table_type,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class NotificationLog(Base):
    """Persistent notification history with delivery tracking."""
    __tablename__ = "notification_log"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    event_type     = Column(String(50), nullable=False, index=True)    # execution_completed, schedule_failed, etc.
    channel        = Column(String(20), nullable=False, index=True)    # websocket, email, webhook
    recipient      = Column(String(200), nullable=False, index=True)   # username, email addr, or webhook URL
    status         = Column(String(20), default="pending", index=True) # pending, sent, failed, delivered
    title          = Column(String(300), nullable=True)
    message        = Column(Text, nullable=True)
    payload        = Column(JSON, nullable=True)
    error_message  = Column(Text, nullable=True)
    attempt_count  = Column(Integer, default=0)
    max_attempts   = Column(Integer, default=3)
    execution_id   = Column(String(100), nullable=True, index=True)
    schedule_id    = Column(Integer, nullable=True)
    is_read        = Column(Integer, default=0)   # 0=unread, 1=read
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at   = Column(DateTime, nullable=True)
    read_at        = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "event_type": self.event_type,
            "channel": self.channel,
            "recipient": self.recipient,
            "status": self.status,
            "title": self.title,
            "message": self.message,
            "payload": self.payload,
            "error_message": self.error_message,
            "attempt_count": self.attempt_count,
            "execution_id": self.execution_id,
            "schedule_id": self.schedule_id,
            "is_read": bool(self.is_read),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
            "read_at": self.read_at.isoformat() if self.read_at else None,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 23: Enterprise Reporting Models (additive — existing models unchanged)
# ═══════════════════════════════════════════════════════════════════════════════


class ReportFolder(Base):
    """Folder for organizing reports into a hierarchy (23A)."""
    __tablename__ = "report_folders"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    parent_id   = Column(Integer, nullable=True, index=True)   # None = root folder
    icon        = Column(String(50),  nullable=True, default="folder")
    color       = Column(String(20),  nullable=True, default="#1976d2")
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "parent_id": self.parent_id, "icon": self.icon or "folder",
            "color": self.color or "#1976d2", "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportFolderAssignment(Base):
    """Maps a report to a folder (separate table — Report model untouched) (23A)."""
    __tablename__ = "report_folder_assignments"

    report_id  = Column(Integer, primary_key=True)
    folder_id  = Column(Integer, nullable=False, index=True)
    assigned_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class ReportTag(Base):
    """Tag label for reports (23A)."""
    __tablename__ = "report_tags"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    name       = Column(String(100), nullable=False, unique=True, index=True)
    color      = Column(String(20),  nullable=True, default="#666666")
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "name": self.name, "color": self.color or "#666666",
                "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None}


class ReportTagAssignment(Base):
    """Many-to-many: report ↔ tag (23A)."""
    __tablename__ = "report_tag_assignments"

    id        = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, nullable=False, index=True)
    tag_id    = Column(Integer, nullable=False, index=True)


class ReportFavorite(Base):
    """User-level report favorite (23A)."""
    __tablename__ = "report_favorites"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    report_id  = Column(Integer, nullable=False, index=True)
    username   = Column(String(100), nullable=False, index=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class ReportView(Base):
    """Recently-viewed tracker per user (23A). Kept at last N entries per user."""
    __tablename__ = "report_views"

    id        = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(Integer, nullable=False, index=True)
    username  = Column(String(100), nullable=False, index=True)
    viewed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)


class RLSPolicy(Base):
    """Row-Level Security policy — injected as extra WHERE at execution time (23G)."""
    __tablename__ = "rls_policies"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    report_id      = Column(Integer, nullable=False, index=True)
    column_name    = Column(String(255), nullable=False)   # DB/Parquet column to filter
    # operator: = | != | IN | NOT IN | LIKE | >  < (for numeric ranges)
    operator       = Column(String(10),  nullable=False, default="=")
    # value_template: literal "sales" | token "{username}" | "{department}"
    value_template = Column(String(500), nullable=False)
    is_enabled     = Column(Boolean, default=True)
    description    = Column(String(500), nullable=True)
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "column_name": self.column_name, "operator": self.operator,
            "value_template": self.value_template, "is_enabled": self.is_enabled,
            "description": self.description, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportBookmark(Base):
    """Named saved parameter set for a report, per user (23B)."""
    __tablename__ = "report_bookmarks"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    report_id    = Column(Integer, nullable=False, index=True)
    username     = Column(String(100), nullable=False, index=True)
    name         = Column(String(255), nullable=False)
    param_values = Column(JSON, nullable=False, default=dict)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "username": self.username,
            "name": self.name, "param_values": self.param_values or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportPDFConfig(Base):
    """PDF export layout configuration per report (23D)."""
    __tablename__ = "report_pdf_configs"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, unique=True, index=True)
    orientation   = Column(String(20), default="landscape")   # landscape | portrait
    paper_size    = Column(String(10), default="A4")          # A4 | Letter | Legal
    include_cover = Column(Boolean, default=False)
    include_header = Column(Boolean, default=True)
    include_footer = Column(Boolean, default=True)
    logo_url      = Column(String(500), nullable=True)
    header_text   = Column(String(500), nullable=True)
    footer_text   = Column(String(500), nullable=True,
                           default="Generated by QueryStudio | Page {page} of {total}")
    font_size     = Column(Integer, default=11)
    max_rows      = Column(Integer, default=10000)
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                           onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "report_id": self.report_id, "orientation": self.orientation,
            "paper_size": self.paper_size, "include_cover": self.include_cover,
            "include_header": self.include_header, "include_footer": self.include_footer,
            "logo_url": self.logo_url, "header_text": self.header_text,
            "footer_text": self.footer_text, "font_size": self.font_size,
            "max_rows": self.max_rows,
        }


class BurstJob(Base):
    """Report burst job — distributes one report run per dimension value (23E)."""
    __tablename__ = "burst_jobs"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    burst_column      = Column(String(255), nullable=False)      # column to split on
    base_params       = Column(JSON, nullable=True)              # shared params for all tasks
    output_format     = Column(String(10), default="pdf")        # pdf | excel | csv
    delivery_type     = Column(String(10), default="email")      # email | s3
    s3_prefix         = Column(String(500), nullable=True)       # "reports/{value}/"
    recipient_map     = Column(JSON, nullable=True)              # {"APAC": "apac@co.com", ...}
    default_recipient = Column(String(500), nullable=True)
    status            = Column(String(20), default="pending", index=True)
    total_tasks       = Column(Integer, default=0)
    done_tasks        = Column(Integer, default=0)
    failed_tasks      = Column(Integer, default=0)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    started_at        = Column(DateTime, nullable=True)
    completed_at      = Column(DateTime, nullable=True)
    error_message     = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "burst_column": self.burst_column, "base_params": self.base_params,
            "output_format": self.output_format, "delivery_type": self.delivery_type,
            "s3_prefix": self.s3_prefix, "recipient_map": self.recipient_map,
            "default_recipient": self.default_recipient, "status": self.status,
            "total_tasks": self.total_tasks, "done_tasks": self.done_tasks,
            "failed_tasks": self.failed_tasks, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error_message": self.error_message,
        }


class BurstTask(Base):
    """One task in a burst job — one row per distinct dimension value (23E)."""
    __tablename__ = "burst_tasks"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    burst_job_id    = Column(Integer, nullable=False, index=True)
    dimension_value = Column(String(500), nullable=False)   # e.g. "APAC", "Finance"
    recipient       = Column(String(500), nullable=True)    # email or S3 path
    output_file     = Column(String(500), nullable=True)
    status          = Column(String(20), default="pending", index=True)
    execution_id    = Column(String(100), nullable=True)
    error_message   = Column(Text, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "burst_job_id": self.burst_job_id,
            "dimension_value": self.dimension_value, "recipient": self.recipient,
            "output_file": self.output_file, "status": self.status,
            "execution_id": self.execution_id, "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class AlertRule(Base):
    """Threshold alert rule on a report metric (23F)."""
    __tablename__ = "alert_rules"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    name              = Column(String(255), nullable=False)
    column_name       = Column(String(255), nullable=False)
    aggregation       = Column(String(20), default="last")    # last | sum | avg | max | min | count
    operator          = Column(String(5),  nullable=False)    # > | < | >= | <= | = | !=
    threshold_value   = Column(Float, nullable=False)
    channels          = Column(JSON, nullable=False, default=list)  # ["email","slack"]
    recipients        = Column(Text, nullable=True)           # comma-separated emails
    slack_webhook     = Column(String(500), nullable=True)
    cooldown_minutes  = Column(Integer, default=60)
    is_enabled        = Column(Boolean, default=True)
    last_triggered_at = Column(DateTime, nullable=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "name": self.name,
            "column_name": self.column_name, "aggregation": self.aggregation,
            "operator": self.operator, "threshold_value": self.threshold_value,
            "channels": self.channels or [], "recipients": self.recipients,
            "slack_webhook": self.slack_webhook, "cooldown_minutes": self.cooldown_minutes,
            "is_enabled": self.is_enabled,
            "last_triggered_at": self.last_triggered_at.isoformat() if self.last_triggered_at else None,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AlertHistory(Base):
    """Record of each alert trigger event (23F)."""
    __tablename__ = "alert_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    rule_id         = Column(Integer, nullable=False, index=True)
    triggered_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    actual_value    = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    channel         = Column(String(20), nullable=True)
    sent_to         = Column(String(500), nullable=True)
    was_suppressed  = Column(Boolean, default=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "rule_id": self.rule_id,
            "triggered_at": self.triggered_at.isoformat() if self.triggered_at else None,
            "actual_value": self.actual_value, "threshold_value": self.threshold_value,
            "channel": self.channel, "sent_to": self.sent_to,
            "was_suppressed": self.was_suppressed,
        }


class ConditionalFormatRule(Base):
    """Cell/row formatting rule per column on a report (23C)."""
    __tablename__ = "conditional_format_rules"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    report_id       = Column(Integer, nullable=False, index=True)
    column_name     = Column(String(255), nullable=False)
    rule_order      = Column(Integer, default=0)          # ascending priority
    # condition_type: value_range | equals | contains | not_null | is_null | top_n | bottom_n
    condition_type  = Column(String(30), nullable=False)
    condition_value = Column(JSON, nullable=True)         # {"min":0,"max":50} / {"text":"err"}
    bg_color        = Column(String(20), nullable=True)   # "#ff4444"
    text_color      = Column(String(20), nullable=True)   # "#ffffff"
    # icon: none | arrow_up | arrow_down | check | warning | danger | info
    icon            = Column(String(30), nullable=True, default="none")
    bold            = Column(Boolean, default=False)
    is_enabled      = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "column_name": self.column_name,
            "rule_order": self.rule_order, "condition_type": self.condition_type,
            "condition_value": self.condition_value, "bg_color": self.bg_color,
            "text_color": self.text_color, "icon": self.icon or "none",
            "bold": self.bold, "is_enabled": self.is_enabled,
        }


class CloudDeliveryConfig(Base):
    """Cloud storage delivery config per schedule (23H)."""
    __tablename__ = "cloud_delivery_configs"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=False, unique=True, index=True)
    provider        = Column(String(20), nullable=False)          # s3 | azure | gcs
    bucket          = Column(String(255), nullable=True)
    prefix_template = Column(String(500), nullable=True)          # "reports/{report_name}/{date}/"
    formats         = Column(JSON, nullable=False, default=list)  # ["pdf","excel","csv"]
    zip_bundle      = Column(Boolean, default=False)
    connection_id   = Column(Integer, nullable=True)              # reuse existing S3 connection creds
    is_enabled      = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id, "provider": self.provider,
            "bucket": self.bucket, "prefix_template": self.prefix_template,
            "formats": self.formats or [], "zip_bundle": self.zip_bundle,
            "connection_id": self.connection_id, "is_enabled": self.is_enabled,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DeliveryHistory(Base):
    """Log of every report delivery attempt (23H)."""
    __tablename__ = "delivery_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=True, index=True)
    burst_task_id   = Column(Integer, nullable=True, index=True)
    execution_id    = Column(String(100), nullable=True)
    delivery_type   = Column(String(20), nullable=False)   # email | s3 | azure | gcs | slack
    destination     = Column(String(500), nullable=True)
    file_format     = Column(String(10), nullable=True)    # pdf | excel | csv | zip
    file_size_bytes = Column(Integer, nullable=True)
    status          = Column(String(20), default="pending", index=True)
    error_message   = Column(Text, nullable=True)
    attempted_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id,
            "burst_task_id": self.burst_task_id, "execution_id": self.execution_id,
            "delivery_type": self.delivery_type, "destination": self.destination,
            "file_format": self.file_format, "file_size_bytes": self.file_size_bytes,
            "status": self.status, "error_message": self.error_message,
            "attempted_at": self.attempted_at.isoformat() if self.attempted_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
        }


class ConnectionProfile(Base):
    """Named environment profile for connection substitution (Phase 24B).

    One profile is active at a time. When active, its mappings redirect any
    matching connection to its target equivalent (e.g. dev_snowflake → prod_snowflake).
    """
    __tablename__ = "connection_profiles"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=False)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class ConnectionProfileMapping(Base):
    """One source→target connection substitution rule within a ConnectionProfile (Phase 24B)."""
    __tablename__ = "connection_profile_mappings"

    id                   = Column(Integer, primary_key=True, autoincrement=True)
    profile_id           = Column(Integer, nullable=False, index=True)  # → ConnectionProfile.id
    source_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. dev)
    target_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. prod)
    description          = Column(String(500), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                   self.id,
            "profile_id":           self.profile_id,
            "source_connection_id": self.source_connection_id,
            "target_connection_id": self.target_connection_id,
            "description":          self.description,
        }


class Workspace(Base):
    """Named workspace / project for isolating team assets (Phase 25)."""
    __tablename__ = "workspaces"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    slug        = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "slug":        self.slug,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class WorkspaceMember(Base):
    """Member of a workspace with a role (Phase 25)."""
    __tablename__ = "workspace_members"

    id           = Column(Integer,     primary_key=True, autoincrement=True)
    workspace_id = Column(Integer,     nullable=False, index=True)  # → Workspace.id
    username     = Column(String(100), nullable=False, index=True)
    role         = Column(String(20),  nullable=False, default="member")  # owner/admin/member
    added_by     = Column(String(100), nullable=True)
    added_at     = Column(DateTime,    default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "workspace_id": self.workspace_id,
            "username":     self.username,
            "role":         self.role,
            "added_by":     self.added_by,
            "added_at":     self.added_at.isoformat() if self.added_at else None,
        }


class ScheduleRunStats(Base):
    """Per-run statistics for scheduled report anomaly detection (Phase 38)."""
    __tablename__ = "schedule_run_stats"

    id                = Column(Integer, primary_key=True, index=True)
    schedule_id       = Column(Integer, nullable=False, index=True)
    run_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    row_count         = Column(Integer, default=0)
    execution_seconds = Column(Float, default=0.0)
    file_size_bytes   = Column(Integer, default=0)
    anomaly_type      = Column(String(50), nullable=True)    # null = normal
    anomaly_details   = Column(JSON, nullable=True)          # z_score, message, etc.

    def to_dict(self):
        return {
            "id": self.id,
            "schedule_id": self.schedule_id,
            "run_at": self.run_at.isoformat() if self.run_at else None,
            "row_count": self.row_count,
            "execution_seconds": self.execution_seconds,
            "file_size_bytes": self.file_size_bytes,
            "anomaly_type": self.anomaly_type,
            "anomaly_details": self.anomaly_details,
        }


class ExecutionCheckpoint(Base):
    """Checkpoint for in-progress query executions — survives server restarts (Phase 41)."""
    __tablename__ = "execution_checkpoints"
    execution_id = Column(String(36), primary_key=True)
    state = Column(String(20), nullable=False)  # "intent" | "running"
    query_config = Column(JSON, nullable=True)
    executed_by = Column(String(200), nullable=True)
    query_id = Column(Integer, nullable=True)
    timestamp = Column(Float, nullable=False)


class TableLineageEntry(Base):
    """Physical table referenced by a query — extracted via SQL parsing (Phase 49)."""
    __tablename__ = "table_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)  # "sql_query" | "parquet_query" | "report"
    query_id = Column(Integer, nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_catalog = Column(String(255), nullable=True)
    table_schema = Column(String(255), nullable=True)
    table_name = Column(String(255), nullable=False, index=True)
    access_type = Column(String(10), default="read")  # "read" | "write"
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    extraction_method = Column(String(20), default="sqlglot")  # "sqlglot" | "regex_fallback"

    __table_args__ = (
        Index('ix_table_lineage_query', 'query_type', 'query_id'),
        Index('ix_table_lineage_table', 'table_catalog', 'table_schema', 'table_name'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "connection_id": self.connection_id,
            "table_catalog": self.table_catalog,
            "table_schema": self.table_schema,
            "table_name": self.table_name,
            "access_type": self.access_type,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
            "extraction_method": self.extraction_method,
        }


class LineageSnapshot(Base):
    """Snapshot of lineage at query execution time (Phase 52)."""
    __tablename__ = "lineage_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String(36), nullable=False, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query" | "parquet_query"
    query_id = Column(Integer, nullable=False, index=True)
    snapshot_data = Column(Text, nullable=False)   # JSON blob of {tables, columns}
    captured_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    __table_args__ = (
        Index('ix_lineage_snapshot_query', 'query_type', 'query_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.snapshot_data) if self.snapshot_data else {}
        except Exception:
            data = {}
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "snapshot_data": data,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
        }


class DataFreshness(Base):
    """Per-table data freshness tracking (Phase 52)."""
    __tablename__ = "data_freshness"

    id = Column(Integer, primary_key=True, index=True)
    table_fqn = Column(String(512), nullable=False, unique=True, index=True)  # catalog.schema.table or schema.table
    connection_id = Column(Integer, nullable=True)
    last_observed_at = Column(DateTime, nullable=True)   # last time a query read this table
    last_refresh_at = Column(DateTime, nullable=True)    # manually marked as refreshed
    freshness_status = Column(String(20), default="unknown")  # fresh | stale | unknown
    stale_threshold_hours = Column(Integer, default=24)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "table_fqn": self.table_fqn,
            "connection_id": self.connection_id,
            "last_observed_at": self.last_observed_at.isoformat() if self.last_observed_at else None,
            "last_refresh_at": self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "freshness_status": self.freshness_status,
            "stale_threshold_hours": self.stale_threshold_hours,
        }


class QueryUsageStat(Base):
    """Tracks table/column usage frequency for auto-suggest (Phase 46)."""
    __tablename__ = "query_usage_stats"

    id = Column(Integer, primary_key=True, index=True)
    object_type = Column(String(10), nullable=False, index=True)  # "table" | "column"
    object_name = Column(String(255), nullable=False, index=True)  # table name or "schema.table.column"
    table_name = Column(String(255), nullable=True, index=True)   # parent table (for columns)
    schema_name = Column(String(255), nullable=True)
    catalog_name = Column(String(255), nullable=True)
    connection_id = Column(Integer, nullable=True, index=True)
    use_count = Column(Integer, default=1)
    last_used_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_usage_stat_lookup', 'object_type', 'object_name', 'connection_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "object_type": self.object_type,
            "object_name": self.object_name,
            "table_name": self.table_name,
            "schema_name": self.schema_name,
            "catalog_name": self.catalog_name,
            "connection_id": self.connection_id,
            "use_count": self.use_count,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
        }


class ColumnLineageEntry(Base):
    """Column-to-column lineage extracted from SQL (Phase 51)."""
    __tablename__ = "column_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query"
    query_id = Column(Integer, nullable=False, index=True)
    source_table = Column(String(255), nullable=True)
    source_column = Column(String(255), nullable=True)
    target_column = Column(String(255), nullable=False)
    transform_type = Column(String(20), default="direct")  # direct|renamed|computed|aggregated|casted|star_expansion
    transform_expr = Column(Text, nullable=True)
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_col_lineage_query', 'query_type', 'query_id'),
        Index('ix_col_lineage_source', 'source_table', 'source_column'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_column": self.target_column,
            "transform_type": self.transform_type,
            "transform_expr": self.transform_expr,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
        }


class NLFeedback(Base):
    """
    Stores user-confirmed NL→SQL pairs (thumbs-up feedback).
    The NL-to-SQL engine uses these as learned custom patterns.
    """
    __tablename__ = "nl_feedback"
    id           = Column(Integer, primary_key=True, autoincrement=True)
    question     = Column(String(500), nullable=False)
    sql          = Column(Text, nullable=False)
    connection_type = Column(String(50), default="duckdb")
    tables_hint  = Column(String(500), nullable=True)   # comma-separated table names used
    rating       = Column(Integer, default=1)            # 1 = thumbs-up, -1 = thumbs-down
    use_count    = Column(Integer, default=1)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "sql": self.sql,
            "connection_type": self.connection_type,
            "tables_hint": self.tables_hint,
            "rating": self.rating,
            "use_count": self.use_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class UIComponentVisibility(Base):
    """
    Controls which UI pages/components are enabled per role.
    Defaults to all enabled; only explicit False rows disable a component.
    """
    __tablename__ = "ui_component_visibility"
    id             = Column(Integer, primary_key=True, autoincrement=True)
    component_key  = Column(String(100), nullable=False)   # e.g. "sql_editor"
    role           = Column(String(50),  nullable=False)   # admin / analyst / viewer
    enabled        = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("component_key", "role", name="uq_ucv_key_role"),)

    def to_dict(self):
        return {
            "component_key": self.component_key,
            "role":          self.role,
            "enabled":       self.enabled,
        }


###############################################################################
# Phase 53 — Semantic Layer Models (BO Universe Equivalent)
###############################################################################

class BusinessDataset(Base):
    """A curated business subject (e.g. 'Sales', 'Orders') that abstracts
    physical tables into a friendly, role-aware semantic layer."""
    __tablename__ = "business_datasets"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    name           = Column(String(200), nullable=False, unique=True)
    description    = Column(Text, default="")
    subject        = Column(String(100), nullable=False, index=True)   # Sales, HR, Finance, etc.
    owner          = Column(String(100), default="admin")              # creator username
    connection_ids = Column(JSON, nullable=False, default=list)        # list of connection IDs used
    source_tables  = Column(JSON, nullable=False, default=list)        # [{"connection_id":1, "table":"s3://bucket/file.parquet", "alias":"orders"}]
    base_query     = Column(Text, default="")                          # optional custom SQL for advanced users
    is_published   = Column(Boolean, default=False, nullable=False)    # visible to business users?
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "subject": self.subject,
            "owner": self.owner,
            "connection_ids": self.connection_ids or [],
            "source_tables": self.source_tables or [],
            "base_query": self.base_query or "",
            "is_published": self.is_published,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DatasetClass(Base):
    """Logical grouping of columns within a dataset (BO Universe Classes).
    E.g. 'Customer', 'Time', 'Product' — organises dimensions and measures."""
    __tablename__ = "dataset_classes"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)           # e.g. "Customer"
    label      = Column(String(200), default="")               # display label
    icon       = Column(String(50), default="")                # optional MUI icon name
    sort_order = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_dsclass_ds_name"),
        Index("ix_dsclass_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "icon": self.icon or "",
            "sort_order": self.sort_order,
        }


class DatasetColumn(Base):
    """A column in a business dataset — maps physical column to friendly name
    with dimension/measure/detail/kpi classification."""
    __tablename__ = "dataset_columns"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    class_id        = Column(Integer, nullable=True)             # FK to DatasetClass.id (optional)
    physical_name   = Column(String(300), nullable=False)        # actual column name in source
    friendly_name   = Column(String(300), nullable=False)        # display label for business users
    column_type     = Column(String(20), nullable=False, default="dimension")  # dimension|measure|detail|kpi
    data_type       = Column(String(50), default="string")       # string|number|date|boolean
    aggregation     = Column(String(30), default="")             # sum|avg|count|min|max|count_distinct (for measures)
    format_pattern  = Column(String(100), default="")            # e.g. "$#,##0.00", "#,##0", "YYYY-MM-DD"
    description     = Column(Text, default="")
    synonyms        = Column(JSON, default=list)                 # ["revenue", "sales_amount", "net_rev"]
    role_whitelist  = Column(JSON, default=list)                 # [] = all roles; ["admin","analyst"] = restricted
    sort_order      = Column(Integer, default=0)
    is_hidden       = Column(Boolean, default=False, nullable=False)
    __table_args__ = (
        UniqueConstraint("dataset_id", "physical_name", name="uq_dscol_ds_phys"),
        Index("ix_dscol_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "class_id": self.class_id,
            "physical_name": self.physical_name,
            "friendly_name": self.friendly_name,
            "column_type": self.column_type,
            "data_type": self.data_type,
            "aggregation": self.aggregation or "",
            "format_pattern": self.format_pattern or "",
            "description": self.description or "",
            "synonyms": self.synonyms or [],
            "role_whitelist": self.role_whitelist or [],
            "sort_order": self.sort_order,
            "is_hidden": self.is_hidden,
        }


class DatasetRelationship(Base):
    """Defines how two datasets (or source tables within a dataset) join.
    Inspired by BO Universe joins."""
    __tablename__ = "dataset_relationships"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id       = Column(Integer, nullable=False, index=True)
    left_table       = Column(String(300), nullable=False)       # alias or table ref
    right_table      = Column(String(300), nullable=False)
    join_type        = Column(String(20), default="inner")       # inner|left|right|full
    join_keys        = Column(JSON, nullable=False, default=list)  # [{"left":"order_id","right":"id"}]
    cardinality      = Column(String(20), default="many_to_one") # one_to_one|one_to_many|many_to_one|many_to_many

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "join_type": self.join_type,
            "join_keys": self.join_keys or [],
            "cardinality": self.cardinality,
        }


class DrillHierarchy(Base):
    """Drill-down hierarchy (e.g. Year → Quarter → Month → Day).
    Tableau-style click-to-expand in business reports."""
    __tablename__ = "drill_hierarchies"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)                  # "Time Hierarchy"
    levels     = Column(JSON, nullable=False, default=list)           # [{"column_id":1,"label":"Year"},{"column_id":2,"label":"Quarter"},...]
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_drill_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "levels": self.levels or [],
        }


class PreDefinedCondition(Base):
    """Reusable WHERE-clause snippets business users can drag into a report
    filter panel (BO pre-defined condition equivalent)."""
    __tablename__ = "predefined_conditions"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id  = Column(Integer, nullable=False, index=True)
    name        = Column(String(200), nullable=False)             # "This Year", "Active Customers Only"
    label       = Column(String(200), default="")
    description = Column(Text, default="")
    where_clause = Column(Text, nullable=False)                   # SQL snippet e.g. "YEAR(order_date) = YEAR(CURRENT_DATE)"
    sort_order  = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_predef_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "description": self.description or "",
            "where_clause": self.where_clause,
            "sort_order": self.sort_order,
        }


class AggregationAwareness(Base):
    """Maps a measure to a pre-aggregated table.  When the report requests
    this measure at a compatible grain, the engine uses the pre-agg table
    instead of scanning raw data."""
    __tablename__ = "aggregation_awareness"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    measure_col_id  = Column(Integer, nullable=False)            # FK to DatasetColumn.id
    agg_table       = Column(String(300), nullable=False)        # pre-aggregated table/parquet path
    agg_dimensions  = Column(JSON, nullable=False, default=list) # dimensions already rolled up in agg_table
    connection_id   = Column(Integer, nullable=True)             # connection for the agg table
    is_enabled      = Column(Boolean, default=True, nullable=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "measure_col_id": self.measure_col_id,
            "agg_table": self.agg_table,
            "agg_dimensions": self.agg_dimensions or [],
            "connection_id": self.connection_id,
            "is_enabled": self.is_enabled,
        }


class FederationExecution(Base):
    """Tracks federated dataset query executions for audit and history."""
    __tablename__ = "federation_executions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    execution_id    = Column(String(100), nullable=False, unique=True, index=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    merged_dataset_id = Column(Integer, nullable=True)          # set for merged queries
    sql_generated   = Column(Text, nullable=False, default="")
    column_ids      = Column(JSON, nullable=False, default=list)  # selected column IDs
    filters         = Column(JSON, nullable=False, default=list)
    condition_ids   = Column(JSON, nullable=False, default=list)
    output_path     = Column(String(500), nullable=True)
    total_rows      = Column(Integer, default=0)
    duration_seconds = Column(Float, default=0.0)
    status          = Column(String(20), nullable=False, default="running")  # running | completed | failed
    error_message   = Column(Text, nullable=True)
    executed_by     = Column(String(100), nullable=True)
    sources_used    = Column(JSON, nullable=False, default=list)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "dataset_id": self.dataset_id,
            "merged_dataset_id": self.merged_dataset_id,
            "sql_generated": self.sql_generated,
            "column_ids": self.column_ids or [],
            "filters": self.filters or [],
            "condition_ids": self.condition_ids or [],
            "output_path": self.output_path,
            "total_rows": self.total_rows,
            "duration_seconds": self.duration_seconds,
            "status": self.status,
            "error_message": self.error_message,
            "executed_by": self.executed_by,
            "sources_used": self.sources_used or [],
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class MergedDimension(Base):
    """Defines how two datasets are merged on shared dimensions (BO-style merge).

    When a business report uses two datasets, MergedDimension records declare
    which columns from each dataset form the merge key."""
    __tablename__ = "merged_dimensions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    primary_dataset_id  = Column(Integer, nullable=False, index=True)
    secondary_dataset_id = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    merge_keys          = Column(JSON, nullable=False, default=list)  # [{"left":"col","right":"col"}]
    merge_type          = Column(String(20), nullable=False, default="inner")  # inner|left|right|full
    is_active           = Column(Boolean, default=True, nullable=False)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("primary_dataset_id", "secondary_dataset_id", "name",
                         name="uq_merged_dimension"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "primary_dataset_id": self.primary_dataset_id,
            "secondary_dataset_id": self.secondary_dataset_id,
            "name": self.name,
            "merge_keys": self.merge_keys or [],
            "merge_type": self.merge_type,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AggCacheEntry(Base):
    """Pre-computed aggregation rollup parquet for sub-second query serving.

    Inspired by BO Aggregate Awareness (transparent routing to coarsest-grain
    pre-agg table), Power BI VertiPaq (pre-loaded compressed data), and Tableau
    Extracts (scheduled refresh with incremental option).

    Cache lifecycle:  pending → building → ready → stale → expired / failed
      - stale: past soft TTL but still serveable (serve + trigger background refresh)
      - expired: past hard expiry, must rebuild (never served)
    """
    __tablename__ = "agg_cache_entries"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    description         = Column(Text, default="")

    # What this cache covers
    dimension_col_ids   = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    measure_col_ids     = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    grain_label         = Column(String(50), default="custom")         # yearly|quarterly|monthly|weekly|daily|custom
    condition_ids       = Column(JSON, nullable=False, default=list)   # pre-defined condition IDs baked in

    # Physical storage
    file_path           = Column(String(500), nullable=True)
    file_size_bytes     = Column(Integer, default=0)
    row_count           = Column(Integer, default=0)

    # Lifecycle
    status              = Column(String(20), default="pending")        # pending|building|ready|stale|expired|failed
    last_built_at       = Column(DateTime, nullable=True)
    last_served_at      = Column(DateTime, nullable=True)
    expires_at          = Column(DateTime, nullable=True)              # hard expiry
    stale_at            = Column(DateTime, nullable=True)              # soft expiry
    error_message       = Column(Text, nullable=True)
    build_duration_seconds = Column(Float, default=0.0)

    # Scheduling
    schedule_config     = Column(JSON, nullable=True)                  # {"type":"cron","cron_expr":"0 2 * * *"}
    is_enabled          = Column(Boolean, default=True, nullable=False)

    # Incremental refresh (Tableau-style)
    incremental_enabled = Column(Boolean, default=False, nullable=False)
    incremental_column  = Column(String(200), nullable=True)
    incremental_last_value = Column(String(500), nullable=True)

    # Stats
    hit_count           = Column(Integer, default=0)
    miss_count          = Column(Integer, default=0)

    created_by          = Column(String(100), default="admin")
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                 onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_aggcache_ds_name"),
        Index("ix_aggcache_dataset_status", "dataset_id", "status"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "description": self.description or "",
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "grain_label": self.grain_label,
            "condition_ids": self.condition_ids or [],
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "row_count": self.row_count,
            "status": self.status,
            "last_built_at": self.last_built_at.isoformat() if self.last_built_at else None,
            "last_served_at": self.last_served_at.isoformat() if self.last_served_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "stale_at": self.stale_at.isoformat() if self.stale_at else None,
            "error_message": self.error_message,
            "build_duration_seconds": self.build_duration_seconds,
            "schedule_config": self.schedule_config,
            "is_enabled": self.is_enabled,
            "incremental_enabled": self.incremental_enabled,
            "incremental_column": self.incremental_column,
            "incremental_last_value": self.incremental_last_value,
            "hit_count": self.hit_count or 0,
            "miss_count": self.miss_count or 0,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class AggCacheSuggestion(Base):
    """Auto-generated suggestion for a new agg cache based on query usage patterns.

    The usage analysis engine examines FederationExecution history to find
    frequently-used dimension+measure combos and creates suggestions that an
    admin can approve (creating an AggCacheEntry) or reject."""
    __tablename__ = "agg_cache_suggestions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    dimension_col_ids   = Column(JSON, nullable=False, default=list)
    measure_col_ids     = Column(JSON, nullable=False, default=list)
    query_count         = Column(Integer, default=0)
    estimated_speedup   = Column(Float, default=0.0)
    status              = Column(String(20), default="pending")        # pending|approved|rejected|implemented
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    reviewed_by         = Column(String(100), nullable=True)
    reviewed_at         = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_aggsuggest_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "query_count": self.query_count,
            "estimated_speedup": self.estimated_speedup,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at.isoformat() if self.reviewed_at else None,
        }


class DatabaseManager:
    """Database manager for handling all database operations"""

    def __init__(self, db_url: str = "sqlite:///./data/parquet_query_engine.db"):
        """
        Initialize database manager

        Args:
            db_url: Database connection URL
        """
        # Ensure data directory exists — resolve the path so UNC paths
        # (\\server\share\...) are handled correctly on Windows.
        raw_path = db_url.replace("sqlite:///", "")
        db_path = Path(raw_path).resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        # Rebuild the URL with the resolved absolute path so SQLite's C library
        # never sees a relative or UNC-relative path.
        if "sqlite" in db_url:
            db_url = "sqlite:///" + db_path.as_posix()
        
        is_sqlite = "sqlite" in db_url

        self.engine = create_engine(
            db_url,
            connect_args={"check_same_thread": False} if is_sqlite else {},
            pool_pre_ping=True,
            # pool_size / max_overflow are ignored for SQLite's StaticPool,
            # but kept for potential future migration to PostgreSQL.
            pool_size=20,
            max_overflow=30
        )

        # Enable WAL journal mode for SQLite so concurrent readers never block
        # each other, and writers only block other writers (not readers).
        # busy_timeout makes writers retry for up to 30 s instead of failing
        # immediately when another writer holds the lock.
        if is_sqlite:
            @sa_event.listens_for(self.engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _conn_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA busy_timeout=30000")
                cursor.execute("PRAGMA wal_autocheckpoint=1000")  # checkpoint every 1000 pages
                cursor.close()

            # Checkpoint WAL on startup to consolidate any leftover WAL from
            # a previous unclean shutdown (prevents "malformed" errors).
            # Also run an integrity check — if the DB is corrupt, back it up
            # and start fresh so the app doesn't crash on every write.
            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("PRAGMA wal_checkpoint(TRUNCATE)"))
                    _conn.commit()
                    _ic = _conn.execute(sa_text("PRAGMA integrity_check")).fetchone()
                    if _ic and _ic[0] != "ok":
                        raise RuntimeError(f"integrity_check failed: {_ic[0]}")
            except Exception as _db_err:
                import logging as _log
                _log.getLogger(__name__).warning(
                    "SQLite DB corrupt or unreadable (%s) — backing up and recreating.", _db_err
                )
                # Dispose all engine connections so the file is unlocked
                self.engine.dispose()
                # Move corrupt files aside
                import shutil as _shutil
                _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                for _suffix in ("", "-wal", "-shm", "-journal"):
                    _f = Path(str(db_path) + _suffix)
                    if _f.exists():
                        _f.rename(_f.with_suffix(f".corrupt_{_ts}{_suffix}"))
                # Recreate engine against a now-empty path
                self.engine = create_engine(
                    db_url,
                    connect_args={"check_same_thread": False},
                    pool_pre_ping=True,
                    pool_size=20, max_overflow=30,
                )
                # Re-register the pragma listener on the fresh engine
                @sa_event.listens_for(self.engine, "connect")
                def _set_sqlite_pragmas_fresh(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=30000")
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                    cursor.close()

        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

        # Create tables (only creates tables that don't exist yet)
        Base.metadata.create_all(bind=self.engine)

        # Safe schema migration for SQLite — add any columns that existing
        # tables might be missing when the schema is updated after initial
        # creation.  Base.metadata.create_all never alters existing tables,
        # so new columns must be applied manually.
        if is_sqlite:
            self._apply_sqlite_migrations()

    def _apply_sqlite_migrations(self):
        """Add columns that may be missing from older DB versions (SQLite only).

        Uses a raw sqlite3 connection (bypasses SQLAlchemy version differences)
        so this works identically with SQLAlchemy 1.x and 2.x.
        """
        import sqlite3 as _sqlite3
        db_file = str(self.engine.url).replace("sqlite:///", "")
        if not db_file or db_file == ":memory:":
            return

        # table → list of (column_name, sqlite_type)
        # Extend this dict whenever a new column is added to an existing model.
        migrations: dict = {
            # audit_log created fresh by Base.metadata.create_all
            "audit_log": [],
            "reports": [
                ("sql_saved_query_id",     "INTEGER"),
                ("sql_override",           "TEXT"),
                ("last_executed_at",       "TIMESTAMP"),
                ("cache_ttl_minutes",      "INTEGER DEFAULT 0"),  # enterprise caching
                ("schedule_config",        "TEXT"),              # JSON schedule config
                ("connection_override_id", "INTEGER"),   # Phase 24A
                ("workspace_id",           "INTEGER"),   # Phase 25
            ],
            "schedules": [
                ("notify_emails",  "TEXT"),
                ("notify_webhook", "TEXT"),
                ("is_shared",      "BOOLEAN DEFAULT 0"),
                ("workspace_id",   "INTEGER"),           # Phase 25
            ],
            "saved_queries": [
                ("is_favorite",  "BOOLEAN DEFAULT 0"),
                ("is_shared",    "BOOLEAN DEFAULT 0"),
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "sql_saved_queries": [
                ("is_shared",    "BOOLEAN DEFAULT 0"),
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "connections": [
                ("is_shared",    "BOOLEAN DEFAULT 0"),
                ("created_by",   "VARCHAR(100)"),
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "dashboards": [
                ("created_by",   "VARCHAR(100)"),
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "materialized_views": [
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "local_tables": [
                ("workspace_id", "INTEGER"),             # Phase 25
            ],
            "query_executions": [
                ("executed_by", "VARCHAR(100)"),
            ],
            "download_files": [
                ("created_by",  "VARCHAR(100)"),
            ],
            "query_shares": [
                ("created_by",  "VARCHAR(100)"),
            ],
            "dashboard_shares": [
                ("created_by",  "VARCHAR(100)"),
            ],
        }
        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        try:
            con = _sqlite3.connect(db_file)
            cur = con.cursor()
            for table, columns in migrations.items():
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    existing = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue  # table doesn't exist yet — create_all will handle it
                for col_name, col_type in columns:
                    if col_name not in existing:
                        try:
                            cur.execute(
                                f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"
                            )
                            _mig_log.info("Migration: added %s.%s (%s)", table, col_name, col_type)
                        except Exception as exc:
                            _mig_log.warning("Migration: failed to add %s.%s: %s", table, col_name, exc)
            con.commit()
            con.close()
        except Exception as exc:
            _mig_log.error("SQLite migration failed: %s", exc, exc_info=True)

    @contextmanager
    def get_session(self) -> Session:
        """
        Context manager for database sessions
        
        Yields:
            Database session
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    # SavedQuery operations
    def create_query(self, name: str, query_config: Dict[str, Any],
                    description: Optional[str] = None,
                    created_by: Optional[str] = None,
                    workspace_id: Optional[int] = None) -> SavedQuery:
        """Create a new saved query"""
        with self.get_session() as session:
            query = SavedQuery(
                name=name,
                description=description,
                query_config=query_config,
                created_by=created_by,
                workspace_id=workspace_id,
            )
            session.add(query)
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def get_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a saved query by ID"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            return query.to_dict() if query else None
    
    def list_queries(self, active_only: bool = True,
                    limit: int = 100, offset: int = 0,
                    workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List all saved queries"""
        with self.get_session() as session:
            query = session.query(SavedQuery)
            if active_only:
                query = query.filter(SavedQuery.is_active == True)
            if workspace_id is not None:
                query = query.filter(
                    (SavedQuery.workspace_id == workspace_id) | (SavedQuery.workspace_id == None)
                )
            query = query.order_by(SavedQuery.created_at.desc())
            query = query.limit(limit).offset(offset)
            return [q.to_dict() for q in query.all()]
    
    def update_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return None
            
            for key, value in kwargs.items():
                if hasattr(query, key):
                    setattr(query, key, value)
            
            query.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def toggle_favorite(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Toggle is_favorite flag on a saved query."""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not query:
                return None
            query.is_favorite = not query.is_favorite
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def delete_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return False
            
            if soft_delete:
                query.is_active = False
                query.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(query)
            
            return True
    
    def increment_execution_count(self, query_id: int) -> None:
        """Increment execution count for a query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if query:
                query.execution_count += 1
                query.last_executed_at = datetime.now(timezone.utc)
    
    # QueryExecution operations
    def create_execution(self, execution_id: str, query_config: Dict[str, Any],
                        query_id: Optional[int] = None,
                        executed_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a new query execution record"""
        with self.get_session() as session:
            execution = QueryExecution(
                execution_id=execution_id,
                query_id=query_id,
                query_config=query_config,
                executed_by=executed_by
            )
            session.add(execution)
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def update_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a query execution"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            
            if not execution:
                return None
            
            for key, value in kwargs.items():
                if hasattr(execution, key):
                    setattr(execution, key, value)
            
            if kwargs.get("status") in ["completed", "failed"]:
                execution.completed_at = datetime.now(timezone.utc)
            
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution by ID"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            return execution.to_dict() if execution else None
    
    def get_last_successful_output_file(self, query_id: int) -> Optional[Dict]:
        """Return the most recent completed execution's output_file for a query_id.
        Only returns if the file still exists on disk (for stale-fallback use).
        """
        import os as _os
        with self.get_session() as session:
            row = (session.query(QueryExecution)
                   .filter(
                       QueryExecution.query_id == query_id,
                       QueryExecution.status == "completed",
                       QueryExecution.output_file.isnot(None),
                   )
                   .order_by(QueryExecution.completed_at.desc())
                   .first())
            if not row or not row.output_file:
                return None
            if not _os.path.exists(row.output_file):
                return None
            return {
                "output_file": row.output_file,
                "completed_at": row.completed_at.isoformat() if row.completed_at else None,
                "total_rows": row.total_rows or 0,
                "file_size_bytes": row.file_size_bytes or 0,
            }

    def list_executions(self, limit: int = 100, offset: int = 0,
                       status: Optional[str] = None) -> List[Dict[str, Any]]:
        """List query executions"""
        with self.get_session() as session:
            query = session.query(QueryExecution)
            
            if status:
                query = query.filter(QueryExecution.status == status)
            
            query = query.order_by(QueryExecution.started_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [e.to_dict() for e in query.all()]
    
    # DownloadFile operations
    def create_download_file(self, file_id: str, filename: str, file_path: str,
                           file_size_bytes: int, execution_id: Optional[str] = None,
                           expires_at: Optional[datetime] = None,
                           created_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a download file record"""
        with self.get_session() as session:
            download_file = DownloadFile(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=file_path,
                file_size_bytes=file_size_bytes,
                expires_at=expires_at,
                created_by=created_by
            )
            session.add(download_file)
            session.flush()
            session.refresh(download_file)
            return download_file.to_dict()
    
    def get_download_file(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get download file by ID"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            return file.to_dict() if file else None
    
    def list_download_files(self, status: Optional[str] = "available",
                          limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List download files"""
        with self.get_session() as session:
            query = session.query(DownloadFile)
            
            if status:
                query = query.filter(DownloadFile.status == status)
            
            query = query.order_by(DownloadFile.created_at.desc())
            query = query.limit(limit).offset(offset)
            
            return [f.to_dict() for f in query.all()]
    
    def update_download_file(self, file_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update download file"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            
            if not file:
                return None
            
            for key, value in kwargs.items():
                if hasattr(file, key):
                    setattr(file, key, value)
            
            session.flush()
            session.refresh(file)
            return file.to_dict()
    
    def increment_download_count(self, file_id: str) -> None:
        """Increment download count"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            if file:
                file.download_count += 1
                file.last_downloaded_at = datetime.now(timezone.utc)

    # ── Connection operations ──────────────────────────────────────────────────

    def create_connection(self, name: str, connection_type: str,
                         config: Dict[str, Any],
                         workspace_id: Optional[int] = None) -> Dict[str, Any]:
        """Create a new connection — encrypts sensitive config fields at rest."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = Connection(
                name=name,
                connection_type=connection_type,
                config=encrypt_config(config),
                workspace_id=workspace_id,
            )
            session.add(connection)
            session.flush()
            session.refresh(connection)
            d = connection.to_dict()
            d["config"] = mask_config(config)   # return masked to caller
            return d

    def get_connection(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials MASKED — safe for API responses to the browser."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = mask_config(decrypt_config(d["config"]))
            return d

    def get_connection_raw(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials DECRYPTED — for internal engine/connector use only.
        Never return this directly to API clients."""
        from core.crypto import decrypt_config
        with self.get_session() as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = decrypt_config(d["config"])
            return d

    def list_connections(self, active_only: bool = True,
                        limit: int = 100, offset: int = 0,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List connections with credentials masked."""
        from core.crypto import decrypt_config, mask_config
        with self.get_session() as session:
            q = session.query(Connection)
            if active_only:
                q = q.filter(Connection.is_active == True)
            if workspace_id is not None:
                q = q.filter(
                    (Connection.workspace_id == workspace_id) | (Connection.workspace_id == None)
                )
            q = q.order_by(Connection.created_at.desc()).limit(limit).offset(offset)
            result = []
            for c in q.all():
                d = c.to_dict()
                d["config"] = mask_config(decrypt_config(d["config"]))
                result.append(d)
            return result

    def update_connection(self, connection_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a connection — re-encrypts config if provided."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return None
            # Encrypt config before persisting
            if "config" in kwargs and isinstance(kwargs["config"], dict):
                kwargs["config"] = encrypt_config(kwargs["config"])
            for key, value in kwargs.items():
                if hasattr(connection, key):
                    setattr(connection, key, value)
            connection.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(connection)
            return connection.to_dict()

    def delete_connection(self, connection_id: int, soft_delete: bool = True) -> bool:
        """Delete a connection."""
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return False
            if soft_delete:
                connection.is_active = False
                connection.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(connection)
            return True

    # ── Report operations ──────────────────────────────────────────────────────

    def create_report(self, **kwargs) -> Dict[str, Any]:
        """Create a new parametric report."""
        with self.get_session() as session:
            report = Report(**kwargs)
            session.add(report)
            session.flush()
            session.refresh(report)
            return report.to_dict()

    def get_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            return r.to_dict() if r else None

    def list_reports(self, active_only: bool = True,
                     limit: int = 200, offset: int = 0,
                     workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Report)
            if active_only:
                q = q.filter(Report.is_active == True)
            if workspace_id is not None:
                q = q.filter(
                    (Report.workspace_id == workspace_id) | (Report.workspace_id == None)
                )
            rows = q.order_by(Report.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def update_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(r, key):
                    setattr(r, key, value)
            r.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def delete_report(self, report_id: int, soft_delete: bool = True) -> bool:
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if not r:
                return False
            if soft_delete:
                r.is_active = False
            else:
                session.delete(r)
            return True

    def increment_report_execution(self, report_id: int):
        with self.get_session() as session:
            r = session.query(Report).filter(Report.id == report_id).first()
            if r:
                r.execution_count = (r.execution_count or 0) + 1
                r.last_executed_at = datetime.now(timezone.utc)

    # ── Connection Profile operations (Phase 24B) ──────────────────────────────

    def list_connection_profiles(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ConnectionProfile).order_by(ConnectionProfile.name).all()
            return [r.to_dict() for r in rows]

    def get_active_profile(self) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(ConnectionProfile).filter(ConnectionProfile.is_active == True).first()
            return r.to_dict() if r else None

    def get_profile_mappings(self, profile_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_connection_profile(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ConnectionProfile(**kwargs)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def update_connection_profile(self, profile_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            p.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def activate_connection_profile(self, profile_id: int) -> bool:
        """Set one profile as active; deactivate all others (exclusive)."""
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            p.is_active = True
            return True

    def deactivate_all_profiles(self) -> None:
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})

    def delete_connection_profile(self, profile_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            session.delete(p)
            return True

    def set_profile_mappings(self, profile_id: int, mappings: List[Dict]) -> List[Dict[str, Any]]:
        """Replace ALL mappings for a profile atomically."""
        with self.get_session() as session:
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            created = []
            for m in mappings:
                obj = ConnectionProfileMapping(
                    profile_id=profile_id,
                    source_connection_id=m["source_connection_id"],
                    target_connection_id=m["target_connection_id"],
                    description=m.get("description"),
                )
                session.add(obj)
                session.flush()
                session.refresh(obj)
                created.append(obj.to_dict())
            return created

    def resolve_connection_via_profile(self, connection_id: int) -> int:
        """Return the mapped connection_id if active profile has a rule; else original.

        Returns connection_id unchanged when no profile is active or no mapping exists.
        """
        active = self.get_active_profile()
        if not active:
            return connection_id
        with self.get_session() as session:
            mapping = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == active["id"],
                ConnectionProfileMapping.source_connection_id == connection_id,
            ).first()
            return mapping.target_connection_id if mapping else connection_id

    # ── Schedule operations ────────────────────────────────────────────────────

    def create_schedule(self, **kwargs) -> Dict[str, Any]:
        """Create a new schedule record."""
        with self.get_session() as session:
            s = Schedule(**kwargs)
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_schedule(self, schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            return s.to_dict() if s else None

    def list_schedules(self, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Schedule)
            if active_only:
                q = q.filter(Schedule.is_active == True)
            rows = q.order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def list_all_schedules(self, limit: int = 500, offset: int = 0) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(Schedule).order_by(Schedule.created_at.desc()).limit(limit).offset(offset).all()
            return [s.to_dict() for s in rows]

    def update_schedule(self, schedule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            s.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    def increment_schedule_run_count(self, schedule_id: int):
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if s:
                s.run_count = (s.run_count or 0) + 1

    def list_downloads_enriched(
        self,
        status: Optional[str] = "available",
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Returns download files enriched with linked execution metadata.

        Single LEFT JOIN query — no N+1 lookups.
        Extra fields added to each record:
          - duration_seconds  (execution completed_at - started_at)
          - total_rows        (rows written by the query engine)
          - format            ('csv' | 'excel' | 'json' derived from filename)
        """
        with self.get_session() as session:
            query = (
                session.query(DownloadFile, QueryExecution)
                .outerjoin(
                    QueryExecution,
                    DownloadFile.execution_id == QueryExecution.execution_id,
                )
            )
            if status:
                query = query.filter(DownloadFile.status == status)

            query = (
                query.order_by(DownloadFile.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = []
            for dl, ex in query.all():
                d = dl.to_dict()

                # Execution metadata
                if ex:
                    if ex.started_at and ex.completed_at:
                        d["duration_seconds"] = round(
                            (ex.completed_at - ex.started_at).total_seconds(), 2
                        )
                    else:
                        d["duration_seconds"] = None
                    d["total_rows"] = ex.total_rows or 0
                else:
                    d["duration_seconds"] = None
                    d["total_rows"] = None

                # Derive format from filename extension
                fname = (d.get("filename") or "").lower()
                if fname.endswith(".xlsx"):
                    d["format"] = "excel"
                elif fname.endswith(".json"):
                    d["format"] = "json"
                else:
                    d["format"] = "csv"

                result.append(d)

            return result

    # ── SQL Saved Queries (Trino / Snowflake / Databricks) ────────────────────

    def create_sql_query(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlSavedQuery record."""
        with self.get_session() as session:
            q = SqlSavedQuery(**kwargs)
            session.add(q)
            session.flush()
            return q.to_dict()

    def list_sql_queries(self, active_only: bool = True, limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL saved queries, newest first."""
        with self.get_session() as session:
            query = session.query(SqlSavedQuery)
            if active_only:
                query = query.filter(SqlSavedQuery.is_active == True)
            rows = query.order_by(SqlSavedQuery.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def get_sql_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL saved query by ID."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            return q.to_dict() if q else None

    def update_sql_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(q, key):
                    setattr(q, key, value)
            q.updated_at = datetime.now(timezone.utc)
            session.flush()
            return q.to_dict()

    def delete_sql_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return False
            if soft_delete:
                q.is_active = False
            else:
                session.delete(q)
            return True

    def increment_sql_query_execution(self, query_id: int):
        """Bump execution counter and last_executed_at timestamp."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if q:
                q.execution_count = (q.execution_count or 0) + 1
                q.last_executed_at = datetime.now(timezone.utc)

    # ── Query Cache operations ─────────────────────────────────────────────────

    def get_cache_entry(self, cache_key: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            return e.to_dict() if e else None

    def set_cache_entry(self, cache_key: str, file_path: str,
                        row_count: int = 0, file_size_bytes: int = 0,
                        expires_at: Optional[datetime] = None,
                        query_config: Optional[dict] = None,
                        connection_id: Optional[int] = None) -> Dict[str, Any]:
        """Upsert a cache entry — safe for concurrent writers on the same key."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            # Try insert first; on PK conflict, update in place.
            try:
                e = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                # PK conflict — another thread inserted first; update instead.
                existing = session.query(QueryCacheEntry).filter(
                    QueryCacheEntry.cache_key == cache_key
                ).first()
                if existing:
                    existing.file_path = file_path
                    existing.row_count = row_count
                    existing.file_size_bytes = file_size_bytes
                    existing.expires_at = expires_at
                    existing.created_at = now
                    existing.query_config = query_config
                    existing.connection_id = connection_id
                    session.flush()
                    return existing.to_dict()
                # Extremely unlikely: another thread deleted between our
                # failed insert and this query — just retry the insert.
                e2 = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_cache_entry(self, cache_key: str) -> bool:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            if not e:
                return False
            session.delete(e)
            return True

    def delete_expired_cache_entries(self) -> int:
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            expired = session.query(QueryCacheEntry).filter(
                QueryCacheEntry.expires_at != None,
                QueryCacheEntry.expires_at < now,
            ).all()
            count = len(expired)
            for e in expired:
                session.delete(e)
            return count

    def list_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(QueryCacheEntry).order_by(QueryCacheEntry.created_at.desc()).all()
            return [e.to_dict() for e in rows]

    def increment_cache_hit(self, cache_key: str) -> None:
        """Increment the hit counter for a cache entry."""
        with self.get_session() as session:
            entry = session.query(QueryCacheEntry).filter_by(cache_key=cache_key).first()
            if entry:
                entry.hit_count = (entry.hit_count or 0) + 1
                session.flush()

    # ── Partition Cache operations ────────────────────────────────────────────

    def get_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str = "fast") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(PartitionCache).filter(
                PartitionCache.connection_id == connection_id,
                PartitionCache.table_name == table_name,
                PartitionCache.scan_type == scan_type,
            ).first()
            return e.to_dict() if e else None

    def set_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str, partition_data: dict) -> Dict[str, Any]:
        """Upsert partition cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    scan_type=scan_type, partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(PartitionCache).filter(
                    PartitionCache.connection_id == connection_id,
                    PartitionCache.table_name == table_name,
                    PartitionCache.scan_type == scan_type,
                ).first()
                if existing:
                    existing.partition_data = partition_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    scan_type=scan_type, partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_partition_cache(self, connection_id: Optional[int] = None,
                               table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(PartitionCache)
            if connection_id is not None:
                q = q.filter(PartitionCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(PartitionCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_partition_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(PartitionCache).order_by(
                PartitionCache.updated_at.desc()
            ).all()
            return [e.to_dict() for e in rows]

    # ── Iceberg File Cache operations ────────────────────────────────────────

    def get_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(IcebergFileCache).filter(
                IcebergFileCache.connection_id == connection_id,
                IcebergFileCache.table_name == table_name,
                IcebergFileCache.filters_hash == filters_hash,
            ).first()
            return e.to_dict() if e else None

    def set_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str, file_list: list) -> Dict[str, Any]:
        """Upsert Iceberg file cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(IcebergFileCache).filter(
                    IcebergFileCache.connection_id == connection_id,
                    IcebergFileCache.table_name == table_name,
                    IcebergFileCache.filters_hash == filters_hash,
                ).first()
                if existing:
                    existing.file_list = file_list
                    existing.file_count = len(file_list)
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_iceberg_file_cache(self, connection_id: Optional[int] = None,
                                   table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergFileCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    # ── Schema cache ────────────────────────────────────────────────────────────

    def find_schema_cache_by_name(self, table_name: str) -> Optional[Dict[str, Any]]:
        """Find any cached schema matching table_name, regardless of connection."""
        with self.get_session() as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.table_name == table_name
            ).order_by(SchemaCache.updated_at.desc()).first()
            return e.to_dict() if e else None

    def get_schema_cache(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.connection_id == connection_id,
                SchemaCache.table_name == table_name,
            ).first()
            return e.to_dict() if e else None

    def set_schema_cache(self, connection_id: int, table_name: str,
                         table_format: str, schema_data: dict) -> Dict[str, Any]:
        """Upsert schema cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(SchemaCache).filter(
                    SchemaCache.connection_id == connection_id,
                    SchemaCache.table_name == table_name,
                ).first()
                if existing:
                    existing.table_format = table_format
                    existing.schema_data = schema_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_schema_cache(self, connection_id: Optional[int] = None,
                            table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(SchemaCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_schema_cache_entries(self, connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            return [e.to_dict() for e in q.order_by(SchemaCache.updated_at.desc()).all()]

    # ── Execution history cleanup ──────────────────────────────────────────────

    def cleanup_old_executions(self, retention_days: int = 30):
        """Delete QueryExecution records older than retention_days.

        Only removes records whose status is terminal (completed / failed /
        cancelled) and whose started_at is older than the retention window.
        Pending / processing rows are never touched (they may still be running).

        Returns (count, [output_file_paths]) so the caller can delete the files.
        """
        import datetime as _dt
        cutoff = datetime.now(timezone.utc) - _dt.timedelta(days=retention_days)
        with self.get_session() as session:
            terminal = ("completed", "failed", "cancelled")
            expired_rows = (
                session.query(QueryExecution)
                .filter(
                    QueryExecution.status.in_(terminal),
                    QueryExecution.started_at < cutoff,
                )
                .all()
            )
            # Collect file paths BEFORE deleting rows (so we can unlink them)
            file_paths = [r.output_file for r in expired_rows if r.output_file]
            count = len(expired_rows)
            for row in expired_rows:
                session.delete(row)
            return count, file_paths

    def get_downloads_size_bytes(self) -> int:
        """Return total file_size_bytes of available download records."""
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .all()
            )
            return sum(r.file_size_bytes or 0 for r in rows)

    # ── Audit log ─────────────────────────────────────────────────────────────

    def audit(self, username: str, action: str,
              resource_type: str = None, resource_id: str = None,
              ip_address: str = None, user_agent: str = None,
              details: dict = None) -> None:
        """Append an immutable audit entry (fire-and-forget, never raises)."""
        try:
            with self.get_session() as session:
                session.add(AuditLog(
                    username=username or "unknown",
                    action=action,
                    resource_type=resource_type,
                    resource_id=str(resource_id) if resource_id is not None else None,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    details=details,
                ))
        except Exception:
            pass  # audit must never break the main flow

    def list_audit_log(self, username: str = None, action: str = None,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries newest-first, with optional filters."""
        with self.get_session() as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def mark_expired_downloads(self) -> int:
        """Mark download records as 'expired' where expires_at < now.

        Returns number of records marked expired.
        """
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(
                    DownloadFile.status == "available",
                    DownloadFile.expires_at != None,
                    DownloadFile.expires_at < now,
                )
                .all()
            )
            for row in rows:
                row.status = "expired"
            return len(rows)

    def expire_oldest_downloads(self, keep_count: int) -> int:
        """Mark oldest download records as expired until only keep_count remain.

        Returns number of records expired.
        """
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .order_by(DownloadFile.created_at.asc())
                .all()
            )
            to_expire = max(0, len(rows) - keep_count)
            for row in rows[:to_expire]:
                row.status = "expired"
            return to_expire

    # ── Query Version operations ───────────────────────────────────────────────

    def create_query_version(self, query_id: int, name: str = None, description: str = None,
                              query_config: dict = None, changed_by: str = None,
                              change_note: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Get next version number
            last = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .first())
            next_ver = (last.version_number + 1) if last else 1
            v = QueryVersion(
                query_id=query_id, version_number=next_ver,
                name=name, description=description, query_config=query_config,
                changed_by=changed_by, change_note=change_note,
            )
            session.add(v)
            session.flush()
            session.refresh(v)
            return v.to_dict()

    def list_query_versions(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .all())
            return [v.to_dict() for v in rows]

    def get_query_version(self, version_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            v = session.query(QueryVersion).filter(QueryVersion.id == version_id).first()
            return v.to_dict() if v else None

    # ── Query Share operations ─────────────────────────────────────────────────

    def create_share(self, query_id: int, created_by: str = None,
                     expires_at: Optional[datetime] = None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = QueryShare(
                token=_uuid.uuid4().hex,
                query_id=query_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            return s.to_dict() if s else None

    def increment_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    def list_shares(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(QueryShare)
                    .filter(QueryShare.query_id == query_id, QueryShare.is_active == True)
                    .order_by(QueryShare.created_at.desc())
                    .all())
            return [s.to_dict() for s in rows]

    def deactivate_share(self, token: str) -> bool:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if not s:
                return False
            s.is_active = False
            return True

    # ── Dashboard share operations ─────────────────────────────────────────────

    def create_dashboard_share(self, dashboard_id: int, created_by: str = None,
                               expires_at=None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = DashboardShare(
                token=_uuid.uuid4().hex,
                dashboard_id=dashboard_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_dashboard_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            return s.to_dict() if s else None

    def increment_dashboard_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    # ── Dashboard operations ───────────────────────────────────────────────────

    def create_dashboard(self, name: str, description: str = None,
                         created_by: str = None,
                         workspace_id: Optional[int] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = Dashboard(name=name, description=description, created_by=created_by,
                          workspace_id=workspace_id)
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def get_dashboard(self, dashboard_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id, Dashboard.is_active == True).first()
            return d.to_dict() if d else None

    def list_dashboards(self, created_by: str = None, is_admin: bool = True,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(Dashboard).filter(Dashboard.is_active == True)
            if not is_admin and created_by:
                q = q.filter(Dashboard.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (Dashboard.workspace_id == workspace_id) | (Dashboard.workspace_id == None)
                )
            rows = q.order_by(Dashboard.updated_at.desc()).all()
            return [d.to_dict() for d in rows]

    def update_dashboard(self, dashboard_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return None
            for k, v in kwargs.items():
                if hasattr(d, k):
                    setattr(d, k, v)
            d.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def delete_dashboard(self, dashboard_id: int) -> bool:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return False
            d.is_active = False
            return True

    # ── Dashboard Widget operations ────────────────────────────────────────────

    def create_widget(self, dashboard_id: int, widget_type: str, source_id: int,
                      title: str = None, layout: dict = None, chart_type: str = "grid",
                      chart_config: dict = None, param_values: dict = None) -> Dict[str, Any]:
        with self.get_session() as session:
            w = DashboardWidget(
                dashboard_id=dashboard_id, widget_type=widget_type, source_id=source_id,
                title=title, layout=layout or {"x": 0, "y": 0, "w": 6, "h": 4},
                chart_type=chart_type, chart_config=chart_config, param_values=param_values,
            )
            session.add(w)
            session.flush()
            session.refresh(w)
            # Touch parent dashboard updated_at
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)
            return w.to_dict()

    def list_widgets(self, dashboard_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = (session.query(DashboardWidget)
                    .filter(DashboardWidget.dashboard_id == dashboard_id)
                    .order_by(DashboardWidget.id)
                    .all())
            return [w.to_dict() for w in rows]

    def update_widget(self, widget_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return None
            for k, v in kwargs.items():
                if hasattr(w, k):
                    setattr(w, k, v)
            w.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(w)
            return w.to_dict()

    def delete_widget(self, widget_id: int) -> bool:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return False
            session.delete(w)
            return True

    def update_widget_layouts(self, dashboard_id: int, layouts: list) -> None:
        """Bulk update widget positions from react-grid-layout onChange."""
        with self.get_session() as session:
            layout_map = {str(item["i"]): item for item in layouts}
            widgets = (session.query(DashboardWidget)
                       .filter(DashboardWidget.dashboard_id == dashboard_id)
                       .all())
            for w in widgets:
                if str(w.id) in layout_map:
                    item = layout_map[str(w.id)]
                    w.layout = {"x": item.get("x", 0), "y": item.get("y", 0),
                                "w": item.get("w", 6), "h": item.get("h", 4)}
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)

    # ── Materialized Views ─────────────────────────────────────────────────

    def create_materialized_view(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            mv = MaterializedView(**kwargs)
            session.add(mv)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def get_materialized_view(self, mv_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            return mv.to_dict() if mv else None

    def get_materialized_view_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.name == name).first()
            return mv.to_dict() if mv else None

    def list_materialized_views(self, connection_id: int = None,
                                 active_only: bool = True,
                                 workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(MaterializedView)
            if active_only:
                q = q.filter(MaterializedView.is_active == True)
            if connection_id is not None:
                q = q.filter(MaterializedView.connection_id == connection_id)
            if workspace_id is not None:
                q = q.filter(
                    (MaterializedView.workspace_id == workspace_id) | (MaterializedView.workspace_id == None)
                )
            rows = q.order_by(MaterializedView.name).all()
            return [mv.to_dict() for mv in rows]

    def update_materialized_view(self, mv_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(mv, key):
                    setattr(mv, key, value)
            mv.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def delete_materialized_view(self, mv_id: int) -> bool:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return False
            session.delete(mv)
            return True

    # ── Local Tables ──────────────────────────────────────────────────────────

    def create_local_table(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            lt = LocalTable(**kwargs)
            session.add(lt)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def get_local_table(self, lt_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            return lt.to_dict() if lt else None

    def get_local_table_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.name == name).first()
            return lt.to_dict() if lt else None

    def list_local_tables(self, visibility: str = None,
                          created_by: str = None,
                          active_only: bool = True,
                          workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(LocalTable)
            if active_only:
                q = q.filter(LocalTable.is_active == True)
            if visibility:
                q = q.filter(LocalTable.visibility == visibility)
            if created_by:
                q = q.filter(LocalTable.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (LocalTable.workspace_id == workspace_id) | (LocalTable.workspace_id == None)
                )
            rows = q.order_by(LocalTable.name).all()
            return [lt.to_dict() for lt in rows]

    def update_local_table(self, lt_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(lt, key):
                    setattr(lt, key, value)
            lt.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def delete_local_table(self, lt_id: int) -> bool:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return False
            session.delete(lt)
            return True

    def touch_local_table(self, lt_id: int) -> None:
        """Update last_accessed_at to now."""
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if lt:
                lt.last_accessed_at = datetime.now(timezone.utc)

    def list_expired_local_tables(self) -> List[Dict[str, Any]]:
        """Return public local tables that have not been accessed within their auto_discard_days."""
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            rows = (session.query(LocalTable)
                    .filter(LocalTable.is_active == True,
                            LocalTable.visibility == "public",
                            LocalTable.auto_discard_days > 0,
                            LocalTable.last_accessed_at != None)
                    .all())
            expired = []
            for lt in rows:
                cutoff = now - timedelta(days=lt.auto_discard_days)
                if lt.last_accessed_at and lt.last_accessed_at < cutoff:
                    expired.append(lt.to_dict())
            return expired

    # ── TaskQueue operations ──────────────────────────────────────────────

    def enqueue_task(self, task_id: str, task_type: str, payload: dict,
                     execution_id: str = None, created_by: str = None,
                     priority: int = 5, timeout_seconds: int = 1800,
                     retry_count: int = 0, max_retries: int = 3,
                     delay_seconds: int = 0) -> Dict[str, Any]:
        """Enqueue a new task. Called by FastAPI when executor.mode='external'."""
        with self.get_session() as session:
            next_retry_at = None
            if delay_seconds > 0:
                next_retry_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
            task = TaskQueue(
                task_id=task_id, task_type=task_type,
                payload=payload, execution_id=execution_id,
                created_by=created_by, priority=priority,
                timeout_seconds=timeout_seconds,
                retry_count=retry_count, max_retries=max_retries,
                next_retry_at=next_retry_at,
            )
            session.add(task)
            session.flush()
            session.refresh(task)
            return task.to_dict()

    def claim_next_task(self, worker_id: str, task_types: list = None) -> Optional[Dict[str, Any]]:
        """Atomic claim: grab the highest-priority pending task.

        Uses raw SQL UPDATE ... WHERE for true atomicity — only one worker
        can claim a given task even under concurrent access.
        """
        with self.get_session() as session:
            from sqlalchemy import text as _text, or_ as _or
            now = datetime.now(timezone.utc)
            # Step 1: Find best candidate (skip tasks not yet eligible due to backoff delay)
            q = (session.query(TaskQueue)
                 .filter(TaskQueue.status == "pending")
                 .filter(_or(TaskQueue.next_retry_at.is_(None),
                             TaskQueue.next_retry_at <= now))
                 .order_by(TaskQueue.priority, TaskQueue.created_at))
            if task_types:
                q = q.filter(TaskQueue.task_type.in_(task_types))
            task = q.first()
            if not task:
                return None
            # Step 2: Atomic claim — UPDATE only if still pending (race-safe)
            result = session.execute(
                _text("""UPDATE task_queue
                         SET status = 'claimed', claimed_by = :worker, claimed_at = :now
                         WHERE id = :tid AND status = 'pending'"""),
                {"worker": worker_id, "now": now, "tid": task.id}
            )
            if result.rowcount == 0:
                return None  # Another worker got it first
            session.expire(task)
            session.refresh(task)
            return task.to_dict()

    def update_task_progress(self, task_id: str, progress_pct: int,
                             progress_detail: str = None) -> None:
        """Called by executor thread to report progress."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.progress_pct = progress_pct
                if progress_detail is not None:
                    task.progress_detail = progress_detail
                if task.status == "claimed":
                    task.status = "processing"
                    task.started_at = datetime.now(timezone.utc)

    def complete_task(self, task_id: str, result: dict = None) -> None:
        """Mark task as completed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "completed"
                task.progress_pct = 100
                task.result = result
                task.completed_at = datetime.now(timezone.utc)

    def fail_task(self, task_id: str, error_message: str) -> None:
        """Mark task as failed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "failed"
                task.error_message = error_message
                task.completed_at = datetime.now(timezone.utc)

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get a single task by task_id."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return task.to_dict() if task else None

    def list_tasks(self, status: str = None, limit: int = 50) -> List[Dict[str, Any]]:
        """List tasks, optionally filtered by status."""
        with self.get_session() as session:
            q = session.query(TaskQueue).order_by(TaskQueue.created_at.desc())
            if status:
                q = q.filter(TaskQueue.status == status)
            return [t.to_dict() for t in q.limit(limit).all()]

    def poll_active_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks that are processing or recently completed/failed (for WS broadcast)."""
        with self.get_session() as session:
            return [t.to_dict() for t in
                    session.query(TaskQueue)
                    .filter(TaskQueue.status.in_(["processing", "completed", "failed"]))
                    .order_by(TaskQueue.created_at.desc())
                    .limit(100)
                    .all()]

    def reclaim_stale_tasks(self, stale_seconds: int = 600) -> int:
        """Re-set claimed/processing tasks that exceeded timeout back to pending.

        Called periodically by the executor for graceful degradation when
        a worker dies mid-task.
        """
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(seconds=stale_seconds)
            stale = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["claimed", "processing"]),
                             TaskQueue.claimed_at < cutoff)
                     .all())
            count = 0
            for t in stale:
                if t.retry_count < t.max_retries:
                    t.status = "pending"
                    t.claimed_by = None
                    t.claimed_at = None
                    t.retry_count += 1
                else:
                    t.status = "failed"
                    t.error_message = "Executor timed out — max retries exceeded"
                    t.completed_at = datetime.now(timezone.utc)
                count += 1
            return count

    def cleanup_old_tasks(self, max_age_hours: int = 24) -> int:
        """Delete completed/failed tasks older than max_age_hours."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
            count = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["completed", "failed"]),
                             TaskQueue.completed_at < cutoff)
                     .delete(synchronize_session=False))
            return count

    # ── Dead-Letter Queue operations (Phase 22C) ──────────────────────────────

    def push_dead_letter(self, task: Dict[str, Any], error: str) -> None:
        """Move a permanently failed task to the DLQ."""
        with self.get_session() as session:
            dlq = DeadLetterQueue(
                task_id=task.get("task_id", ""),
                task_type=task.get("task_type", "unknown"),
                payload=task.get("payload", {}),
                execution_id=task.get("execution_id"),
                created_by=task.get("created_by") or (task.get("payload") or {}).get("executed_by"),
                original_error=error,
                retry_count=task.get("retry_count", 0),
                first_failed_at=datetime.now(timezone.utc),
            )
            session.merge(dlq)

    def list_dead_letter(self, resolved: Optional[bool] = False,
                         limit: int = 100) -> List[Dict[str, Any]]:
        """List DLQ entries. resolved=None returns all."""
        with self.get_session() as session:
            q = session.query(DeadLetterQueue)
            if resolved is not None:
                q = q.filter(DeadLetterQueue.resolved == int(resolved))
            q = q.order_by(DeadLetterQueue.dead_at.desc()).limit(limit)
            return [r.to_dict() for r in q.all()]

    def resolve_dead_letter(self, task_id: str, resolved_by: str) -> bool:
        """Mark a DLQ entry as resolved."""
        with self.get_session() as session:
            dlq = session.query(DeadLetterQueue).filter(
                DeadLetterQueue.task_id == task_id
            ).first()
            if not dlq:
                return False
            dlq.resolved = 1
            dlq.resolved_at = datetime.now(timezone.utc)
            dlq.resolved_by = resolved_by
            return True

    def request_task_cancel(self, execution_id: str) -> bool:
        """Request cancellation of a task by execution_id.

        Sets cancel_requested=1 so the executor worker picks it up.
        Returns True if a running task was found and flagged.
        """
        with self.get_session() as session:
            task = (session.query(TaskQueue)
                    .filter(TaskQueue.execution_id == execution_id,
                            TaskQueue.status.in_(["pending", "claimed", "processing"]))
                    .first())
            if not task:
                return False
            task.cancel_requested = 1
            if task.status == "pending":
                task.status = "cancelled"
                task.error_message = "Cancelled by user"
                task.completed_at = datetime.now(timezone.utc)
            return True

    def is_task_cancelled(self, task_id: str) -> bool:
        """Quick check — has cancellation been requested for this task?

        Called by executor worker between chunks for cooperative cancellation.
        """
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return bool(task and task.cancel_requested)

    # ── TableFavorite operations ──────────────────────────────────────────

    def toggle_table_favorite(self, username: str, table_path: str,
                              table_name: str, connection_id: int = None,
                              table_type: str = None) -> bool:
        """Toggle favorite. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = (session.query(TableFavorite)
                        .filter(TableFavorite.username == username,
                                TableFavorite.table_path == table_path,
                                TableFavorite.connection_id == connection_id)
                        .first())
            if existing:
                session.delete(existing)
                return False
            fav = TableFavorite(
                username=username, table_path=table_path,
                table_name=table_name, connection_id=connection_id,
                table_type=table_type,
            )
            session.add(fav)
            return True

    def list_table_favorites(self, username: str,
                             connection_id: int = None) -> List[Dict[str, Any]]:
        """List user's favorited tables."""
        with self.get_session() as session:
            q = session.query(TableFavorite).filter(TableFavorite.username == username)
            if connection_id is not None:
                q = q.filter(TableFavorite.connection_id == connection_id)
            return [f.to_dict() for f in q.order_by(TableFavorite.created_at.desc()).all()]

    # ── Notification Log ────────────────────────────────────────────────────

    def log_notification(self, event_type: str, channel: str, recipient: str,
                         status: str = "sent", title: str = None, message: str = None,
                         payload: dict = None, execution_id: str = None,
                         schedule_id: int = None, attempt_count: int = 1,
                         error_message: str = None) -> Dict[str, Any]:
        """Record a notification delivery attempt."""
        with self.get_session() as session:
            row = NotificationLog(
                event_type=event_type, channel=channel, recipient=recipient,
                status=status, title=title, message=message, payload=payload,
                error_message=error_message, attempt_count=attempt_count,
                execution_id=execution_id, schedule_id=schedule_id,
                delivered_at=datetime.now(timezone.utc) if status == "sent" else None,
            )
            session.add(row)
            session.commit()
            session.refresh(row)
            return row.to_dict()

    def update_notification_status(self, notif_id: int, status: str,
                                   error_message: str = None) -> None:
        """Update delivery status of a notification."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row:
                row.status = status
                if error_message:
                    row.error_message = error_message
                if status == "sent":
                    row.delivered_at = datetime.now(timezone.utc)
                session.commit()

    def list_notifications(self, username: str, unread_only: bool = False,
                           limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """List notifications for a user (websocket channel, matched by recipient)."""
        with self.get_session() as session:
            q = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
            )
            if unread_only:
                q = q.filter(NotificationLog.is_read == 0)
            rows = q.order_by(NotificationLog.created_at.desc()).offset(offset).limit(limit).all()
            return [r.to_dict() for r in rows]

    def count_unread_notifications(self, username: str) -> int:
        """Count unread websocket notifications for a user."""
        with self.get_session() as session:
            return session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).count()

    def mark_notification_read(self, notif_id: int) -> None:
        """Mark a single notification as read."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row and not row.is_read:
                row.is_read = 1
                row.read_at = datetime.now(timezone.utc)
                session.commit()

    def mark_all_notifications_read(self, username: str) -> int:
        """Mark all unread notifications as read for a user. Returns count."""
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            count = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).update({"is_read": 1, "read_at": now}, synchronize_session=False)
            session.commit()
            return count

    def cleanup_old_notifications(self, max_age_days: int = 30) -> int:
        """Delete notifications older than max_age_days. Returns count deleted."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
            count = session.query(NotificationLog).filter(
                NotificationLog.created_at < cutoff,
            ).delete(synchronize_session=False)
            session.commit()
            return count

    # ── Phase 23A: Report Catalog ─────────────────────────────────────────────

    def create_folder(self, name: str, description: str = None, parent_id: int = None,
                      created_by: str = None, icon: str = "folder",
                      color: str = "#1976d2") -> Dict[str, Any]:
        with self.get_session() as session:
            folder = ReportFolder(name=name, description=description, parent_id=parent_id,
                                  created_by=created_by, icon=icon, color=color)
            session.add(folder)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def list_folders(self, parent_id: Optional[int] = None,
                     all_folders: bool = False) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(ReportFolder)
            if not all_folders:
                if parent_id is None:
                    q = q.filter(ReportFolder.parent_id.is_(None))
                else:
                    q = q.filter(ReportFolder.parent_id == parent_id)
            return [f.to_dict() for f in q.order_by(ReportFolder.name).all()]

    def update_folder(self, folder_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return None
            for k, v in kwargs.items():
                if hasattr(folder, k):
                    setattr(folder, k, v)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def delete_folder(self, folder_id: int) -> bool:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return False
            # Un-assign any reports in this folder
            session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.folder_id == folder_id
            ).delete(synchronize_session=False)
            # Re-parent child folders to this folder's parent
            session.query(ReportFolder).filter(
                ReportFolder.parent_id == folder_id
            ).update({"parent_id": folder.parent_id}, synchronize_session=False)
            session.delete(folder)
            return True

    def set_report_folder(self, report_id: int, folder_id: Optional[int]) -> None:
        with self.get_session() as session:
            existing = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id
            ).first()
            if folder_id is None:
                if existing:
                    session.delete(existing)
            else:
                if existing:
                    existing.folder_id = folder_id
                else:
                    session.add(ReportFolderAssignment(report_id=report_id, folder_id=folder_id))

    def get_report_folder(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            assignment = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id
            ).first()
            if not assignment:
                return None
            folder = session.query(ReportFolder).filter(
                ReportFolder.id == assignment.folder_id
            ).first()
            return folder.to_dict() if folder else None

    def create_tag(self, name: str, color: str = "#666666",
                   created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            tag = ReportTag(name=name, color=color, created_by=created_by)
            session.merge(tag)  # merge handles unique constraint gracefully
            session.flush()
            existing = session.query(ReportTag).filter(ReportTag.name == name).first()
            return existing.to_dict() if existing else tag.to_dict()

    def list_tags(self) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [t.to_dict() for t in session.query(ReportTag).order_by(ReportTag.name).all()]

    def delete_tag(self, tag_id: int) -> bool:
        with self.get_session() as session:
            tag = session.query(ReportTag).filter(ReportTag.id == tag_id).first()
            if not tag:
                return False
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.tag_id == tag_id
            ).delete(synchronize_session=False)
            session.delete(tag)
            return True

    def assign_report_tags(self, report_id: int, tag_ids: List[int]) -> None:
        with self.get_session() as session:
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id
            ).delete(synchronize_session=False)
            for tid in tag_ids:
                session.add(ReportTagAssignment(report_id=report_id, tag_id=tid))

    def get_report_tags(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            assignments = session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id
            ).all()
            tag_ids = [a.tag_id for a in assignments]
            if not tag_ids:
                return []
            tags = session.query(ReportTag).filter(ReportTag.id.in_(tag_ids)).all()
            return [t.to_dict() for t in tags]

    def toggle_report_favorite(self, report_id: int, username: str) -> bool:
        """Toggle. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = session.query(ReportFavorite).filter(
                ReportFavorite.report_id == report_id,
                ReportFavorite.username == username,
            ).first()
            if existing:
                session.delete(existing)
                return False
            session.add(ReportFavorite(report_id=report_id, username=username))
            return True

    def get_user_favorites(self, username: str) -> List[int]:
        """Return list of favorited report_ids for a user."""
        with self.get_session() as session:
            rows = session.query(ReportFavorite).filter(
                ReportFavorite.username == username
            ).all()
            return [r.report_id for r in rows]

    def record_report_view(self, report_id: int, username: str,
                           keep_last: int = 20) -> None:
        with self.get_session() as session:
            session.add(ReportView(report_id=report_id, username=username))
            session.flush()
            # Trim to last N views per user
            subq = (session.query(ReportView.id)
                    .filter(ReportView.username == username)
                    .order_by(ReportView.viewed_at.desc())
                    .offset(keep_last).all())
            old_ids = [r.id for r in subq]
            if old_ids:
                session.query(ReportView).filter(
                    ReportView.id.in_(old_ids)
                ).delete(synchronize_session=False)

    def get_recently_viewed(self, username: str, limit: int = 10) -> List[int]:
        """Return list of recently viewed report_ids (most recent first)."""
        with self.get_session() as session:
            rows = (session.query(ReportView)
                    .filter(ReportView.username == username)
                    .order_by(ReportView.viewed_at.desc())
                    .limit(limit).all())
            seen: set = set()
            result = []
            for r in rows:
                if r.report_id not in seen:
                    seen.add(r.report_id)
                    result.append(r.report_id)
            return result

    def search_reports(self, q: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Full-text search across report name + description."""
        from sqlalchemy import or_
        with self.get_session() as session:
            term = f"%{q}%"
            rows = (session.query(Report)
                    .filter(Report.is_active == True,
                            or_(Report.name.ilike(term),
                                Report.description.ilike(term)))
                    .order_by(Report.name)
                    .limit(limit).all())
            return [r.to_dict() for r in rows]

    # ── Phase 23G: Row-Level Security ─────────────────────────────────────────

    def create_rls_policy(self, report_id: int, column_name: str, operator: str,
                          value_template: str, description: str = None,
                          created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            policy = RLSPolicy(report_id=report_id, column_name=column_name,
                               operator=operator, value_template=value_template,
                               description=description, created_by=created_by)
            session.add(policy)
            session.flush()
            session.refresh(policy)
            return policy.to_dict()

    def list_rls_policies(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [p.to_dict() for p in
                    session.query(RLSPolicy).filter(RLSPolicy.report_id == report_id).all()]

    def update_rls_policy(self, policy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            policy = session.query(RLSPolicy).filter(RLSPolicy.id == policy_id).first()
            if not policy:
                return None
            for k, v in kwargs.items():
                if hasattr(policy, k):
                    setattr(policy, k, v)
            session.flush()
            session.refresh(policy)
            return policy.to_dict()

    def delete_rls_policy(self, policy_id: int) -> bool:
        with self.get_session() as session:
            policy = session.query(RLSPolicy).filter(RLSPolicy.id == policy_id).first()
            if not policy:
                return False
            session.delete(policy)
            return True

    def resolve_rls_value(self, value_template: str,
                          user_attrs: Dict[str, Any]) -> str:
        """Resolve {username}, {department}, etc. tokens from user attributes."""
        import re
        result = value_template
        for token in re.findall(r"\{(\w+)\}", value_template):
            val = user_attrs.get(token, "")
            result = result.replace(f"{{{token}}}", str(val))
        return result

    def build_rls_where_clauses(self, report_id: int,
                                user_attrs: Dict[str, Any]) -> List[str]:
        """Return list of SQL WHERE snippets for this report + user."""
        policies = self.list_rls_policies(report_id)
        clauses = []
        for p in policies:
            if not p.get("is_enabled"):
                continue
            col = p["column_name"]
            op  = p["operator"]
            val = self.resolve_rls_value(p["value_template"], user_attrs)
            if op.upper() in ("IN", "NOT IN"):
                vals = ", ".join(f"'{v.strip()}'" for v in val.split(","))
                clauses.append(f"{col} {op} ({vals})")
            else:
                clauses.append(f"{col} {op} '{val}'")
        return clauses

    # ── Phase 23B: Report Bookmarks ───────────────────────────────────────────

    def save_bookmark(self, report_id: int, username: str, name: str,
                      param_values: dict) -> Dict[str, Any]:
        with self.get_session() as session:
            bm = ReportBookmark(report_id=report_id, username=username,
                                name=name, param_values=param_values)
            session.add(bm)
            session.flush()
            session.refresh(bm)
            return bm.to_dict()

    def list_bookmarks(self, report_id: int,
                       username: str) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [b.to_dict() for b in
                    session.query(ReportBookmark)
                    .filter(ReportBookmark.report_id == report_id,
                            ReportBookmark.username == username)
                    .order_by(ReportBookmark.name).all()]

    def delete_bookmark(self, bookmark_id: int, username: str) -> bool:
        with self.get_session() as session:
            bm = session.query(ReportBookmark).filter(
                ReportBookmark.id == bookmark_id,
                ReportBookmark.username == username,
            ).first()
            if not bm:
                return False
            session.delete(bm)
            return True

    # ── Phase 23D: PDF Config ─────────────────────────────────────────────────

    def get_pdf_config(self, report_id: int) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id
            ).first()
            if not cfg:
                return ReportPDFConfig(report_id=report_id).to_dict()
            return cfg.to_dict()

    def save_pdf_config(self, report_id: int, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id
            ).first()
            if not cfg:
                cfg = ReportPDFConfig(report_id=report_id)
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            cfg.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    # ── Phase 23E: Report Bursting ────────────────────────────────────────────

    def create_burst_job(self, report_id: int, burst_column: str,
                         output_format: str = "pdf", delivery_type: str = "email",
                         base_params: dict = None, recipient_map: dict = None,
                         default_recipient: str = None, s3_prefix: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            job = BurstJob(report_id=report_id, burst_column=burst_column,
                           output_format=output_format, delivery_type=delivery_type,
                           base_params=base_params or {}, recipient_map=recipient_map,
                           default_recipient=default_recipient, s3_prefix=s3_prefix,
                           created_by=created_by)
            session.add(job)
            session.flush()
            session.refresh(job)
            return job.to_dict()

    def get_burst_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            job = session.query(BurstJob).filter(BurstJob.id == job_id).first()
            return job.to_dict() if job else None

    def list_burst_jobs(self, report_id: int,
                        limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [j.to_dict() for j in
                    session.query(BurstJob)
                    .filter(BurstJob.report_id == report_id)
                    .order_by(BurstJob.created_at.desc())
                    .limit(limit).all()]

    def update_burst_job(self, job_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstJob).filter(BurstJob.id == job_id).update(
                kwargs, synchronize_session=False
            )

    def create_burst_tasks(self, job_id: int,
                           tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            created = []
            for t in tasks:
                bt = BurstTask(burst_job_id=job_id,
                               dimension_value=t["dimension_value"],
                               recipient=t.get("recipient"))
                session.add(bt)
                session.flush()
                session.refresh(bt)
                created.append(bt.to_dict())
            return created

    def list_burst_tasks(self, job_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [t.to_dict() for t in
                    session.query(BurstTask)
                    .filter(BurstTask.burst_job_id == job_id)
                    .order_by(BurstTask.dimension_value).all()]

    def update_burst_task(self, task_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstTask).filter(BurstTask.id == task_id).update(
                kwargs, synchronize_session=False
            )

    # ── Phase 23F: Alert Rules ────────────────────────────────────────────────

    def create_alert_rule(self, report_id: int, name: str, column_name: str,
                          operator: str, threshold_value: float,
                          aggregation: str = "last", channels: list = None,
                          recipients: str = None, slack_webhook: str = None,
                          cooldown_minutes: int = 60,
                          created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            rule = AlertRule(
                report_id=report_id, name=name, column_name=column_name,
                operator=operator, threshold_value=threshold_value,
                aggregation=aggregation, channels=channels or [],
                recipients=recipients, slack_webhook=slack_webhook,
                cooldown_minutes=cooldown_minutes, created_by=created_by,
            )
            session.add(rule)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def list_alert_rules(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [r.to_dict() for r in
                    session.query(AlertRule)
                    .filter(AlertRule.report_id == report_id)
                    .order_by(AlertRule.name).all()]

    def update_alert_rule(self, rule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return None
            for k, v in kwargs.items():
                if hasattr(rule, k):
                    setattr(rule, k, v)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def delete_alert_rule(self, rule_id: int) -> bool:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return False
            session.delete(rule)
            return True

    def record_alert(self, rule_id: int, actual_value: float,
                     threshold_value: float, channel: str, sent_to: str,
                     suppressed: bool = False) -> None:
        with self.get_session() as session:
            session.add(AlertHistory(
                rule_id=rule_id, actual_value=actual_value,
                threshold_value=threshold_value, channel=channel,
                sent_to=sent_to, was_suppressed=suppressed,
            ))
            if not suppressed:
                session.query(AlertRule).filter(AlertRule.id == rule_id).update(
                    {"last_triggered_at": datetime.now(timezone.utc)},
                    synchronize_session=False,
                )

    def list_alert_history(self, rule_id: int,
                           limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [h.to_dict() for h in
                    session.query(AlertHistory)
                    .filter(AlertHistory.rule_id == rule_id)
                    .order_by(AlertHistory.triggered_at.desc())
                    .limit(limit).all()]

    def evaluate_alert_rules(self, report_id: int,
                             result_df_dict: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Evaluate all enabled alert rules for a report against result rows.
        Returns list of triggered rule dicts (caller handles notification)."""
        rules = [r for r in self.list_alert_rules(report_id) if r.get("is_enabled")]
        triggered = []
        now = datetime.now(timezone.utc)

        for rule in rules:
            # Check cooldown
            last = rule.get("last_triggered_at")
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt.tzinfo is None:
                        last_dt = last_dt.replace(tzinfo=timezone.utc)
                    elapsed_min = (now - last_dt).total_seconds() / 60
                    if elapsed_min < rule["cooldown_minutes"]:
                        continue  # Still in cooldown
                except Exception:
                    pass

            col = rule["column_name"]
            agg = rule.get("aggregation", "last")
            try:
                values = [float(r[col]) for r in result_df_dict
                          if r.get(col) is not None]
                if not values:
                    continue
                if agg == "last":
                    actual = values[-1]
                elif agg == "sum":
                    actual = sum(values)
                elif agg == "avg":
                    actual = sum(values) / len(values)
                elif agg == "max":
                    actual = max(values)
                elif agg == "min":
                    actual = min(values)
                elif agg == "count":
                    actual = float(len(values))
                else:
                    actual = values[-1]
            except (KeyError, ValueError, TypeError):
                continue

            op = rule["operator"]
            th = rule["threshold_value"]
            fired = (
                (op == ">"  and actual >  th) or
                (op == "<"  and actual <  th) or
                (op == ">=" and actual >= th) or
                (op == "<=" and actual <= th) or
                (op == "="  and actual == th) or
                (op == "!=" and actual != th)
            )
            if fired:
                triggered.append({**rule, "actual_value": actual})

        return triggered

    # ── Phase 23C: Conditional Formatting ────────────────────────────────────

    def save_conditional_formats(self, report_id: int,
                                 rules: List[Dict[str, Any]]) -> None:
        """Replace all conditional format rules for a report."""
        with self.get_session() as session:
            session.query(ConditionalFormatRule).filter(
                ConditionalFormatRule.report_id == report_id
            ).delete(synchronize_session=False)
            for i, r in enumerate(rules):
                session.add(ConditionalFormatRule(
                    report_id=report_id,
                    column_name=r.get("column_name", ""),
                    rule_order=r.get("rule_order", i),
                    condition_type=r.get("condition_type", "value_range"),
                    condition_value=r.get("condition_value"),
                    bg_color=r.get("bg_color"),
                    text_color=r.get("text_color"),
                    icon=r.get("icon", "none"),
                    bold=r.get("bold", False),
                    is_enabled=r.get("is_enabled", True),
                ))

    def get_conditional_formats(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            return [r.to_dict() for r in
                    session.query(ConditionalFormatRule)
                    .filter(ConditionalFormatRule.report_id == report_id)
                    .order_by(ConditionalFormatRule.column_name,
                               ConditionalFormatRule.rule_order)
                    .all()]

    # ── Phase 23H: Cloud Delivery ─────────────────────────────────────────────

    def save_cloud_delivery_config(self, schedule_id: int,
                                   **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            if not cfg:
                cfg = CloudDeliveryConfig(schedule_id=schedule_id,
                                          provider=kwargs.pop("provider", "s3"))
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    def get_cloud_delivery_config(self,
                                  schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            return cfg.to_dict() if cfg else None

    def record_delivery(self, delivery_type: str, destination: str,
                        status: str, schedule_id: int = None,
                        burst_task_id: int = None, execution_id: str = None,
                        file_format: str = None, file_size_bytes: int = None,
                        error_message: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = DeliveryHistory(
                schedule_id=schedule_id, burst_task_id=burst_task_id,
                execution_id=execution_id, delivery_type=delivery_type,
                destination=destination, file_format=file_format,
                file_size_bytes=file_size_bytes, status=status,
                error_message=error_message,
                delivered_at=datetime.now(timezone.utc) if status == "delivered" else None,
            )
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def list_delivery_history(self, schedule_id: int = None,
                              burst_task_id: int = None,
                              limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DeliveryHistory)
            if schedule_id is not None:
                q = q.filter(DeliveryHistory.schedule_id == schedule_id)
            if burst_task_id is not None:
                q = q.filter(DeliveryHistory.burst_task_id == burst_task_id)
            return [d.to_dict() for d in
                    q.order_by(DeliveryHistory.attempted_at.desc()).limit(limit).all()]

    # ── Workspaces (Phase 25) ─────────────────────────────────────────────────

    def ensure_default_workspace(self) -> Dict[str, Any]:
        """Create the Global workspace on first startup if none exist."""
        with self.get_session() as session:
            existing = session.query(Workspace).filter(Workspace.is_active == True).first()
            if existing:
                return existing.to_dict()
            ws = Workspace(name="Global", slug="global",
                           description="Default workspace", created_by="system")
            session.add(ws)
            session.flush()
            session.refresh(ws)
            return ws.to_dict()

    def list_workspaces(self, username: str = None) -> List[Dict[str, Any]]:
        """Return workspaces the user is a member of, or all if username is None."""
        with self.get_session() as session:
            if username is None:
                wss = session.query(Workspace).filter(
                    Workspace.is_active == True
                ).order_by(Workspace.name).all()
                return [w.to_dict() for w in wss]
            # Workspaces where user is a member
            member_wids = [
                m.workspace_id for m in
                session.query(WorkspaceMember).filter(
                    WorkspaceMember.username == username
                ).all()
            ]
            wss = session.query(Workspace).filter(
                Workspace.id.in_(member_wids),
                Workspace.is_active == True,
            ).order_by(Workspace.name).all()
            return [w.to_dict() for w in wss]

    def get_workspace(self, workspace_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            return ws.to_dict() if ws else None

    def create_workspace(self, name: str, slug: str,
                         description: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            ws = Workspace(name=name, slug=slug, description=description,
                           created_by=created_by)
            session.add(ws)
            session.flush()
            session.refresh(ws)
            # Auto-add creator as owner
            if created_by:
                m = WorkspaceMember(workspace_id=ws.id, username=created_by,
                                    role="owner", added_by=created_by)
                session.add(m)
                session.flush()
            return ws.to_dict()

    def update_workspace(self, workspace_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return None
            for k, v in kwargs.items():
                if hasattr(ws, k):
                    setattr(ws, k, v)
            ws.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(ws)
            return ws.to_dict()

    def delete_workspace(self, workspace_id: int) -> bool:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return False
            ws.is_active = False
            ws.updated_at = datetime.now(timezone.utc)
            return True

    def list_workspace_members(self, workspace_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            members = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id
            ).order_by(WorkspaceMember.added_at).all()
            return [m.to_dict() for m in members]

    def add_workspace_member(self, workspace_id: int, username: str,
                             role: str = "member",
                             added_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Upsert: update role if already member
            existing = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if existing:
                existing.role = role
                session.flush()
                session.refresh(existing)
                return existing.to_dict()
            m = WorkspaceMember(workspace_id=workspace_id, username=username,
                                role=role, added_by=added_by)
            session.add(m)
            session.flush()
            session.refresh(m)
            return m.to_dict()

    def update_workspace_member_role(self, workspace_id: int,
                                     username: str, role: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            m.role = role
            return True

    def remove_workspace_member(self, workspace_id: int,
                                username: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            session.delete(m)
            return True

    # ── Report Embed Tokens (27) ──────────────────────────────────────────────

    def create_report_embed_token(self, report_id: int, created_by: str = None,
                                  expires_at=None, allowed_params=None) -> Dict[str, Any]:
        import uuid, json as _json
        with self.get_session() as session:
            tok = ReportEmbedToken(
                token=uuid.uuid4().hex,
                report_id=report_id,
                created_by=created_by,
                expires_at=expires_at,
                is_active=True,
                access_count=0,
                allowed_params=_json.dumps(allowed_params) if allowed_params else None,
            )
            session.add(tok)
            session.flush()
            return tok.to_dict()

    def get_embed_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            return t.to_dict() if t else None

    def list_embed_tokens(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.report_id == report_id,
            ).order_by(ReportEmbedToken.created_at.desc()).all()
            return [r.to_dict() for r in rows]

    def revoke_embed_token(self, token: str) -> bool:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if not t:
                return False
            t.is_active = False
            return True

    def increment_embed_token_access(self, token: str) -> None:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if t:
                t.access_count = (t.access_count or 0) + 1

    # ── Audit & Compliance (28) ───────────────────────────────────────────────

    def get_audit_log_filtered(self, username: str = None, action: str = None,
                               resource_type: str = None, date_from: str = None,
                               date_to: str = None, limit: int = 200,
                               offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries with extended filters."""
        with self.get_session() as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            if resource_type:
                q = q.filter(AuditLog.resource_type == resource_type)
            if date_from:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp >= _parse(date_from))
                except Exception:
                    pass
            if date_to:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp <= _parse(date_to))
                except Exception:
                    pass
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def get_data_access_summary(self) -> List[Dict[str, Any]]:
        """Return per-user aggregate data access statistics."""
        with self.get_session() as session:
            from sqlalchemy import func, distinct
            # Aggregate from query_executions
            exec_rows = session.query(
                QueryExecution.executed_by,
                func.count(QueryExecution.id).label("total_executions"),
                func.max(QueryExecution.started_at).label("last_active"),
                func.sum(QueryExecution.total_rows).label("total_rows"),
            ).filter(QueryExecution.executed_by.isnot(None)).group_by(
                QueryExecution.executed_by
            ).all()
            # Aggregate download count from audit_log
            download_rows = session.query(
                AuditLog.username,
                func.count(AuditLog.id).label("export_count"),
            ).filter(AuditLog.action.in_(["download_file", "export_csv"])).group_by(
                AuditLog.username
            ).all()
            dl_map = {r.username: r.export_count for r in download_rows}
            result = []
            for r in exec_rows:
                result.append({
                    "username": r.executed_by,
                    "total_executions": r.total_executions or 0,
                    "last_active": r.last_active.isoformat() if r.last_active else None,
                    "total_rows": r.total_rows or 0,
                    "export_count": dl_map.get(r.executed_by, 0),
                })
            return result

    # -- Schedule run stats (Phase 38 anomaly detection) -------------------------

    def create_schedule_run_stats(self, schedule_id: int, row_count: int = 0,
                                  execution_seconds: float = 0.0,
                                  file_size_bytes: int = 0,
                                  anomaly_type: str = None,
                                  anomaly_details: dict = None) -> dict:
        with self.get_session() as session:
            entry = ScheduleRunStats(
                schedule_id=schedule_id,
                row_count=row_count,
                execution_seconds=execution_seconds,
                file_size_bytes=file_size_bytes,
                anomaly_type=anomaly_type,
                anomaly_details=anomaly_details,
            )
            session.add(entry)
            session.commit()
            session.refresh(entry)
            return entry.to_dict()

    def get_schedule_run_stats(self, schedule_id: int, limit: int = 20) -> list:
        with self.get_session() as session:
            entries = (session.query(ScheduleRunStats)
                       .filter_by(schedule_id=schedule_id)
                       .order_by(ScheduleRunStats.run_at.desc())
                       .limit(limit)
                       .all())
            return [e.to_dict() for e in entries]

    def list_anomalies(self, schedule_id: int = None, limit: int = 50) -> list:
        with self.get_session() as session:
            q = session.query(ScheduleRunStats).filter(
                ScheduleRunStats.anomaly_type.isnot(None)
            )
            if schedule_id:
                q = q.filter_by(schedule_id=schedule_id)
            entries = q.order_by(ScheduleRunStats.run_at.desc()).limit(limit).all()
            return [e.to_dict() for e in entries]

    # ── Checkpoint methods (Phase 41) ────────────────────────────────────

    def set_checkpoint(self, execution_id: str, state: str, query_config: dict,
                       executed_by: str = "", query_id: int = None,
                       timestamp: float = 0) -> None:
        """Insert or update a checkpoint record for an execution."""
        import time as _time
        with self.get_session() as session:
            cp = ExecutionCheckpoint(
                execution_id=execution_id, state=state,
                query_config=query_config, executed_by=executed_by,
                query_id=query_id, timestamp=timestamp or _time.time(),
            )
            session.merge(cp)

    def update_checkpoint(self, execution_id: str, state: str, timestamp: float = 0) -> None:
        """Update the state of an existing checkpoint."""
        import time as _time
        with self.get_session() as session:
            cp = session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).first()
            if cp:
                cp.state = state
                cp.timestamp = timestamp or _time.time()

    def delete_checkpoint(self, execution_id: str) -> None:
        """Remove a checkpoint record (execution finished)."""
        with self.get_session() as session:
            session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).delete()

    def get_all_checkpoints(self) -> list:
        """Return all checkpoint records (used during recovery on startup)."""
        with self.get_session() as session:
            rows = session.query(ExecutionCheckpoint).all()
            return [{"execution_id": r.execution_id, "state": r.state,
                     "query_config": r.query_config, "executed_by": r.executed_by,
                     "query_id": r.query_id, "timestamp": r.timestamp} for r in rows]

    def get_user_data_export(self, username: str) -> Dict[str, Any]:
        """Return all data related to a user for GDPR subject export."""
        with self.get_session() as session:
            saved_queries = session.query(SavedQuery).filter(
                SavedQuery.created_by == username
            ).all()
            sql_queries = session.query(SqlSavedQuery).filter(
                SqlSavedQuery.created_by == username
            ).all()
            executions = session.query(QueryExecution).filter(
                QueryExecution.executed_by == username
            ).order_by(QueryExecution.started_at.desc()).limit(10000).all()
            downloads = session.query(DownloadFile).filter(
                DownloadFile.created_by == username
            ).order_by(DownloadFile.created_at.desc()).limit(10000).all()
            schedules = session.query(Schedule).filter(
                Schedule.created_by == username
            ).all()
            audit = session.query(AuditLog).filter(
                AuditLog.username == username
            ).order_by(AuditLog.timestamp.desc()).limit(50000).all()
            return {
                "username": username,
                "saved_queries": [q.to_dict() for q in saved_queries],
                "sql_queries": [q.to_dict() for q in sql_queries],
                "executions": [e.to_dict() for e in executions],
                "downloads": [d.to_dict() for d in downloads],
                "schedules": [s.to_dict() for s in schedules],
                "audit_log": [a.to_dict() for a in audit],
            }

    # ── Table lineage (Phase 49) ─────────────────────────────────────────────

    def upsert_table_lineage(self, query_type: str, query_id: int, entries: List[Dict[str, Any]]) -> None:
        """Replace all lineage entries for a query with new ones."""
        with self.get_session() as session:
            session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).delete()
            for e in entries:
                session.add(TableLineageEntry(
                    query_type=e["query_type"],
                    query_id=e["query_id"],
                    connection_id=e.get("connection_id"),
                    table_catalog=e.get("table_catalog"),
                    table_schema=e.get("table_schema"),
                    table_name=e["table_name"],
                    access_type=e.get("access_type", "read"),
                    extraction_method=e.get("extraction_method", "sqlglot"),
                ))

    def get_table_lineage_for_query(self, query_type: str, query_id: int) -> List[Dict[str, Any]]:
        """All physical tables a query touches."""
        with self.get_session() as session:
            rows = session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).all()
            return [r.to_dict() for r in rows]

    def get_queries_for_table(self, table_catalog: Optional[str], table_schema: Optional[str],
                              table_name: str) -> List[Dict[str, Any]]:
        """Reverse lookup: all queries that reference a physical table (impact analysis)."""
        with self.get_session() as session:
            q = session.query(TableLineageEntry).filter(TableLineageEntry.table_name == table_name)
            if table_schema:
                q = q.filter(TableLineageEntry.table_schema == table_schema)
            if table_catalog:
                q = q.filter(TableLineageEntry.table_catalog == table_catalog)
            return [r.to_dict() for r in q.all()]

    def get_all_table_lineage_entries(self) -> List[Dict[str, Any]]:
        """All table lineage entries — for graph building."""
        with self.get_session() as session:
            rows = session.query(TableLineageEntry).all()
            return [r.to_dict() for r in rows]

    def delete_table_lineage(self, query_type: str, query_id: int) -> None:
        """Remove lineage entries when a query is deleted."""
        with self.get_session() as session:
            session.query(TableLineageEntry).filter(
                TableLineageEntry.query_type == query_type,
                TableLineageEntry.query_id == query_id,
            ).delete()

    def search_table_lineage(self, search_term: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Full-text search across table catalog/schema/name."""
        with self.get_session() as session:
            pattern = f"%{search_term}%"
            from sqlalchemy import or_
            rows = session.query(TableLineageEntry).filter(
                or_(
                    TableLineageEntry.table_name.ilike(pattern),
                    TableLineageEntry.table_schema.ilike(pattern),
                    TableLineageEntry.table_catalog.ilike(pattern),
                )
            ).limit(limit).all()
            # Deduplicate by (catalog, schema, table)
            seen = set()
            results = []
            for r in rows:
                key = (r.table_catalog, r.table_schema, r.table_name)
                if key not in seen:
                    seen.add(key)
                    results.append({
                        "table_catalog": r.table_catalog,
                        "table_schema": r.table_schema,
                        "table_name": r.table_name,
                        "connection_id": r.connection_id,
                        "query_count": session.query(TableLineageEntry).filter(
                            TableLineageEntry.table_name == r.table_name,
                            TableLineageEntry.table_schema == r.table_schema,
                            TableLineageEntry.table_catalog == r.table_catalog,
                        ).count(),
                    })
            return results

    # ── Phase 46: Query Usage Stats (auto-suggest) ────────────────────────────

    def record_usage(self, object_type: str, object_name: str,
                     connection_id: Optional[int] = None,
                     table_name: Optional[str] = None,
                     schema_name: Optional[str] = None,
                     catalog_name: Optional[str] = None) -> None:
        """Increment use_count for table/column or create new entry."""
        with self.get_session() as session:
            row = session.query(QueryUsageStat).filter(
                QueryUsageStat.object_type == object_type,
                QueryUsageStat.object_name == object_name,
                QueryUsageStat.connection_id == connection_id,
            ).first()
            if row:
                row.use_count += 1
                row.last_used_at = datetime.now(timezone.utc)
            else:
                session.add(QueryUsageStat(
                    object_type=object_type,
                    object_name=object_name,
                    table_name=table_name,
                    schema_name=schema_name,
                    catalog_name=catalog_name,
                    connection_id=connection_id,
                    use_count=1,
                ))

    def get_table_suggestions(self, prefix: str = "",
                               connection_id: Optional[int] = None,
                               limit: int = 20) -> List[Dict[str, Any]]:
        """Return tables ranked by use_count descending, optionally filtered by prefix."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "table")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            if prefix:
                q = q.filter(QueryUsageStat.object_name.ilike(f"{prefix}%"))
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_column_suggestions(self, table_name: str = "",
                                connection_id: Optional[int] = None,
                                limit: int = 30) -> List[Dict[str, Any]]:
        """Return columns for a table ranked by use_count."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "column")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            if table_name:
                q = q.filter(QueryUsageStat.table_name == table_name)
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_top_tables(self, connection_id: Optional[int] = None,
                       limit: int = 50) -> List[Dict[str, Any]]:
        """Top tables by usage across all connections."""
        with self.get_session() as session:
            q = session.query(QueryUsageStat).filter(QueryUsageStat.object_type == "table")
            if connection_id is not None:
                q = q.filter(QueryUsageStat.connection_id == connection_id)
            rows = q.order_by(QueryUsageStat.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    # ── Phase 51: Column Lineage ──────────────────────────────────────────────

    def upsert_column_lineage(self, query_type: str, query_id: int,
                               entries: List[Dict[str, Any]]) -> None:
        """Replace all column lineage entries for a query."""
        with self.get_session() as session:
            session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.query_type == query_type,
                ColumnLineageEntry.query_id == query_id,
            ).delete()
            for e in entries:
                session.add(ColumnLineageEntry(
                    query_type=query_type,
                    query_id=query_id,
                    source_table=e.get("source_table"),
                    source_column=e.get("source_column"),
                    target_column=e["target_column"],
                    transform_type=e.get("transform_type", "direct"),
                    transform_expr=e.get("transform_expr"),
                ))

    def get_column_lineage_for_query(self, query_type: str, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.query_type == query_type,
                ColumnLineageEntry.query_id == query_id,
            ).all()
            return [r.to_dict() for r in rows]

    def get_column_impact(self, table_name: str, column_name: str) -> List[Dict[str, Any]]:
        """All queries that consume a specific source table.column."""
        with self.get_session() as session:
            rows = session.query(ColumnLineageEntry).filter(
                ColumnLineageEntry.source_table == table_name,
                ColumnLineageEntry.source_column == column_name,
            ).order_by(ColumnLineageEntry.query_id).all()
            return [r.to_dict() for r in rows]

    # ── NL Feedback / Learning ────────────────────────────────────────────────

    def save_nl_feedback(self, question: str, sql: str,
                          connection_type: str = "duckdb",
                          tables_hint: str = "",
                          rating: int = 1) -> Dict[str, Any]:
        """Upsert a user-rated NL→SQL pair (by question text)."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            existing = session.query(NLFeedback).filter(
                NLFeedback.question == question[:500]
            ).first()
            if existing:
                existing.sql          = sql
                existing.rating       = rating
                existing.use_count    = (existing.use_count or 0) + 1
                existing.updated_at   = now
                session.flush()
                return existing.to_dict()
            row = NLFeedback(
                question=question[:500], sql=sql,
                connection_type=connection_type,
                tables_hint=tables_hint[:500] if tables_hint else "",
                rating=rating, use_count=1,
                created_at=now, updated_at=now,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_nl_feedback(self, limit: int = 200, rating: int = 1) -> List[Dict[str, Any]]:
        """Return all positively-rated NL→SQL pairs, sorted by use_count desc."""
        with self.get_session() as session:
            rows = session.query(NLFeedback).filter(
                NLFeedback.rating >= rating
            ).order_by(NLFeedback.use_count.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def delete_nl_feedback(self, feedback_id: int) -> bool:
        """Remove a learned pattern by ID."""
        with self.get_session() as session:
            row = session.query(NLFeedback).filter(NLFeedback.id == feedback_id).first()
            if row:
                session.delete(row)
                return True
            return False

    # ------------------------------------------------------------------ #
    #  UI Component Visibility                                             #
    # ------------------------------------------------------------------ #

    def get_ui_visibility(self) -> List[Dict[str, Any]]:
        """Return all stored visibility rows (only explicit overrides)."""
        with self.get_session() as session:
            rows = session.query(UIComponentVisibility).order_by(
                UIComponentVisibility.component_key,
                UIComponentVisibility.role,
            ).all()
            return [r.to_dict() for r in rows]

    def get_ui_visibility_for_role(self, role: str) -> Dict[str, bool]:
        """Return {component_key: enabled} map for a given role."""
        with self.get_session() as session:
            rows = session.query(UIComponentVisibility).filter(
                UIComponentVisibility.role == role
            ).all()
            return {r.component_key: r.enabled for r in rows}

    def set_ui_visibility(self, component_key: str, role: str, enabled: bool) -> Dict[str, Any]:
        """Upsert a single visibility rule."""
        with self.get_session() as session:
            row = session.query(UIComponentVisibility).filter(
                UIComponentVisibility.component_key == component_key,
                UIComponentVisibility.role == role,
            ).first()
            if row:
                row.enabled = enabled
            else:
                row = UIComponentVisibility(
                    component_key=component_key, role=role, enabled=enabled
                )
                session.add(row)
            session.flush()
            return row.to_dict()

    def bulk_set_ui_visibility(self, rules: List[Dict[str, Any]]) -> int:
        """Upsert many rules at once.  rules = [{component_key, role, enabled}]"""
        count = 0
        for r in rules:
            self.set_ui_visibility(r["component_key"], r["role"], bool(r["enabled"]))
            count += 1
        return count

    # ── Lineage Snapshots (Phase 52) ─────────────────────────────────────────

    def save_lineage_snapshot(self, execution_id: str, query_type: str,
                               query_id: int, snapshot_data: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            row = LineageSnapshot(
                execution_id=execution_id,
                query_type=query_type,
                query_id=query_id,
                snapshot_data=json.dumps(snapshot_data),
                captured_at=datetime.now(timezone.utc),
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_lineage_snapshots(self, query_type: str = None, query_id: int = None,
                               limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(LineageSnapshot)
            if query_type:
                q = q.filter(LineageSnapshot.query_type == query_type)
            if query_id is not None:
                q = q.filter(LineageSnapshot.query_id == query_id)
            rows = q.order_by(LineageSnapshot.captured_at.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def get_lineage_snapshot(self, snapshot_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(LineageSnapshot).filter(LineageSnapshot.id == snapshot_id).first()
            return row.to_dict() if row else None

    def delete_old_lineage_snapshots(self, older_than_days: int) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(days=older_than_days)
        with self.get_session() as session:
            deleted = session.query(LineageSnapshot).filter(
                LineageSnapshot.captured_at < cutoff
            ).delete()
            return deleted

    # ── Data Freshness (Phase 52) ─────────────────────────────────────────────

    def upsert_data_freshness(self, table_fqn: str, connection_id: Optional[int],
                               stale_threshold_hours: int = 24) -> Dict[str, Any]:
        """Record a table as observed now (freshness heartbeat)."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            ).first()
            if row:
                row.last_observed_at = now
                row.freshness_status = "fresh"
                if connection_id is not None:
                    row.connection_id = connection_id
            else:
                row = DataFreshness(
                    table_fqn=table_fqn,
                    connection_id=connection_id,
                    last_observed_at=now,
                    freshness_status="fresh",
                    stale_threshold_hours=stale_threshold_hours,
                )
                session.add(row)
            session.flush()
            return row.to_dict()

    def get_data_freshness(self, table_fqn: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DataFreshness)
            if table_fqn:
                q = q.filter(DataFreshness.table_fqn == table_fqn)
            return [r.to_dict() for r in q.order_by(DataFreshness.table_fqn).all()]

    def update_freshness_threshold(self, table_fqn: str, hours: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            ).first()
            if not row:
                return None
            row.stale_threshold_hours = hours
            session.flush()
            return row.to_dict()

    def mark_table_refreshed(self, table_fqn: str) -> Optional[Dict[str, Any]]:
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(DataFreshness).filter(
                DataFreshness.table_fqn == table_fqn
            ).first()
            if not row:
                return None
            row.last_refresh_at = now
            row.last_observed_at = now
            row.freshness_status = "fresh"
            session.flush()
            return row.to_dict()

    # ─────────────────────────────────────────────────────────────────────
    # Phase 53 — Semantic Layer (Business Datasets)
    # ─────────────────────────────────────────────────────────────────────

    # ── BusinessDataset CRUD ──────────────────────────────────────────────

    def list_datasets(self, subject: str = None, published_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(BusinessDataset)
            if subject:
                q = q.filter(BusinessDataset.subject == subject)
            if published_only:
                q = q.filter(BusinessDataset.is_published == True)
            return [r.to_dict() for r in q.order_by(BusinessDataset.name).all()]

    def get_dataset(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            return row.to_dict() if row else None

    def create_dataset(self, name: str, subject: str, description: str = "",
                       owner: str = "admin", connection_ids: list = None,
                       source_tables: list = None, base_query: str = "",
                       is_published: bool = False) -> Dict[str, Any]:
        with self.get_session() as session:
            ds = BusinessDataset(
                name=name, subject=subject, description=description,
                owner=owner, connection_ids=connection_ids or [],
                source_tables=source_tables or [], base_query=base_query,
                is_published=is_published,
            )
            session.add(ds)
            session.flush()
            return ds.to_dict()

    def update_dataset(self, dataset_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return None
            allowed = {"name", "description", "subject", "owner", "connection_ids",
                       "source_tables", "base_query", "is_published"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def delete_dataset(self, dataset_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return False
            # Cascade: delete related objects
            session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id).delete()
            session.query(DatasetClass).filter(DatasetClass.dataset_id == dataset_id).delete()
            session.query(DatasetRelationship).filter(DatasetRelationship.dataset_id == dataset_id).delete()
            session.query(DrillHierarchy).filter(DrillHierarchy.dataset_id == dataset_id).delete()
            session.query(PreDefinedCondition).filter(PreDefinedCondition.dataset_id == dataset_id).delete()
            session.query(AggregationAwareness).filter(AggregationAwareness.dataset_id == dataset_id).delete()
            session.delete(row)
            return True

    # ── DatasetClass CRUD ─────────────────────────────────────────────────

    def list_dataset_classes(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetClass).filter(
                DatasetClass.dataset_id == dataset_id
            ).order_by(DatasetClass.sort_order, DatasetClass.name).all()
            return [r.to_dict() for r in rows]

    def create_dataset_class(self, dataset_id: int, name: str,
                             label: str = "", icon: str = "",
                             sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            obj = DatasetClass(dataset_id=dataset_id, name=name,
                               label=label, icon=icon, sort_order=sort_order)
            session.add(obj)
            session.flush()
            return obj.to_dict()

    def update_dataset_class(self, class_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "icon", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_class(self, class_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return False
            # Unlink columns from this class (set class_id=None)
            session.query(DatasetColumn).filter(DatasetColumn.class_id == class_id).update(
                {"class_id": None}, synchronize_session="fetch")
            session.delete(row)
            return True

    # ── DatasetColumn CRUD ────────────────────────────────────────────────

    def list_dataset_columns(self, dataset_id: int,
                             column_type: str = None,
                             include_hidden: bool = True) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id)
            if column_type:
                q = q.filter(DatasetColumn.column_type == column_type)
            if not include_hidden:
                q = q.filter(DatasetColumn.is_hidden == False)
            return [r.to_dict() for r in q.order_by(DatasetColumn.sort_order, DatasetColumn.friendly_name).all()]

    def get_dataset_column(self, column_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            return row.to_dict() if row else None

    def create_dataset_column(self, dataset_id: int, physical_name: str,
                              friendly_name: str, column_type: str = "dimension",
                              data_type: str = "string", aggregation: str = "",
                              format_pattern: str = "", description: str = "",
                              synonyms: list = None, role_whitelist: list = None,
                              class_id: int = None, sort_order: int = 0,
                              is_hidden: bool = False) -> Dict[str, Any]:
        with self.get_session() as session:
            col = DatasetColumn(
                dataset_id=dataset_id, physical_name=physical_name,
                friendly_name=friendly_name, column_type=column_type,
                data_type=data_type, aggregation=aggregation,
                format_pattern=format_pattern, description=description,
                synonyms=synonyms or [], role_whitelist=role_whitelist or [],
                class_id=class_id, sort_order=sort_order, is_hidden=is_hidden,
            )
            session.add(col)
            session.flush()
            return col.to_dict()

    def update_dataset_column(self, column_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return None
            allowed = {"physical_name", "friendly_name", "column_type", "data_type",
                       "aggregation", "format_pattern", "description", "synonyms",
                       "role_whitelist", "class_id", "sort_order", "is_hidden"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_column(self, column_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    def bulk_create_dataset_columns(self, dataset_id: int,
                                    columns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Bulk-create columns for a dataset (used by auto-detect from schema)."""
        results = []
        with self.get_session() as session:
            for c in columns:
                col = DatasetColumn(
                    dataset_id=dataset_id,
                    physical_name=c.get("physical_name", ""),
                    friendly_name=c.get("friendly_name", c.get("physical_name", "")),
                    column_type=c.get("column_type", "dimension"),
                    data_type=c.get("data_type", "string"),
                    aggregation=c.get("aggregation", ""),
                    format_pattern=c.get("format_pattern", ""),
                    description=c.get("description", ""),
                    synonyms=c.get("synonyms", []),
                    role_whitelist=c.get("role_whitelist", []),
                    class_id=c.get("class_id"),
                    sort_order=c.get("sort_order", 0),
                    is_hidden=c.get("is_hidden", False),
                )
                session.add(col)
                session.flush()
                results.append(col.to_dict())
        return results

    # ── DatasetRelationship CRUD ──────────────────────────────────────────

    def list_dataset_relationships(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetRelationship).filter(
                DatasetRelationship.dataset_id == dataset_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_dataset_relationship(self, dataset_id: int, left_table: str,
                                    right_table: str, join_keys: list,
                                    join_type: str = "inner",
                                    cardinality: str = "many_to_one") -> Dict[str, Any]:
        with self.get_session() as session:
            rel = DatasetRelationship(
                dataset_id=dataset_id, left_table=left_table,
                right_table=right_table, join_keys=join_keys,
                join_type=join_type, cardinality=cardinality,
            )
            session.add(rel)
            session.flush()
            return rel.to_dict()

    def update_dataset_relationship(self, rel_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"left_table", "right_table", "join_type", "join_keys", "cardinality"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_relationship(self, rel_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── DrillHierarchy CRUD ───────────────────────────────────────────────

    def list_drill_hierarchies(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DrillHierarchy).filter(
                DrillHierarchy.dataset_id == dataset_id
            ).order_by(DrillHierarchy.name).all()
            return [r.to_dict() for r in rows]

    def create_drill_hierarchy(self, dataset_id: int, name: str,
                               levels: list) -> Dict[str, Any]:
        with self.get_session() as session:
            h = DrillHierarchy(dataset_id=dataset_id, name=name, levels=levels)
            session.add(h)
            session.flush()
            return h.to_dict()

    def update_drill_hierarchy(self, hierarchy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "levels"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_drill_hierarchy(self, hierarchy_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── PreDefinedCondition CRUD ──────────────────────────────────────────

    def list_predefined_conditions(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(PreDefinedCondition).filter(
                PreDefinedCondition.dataset_id == dataset_id
            ).order_by(PreDefinedCondition.sort_order, PreDefinedCondition.name).all()
            return [r.to_dict() for r in rows]

    def create_predefined_condition(self, dataset_id: int, name: str,
                                    where_clause: str, label: str = "",
                                    description: str = "",
                                    sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            c = PreDefinedCondition(
                dataset_id=dataset_id, name=name, where_clause=where_clause,
                label=label, description=description, sort_order=sort_order,
            )
            session.add(c)
            session.flush()
            return c.to_dict()

    def update_predefined_condition(self, condition_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "description", "where_clause", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_predefined_condition(self, condition_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── AggregationAwareness CRUD ─────────────────────────────────────────

    def list_aggregation_awareness(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(AggregationAwareness).filter(
                AggregationAwareness.dataset_id == dataset_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_aggregation_awareness(self, dataset_id: int, measure_col_id: int,
                                     agg_table: str, agg_dimensions: list,
                                     connection_id: int = None,
                                     is_enabled: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            aa = AggregationAwareness(
                dataset_id=dataset_id, measure_col_id=measure_col_id,
                agg_table=agg_table, agg_dimensions=agg_dimensions,
                connection_id=connection_id, is_enabled=is_enabled,
            )
            session.add(aa)
            session.flush()
            return aa.to_dict()

    def delete_aggregation_awareness(self, agg_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(AggregationAwareness).filter(AggregationAwareness.id == agg_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── Full dataset with all children (single round-trip) ────────────────

    def get_dataset_full(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        """Return a dataset with all its classes, columns, relationships,
        hierarchies, conditions, and aggregation awareness rules."""
        ds = self.get_dataset(dataset_id)
        if not ds:
            return None
        ds["classes"]        = self.list_dataset_classes(dataset_id)
        ds["columns"]        = self.list_dataset_columns(dataset_id)
        ds["relationships"]  = self.list_dataset_relationships(dataset_id)
        ds["hierarchies"]    = self.list_drill_hierarchies(dataset_id)
        ds["conditions"]     = self.list_predefined_conditions(dataset_id)
        ds["agg_awareness"]  = self.list_aggregation_awareness(dataset_id)
        return ds

    # ── Federation Executions ─────────────────────────────────────────────────

    def create_federation_execution(self, *, execution_id: str, dataset_id: int,
                                    merged_dataset_id: Optional[int] = None,
                                    sql_generated: str = "", column_ids: list = None,
                                    filters: list = None, condition_ids: list = None,
                                    executed_by: str = "") -> Dict[str, Any]:
        with self.get_session() as session:
            fe = FederationExecution(
                execution_id=execution_id, dataset_id=dataset_id,
                merged_dataset_id=merged_dataset_id, sql_generated=sql_generated,
                column_ids=column_ids or [], filters=filters or [],
                condition_ids=condition_ids or [], status="running",
                executed_by=executed_by,
            )
            session.add(fe)
            session.flush()
            return fe.to_dict()

    def update_federation_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return None
            for k, v in kwargs.items():
                if hasattr(fe, k):
                    setattr(fe, k, v)
            session.flush()
            return fe.to_dict()

    def get_federation_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            return fe.to_dict() if fe else None

    def list_federation_executions(self, dataset_id: Optional[int] = None,
                                    limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(FederationExecution)
            if dataset_id is not None:
                q = q.filter(FederationExecution.dataset_id == dataset_id)
            q = q.order_by(FederationExecution.created_at.desc()).limit(limit)
            return [fe.to_dict() for fe in q.all()]

    def delete_federation_execution(self, execution_id: str) -> bool:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return False
            session.delete(fe)
            return True

    # ── Merged Dimensions ─────────────────────────────────────────────────────

    def create_merged_dimension(self, *, primary_dataset_id: int,
                                secondary_dataset_id: int, name: str,
                                merge_keys: list, merge_type: str = "inner",
                                is_active: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            md = MergedDimension(
                primary_dataset_id=primary_dataset_id,
                secondary_dataset_id=secondary_dataset_id,
                name=name, merge_keys=merge_keys, merge_type=merge_type,
                is_active=is_active,
            )
            session.add(md)
            session.flush()
            return md.to_dict()

    def list_merged_dimensions(self, dataset_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(MergedDimension)
            if dataset_id is not None:
                q = q.filter(
                    (MergedDimension.primary_dataset_id == dataset_id) |
                    (MergedDimension.secondary_dataset_id == dataset_id)
                )
            return [md.to_dict() for md in q.all()]

    def get_merged_dimension(self, md_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            return md.to_dict() if md else None

    def update_merged_dimension(self, md_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return None
            for k, v in kwargs.items():
                if hasattr(md, k):
                    setattr(md, k, v)
            session.flush()
            return md.to_dict()

    def delete_merged_dimension(self, md_id: int) -> bool:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return False
            session.delete(md)
            return True

    # ── AggCacheEntry CRUD ────────────────────────────────────────────

    def list_agg_cache_entries(self, dataset_id: int = None,
                               status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheEntry.status == status)
            return [e.to_dict() for e in q.order_by(AggCacheEntry.id).all()]

    def get_agg_cache_entry(self, entry_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            return e.to_dict() if e else None

    def create_agg_cache_entry(self, *, dataset_id: int, name: str,
                                description: str = "",
                                dimension_col_ids: list = None,
                                measure_col_ids: list = None,
                                grain_label: str = "custom",
                                condition_ids: list = None,
                                schedule_config: dict = None,
                                is_enabled: bool = True,
                                incremental_enabled: bool = False,
                                incremental_column: str = None,
                                created_by: str = "admin") -> Dict[str, Any]:
        with self.get_session() as session:
            entry = AggCacheEntry(
                dataset_id=dataset_id,
                name=name,
                description=description,
                dimension_col_ids=dimension_col_ids or [],
                measure_col_ids=measure_col_ids or [],
                grain_label=grain_label,
                condition_ids=condition_ids or [],
                schedule_config=schedule_config,
                is_enabled=is_enabled,
                incremental_enabled=incremental_enabled,
                incremental_column=incremental_column,
                created_by=created_by,
            )
            session.add(entry)
            session.flush()
            return entry.to_dict()

    def update_agg_cache_entry(self, entry_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return None
            for k, v in kwargs.items():
                if hasattr(entry, k):
                    setattr(entry, k, v)
            session.flush()
            return entry.to_dict()

    def delete_agg_cache_entry(self, entry_id: int) -> bool:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return False
            session.delete(entry)
            return True

    def increment_agg_cache_hit(self, entry_id: int) -> None:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if entry:
                entry.hit_count = (entry.hit_count or 0) + 1
                entry.last_served_at = datetime.now(timezone.utc)

    def increment_agg_cache_miss(self, entry_id: int) -> None:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if entry:
                entry.miss_count = (entry.miss_count or 0) + 1

    def get_agg_cache_stats(self, dataset_id: int = None) -> Dict[str, Any]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            entries = q.all()
            total_hits = sum(e.hit_count or 0 for e in entries)
            total_misses = sum(e.miss_count or 0 for e in entries)
            total_size = sum(e.file_size_bytes or 0 for e in entries)
            by_status: Dict[str, int] = {}
            ds_ids = set()
            for e in entries:
                by_status[e.status] = by_status.get(e.status, 0) + 1
                ds_ids.add(e.dataset_id)
            total_requests = total_hits + total_misses
            suggestions_q = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.status == "pending")
            if dataset_id is not None:
                suggestions_q = suggestions_q.filter(
                    AggCacheSuggestion.dataset_id == dataset_id)
            return {
                "total_entries": len(entries),
                "entries_by_status": by_status,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2) if total_size else 0,
                "total_hits": total_hits,
                "total_misses": total_misses,
                "hit_rate_percent": round(total_hits / total_requests * 100, 1) if total_requests else 0,
                "datasets_cached": len(ds_ids),
                "suggestions_pending": suggestions_q.count(),
            }

    # ── AggCacheSuggestion CRUD ───────────────────────────────────────

    def list_agg_cache_suggestions(self, dataset_id: int = None,
                                    status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheSuggestion)
            if dataset_id is not None:
                q = q.filter(AggCacheSuggestion.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheSuggestion.status == status)
            return [s.to_dict() for s in q.order_by(AggCacheSuggestion.id.desc()).all()]

    def create_agg_cache_suggestion(self, *, dataset_id: int,
                                     dimension_col_ids: list,
                                     measure_col_ids: list,
                                     query_count: int,
                                     estimated_speedup: float = 0.0) -> Dict[str, Any]:
        with self.get_session() as session:
            s = AggCacheSuggestion(
                dataset_id=dataset_id,
                dimension_col_ids=dimension_col_ids,
                measure_col_ids=measure_col_ids,
                query_count=query_count,
                estimated_speedup=estimated_speedup,
            )
            session.add(s)
            session.flush()
            return s.to_dict()

    def update_agg_cache_suggestion(self, suggestion_id: int,
                                     **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return None
            for k, v in kwargs.items():
                if hasattr(s, k):
                    setattr(s, k, v)
            session.flush()
            return s.to_dict()

    def delete_agg_cache_suggestion(self, suggestion_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return False
            session.delete(s)
            return True
