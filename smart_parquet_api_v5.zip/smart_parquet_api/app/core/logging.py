# ============================================================
# app/core/logging.py — Structured logging (structlog)
# ============================================================
import logging
import sys
import structlog
from app.core.settings import settings


def setup_logging() -> None:
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer() if not settings.debug
            else structlog.dev.ConsoleRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
    )

    # Silence noisy libs
    for lib in ("uvicorn.access", "boto3", "botocore", "s3transfer"):
        logging.getLogger(lib).setLevel(logging.WARNING)


logger = structlog.get_logger()
