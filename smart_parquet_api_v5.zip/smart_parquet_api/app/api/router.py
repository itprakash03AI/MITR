# ============================================================
# app/api/router.py — Dynamic endpoint generation from registry
# ============================================================
"""
For each EndpointSpec in the registry we programmatically create
a FastAPI route so that queries.yaml drives the API surface.

GET  endpoints get query params auto-generated from ParamSpec.
POST endpoints accept a QueryRequest body.
"""
import inspect
import re
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
import json
import structlog

from app.core.config_loader import EndpointSpec, ParamSpec, registry
from app.core.database import DuckDBPool, get_db_pool
from app.core.query_executor import QueryExecutor, result_cache
from app.core.settings import settings
from app.api.models import (
    ExplainResponse,
    QueryRequest,
)

logger = structlog.get_logger()


# ── SQL safety guard ─────────────────────────────────────────────────────────

def _validate_sql(sql: str) -> None:
    """
    Lightweight guard for the generic endpoint.
    Only allows SELECT / WITH / EXPLAIN statements.
    Blocks DDL, DML, file writes, shell calls.
    """
    if not settings.generic_endpoint_enabled:
        raise HTTPException(status_code=403, detail="Generic query endpoint is disabled")

    stripped = sql.strip().upper()
    allowed = [p.strip().upper() for p in settings.generic_endpoint_allowed_prefixes.split(",")]

    if not any(stripped.startswith(p) for p in allowed):
        raise HTTPException(
            status_code=400,
            detail=f"Only {allowed} statements are permitted in the generic endpoint",
        )

    # Block obvious dangerous patterns
    danger_patterns = [
        r"\bCOPY\b", r"\bEXPORT\b", r"\bINSTALL\b", r"\bLOAD\b",
        r"\bCREATE\b", r"\bDROP\b", r"\bINSERT\b", r"\bUPDATE\b",
        r"\bDELETE\b", r"\bALTER\b", r"\bATTACH\b", r"\bDETACH\b",
        r"shell\s*\(", r"read_text\s*\(",
    ]
    for pattern in danger_patterns:
        if re.search(pattern, stripped):
            raise HTTPException(
                status_code=400,
                detail=f"Statement contains a disallowed keyword: {pattern}",
            )


# ── Admin / meta router ──────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/api/admin", tags=["⚙️ Admin"])


@admin_router.get("/health", summary="Health check")
async def health(pool: DuckDBPool = Depends(get_db_pool)):
    try:
        import strawberry  # noqa
        graphql_ok = True
    except ImportError:
        graphql_ok = False
    try:
        import pyiceberg  # noqa
        iceberg_ok = True
    except ImportError:
        iceberg_ok = False
    return {
        "status": "ok",
        "version": settings.app_version,
        "pool_size": settings.duckdb_threads,
        "cache_entries": result_cache.size,
        "features": {
            "s3":       settings.s3_enabled,
            "iceberg":  settings.iceberg_enabled and iceberg_ok,
            "graphql":  graphql_ok,
            "generic_sql": settings.generic_endpoint_enabled,
        },
        "optional_packages": {
            "pyiceberg":          iceberg_ok,
            "strawberry-graphql": graphql_ok,
        },
    }


@admin_router.get("/endpoints", summary="List all registered config-driven endpoints")
async def list_endpoints():
    eps = registry.all()
    return {
        "total": len(eps),
        "endpoints": [
            {
                "id": ep.id,
                "path": f"/api/query{ep.path}",
                "method": ep.method,
                "tags": ep.tags,
                "summary": ep.summary,
                "parameters": [
                    {
                        "name": p.name,
                        "type": p.param_type,
                        "required": p.required,
                        "default": p.default,
                    }
                    for p in ep.parameters
                ],
                "sources": {
                    k: {"type": v.source_type, "path": v.resolved_path}
                    for k, v in ep.sources.items()
                },
            }
            for ep in eps
        ],
    }


@admin_router.delete("/cache", summary="Clear result cache")
async def clear_cache():
    result_cache.clear()
    return {"message": "Cache cleared", "entries": 0}


@admin_router.get("/cache", summary="Cache statistics")
async def cache_stats():
    return {"entries": result_cache.size}


# ── Generic ad-hoc query endpoint ────────────────────────────────────────────
generic_router = APIRouter(prefix="/api/execute", tags=["🔍 Generic SQL Executor"])


@generic_router.post(
    "/sql",
    summary="Execute any SQL on Parquet / Iceberg",
    description="""
## Generic SQL Executor

Execute **any SELECT query** directly against Parquet files or Iceberg tables
using DuckDB syntax.  Useful for ad-hoc analysis, debugging, and exploration.

### Reading Parquet files

```sql
-- Local file
SELECT account_type, COUNT(*) AS cnt
FROM read_parquet('/app/data/tb_accounts.parquet')
GROUP BY account_type

-- S3 file
SELECT *
FROM read_parquet('s3://my-bucket/warehouse/tb_transactions.parquet')
WHERE fiscal_year = 2024
LIMIT 100

-- Glob pattern (multiple partitions)
SELECT *
FROM read_parquet('s3://my-bucket/data/year=2024/**/*.parquet')
LIMIT 500

-- Join two files inline
SELECT a.account_name, SUM(t.debit_amount) AS total_debits
FROM read_parquet('/app/data/tb_accounts.parquet')      AS a
JOIN read_parquet('/app/data/tb_transactions.parquet')  AS t
  ON a.account_id = t.account_id
GROUP BY a.account_name
ORDER BY total_debits DESC
LIMIT 20
```

### Reading Iceberg tables (requires ICEBERG_ENABLED=true)

```sql
-- DuckDB iceberg extension (direct Parquet files from snapshot)
SELECT account_id, SUM(debit_amount)
FROM read_parquet(['s3://warehouse/tb/data/snap1.parquet',
                   's3://warehouse/tb/data/snap2.parquet'], union_by_name=true)
GROUP BY account_id
```

### Security
Only `SELECT`, `WITH`, and `EXPLAIN` statements are allowed.
DDL, DML, file writes, and shell access are blocked.
""",
)
async def execute_sql(
    sql: str = Body(
        ...,
        media_type="text/plain",
        openapi_examples={
            "simple_count": {
                "summary": "Count rows in accounts",
                "value": "SELECT account_type, COUNT(*) AS cnt FROM read_parquet('data/tb_accounts.parquet') GROUP BY account_type ORDER BY cnt DESC",
            },
            "join_query": {
                "summary": "Join accounts + transactions",
                "value": "SELECT a.account_name, a.account_type, SUM(t.debit_amount) AS total_debits, SUM(t.credit_amount) AS total_credits FROM read_parquet('data/tb_accounts.parquet') AS a JOIN read_parquet('data/tb_transactions.parquet') AS t ON a.account_id = t.account_id WHERE t.fiscal_year = 2024 GROUP BY a.account_name, a.account_type ORDER BY total_debits DESC LIMIT 20",
            },
            "union_all": {
                "summary": "UNION ALL across two files",
                "value": "SELECT 'ACCOUNTS' AS src, COUNT(*) AS cnt FROM read_parquet('data/tb_accounts.parquet') UNION ALL SELECT 'TRANSACTIONS' AS src, COUNT(*) AS cnt FROM read_parquet('data/tb_transactions.parquet') UNION ALL SELECT 'BALANCES' AS src, COUNT(*) AS cnt FROM read_parquet('data/tb_balances.parquet')",
            },
            "window_function": {
                "summary": "Running balance with window function",
                "value": "SELECT account_id, fiscal_year, period, closing_balance, SUM(closing_balance) OVER (PARTITION BY account_id ORDER BY fiscal_year, period ROWS UNBOUNDED PRECEDING) AS running_total FROM read_parquet('data/tb_balances.parquet') ORDER BY account_id, fiscal_year, period LIMIT 100",
            },
            "schema_inspect": {
                "summary": "Inspect Parquet file schema",
                "value": "DESCRIBE SELECT * FROM read_parquet('data/tb_accounts.parquet')",
            },
            "explain_plan": {
                "summary": "Query execution plan",
                "value": "EXPLAIN SELECT a.account_id, SUM(t.debit_amount) FROM read_parquet('data/tb_accounts.parquet') a JOIN read_parquet('data/tb_transactions.parquet') t ON a.account_id = t.account_id GROUP BY a.account_id",
            },
        },
        description="DuckDB SQL — SELECT / WITH / EXPLAIN only",
    ),
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(
        default=settings.default_page_size,
        ge=1,
        le=settings.generic_endpoint_max_rows,
        alias="pageSize",
        description=f"Rows per page (max {settings.generic_endpoint_max_rows})",
    ),
    cache: bool = Query(default=False, description="Cache results (default off for ad-hoc)"),
    pool: DuckDBPool = Depends(get_db_pool),
):
    _validate_sql(sql)
    executor = QueryExecutor(pool)
    logger.info("generic_sql_execute", sql_preview=sql[:120])

    try:
        result = await executor.execute(
            sql,
            page=page,
            page_size=page_size,
            cache=cache,
            cache_ttl=60,
        )
    except TimeoutError:
        raise HTTPException(status_code=504, detail="Query timed out")
    except Exception as exc:
        logger.error("generic_sql_failed", error=str(exc))
        raise HTTPException(status_code=400, detail=str(exc))

    return result.to_dict()


@generic_router.post(
    "/sql/stream",
    summary="Stream large result sets as NDJSON",
    description="""
Streams query results as **newline-delimited JSON** (one JSON object per line).
Ideal for exporting large datasets without loading everything into memory.

```bash
curl -X POST http://localhost:8000/api/execute/sql/stream \\
  -H 'Content-Type: text/plain' \\
  -d "SELECT * FROM read_parquet('data/tb_transactions.parquet')" \\
  | head -5
```
""",
)
async def stream_sql(
    sql: str = Body(..., media_type="text/plain", description="SELECT query to stream"),
    pool: DuckDBPool = Depends(get_db_pool),
):
    _validate_sql(sql)
    executor = QueryExecutor(pool)

    async def _gen():
        async for chunk in executor.stream(sql, chunk_size=2000):
            for row in chunk:
                yield json.dumps(row, default=str) + "\n"

    return StreamingResponse(_gen(), media_type="application/x-ndjson")


@generic_router.post(
    "/sql/explain",
    summary="Get DuckDB query execution plan",
    description="Returns the DuckDB logical + physical query plan for the given SQL.",
)
async def explain_sql(
    sql: str = Body(..., media_type="text/plain", description="SQL to explain"),
    pool: DuckDBPool = Depends(get_db_pool),
):
    _validate_sql(sql)
    executor = QueryExecutor(pool)
    plan = await executor.explain(sql)
    return {"plan": plan}


@generic_router.post(
    "/parquet/schema",
    summary="Inspect Parquet file schema",
    description="""
Returns the column names and types of a Parquet file without reading all data.
Works for local paths and `s3://` URIs.

```json
{ "path": "data/tb_accounts.parquet" }
{ "path": "s3://my-bucket/warehouse/tb_transactions.parquet" }
```
""",
)
async def parquet_schema(
    path: str = Body(..., embed=True, description="Path to Parquet file (local or s3://)"),
    pool: DuckDBPool = Depends(get_db_pool),
):
    sql = f"DESCRIBE SELECT * FROM read_parquet('{path.replace(chr(39), '')}')"
    executor = QueryExecutor(pool)
    try:
        result = await executor.execute(sql, page=1, page_size=2000, cache=True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {
        "path": path,
        "columns": result.rows,
        "total_columns": result.total_rows,
    }


@generic_router.post(
    "/parquet/sample",
    summary="Sample rows from a Parquet file",
    description="Returns N sample rows from a Parquet file — useful for exploration.",
)
async def parquet_sample(
    path: str = Body(..., embed=True, description="Path to Parquet file"),
    n: int = Body(default=10, embed=True, ge=1, le=1000, description="Number of rows"),
    pool: DuckDBPool = Depends(get_db_pool),
):
    safe_path = path.replace("'", "")
    sql = f"SELECT * FROM read_parquet('{safe_path}') LIMIT {n}"
    executor = QueryExecutor(pool)
    try:
        result = await executor.execute(sql, page=1, page_size=n, cache=True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return result.to_dict()


# ── Iceberg catalog explorer ──────────────────────────────────────────────────
iceberg_router = APIRouter(prefix="/api/iceberg", tags=["🧊 Iceberg Catalog"])


def _require_iceberg():
    if not settings.iceberg_enabled:
        raise HTTPException(
            status_code=503,
            detail="Iceberg is disabled. Set ICEBERG_ENABLED=true in .env",
        )


@iceberg_router.get(
    "/test-connection",
    summary="Test Iceberg catalog connection step by step",
    description="""
Runs a diagnostic connection test and returns results for every step:

1. Is `pyiceberg` installed?
2. Is the config valid (required env vars present)?
3. Can we reach the catalog (Glue API / S3 metadata)?
4. Can we list namespaces?
5. Can we list tables?

**Use this first when setting up a new connection.**
""",
)
async def test_iceberg_connection():
    _require_iceberg()
    try:
        from app.core.iceberg import test_connection
        return test_connection()
    except Exception as exc:
        return {"success": False, "error": str(exc)}



    summary="List all Iceberg namespaces",
    description="""
Lists all namespaces (databases/schemas) in the configured Iceberg catalog.

Enable Iceberg by setting in `.env`:
```
ICEBERG_ENABLED=true
ICEBERG_CATALOG_TYPE=rest          # rest | glue | hive | hadoop | nessie
ICEBERG_REST_URI=http://localhost:8181
```
""",
)
async def list_namespaces():
    _require_iceberg()
    try:
        from app.core.iceberg import list_iceberg_namespaces
        return {"namespaces": list_iceberg_namespaces()}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@iceberg_router.get(
    "/namespaces/{namespace}/tables",
    summary="List tables in an Iceberg namespace",
)
async def list_tables(namespace: str):
    _require_iceberg()
    try:
        from app.core.iceberg import list_iceberg_tables
        return {"namespace": namespace, "tables": list_iceberg_tables(namespace)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@iceberg_router.get(
    "/namespaces/{namespace}/tables/{table}",
    summary="Describe an Iceberg table",
    description="""
Returns full metadata for the Iceberg table including:
- Schema (column names + types)
- Partition spec
- Current snapshot info
- Number of data files
- Table properties
""",
)
async def describe_table(namespace: str, table: str):
    _require_iceberg()
    try:
        from app.core.iceberg import describe_iceberg_table
        return describe_iceberg_table(namespace, table)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@iceberg_router.post(
    "/query",
    summary="Execute SQL on an Iceberg table",
    description="""
## Query Iceberg Tables via DuckDB

Resolves the Iceberg table's current snapshot → extracts Parquet data file
paths → hands them to DuckDB for vectorised execution.

**No Spark. No JVM. Pure DuckDB + PyIceberg.**

### Request body

```json
{
  "namespace": "finance",
  "table": "trial_balance_transactions",
  "sql": "SELECT account_id, SUM(debit_amount) AS total FROM {table} GROUP BY account_id ORDER BY total DESC LIMIT 20",
  "snapshot_id": null,
  "page": 1,
  "page_size": 1000
}
```

The `{table}` placeholder in the SQL is automatically replaced with the
DuckDB `read_parquet([...])` expression for the current (or specified) snapshot.

### Example — cross-Iceberg-table JOIN

```json
{
  "namespace": "finance",
  "table": "tb_transactions",
  "sql": "SELECT t.account_id, a.account_name, SUM(t.debit_amount) FROM {table} t JOIN read_parquet('/data/tb_accounts.parquet') a ON t.account_id = a.account_id GROUP BY 1,2",
  "page": 1,
  "page_size": 500
}
```
""",
)
async def query_iceberg(
    namespace: str = Body(..., embed=True, description="Iceberg namespace (e.g. finance)"),
    table: str     = Body(..., embed=True, description="Table name"),
    sql: str       = Body(
        ..., embed=True,
        description="SQL query — use {table} as placeholder for the Iceberg table expression",
        openapi_examples={
            "simple": {
                "summary": "SELECT from Iceberg table",
                "value": "SELECT * FROM {table} LIMIT 100",
            },
            "aggregate": {
                "summary": "Aggregation on Iceberg table",
                "value": "SELECT account_type, COUNT(*) AS cnt, SUM(debit_amount) AS total FROM {table} GROUP BY account_type ORDER BY total DESC",
            },
        },
    ),
    snapshot_id: Optional[int] = Body(
        default=None, embed=True,
        description="Pin to a specific snapshot ID (leave null for current snapshot)",
    ),
    page: int      = Body(default=1, embed=True, ge=1),
    page_size: int = Body(default=settings.default_page_size, embed=True,
                          ge=1, le=settings.max_page_size),
    pool: DuckDBPool = Depends(get_db_pool),
):
    _require_iceberg()
    _validate_sql(sql)

    try:
        from app.core.iceberg import IcebergTableResolver
        table_expr = IcebergTableResolver.build_duckdb_sql(namespace, table, "t", snapshot_id)
    except Exception as exc:
        raise HTTPException(status_code=404, detail=f"Failed to resolve Iceberg table: {exc}")

    # Replace {table} placeholder in user SQL
    rendered_sql = sql.replace("{table}", table_expr)

    executor = QueryExecutor(pool)
    logger.info("iceberg_query", namespace=namespace, table=table, sql_preview=sql[:100])

    try:
        result = await executor.execute(
            rendered_sql,
            page=page,
            page_size=page_size,
            cache=True,
        )
    except TimeoutError:
        raise HTTPException(status_code=504, detail="Query timed out")
    except Exception as exc:
        logger.error("iceberg_query_failed", error=str(exc))
        raise HTTPException(status_code=400, detail=str(exc))

    return {
        **result.to_dict(),
        "iceberg": {
            "namespace": namespace,
            "table": table,
            "snapshot_id": snapshot_id or "latest",
        },
    }


@iceberg_router.get(
    "/namespaces/{namespace}/tables/{table}/snapshots",
    summary="List all snapshots for an Iceberg table",
    description="Returns the snapshot history — useful for time travel queries.",
)
async def list_snapshots(namespace: str, table: str):
    _require_iceberg()
    try:
        from app.core.iceberg import get_iceberg_catalog
        catalog = get_iceberg_catalog()
        tbl = catalog.load_table(f"{namespace}.{table}")
        snaps = []
        for snap in (tbl.metadata.snapshots or []):
            snaps.append({
                "snapshot_id":   snap.snapshot_id,
                "timestamp_ms":  snap.timestamp_ms,
                "operation":     snap.summary.operation if snap.summary else None,
                "parent_id":     snap.parent_snapshot_id,
            })
        return {
            "table": f"{namespace}.{table}",
            "current_snapshot_id": tbl.current_snapshot().snapshot_id if tbl.current_snapshot() else None,
            "snapshots": sorted(snaps, key=lambda s: s["timestamp_ms"], reverse=True),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── Dynamic query router ──────────────────────────────────────────────────────
query_router = APIRouter(prefix="/api/query", tags=["📋 Config-Driven Queries"])


def _build_handler(ep: EndpointSpec):
    """
    Factory: returns a FastAPI handler function tailored for `ep`.
    Dynamically builds the signature so FastAPI generates proper query params.
    """

    async def _handler(
        request: Request,
        page: int = Query(default=1, ge=1, description="Page number"),
        page_size: int = Query(
            default=settings.default_page_size,
            ge=1,
            le=settings.max_page_size,
            alias="pageSize",
            description="Rows per page",
        ),
        cache: bool = Query(default=ep.cache, description="Use cache"),
        explain: bool = Query(default=False, description="Return query plan"),
        pool: DuckDBPool = Depends(get_db_pool),
        **user_params,
    ):
        executor = QueryExecutor(pool)
        param_values: Dict[str, Any] = dict(user_params)

        try:
            sql = ep.render_query(param_values)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))

        logger.info("request_received", endpoint=ep.id, page=page, page_size=page_size)

        if explain:
            plan = await executor.explain(sql)
            return {"query_id": ep.id, "plan": plan}

        if ep.stream:
            async def _stream_gen():
                async for chunk in executor.stream(sql):
                    for row in chunk:
                        yield json.dumps(row, default=str) + "\n"
            return StreamingResponse(_stream_gen(), media_type="application/x-ndjson")

        try:
            result = await executor.execute(
                sql,
                page=page,
                page_size=page_size,
                cache=cache,
                cache_ttl=ep.cache_ttl,
            )
        except TimeoutError:
            raise HTTPException(status_code=504, detail="Query timed out")
        except Exception as exc:
            logger.error("query_failed", endpoint=ep.id, error=str(exc))
            raise HTTPException(status_code=500, detail=str(exc))

        return result.to_dict()

    # Inject per-endpoint query params into function signature for OpenAPI
    existing_params = list(inspect.signature(_handler).parameters.values())
    ep_params = []
    for p_spec in ep.parameters:
        default = Query(
            default=p_spec.default if not p_spec.required else ...,
            description=p_spec.description,
            **({"enum": p_spec.enum} if p_spec.enum else {}),
        )
        ep_params.append(
            inspect.Parameter(
                name=p_spec.name,
                kind=inspect.Parameter.KEYWORD_ONLY,
                default=default,
                annotation=Optional[p_spec.python_type] if not p_spec.required else p_spec.python_type,
            )
        )

    new_params = existing_params[:-1] + ep_params + [existing_params[-1]]
    _handler.__signature__ = inspect.Signature(new_params)
    _handler.__name__ = f"endpoint_{ep.id}"
    _handler.__doc__ = ep.description or ep.summary

    return _handler


def register_all_endpoints(app_router: APIRouter) -> None:
    for ep in registry.all():
        handler = _build_handler(ep)
        app_router.add_api_route(
            path=ep.path,
            endpoint=handler,
            methods=[ep.method],
            summary=ep.summary,
            description=ep.description,
            tags=ep.tags,
            response_model=None,
        )
        logger.info("route_mounted", method=ep.method, path=f"/api/query{ep.path}")
