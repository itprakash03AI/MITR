# ============================================================
# app/api/models.py — Request & Response Pydantic schemas
# ============================================================
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, model_validator
from app.core.settings import settings


# ── Request ──────────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    """POST body for ad-hoc queries (optional advanced usage)."""
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Named query parameters")
    page: int = Field(default=1, ge=1, description="Page number (1-indexed)")
    page_size: int = Field(
        default=settings.default_page_size,
        ge=1,
        le=settings.max_page_size,
        description="Rows per page",
    )
    cache: bool = Field(default=True, description="Use cached result if available")
    explain: bool = Field(default=False, description="Return query plan instead of data")


# ── Response ─────────────────────────────────────────────────────────────────

class QueryMeta(BaseModel):
    query_id: str
    columns: List[str]
    total_rows: int
    page: int
    page_size: int
    total_pages: int
    execution_ms: float
    cached: bool


class QueryResponse(BaseModel):
    meta: QueryMeta
    data: List[Dict[str, Any]]


class ExplainResponse(BaseModel):
    query_id: str
    plan: str


class HealthResponse(BaseModel):
    status: str
    version: str
    pool_size: int
    cache_entries: int
    s3_enabled: bool


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    query_id: Optional[str] = None


class CacheStatsResponse(BaseModel):
    entries: int
    message: str


class EndpointInfo(BaseModel):
    id: str
    path: str
    method: str
    tags: List[str]
    summary: str
    description: str
    sources: Dict[str, Dict[str, str]]
    parameters: List[Dict[str, Any]]
    pagination: bool
    cache: bool


class RegistryResponse(BaseModel):
    total: int
    endpoints: List[EndpointInfo]
