# ============================================================
# app/api/graphql_schema.py — Strawberry GraphQL schema
# ============================================================
"""
GraphQL layer on top of DuckDB + Parquet.

Why GraphQL here?
  - Clients select EXACTLY which columns they want from 1000-column tables
  - Nested queries replace N separate REST calls
  - Single endpoint, self-documenting schema
  - Perfect for front-end teams who don't know SQL

Architecture:
  GraphQL query → resolver → DuckDB SQL → Parquet files
  The resolver translates GraphQL field selections into SELECT col1, col2
  so DuckDB only reads what's needed.
"""
from __future__ import annotations

import textwrap
from typing import Annotated, AsyncGenerator, List, Optional

import strawberry
from strawberry.fastapi import GraphQLRouter
from strawberry.scalars import JSON
from strawberry.types import Info
import structlog

from app.core.database import get_db_pool
from app.core.query_executor import QueryExecutor
from app.core.settings import settings

logger = structlog.get_logger()

# ── Scalar helpers ────────────────────────────────────────────────────────────
Float = float
Int   = int


# ═══════════════════════════════════════════════════════════════════════════
# GraphQL Types
# ═══════════════════════════════════════════════════════════════════════════

@strawberry.type(description="Chart of Accounts master record")
class Account:
    account_id:          str
    account_code:        str
    account_name:        str
    account_type:        str
    account_subtype:     Optional[str]
    currency:            Optional[str]
    entity:              Optional[str]
    cost_centre:         Optional[str]
    segment:             Optional[str]
    ledger:              Optional[str]
    is_active:           Optional[bool]
    is_control_account:  Optional[bool]
    hierarchy_level:     Optional[int]
    ifrs_classification: Optional[str]
    gaap_classification: Optional[str]
    tax_code:            Optional[str]
    intercompany_flag:   Optional[bool]


@strawberry.type(description="Journal entry / transaction line")
class Transaction:
    transaction_id:   str
    account_id:       str
    journal_id:       Optional[str]
    posting_date:     Optional[str]
    fiscal_year:      Optional[int]
    period:           Optional[int]
    source_system:    Optional[str]
    transaction_type: Optional[str]
    status:           Optional[str]
    entity:           Optional[str]
    currency:         Optional[str]
    exchange_rate:    Optional[float]
    debit_amount:     Optional[float]
    credit_amount:    Optional[float]
    net_movement:     Optional[float]
    description:      Optional[str]
    reference:        Optional[str]


@strawberry.type(description="Period-end balance snapshot")
class Balance:
    balance_id:       str
    account_id:       str
    fiscal_year:      Optional[int]
    period:           Optional[int]
    entity:           Optional[str]
    currency:         Optional[str]
    ledger:           Optional[str]
    segment:          Optional[str]
    opening_balance:  Optional[float]
    period_debits:    Optional[float]
    period_credits:   Optional[float]
    closing_balance:  Optional[float]
    ytd_debits:       Optional[float]
    ytd_credits:      Optional[float]
    budget_amount:    Optional[float]
    variance:         Optional[float]
    variance_pct:     Optional[float]
    is_reconciled:    Optional[bool]
    last_reconciled:  Optional[str]


@strawberry.type(description="Account with its transactions and balances (nested)")
class AccountWithDetail:
    account:      Account
    transactions: List[Transaction]
    balances:     List[Balance]
    summary: Optional["AccountSummary"]


@strawberry.type(description="Aggregated account summary")
class AccountSummary:
    account_id:       str
    account_type:     str
    total_debits:     float
    total_credits:    float
    net_movement:     float
    avg_balance:      float
    closing_balance:  float
    budget_variance:  float
    txn_count:        int


@strawberry.type(description="Trial balance row (joined view)")
class TrialBalanceRow:
    account_id:        str
    account_code:      str
    account_name:      str
    account_type:      str
    entity:            Optional[str]
    fiscal_year:       Optional[int]
    period:            Optional[int]
    currency:          Optional[str]
    opening_balance:   Optional[float]
    total_debits:      Optional[float]
    total_credits:     Optional[float]
    closing_balance:   Optional[float]
    budget_amount:     Optional[float]
    variance:          Optional[float]
    variance_pct:      Optional[float]
    is_reconciled:     Optional[bool]
    txn_count:         Optional[int]


@strawberry.type(description="P&L summary row")
class PLRow:
    entity:        str
    fiscal_year:   int
    period:        int
    currency:      str
    account_type:  str
    total_revenue: float
    total_expense: float
    net_pl:        float
    budget_total:  float
    variance:      float


@strawberry.type(description="Generic paginated result")
class PageInfo:
    total_rows:  int
    page:        int
    page_size:   int
    total_pages: int
    execution_ms: float


@strawberry.type
class AccountsPage:
    page_info: PageInfo
    items:     List[Account]


@strawberry.type
class TransactionsPage:
    page_info: PageInfo
    items:     List[Transaction]


@strawberry.type
class TrialBalancePage:
    page_info: PageInfo
    items:     List[TrialBalanceRow]


# ── Input types ───────────────────────────────────────────────────────────────

@strawberry.input(description="Filter options for accounts")
class AccountFilter:
    account_type:    Optional[str] = strawberry.UNSET
    entity:          Optional[str] = strawberry.UNSET
    is_active:       Optional[bool] = strawberry.UNSET
    cost_centre:     Optional[str] = strawberry.UNSET
    currency:        Optional[str] = strawberry.UNSET
    search:          Optional[str] = strawberry.UNSET   # searches name + code


@strawberry.input(description="Filter options for transactions")
class TransactionFilter:
    account_id:       Optional[str] = strawberry.UNSET
    fiscal_year:      Optional[int] = strawberry.UNSET
    period:           Optional[int] = strawberry.UNSET
    entity:           Optional[str] = strawberry.UNSET
    currency:         Optional[str] = strawberry.UNSET
    transaction_type: Optional[str] = strawberry.UNSET
    status:           Optional[str] = strawberry.UNSET
    source_system:    Optional[str] = strawberry.UNSET
    min_debit:        Optional[float] = strawberry.UNSET
    max_debit:        Optional[float] = strawberry.UNSET


@strawberry.input(description="Filter for trial balance / balance queries")
class BalanceFilter:
    fiscal_year:   Optional[int] = strawberry.UNSET
    period:        Optional[int] = strawberry.UNSET
    entity:        Optional[str] = strawberry.UNSET
    currency:      Optional[str] = strawberry.UNSET
    ledger:        Optional[str] = strawberry.UNSET
    is_reconciled: Optional[bool] = strawberry.UNSET


# ── DuckDB paths (used in SQL) ────────────────────────────────────────────────
from pathlib import Path as _Path
_DATA = _Path(settings.local_data_dir)
_A = str(_DATA / "tb_accounts.parquet")
_T = str(_DATA / "tb_transactions.parquet")
_B = str(_DATA / "tb_balances.parquet")


# ── Resolver helpers ──────────────────────────────────────────────────────────

def _where(clauses: list[str]) -> str:
    if not clauses:
        return ""
    return "WHERE " + " AND ".join(clauses)


def _like_or_eq(col: str, val: str) -> str:
    """Use LIKE if val contains %, otherwise exact match."""
    if "%" in val:
        return f"{col} LIKE '{val.replace(chr(39), '')}'"
    return f"{col} = '{val.replace(chr(39), '')}'"


def _row_to(cls, row: dict):
    """Map a dict row to a Strawberry type."""
    init = {}
    for field in cls.__dataclass_fields__:
        init[field] = row.get(field)
    return cls(**init)


async def _exec(info: Info, sql: str, page=1, page_size=1000):
    pool = get_db_pool()
    executor = QueryExecutor(pool)
    return await executor.execute(sql, page=page, page_size=page_size)


# ═══════════════════════════════════════════════════════════════════════════
# Resolvers — Query
# ═══════════════════════════════════════════════════════════════════════════

@strawberry.type
class Query:

    # ── Accounts ──────────────────────────────────────────────────────────

    @strawberry.field(description="Fetch a list of accounts with optional filters")
    async def accounts(
        self,
        info: Info,
        filter: Optional[AccountFilter] = None,
        page: int = 1,
        page_size: int = 100,
    ) -> AccountsPage:
        where = []
        if filter:
            if filter.account_type is not strawberry.UNSET and filter.account_type:
                where.append(_like_or_eq("account_type", filter.account_type))
            if filter.entity is not strawberry.UNSET and filter.entity:
                where.append(_like_or_eq("entity", filter.entity))
            if filter.is_active is not strawberry.UNSET and filter.is_active is not None:
                where.append(f"is_active = {'true' if filter.is_active else 'false'}")
            if filter.cost_centre is not strawberry.UNSET and filter.cost_centre:
                where.append(_like_or_eq("cost_centre", filter.cost_centre))
            if filter.currency is not strawberry.UNSET and filter.currency:
                where.append(_like_or_eq("currency", filter.currency))
            if filter.search is not strawberry.UNSET and filter.search:
                s = filter.search.replace("'", "")
                where.append(f"(account_name ILIKE '%{s}%' OR account_code ILIKE '%{s}%')")

        # Column pushdown — only fetch what the GraphQL client asked for
        requested = _get_selected_fields(info, "items")
        all_cols = [
            "account_id", "account_code", "account_name", "account_type",
            "account_subtype", "currency", "entity", "cost_centre", "segment",
            "ledger", "is_active", "is_control_account", "hierarchy_level",
            "ifrs_classification", "gaap_classification", "tax_code", "intercompany_flag",
        ]
        cols = [c for c in all_cols if c in requested] or all_cols

        sql = f"""
            SELECT {', '.join(cols)}
            FROM read_parquet('{_A}')
            {_where(where)}
            ORDER BY account_code
        """
        result = await _exec(info, sql, page, page_size)
        items = [
            Account(**{c: row.get(c) for c in all_cols})
            for row in result.rows
        ]
        return AccountsPage(
            page_info=PageInfo(
                total_rows=result.total_rows, page=result.page,
                page_size=result.page_size,
                total_pages=max(1, (result.total_rows + result.page_size - 1) // result.page_size),
                execution_ms=result.execution_ms,
            ),
            items=items,
        )

    @strawberry.field(description="Fetch a single account by ID")
    async def account(self, info: Info, account_id: str) -> Optional[Account]:
        sql = f"SELECT * FROM read_parquet('{_A}') WHERE account_id = '{account_id.replace(chr(39), '')}' LIMIT 1"
        result = await _exec(info, sql)
        if not result.rows:
            return None
        row = result.rows[0]
        return Account(**{f: row.get(f) for f in Account.__dataclass_fields__})

    # ── Transactions ───────────────────────────────────────────────────────

    @strawberry.field(description="Fetch transactions with rich filtering")
    async def transactions(
        self,
        info: Info,
        filter: Optional[TransactionFilter] = None,
        page: int = 1,
        page_size: int = 500,
    ) -> TransactionsPage:
        where = []
        if filter:
            if filter.account_id is not strawberry.UNSET and filter.account_id:
                where.append(f"account_id = '{filter.account_id.replace(chr(39), '')}'")
            if filter.fiscal_year is not strawberry.UNSET and filter.fiscal_year:
                where.append(f"fiscal_year = {int(filter.fiscal_year)}")
            if filter.period is not strawberry.UNSET and filter.period:
                where.append(f"period = {int(filter.period)}")
            if filter.entity is not strawberry.UNSET and filter.entity:
                where.append(_like_or_eq("entity", filter.entity))
            if filter.currency is not strawberry.UNSET and filter.currency:
                where.append(_like_or_eq("currency", filter.currency))
            if filter.transaction_type is not strawberry.UNSET and filter.transaction_type:
                where.append(_like_or_eq("transaction_type", filter.transaction_type))
            if filter.status is not strawberry.UNSET and filter.status:
                where.append(_like_or_eq("status", filter.status))
            if filter.source_system is not strawberry.UNSET and filter.source_system:
                where.append(_like_or_eq("source_system", filter.source_system))
            if filter.min_debit is not strawberry.UNSET and filter.min_debit is not None:
                where.append(f"debit_amount >= {float(filter.min_debit)}")
            if filter.max_debit is not strawberry.UNSET and filter.max_debit is not None:
                where.append(f"debit_amount <= {float(filter.max_debit)}")

        sql = f"""
            SELECT
                transaction_id, account_id, journal_id,
                posting_date::VARCHAR AS posting_date, fiscal_year, period,
                source_system, transaction_type, status, entity, currency,
                exchange_rate, debit_amount, credit_amount,
                (debit_amount - credit_amount) AS net_movement,
                description, reference
            FROM read_parquet('{_T}')
            {_where(where)}
            ORDER BY posting_date DESC, debit_amount DESC
        """
        result = await _exec(info, sql, page, page_size)
        fields = list(Transaction.__dataclass_fields__.keys())
        items = [Transaction(**{f: row.get(f) for f in fields}) for row in result.rows]
        return TransactionsPage(
            page_info=PageInfo(
                total_rows=result.total_rows, page=result.page,
                page_size=result.page_size,
                total_pages=max(1, (result.total_rows + result.page_size - 1) // result.page_size),
                execution_ms=result.execution_ms,
            ),
            items=items,
        )

    # ── Trial Balance ──────────────────────────────────────────────────────

    @strawberry.field(description="""
    Full trial balance — aggregated per account/entity/period.
    Joins accounts + transactions + balances in a single DuckDB query.
    """)
    async def trial_balance(
        self,
        info: Info,
        filter: Optional[BalanceFilter] = None,
        page: int = 1,
        page_size: int = 500,
    ) -> TrialBalancePage:
        where = []
        if filter:
            if filter.fiscal_year is not strawberry.UNSET and filter.fiscal_year:
                where.append(f"b.fiscal_year = {int(filter.fiscal_year)}")
            if filter.period is not strawberry.UNSET and filter.period:
                where.append(f"b.period = {int(filter.period)}")
            if filter.entity is not strawberry.UNSET and filter.entity:
                where.append(_like_or_eq("b.entity", filter.entity))
            if filter.currency is not strawberry.UNSET and filter.currency:
                where.append(_like_or_eq("b.currency", filter.currency))
            if filter.ledger is not strawberry.UNSET and filter.ledger:
                where.append(_like_or_eq("b.ledger", filter.ledger))
            if filter.is_reconciled is not strawberry.UNSET and filter.is_reconciled is not None:
                where.append(f"b.is_reconciled = {'true' if filter.is_reconciled else 'false'}")

        sql = f"""
            SELECT
                a.account_id,
                a.account_code,
                a.account_name,
                a.account_type,
                b.entity,
                b.fiscal_year,
                b.period,
                b.currency,
                b.opening_balance,
                SUM(t.debit_amount)   AS total_debits,
                SUM(t.credit_amount)  AS total_credits,
                b.closing_balance,
                b.budget_amount,
                b.variance,
                b.variance_pct,
                b.is_reconciled,
                COUNT(t.transaction_id) AS txn_count
            FROM read_parquet('{_B}') b
            JOIN read_parquet('{_A}') a ON b.account_id = a.account_id
            LEFT JOIN read_parquet('{_T}') t
                ON b.account_id  = t.account_id
               AND b.fiscal_year = t.fiscal_year
               AND b.period      = t.period
            {_where(where)}
            GROUP BY
                a.account_id, a.account_code, a.account_name, a.account_type,
                b.entity, b.fiscal_year, b.period, b.currency,
                b.opening_balance, b.closing_balance, b.budget_amount,
                b.variance, b.variance_pct, b.is_reconciled
            ORDER BY a.account_code, b.entity, b.period
        """
        result = await _exec(info, sql, page, page_size)
        fields = list(TrialBalanceRow.__dataclass_fields__.keys())
        items = [TrialBalanceRow(**{f: row.get(f) for f in fields}) for row in result.rows]
        return TrialBalancePage(
            page_info=PageInfo(
                total_rows=result.total_rows, page=result.page,
                page_size=result.page_size,
                total_pages=max(1, (result.total_rows + result.page_size - 1) // result.page_size),
                execution_ms=result.execution_ms,
            ),
            items=items,
        )

    @strawberry.field(description="Nested account with full transaction + balance history")
    async def account_with_detail(
        self,
        info: Info,
        account_id: str,
        fiscal_year: Optional[int] = 2024,
    ) -> Optional[AccountWithDetail]:
        safe_id = account_id.replace("'", "")

        # Fetch account
        acc_sql = f"SELECT * FROM read_parquet('{_A}') WHERE account_id = '{safe_id}' LIMIT 1"
        acc_res = await _exec(info, acc_sql)
        if not acc_res.rows:
            return None
        acc = Account(**{f: acc_res.rows[0].get(f) for f in Account.__dataclass_fields__})

        # Fetch transactions
        txn_sql = f"""
            SELECT transaction_id, account_id, journal_id,
                   posting_date::VARCHAR AS posting_date,
                   fiscal_year, period, source_system, transaction_type,
                   status, entity, currency, exchange_rate,
                   debit_amount, credit_amount,
                   (debit_amount - credit_amount) AS net_movement,
                   description, reference
            FROM read_parquet('{_T}')
            WHERE account_id = '{safe_id}'
              AND fiscal_year = {int(fiscal_year or 2024)}
            ORDER BY posting_date DESC
        """
        txn_res = await _exec(info, txn_sql, page_size=5000)
        txns = [
            Transaction(**{f: r.get(f) for f in Transaction.__dataclass_fields__})
            for r in txn_res.rows
        ]

        # Fetch balances
        bal_sql = f"""
            SELECT balance_id, account_id, fiscal_year, period, entity, currency,
                   ledger, segment, opening_balance, period_debits, period_credits,
                   closing_balance, ytd_debits, ytd_credits, budget_amount,
                   variance, variance_pct, is_reconciled, last_reconciled::VARCHAR AS last_reconciled
            FROM read_parquet('{_B}')
            WHERE account_id = '{safe_id}'
              AND fiscal_year = {int(fiscal_year or 2024)}
            ORDER BY period
        """
        bal_res = await _exec(info, bal_sql, page_size=5000)
        bals = [
            Balance(**{f: r.get(f) for f in Balance.__dataclass_fields__})
            for r in bal_res.rows
        ]

        # Summary
        summary = None
        if txn_res.rows and bal_res.rows:
            total_d = sum(t.debit_amount or 0 for t in txns)
            total_c = sum(t.credit_amount or 0 for t in txns)
            avg_b   = sum(b.closing_balance or 0 for b in bals) / max(len(bals), 1)
            last_b  = bals[-1].closing_balance or 0 if bals else 0
            budget  = sum(b.budget_amount or 0 for b in bals)
            summary = AccountSummary(
                account_id=safe_id,
                account_type=acc.account_type,
                total_debits=total_d,
                total_credits=total_c,
                net_movement=total_d - total_c,
                avg_balance=avg_b,
                closing_balance=last_b,
                budget_variance=last_b - budget,
                txn_count=len(txns),
            )

        return AccountWithDetail(account=acc, transactions=txns, balances=bals, summary=summary)

    @strawberry.field(description="P&L rollup by entity and period")
    async def pl_rollup(
        self,
        info: Info,
        fiscal_year: int = 2024,
        entity: Optional[str] = None,
    ) -> List[PLRow]:
        where = [f"b.fiscal_year = {fiscal_year}"]
        if entity:
            where.append(_like_or_eq("b.entity", entity))

        sql = f"""
            SELECT
                b.entity,
                b.fiscal_year,
                b.period,
                b.currency,
                a.account_type,
                SUM(CASE WHEN a.account_type = 'Revenue' THEN b.closing_balance ELSE 0 END) AS total_revenue,
                SUM(CASE WHEN a.account_type = 'Expense' THEN b.closing_balance ELSE 0 END) AS total_expense,
                SUM(CASE WHEN a.account_type = 'Revenue' THEN b.closing_balance ELSE 0 END)
                - SUM(CASE WHEN a.account_type = 'Expense' THEN b.closing_balance ELSE 0 END) AS net_pl,
                SUM(b.budget_amount) AS budget_total,
                SUM(b.variance)      AS variance
            FROM read_parquet('{_B}') b
            JOIN read_parquet('{_A}') a ON b.account_id = a.account_id
            WHERE a.account_type IN ('Revenue', 'Expense')
              AND {' AND '.join(where)}
            GROUP BY b.entity, b.fiscal_year, b.period, b.currency, a.account_type
            ORDER BY b.entity, b.period, a.account_type
        """
        result = await _exec(info, sql, page_size=10000)
        fields = list(PLRow.__dataclass_fields__.keys())
        return [PLRow(**{f: r.get(f) for f in fields}) for r in result.rows]

    @strawberry.field(description="Run a raw SQL query (SELECT only) — for power users")
    async def raw_sql(
        self,
        info: Info,
        sql: str,
        page: int = 1,
        page_size: int = 1000,
    ) -> JSON:
        # Basic safety check
        stripped = sql.strip().upper()
        if not any(stripped.startswith(p) for p in ("SELECT", "WITH", "EXPLAIN")):
            raise ValueError("Only SELECT/WITH/EXPLAIN allowed in raw_sql")

        result = await _exec(info, sql, page, page_size)
        return result.to_dict()


# ── Mutation ──────────────────────────────────────────────────────────────────

@strawberry.type
class Mutation:

    @strawberry.mutation(description="Clear the result cache")
    async def clear_cache(self) -> str:
        from app.core.query_executor import result_cache
        result_cache.clear()
        return "Cache cleared"

    @strawberry.mutation(description="Warm the cache for a named config endpoint")
    async def warm_cache(self, endpoint_id: str) -> str:
        from app.core.config_loader import registry
        ep = registry.get(endpoint_id)
        if not ep:
            raise ValueError(f"Endpoint '{endpoint_id}' not found in registry")
        sql = ep.render_query({})
        pool = get_db_pool()
        executor = QueryExecutor(pool)
        await executor.execute(sql, page=1, page_size=100, cache=True)
        return f"Cache warmed for '{endpoint_id}'"


# ── Subscription ──────────────────────────────────────────────────────────────

@strawberry.type
class Subscription:

    @strawberry.subscription(description="Stream rows from a query as they are produced")
    async def stream_query(self, info: Info, sql: str) -> AsyncGenerator[JSON, None]:
        stripped = sql.strip().upper()
        if not any(stripped.startswith(p) for p in ("SELECT", "WITH")):
            raise ValueError("Only SELECT/WITH allowed")

        pool = get_db_pool()
        executor = QueryExecutor(pool)
        async for chunk in executor.stream(sql, chunk_size=500):
            for row in chunk:
                yield row


# ── Schema ────────────────────────────────────────────────────────────────────

schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
    subscription=Subscription,
)

graphql_router = GraphQLRouter(
    schema,
    graphiql=True,   # enable GraphiQL browser IDE at /graphql
)


# ── Helper: extract selected fields from GraphQL query ───────────────────────

def _get_selected_fields(info: Info, field_path: str = "") -> set[str]:
    """Walk the field selection set and collect leaf field names."""
    try:
        fields = set()
        selections = info.selected_fields
        if field_path:
            # Drill into a nested field like "items"
            for s in selections:
                if s.name == field_path:
                    for sub in s.selections:
                        fields.add(sub.name)
            return fields
        for s in selections:
            fields.add(s.name)
        return fields
    except Exception:
        return set()
