"""
Query Result Cache — disk-backed parquet cache with configurable TTL.

Cache key:   sha256 of canonical JSON (sorted keys) of query_config dict.
Cache store: data/cache/ directory — one .parquet file per unique query.
DB metadata: query_result_cache table tracks path + expiry.

Resolution: cache hit → serve instantly (zero DuckDB execution).
Miss:       execute normally → write result → store in cache for next time.
"""
from __future__ import annotations

import hashlib
import json
import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_DEFAULT_TTL = 3600   # seconds (1 hour)
_db_manager  = None
_cache_dir: Optional[Path] = None
_ttl_seconds: int = _DEFAULT_TTL
_enabled: bool = True


def init_query_cache(db_manager, cache_dir: Path, ttl_seconds: int = _DEFAULT_TTL,
                     enabled: bool = True) -> None:
    global _db_manager, _cache_dir, _ttl_seconds, _enabled
    _db_manager  = db_manager
    _cache_dir   = Path(cache_dir)
    _ttl_seconds = ttl_seconds
    _enabled     = enabled
    _cache_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[query_cache] Initialised — dir=%s ttl=%ds enabled=%s",
                _cache_dir, _ttl_seconds, _enabled)


def make_cache_key(query_config: dict) -> str:
    """Stable sha256 hash of query config — order-independent."""
    canonical = json.dumps(query_config, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()


def get_cached_result(cache_key: str) -> Optional[Path]:
    """Return path to cached parquet if hit + not expired, else None."""
    if not _enabled or _db_manager is None:
        return None
    try:
        entry = _db_manager.get_cache_entry(cache_key)
        if not entry:
            return None
        # Check expiry
        expires_str = entry.get("expires_at")
        if expires_str:
            try:
                exp = datetime.fromisoformat(expires_str)
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp < datetime.now(timezone.utc):
                    _evict(cache_key, entry.get("file_path"))
                    return None
            except Exception:
                pass
        fp = Path(entry["file_path"])
        if not fp.exists():
            _db_manager.delete_cache_entry(cache_key)
            return None
        logger.debug("[query_cache] HIT  key=%s", cache_key[:12])
        return fp
    except Exception as exc:
        logger.warning("[query_cache] get error: %s", exc)
        return None


def store_result(cache_key: str, source_parquet: Path, query_config: dict,
                 row_count: int = 0, ttl_seconds: Optional[int] = None) -> Optional[Path]:
    """Copy source_parquet into cache dir, register DB entry. Returns cache path."""
    if not _enabled or _db_manager is None or _cache_dir is None:
        return None
    try:
        ttl = ttl_seconds if ttl_seconds is not None else _ttl_seconds
        dest = _cache_dir / f"{cache_key}.parquet"
        shutil.copy2(str(source_parquet), str(dest))
        size    = dest.stat().st_size
        expires = datetime.now(timezone.utc) + timedelta(seconds=ttl)
        _db_manager.set_cache_entry(
            cache_key=cache_key,
            file_path=str(dest),
            row_count=row_count,
            file_size_bytes=size,
            expires_at=expires,
            query_config=query_config,
        )
        logger.debug("[query_cache] STORED key=%s size=%d ttl=%ds", cache_key[:12], size, ttl)
        return dest
    except Exception as exc:
        logger.warning("[query_cache] store error: %s", exc)
        return None


def invalidate(cache_key: str) -> None:
    """Manually evict a single cache entry."""
    if _db_manager is None:
        return
    try:
        entry = _db_manager.get_cache_entry(cache_key)
        if entry:
            _evict(cache_key, entry.get("file_path"))
    except Exception:
        pass


def cleanup_expired() -> int:
    """Delete expired cache entries — called by APScheduler every 30 min."""
    if _db_manager is None:
        return 0
    try:
        deleted = _db_manager.delete_expired_cache_entries()
        # Also sweep orphaned .parquet files not tracked in DB
        if _cache_dir and _cache_dir.exists():
            known = {e.get("file_path", "") for e in (_db_manager.list_cache_entries() or [])}
            for f in _cache_dir.glob("*.parquet"):
                if str(f) not in known:
                    try:
                        f.unlink(missing_ok=True)
                    except OSError:
                        pass
        logger.info("[query_cache] Cleanup: removed %d expired entries", deleted)
        return deleted
    except Exception as exc:
        logger.warning("[query_cache] cleanup error: %s", exc)
        return 0


def get_stats() -> dict:
    """Return cache statistics for the /api/cache/stats endpoint."""
    if _db_manager is None:
        return {"enabled": False, "entry_count": 0, "total_size_bytes": 0}
    try:
        entries = _db_manager.list_cache_entries()
        total_size = sum(e.get("file_size_bytes", 0) for e in entries)
        # Count expired separately
        now = datetime.now(timezone.utc)
        expired = sum(
            1 for e in entries
            if e.get("expires_at") and
            datetime.fromisoformat(e["expires_at"]).replace(tzinfo=timezone.utc) < now
        )
        return {
            "enabled":          _enabled,
            "entry_count":      len(entries),
            "valid_count":      len(entries) - expired,
            "expired_count":    expired,
            "total_size_bytes": total_size,
            "total_size_mb":    round(total_size / 1024 / 1024, 2),
            "ttl_seconds":      _ttl_seconds,
            "cache_dir":        str(_cache_dir),
        }
    except Exception:
        return {"enabled": _enabled, "entry_count": 0, "total_size_bytes": 0}


def _evict(cache_key: str, file_path: Optional[str]) -> None:
    try:
        _db_manager.delete_cache_entry(cache_key)
    except Exception:
        pass
    if file_path:
        try:
            Path(file_path).unlink(missing_ok=True)
        except OSError:
            pass
