import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  username: string;
  display_name: string;
  email: string;
  groups: string[];
  is_admin: boolean;
}

interface AuthContextValue {
  user: User | null;
  authEnabled: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

// Module-level header accessed by api.ts without circular imports
let _authHeader: string | null = null;
export const getAuthHeader = () => _authHeader;

const STORAGE_KEY = 'qs_auth';

// Use relative paths — proxied in dev (vite.config.ts), same origin in prod
const authFetch = (path: string, opts?: RequestInit) =>
  fetch(path, opts);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authEnabled, setAuthEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const res = await authFetch('/auth/config');
        if (!res.ok) { setIsLoading(false); return; }
        const cfg = await res.json() as { type: string };
        const enabled = cfg.type !== 'none';
        setAuthEnabled(enabled);
        if (!enabled) { setIsLoading(false); return; }

        // Restore session from sessionStorage
        const stored = sessionStorage.getItem(STORAGE_KEY);
        if (stored) {
          try {
            const { header } = JSON.parse(stored) as { header: string };
            const meRes = await authFetch('/auth/me', {
              headers: { Authorization: header },
            });
            if (meRes.ok) {
              _authHeader = header;
              setUser(await meRes.json() as User);
            } else {
              sessionStorage.removeItem(STORAGE_KEY);
            }
          } catch {
            sessionStorage.removeItem(STORAGE_KEY);
          }
        }
      } catch {
        // Backend unreachable — proceed without auth gate
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  const login = async (username: string, password: string) => {
    const header = 'Basic ' + btoa(`${username}:${password}`);
    const res = await authFetch('/auth/login', {
      method: 'POST',
      headers: { Authorization: header, 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({})) as { detail?: string };
      throw new Error(err.detail || 'Login failed');
    }
    const userData = await res.json() as User;
    _authHeader = header;
    setUser(userData);
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ header }));
  };

  const logout = () => {
    _authHeader = null;
    setUser(null);
    sessionStorage.removeItem(STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, authEnabled, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
