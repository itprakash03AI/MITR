/**
 * Admin Panel — QueryStudio Enterprise
 * Active queries · User activity · System health · Storage · Cache · Audit log
 */
// @ts-nocheck
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Paper, Grid, Chip, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TextField, InputAdornment, Divider, Alert,
  LinearProgress, Tooltip, Stack, IconButton, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions, Avatar,
  useTheme,
} from '@mui/material';
import {
  CheckCircle as OkIcon,
  Error as ErrIcon,
  Warning as WarnIcon,
  Refresh as RefreshIcon,
  CleaningServices as CleanupIcon,
  DeleteSweep as ClearCacheIcon,
  Storage as StorageIcon,
  FolderOpen as FolderIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Security as AuditIcon,
  Memory as CacheIcon,
  MonitorHeart as HealthIcon,
  Cancel as CancelIcon,
  PlayCircleOutline as ActiveIcon,
  AccessTime as DurationIcon,
  Block as BlockedIcon,
  Groups as UsersIcon,
  HourglassTop as RunningIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';

const API_BASE = import.meta.env.VITE_API_URL || '';

// ── Formatters ──────────────────────────────────────────────────────────────
const fmtSize = (bytes: number) => {
  if (!bytes) return '0 B';
  const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${s[i]}`;
};
const fmtMb   = (mb: number) => mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb} MB`;
const fmtDate = (s: string)  => s ? new Date(s).toLocaleString() : '—';
const fmtDuration = (secs: number) => {
  if (secs < 60)   return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
};

// ── Section header ──────────────────────────────────────────────────────────
const SectionHeader = ({ icon, title, action = null, badge = null }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
    {icon}
    <Typography variant="h6" fontWeight={700} sx={{ flex: 1 }}>{title}</Typography>
    {badge != null && badge > 0 && (
      <Chip size="small" label={badge} color="error"
        sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
    )}
    {action}
  </Box>
);

// ── Stat card ───────────────────────────────────────────────────────────────
const StatCard = ({ label, value, sub = '', warn = false }) => (
  <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 120 }}>
    <Typography variant="caption" color="text.secondary">{label}</Typography>
    <Typography variant="h5" fontWeight={700}
      color={warn ? 'error.main' : 'text.primary'}>
      {value}
    </Typography>
    {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
  </Paper>
);

// ── Status chip ─────────────────────────────────────────────────────────────
const StatusChip = ({ ok, label = '' }) => (
  <Chip
    size="small"
    icon={ok
      ? <OkIcon  sx={{ fontSize: '14px !important' }} />
      : <ErrIcon sx={{ fontSize: '14px !important' }} />}
    label={label || (ok ? 'OK' : 'Error')}
    color={ok ? 'success' : 'error'}
    variant="outlined"
  />
);

// ── Live duration ticker ────────────────────────────────────────────────────
const LiveDuration = ({ seconds: initial, warn }) => {
  const [secs, setSecs] = useState(initial);
  useEffect(() => {
    setSecs(initial);
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [initial]);
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <DurationIcon sx={{ fontSize: 14, color: warn ? 'error.main' : 'text.secondary' }} />
      <Typography variant="body2" fontWeight={warn ? 700 : 400}
        color={warn ? 'error.main' : 'text.primary'}>
        {fmtDuration(secs)}
      </Typography>
    </Box>
  );
};

// ══ Main component ══════════════════════════════════════════════════════════
const AdminPage = () => {
  const { addNotification } = useNotifications();
  const theme = useTheme();

  const [health,      setHealth]      = useState<any>(null);
  const [storage,     setStorage]     = useState<any>(null);
  const [cache,       setCache]       = useState<any>(null);
  const [activeQ,     setActiveQ]     = useState<any[]>([]);
  const [userStats,   setUserStats]   = useState<any[]>([]);
  const [auditLog,    setAuditLog]    = useState<any[]>([]);
  const [auditPage,   setAuditPage]   = useState(0);
  const [auditTotal,  setAuditTotal]  = useState(0);
  const [auditSearch, setAuditSearch] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [loading,     setLoading]     = useState({
    health: true, storage: true, cache: true,
    activeQ: true, userStats: true, audit: true,
  });
  const [cleanupBusy, setCleanupBusy] = useState(false);
  const [cacheBusy,   setCacheBusy]   = useState(false);
  const [cancelTarget, setCancelTarget] = useState<any>(null);
  const [cancelBusy,   setCancelBusy]   = useState(false);

  const AUDIT_PER_PAGE = 25;
  const WARN_SECS = 300; // 5-min threshold

  const setOne = (k: string, v: boolean) =>
    setLoading(prev => ({ ...prev, [k]: v }));

  const loadSection = useCallback(async (section: string) => {
    setOne(section, true);
    try {
      switch (section) {
        case 'health': {
          const d = await fetch(`${API_BASE}/health`).then(r => r.json());
          setHealth(d);
          break;
        }
        case 'storage': {
          const d = await fetch(`${API_BASE}/api/admin/storage`).then(r => r.json());
          setStorage(d);
          break;
        }
        case 'cache': {
          const d = await fetch(`${API_BASE}/api/cache/stats`).then(r => r.json());
          setCache(d);
          break;
        }
        case 'activeQ': {
          const d = await fetch(`${API_BASE}/api/admin/active-queries`).then(r => r.json());
          setActiveQ(Array.isArray(d) ? d : []);
          break;
        }
        case 'userStats': {
          const d = await fetch(`${API_BASE}/api/admin/user-stats`).then(r => r.json());
          setUserStats(Array.isArray(d) ? d : []);
          break;
        }
        case 'audit': {
          const qs = new URLSearchParams({
            limit:  String(AUDIT_PER_PAGE),
            offset: String(auditPage * AUDIT_PER_PAGE),
            ...(auditSearch ? { username: auditSearch } : {}),
            ...(auditAction ? { action:   auditAction } : {}),
          });
          const res  = await fetch(`${API_BASE}/api/admin/audit-log?${qs}`);
          const data = await res.json();
          setAuditLog(Array.isArray(data) ? data : data.items || []);
          setAuditTotal(data.total || (Array.isArray(data) ? data.length : 0));
          break;
        }
      }
    } catch { /* silent */ }
    setOne(section, false);
  }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  const loadAll = useCallback(() => {
    ['health', 'storage', 'cache', 'activeQ', 'userStats', 'audit'].forEach(loadSection);
  }, [loadSection]);

  useEffect(() => { loadAll(); }, []); // eslint-disable-line
  useEffect(() => { loadSection('audit'); }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  // Poll active queries + user stats every 10s
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    pollRef.current = setInterval(() => {
      loadSection('activeQ');
      loadSection('userStats');
    }, 10_000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []); // eslint-disable-line

  // ── Handlers ────────────────────────────────────────────────────────────
  const handleCleanup = async () => {
    setCleanupBusy(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/storage/cleanup`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      addNotification({ type: 'success', title: 'Cleanup Complete', message: 'Stale files removed' });
      loadSection('storage');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cleanup Failed', message: e.message });
    } finally { setCleanupBusy(false); }
  };

  const handleClearCache = async () => {
    setCacheBusy(true);
    try {
      await fetch(`${API_BASE}/api/cache`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Cache Cleared', message: 'Query result cache cleared' });
      loadSection('cache');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Clear Failed', message: e.message });
    } finally { setCacheBusy(false); }
  };

  const handleAdminCancel = async () => {
    if (!cancelTarget) return;
    setCancelBusy(true);
    try {
      const res  = await fetch(`${API_BASE}/api/admin/queries/${cancelTarget.execution_id}`, { method: 'DELETE' });
      const body = await res.json();
      addNotification({ type: 'success', title: 'Query Cancelled', message: body.message });
      setCancelTarget(null);
      await Promise.all([loadSection('activeQ'), loadSection('userStats')]);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cancel Failed', message: e.message });
    } finally { setCancelBusy(false); }
  };

  // ── Derived ──────────────────────────────────────────────────────────────
  const longRunning  = activeQ.filter(q => q.duration_seconds >= WARN_SECS);
  const totalActive  = activeQ.length;

  return (
    <Box sx={{ p: 3, maxWidth: 1600, mx: 'auto', overflow: 'auto', height: '100%' }}>

      {/* ── Page header ── */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Admin Panel</Typography>
          <Typography variant="body2" color="text.secondary">
            Active queries · Users · System health · Storage · Cache · Audit log
          </Typography>
        </Box>
        <Button variant="outlined" size="small" startIcon={<RefreshIcon />} onClick={loadAll}>
          Refresh All
        </Button>
      </Box>

      {/* Long-running alert */}
      {longRunning.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }} icon={<BlockedIcon />}
          action={
            <Button size="small" color="inherit" onClick={() => loadSection('activeQ')}>Refresh</Button>
          }>
          <strong>{longRunning.length}</strong> quer{longRunning.length > 1 ? 'ies' : 'y'} running
          longer than {WARN_SECS / 60} minutes — consider cancelling to free resources.
        </Alert>
      )}

      <Grid container spacing={3}>

        {/* ════ Active Queries ══════════════════════════════════════════════ */}
        <Grid size={12}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<ActiveIcon color="primary" fontSize="small" />}
              title="Active Queries"
              badge={totalActive}
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => loadSection('activeQ')}>Refresh</Button>
              }
            />
            {loading.activeQ && <LinearProgress sx={{ mb: 1 }} />}

            {!loading.activeQ && activeQ.length === 0 ? (
              <Box sx={{ py: 4, textAlign: 'center', color: 'text.secondary' }}>
                <RunningIcon sx={{ fontSize: 36, mb: 1, opacity: 0.3 }} />
                <Typography variant="body2">No active queries — system is idle</Typography>
              </Box>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['User', 'Status', 'Duration', 'Progress', 'Connection', 'Started', 'Actions'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {activeQ.map((row) => {
                      const isWarn   = row.duration_seconds >= WARN_SECS;
                      const progress = row.chunks_processed > 0
                        ? Math.min(99, Math.round(row.chunks_processed * 5)) : null;
                      return (
                        <TableRow key={row.execution_id} hover
                          sx={isWarn ? { bgcolor: 'rgba(255,152,0,0.06)' } : {}}>

                          {/* User */}
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                              <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                                bgcolor: theme.palette.primary.light }}>
                                {(row.executed_by || 'G')[0].toUpperCase()}
                              </Avatar>
                              <Typography variant="body2">{row.executed_by || 'guest'}</Typography>
                            </Box>
                          </TableCell>

                          {/* Status */}
                          <TableCell>
                            <Chip size="small" label={row.status}
                              color={row.status === 'processing' ? 'primary' : 'default'}
                              variant="outlined"
                              icon={row.status === 'processing'
                                ? <RunningIcon sx={{ fontSize: '12px !important',
                                    animation: 'spin 1.4s linear infinite',
                                    '@keyframes spin': { '0%': { transform: 'rotate(0deg)' }, '100%': { transform: 'rotate(360deg)' } } }} />
                                : undefined}
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          </TableCell>

                          {/* Duration (live ticker) */}
                          <TableCell>
                            <LiveDuration seconds={row.duration_seconds} warn={isWarn} />
                          </TableCell>

                          {/* Progress */}
                          <TableCell sx={{ minWidth: 110 }}>
                            {progress != null ? (
                              <Box>
                                <LinearProgress variant="determinate" value={progress}
                                  sx={{ height: 6, borderRadius: 3, mb: 0.3 }} />
                                <Typography variant="caption" color="text.secondary">
                                  {row.chunks_processed} chunks
                                </Typography>
                              </Box>
                            ) : (
                              <LinearProgress sx={{ height: 6, borderRadius: 3 }} />
                            )}
                          </TableCell>

                          {/* Connection */}
                          <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                            {row.connection_name || '—'}
                          </TableCell>

                          {/* Started */}
                          <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap', color: 'text.secondary' }}>
                            {fmtDate(row.started_at)}
                          </TableCell>

                          {/* Actions */}
                          <TableCell>
                            <Tooltip title="Cancel this query (admin override)">
                              <IconButton size="small" color="error"
                                onClick={() => setCancelTarget(row)}>
                                <CancelIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* ════ System Health ════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<HealthIcon color="primary" fontSize="small" />} title="System Health"
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => loadSection('health')}>Refresh</Button>
              }
            />
            {loading.health && <LinearProgress sx={{ mb: 2 }} />}
            {health && (
              <>
                <Stack direction="row" spacing={1} mb={2} flexWrap="wrap" useFlexGap>
                  <StatusChip ok={health.status === 'healthy'} label={health.status?.toUpperCase()} />
                  <StatusChip ok={health.database?.ok} label={`DB: ${health.database?.ok ? 'OK' : 'Error'}`} />
                  <StatusChip ok={health.s3?.status === 'connected'} label={`S3: ${health.s3?.status || 'n/a'}`} />
                  {health.disk?.warning && <Chip size="small" icon={<WarnIcon />} label="Low Disk" color="warning" />}
                </Stack>
                <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                  <StatCard label="Active Queries"  value={health.queries?.active ?? totalActive}
                    warn={(health.queries?.active ?? totalActive) >= (health.queries?.per_user_limit ?? 99)} />
                  <StatCard label="Per-User Limit"  value={health.queries?.per_user_limit ?? '—'} />
                  <StatCard label="Disk Free"
                    value={`${health.disk?.free_gb ?? '—'} GB`}
                    warn={health.disk?.warning}
                    sub={`${health.disk?.used_pct ?? '—'}% used`} />
                </Stack>
              </>
            )}
          </Paper>
        </Grid>

        {/* ════ User Activity ════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<UsersIcon color="primary" fontSize="small" />} title="User Activity"
              action={
                <Button size="small" startIcon={<RefreshIcon />} variant="text"
                  onClick={() => { loadSection('userStats'); loadSection('activeQ'); }}>Refresh</Button>
              }
            />
            {loading.userStats && <LinearProgress sx={{ mb: 2 }} />}
            {userStats.length === 0 && !loading.userStats ? (
              <Typography variant="body2" color="text.secondary">No user activity today</Typography>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['User', 'Active Now', 'Queries Today', 'Errors', 'Last Active'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem' }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {userStats.map(u => (
                      <TableRow key={u.username} hover>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                            <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                              bgcolor: theme.palette.primary.light }}>
                              {u.username[0].toUpperCase()}
                            </Avatar>
                            <Typography variant="body2">{u.username}</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          {u.active_now > 0
                            ? <Chip size="small" label={u.active_now} color="primary" variant="outlined"
                                sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
                            : <Typography variant="body2" color="text.disabled">—</Typography>
                          }
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.8rem' }}>{u.queries_today}</TableCell>
                        <TableCell>
                          {u.failed_today > 0
                            ? <Chip size="small" label={u.failed_today} color="error" variant="outlined"
                                sx={{ height: 20, fontSize: 11 }} />
                            : <Typography variant="body2" color="text.disabled">—</Typography>
                          }
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem', color: 'text.secondary', whiteSpace: 'nowrap' }}>
                          {fmtDate(u.last_seen)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* ════ Storage ══════════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 8 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<StorageIcon color="primary" fontSize="small" />}
              title="Storage"
              action={
                <Button size="small"
                  startIcon={cleanupBusy ? <CircularProgress size={14} /> : <CleanupIcon />}
                  variant="outlined" color="warning" onClick={handleCleanup} disabled={cleanupBusy}>
                  Clean Up Now
                </Button>
              }
            />
            {loading.storage && <LinearProgress sx={{ mb: 2 }} />}
            {storage && (
              <>
                <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
                  {Object.entries(storage.directories || {}).map(([name, info]: [string, any]) => (
                    <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <FolderIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                      <Box>
                        <Typography variant="caption" color="text.secondary"
                          sx={{ textTransform: 'capitalize', display: 'block' }}>{name}</Typography>
                        <Typography variant="body2" fontWeight={600}>
                          {fmtSize(info.size_bytes)}
                          <Typography component="span" variant="caption"
                            color="text.secondary" sx={{ ml: 0.5 }}>
                            {info.file_count} files
                          </Typography>
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                </Stack>
                {storage.disk && (
                  <Box sx={{ mb: 1.5 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography variant="caption" color="text.secondary">Disk usage</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {fmtSize(storage.disk.used_gb * 1024 ** 3)} / {fmtSize(storage.disk.total_gb * 1024 ** 3)}
                      </Typography>
                    </Box>
                    <LinearProgress variant="determinate" value={storage.disk.used_pct}
                      color={storage.disk.used_pct > 85 ? 'error' : storage.disk.used_pct > 70 ? 'warning' : 'primary'}
                      sx={{ height: 8, borderRadius: 4 }} />
                  </Box>
                )}
                <Divider sx={{ my: 1.5 }} />
                <Typography variant="caption" color="text.secondary">
                  Downloads expire after <strong>{storage.settings?.downloads_expiry_days}d</strong> ·
                  Execution history kept <strong>{storage.settings?.execution_retention_days}d</strong> ·
                  Cache limit <strong>{fmtMb(storage.settings?.max_cache_size_mb)}</strong> ·
                  Downloads limit <strong>{fmtMb(storage.settings?.max_downloads_size_mb)}</strong>
                </Typography>
              </>
            )}
          </Paper>
        </Grid>

        {/* ════ Cache ════════════════════════════════════════════════════════ */}
        <Grid size={{ xs: 12, md: 4 }}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader
              icon={<CacheIcon color="primary" fontSize="small" />}
              title="Query Cache"
              action={
                <Button size="small"
                  startIcon={cacheBusy ? <CircularProgress size={14} /> : <ClearCacheIcon />}
                  variant="outlined" color="error" onClick={handleClearCache} disabled={cacheBusy}>
                  Clear
                </Button>
              }
            />
            {loading.cache && <LinearProgress sx={{ mb: 2 }} />}
            {cache && (
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <StatCard label="Cached Results" value={cache.total_entries ?? cache.count ?? '—'} />
                <StatCard label="Cache Size"
                  value={fmtSize((cache.total_size_bytes ?? cache.size_bytes) || 0)} />
                <StatCard label="Hit Rate"
                  value={cache.hit_rate != null ? `${Math.round(cache.hit_rate * 100)}%` : '—'} />
              </Stack>
            )}
            {!loading.cache && !cache && (
              <Typography variant="body2" color="text.secondary">Cache stats unavailable</Typography>
            )}
          </Paper>
        </Grid>

        {/* ════ Audit Log ════════════════════════════════════════════════════ */}
        <Grid size={12}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <SectionHeader icon={<AuditIcon color="primary" fontSize="small" />} title="Audit Log" />

            <Stack direction="row" spacing={1.5} mb={2}>
              <TextField
                size="small" placeholder="Filter by user"
                value={auditSearch}
                onChange={e => { setAuditSearch(e.target.value); setAuditPage(0); }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                  endAdornment: auditSearch
                    ? <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setAuditSearch('')}>
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    : null,
                }}
                sx={{ width: 200 }}
              />
              <TextField
                size="small" placeholder="Filter by action"
                value={auditAction}
                onChange={e => { setAuditAction(e.target.value); setAuditPage(0); }}
                InputProps={{
                  endAdornment: auditAction
                    ? <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setAuditAction('')}>
                          <ClearIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    : null,
                }}
                sx={{ width: 200 }}
              />
            </Stack>

            {loading.audit && <LinearProgress sx={{ mb: 1 }} />}
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Timestamp', 'User', 'Action', 'Resource', 'IP'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {auditLog.length === 0 && !loading.audit ? (
                    <TableRow>
                      <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                        No audit entries found
                      </TableCell>
                    </TableRow>
                  ) : auditLog.map((row, i) => (
                    <TableRow key={i} hover>
                      <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                        {fmtDate(row.timestamp)}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{row.username || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.action} variant="outlined"
                          sx={{ fontSize: '0.7rem', height: 20 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                        {row.resource_type
                          ? `${row.resource_type}${row.resource_id ? ` #${String(row.resource_id).substring(0, 8)}` : ''}`
                          : '—'}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                        {row.ip_address || '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              component="div"
              count={auditTotal > 0 ? auditTotal : auditLog.length}
              page={auditPage}
              rowsPerPage={AUDIT_PER_PAGE}
              rowsPerPageOptions={[AUDIT_PER_PAGE]}
              onPageChange={(_, p) => setAuditPage(p)}
            />
          </Paper>
        </Grid>

      </Grid>

      {/* ── Cancel confirm dialog ── */}
      <Dialog open={Boolean(cancelTarget)} onClose={() => !cancelBusy && setCancelTarget(null)}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CancelIcon color="error" />
          Cancel Query
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to cancel the query running for{' '}
            <strong>{cancelTarget?.executed_by || 'guest'}</strong>?
            {cancelTarget?.duration_seconds >= WARN_SECS && (
              <><br /><br />
                <Typography component="span" color="warning.main" fontWeight={600}>
                  This query has been running for {fmtDuration(cancelTarget?.duration_seconds)}.
                </Typography>
              </>
            )}
          </DialogContentText>
          {cancelTarget && (
            <Box sx={{ mt: 2, p: 1.5, bgcolor: 'action.hover', borderRadius: 1, fontSize: '0.8rem' }}>
              <strong>ID:</strong> {cancelTarget.execution_id?.substring(0, 16)}…<br />
              <strong>Connection:</strong> {cancelTarget.connection_name || '—'}<br />
              <strong>Started:</strong> {fmtDate(cancelTarget.started_at)}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelTarget(null)} disabled={cancelBusy}>Keep Running</Button>
          <Button variant="contained" color="error" onClick={handleAdminCancel} disabled={cancelBusy}
            startIcon={cancelBusy ? <CircularProgress size={14} /> : <CancelIcon />}>
            Cancel Query
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default AdminPage;
