"""
QueryStudio — centralised configuration loader.

Resolution order (highest → lowest priority):
  1. Environment variables  (QUERYSTUDIO_<SECTION>_<KEY>  e.g. QUERYSTUDIO_SERVER_PORT)
  2. config.json            (backend/config.json)
  3. Built-in defaults      (hardcoded in this file)

For OpenShift / container deployments set env vars in the Deployment manifest or
a ConfigMap/Secret — no code changes required.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# config.json lives next to main.py (backend/)
_CONFIG_FILE = Path(__file__).resolve().parent.parent / "config.json"

# ── Built-in defaults (fallback when neither env var nor config.json provides a value) ──
_DEFAULTS: dict = {
    "database": {
        "type": "sqlite",           # "sqlite" | "oracle"
        "oracle_dsn": "",
        "oracle_user": "",
        "oracle_password": "",
    },
    "auth": {
        "type": "none",             # "none" | "ad"
        "ad_server": "",
        "ad_domain": "",
        "ad_base_dn": "",
        "ad_user_search_filter": "(sAMAccountName={username})",
        "ad_group_attribute": "memberOf",
        "ad_admin_groups": "",
    },
    "server": {
        "host": "0.0.0.0",
        "port": 8000,
        "log_level": "info",
        "workers": 1,
    },
    "paths": {
        "data_dir": "data",
        "parquet_dir": "data/parquet",
        "downloads_dir": "data/downloads",
        "db_file": "data/parquet_query_engine.db",
        "secret_key_file": "data/secret.key",
        "upload_dir": "data/uploads",
    },
    "query_engine": {
        "chunk_size": 100000,
        "max_workers": 0,
        "query_timeout_seconds": 1800,   # 30 min; 0 = no limit
        "max_concurrent_per_user": 10,   # max parallel queries per user
    },
    "s3": {
        "default_region": "us-east-1",
    },
    "scheduler": {
        "cleanup_temp_files_hours": 1,
        "max_missed_jobs": 3,
        "execution_retention_days": 30,   # delete execution history older than N days
    },
    "storage": {
        "max_cache_size_mb":     2048,    # LRU-evict cache when total exceeds this
        "max_downloads_size_mb": 10240,   # warn/evict downloads when total exceeds this
        "downloads_expiry_days": 7,       # default download file TTL
    },
    "cors": {
        "allow_origins": ["*"],
        "allow_methods": ["*"],
        "allow_headers": ["*"],
    },
    "email": {
        "host": "",
        "port": 587,
        "user": "",
        "password": "",
        "from_address": "",
        "use_tls": True,
    },
    "cache": {
        "enabled":     True,
        "ttl_seconds": 3600,
        "max_size_mb": 2048,
    },
}


def _load_file() -> dict:
    if _CONFIG_FILE.exists():
        try:
            with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            logger.info("Loaded config from %s", _CONFIG_FILE)
            return data
        except Exception as e:
            logger.warning("Failed to parse %s: %s — using defaults", _CONFIG_FILE, e)
    return {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (override wins)."""
    result = dict(base)
    for k, v in override.items():
        if k.startswith("_comment"):
            continue
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _apply_env(cfg: dict, prefix: str = "QUERYSTUDIO") -> dict:
    """
    Override config values from environment variables.

    Mapping:  QUERYSTUDIO_SERVER_PORT=9000  →  cfg["server"]["port"] = 9000
              QUERYSTUDIO_PATHS_DATA_DIR=/mnt/data  →  cfg["paths"]["data_dir"] = "/mnt/data"
    """
    for key, raw in os.environ.items():
        if not key.upper().startswith(prefix + "_"):
            continue
        parts = key[len(prefix) + 1:].lower().split("_", 1)
        if len(parts) != 2:
            continue
        section, field = parts
        if section not in cfg:
            continue
        if field not in cfg[section]:
            continue
        original = cfg[section][field]
        try:
            if isinstance(original, bool):
                cfg[section][field] = raw.lower() in ("1", "true", "yes")
            elif isinstance(original, int):
                cfg[section][field] = int(raw)
            elif isinstance(original, float):
                cfg[section][field] = float(raw)
            elif isinstance(original, list):
                cfg[section][field] = [v.strip() for v in raw.split(",")]
            else:
                cfg[section][field] = raw
        except ValueError:
            logger.warning("Could not cast env var %s=%r to %s — skipping", key, raw, type(original).__name__)
    return cfg


# ── Build the merged config once at import time ──────────────────────────────
_file_cfg = _load_file()
_merged   = _deep_merge(_DEFAULTS, _file_cfg)
_cfg      = _apply_env(_merged)


def get(section: str, key: str, fallback: Any = None) -> Any:
    """Return a config value. Falls back to `fallback` if not found."""
    return _cfg.get(section, {}).get(key, fallback)


# ── Convenience accessors ─────────────────────────────────────────────────────

class _ServerCfg:
    host:       str = property(lambda self: get("server", "host"))        # type: ignore[assignment]
    port:       int = property(lambda self: get("server", "port"))        # type: ignore[assignment]
    log_level:  str = property(lambda self: get("server", "log_level"))   # type: ignore[assignment]
    workers:    int = property(lambda self: get("server", "workers"))     # type: ignore[assignment]

_HERE = Path(__file__).resolve().parent.parent  # backend/


def _resolve(rel: str) -> Path:
    """Resolve a path that may be relative (to backend/) or absolute."""
    p = Path(rel)
    return p if p.is_absolute() else (_HERE / p)


class _PathsCfg:
    @property
    def data_dir(self)        -> Path: return _resolve(get("paths", "data_dir"))
    @property
    def parquet_dir(self)     -> Path: return _resolve(get("paths", "parquet_dir"))
    @property
    def downloads_dir(self)   -> Path: return _resolve(get("paths", "downloads_dir"))
    @property
    def db_file(self)         -> Path: return _resolve(get("paths", "db_file"))
    @property
    def secret_key_file(self) -> Path: return _resolve(get("paths", "secret_key_file"))
    @property
    def upload_dir(self)      -> Path: return _resolve(get("paths", "upload_dir"))
    @property
    def db_url(self)          -> str:
        return "sqlite:///" + self.db_file.as_posix()


class _QueryEngineCfg:
    @property
    def chunk_size(self)  -> int: return int(get("query_engine", "chunk_size"))
    @property
    def max_workers(self) -> int:
        w = int(get("query_engine", "max_workers"))
        return w if w > 0 else min(32, (os.cpu_count() or 4) + 4)
    @property
    def query_timeout_seconds(self) -> int:
        return int(get("query_engine", "query_timeout_seconds", 1800))
    @property
    def max_concurrent_per_user(self) -> int:
        return int(get("query_engine", "max_concurrent_per_user", 3))


class _S3Cfg:
    @property
    def default_region(self) -> str: return get("s3", "default_region")


class _StorageCfg:
    @property
    def max_cache_size_mb(self)     -> int: return int(get("storage", "max_cache_size_mb", 2048))
    @property
    def max_downloads_size_mb(self) -> int: return int(get("storage", "max_downloads_size_mb", 10240))
    @property
    def downloads_expiry_days(self) -> int: return int(get("storage", "downloads_expiry_days", 7))


class _SchedulerCfg:
    @property
    def cleanup_temp_files_hours(self)   -> int: return int(get("scheduler", "cleanup_temp_files_hours"))
    @property
    def max_missed_jobs(self)            -> int: return int(get("scheduler", "max_missed_jobs"))
    @property
    def execution_retention_days(self)   -> int: return int(get("scheduler", "execution_retention_days", 30))


class _CorsCfg:
    @property
    def allow_origins(self) -> list: return get("cors", "allow_origins")
    @property
    def allow_methods(self) -> list: return get("cors", "allow_methods")
    @property
    def allow_headers(self) -> list: return get("cors", "allow_headers")


class _DatabaseCfg:
    @property
    def type(self) -> str:
        return get("database", "type", "sqlite").lower()

    @property
    def db_url(self) -> str:
        """Return the SQLAlchemy DB URL for the metadata store."""
        if self.type == "oracle":
            user = get("database", "oracle_user") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_USER", "")
            pwd  = get("database", "oracle_password") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_PASSWORD", "")
            dsn  = get("database", "oracle_dsn") or os.getenv("QUERYSTUDIO_DATABASE_ORACLE_DSN", "")
            if not (user and pwd and dsn):
                raise ValueError(
                    "database.type=oracle requires oracle_user, oracle_password, and oracle_dsn "
                    "in config.json or QUERYSTUDIO_DATABASE_ORACLE_* env vars."
                )
            return f"oracle+oracledb://{user}:{pwd}@{dsn}"
        # Default: SQLite
        return "sqlite:///" + _PathsCfg().db_file.as_posix()


class _AuthCfg:
    @property
    def type(self) -> str:
        return get("auth", "type", "none").lower()

    @property
    def ad_server(self) -> str:         return get("auth", "ad_server", "")
    @property
    def ad_domain(self) -> str:         return get("auth", "ad_domain", "")
    @property
    def ad_base_dn(self) -> str:        return get("auth", "ad_base_dn", "")
    @property
    def ad_user_search_filter(self) -> str:
        return get("auth", "ad_user_search_filter", "(sAMAccountName={username})")
    @property
    def ad_group_attribute(self) -> str: return get("auth", "ad_group_attribute", "memberOf")
    @property
    def ad_admin_groups(self) -> list:
        raw = get("auth", "ad_admin_groups", "")
        return [g.strip() for g in raw.split(",") if g.strip()] if raw else []


class _EmailCfg:
    @property
    def host(self) -> str:         return get("email", "host", "")
    @property
    def port(self) -> int:         return int(get("email", "port", 587))
    @property
    def user(self) -> str:         return get("email", "user", "")
    @property
    def password(self) -> str:     return get("email", "password", "")
    @property
    def from_address(self) -> str: return get("email", "from_address", "")
    @property
    def use_tls(self) -> bool:     return bool(get("email", "use_tls", True))
    @property
    def enabled(self) -> bool:     return bool(self.host)


class _CacheCfg:
    @property
    def enabled(self)     -> bool: return bool(get("cache", "enabled", True))
    @property
    def ttl_seconds(self) -> int:  return int(get("cache", "ttl_seconds", 3600))
    @property
    def max_size_mb(self) -> int:  return int(get("cache", "max_size_mb", 2048))


server        = _ServerCfg()
paths         = _PathsCfg()
database      = _DatabaseCfg()
auth          = _AuthCfg()
query_engine  = _QueryEngineCfg()
s3            = _S3Cfg()
scheduler     = _SchedulerCfg()
cors          = _CorsCfg()
email         = _EmailCfg()
cache         = _CacheCfg()
storage       = _StorageCfg()
