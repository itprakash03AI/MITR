"""
Active Directory / LDAP authentication for QueryStudio.

When auth.type = "ad" in config.json, all API requests must include an
Authorization: Bearer <base64(user:password)> header (HTTP Basic encoded
as Bearer for API compatibility) OR a session token obtained from POST /auth/login.

AD configuration (config.json or QUERYSTUDIO_AUTH_* env vars):
  ad_server              – LDAP server URL  e.g. "ldap://ad.example.com"
  ad_domain              – Windows domain   e.g. "EXAMPLE"
  ad_base_dn             – Search base      e.g. "DC=example,DC=com"
  ad_user_search_filter  – LDAP filter with {username} placeholder
  ad_group_attribute     – Attribute holding group memberships (memberOf)
  ad_admin_groups        – Comma-separated list of AD groups → admin role

Requires: ldap3   (pip install ldap3)
"""
from __future__ import annotations

import base64
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def _ldap3():
    try:
        import ldap3
        return ldap3
    except ImportError:
        raise RuntimeError(
            "ldap3 is not installed. Run: pip install ldap3  then restart the backend."
        )


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """
    Authenticate `username` / `password` against Active Directory.

    Returns a user-info dict on success:
        { "username": str, "display_name": str, "email": str,
          "groups": [str], "is_admin": bool }
    Returns None on failure.
    """
    from core.config import auth as _auth

    if _auth.type != "ad":
        # auth disabled — accept any credentials (or no credentials)
        return {"username": username, "display_name": username,
                "email": "", "groups": [], "is_admin": True}

    ldap3 = _ldap3()

    server_url = _auth.ad_server
    domain     = _auth.ad_domain
    base_dn    = _auth.ad_base_dn
    search_filter = _auth.ad_user_search_filter.format(username=username)
    group_attr    = _auth.ad_group_attribute
    admin_groups  = set(g.lower() for g in _auth.ad_admin_groups)

    # Bind with domain\username (or UPN: username@domain)
    bind_user = f"{domain}\\{username}" if domain else username

    server = ldap3.Server(server_url, get_info=ldap3.ALL)
    try:
        conn = ldap3.Connection(
            server,
            user=bind_user,
            password=password,
            authentication=ldap3.NTLM if domain else ldap3.SIMPLE,
            auto_bind=True,
        )
    except ldap3.core.exceptions.LDAPBindError:
        logger.warning("AD bind failed for user: %s", username)
        return None

    # Search for the user to get display name, email, groups
    conn.search(
        search_base=base_dn,
        search_filter=search_filter,
        attributes=["displayName", "mail", group_attr],
    )

    if not conn.entries:
        conn.unbind()
        logger.warning("AD search returned no entries for: %s", username)
        return None

    entry = conn.entries[0]
    display_name = str(entry.displayName) if hasattr(entry, "displayName") else username
    email        = str(entry.mail)        if hasattr(entry, "mail")        else ""

    raw_groups: list = []
    if hasattr(entry, group_attr):
        raw_groups = list(getattr(entry, group_attr))

    # Extract CN from each group DN  e.g. "CN=Admins,DC=..." → "admins"
    groups = []
    for dn in raw_groups:
        cn = dn.split(",")[0].replace("CN=", "").replace("cn=", "").strip()
        groups.append(cn)

    is_admin = bool(admin_groups & {g.lower() for g in groups}) if admin_groups else False

    conn.unbind()
    return {
        "username": username,
        "display_name": display_name,
        "email": email,
        "groups": groups,
        "is_admin": is_admin,
    }


def decode_basic_header(authorization: str) -> tuple[str, str]:
    """Parse 'Basic <base64(user:password)>' or 'Bearer <base64(user:password)>' header."""
    parts = authorization.split(" ", 1)
    if len(parts) != 2:
        raise ValueError("Invalid Authorization header format")
    encoded = parts[1]
    try:
        decoded = base64.b64decode(encoded).decode("utf-8")
    except Exception:
        raise ValueError("Could not base64-decode Authorization header")
    if ":" not in decoded:
        raise ValueError("Authorization payload must be user:password")
    user, pw = decoded.split(":", 1)
    return user, pw
