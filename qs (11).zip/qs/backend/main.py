"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
import time as _time
import uuid
import logging
from pathlib import Path
import asyncio
import os
import sys
from dotenv import load_dotenv

# Windows ProactorEventLoop raises spurious OSError on socket shutdown — switch
# to SelectorEventLoop which avoids this.  Must be set before any event loop starts.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# ── Graceful shutdown on Windows + Linux ──────────────────────────────────────
# Do NOT override SIGINT/SIGTERM with os._exit() — that kills the process
# without releasing sockets, leaving port 8000 in TIME_WAIT and causing
# "Only one usage of each socket address" on the next restart.
# Let uvicorn handle SIGINT/SIGTERM naturally; the executor is shut down
# in the FastAPI shutdown event handler below.

from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
from api.sql_query_api import router as sql_router, set_sql_dependencies
from api.reports_api import router as reports_router, set_report_dependencies
from api.schedules_api import router as schedules_router, set_schedule_dependencies
from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
# Load environment variables
load_dotenv()

from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType, AggregationConfig
from core.s3_storage import S3Config, build_s3_config
from core.database import DatabaseManager
from core.websocket_manager import WebSocketManager
from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
from core.connectors import get_connector, SQL_CONNECTOR_TYPES

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ── Load centralised config (config.json + env var overrides) ─────────────────
from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg

# Ensure all data directories exist at startup
_paths.data_dir.mkdir(parents=True, exist_ok=True)
_paths.parquet_dir.mkdir(parents=True, exist_ok=True)
_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
_paths.upload_dir.mkdir(parents=True, exist_ok=True)

_DATA_DIR = _paths.data_dir   # kept for backward-compat references below
_DB_URL   = _db_cfg.db_url   # sqlite or oracle depending on config.json / env vars

# Initialize FastAPI app
app = FastAPI(
    title="QueryStudio API",
    description="Enterprise-grade query engine — S3, Iceberg, Snowflake, Trino, Databricks",
    version="2.0.0"
)

# GZip compression (~70% payload reduction for JSON responses)
app.add_middleware(GZipMiddleware, minimum_size=1024)

# CORS middleware — origins/methods/headers driven by config.json / env vars
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_cfg.allow_origins,
    allow_credentials=True,
    allow_methods=_cors_cfg.allow_methods,
    allow_headers=_cors_cfg.allow_headers,
)

# Thread pool for CPU-bound query execution
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)
app.include_router(data_grid_router)
app.include_router(sql_router)
app.include_router(reports_router)
app.include_router(schedules_router)
app.include_router(dashboards_router)

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        auth_mode=os.getenv('S3_AUTH_MODE', 'keys'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        aws_profile=os.getenv('AWS_PROFILE'),
        role_arn=os.getenv('AWS_ROLE_ARN'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL'),
        ssl_verify=os.getenv('S3_SSL_VERIFY', 'true').lower() != 'false',
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# Per-execution cancellation registry
import threading as _threading
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency tracking
_user_query_counts: dict = {}    # username → int (active query count)
_user_query_lock = _threading.Lock()


# ── Active Directory / Auth helpers ───────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    password: str


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none" → always returns a guest user (no login required)
    - auth.type = "ad"   → requires Authorization: Basic/Bearer <base64(user:pass)>
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type != "ad":
        return {"username": "guest", "is_admin": True, "groups": []}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid AD credentials")
    return user


@app.post("/auth/login")
async def login(req: _LoginRequest):
    """
    Authenticate against Active Directory (or return guest info when auth is disabled).
    Returns user info including group memberships and admin flag.
    """
    from core.ad_auth import authenticate_user
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return user


@app.get("/auth/me")
async def whoami(request: Request):
    """Return the current user's identity (or guest when auth is disabled)."""
    return _get_current_user(request)


@app.get("/auth/config")
async def auth_config():
    """Return auth configuration visible to the frontend (type only — no secrets)."""
    return {"type": _auth_cfg.type, "domain": _auth_cfg.ad_domain}


# Pydantic Models
class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None


_ALL_CONN_TYPES = "^(s3|local|trino|starburst|snowflake|databricks|oracle)$"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# Helper functions
# build_s3_config is imported from core.s3_storage — single source of truth


def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how
            )
            for j in config.joins
        ]
    
    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]
    
    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]
    
    aggregations = None
    if config.aggregations:
        aggregations = [
            AggregationConfig(column=a.column, function=a.function.upper(),
                              alias=a.alias, distinct=a.distinct)
            for a in config.aggregations
        ]

    having = None
    if config.having:
        having = [{"column": h.column, "function": h.function.upper(),
                   "operator": h.operator, "value": h.value}
                  for h in config.having]

    computed_columns = None
    if config.computed_columns:
        computed_columns = [{"expression": c.expression, "alias": c.alias}
                           for c in config.computed_columns]

    case_expressions = None
    if config.case_expressions:
        case_expressions = [
            {"when_clauses": [{"when_column": w.when_column, "when_operator": w.when_operator,
                               "when_value": w.when_value, "then_value": w.then_value}
                              for w in ce.when_clauses],
             "else_value": ce.else_value, "alias": ce.alias}
            for ce in config.case_expressions
        ]

    window_functions = None
    if config.window_functions:
        window_functions = [
            {"function": wf.function.upper(), "alias": wf.alias,
             "column": wf.column,
             "partition_by": wf.partition_by,
             "order_by": [{"column": o.column, "direction": o.direction}
                          for o in wf.order_by] if wf.order_by else None,
             "offset": wf.offset, "default_value": wf.default_value}
            for wf in config.window_functions
        ]

    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by,
        group_by=config.group_by,
        aggregations=aggregations,
        distinct=config.distinct,
        having=having,
        filter_logic=config.filter_logic.upper(),
        computed_columns=computed_columns,
        case_expressions=case_expressions,
        column_aliases=config.column_aliases,
        window_functions=window_functions,
    )


async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest",
                                  raw_sql: Optional[str] = None):
    """Background task for query execution"""
    run_engine = active_engine or engine
    cancel_event = _threading.Event()
    _cancellation_flags[execution_id] = cancel_event
    try:
        db_manager.update_execution(execution_id, status="processing")
        
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            if is_terminal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet():
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0
            pq_writer = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                if raw_sql:
                    _query_gen = run_engine.execute_raw_duckdb_sql(raw_sql)
                elif run_engine._needs_duckdb(query_config):
                    _query_gen = run_engine.execute_duckdb_query(query_config)
                else:
                    _query_gen = run_engine.execute_query(query_config)
                for chunk_df in _query_gen:
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    table = _pa.Table.from_pandas(chunk_df, preserve_index=False)
                    if pq_writer is None:
                        pq_writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                    pq_writer.write_table(table)
                    total_rows += len(chunk_df)
                    chunks_processed += 1
            finally:
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # Ensure an empty file exists for 0-row results so downstream
                # readers don't get a FileNotFoundError.
                if total_rows == 0 and not output_file.exists():
                    output_file.touch()
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed"}

        _timeout = _qe_cfg.query_timeout_seconds
        try:
            stats = await asyncio.wait_for(
                loop.run_in_executor(query_executor, _exec_to_parquet),
                timeout=_timeout if _timeout > 0 else None,
            )
        except asyncio.TimeoutError:
            cancel_event.set()   # stop the thread at next chunk boundary
            raise TimeoutError(f"Query exceeded timeout of {_timeout}s")

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — no file copy, cache points to same parquet
        try:
            from core.query_cache import make_cache_key, store_result
            _ck = make_cache_key(query_config.__dict__ if hasattr(query_config, '__dict__') else {})
            if output_file.exists():
                store_result(_ck, output_file, {}, row_count=stats.get("total_rows", 0), copy=False)
        except Exception:
            pass

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        logger.info(f"Query execution completed: {execution_id}")
        
    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}")

        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )

        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        _cancellation_flags.pop(execution_id, None)
        _running_tasks.pop(execution_id, None)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_sql_connector_background(
    execution_id: str,
    connector,          # SqlConnector instance (already constructed)
    sql: str,           # complete SQL built by engine.build_query_sql()
    query_id: Optional[int] = None,
    executed_by: str = "guest",
):
    """Execute a query against a SQL connector (Trino/Starburst/Snowflake/Databricks/Oracle).
    Mirrors the structure of execute_query_background so the frontend receives
    the same WebSocket messages and can download results the same way.
    """
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    import pandas as _pd

    cancel_event = _threading.Event()
    _cancellation_flags[execution_id] = cancel_event
    try:
        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        def _exec_sql():
            try:
                logger.info(f"SQL connector query [{execution_id}]:\n{sql}")
                result = connector.execute_query(sql)
                # result = {"columns": [{"name":..,"type":..}], "rows": [...], "total_rows": int}
                rows    = result.get("rows", [])
                col_defs = result.get("columns", [])
                col_names = [c["name"] for c in col_defs]
                df = _pd.DataFrame(rows, columns=col_names) if rows else _pd.DataFrame(columns=col_names)
                total_rows = len(df)
                output_file.parent.mkdir(parents=True, exist_ok=True)
                if total_rows > 0:
                    table = _pa.Table.from_pandas(df, preserve_index=False)
                    with open(str(output_file), "wb") as fh:
                        _pq.ParquetWriter(fh, table.schema, compression="zstd").write_table(table)
                else:
                    output_file.touch()
                file_size = output_file.stat().st_size
                return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
            finally:
                try:
                    connector.close()
                except Exception:
                    pass

        _timeout = _qe_cfg.query_timeout_seconds
        try:
            stats = await asyncio.wait_for(
                loop.run_in_executor(query_executor, _exec_sql),
                timeout=_timeout if _timeout > 0 else None,
            )
        except asyncio.TimeoutError:
            cancel_event.set()
            raise TimeoutError(f"SQL connector query exceeded timeout of {_timeout}s")

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )
        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        if query_id:
            db_manager.increment_execution_count(query_id)
        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"SQL connector query completed: {execution_id} ({stats.get('total_rows',0)} rows)")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"SQL connector query cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled", error_message="Cancelled by user")
        await ws_manager.broadcast({"type": "execution_cancelled", "execution_id": execution_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat()})
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"SQL connector query failed {execution_id}: {e}")
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                                    "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()})
    finally:
        _cancellation_flags.pop(execution_id, None)
        _running_tasks.pop(execution_id, None)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_cross_query_background(
    execution_id: str,
    primary_engine,
    primary_config: QueryConfig,
    secondary_engine,
    secondary_config: QueryConfig,
    combine_mode: str,
    join_config: Optional[dict],
    query_id: Optional[int] = None,
    executed_by: str = "guest",
):
    """Background task for cross-connection (multi-source) query execution."""
    import pandas as _pd
    cancel_event = _threading.Event()
    _cancellation_flags[execution_id] = cancel_event
    try:
        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        async def _progress(data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            if data.get("status") in ("completed", "failed"):
                db_manager.update_execution(
                    execution_id,
                    status=data["status"],
                    total_rows=data.get("total_rows", 0),
                    chunks_processed=data.get("chunks_processed", 0),
                    output_file=str(output_file) if data.get("status") == "completed" else None,
                    file_size_bytes=data.get("file_size_bytes", 0),
                    error_message=data.get("error"),
                )

        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            if data.get("status") in ("completed", "failed") or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(_progress(data), loop)

        import pyarrow as _pa
        import pyarrow.parquet as _pq

        def _exec_cross():
            output_file.parent.mkdir(parents=True, exist_ok=True)

            # ── Primary source ────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "primary",
                            "message": "Executing primary source query"})
            chunks_a = []
            for chunk in primary_engine.execute_query(primary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_a.append(chunk)
            df_a = _pd.concat(chunks_a, ignore_index=True) if chunks_a else _pd.DataFrame()

            # ── Secondary source ──────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "secondary",
                            "message": "Executing secondary source query"})
            chunks_b = []
            for chunk in secondary_engine.execute_query(secondary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_b.append(chunk)
            df_b = _pd.concat(chunks_b, ignore_index=True) if chunks_b else _pd.DataFrame()

            # ── Combine ───────────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "combining",
                            "message": f"Combining via {combine_mode.upper()}"})
            if combine_mode == "union":
                df_result = _pd.concat([df_a, df_b], ignore_index=True, sort=False)
            elif combine_mode == "join":
                if not join_config:
                    raise ValueError("join_config required for join mode")
                how = join_config.get("how", "inner")
                left_on = join_config.get("left_on")
                right_on = join_config.get("right_on")
                suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
                if isinstance(left_on, str): left_on = [left_on]
                if isinstance(right_on, str): right_on = [right_on]
                if not left_on or not right_on:
                    raise ValueError("join_config must specify left_on and right_on")
                df_result = _pd.merge(df_a, df_b, how=how,
                                      left_on=left_on, right_on=right_on,
                                      suffixes=suffixes)
            else:
                raise ValueError(f"Unknown combine_mode '{combine_mode}'")

            # ── Save parquet ──────────────────────────────────────────────────
            fh = open(str(output_file), "wb")
            try:
                table = _pa.Table.from_pandas(df_result, preserve_index=False)
                writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                writer.write_table(table)
                writer.close()
            finally:
                fh.close()
            if df_result.empty and not output_file.exists():
                output_file.touch()

            total_rows = len(df_result)
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows,
                            "file_size_bytes": file_size, "chunks_processed": 2})
            return {"total_rows": total_rows, "chunks_processed": 2,
                    "file_size_bytes": file_size, "status": "completed"}

        _timeout = _qe_cfg.query_timeout_seconds
        try:
            stats = await asyncio.wait_for(
                loop.run_in_executor(query_executor, _exec_cross),
                timeout=_timeout if _timeout > 0 else None,
            )
        except asyncio.TimeoutError:
            cancel_event.set()
            raise TimeoutError(f"Query exceeded timeout of {_timeout}s")

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"cross_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        if query_id:
            db_manager.increment_execution_count(query_id)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "combine_mode": combine_mode,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"Cross-connection query completed: {execution_id} ({combine_mode})")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"Cross-connection query cancelled: {execution_id}")
        cur = db_manager.get_execution(execution_id)
        if cur and cur.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"Error in cross-connection query {execution_id}: {e}")
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        _cancellation_flags.pop(execution_id, None)
        _running_tasks.pop(execution_id, None)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


# ── Audit helper ──────────────────────────────────────────────────────────────

def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        db_manager.audit(username, action, resource_type=resource_type,
                         resource_id=resource_id, ip_address=ip,
                         user_agent=ua[:500] if ua else None, details=details)
    except Exception:
        pass


# ── SPA static file serving ───────────────────────────────────────────────────
# Serve the built React frontend when the static/ dir exists next to main.py.
# In Docker: built by Dockerfile into ./static
# In local dev: build frontend with `npm run build` → output to ./static or ../frontend/build
# Falls back to a JSON root response when no built frontend is present.
_STATIC_CANDIDATES = [
    Path(__file__).resolve().parent / "static",          # Docker / production
    Path(__file__).resolve().parent.parent / "frontend" / "build",  # local dev
    Path(__file__).resolve().parent.parent / "frontend" / "dist",   # legacy Vite
]
_STATIC_DIR: Optional[Path] = next((p for p in _STATIC_CANDIDATES if p.is_dir()), None)

if _STATIC_DIR:
    from fastapi.staticfiles import StaticFiles
    # Mount /assets (hashed JS/CSS bundles) — short cache for CDN
    _assets = _STATIC_DIR / "assets"
    if _assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")
    logger.info("Serving built frontend from %s", _STATIC_DIR)
else:
    logger.info("No built frontend found — API-only mode")


@app.get("/health")
async def health_check():
    """Health check — DB connectivity, disk space, active queries."""
    import shutil as _shutil

    # Database ping
    db_ok = False
    try:
        db_manager.get_execution("__health_probe__")   # returns None, never raises
        db_ok = True
    except Exception:
        pass

    # Disk usage for data directory
    try:
        _du = _shutil.disk_usage(str(_paths.data_dir))
        disk_free_gb  = round(_du.free  / (1024 ** 3), 2)
        disk_used_pct = round(_du.used  / _du.total * 100, 1)
        disk_warn     = disk_free_gb < 5.0
    except Exception:
        disk_free_gb = disk_used_pct = -1
        disk_warn = False

    # S3 connectivity (non-blocking, best-effort)
    s3_status = "not_configured"
    if engine.s3_handler:
        try:
            s3_status = "connected" if engine.s3_handler.test_connection().get("connected") else "error"
        except Exception:
            s3_status = "error"

    active_queries = len([t for t in _running_tasks.values() if not t.done()])
    overall = "healthy" if db_ok and not disk_warn else "degraded"

    return {
        "status":    overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database":  {"ok": db_ok},
        "disk":      {"free_gb": disk_free_gb, "used_pct": disk_used_pct, "warning": disk_warn},
        "queries":   {"active": active_queries, "max_workers": _qe_cfg.max_workers,
                      "per_user_limit": _qe_cfg.max_concurrent_per_user},
        "s3":        {"status": s3_status},
    }


# ── Storage management endpoints ──────────────────────────────────────────────

def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest: oldest = mt
                    if newest is None or mt > newest: newest = mt
                except OSError:
                    pass
    return {
        "path": str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb": round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


@app.get("/api/admin/storage")
async def get_storage_summary(_user: dict = Depends(_get_current_user)):
    """Return per-directory disk usage and configured retention settings."""
    import shutil as _shutil
    dirs = {
        "downloads": _paths.downloads_dir,
        "cache":     _paths.data_dir / "cache",
        "parquet":   _paths.parquet_dir,
        "uploads":   _paths.data_dir / "uploads",
    }
    breakdown = {name: _dir_stats(Path(p)) for name, p in dirs.items()}

    try:
        du = _shutil.disk_usage(str(_paths.data_dir))
        disk = {
            "total_gb":   round(du.total / (1024 ** 3), 2),
            "used_gb":    round(du.used  / (1024 ** 3), 2),
            "free_gb":    round(du.free  / (1024 ** 3), 2),
            "used_pct":   round(du.used  / du.total * 100, 1),
        }
    except Exception:
        disk = {}

    from core.config import storage as _stg_cfg, scheduler as _sched_cfg
    return {
        "disk": disk,
        "directories": breakdown,
        "settings": {
            "downloads_expiry_days":    _stg_cfg.downloads_expiry_days,
            "execution_retention_days": _sched_cfg.execution_retention_days,
            "max_cache_size_mb":        _stg_cfg.max_cache_size_mb,
            "max_downloads_size_mb":    _stg_cfg.max_downloads_size_mb,
        },
        "tracked_downloads": db_manager.get_downloads_size_bytes() // (1024 * 1024),
    }


@app.post("/api/admin/storage/cleanup")
async def trigger_cleanup(_user: dict = Depends(_get_current_user)):
    """Manually trigger all cleanup jobs immediately (admin action)."""
    from core.scheduler import _cleanup_temp_files, _enforce_storage_quotas, _cleanup_execution_history
    import concurrent.futures as _cf
    results = {}
    for name, fn in [
        ("temp_files",         _cleanup_temp_files),
        ("storage_quotas",     _enforce_storage_quotas),
        ("execution_history",  _cleanup_execution_history),
    ]:
        try:
            fn()
            results[name] = "ok"
        except Exception as exc:
            results[name] = str(exc)
    _audit(_user, "manual_storage_cleanup", None, details=results)
    logger.info("Manual storage cleanup triggered by %s: %s", (_user or {}).get("username", "guest"), results)
    return {"status": "completed", "results": results}


@app.get("/api/admin/active-queries")
async def get_active_queries(_user: dict = Depends(_get_current_user)):
    """Return all currently running/pending executions with live duration and connection info.

    Source of truth is _running_tasks (in-memory), not DB status — the DB record
    may still show 'pending' while the background task is already executing.
    """
    from datetime import datetime, timezone as _tz
    now = datetime.now(_tz.utc)

    # 1. Live execution IDs — union of asyncio tasks AND cancellation flags.
    #    _cancellation_flags is set at the very start of each background function and
    #    removed only in the finally block, so it's the most reliable liveness signal.
    live_ids = (
        {eid for eid, task in _running_tasks.items() if not task.done()} |
        set(_cancellation_flags.keys())
    )

    # 2. DB rows for pending/processing (catches tasks not yet in _running_tasks)
    db_rows: dict = {}
    for status in ("processing", "pending"):
        for r in db_manager.list_executions(limit=500, status=status):
            db_rows[r["execution_id"]] = r

    # 3. Fetch DB records for any live task not already captured above
    for eid in live_ids:
        if eid not in db_rows:
            r = db_manager.get_execution(eid)
            if r:
                db_rows[r["execution_id"]] = r
            else:
                # Task exists in memory but no DB record yet — synthesise a minimal row
                db_rows[eid] = {
                    "execution_id": eid,
                    "status": "processing",
                    "started_at": now.isoformat(),
                    "executed_by": None,
                    "chunks_processed": 0,
                    "query_config": {},
                }

    conn_cache: dict = {}
    def _conn_name(cid):
        if cid is None:
            return None
        if cid not in conn_cache:
            try:
                c = db_manager.get_connection_raw(cid)
                conn_cache[cid] = c.get("name", f"#{cid}") if c else f"#{cid}"
            except Exception:
                conn_cache[cid] = f"#{cid}"
        return conn_cache[cid]

    enriched = []
    for r in db_rows.values():
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_tz.utc)
                duration_s = int((now - dt).total_seconds())
            except Exception:
                duration_s = 0
        else:
            duration_s = 0

        qcfg    = r.get("query_config") or {}
        conn_id = qcfg.get("connection_id") or r.get("connection_id")

        enriched.append({
            **r,
            "duration_seconds": duration_s,
            "connection_name":  _conn_name(conn_id),
            "task_alive":       r["execution_id"] in live_ids,
        })

    enriched.sort(key=lambda x: x["duration_seconds"], reverse=True)
    return enriched


@app.get("/api/admin/user-stats")
async def get_user_stats(_user: dict = Depends(_get_current_user)):
    """Per-user query activity: active now, completed today, last seen."""
    from datetime import datetime, timezone as _tz, timedelta
    today_start = datetime.now(_tz.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    # All executions from today
    all_today = db_manager.list_executions(limit=2000)
    user_map: dict = {}

    for r in all_today:
        u = r.get("executed_by") or "guest"
        if u not in user_map:
            user_map[u] = {"username": u, "queries_today": 0, "last_seen": None,
                           "active_now": 0, "failed_today": 0}
        started = r.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_tz.utc)
                if dt >= today_start:
                    user_map[u]["queries_today"] += 1
                    if r.get("status") == "failed":
                        user_map[u]["failed_today"] += 1
                if user_map[u]["last_seen"] is None or started > user_map[u]["last_seen"]:
                    user_map[u]["last_seen"] = started
            except Exception:
                pass

    # Overlay live active counts
    with _user_query_lock:
        for uname, cnt in _user_query_counts.items():
            if uname not in user_map:
                user_map[uname] = {"username": uname, "queries_today": 0, "last_seen": None,
                                   "active_now": cnt, "failed_today": 0}
            else:
                user_map[uname]["active_now"] = cnt

    return sorted(user_map.values(), key=lambda x: x["active_now"], reverse=True)


@app.get("/api/admin/query-eta")
async def get_query_eta(connection_id: Optional[int] = None,
                        _user: dict = Depends(_get_current_user)):
    """Return estimated execution time (seconds) based on recent completed executions.
    Optionally scoped to a specific connection_id for a more accurate estimate.
    """
    from datetime import datetime, timezone as _tz
    recent = db_manager.list_executions(limit=200, status="completed")
    durations = []
    for r in recent:
        s = r.get("started_at")
        c = r.get("completed_at")
        if not s or not c:
            continue
        # Filter by connection if requested
        if connection_id is not None:
            qcfg = r.get("query_config") or {}
            if qcfg.get("connection_id") != connection_id:
                continue
        try:
            dt_s = datetime.fromisoformat(s)
            dt_c = datetime.fromisoformat(c)
            if dt_s.tzinfo is None: dt_s = dt_s.replace(tzinfo=_tz.utc)
            if dt_c.tzinfo is None: dt_c = dt_c.replace(tzinfo=_tz.utc)
            secs = (dt_c - dt_s).total_seconds()
            if 0 < secs < 3600:  # ignore outliers > 1hr
                durations.append(secs)
        except Exception:
            pass
    if not durations:
        return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}
    durations.sort()
    # Use 75th percentile as the estimate (more conservative than mean)
    p75_idx = int(len(durations) * 0.75)
    avg = sum(durations) / len(durations)
    p75 = durations[min(p75_idx, len(durations) - 1)]
    return {
        "avg_seconds":  round(avg, 1),
        "p75_seconds":  round(p75, 1),
        "min_seconds":  round(min(durations), 1),
        "max_seconds":  round(max(durations), 1),
        "sample_count": len(durations),
        "connection_id": connection_id,
    }


@app.delete("/api/admin/queries/{execution_id}")
async def admin_cancel_execution(execution_id: str, _user: dict = Depends(_get_current_user)):
    """Admin-level cancel — no ownership check. Uses same cancel machinery."""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution.get("status") not in ("pending", "processing"):
            return {"execution_id": execution_id,
                    "message": f"Already {execution.get('status')}"}

        cancel_event = _cancellation_flags.get(execution_id)
        if cancel_event:
            cancel_event.set()
        task = _running_tasks.get(execution_id)
        if task and not task.done():
            task.cancel()

        cancelled_by = (_user or {}).get("username", "admin")
        db_manager.update_execution(execution_id, status="cancelled",
                                    error_message=f"Cancelled by admin: {cancelled_by}")
        await ws_manager.broadcast({
            "type":         "execution_cancelled",
            "execution_id": execution_id,
            "cancelled_by": cancelled_by,
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
        _audit(_user, "admin_cancel_query", None, "execution", execution_id,
               {"cancelled_user": execution.get("executed_by")})
        return {"execution_id": execution_id, "message": "Cancelled by admin"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# S3 Configuration Endpoints

@app.post("/api/s3/configure")
async def configure_s3(config: S3ConfigModel):
    """Configure or update S3 connection"""
    try:
        s3_config = build_s3_config(config.model_dump())
        
        engine.set_s3_config(s3_config)
        
        # Test connection
        test_result = engine.s3_handler.test_connection()
        
        return {
            "message": "S3 configured successfully",
            "connection_test": test_result
        }
    except Exception as e:
        logger.error(f"Error configuring S3: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/test")
async def test_s3_connection():
    """Test S3 connection"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        result = engine.s3_handler.test_connection()
        return result
    except Exception as e:
        logger.error(f"Error testing S3 connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/folders")
async def list_s3_folders(prefix: str = ""):
    """List folders in S3 bucket"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        folders = engine.list_s3_folders(prefix)
        return folders
    except Exception as e:
        logger.error(f"Error listing S3 folders: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/s3/files")
async def list_s3_files(folder: str = ""):
    """List parquet files in S3 folder"""
    if not engine.s3_handler:
        raise HTTPException(status_code=400, detail="S3 not configured")
    
    try:
        files = engine.list_s3_files(folder)
        return files
    except Exception as e:
        logger.error(f"Error listing S3 files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# File Management Endpoints

@app.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = ""):
    """List all available parquet files from local and/or S3"""
    try:
        files = engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str):
    """Get schema information for a specific file"""
    try:
        schema = engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error(f"Error getting file schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...), _user: dict = Depends(_get_current_user)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")
        
        file_path = Path(engine.base_path) / file.filename
        
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"File uploaded: {file.filename}")
        
        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Query Management Endpoints (same as before)
@app.post("/api/queries")
async def create_query(req: Request, request: SaveQueryRequest, _user: dict = Depends(_get_current_user)):
    """Save a new query"""
    try:
        # Do NOT validate file existence here — files may be on S3 or remote paths
        # that aren't accessible from the server at save time. Validation runs at
        # execution time when the engine actually needs the files.
        query = db_manager.create_query(
            name=request.name,
            description=request.description,
            query_config=request.query_config.model_dump(),
            created_by=request.created_by
        )
        _audit(_user, "save_query", req, "query", query["id"], {"name": request.name})
        logger.info(f"Query saved: {query['id']}")
        return query
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0,
                       request: Request = None):
    """List saved queries — filtered by owner when auth=ad and user is not admin."""
    try:
        queries = db_manager.list_queries(active_only=active_only, limit=limit, offset=offset)
        # Row-level security: non-admin AD users only see their own queries
        if _auth_cfg.type == "ad" and request:
            user = _get_current_user(request)
            if not user.get("is_admin"):
                queries = [q for q in queries if q.get("created_by") == user.get("username")]
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


@app.post("/api/execute/preview-sql")
async def preview_sql(request: PreviewSqlRequest, _user: dict = Depends(_get_current_user)):
    """Generate the actual SQL that would be executed for a given query config.
    Returns DuckDB read_parquet SQL for parquet connections, or native SQL for SQL connectors."""
    try:
        engine_config = convert_query_config_to_engine(request.query_config)
        if request.connection_id:
            conn = db_manager.get_connection_raw(request.connection_id)
            if conn:
                conn_type = conn.get('connection_type')
                cfg = conn.get('config', {})
                if conn_type in SQL_CONNECTOR_TYPES:
                    table_ref = request.query_config.files[0] if request.query_config.files else ""
                    sql = engine.build_query_sql(engine_config, table_ref)
                    return {"sql": sql, "dialect": conn_type}
                elif conn_type == 'local':
                    local_path = str(_normalize_path(cfg.get('base_path', './data/parquet')))
                    local_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
                    sql = local_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
                elif conn_type == 's3':
                    s3_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(cfg),
                    )
                    sql = s3_engine.get_duckdb_sql(engine_config)
                    return {"sql": sql, "dialect": "duckdb"}
        sql = engine.get_duckdb_sql(engine_config)
        return {"sql": sql, "dialect": "duckdb"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks, _user: dict = Depends(_get_current_user)):
    """Execute a query (saved or ad-hoc)"""
    try:
        if request.query_config:
            # Client passes an explicit (possibly parameterised) query config — use it.
            # query_id may also be set for audit/tracking purposes; that is fine.
            query_config_model = request.query_config
        elif request.query_id:
            saved_query = db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.raw_sql:
            # SQL editor mode — no visual query config needed
            query_config_model = QueryConfigModel(files=[])
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id, query_config, or raw_sql must be provided"
            )

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except Exception:
            pass   # non-fatal — proceed with original filters

        # Resolve engine based on connection type
        # Explicit request.connection_id takes priority; fall back to connection_id stored in saved query
        _effective_conn_id = request.connection_id or query_config_model.connection_id
        active_engine = engine
        if _effective_conn_id:
            conn_record = db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})
                if _conn_type == 'local':
                    local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
                    active_engine = ParquetQueryEngine(
                        base_path=local_path,
                        chunk_size=_qe_cfg.chunk_size,
                    )
                elif _conn_type == 's3':
                    active_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(_cfg),
                    )
                elif _conn_type in SQL_CONNECTOR_TYPES:
                    # ── SQL connector execution path ──────────────────────────
                    # Build SQL from the query config and dispatch to the connector.
                    # Bypass parquet validation — there are no local files to check.
                    sql_connector = get_connector(_conn_type, _cfg)
                    if request.raw_sql:
                        sql_str = request.raw_sql
                    else:
                        engine_config = convert_query_config_to_engine(query_config_model)
                        table_ref = query_config_model.files[0] if query_config_model.files else None
                        if not table_ref:
                            raise HTTPException(status_code=400, detail="No table specified in query config")
                        sql_str = engine.build_query_sql(engine_config, table_ref)

                    _username = _user.get("username", "guest") if _user else "guest"
                    with _user_query_lock:
                        _active = _user_query_counts.get(_username, 0)
                        if _active >= _qe_cfg.max_concurrent_per_user:
                            raise HTTPException(
                                status_code=429,
                                detail=f"Too many concurrent queries ({_active} running)."
                            )
                        _user_query_counts[_username] = _active + 1
                    try:
                        execution_id = str(uuid.uuid4())
                        execution = db_manager.create_execution(
                            execution_id=execution_id,
                            query_id=request.query_id,
                            query_config=query_config_model.model_dump(),
                            executed_by=request.executed_by or _username
                        )
                        _task = asyncio.create_task(
                            execute_sql_connector_background(
                                execution_id, sql_connector, sql_str,
                                query_id=request.query_id, executed_by=_username,
                            )
                        )
                        _running_tasks[execution_id] = _task
                        _task.add_done_callback(lambda t: _running_tasks.pop(execution_id, None))
                    except Exception:
                        with _user_query_lock:
                            _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                        raise
                    _audit(_user, "execute_sql_connector_query", None, "execution", execution_id,
                           {"conn_type": _conn_type, "table": table_ref, "query_id": request.query_id})
                    logger.info(f"SQL connector query started: {execution_id} ({_conn_type}:{table_ref})")
                    return {
                        "execution_id": execution_id,
                        "status": "pending",
                        "started_at": execution["started_at"],
                        "message": f"SQL connector query started ({_conn_type})"
                    }

        engine_config = convert_query_config_to_engine(query_config_model)

        # ── Cross-connection join / union path ────────────────────────────────
        if request.secondary_connection_id and request.secondary_query_config:
            # Validate secondary connection exists
            sec_conn_record = db_manager.get_connection_raw(request.secondary_connection_id)
            if not sec_conn_record:
                raise HTTPException(
                    status_code=404,
                    detail=f"Secondary connection {request.secondary_connection_id} not found"
                )

            # Validate secondary query config is parseable
            try:
                sec_qc_model = QueryConfigModel(**request.secondary_query_config)
            except Exception as _pve:
                raise HTTPException(status_code=400,
                                    detail=f"Invalid secondary_query_config: {_pve}")

            # Validate join_config present when mode=join
            if request.combine_mode == "join":
                _jc = request.join_config or {}
                if not _jc.get("left_on") or not _jc.get("right_on"):
                    raise HTTPException(
                        status_code=400,
                        detail="join_config with left_on and right_on is required when combine_mode='join'"
                    )

            # Resolve secondary engine
            secondary_engine = engine
            _sc_type = sec_conn_record.get('connection_type')
            _sc_cfg = sec_conn_record.get('config', {})
            if _sc_type == 'local':
                _sc_path = str(_normalize_path(_sc_cfg.get('base_path', './data/parquet')))
                secondary_engine = ParquetQueryEngine(
                    base_path=_sc_path,
                    chunk_size=_qe_cfg.chunk_size,
                )
            elif _sc_type == 's3':
                secondary_engine = ParquetQueryEngine(
                    base_path=str(_paths.parquet_dir),
                    chunk_size=_qe_cfg.chunk_size,
                    s3_config=build_s3_config(_sc_cfg),
                )

            secondary_config = convert_query_config_to_engine(sec_qc_model)

            _username = _user.get("username", "guest") if _user else "guest"
            _max_per_user = _qe_cfg.max_concurrent_per_user
            with _user_query_lock:
                _active = _user_query_counts.get(_username, 0)
                if _active >= _max_per_user:
                    raise HTTPException(
                        status_code=429,
                        detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                               "Wait for one to complete or cancel it first."
                    )
                _user_query_counts[_username] = _active + 1

            # Guard: decrement counter if task setup fails after increment
            try:
                execution_id = str(uuid.uuid4())
                execution = db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by or _username
                )
                _task = asyncio.create_task(
                    execute_cross_query_background(
                        execution_id,
                        active_engine,
                        engine_config,
                        secondary_engine,
                        secondary_config,
                        combine_mode=request.combine_mode,
                        join_config=request.join_config,
                        query_id=request.query_id,
                        executed_by=_username,
                    )
                )
                _running_tasks[execution_id] = _task
                _task.add_done_callback(lambda t: _running_tasks.pop(execution_id, None))
            except Exception:
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                raise

            _audit(_user, "execute_cross_query", None, "execution", execution_id,
                   {"query_id": request.query_id,
                    "primary_connection_id": request.connection_id,
                    "secondary_connection_id": request.secondary_connection_id,
                    "combine_mode": request.combine_mode})
            logger.info(f"Cross-connection query started: {execution_id} ({request.combine_mode})")

            return {
                "execution_id": execution_id,
                "status": "pending",
                "started_at": execution["started_at"],
                "is_cross_connection": True,
                "combine_mode": request.combine_mode,
                "message": f"Cross-connection {request.combine_mode.upper()} query started"
            }

        # ── Single-source path (original) ─────────────────────────────────────
        # Run validate_query off the event loop — it reads file schemas from disk
        # and can take 100 ms – 2 s per file, which would stall all other requests.
        _loop = asyncio.get_running_loop()
        validation = await _loop.run_in_executor(
            query_executor, active_engine.validate_query, engine_config
        )
        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={"message": "Invalid query configuration", "errors": validation["errors"]}
            )

        # ── Query result cache check ──────────────────────────────────────────
        # Only cache ad-hoc / saved_query executions (not custom connection queries)
        if not _effective_conn_id:
            from core.query_cache import make_cache_key, get_cached_result
            _cache_key = make_cache_key(query_config_model.model_dump())
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                db_manager.update_execution(execution_id, status="completed",
                                            output_file=str(_cached_path))
                db_manager.create_download_file(
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_path.stat().st_size,
                    expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                )
                await ws_manager.broadcast({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # Per-user concurrent query limit
        _username = _user.get("username", "guest") if _user else "guest"
        _max_per_user = _qe_cfg.max_concurrent_per_user
        with _user_query_lock:
            _active = _user_query_counts.get(_username, 0)
            if _active >= _max_per_user:
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                           "Wait for one to complete or cancel it first."
                )
            _user_query_counts[_username] = _active + 1

        # Guard: decrement counter if task setup fails after increment
        try:
            execution_id = str(uuid.uuid4())
            execution = db_manager.create_execution(
                execution_id=execution_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username
            )
            # Use create_task (not background_tasks) so queries run truly concurrently.
            _task = asyncio.create_task(
                execute_query_background(
                    execution_id,
                    engine_config,
                    request.query_id,
                    active_engine,
                    executed_by=_username,
                    raw_sql=request.raw_sql,
                )
            )
            _running_tasks[execution_id] = _task
            _task.add_done_callback(lambda t: _running_tasks.pop(execution_id, None))
        except Exception:
            with _user_query_lock:
                _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
            raise

        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads")
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0):
    """List available downloads"""
    try:
        downloads = db_manager.list_download_files(status=status, limit=limit, offset=offset)
        return downloads
    except Exception as e:
        logger.error(f"Error listing downloads: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/downloads/{file_id}")
async def download_file(file_id: str):
    """Download a file"""
    try:
        download_info = db_manager.get_download_file(file_id)
        
        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        if download_info["status"] != "available":
            raise HTTPException(status_code=410, detail="File is no longer available")
        
        file_path = Path(download_info["file_path"])
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        db_manager.increment_download_count(file_id)
        
        logger.info(f"File downloaded: {file_id}")
        
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type="text/csv"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 1. GET /api/queries/{query_id}
#    ReportPage calls api.getSavedQuery(id) to load a report by ID
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}")
async def get_query(query_id: int):
    """Get a single saved query by ID"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 2. DELETE /api/queries/{query_id}
#    SavedQueries page delete button
#    Uses db_manager.delete_query() — soft delete, sets is_active=False
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, req: Request, _user: dict = Depends(_get_current_user)):
    """Soft-delete a saved query (sets is_active=False)"""
    try:
        query = db_manager.get_query(query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        db_manager.delete_query(query_id, soft_delete=True)
        _audit(_user, "delete_query", req, "query", query_id, {"name": query.get("name")})
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# PUT /api/queries/{query_id}  — update + version snapshot
# ─────────────────────────────────────────────────────────────────────────────
class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None


@app.put("/api/queries/{query_id}")
async def update_query(query_id: int, request: UpdateQueryRequest,
                       _user: dict = Depends(_get_current_user)):
    """Update a saved query — auto-saves a version snapshot before changes."""
    try:
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only update their own queries
        if _auth_cfg.type == "ad" and not _user.get("is_admin"):
            if existing.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        # Snapshot before change
        db_manager.create_query_version(
            query_id=query_id,
            name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"],
            changed_by=_user.get("username"), change_note=request.change_note,
        )
        updates = {}
        if request.name is not None:        updates["name"] = request.name
        if request.description is not None: updates["description"] = request.description
        if request.query_config is not None:
            updates["query_config"] = request.query_config.model_dump()
        result = db_manager.update_query(query_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query {query_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Version History endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/queries/{query_id}/versions")
async def list_query_versions(query_id: int, _user: dict = Depends(_get_current_user)):
    try:
        return db_manager.list_query_versions(query_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/queries/{query_id}/versions/{version_id}/restore")
async def restore_query_version(query_id: int, version_id: int,
                                _user: dict = Depends(_get_current_user)):
    try:
        v = db_manager.get_query_version(version_id)
        if not v or v["query_id"] != query_id:
            raise HTTPException(status_code=404, detail="Version not found")
        existing = db_manager.get_query(query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # Save current state as a version before restoring
        db_manager.create_query_version(
            query_id=query_id, name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"], changed_by=_user.get("username"),
            change_note=f"Auto-saved before restore to v{v['version_number']}",
        )
        db_manager.update_query(query_id, name=v["name"], description=v["description"],
                                query_config=v["query_config"])
        return {"message": f"Restored to version {v['version_number']}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Query Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/queries/{query_id}/share")
async def share_query(query_id: int, request: ShareQueryRequest,
                      _user: dict = Depends(_get_current_user)):
    q = db_manager.get_query(query_id)
    if not q:
        raise HTTPException(status_code=404, detail="Query not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_share(query_id, _user.get("username"), expires_at)
    return share


@app.get("/api/queries/{query_id}/shares")
async def list_query_shares(query_id: int, _user: dict = Depends(_get_current_user)):
    return db_manager.list_shares(query_id)


@app.delete("/api/queries/{query_id}/shares/{token}")
async def revoke_share(query_id: int, token: str, _user: dict = Depends(_get_current_user)):
    db_manager.deactivate_share(token)
    return {"message": "Share revoked"}


# PUBLIC endpoint — NO auth (accessible by anyone with the link)
@app.get("/api/shared/{token}")
async def get_shared_query(token: str):
    share = db_manager.get_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception:
            pass
    db_manager.increment_share_access(token)
    q = db_manager.get_query(share["query_id"])
    if not q:
        raise HTTPException(status_code=404, detail="Query no longer exists")
    return {"query": q, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard Sharing endpoints
# ─────────────────────────────────────────────────────────────────────────────
class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


@app.post("/api/dashboards/{dashboard_id}/share")
async def share_dashboard(dashboard_id: int, request: ShareDashboardRequest,
                          _user: dict = Depends(_get_current_user)):
    d = db_manager.get_dashboard(dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = db_manager.create_dashboard_share(dashboard_id, _user.get("username"), expires_at)
    return share


@app.get("/api/shared-dashboard/{token}")
async def get_shared_dashboard(token: str):
    """Public endpoint — no auth required."""
    share = db_manager.get_dashboard_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception:
            pass
    db_manager.increment_dashboard_share_access(token)
    d = db_manager.get_dashboard(share["dashboard_id"])
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard no longer exists")
    widgets = db_manager.list_widgets(share["dashboard_id"])
    return {"dashboard": d, "widgets": widgets, "share": share}


# ─────────────────────────────────────────────────────────────────────────────
# Admin — Audit log endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/admin/audit-log")
async def get_audit_log(
    username: Optional[str] = None,
    action:   Optional[str] = None,
    limit:    int = 200,
    offset:   int = 0,
    _user: dict = Depends(_get_current_user),
):
    """Return audit log entries (admin only). Filterable by username and action."""
    if _auth_cfg.type == "ad" and not (_user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return db_manager.list_audit_log(username=username, action=action,
                                     limit=min(limit, 1000), offset=offset)


# ─────────────────────────────────────────────────────────────────────────────
# Cache management endpoints
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/cache/stats")
async def get_cache_stats(_user: dict = Depends(_get_current_user)):
    from core.query_cache import get_stats
    return get_stats()


@app.delete("/api/cache")
async def clear_cache(_user: dict = Depends(_get_current_user)):
    from core.query_cache import cleanup_expired
    count = cleanup_expired()
    return {"message": f"Removed {count} expired cache entries"}


@app.post("/api/webhooks/test")
async def test_webhook_url(body: dict, _user: dict = Depends(_get_current_user)):
    """Test a webhook URL by sending a sample notification."""
    url = body.get("url", "")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    from core.webhook_service import test_webhook
    return test_webhook(url)


# ─────────────────────────────────────────────────────────────────────────────
# 3. DELETE /api/downloads/{file_id}
#    Downloads page delete button
#    Uses update_download_file() to set status='deleted', removes file from disk
# ─────────────────────────────────────────────────────────────────────────────
@app.delete("/api/downloads/{file_id}")
async def delete_download(file_id: str, _user: dict = Depends(_get_current_user)):
    """Mark a download as deleted and remove from disk"""
    try:
        download = db_manager.get_download_file(file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")

        # Remove file from disk if it exists
        file_path = Path(download["file_path"])
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        db_manager.update_download_file(file_id, status="deleted")

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 4. GET /api/executions
#    ExecutionHistory component — list recent executions
#    Uses list_executions(limit, offset, status) — all params optional
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions")
async def list_executions(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = None
):
    """List recent query executions"""
    try:
        executions = db_manager.list_executions(
            limit=limit,
            offset=offset,
            status=status if status else None
        )
        return executions
    except Exception as e:
        logger.error(f"Error listing executions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 5. GET /api/executions/{execution_id}
#    Single execution detail — used by ExecutionHistory detail view
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str):
    """Get a single execution record by ID"""
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 6. GET /api/executions/{execution_id}/status
#    ReportPage polls this every 2 seconds to know when query finishes
#    Uses get_execution() — already tracked by execute_query_background()
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str):
    """
    Get status of an execution — polled by ReportPage.
    Returns: { execution_id, status, total_rows, started_at, completed_at, error_message }
    status values: pending | processing | completed | failed
    """
    try:
        execution = db_manager.get_execution(execution_id)

        if not execution:
            # Not in DB yet (just started) — check downloads as fallback
            downloads = db_manager.list_download_files(status="available", limit=500, offset=0)
            match = next(
                (d for d in downloads if d.get("execution_id") == execution_id),
                None
            )
            if match:
                return {
                    "execution_id": execution_id,
                    "status": "completed",
                    "file_id": match["file_id"],
                    "filename": match["filename"],
                    "total_rows": None,
                }
            return {"execution_id": execution_id, "status": "pending"}

        return {
            "execution_id": execution_id,
            "status": execution.get("status", "unknown"),
            "total_rows": execution.get("total_rows"),
            "started_at": execution.get("started_at"),
            "completed_at": execution.get("completed_at"),
            "error_message": execution.get("error_message"),
        }

    except Exception as e:
        logger.error(f"Error getting execution status {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: The data_grid_api router already adds these routes via include_router:
#   GET /api/executions/{execution_id}/results  (pagination)
#   GET /api/executions/{execution_id}/export   (csv/excel/json)
#   GET /api/executions/{execution_id}/stats    (column stats)
# ─────────────────────────────────────────────────────────────────────────────


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """
    Cancel a running execution.
    Works by:
      1. Setting the threading.Event — stops the worker thread after the current chunk.
      2. Cancelling the asyncio.Task — stops the coroutine waiting on run_in_executor.
      3. Marking the DB record as cancelled immediately.
    """
    try:
        execution = db_manager.get_execution(execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # 1. Signal the worker thread to stop between chunks
        cancel_event = _cancellation_flags.get(execution_id)
        if cancel_event:
            cancel_event.set()
            logger.info(f"Set cancellation flag for execution {execution_id}")

        # 2. Cancel the asyncio task (stops it from waiting on the executor)
        task = _running_tasks.get(execution_id)
        if task and not task.done():
            task.cancel()
            logger.info(f"Cancelled asyncio task for execution {execution_id}")

        # 3. Mark as cancelled in DB immediately (don't wait for thread to stop)
        db_manager.update_execution(
            execution_id,
            status="cancelled",
            error_message="Cancelled by user"
        )

        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        db_manager.audit("system", "cancel_query", resource_type="execution",
                         resource_id=execution_id)
        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# 8. FIX: Downloads page shows EVERY query execution
#
# ROOT CAUSE: execute_query_background() calls db_manager.create_download_file()
# after every execution, so ALL results appear in the Downloads page.
#
# Downloads should only show EXPLICIT exports (xlsx/json/csv the user requested).
#
# SOLUTION: In execute_query_background(), change create_download_file to use
# status="internal" instead of status="available":
#
#   db_manager.create_download_file(
#       file_id=file_id,
#       execution_id=execution_id,
#       filename=f"query_result_{execution_id}.csv",
#       file_path=str(output_file),
#       file_size_bytes=stats["file_size_bytes"],
#       expires_at=datetime.now(timezone.utc) + timedelta(days=7),
#       # ADD THIS:
#       created_by="internal"       # ← use created_by field to tag internal files
#   )
#
# Then in list_download_files, the Downloads page already filters by status="available"
# by default — internal results use status="available" but we mark created_by="internal".
#
# SIMPLEST FIX (no DB schema change needed):
# Change the Downloads page list_downloads route filter to exclude internal records:
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/exports")
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').
    """
    try:
        all_files = db_manager.list_download_files(status=status, limit=limit*3, offset=0)
        # Exclude internal auto-generated results
        exports = [f for f in all_files if f.get("created_by") != "internal"]
        return exports[:limit]
    except Exception as e:
        logger.error(f"Error listing exports: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    
# ─────────────────────────────────────────────────────────────────────────────
# Connection Manager Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/connections")
async def list_connections(active_only: bool = True):
    """List all connections"""
    try:
        return db_manager.list_connections(active_only=active_only)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections")
async def create_connection(request: ConnectionConfigModel, _user: dict = Depends(_get_current_user)):
    """Create a new connection"""
    try:
        return db_manager.create_connection(
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@app.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest):
    """Test a connection configuration without saving — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_type = request.connection_type
    conn_cfg  = dict(request.config)

    # When editing a saved connection the browser sends "***" for any sensitive
    # field the user did not change.  Substitute those placeholders with the
    # real (decrypted) values from the DB so the test uses valid credentials.
    if request.connection_id is not None:
        raw = db_manager.get_connection_raw(request.connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            for k, v in conn_cfg.items():
                if v == "***" and k in raw_cfg:
                    conn_cfg[k] = raw_cfg[k]

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_cfg)
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_cfg)
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int):
    """Get a specific connection"""
    conn = db_manager.get_connection(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@app.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel, _user: dict = Depends(_get_current_user)):
    """Update an existing connection"""
    try:
        conn = db_manager.update_connection(
            connection_id,
            name=request.name,
            connection_type=request.connection_type,
            config=request.config
        )
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int, _user: dict = Depends(_get_current_user)):
    """Delete a connection"""
    try:
        success = db_manager.delete_connection(connection_id)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        conn_manager.invalidate_cache(connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int):
    """Test a saved connection and persist the result — runs in thread so event loop stays free."""
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    # Fetch raw creds synchronously (fast SQLite read) before entering executor
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw['connection_type']

    def _do():
        if conn_type in SQL_CONNECTOR_TYPES:
            connector = get_connector(conn_type, conn_raw['config'])
            try:
                return connector.test_connection()
            finally:
                connector.close()
        return conn_manager.test_connection(conn_type, conn_raw['config'])

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(query_executor, _do)
        db_manager.update_connection(
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result.get('message', '')
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = ""):
    """List tables/files for a connection.
    - S3 / local  → parquet file listing via ConnectionManager
    - SQL connectors → list tables from the configured catalog.schema
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _list_sql_tables():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                catalog = cfg.get("catalog") or cfg.get("database") or ""
                schema  = cfg.get("schema") or "public"
                tables  = connector.list_tables(catalog, schema)
                # Normalise to the same shape the frontend expects for file items
                result = []
                for t in tables:
                    tname = t["name"]
                    full_path = f"{catalog}.{schema}.{tname}" if catalog else f"{schema}.{tname}"
                    result.append({
                        "name":       tname,
                        "path":       full_path,
                        "folder":     f"{catalog}/{schema}" if catalog else schema,
                        "num_rows":   None,
                        "num_columns": None,
                        "size_bytes": None,
                        "table_type": t.get("type", "TABLE"),
                    })
                return result
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(query_executor, _list_sql_tables)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.list_files, connection_id, folder
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str):
    """Get schema for a file or SQL table.
    - S3 / local  → parquet metadata via ConnectionManager
    - SQL connectors → list_columns(catalog, schema, table)
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _sql_schema():
            cfg = conn_raw["config"]
            connector = get_connector(conn_type, cfg)
            try:
                # file_path is "catalog.schema.table" or "schema.table"
                parts = file_path.split(".")
                if len(parts) == 3:
                    catalog, schema, table = parts
                elif len(parts) == 2:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema, table = parts
                else:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema  = cfg.get("schema") or "public"
                    table   = file_path
                cols = connector.list_columns(catalog, schema, table)
                return {"columns": cols}
            finally:
                connector.close()

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(query_executor, _sql_schema)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            query_executor, conn_manager.get_schema, connection_id, file_path
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Iceberg S3 Endpoints
# ─────────────────────────────────────────────────────────────────────────────

def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config."""
    import boto3
    cfg = conn_raw.get('config', {})
    kwargs = {
        'region_name': cfg.get('region_name', 'us-east-1'),
    }
    if cfg.get('aws_access_key_id'):
        kwargs['aws_access_key_id']     = cfg['aws_access_key_id']
        kwargs['aws_secret_access_key'] = cfg.get('aws_secret_access_key', '')
    if cfg.get('endpoint_url'):
        kwargs['endpoint_url'] = cfg['endpoint_url']
    return boto3.client('s3', **kwargs)


@app.get("/api/connections/{connection_id}/iceberg/tables")
async def list_iceberg_tables(connection_id: int, prefix: str = ""):
    """
    Scan an S3 prefix for Iceberg table directories — runs in thread (S3 listing is blocking).
    Returns list of {name, prefix, type='iceberg_table', path} dicts.
    """
    from core.iceberg_reader import list_iceberg_tables as _list_iceberg_tables
    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']
    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        tables = _list_iceberg_tables(s3, bucket, prefix)
        return {"tables": tables, "bucket": bucket, "prefix": prefix}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error listing Iceberg tables: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/connections/{connection_id}/iceberg/files")
async def list_iceberg_files(
    connection_id: int,
    table_prefix: str,
    partition_filter: Optional[str] = None,   # JSON: [{"col":"business_date","op":"equals","val":"${today}"}]
):
    """
    Read an Iceberg table's metadata chain — runs in thread (Avro + S3 reads are blocking).
    Returns list of {key, name, path, size_bytes, last_modified, folder, type='parquet'}.

    Optional partition_filter (JSON array) enables server-side manifest pruning so only
    files for the relevant partition(s) are returned.  Date expressions (${today}, etc.)
    in filter values are resolved at request time.
    """
    from core.iceberg_reader import get_iceberg_data_files
    from core.date_resolver import resolve_filter_dates
    import json as _json

    conn_raw = db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']

    pfilters = None
    if partition_filter:
        try:
            pfilters = resolve_filter_dates(_json.loads(partition_filter))
        except Exception:
            pass

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        files = get_iceberg_data_files(s3, bucket, table_prefix, partition_filters=pfilters)
        return {"files": files, "bucket": bucket, "table_prefix": table_prefix, "count": len(files)}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(query_executor, _do)
    except Exception as e:
        logger.error("Error reading Iceberg data files: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # Start APScheduler (non-fatal — server starts regardless)
    from core.scheduler import init_scheduler
    import threading as _threading

    def _start_scheduler():
        try:
            init_scheduler(db_manager, ws_manager, loop,
                           db_url=_DB_URL)
        except Exception as exc:
            logger.error("APScheduler startup failed (non-fatal): %s", exc)

    _threading.Thread(target=_start_scheduler, daemon=True).start()


@app.on_event("shutdown")
async def _shutdown():
    logger.info("Shutdown: draining %d in-flight queries (10 s grace)…", len(_running_tasks))
    # Signal all threads to stop at next chunk boundary
    for _ev in list(_cancellation_flags.values()):
        _ev.set()
    # Cancel all asyncio tasks
    _pending = [t for t in _running_tasks.values() if not t.done()]
    for t in _pending:
        t.cancel()
    if _pending:
        await asyncio.gather(*_pending, return_exceptions=True)

    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()
    query_executor.shutdown(wait=True, cancel_futures=True)


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        logger.warning("WebSocket connection closed unexpectedly: %s", e)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    await _handle_ws(websocket)


# ── SPA catch-all — MUST be the last HTTP route registered ───────────────────
# Serves index.html for all browser navigation routes that don't match any API
# endpoint.  WebSocket routes (/ws) are unaffected (different protocol).
if _STATIC_DIR:
    @app.get("/", include_in_schema=False)
    async def _spa_root():
        return FileResponse(str(_STATIC_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def _spa_catch_all(full_path: str):
        return FileResponse(str(_STATIC_DIR / "index.html"))
else:
    @app.get("/")
    async def _api_root():
        return {
            "name": "QueryStudio API",
            "version": "2.0.0",
            "status": "operational",
            "note": "Build the frontend (`npm run build` in frontend/) to enable SPA serving.",
        }


if __name__ == "__main__":
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    uvicorn.run(
        app,
        host=_server_cfg.host,
        port=_server_cfg.port,
        log_level=_server_cfg.log_level,
        workers=_server_cfg.workers,
    )
