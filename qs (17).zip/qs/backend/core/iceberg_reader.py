"""
Iceberg table reader for S3.

Reads Apache Iceberg v1/v2 table metadata stored on S3 to discover the
active set of Parquet data files for a given table snapshot.

Flow:
  1. Scan S3 prefix for directories that contain a metadata/ subfolder
     with *.metadata.json files → those are Iceberg tables.
  2. Read the latest metadata.json to get current-snapshot-id.
  3. Follow the manifest-list (Avro) → manifest files (Avro) → data file paths.
  4. Return S3 keys for all ADDED/EXISTING Parquet data files.

Partition pruning (enterprise feature):
  Pass partition_filters=[{"col":"business_date","op":"equals","val":"2024-01-15"}]
  to get_iceberg_data_files().  The reader decodes per-manifest partition bounds
  from the Avro manifest-list and skips manifests (and their data files) that
  cannot possibly match the filter — dramatically reducing S3 API calls and
  latency for large tables.

Supported partition bound types:  string, date, int, long, float, double,
  timestamp (µs since epoch).

Requires: fastavro (for Avro manifest reading)
"""

from __future__ import annotations

import io
import json
import logging
import struct
from datetime import date, datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── S3 URI helpers ────────────────────────────────────────────────────────────

def _s3_uri_to_key(uri: str) -> str:
    """Convert s3://bucket/key  or  s3a://bucket/key  →  key only."""
    for scheme in ("s3a://", "s3n://", "s3://"):
        if uri.startswith(scheme):
            path = uri[len(scheme):]
            slash = path.find("/")
            return path[slash + 1:] if slash >= 0 else ""
    return uri  # already a bare key


def _read_s3_bytes(s3_client, bucket: str, key: str) -> bytes:
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    return obj["Body"].read()


def _read_s3_json(s3_client, bucket: str, key: str) -> dict:
    return json.loads(_read_s3_bytes(s3_client, bucket, key))


def _read_avro(data: bytes) -> List[dict]:
    """Deserialise an Avro byte stream using fastavro."""
    try:
        import fastavro
        return list(fastavro.reader(io.BytesIO(data)))
    except ImportError:
        raise RuntimeError(
            "fastavro is required for Iceberg manifest reading. "
            "Install it with: pip install fastavro>=1.9.0"
        )


# ── Table detection ───────────────────────────────────────────────────────────

def is_iceberg_table(s3_client, bucket: str, prefix: str) -> bool:
    """Return True if the S3 prefix looks like an Iceberg table directory.

    Checks for a metadata/ subfolder containing Iceberg metadata files:
      - v1.metadata.json, 00000-xxx.metadata.json  (standard naming)
      - metadata.json  (simplified naming)
      - *.avro  (Avro manifest files used by some Iceberg writers)
    Also checks for a data/ subfolder as secondary confirmation.
    """
    meta_prefix = prefix.rstrip("/") + "/metadata/"
    try:
        resp = s3_client.list_objects_v2(
            Bucket=bucket, Prefix=meta_prefix, MaxKeys=30
        )
        for obj in resp.get("Contents", []):
            key = obj["Key"]
            basename = key.rsplit("/", 1)[-1].lower()
            # Standard: v1.metadata.json, 00001-uuid.metadata.json
            if basename.endswith(".metadata.json"):
                return True
            # Simplified: just metadata.json
            if basename == "metadata.json":
                return True
            # Avro manifest files (snap-*.avro, *.avro)
            if basename.endswith(".avro"):
                return True
    except Exception:
        pass
    return False


def list_iceberg_tables(
    s3_client, bucket: str, prefix: str = ""
) -> List[Dict[str, Any]]:
    """
    Scan one level of S3 prefix for Iceberg table directories.

    Args:
        s3_client: boto3 S3 client
        bucket:    S3 bucket name
        prefix:    S3 prefix to scan (warehouse path, e.g. "warehouse/db/")

    Returns:
        List of dicts: {name, prefix, type='iceberg_table', path}
    """
    paginator = s3_client.get_paginator("list_objects_v2")
    tables: List[Dict[str, Any]] = []

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]
                name = folder.rstrip("/").split("/")[-1]
                if is_iceberg_table(s3_client, bucket, folder):
                    tables.append({
                        "name":   name,
                        "prefix": folder,
                        "type":   "iceberg_table",
                        # virtual path consumed by the query builder
                        "path":   f"__iceberg__:{folder}",
                        "folder": prefix,
                    })
    except Exception as e:
        logger.error("Error scanning for Iceberg tables at %s: %s", prefix, e)
        raise

    logger.info("Found %d Iceberg tables under prefix '%s'", len(tables), prefix)
    return tables


# ── Partition spec + bound decoding ──────────────────────────────────────────

_EPOCH = date(1970, 1, 1)


def _decode_bound(raw: Optional[bytes], iceberg_type: str) -> Any:
    """Decode an Iceberg partition bound byte array to a Python value.

    Returns None if raw is None / empty.
    """
    if not raw:
        return None
    try:
        t = iceberg_type.lower()
        if t in ("string", "varchar", "char", "uuid"):
            return raw.decode("utf-8")
        if t == "boolean":
            return raw[0] != 0
        if t in ("int", "integer", "date"):
            val = struct.unpack_from("<i", raw)[0]
            if t == "date":
                return str(_EPOCH + timedelta(days=val))
            return val
        if t in ("long", "bigint", "time", "timestamp", "timestamptz",
                 "timestamp_tz", "timestamp with local time zone"):
            val = struct.unpack_from("<q", raw)[0]
            if t in ("timestamp", "timestamptz", "timestamp_tz",
                     "timestamp with local time zone"):
                # microseconds since epoch → ISO datetime
                try:
                    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=val)
                    return dt.isoformat()
                except Exception:
                    return val
            return val
        if t == "float":
            return struct.unpack_from("<f", raw)[0]
        if t in ("double", "decimal"):
            return struct.unpack_from("<d", raw)[0]
        # Fallback: try utf-8
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return None


def _extract_partition_spec(metadata: dict) -> Dict[str, str]:
    """Return {partition_field_name: iceberg_type} from Iceberg metadata JSON.

    Handles both v1 (top-level "schema"/"partition-spec") and
    v2 (lists "schemas"/"partition-specs" with current IDs).
    """
    # Build field_id → type map from schema(s)
    field_type: Dict[int, str] = {}
    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    for schema in schemas:
        for field in schema.get("fields", []):
            fid = field.get("id") or field.get("field-id")
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                ftype = ftype.get("type", "string")
            if fid is not None:
                field_type[fid] = str(ftype)

    # Resolve active partition spec
    specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    default_spec_id = metadata.get("default-spec-id", 0)
    active_spec = next(
        (s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {}
    )

    result: Dict[str, str] = {}
    for pf in active_spec.get("fields", []):
        name      = pf.get("name", "")
        source_id = pf.get("source-id") or pf.get("source_id")
        transform = pf.get("transform", "identity")
        if not name:
            continue
        # Only identity-transformed fields have meaningful bounds we can compare
        if transform not in ("identity", "void"):
            # For bucket/truncate/year/month/day/hour transforms the bound type
            # differs — skip for now to avoid false pruning.
            if transform not in ("year", "month", "day", "hour"):
                result[name] = field_type.get(source_id, "string")
                continue
            # date-based transforms: bounds are ints (year/month/day/hour counts)
            # Register them but mark the type so the comparator knows.
            result[name] = f"_transform_{transform}"
            continue
        result[name] = field_type.get(source_id, "string")

    return result


# ── Partition filter evaluation ───────────────────────────────────────────────

def _manifest_matches_filters(
    manifest_entry: dict,
    partition_spec: Dict[str, str],
    filters: List[Dict[str, Any]],
) -> bool:
    """Return False only if we can *prove* no data file in this manifest satisfies
    all filters.  Returns True when uncertain (safe over-approximation).

    manifest_entry fields (from Avro manifest-list):
      partitions: list<{lower_bound: bytes, upper_bound: bytes, contains_null: bool}>
    """
    parts = manifest_entry.get("partitions")
    if not parts:
        return True   # no partition metadata → can't prune → keep manifest

    spec_fields = list(partition_spec.items())   # ordered: name, type

    for filt in filters:
        col = filt.get("col") or filt.get("column", "")
        op  = filt.get("op")  or filt.get("operator", "")
        val = filt.get("val") or filt.get("value", "")

        # Find index of this column in partition spec
        spec_idx = next(
            (i for i, (n, _) in enumerate(spec_fields) if n == col), None
        )
        if spec_idx is None or spec_idx >= len(parts):
            continue  # column not partitioned → can't prune on it

        ptype = spec_fields[spec_idx][1]
        pbounds = parts[spec_idx]
        lo_raw = pbounds.get("lower_bound")
        hi_raw = pbounds.get("upper_bound")
        has_null = pbounds.get("contains_null", False)

        lo = _decode_bound(lo_raw, ptype) if lo_raw else None
        hi = _decode_bound(hi_raw, ptype) if hi_raw else None

        if lo is None and hi is None:
            continue   # no bounds info → keep

        # Convert filter value to comparable type
        try:
            cval: Any = val
            if ptype in ("int", "integer") or ptype.startswith("_transform_"):
                cval = int(val)
            elif ptype in ("long", "bigint"):
                cval = int(val)
            elif ptype in ("float",):
                cval = float(val)
            elif ptype in ("double", "decimal"):
                cval = float(val)
        except (ValueError, TypeError):
            cval = str(val)

        # Apply operator check — if we can PROVE the manifest doesn't match, prune
        try:
            if op in ("equals", "eq", "=", "=="):
                if lo is not None and cval < lo:
                    return False
                if hi is not None and cval > hi:
                    return False
            elif op in ("not_equals", "ne", "!="):
                pass   # Can't prune safely on ≠
            elif op in ("gt", ">"):
                if hi is not None and cval >= hi and not has_null:
                    return False
            elif op in ("gte", ">="):
                if hi is not None and cval > hi and not has_null:
                    return False
            elif op in ("lt", "<"):
                if lo is not None and cval <= lo and not has_null:
                    return False
            elif op in ("lte", "<="):
                if lo is not None and cval < lo and not has_null:
                    return False
        except TypeError:
            pass  # incomparable types → keep

    return True   # manifest may contain matching rows


# ── Metadata + manifest traversal ────────────────────────────────────────────

def _latest_metadata_key(s3_client, bucket: str, meta_prefix: str) -> str:
    """Return the S3 key of the most-recently-modified *.metadata.json file."""
    resp = s3_client.list_objects_v2(Bucket=bucket, Prefix=meta_prefix)
    candidates = [
        obj for obj in resp.get("Contents", [])
        if obj["Key"].endswith(".metadata.json")
    ]
    if not candidates:
        raise ValueError(f"No Iceberg metadata JSON found under {meta_prefix}")
    return max(candidates, key=lambda x: x["LastModified"])["Key"]


def _batch_s3_metadata(
    s3_client, bucket: str, keys: List[str]
) -> Dict[str, Dict[str, Any]]:
    """Return {key: {size_bytes, last_modified}} for a list of S3 keys.

    Uses list_objects_v2 grouped by common prefix to minimise API calls instead
    of one head_object per file (which is O(N) round trips).
    """
    if not keys:
        return {}

    result: Dict[str, Dict[str, Any]] = {}

    # Group keys by their directory prefix (everything up to the last /)
    from collections import defaultdict
    prefix_map: Dict[str, List[str]] = defaultdict(list)
    for key in keys:
        slash = key.rfind("/")
        prefix = key[: slash + 1] if slash >= 0 else ""
        prefix_map[prefix].append(key)

    for prefix, prefix_keys in prefix_map.items():
        key_set = set(prefix_keys)
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    k = obj["Key"]
                    if k in key_set:
                        result[k] = {
                            "size_bytes":    obj["Size"],
                            "last_modified": obj["LastModified"].isoformat(),
                        }
        except Exception as exc:
            logger.warning("list_objects_v2 failed for prefix %s: %s", prefix, exc)
            # Fall back to individual HEAD for this batch
            for k in prefix_keys:
                try:
                    head = s3_client.head_object(Bucket=bucket, Key=k)
                    result[k] = {
                        "size_bytes":    head["ContentLength"],
                        "last_modified": head["LastModified"].isoformat(),
                    }
                except Exception:
                    result[k] = {"size_bytes": 0, "last_modified": ""}

    return result


def get_iceberg_data_files(
    s3_client,
    bucket: str,
    table_prefix: str,
    partition_filters: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """
    Read Iceberg table metadata and return the active Parquet data files.

    Args:
        s3_client:         boto3 S3 client
        bucket:            S3 bucket name
        table_prefix:      S3 prefix of the Iceberg table root (ends with /)
        partition_filters: Optional list of filter dicts in adv_filters format
                           e.g. [{"col":"business_date","op":"equals","val":"2024-01-15"}]
                           Used to prune manifests via Iceberg partition bounds.

    Returns:
        List of dicts: {key, name, path, size_bytes, last_modified, folder, type}
    """
    meta_prefix = table_prefix.rstrip("/") + "/metadata/"

    # ── Step 1: Read latest table metadata JSON ───────────────────────────────
    meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
    metadata = _read_s3_json(s3_client, bucket, meta_key)
    logger.info("Iceberg metadata: %s (format-version %s)",
                meta_key, metadata.get("format-version", "?"))

    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        logger.warning("Table %s has no current snapshot — returning empty", table_prefix)
        return []

    snapshots = {s["snapshot-id"]: s for s in metadata.get("snapshots", [])}
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        raise ValueError(
            f"Snapshot {current_snapshot_id} not found in {meta_key}"
        )

    # ── Step 2: Parse partition spec (needed for pruning) ─────────────────────
    partition_spec: Dict[str, str] = {}
    use_pruning = bool(partition_filters)
    if use_pruning:
        try:
            partition_spec = _extract_partition_spec(metadata)
            logger.info(
                "Iceberg partition spec for %s: %s", table_prefix,
                {k: v for k, v in partition_spec.items()}
            )
        except Exception as exc:
            logger.warning("Could not parse partition spec — pruning disabled: %s", exc)
            use_pruning = False

    # ── Step 3: Read manifest list ────────────────────────────────────────────
    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        manifest_list_data = _read_s3_bytes(s3_client, bucket, ml_key)
        manifests = _read_avro(manifest_list_data)
    else:
        manifests = snapshot.get("manifests", [])

    # ── Step 4: Prune manifests using partition bounds ─────────────────────────
    if use_pruning and partition_spec and partition_filters:
        total = len(manifests)
        manifests = [
            m for m in manifests
            if _manifest_matches_filters(m, partition_spec, partition_filters)
        ]
        pruned = total - len(manifests)
        if pruned:
            logger.info(
                "Iceberg partition pruning: skipped %d/%d manifests for table %s",
                pruned, total, table_prefix,
            )

    # ── Step 5: Read each manifest and collect data file paths ────────────────
    data_file_keys: List[str] = []
    for manifest in manifests:
        manifest_path = (
            manifest.get("manifest_path")
            or manifest.get("manifest-path")
            or (manifest if isinstance(manifest, str) else None)
        )
        if not manifest_path:
            continue

        manifest_key = _s3_uri_to_key(manifest_path)
        try:
            manifest_data = _read_s3_bytes(s3_client, bucket, manifest_key)
            entries = _read_avro(manifest_data)
        except Exception as e:
            logger.warning("Could not read manifest %s: %s", manifest_key, e)
            continue

        for entry in entries:
            # status: 0=EXISTING  1=ADDED  2=DELETED
            if entry.get("status") == 2:
                continue
            data_file = entry.get("data_file") or {}
            file_path  = data_file.get("file_path") or data_file.get("path", "")
            if file_path.endswith(".parquet"):
                data_file_keys.append(_s3_uri_to_key(file_path))

    logger.info("Iceberg table %s → %d data files after pruning", table_prefix, len(data_file_keys))

    # ── Step 6: Batch-fetch S3 metadata (replaces N×head_object) ─────────────
    s3_meta = _batch_s3_metadata(s3_client, bucket, data_file_keys)

    result: List[Dict[str, Any]] = []
    for key in data_file_keys:
        meta = s3_meta.get(key, {})
        result.append({
            "key":           key,
            "name":          key.split("/")[-1],
            "path":          key,
            "size_bytes":    meta.get("size_bytes", 0),
            "last_modified": meta.get("last_modified", ""),
            "folder":        "/".join(key.split("/")[:-1]) + "/" if "/" in key else "",
            "type":          "parquet",
        })

    return result
