import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import api, { ApiError } from '../services/api';
import DataGridViewer from './DataGridViewer';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Button, ButtonGroup, Paper, Card, CardContent,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem,
  Checkbox, FormControlLabel, Chip, IconButton, Tooltip,
  CircularProgress, LinearProgress, Alert, Stack, List, ListItem,
  ListItemButton, ListItemText, ListItemIcon, Divider, InputAdornment, Collapse,
  Autocomplete,
} from '@mui/material';
import {
  TableChart as TableIcon, Link as JoinIcon, ViewColumn as ColumnIcon,
  FilterAlt as FilterIcon, PlayArrow as PlayIcon, Save as SaveIcon,
  Code as CodeIcon, Close as CloseIcon, Add as AddIcon, Delete as DeleteIcon,
  Edit as EditIcon, Warning as WarningIcon, OpenInNew as OpenInNewIcon,
  Search as SearchIcon, ChevronLeft as CollapseIcon, ChevronRight as ExpandIcon,
  FolderOpen as FolderIcon, TableRows as TableRowsIcon, Refresh as RefreshIcon,
  Functions as AggIcon, Calculate as ComputedIcon, AccountTree as WindowIcon,
  CallSplit as CaseIcon,
} from '@mui/icons-material';

const SIDEBAR_W = 248;
const fmtSecs = (s: number) => {
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60), sec = s % 60;
  return sec > 0 ? `${m}m ${sec}s` : `${m}m`;
};

const CompleteQueryBuilder = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Connection state
  const [connections, setConnections] = useState([]);
  const [selectedConnectionId, setSelectedConnectionId] = useState(null);

  // Core state
  const [allFiles, setAllFiles] = useState([]);
  const [selectedTables, setSelectedTables] = useState([]);
  const [tableSchemas, setTableSchemas] = useState({});

  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarSearch, setSidebarSearch] = useState('');
  const [expandedFolders, setExpandedFolders] = useState({});
  const [loadedFolders, setLoadedFolders] = useState<Set<string>>(new Set());
  const [loadingFolder, setLoadingFolder] = useState<string | null>(null);
  const [filesLoading, setFilesLoading] = useState(false);

  // Query building
  const [joins, setJoins] = useState([]);
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [filters, setFilters] = useState([]);
  const [orderBy, setOrderBy] = useState([]);
  const [limit, setLimit] = useState(1000);

  // Modals
  const [showTableSelector, setShowTableSelector] = useState(false);
  const [showJoinBuilder, setShowJoinBuilder] = useState(false);
  const [showColumnSelector, setShowColumnSelector] = useState(false);
  const [showFilterBuilder, setShowFilterBuilder] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showAggBuilder, setShowAggBuilder] = useState(false);
  const [aggregations, setAggregations] = useState([]);  // [{column, function, alias, distinct}]
  // Advanced SQL features
  const [distinct, setDistinct] = useState(false);
  const [filterLogic, setFilterLogic] = useState('AND');
  const [having, setHaving] = useState<any[]>([]);
  const [computedColumns, setComputedColumns] = useState<any[]>([]);
  const [caseExpressions, setCaseExpressions] = useState<any[]>([]);
  const [columnAliases, setColumnAliases] = useState<Record<string, string>>({});
  const [windowFunctions, setWindowFunctions] = useState<any[]>([]);
  const [showHavingBuilder, setShowHavingBuilder] = useState(false);
  const [showComputedBuilder, setShowComputedBuilder] = useState(false);
  const [showCaseBuilder, setShowCaseBuilder] = useState(false);
  const [showWindowBuilder, setShowWindowBuilder] = useState(false);

  // Execution
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [elapsed, setElapsed] = useState(0);         // seconds since execute
  const [etaSeconds, setEtaSeconds] = useState(null); // historical p75
  const execStartRef = useRef<number | null>(null);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [sqlPreview, setSqlPreview] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  // SQL editor mode
  const [queryMode, setQueryMode] = useState<'visual' | 'sql'>('visual');
  const [rawSql, setRawSql] = useState('');
  const [sqlLoading, setSqlLoading] = useState(false);

  // Results viewer
  const [showResults, setShowResults] = useState(false);
  const [resultsExecutionId, setResultsExecutionId] = useState(null);

  // Edit mode — set when navigated from SavedQueries with loadQuery state
  const [editingQueryId, setEditingQueryId] = useState(null);
  const [editingQueryName, setEditingQueryName] = useState('');

  // Iceberg table state (S3 connections with iceberg_warehouse_path)
  const [icebergTables, setIcebergTables] = useState([]);
  const [expandedIcebergTables, setExpandedIcebergTables] = useState({});
  const [icebergTableFiles, setIcebergTableFiles] = useState({});  // prefix → file[]
  const [icebergLoading, setIcebergLoading] = useState(false);
  const [icebergLoadingTable, setIcebergLoadingTable] = useState(null);

  // Cross-connection Union / Join (parquet files from a second connection)
  const [showCrossConn, setShowCrossConn] = useState(false);
  const [crossConnId, setCrossConnId] = useState(null);
  const [crossConnFiles, setCrossConnFiles] = useState([]);
  const [crossConnFile, setCrossConnFile] = useState(null);
  const [crossConnMode, setCrossConnMode] = useState('union'); // 'union' | 'join'
  const [crossJoinLeftOn, setCrossJoinLeftOn] = useState('');
  const [crossJoinRightOn, setCrossJoinRightOn] = useState('');
  const [crossJoinHow, setCrossJoinHow] = useState('inner');
  const [crossConnLoading, setCrossConnLoading] = useState(false);

  const { addNotification } = useNotifications();
  const { lastMessage } = useWebSocket();

  useEffect(() => {
    loadConnections();
    // loadFiles is triggered by the [selectedConnectionId] effect — no need here
  }, []);

  // Ctrl+Enter global shortcut → execute query
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        if (selectedTables.length > 0 && !executing) executeQuery();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [selectedTables, executing]);

  // Load saved query into builder when navigated from SavedQueries
  useEffect(() => {
    const loadQuery = location.state?.loadQuery;
    if (!loadQuery) return;
    const qc = loadQuery.query_config || {};

    setEditingQueryId(loadQuery.id);
    setEditingQueryName(loadQuery.name || '');

    // Reconstruct selectedTables from files array in query_config
    if (qc.files && qc.files.length > 0) {
      const tables = qc.files.map(path => ({
        path,
        name: path.split('/').pop().replace(/\.[^.]+$/, ''),
        folder: path.includes('/') ? path.substring(0, path.lastIndexOf('/')) : '',
      }));
      setSelectedTables(tables);
    }

    // Reconstruct joins
    if (qc.joins && qc.joins.length > 0) {
      setJoins(qc.joins.map((j, i) => ({
        id: Date.now() + i,
        leftTable:   j.left_file,
        rightTable:  j.right_file,
        leftColumn:  Array.isArray(j.left_on)  ? j.left_on[0]  : j.left_on,
        rightColumn: Array.isArray(j.right_on) ? j.right_on[0] : j.right_on,
        joinType:    j.how || 'inner',
      })));
    }

    // Reconstruct columns
    if (qc.columns && qc.columns.length > 0) {
      setSelectedColumns(qc.columns.map(col => {
        const parts = col.split('.');
        return parts.length === 2
          ? { tableName: parts[0], columnName: parts[1] }
          : { tableName: '', columnName: col };
      }));
    }

    // Reconstruct filters
    if (qc.filters && qc.filters.length > 0) {
      setFilters(qc.filters.map((f, i) => {
        const base: any = { id: Date.now() + i, column: f.column, operator: f.operator };
        if (f.operator === 'between' && Array.isArray(f.value)) {
          base.value_low = f.value[0]; base.value_high = f.value[1]; base.value = '';
        } else {
          base.value = Array.isArray(f.value) ? f.value.join(', ') : (f.value ?? '');
        }
        return base;
      }));
    }

    // Reconstruct order by
    if (qc.order_by && qc.order_by.length > 0) {
      setOrderBy(qc.order_by.map(o => ({ column: o.column, direction: o.direction || 'asc' })));
    }

    if (qc.limit) setLimit(qc.limit);

    // Reconstruct aggregations
    if (qc.aggregations?.length > 0) {
      setAggregations(qc.aggregations.map((a: any) => ({
        column: a.column, function: a.function,
        alias: a.alias || '', distinct: a.distinct || false,
      })));
    }
    // Reconstruct advanced SQL features
    if (qc.distinct) setDistinct(true);
    if (qc.filter_logic) setFilterLogic(qc.filter_logic);
    if (qc.having?.length > 0) setHaving(qc.having);
    if (qc.computed_columns?.length > 0) setComputedColumns(qc.computed_columns);
    if (qc.case_expressions?.length > 0) setCaseExpressions(qc.case_expressions);
    if (qc.column_aliases) setColumnAliases(qc.column_aliases);
    if (qc.window_functions?.length > 0) setWindowFunctions(qc.window_functions);

    addNotification({ type: 'info', title: 'Query Loaded', message: `Editing "${loadQuery.name}"` });

    // Clear the router state so a refresh doesn't re-apply
    navigate('/', { replace: true, state: {} });
  }, [location.state?.loadQuery]);

  // Reload file list when connection changes
  useEffect(() => {
    setSelectedTables([]);
    setTableSchemas({});
    setSidebarSearch('');
    setIcebergTables([]);
    setIcebergTableFiles({});
    setExpandedIcebergTables({});
    setLoadedFolders(new Set());
    setExpandedFolders({});
    loadFiles();
    // Load Iceberg tables if this is an S3 connection with a warehouse path configured
    const conn = connections.find(c => c.id === selectedConnectionId);
    const warehousePath = conn?.config?.iceberg_warehouse_path;
    if (conn?.connection_type === 's3' && warehousePath) {
      loadIcebergTablesForConn(selectedConnectionId, warehousePath);
    }
  }, [selectedConnectionId]);

  useEffect(() => {
    if (selectedTables.length > 0) loadSchemas();
  }, [selectedTables]);

  useEffect(() => {
    generateSQLPreview();
  }, [selectedTables, joins, selectedColumns, filters, orderBy, limit, aggregations,
      distinct, filterLogic, having, computedColumns, caseExpressions, columnAliases, windowFunctions]);

  useEffect(() => {
    if (lastMessage && lastMessage.execution_id === executionId) {
      handleProgress(lastMessage);
    }
  }, [lastMessage]);

  const loadConnections = async () => {
    try {
      const conns = await api.listConnections(true);
      setConnections(conns || []);
    } catch {}
  };

  const loadFiles = async (folder = '') => {
    // Only show full spinner for root load; folder expansions use per-folder state
    if (!folder) setFilesLoading(true);
    try {
      const items = selectedConnectionId
        ? await api.listConnectionFiles(selectedConnectionId, folder)
        : await api.listFiles();
      const loaded = items || [];
      if (!folder) {
        // Root load — replace everything
        setAllFiles(loaded);
        setExpandedFolders({});
        if (loaded.length > 0) setSidebarOpen(true);
      } else {
        // Subfolder load — append new items (avoid duplicates by key)
        setAllFiles(prev => {
          const existing = new Set(prev.map((f: any) => f.key || f.path));
          const newItems = loaded.filter((f: any) => !existing.has(f.key || f.path));
          return [...prev, ...newItems];
        });
      }
    } catch (_err) {
      const error = _err as any;
      const isTokenExpired = error instanceof ApiError && error.errorCode === 'TOKEN_EXPIRED';
      addNotification({
        type: 'error',
        title: isTokenExpired ? 'Session Token Expired' : 'Error loading files',
        message: error.message,
        ...(isTokenExpired ? { action: { label: 'Update Connection', href: '/connections' } } : {}),
      });
    } finally {
      if (!folder) setFilesLoading(false);
    }
  };

  const loadSchemas = async () => {
    const schemas = {};
    for (const table of selectedTables) {
      if (tableSchemas[table.path]) {
        schemas[table.path] = tableSchemas[table.path];
        continue;
      }
      try {
        // For S3 files, table.key holds the raw S3 key (no s3://bucket/ prefix)
        // which is safe to embed in the URL path. Fall back to table.path for local files.
        const schemaPath = (table as any).key || table.path;
        const schema = selectedConnectionId
          ? await api.getConnectionFileSchema(selectedConnectionId, schemaPath)
          : await api.getFileSchema(table.path);
        schemas[table.path] = (schema.columns || []).slice().sort((a, b) => a.name.localeCompare(b.name));
      } catch (_err) {
      const error = _err as Error;
        console.error(`Error loading schema for ${table.path}:`, error);
      }
    }
    setTableSchemas(prev => ({ ...prev, ...schemas }));
  };

  // Load file list for the secondary cross-connection
  const loadCrossConnFiles = async (connId) => {
    if (!connId) { setCrossConnFiles([]); setCrossConnFile(null); return; }
    setCrossConnLoading(true);
    try {
      const files = await api.listConnectionFiles(connId);
      setCrossConnFiles(files || []);
      setCrossConnFile(null);
    } catch {
      setCrossConnFiles([]);
    } finally {
      setCrossConnLoading(false);
    }
  };

  const loadIcebergTablesForConn = async (connId, warehousePath: string) => {
    setIcebergLoading(true);
    try {
      const result = await api.listIcebergTables(String(connId), warehousePath);
      setIcebergTables(result.tables || []);
    } catch (_err) {
      setIcebergTables([]);
    } finally {
      setIcebergLoading(false);
    }
  };

  const loadIcebergTableFiles = async (table) => {
    if (icebergTableFiles[table.prefix] !== undefined) return; // already loaded or loading
    setIcebergLoadingTable(table.prefix);
    // Mark as loading (empty array placeholder avoids double-fetch)
    setIcebergTableFiles(prev => ({ ...prev, [table.prefix]: null }));
    try {
      const result = await api.listIcebergFiles(String(selectedConnectionId), table.prefix);
      setIcebergTableFiles(prev => ({ ...prev, [table.prefix]: result.files || [] }));
    } catch (_err) {
      setIcebergTableFiles(prev => ({ ...prev, [table.prefix]: [] }));
    } finally {
      setIcebergLoadingTable(null);
    }
  };

  const handleProgress = (message) => {
    if (message.type === 'execution_progress') {
      setProgress({
        rows: message.data?.total_rows || 0,
        chunks: message.data?.chunks_processed || 0,
        status: message.data?.status || 'processing',
      });
      if (message.data?.status === 'completed') {
        if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
        const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
        setExecuting(false);
        setProgress({ rows: message.data.total_rows || 0, status: 'completed', elapsed: finalElapsed });
        setResultsExecutionId(executionId);
        setShowResults(true);
      }
    } else if (message.type === 'execution_completed') {
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
      setExecuting(false);
      setProgress({ rows: message.stats?.total_rows || 0, status: 'completed', elapsed: finalElapsed });
      setResultsExecutionId(executionId);
      setShowResults(true);
    } else if (message.type === 'execution_failed') {
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      setExecuting(false);
      const isTokenExpired = message.error_code === 'TOKEN_EXPIRED';
      setProgress({
        status: 'failed',
        error: message.error,
        ...(isTokenExpired ? { errorCode: 'TOKEN_EXPIRED' } : {}),
      });
      if (isTokenExpired) {
        addNotification({ type: 'error', title: 'Session Token Expired', message: message.error,
                          action: { label: 'Update Connection', href: '/connections' } });
      }
    }
  };

  const generateSQLPreview = () => {
    if (selectedTables.length === 0) {
      setSqlPreview('-- Select tables to build query');
      return;
    }
    const OP_MAP: Record<string, string> = {
      eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=',
      in: 'IN', not_in: 'NOT IN', contains: 'LIKE', not_contains: 'NOT LIKE',
      between: 'BETWEEN', is_null: 'IS NULL', is_not_null: 'IS NOT NULL',
    };

    let sql = distinct ? 'SELECT DISTINCT\n' : 'SELECT\n';
    const selectParts: string[] = [];

    if (aggregations.length > 0) {
      const aggColSet = new Set(aggregations.map((a: any) => a.column));
      const groupCols = selectedColumns.filter(c => !aggColSet.has(c.columnName));
      groupCols.forEach(c => {
        const alias = columnAliases[c.columnName];
        selectParts.push(`  ${c.columnName}${alias ? ` AS ${alias}` : ''}`);
      });
      aggregations.forEach((a: any) => {
        const alias = a.alias || `${a.function.toLowerCase()}_${a.column}`;
        const dkw = a.distinct ? 'DISTINCT ' : '';
        selectParts.push(`  ${a.function}(${dkw}${a.column}) AS ${alias}`);
      });
    } else {
      if (selectedColumns.length > 0) {
        selectedColumns.forEach(c => {
          const alias = columnAliases[c.columnName];
          selectParts.push(`  ${c.tableName}.${c.columnName}${alias ? ` AS ${alias}` : ''}`);
        });
      } else {
        selectParts.push('  *');
      }
    }
    // Computed columns
    computedColumns.forEach((cc: any) => selectParts.push(`  (${cc.expression}) AS ${cc.alias}`));
    // CASE WHEN
    caseExpressions.forEach((ce: any) => {
      let c = 'CASE';
      (ce.when_clauses || []).forEach((w: any) => {
        const op = OP_MAP[w.when_operator] || '=';
        if (['is_null', 'is_not_null'].includes(w.when_operator)) {
          c += ` WHEN ${w.when_column} ${op} THEN '${w.then_value}'`;
        } else {
          c += ` WHEN ${w.when_column} ${op} '${w.when_value}' THEN '${w.then_value}'`;
        }
      });
      if (ce.else_value) c += ` ELSE '${ce.else_value}'`;
      c += ` END AS ${ce.alias}`;
      selectParts.push(`  ${c}`);
    });
    // Window functions
    windowFunctions.forEach((wf: any) => {
      const fn = wf.function;
      const parts: string[] = [];
      if (wf.partition_by?.length) parts.push(`PARTITION BY ${wf.partition_by.join(', ')}`);
      if (wf.order_by?.length) parts.push(`ORDER BY ${wf.order_by.map((o: any) => `${o.column} ${(o.direction || 'ASC').toUpperCase()}`).join(', ')}`);
      const over = `OVER (${parts.join(' ')})`;
      if (['ROW_NUMBER', 'RANK', 'DENSE_RANK'].includes(fn)) {
        selectParts.push(`  ${fn}() ${over} AS ${wf.alias}`);
      } else if (['LAG', 'LEAD'].includes(fn)) {
        selectParts.push(`  ${fn}(${wf.column || ''}, ${wf.offset || 1}) ${over} AS ${wf.alias}`);
      } else {
        selectParts.push(`  ${fn}(${wf.column || '*'}) ${over} AS ${wf.alias}`);
      }
    });

    sql += selectParts.join(',\n');
    if (joins.length > 0) {
      sql += `\n\nFROM ${selectedTables[0].name}`;
      joins.forEach(j => {
        const rt = selectedTables.find(t => t.path === j.rightTable);
        sql += `\n${j.joinType.toUpperCase()} JOIN ${rt?.name}\n  ON ${j.leftColumn} = ${j.rightColumn}`;
      });
    } else if (selectedTables.length > 1) {
      sql += '\n\nFROM (\n' + selectedTables.map(t => `  SELECT * FROM ${t.name}`).join('\n  UNION ALL\n') + '\n)';
    } else {
      sql += `\n\nFROM ${selectedTables[0].name}`;
    }

    // WHERE
    if (filters.length > 0) {
      sql += '\n\nWHERE\n';
      sql += filters.map((f, i) => {
        const op = OP_MAP[f.operator] || '=';
        let valStr = '';
        if (['is_null', 'is_not_null'].includes(f.operator)) valStr = '';
        else if (f.operator === 'between') valStr = `${f.value_low || ''} AND ${f.value_high || ''}`;
        else if (['in', 'not_in'].includes(f.operator)) valStr = `(${f.value})`;
        else if (['contains', 'not_contains'].includes(f.operator)) valStr = `'%${f.value}%'`;
        else valStr = String(f.value ?? '');
        return `  ${i > 0 ? `${filterLogic} ` : ''}${f.column} ${op} ${valStr}`;
      }).join('\n');
    }

    // GROUP BY
    if (aggregations.length > 0) {
      const aggColSet = new Set(aggregations.map((a: any) => a.column));
      const groupCols = selectedColumns.filter(c => !aggColSet.has(c.columnName)).map(c => c.columnName);
      if (groupCols.length > 0) {
        sql += '\n\nGROUP BY\n';
        sql += groupCols.map(c => `  ${c}`).join(',\n');
      }
    }

    // HAVING
    if (having.length > 0) {
      sql += '\n\nHAVING\n';
      sql += having.map((h: any, i: number) => {
        const op = OP_MAP[h.operator] || '=';
        const fn = h.function ? `${h.function}(${h.column})` : h.column;
        return `  ${i > 0 ? 'AND ' : ''}${fn} ${op} ${h.value}`;
      }).join('\n');
    }

    if (orderBy.length > 0) {
      sql += '\n\nORDER BY\n';
      sql += orderBy.map(o => `  ${o.column} ${o.direction.toUpperCase()}`).join(',\n');
    }
    sql += `\n\nLIMIT ${limit};`;
    setSqlPreview(sql);
  };

  const toggleTable = (file) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      setSelectedTables(selectedTables.filter(t => t.path !== file.path));
    } else {
      setSelectedTables([...selectedTables, file]);
    }
  };

  const buildQueryConfigObject = () => {
    const queryFiles = joins.length > 0
      ? [selectedTables[0].path]
      : selectedTables.map(t => t.path);
    const aggColNames = new Set(aggregations.map((a: any) => a.column));
    const groupByCols = selectedColumns.filter(c => !aggColNames.has(c.columnName)).map(c => c.columnName);
    const qc: any = {
      files: queryFiles,
      joins: joins.map(j => ({
        left_file: j.leftTable, right_file: j.rightTable,
        left_on: [j.leftColumn], right_on: [j.rightColumn], how: j.joinType,
      })),
      columns: selectedColumns.map(c => c.columnName),
      filters: filters.map(f => {
        const base: any = { column: f.column, operator: f.operator };
        if (f.operator === 'between') base.value = [f.value_low, f.value_high];
        else if (['is_null', 'is_not_null'].includes(f.operator)) base.value = null;
        else if (['in', 'not_in'].includes(f.operator)) base.value = String(f.value).split(',').map((v: string) => v.trim());
        else base.value = f.value;
        return base;
      }),
      order_by: orderBy.map(o => ({ column: o.column, direction: o.direction })),
      limit,
    };
    if (distinct) qc.distinct = true;
    if (filterLogic !== 'AND') qc.filter_logic = filterLogic;
    if (Object.keys(columnAliases).length > 0) qc.column_aliases = columnAliases;
    if (aggregations.length > 0) {
      qc.group_by = groupByCols;
      qc.aggregations = aggregations.map((a: any) => ({
        column: a.column, function: a.function,
        alias: a.alias || `${a.function.toLowerCase()}_${a.column}`,
        ...(a.distinct ? { distinct: true } : {}),
      }));
    }
    if (having.length > 0) qc.having = having;
    if (computedColumns.length > 0) qc.computed_columns = computedColumns;
    if (caseExpressions.length > 0) qc.case_expressions = caseExpressions;
    if (windowFunctions.length > 0) qc.window_functions = windowFunctions;
    return qc;
  };

  const switchToSqlMode = async () => {
    setQueryMode('sql');
    if (selectedTables.length === 0) {
      setRawSql('-- Select a table from the sidebar first');
      return;
    }
    setSqlLoading(true);
    try {
      const response = await api.previewSql({
        query_config: buildQueryConfigObject(),
        ...(selectedConnectionId ? { connection_id: selectedConnectionId } : {}),
      });
      setRawSql(response.sql);
    } catch {
      setRawSql(sqlPreview || '-- Could not generate SQL');
    } finally {
      setSqlLoading(false);
    }
  };

  const executeQuery = async () => {
    if (queryMode === 'sql') {
      if (!rawSql.trim()) {
        addNotification({ type: 'warning', title: 'Empty SQL', message: 'Enter a SQL query to execute' });
        return;
      }
    } else if (selectedTables.length === 0) {
      addNotification({ type: 'warning', title: 'No Tables', message: 'Select at least one table' });
      return;
    }
    const hasLargeTable = selectedTables.some(t => t.num_rows > 1000000);
    if (queryMode !== 'sql' && hasLargeTable && joins.length > 0 && limit > 10000) {
      const totalRows = selectedTables.reduce((acc, t) => acc * (t.num_rows || 1), 1);
      const confirmed = window.confirm(
        `⚠️ WARNING: Large Join Detected!\n\nTables: ${selectedTables.map(t => `${t.name} (${t.num_rows?.toLocaleString()} rows)`).join(' × ')}\nPotential result: ${totalRows.toLocaleString()} rows\n\nThis could take a long time!\n\nRecommendation: set LIMIT ≤ 1000 and add WHERE filters.\n\nContinue anyway?`
      );
      if (!confirmed) return;
    }

    const queryConfig = queryMode !== 'sql' ? buildQueryConfigObject() : null;
    // Validate cross-connection config if enabled
    if (showCrossConn && crossConnId) {
      if (!crossConnFile) {
        addNotification({ type: 'warning', title: 'No Secondary File', message: 'Select a file from the secondary connection' });
        return;
      }
      if (crossConnMode === 'join' && (!crossJoinLeftOn || !crossJoinRightOn)) {
        addNotification({ type: 'warning', title: 'Join Config Incomplete', message: 'Specify both join key columns for cross-connection JOIN' });
        return;
      }
    }

    try {
      setExecuting(true);
      setShowResults(false);
      setProgress({ rows: 0, status: 'starting' });
      setElapsed(0);
      execStartRef.current = Date.now();
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      elapsedTimerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - (execStartRef.current ?? Date.now())) / 1000));
      }, 1000);
      // Fetch ETA from historical data for this connection
      const connId = selectedConnectionId || null;
      fetch(`${import.meta.env.VITE_API_URL || ''}/api/admin/query-eta${connId ? `?connection_id=${connId}` : ''}`)
        .then(r => r.json()).then(d => setEtaSeconds(d.p75_seconds ?? null)).catch(() => {});

      const payload: any = selectedConnectionId ? { connection_id: selectedConnectionId } : {};
      if (queryMode === 'sql') {
        payload.raw_sql = rawSql;
      } else {
        payload.query_config = queryConfig;
        // Attach cross-connection params
        if (showCrossConn && crossConnId && crossConnFile) {
          payload.secondary_connection_id = crossConnId;
          payload.secondary_query_config  = { files: [crossConnFile], limit };
          payload.combine_mode            = crossConnMode;
          if (crossConnMode === 'join') {
            payload.join_config = {
              how:      crossJoinHow,
              left_on:  crossJoinLeftOn,
              right_on: crossJoinRightOn,
              suffixes: ['_primary', '_secondary'],
            };
          }
        }
      }

      const response = await api.executeQuery(payload);
      setExecutionId(response.execution_id);
      const modeLabel = response.is_cross_connection
        ? ` (${(response.combine_mode || 'union').toUpperCase()})`
        : '';
      addNotification({ type: 'info', title: `Query Started${modeLabel}`, message: `ID: ${response.execution_id?.substring(0, 8)}` });
    } catch (_err) {
      const error = _err as Error;
      setExecuting(false);
      setProgress(null);
      addNotification({ type: 'error', title: 'Failed', message: error.message });
    }
  };

  const cancelQuery = async () => {
    if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
    if (executionId) {
      try { await api.cancelExecution(executionId); } catch {}
    }
    setExecuting(false);
    setProgress(null);
    addNotification({ type: 'info', title: 'Cancelled', message: 'Execution cancelled' });
  };

  const selectedConn = connections.find(c => c.id === selectedConnectionId);

  // ── Sidebar file tree (grouped by folder) ─────────────────────────────────
  const filteredFiles = useMemo(() => {
    const q = sidebarSearch.toLowerCase();
    return q ? allFiles.filter(f => f.name.toLowerCase().includes(q) || f.path.toLowerCase().includes(q)) : allFiles;
  }, [allFiles, sidebarSearch]);

  const fileTree = useMemo(() => {
    const rootFiles: any[] = [];
    const rootFolders: any[] = [];
    const childFiles: Record<string, any[]> = {};   // parent folder key → files
    const childFolders: Record<string, any[]> = {};  // parent folder key → sub-folders
    const folderKeys = new Set<string>();

    // First pass: collect explicit folder items from backend
    filteredFiles.forEach(f => {
      if (f.type === 'folder') folderKeys.add(f.key);
    });

    filteredFiles.forEach(f => {
      const parentKey = f.folder || '';
      if (f.type === 'folder') {
        if (!parentKey) { rootFolders.push(f); }
        else {
          if (!childFolders[parentKey]) childFolders[parentKey] = [];
          childFolders[parentKey].push(f);
        }
      } else if (!parentKey) {
        rootFiles.push(f);
      } else if (folderKeys.has(parentKey)) {
        // S3 files — parentKey matches a real folder item's key
        if (!childFiles[parentKey]) childFiles[parentKey] = [];
        childFiles[parentKey].push(f);
      } else {
        // Local files — no explicit folder item, create synthetic one
        if (!folderKeys.has(parentKey)) {
          folderKeys.add(parentKey);
          const displayName = parentKey.replace(/\/$/, '').split('/').pop() || parentKey;
          rootFolders.push({ key: parentKey, name: displayName, type: 'folder', synthetic: true });
        }
        if (!childFiles[parentKey]) childFiles[parentKey] = [];
        childFiles[parentKey].push(f);
      }
    });
    return { rootFiles, rootFolders, childFiles, childFolders };
  }, [filteredFiles]);

  // Recursive folder renderer for the sidebar tree
  const renderFolder = (folder: any, depth: number) => {
    const folderKey = folder.key;
    const isExpanded = !!expandedFolders[folderKey];
    const isLoaded = loadedFolders.has(folderKey);
    const isLoading = loadingFolder === folderKey;
    const subFiles = fileTree.childFiles[folderKey] || [];
    const subFolders = fileTree.childFolders[folderKey] || [];
    const indent = 1.5 + depth * 1.5;  // progressive indentation

    return (
      <Box key={folderKey}>
        <ListItemButton
          dense
          onClick={async () => {
            const willExpand = !isExpanded;
            setExpandedFolders(prev => ({ ...prev, [folderKey]: willExpand }));
            // Lazy-load: only for non-synthetic (S3) folders that haven't been loaded yet
            if (willExpand && !isLoaded && !folder.synthetic && selectedConnectionId) {
              setLoadingFolder(folderKey);
              await loadFiles(folderKey);
              setLoadedFolders(prev => new Set(prev).add(folderKey));
              setLoadingFolder(null);
            }
          }}
          sx={{ px: 1.5, py: 0.5, pl: indent }}
        >
          {isExpanded ? <CollapseIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} /> : <ExpandIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} />}
          <FolderIcon sx={{ fontSize: 14, mr: 0.75, color: 'warning.main' }} />
          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', flexGrow: 1 }} noWrap>
            {folder.name}
          </Typography>
          {isLoading && <CircularProgress size={12} />}
        </ListItemButton>
        <Collapse in={isExpanded}>
          {subFolders.map(sf => renderFolder(sf, depth + 1))}
          {subFiles.map(file => (
            <SidebarFileItem
              key={file.path}
              file={file}
              selected={!!selectedTables.find(t => t.path === file.path)}
              onToggle={() => toggleTable(file)}
              indent
            />
          ))}
          {isLoaded && subFiles.length === 0 && subFolders.length === 0 && (
            <Typography variant="caption" sx={{ pl: indent + 1.5, color: 'text.disabled', display: 'block', py: 0.5, fontSize: 11 }}>
              No files found
            </Typography>
          )}
        </Collapse>
      </Box>
    );
  };

  return (
    <Box sx={{ height: 'calc(100vh - 52px)', display: 'flex', flexDirection: 'row', bgcolor: 'background.default', overflow: 'hidden' }}>

      {/* ─── File Sidebar (Toad-style) ──────────────────────────────────────── */}
      <Box sx={{
        width: sidebarOpen ? SIDEBAR_W : 0,
        minWidth: sidebarOpen ? SIDEBAR_W : 0,
        transition: 'width 0.2s ease, min-width 0.2s ease',
        overflow: 'hidden',
        borderRight: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Sidebar header */}
        <Box sx={{ px: 1.5, py: 1, display: 'flex', alignItems: 'center', gap: 0.5, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <TableRowsIcon sx={{ fontSize: 16, color: 'primary.main', flexShrink: 0 }} />
          <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.primary', flexGrow: 1, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Tables
          </Typography>
          {filesLoading
            ? <CircularProgress size={14} />
            : <Tooltip title="Refresh">
                <IconButton size="small" onClick={loadFiles} sx={{ p: 0.25 }}>
                  <RefreshIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Tooltip>
          }
          <Tooltip title="Collapse sidebar">
            <IconButton size="small" onClick={() => setSidebarOpen(false)} sx={{ p: 0.25 }}>
              <CollapseIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>

        {/* Search */}
        <Box sx={{ px: 1, pt: 1, pb: 0.5, flexShrink: 0 }}>
          <TextField
            size="small"
            placeholder="Search tables..."
            value={sidebarSearch}
            onChange={e => setSidebarSearch(e.target.value)}
            fullWidth
            InputProps={{
              startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment>,
              endAdornment: sidebarSearch
                ? <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSidebarSearch('')} sx={{ p: 0.25 }}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </InputAdornment>
                : null,
            }}
            sx={{ '& .MuiInputBase-root': { fontSize: 13 } }}
          />
        </Box>

        {/* File tree */}
        <Box sx={{ flex: 1, overflowY: 'auto', pb: 1 }}>

          {/* ── Iceberg Tables section (S3 only) ──────────────────────────── */}
          {(icebergLoading || icebergTables.length > 0) && (
            <Box>
              <Box sx={{ px: 1.5, py: 0.5, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <TableRowsIcon sx={{ fontSize: 13, color: 'success.main' }} />
                <Typography variant="caption" sx={{ fontWeight: 700, color: 'success.main', textTransform: 'uppercase', letterSpacing: 0.5, flexGrow: 1, fontSize: 10 }}>
                  Iceberg Tables
                </Typography>
                {icebergLoading && <CircularProgress size={12} />}
              </Box>
              {icebergTables.map(table => (
                <Box key={table.prefix}>
                  <ListItemButton
                    dense
                    onClick={() => {
                      const isExpanded = !!expandedIcebergTables[table.prefix];
                      setExpandedIcebergTables(prev => ({ ...prev, [table.prefix]: !isExpanded }));
                      if (!isExpanded) loadIcebergTableFiles(table);
                    }}
                    sx={{ px: 1.5, py: 0.5 }}
                  >
                    {expandedIcebergTables[table.prefix]
                      ? <CollapseIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} />
                      : <ExpandIcon sx={{ fontSize: 14, mr: 0.5, color: 'text.disabled' }} />}
                    <TableRowsIcon sx={{ fontSize: 14, mr: 0.75, color: 'success.main' }} />
                    <Typography variant="caption" sx={{ fontWeight: 600, color: 'success.dark', flexGrow: 1 }} noWrap>
                      {table.name}
                    </Typography>
                    {icebergLoadingTable === table.prefix
                      ? <CircularProgress size={12} />
                      : icebergTableFiles[table.prefix] != null && (
                          <Typography variant="caption" color="text.disabled">
                            ({(icebergTableFiles[table.prefix] || []).length})
                          </Typography>
                        )
                    }
                  </ListItemButton>
                  <Collapse in={!!expandedIcebergTables[table.prefix]}>
                    {(icebergTableFiles[table.prefix] || []).map(file => (
                      <SidebarFileItem
                        key={file.key}
                        file={{ ...file, path: file.key, name: file.name.replace(/\.parquet$/i, '') }}
                        selected={!!selectedTables.find(t => t.path === file.key)}
                        onToggle={() => toggleTable({ ...file, path: file.key })}
                        indent
                      />
                    ))}
                    {icebergTableFiles[table.prefix]?.length === 0 && (
                      <Typography variant="caption" sx={{ pl: 4.5, color: 'text.disabled', display: 'block', py: 0.5, fontSize: 11 }}>
                        No data files found
                      </Typography>
                    )}
                  </Collapse>
                </Box>
              ))}
              {icebergTables.length > 0 && <Divider sx={{ my: 0.5 }} />}
            </Box>
          )}

          {allFiles.length === 0 && !filesLoading && icebergTables.length === 0 && (
            <Box sx={{ px: 2, pt: 2, textAlign: 'center' }}>
              <Typography variant="caption" color="text.disabled">
                {selectedConnectionId ? 'No parquet files found' : 'Select a connection or use default data'}
              </Typography>
            </Box>
          )}

          {/* Root-level files */}
          {fileTree.rootFiles.map(file => (
            <SidebarFileItem
              key={file.path}
              file={file}
              selected={!!selectedTables.find(t => t.path === file.path)}
              onToggle={() => toggleTable(file)}
            />
          ))}

          {/* Folders (lazy-load on expand, recursive) */}
          {fileTree.rootFolders.map(folder => renderFolder(folder, 0))}
        </Box>

        {/* Selected count footer */}
        {selectedTables.length > 0 && (
          <Box sx={{ px: 1.5, py: 0.75, borderTop: 1, borderColor: 'divider', bgcolor: 'primary.50', flexShrink: 0 }}>
            <Typography variant="caption" sx={{ color: 'primary.main', fontWeight: 600 }}>
              {selectedTables.length} table{selectedTables.length > 1 ? 's' : ''} selected
            </Typography>
          </Box>
        )}
      </Box>

      {/* ─── Main content (controls + results) ─────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* ─── Controls strip ────────────────────────────────────────────── */}
        <Box sx={{ flexShrink: 0, px: 2, pt: 2, pb: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: 'background.paper' }}>

          {/* SQL Preview panel (collapsible) */}
          {showPreview && (
            <Paper sx={{ p: 2, bgcolor: 'grey.900' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="subtitle2" sx={{ color: 'grey.300' }}>
                  <CodeIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />
                  SQL Preview
                </Typography>
                <IconButton size="small" onClick={() => setShowPreview(false)} sx={{ color: 'grey.400' }}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Box>
              <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 13, color: '#4fc3f7', whiteSpace: 'pre-wrap', wordBreak: 'break-word', m: 0, maxHeight: 160, overflowY: 'auto' }}>
                {sqlPreview}
              </Box>
            </Paper>
          )}

          {/* Row 1: Data source + sidebar toggle + SQL toggle */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
            {/* Sidebar toggle */}
            {!sidebarOpen && (
              <Tooltip title="Show table browser">
                <IconButton size="small" onClick={() => setSidebarOpen(true)} sx={{ border: 1, borderColor: 'divider' }}>
                  <ExpandIcon />
                </IconButton>
              </Tooltip>
            )}

            <Typography variant="body2" sx={{ fontWeight: 600, color: 'text.secondary', whiteSpace: 'nowrap' }}>
              Data Source:
            </Typography>
            <TextField
              select
              size="small"
              value={selectedConnectionId ?? ''}
              onChange={e => setSelectedConnectionId(e.target.value === '' ? null : Number(e.target.value))}
              sx={{ minWidth: 220 }}
            >
              <MenuItem value="">Local (default)</MenuItem>
              {connections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  {c.name}
                  <Typography component="span" variant="caption" sx={{ ml: 1, color: 'text.disabled' }}>
                    ({c.connection_type})
                  </Typography>
                </MenuItem>
              ))}
            </TextField>
            {connections.length === 0 && (
              <Button
                size="small"
                variant="text"
                startIcon={<OpenInNewIcon fontSize="small" />}
                onClick={() => navigate('/connections')}
                sx={{ textTransform: 'none', fontSize: 12, color: 'text.secondary' }}
              >
                Manage Connections
              </Button>
            )}
            {selectedConn && (
              <Chip
                size="small"
                label={selectedConn.last_test_status === 'success' ? 'Connected' : 'Untested'}
                color={selectedConn.last_test_status === 'success' ? 'success' : 'default'}
                variant="outlined"
              />
            )}
            <Box sx={{ flexGrow: 1 }} />
            <Button variant="outlined" size="small" startIcon={<CodeIcon />} onClick={() => setShowPreview(v => !v)}>
              {showPreview ? 'Hide SQL' : 'SQL Preview'}
            </Button>
          </Box>

          {/* Row 2: Query builder toolbar + execute */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <ButtonGroup variant="contained" size="small">
              <Tooltip title="Browse tables in sidebar or open picker">
                <Button onClick={() => setShowTableSelector(true)} startIcon={<TableIcon />}>
                  Tables
                  <Chip label={selectedTables.length} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                </Button>
              </Tooltip>
              <Tooltip title="Configure joins (need ≥2 tables)">
                <span>
                  <Button onClick={() => setShowJoinBuilder(true)} disabled={selectedTables.length < 2} startIcon={<JoinIcon />}>
                    Joins
                    <Chip label={joins.length} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Pick columns (SELECT)">
                <span>
                  <Button onClick={() => setShowColumnSelector(true)} disabled={selectedTables.length === 0} startIcon={<ColumnIcon />}>
                    Columns
                    <Chip label={selectedColumns.length || '*'} size="small" sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }} color="default" />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Aggregate functions (SUM, AVG, COUNT...)">
                <span>
                  <Button onClick={() => setShowAggBuilder(true)} disabled={selectedTables.length === 0}
                    startIcon={<AggIcon />} color={aggregations.length > 0 ? 'secondary' : 'inherit'}>
                    Aggregate
                    <Chip label={aggregations.length} size="small"
                      sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }}
                      color={aggregations.length > 0 ? 'secondary' : 'default'} />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Add WHERE filters">
                <Button onClick={() => setShowFilterBuilder(true)} startIcon={<FilterIcon />}>
                  Filters
                  <Chip
                    label={filters.length}
                    size="small"
                    sx={{ ml: 0.75, height: 18, minWidth: 18, fontSize: 11 }}
                    color={filters.length > 0 ? 'warning' : 'default'}
                  />
                </Button>
              </Tooltip>
            </ButtonGroup>

            {/* Advanced SQL buttons */}
            <ButtonGroup variant="outlined" size="small">
              <Tooltip title="SELECT DISTINCT — remove duplicate rows">
                <Button onClick={() => setDistinct(d => !d)} color={distinct ? 'secondary' : 'inherit'}
                  variant={distinct ? 'contained' : 'outlined'} sx={{ fontSize: 12, minWidth: 0 }}>
                  DISTINCT
                </Button>
              </Tooltip>
              <Tooltip title="HAVING — filter aggregated results">
                <span>
                  <Button onClick={() => setShowHavingBuilder(true)} disabled={aggregations.length === 0}
                    color={having.length > 0 ? 'warning' : 'inherit'} sx={{ fontSize: 12 }}>
                    HAVING <Chip label={having.length} size="small" sx={{ ml: 0.5, height: 16, fontSize: 10 }} />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Computed columns (expressions, date/string functions)">
                <span>
                  <Button onClick={() => setShowComputedBuilder(true)} disabled={selectedTables.length === 0}
                    startIcon={<ComputedIcon sx={{ fontSize: 16 }} />}
                    color={computedColumns.length > 0 ? 'info' : 'inherit'} sx={{ fontSize: 12 }}>
                    Computed <Chip label={computedColumns.length} size="small" sx={{ ml: 0.5, height: 16, fontSize: 10 }} />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="CASE WHEN conditional expressions">
                <span>
                  <Button onClick={() => setShowCaseBuilder(true)} disabled={selectedTables.length === 0}
                    startIcon={<CaseIcon sx={{ fontSize: 16 }} />}
                    color={caseExpressions.length > 0 ? 'info' : 'inherit'} sx={{ fontSize: 12 }}>
                    CASE <Chip label={caseExpressions.length} size="small" sx={{ ml: 0.5, height: 16, fontSize: 10 }} />
                  </Button>
                </span>
              </Tooltip>
              <Tooltip title="Window functions (ROW_NUMBER, RANK, LAG, LEAD...)">
                <span>
                  <Button onClick={() => setShowWindowBuilder(true)} disabled={selectedTables.length === 0}
                    startIcon={<WindowIcon sx={{ fontSize: 16 }} />}
                    color={windowFunctions.length > 0 ? 'info' : 'inherit'} sx={{ fontSize: 12 }}>
                    Window <Chip label={windowFunctions.length} size="small" sx={{ ml: 0.5, height: 16, fontSize: 10 }} />
                  </Button>
                </span>
              </Tooltip>
            </ButtonGroup>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 600 }}>Limit:</Typography>
              <TextField
                type="number"
                size="small"
                value={limit}
                onChange={e => setLimit(parseInt(e.target.value) || 0)}
                sx={{ width: 100 }}
              />
            </Box>

            {/* Cross-connection toggle */}
            <Tooltip title={showCrossConn ? 'Remove secondary source' : 'Union or Join with a file from another connection'}>
              <Button
                size="small"
                variant={showCrossConn ? 'contained' : 'outlined'}
                color={showCrossConn ? 'warning' : 'inherit'}
                startIcon={<JoinIcon />}
                onClick={() => setShowCrossConn(v => !v)}
                sx={{ fontSize: 12 }}
              >
                {showCrossConn ? 'Cross-Conn ✓' : 'Union / Join'}
              </Button>
            </Tooltip>

            <Box sx={{ flexGrow: 1 }} />

            <Tooltip title={queryMode === 'sql' ? 'Switch to visual query builder' : 'Switch to SQL editor'}>
              <ButtonGroup size="small" variant="outlined">
                <Button
                  onClick={() => setQueryMode('visual')}
                  variant={queryMode === 'visual' ? 'contained' : 'outlined'}
                  color={queryMode === 'visual' ? 'primary' : 'inherit'}
                  sx={{ textTransform: 'none', px: 1.5 }}
                >
                  Visual
                </Button>
                <Button
                  startIcon={sqlLoading ? <CircularProgress size={12} /> : <CodeIcon />}
                  onClick={switchToSqlMode}
                  variant={queryMode === 'sql' ? 'contained' : 'outlined'}
                  color={queryMode === 'sql' ? 'primary' : 'inherit'}
                  sx={{ textTransform: 'none', px: 1.5 }}
                >
                  SQL
                </Button>
              </ButtonGroup>
            </Tooltip>

            <Button
              variant="outlined"
              size="small"
              startIcon={<SaveIcon />}
              onClick={() => setShowSaveDialog(true)}
              disabled={selectedTables.length === 0}
            >
              Save
            </Button>
            <Button
              variant="contained"
              color="success"
              size="small"
              startIcon={executing ? <CircularProgress size={16} color="inherit" /> : <PlayIcon />}
              onClick={executeQuery}
              disabled={(queryMode !== 'sql' && selectedTables.length === 0) || executing}
              sx={{ fontWeight: 700, minWidth: 120 }}
            >
              {executing ? 'Running...' : 'Execute'}
            </Button>
          </Box>

          {/* Row 2b: Cross-Connection UNION / JOIN panel */}
          {showCrossConn && (
            <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'warning.50', borderColor: 'warning.300' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                <JoinIcon sx={{ fontSize: 16, color: 'warning.main', flexShrink: 0 }} />
                <Typography variant="caption" sx={{ fontWeight: 700, color: 'warning.dark', whiteSpace: 'nowrap' }}>
                  CROSS-CONNECTION
                </Typography>

                {/* Mode: UNION or JOIN */}
                <TextField
                  select size="small" label="Mode"
                  value={crossConnMode}
                  onChange={e => setCrossConnMode(e.target.value)}
                  sx={{ minWidth: 100 }}
                >
                  <MenuItem value="union">UNION (stack rows)</MenuItem>
                  <MenuItem value="join">JOIN (merge by key)</MenuItem>
                </TextField>

                {/* Secondary connection */}
                <TextField
                  select size="small" label="Secondary Connection"
                  value={crossConnId || ''}
                  onChange={e => { const v = e.target.value ? Number(e.target.value) : null; setCrossConnId(v); loadCrossConnFiles(v); }}
                  sx={{ minWidth: 200 }}
                >
                  <MenuItem value="">— Select —</MenuItem>
                  {connections.map(c => (
                    <MenuItem key={c.id} value={c.id} disabled={c.id === selectedConnectionId}>
                      {c.name} ({c.connection_type})
                    </MenuItem>
                  ))}
                </TextField>

                {/* Secondary file */}
                {crossConnId && (
                  <TextField
                    select size="small" label="Secondary File"
                    value={crossConnFile || ''}
                    onChange={e => setCrossConnFile(e.target.value || null)}
                    sx={{ minWidth: 240 }}
                    disabled={crossConnLoading}
                    InputProps={{ endAdornment: crossConnLoading ? <CircularProgress size={14} /> : null }}
                  >
                    <MenuItem value="">— Select file —</MenuItem>
                    {crossConnFiles.map(f => (
                      <MenuItem key={f.path} value={f.path}>{f.name}{f.folder ? ` (${f.folder})` : ''}</MenuItem>
                    ))}
                  </TextField>
                )}

                {/* JOIN keys */}
                {crossConnMode === 'join' && crossConnId && (
                  <>
                    <TextField
                      select size="small" label="Join Type"
                      value={crossJoinHow}
                      onChange={e => setCrossJoinHow(e.target.value)}
                      sx={{ minWidth: 110 }}
                    >
                      {['inner', 'left', 'right', 'outer'].map(h => (
                        <MenuItem key={h} value={h}>{h.toUpperCase()}</MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      size="small" label="Primary key col"
                      value={crossJoinLeftOn}
                      onChange={e => setCrossJoinLeftOn(e.target.value)}
                      placeholder="e.g. id"
                      sx={{ minWidth: 140 }}
                    />
                    <Typography variant="caption" color="text.secondary">=</Typography>
                    <TextField
                      size="small" label="Secondary key col"
                      value={crossJoinRightOn}
                      onChange={e => setCrossJoinRightOn(e.target.value)}
                      placeholder="e.g. customer_id"
                      sx={{ minWidth: 140 }}
                    />
                  </>
                )}

                {crossConnFile && (
                  <Chip
                    size="small"
                    color="warning"
                    label={`${crossConnMode.toUpperCase()} ready`}
                    sx={{ fontSize: 11 }}
                  />
                )}
              </Box>
            </Paper>
          )}

          {/* Row 3: Query summary + execution progress */}
          {(selectedTables.length > 0 || executing) && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap', minHeight: 28 }}>
              {selectedTables.length > 0 && (
                <Typography variant="body2" color="text.secondary">
                  <strong>FROM</strong> {joins.length > 0
                    ? `${selectedTables[0].name} + ${joins.length} join(s)`
                    : selectedTables.length > 1
                      ? `${selectedTables.length} tables (UNION ALL)`
                      : selectedTables[0].name}
                  {selectedColumns.length > 0 && ` · ${selectedColumns.length} column(s) selected`}
                  {filters.length > 0 && ` · ${filters.length} filter(s)`}
                </Typography>
              )}
              {executing && (
                <>
                  <LinearProgress sx={{ flex: 1, minWidth: 80, maxWidth: 240 }} />
                  <Typography variant="caption" color="primary.main" sx={{ fontWeight: 500 }}>
                    {progress?.status === 'starting'
                      ? 'Starting...'
                      : `${(progress?.rows || 0).toLocaleString()} rows · ${fmtSecs(elapsed)}`}
                  </Typography>
                  {etaSeconds != null && elapsed < etaSeconds && (
                    <Typography variant="caption" color="text.secondary">
                      ~{fmtSecs(Math.max(1, Math.round(etaSeconds - elapsed)))} left
                    </Typography>
                  )}
                  <Button size="small" variant="text" color="error" onClick={cancelQuery}
                    sx={{ textTransform: 'none', py: 0 }}>Cancel</Button>
                </>
              )}
              {!executing && progress?.status === 'completed' && (
                <Typography variant="caption" color="success.main" sx={{ fontWeight: 600 }}>
                  Done in {fmtSecs(progress.elapsed ?? 0)} · {(progress.rows || 0).toLocaleString()} rows
                </Typography>
              )}
            </Box>
          )}

          {/* Error alert */}
          {progress?.status === 'failed' && (
            <Alert severity="error" onClose={() => setProgress(null)} sx={{ py: 0.5 }}>
              <strong>Query failed:</strong> {progress.error}
            </Alert>
          )}
        </Box>

        {/* ─── Results / SQL editor area ─────────────────────────────────── */}
        <Box sx={{ flex: 1, overflow: 'hidden', p: 1 }}>
          {queryMode === 'sql' ? (
            <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Paper variant="outlined" sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1, flex: showResults ? '0 0 42%' : 1, minHeight: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <CodeIcon fontSize="small" color="primary" />
                  <Typography variant="caption" sx={{ fontWeight: 700, letterSpacing: 0.5 }}>SQL EDITOR</Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>
                    — type or paste SQL, then Execute
                  </Typography>
                  <Box sx={{ flexGrow: 1 }} />
                  <Tooltip title="Regenerate SQL from current visual builder state">
                    <span>
                      <Button size="small" variant="text" onClick={switchToSqlMode}
                        disabled={sqlLoading || selectedTables.length === 0}
                        startIcon={sqlLoading ? <CircularProgress size={12} /> : <RefreshIcon />}
                        sx={{ textTransform: 'none', py: 0 }}
                      >
                        Refresh
                      </Button>
                    </span>
                  </Tooltip>
                </Box>
                <TextField
                  multiline
                  fullWidth
                  value={rawSql}
                  onChange={e => setRawSql(e.target.value)}
                  placeholder="-- Write or paste your SQL here..."
                  sx={{ flex: 1, '& .MuiInputBase-root': { fontFamily: 'monospace', fontSize: 13, alignItems: 'flex-start', height: '100%' }, '& .MuiInputBase-input': { fontFamily: 'monospace', fontSize: 13, lineHeight: 1.6 } }}
                  inputProps={{ spellCheck: false }}
                />
              </Paper>
              {showResults && resultsExecutionId && (
                <Box sx={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
                  <DataGridViewer
                    executionId={resultsExecutionId}
                    onClose={() => { setShowResults(false); setResultsExecutionId(null); }}
                  />
                </Box>
              )}
            </Box>
          ) : showResults && resultsExecutionId ? (
            <DataGridViewer
              executionId={resultsExecutionId}
              onClose={() => { setShowResults(false); setResultsExecutionId(null); }}
            />
          ) : (
            <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, color: 'text.secondary', userSelect: 'none' }}>
              <TableIcon sx={{ fontSize: '5rem', opacity: 0.08 }} />
              <Typography variant="h5" sx={{ fontWeight: 600, opacity: 0.4 }}>
                {selectedTables.length === 0 ? 'Click a table in the sidebar to get started' : 'Run the query to see results'}
              </Typography>
              {selectedTables.length > 0 && !executing && (
                <Button variant="contained" size="large" startIcon={<PlayIcon />} onClick={executeQuery} sx={{ mt: 1 }}>
                  Execute Query
                </Button>
              )}
            </Box>
          )}
        </Box>
      </Box>

      {/* ─── Modals ──────────────────────────────────────────────────────────── */}
      <TableSelectorModal
        open={showTableSelector}
        files={allFiles}
        selectedTables={selectedTables}
        onUpdate={setSelectedTables}
        onClose={() => setShowTableSelector(false)}
      />
      <JoinBuilderModal
        open={showJoinBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        joins={joins}
        onUpdate={setJoins}
        onClose={() => setShowJoinBuilder(false)}
      />
      <ColumnSelectorModal
        open={showColumnSelector}
        tables={selectedTables}
        schemas={tableSchemas}
        selectedColumns={selectedColumns}
        onUpdate={setSelectedColumns}
        onClose={() => setShowColumnSelector(false)}
      />
      <FilterBuilderModal
        open={showFilterBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        filters={filters}
        filterLogic={filterLogic}
        onFilterLogicChange={setFilterLogic}
        onUpdate={setFilters}
        onClose={() => setShowFilterBuilder(false)}
      />
      <AggregationBuilderModal
        open={showAggBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        selectedColumns={selectedColumns}
        aggregations={aggregations}
        onUpdate={setAggregations}
        onClose={() => setShowAggBuilder(false)}
      />
      <HavingBuilderModal
        open={showHavingBuilder}
        aggregations={aggregations}
        tables={selectedTables}
        schemas={tableSchemas}
        having={having}
        onUpdate={setHaving}
        onClose={() => setShowHavingBuilder(false)}
      />
      <ComputedColumnBuilderModal
        open={showComputedBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        computedColumns={computedColumns}
        onUpdate={setComputedColumns}
        onClose={() => setShowComputedBuilder(false)}
      />
      <CaseExpressionBuilderModal
        open={showCaseBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        caseExpressions={caseExpressions}
        onUpdate={setCaseExpressions}
        onClose={() => setShowCaseBuilder(false)}
      />
      <WindowFunctionBuilderModal
        open={showWindowBuilder}
        tables={selectedTables}
        schemas={tableSchemas}
        windowFunctions={windowFunctions}
        onUpdate={setWindowFunctions}
        onClose={() => setShowWindowBuilder(false)}
      />
      <SaveQueryModal
        open={showSaveDialog}
        queryConfig={{
          files: joins.length > 0 ? [selectedTables[0]?.path].filter(Boolean) : selectedTables.map(t => t.path),
          joins: joins.map(j => ({ left_file: j.leftTable, right_file: j.rightTable, left_on: [j.leftColumn], right_on: [j.rightColumn], how: j.joinType })),
          columns: selectedColumns.map(c => c.columnName),
          filters: filters.map(f => {
            const base: any = { column: f.column, operator: f.operator };
            if (f.operator === 'between') base.value = [f.value_low, f.value_high];
            else if (['is_null', 'is_not_null'].includes(f.operator)) base.value = null;
            else if (['in', 'not_in'].includes(f.operator)) base.value = String(f.value).split(',').map((v: string) => v.trim());
            else base.value = f.value;
            return base;
          }),
          order_by: orderBy.map((o: any) => ({ column: o.column, direction: o.direction })),
          limit,
          ...(distinct ? { distinct: true } : {}),
          ...(filterLogic !== 'AND' ? { filter_logic: filterLogic } : {}),
          ...(aggregations.length > 0 ? {
            group_by: selectedColumns.filter(c => !new Set(aggregations.map(a => a.column)).has(c.columnName)).map(c => c.columnName),
            aggregations: aggregations.map(a => ({ column: a.column, function: a.function, alias: a.alias || `${a.function.toLowerCase()}_${a.column}`, ...(a.distinct ? { distinct: true } : {}) })),
          } : {}),
          ...(having.length > 0 ? { having } : {}),
          ...(computedColumns.length > 0 ? { computed_columns: computedColumns } : {}),
          ...(caseExpressions.length > 0 ? { case_expressions: caseExpressions } : {}),
          ...(Object.keys(columnAliases).length > 0 ? { column_aliases: columnAliases } : {}),
          ...(windowFunctions.length > 0 ? { window_functions: windowFunctions } : {}),
          ...(selectedConnectionId ? { connection_id: selectedConnectionId } : {}),
        }}
        sqlPreview={sqlPreview}
        editingQueryId={editingQueryId}
        editingQueryName={editingQueryName}
        onClose={() => setShowSaveDialog(false)}
        onSaved={(id, name) => { setEditingQueryId(id); setEditingQueryName(name); }}
      />
    </Box>
  );
};

// ============================================================================
// SIDEBAR FILE ITEM
// ============================================================================
const SidebarFileItem = ({ file, selected, onToggle, indent = false }) => (
  <ListItemButton
    dense
    onClick={onToggle}
    selected={selected}
    sx={{
      pl: indent ? 3.5 : 1.5,
      pr: 1,
      py: 0.5,
      '&.Mui-selected': { bgcolor: 'rgba(21,101,192,0.08)' },
      '&.Mui-selected:hover': { bgcolor: 'rgba(21,101,192,0.12)' },
    }}
  >
    <ListItemIcon sx={{ minWidth: 24 }}>
      <Checkbox
        checked={selected}
        size="small"
        sx={{ p: 0, '& .MuiSvgIcon-root': { fontSize: 16 } }}
        disableRipple
      />
    </ListItemIcon>
    <ListItemText
      primary={file.name.replace(/\.parquet$/i, '')}
      secondary={[file.folder ? `📁 ${file.folder}` : null, file.num_rows != null ? `${file.num_rows.toLocaleString()} rows` : null].filter(Boolean).join(' · ') || null}
      primaryTypographyProps={{ variant: 'caption', fontWeight: selected ? 700 : 400, noWrap: true }}
      secondaryTypographyProps={{ variant: 'caption', sx: { fontSize: 10 }, noWrap: true }}
    />
    {file.num_rows > 1000000 && (
      <Tooltip title="Large file">
        <WarningIcon sx={{ fontSize: 13, color: 'warning.main', ml: 0.5 }} />
      </Tooltip>
    )}
  </ListItemButton>
);

// ============================================================================
// TABLE SELECTOR MODAL
// ============================================================================
const TableSelectorModal = ({ open, files, selectedTables, onUpdate, onClose }) => {
  const toggleTable = (file) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      onUpdate(selectedTables.filter(t => t.path !== file.path));
    } else {
      onUpdate([...selectedTables, file]);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TableIcon />
          <span>Select Tables</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={1}>
          {files.length === 0 && (
            <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
              No parquet files found in this data source.
            </Typography>
          )}
          {files.map(file => {
            const isSelected = selectedTables.find(t => t.path === file.path);
            return (
              <Card
                key={file.path}
                variant="outlined"
                sx={{
                  cursor: 'pointer',
                  bgcolor: isSelected ? 'action.selected' : 'background.paper',
                  borderColor: isSelected ? 'primary.main' : 'divider',
                  '&:hover': { bgcolor: 'action.hover' },
                }}
                onClick={() => toggleTable(file)}
              >
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 1.5, py: 1.5, '&:last-child': { pb: 1.5 } }}>
                  <Checkbox checked={!!isSelected} readOnly />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium' }}>
                      {file.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                      {file.folder && (
                        <Typography variant="body2" color="text.disabled" sx={{ fontSize: 11 }}>
                          {file.folder}/
                        </Typography>
                      )}
                      <Typography variant="body2" color="text.secondary">
                        {file.num_rows?.toLocaleString()} rows &middot; {file.num_columns} cols
                      </Typography>
                      {file.num_rows > 1000000 && (
                        <Chip
                          icon={<WarningIcon />}
                          label="Large"
                          size="small"
                          color="warning"
                          variant="outlined"
                        />
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            );
          })}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedTables.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// JOIN BUILDER MODAL - COMPLETE WITH EDIT/DELETE
// ============================================================================
const JoinBuilderModal = ({ open, tables, schemas, joins, onUpdate, onClose }) => {
  const [editingJoin, setEditingJoin] = useState(null);
  const [newJoin, setNewJoin] = useState({
    leftTable: tables[0]?.path || '',
    rightTable: tables[1]?.path || '',
    leftColumn: '',
    rightColumn: '',
    joinType: 'inner'
  });

  useEffect(() => {
    if (open) {
      setNewJoin({
        leftTable: tables[0]?.path || '',
        rightTable: tables[1]?.path || '',
        leftColumn: '',
        rightColumn: '',
        joinType: 'inner'
      });
      setEditingJoin(null);
    }
  }, [open, tables]);

  const getAllColumns = (tablePath) => schemas[tablePath] || [];

  const addJoin = () => {
    if (!newJoin.leftColumn || !newJoin.rightColumn) {
      alert('Please select join columns for both tables');
      return;
    }
    if (editingJoin !== null) {
      const updated = [...joins];
      updated[editingJoin] = { ...newJoin, id: joins[editingJoin].id };
      onUpdate(updated);
      setEditingJoin(null);
    } else {
      onUpdate([...joins, { ...newJoin, id: Date.now() }]);
    }
    setNewJoin({
      leftTable: tables[0]?.path || '',
      rightTable: tables[1]?.path || '',
      leftColumn: '',
      rightColumn: '',
      joinType: 'inner'
    });
  };

  const editJoin = (index) => { setEditingJoin(index); setNewJoin(joins[index]); };
  const deleteJoin = (index) => {
    if (window.confirm('Delete this join?')) onUpdate(joins.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <JoinIcon />
          <span>Configure Joins</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 'bold' }}>
            {editingJoin !== null
              ? <><EditIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Edit Join</>
              : <><AddIcon sx={{ fontSize: 18, mr: 0.5, verticalAlign: 'text-bottom' }} />Add New Join</>}
          </Typography>

          <Box sx={{ mb: 2 }}>
            <TextField
              select label="Join Type" fullWidth size="small"
              value={newJoin.joinType}
              onChange={e => setNewJoin({ ...newJoin, joinType: e.target.value })}
            >
              <MenuItem value="inner">INNER JOIN</MenuItem>
              <MenuItem value="left">LEFT JOIN</MenuItem>
              <MenuItem value="right">RIGHT JOIN</MenuItem>
              <MenuItem value="outer">FULL OUTER JOIN</MenuItem>
            </TextField>
          </Box>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} sx={{ mb: 1 }}>
            <Box sx={{ flex: 1 }}>
              <TextField
                select label="Left Table" fullWidth size="small"
                value={newJoin.leftTable}
                onChange={e => setNewJoin({ ...newJoin, leftTable: e.target.value, leftColumn: '' })}
                sx={{ mb: 1.5 }}
              >
                {tables.map(t => <MenuItem key={t.path} value={t.path}>{t.name}{t.folder ? ` (${t.folder})` : ''}</MenuItem>)}
              </TextField>
              <Autocomplete
                options={getAllColumns(newJoin.leftTable)}
                getOptionLabel={col => `${col.name} (${col.type})`}
                value={getAllColumns(newJoin.leftTable).find(c => c.name === newJoin.leftColumn) || null}
                onChange={(_, val) => setNewJoin({ ...newJoin, leftColumn: val?.name || '' })}
                renderInput={(params) => <TextField {...params} label="Left Column" size="small" placeholder="Search..." />}
                size="small"
                fullWidth
              />
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Typography variant="h5" color="text.secondary">=</Typography>
            </Box>

            <Box sx={{ flex: 1 }}>
              <TextField
                select label="Right Table" fullWidth size="small"
                value={newJoin.rightTable}
                onChange={e => setNewJoin({ ...newJoin, rightTable: e.target.value, rightColumn: '' })}
                sx={{ mb: 1.5 }}
              >
                {tables.map(t => <MenuItem key={t.path} value={t.path}>{t.name}{t.folder ? ` (${t.folder})` : ''}</MenuItem>)}
              </TextField>
              <Autocomplete
                options={getAllColumns(newJoin.rightTable)}
                getOptionLabel={col => `${col.name} (${col.type})`}
                value={getAllColumns(newJoin.rightTable).find(c => c.name === newJoin.rightColumn) || null}
                onChange={(_, val) => setNewJoin({ ...newJoin, rightColumn: val?.name || '' })}
                renderInput={(params) => <TextField {...params} label="Right Column" size="small" placeholder="Search..." />}
                size="small"
                fullWidth
              />
            </Box>
          </Stack>

          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 2 }}>
            {editingJoin !== null && (
              <Button
                variant="outlined"
                onClick={() => {
                  setEditingJoin(null);
                  setNewJoin({ leftTable: tables[0]?.path, rightTable: tables[1]?.path, leftColumn: '', rightColumn: '', joinType: 'inner' });
                }}
              >
                Cancel Edit
              </Button>
            )}
            <Button variant="contained" onClick={addJoin} startIcon={editingJoin !== null ? <SaveIcon /> : <AddIcon />}>
              {editingJoin !== null ? 'Update Join' : 'Add Join'}
            </Button>
          </Stack>
        </Paper>

        {joins.length > 0 && (
          <Box>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 'bold' }}>
              Configured Joins ({joins.length})
            </Typography>
            <Stack spacing={1}>
              {joins.map((join, index) => {
                const leftTable = tables.find(t => t.path === join.leftTable);
                const rightTable = tables.find(t => t.path === join.rightTable);
                return (
                  <Paper key={join.id} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Chip label={join.joinType.toUpperCase()} size="small" color="primary" />
                      <Typography variant="body2">
                        <strong>{leftTable?.name}</strong>.{join.leftColumn}
                        <Typography component="span" sx={{ mx: 1, color: 'text.secondary' }}>=</Typography>
                        <strong>{rightTable?.name}</strong>.{join.rightColumn}
                      </Typography>
                    </Box>
                    <Box>
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => editJoin(index)} color="primary">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton size="small" onClick={() => deleteJoin(index)} color="error">
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Paper>
                );
              })}
            </Stack>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// COLUMN SELECTOR MODAL - COMPLETE
// ============================================================================
const ColumnSelectorModal = ({ open, tables, schemas, selectedColumns, onUpdate, onClose }) => {
  const [colSearch, setColSearch] = React.useState('');

  const toggleColumn = (table, column) => {
    const exists = selectedColumns.find(c => c.tableName === table.name && c.columnName === column.name);
    if (exists) {
      onUpdate(selectedColumns.filter(c => !(c.tableName === table.name && c.columnName === column.name)));
    } else {
      onUpdate([...selectedColumns, { tableName: table.name, columnName: column.name, type: column.type }]);
    }
  };

  const selectAll = (table) => {
    const cols = schemas[table.path] || [];
    const newCols = cols.map(c => ({ tableName: table.name, columnName: c.name, type: c.type }));
    onUpdate([...selectedColumns.filter(c => c.tableName !== table.name), ...newCols]);
  };

  const deselectAll = (table) => {
    onUpdate(selectedColumns.filter(c => c.tableName !== table.name));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <ColumnIcon />
          <span>Select Columns</span>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <TextField
          size="small" fullWidth placeholder="Search columns..."
          value={colSearch} onChange={e => setColSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ mb: 2 }}
        />
        <Stack spacing={2}>
          {tables.map(table => {
            const allCols = schemas[table.path] || [];
            const cols = colSearch ? allCols.filter(c => c.name.toLowerCase().includes(colSearch.toLowerCase())) : allCols;
            return (
              <Paper key={table.path} variant="outlined" sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {table.name}
                    <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      ({cols.length}{colSearch ? ` / ${allCols.length}` : ''} columns)
                    </Typography>
                  </Typography>
                  <Stack direction="row" spacing={1}>
                    <Button size="small" onClick={() => selectAll(table)}>Select All</Button>
                    <Button size="small" onClick={() => deselectAll(table)}>Clear</Button>
                  </Stack>
                </Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 0.5 }}>
                  {cols.map(col => {
                    const isSelected = selectedColumns.find(c => c.tableName === table.name && c.columnName === col.name);
                    return (
                      <FormControlLabel
                        key={col.name}
                        control={<Checkbox checked={!!isSelected} onChange={() => toggleColumn(table, col)} size="small" />}
                        label={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Typography variant="body2">{col.name}</Typography>
                            <Typography variant="caption" color="text.secondary">({col.type})</Typography>
                          </Box>
                        }
                      />
                    );
                  })}
                </Box>
              </Paper>
            );
          })}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedColumns.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// AGGREGATION BUILDER MODAL
// ============================================================================
const NUMERIC_TYPES = new Set([
  'int8', 'int16', 'int32', 'int64', 'uint8', 'uint16', 'uint32', 'uint64',
  'float', 'float16', 'float32', 'float64', 'double', 'decimal', 'decimal128',
  'number', 'numeric', 'integer', 'bigint', 'smallint', 'tinyint', 'real',
]);
const isNumericCol = (type: string) => {
  const t = (type || '').toLowerCase().replace(/\(.*\)/, '').trim();
  return NUMERIC_TYPES.has(t);
};
const AGG_FUNCS_NUMERIC = ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
const AGG_FUNCS_ANY     = ['COUNT'];

const AggregationBuilderModal = ({ open, tables, schemas, selectedColumns, aggregations, onUpdate, onClose }) => {
  // Local copy for editing
  const [localAggs, setLocalAggs] = React.useState<any[]>([]);

  React.useEffect(() => {
    if (open) setLocalAggs(aggregations.length > 0 ? [...aggregations] : []);
  }, [open]); // eslint-disable-line

  // All columns from all selected tables
  const allCols = React.useMemo(() => {
    const cols: { table: string; name: string; type: string }[] = [];
    tables.forEach(t => {
      (schemas[t.path] || []).forEach(c => {
        cols.push({ table: t.name, name: c.name, type: c.type || '' });
      });
    });
    return cols;
  }, [tables, schemas]);

  const numericCols = allCols.filter(c => isNumericCol(c.type));

  const addAgg = () => {
    const first = numericCols[0] || allCols[0];
    if (!first) return;
    setLocalAggs(prev => [...prev, {
      column: first.name,
      function: isNumericCol(first.type) ? 'SUM' : 'COUNT',
      alias: '',
    }]);
  };

  const removeAgg = (idx: number) => setLocalAggs(prev => prev.filter((_, i) => i !== idx));
  const updateAgg = (idx: number, field: string, val: string | boolean) => {
    setLocalAggs(prev => prev.map((a, i) => {
      if (i !== idx) return a;
      const updated = { ...a, [field]: val };
      // When column changes, reset function if new column is non-numeric
      if (field === 'column') {
        const col = allCols.find(c => c.name === val);
        if (col && !isNumericCol(col.type) && updated.function !== 'COUNT') {
          updated.function = 'COUNT';
        }
      }
      return updated;
    }));
  };

  const handleDone = () => { onUpdate(localAggs); onClose(); };
  const handleClear = () => { setLocalAggs([]); onUpdate([]); onClose(); };

  // Derive group-by columns: selected columns NOT in the aggregation list
  const aggColSet = new Set(localAggs.map(a => a.column));
  const groupByCols = selectedColumns.filter(c => !aggColSet.has(c.columnName));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <AggIcon color="secondary" />
          <span>Aggregation — GROUP BY</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        {selectedColumns.length === 0 && (
          <Alert severity="info" sx={{ mb: 2 }}>Select columns first (via the Columns button), then define aggregations here.</Alert>
        )}

        {/* Aggregation rows */}
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Aggregations</Typography>
        <Stack spacing={1.5} sx={{ mb: 3 }}>
          {localAggs.length === 0 && (
            <Typography variant="body2" color="text.secondary">No aggregations defined — click "Add Aggregation" below.</Typography>
          )}
          {localAggs.map((agg, idx) => {
            const col = allCols.find(c => c.name === agg.column);
            const isNum = col ? isNumericCol(col.type) : false;
            const funcs = isNum ? AGG_FUNCS_NUMERIC : AGG_FUNCS_ANY;
            return (
              <Paper key={idx} variant="outlined" sx={{ p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
                <TextField
                  select size="small" label="Function" value={agg.function}
                  onChange={e => updateAgg(idx, 'function', e.target.value)}
                  sx={{ minWidth: 100 }}>
                  {funcs.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
                </TextField>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>(</Typography>
                <Autocomplete
                  options={allCols}
                  getOptionLabel={c => c.name}
                  getOptionDisabled={c => !isNumericCol(c.type) && agg.function !== 'COUNT'}
                  value={allCols.find(c => c.name === agg.column) || null}
                  onChange={(_, val) => updateAgg(idx, 'column', val?.name || '')}
                  renderOption={(props, c) => (
                    <li {...props} key={`${c.table}.${c.name}`}>
                      <Typography variant="body2">{c.name}</Typography>
                      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>{c.type}</Typography>
                    </li>
                  )}
                  renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search..." />}
                  size="small"
                  sx={{ minWidth: 180 }}
                />
                <Typography variant="body2" sx={{ fontWeight: 600 }}>)</Typography>
                {agg.function === 'COUNT' && (
                  <FormControlLabel
                    control={<Checkbox checked={agg.distinct || false} size="small"
                      onChange={e => updateAgg(idx, 'distinct', e.target.checked)} />}
                    label={<Typography variant="caption">DISTINCT</Typography>}
                    sx={{ ml: 0, mr: 0 }}
                  />
                )}
                <Typography variant="body2" color="text.secondary">AS</Typography>
                <TextField
                  size="small" label="Alias" value={agg.alias}
                  placeholder={`${agg.function.toLowerCase()}_${agg.column}`}
                  onChange={e => updateAgg(idx, 'alias', e.target.value)}
                  sx={{ minWidth: 150 }}
                />
                <IconButton size="small" color="error" onClick={() => removeAgg(idx)}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Paper>
            );
          })}
          <Button size="small" startIcon={<AddIcon />} onClick={addAgg} variant="outlined"
            disabled={allCols.length === 0}
            sx={{ alignSelf: 'flex-start' }}>
            Add Aggregation
          </Button>
        </Stack>

        {/* GROUP BY preview */}
        {localAggs.length > 0 && (
          <>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle2" sx={{ mb: 1 }}>GROUP BY (auto-derived)</Typography>
            {groupByCols.length > 0 ? (
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                {groupByCols.map(c => (
                  <Chip key={c.columnName} label={c.columnName} size="small" variant="outlined" />
                ))}
              </Box>
            ) : (
              <Alert severity="warning" sx={{ py: 0 }}>
                No GROUP BY columns — the query will return a single aggregated row.
                Select non-aggregated columns to group by.
              </Alert>
            )}
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              All selected columns that are <strong>not</strong> being aggregated automatically become GROUP BY columns.
            </Typography>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClear} color="warning" disabled={localAggs.length === 0}>Clear All</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" color="secondary" onClick={handleDone}>
          Done ({localAggs.length} aggregation{localAggs.length !== 1 ? 's' : ''})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// FILTER BUILDER MODAL — Enhanced with IS NULL, BETWEEN, NOT IN, AND/OR logic
// ============================================================================
const _FILTER_OPS = [
  { value: 'eq', label: '= (equals)' },
  { value: 'ne', label: '!= (not equals)' },
  { value: 'gt', label: '> (greater than)' },
  { value: 'gte', label: '>= (greater or equal)' },
  { value: 'lt', label: '< (less than)' },
  { value: 'lte', label: '<= (less or equal)' },
  { value: 'in', label: 'IN (comma-separated)' },
  { value: 'not_in', label: 'NOT IN (comma-separated)' },
  { value: 'contains', label: 'LIKE (contains)' },
  { value: 'not_contains', label: 'NOT LIKE' },
  { value: 'between', label: 'BETWEEN (range)' },
  { value: 'is_null', label: 'IS NULL' },
  { value: 'is_not_null', label: 'IS NOT NULL' },
];
const _NO_VALUE_OPS = new Set(['is_null', 'is_not_null']);
const _LIST_OPS = new Set(['in', 'not_in']);

const FilterBuilderModal = ({ open, tables, schemas, filters, filterLogic, onFilterLogicChange, onUpdate, onClose }) => {
  const [editingFilter, setEditingFilter] = useState(null);
  const [newFilter, setNewFilter] = useState<any>({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' });

  const allColumns = tables.flatMap(t =>
    (schemas[t.path] || []).map(c => ({ table: t.name, column: c.name, type: c.type }))
  ).sort((a, b) => a.column.localeCompare(b.column));

  const addFilter = () => {
    const noValue = _NO_VALUE_OPS.has(newFilter.operator);
    if (!newFilter.column || (!noValue && newFilter.operator !== 'between' && !newFilter.value)) {
      alert('Please fill all required fields');
      return;
    }
    if (newFilter.operator === 'between' && (!newFilter.value_low || !newFilter.value_high)) {
      alert('BETWEEN requires both low and high values');
      return;
    }
    if (editingFilter !== null) {
      const updated = [...filters];
      updated[editingFilter] = { ...newFilter, id: filters[editingFilter].id };
      onUpdate(updated);
      setEditingFilter(null);
    } else {
      onUpdate([...filters, { ...newFilter, id: Date.now() }]);
    }
    setNewFilter({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' });
  };

  const editFilter = (index) => { setEditingFilter(index); setNewFilter({ ...filters[index] }); };
  const deleteFilter = (index) => {
    if (window.confirm('Delete this filter?')) onUpdate(filters.filter((_, i) => i !== index));
  };

  const fmtFilter = (f: any) => {
    const opLabel: Record<string, string> = { eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=',
      in: 'IN', not_in: 'NOT IN', contains: 'LIKE', not_contains: 'NOT LIKE',
      between: 'BETWEEN', is_null: 'IS NULL', is_not_null: 'IS NOT NULL' };
    const op = opLabel[f.operator] || f.operator;
    if (_NO_VALUE_OPS.has(f.operator)) return `${f.column} ${op}`;
    if (f.operator === 'between') return `${f.column} ${op} ${f.value_low} AND ${f.value_high}`;
    return `${f.column} ${op} ${f.value}`;
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <FilterIcon />
          <span>Filters (WHERE)</span>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        {/* AND / OR toggle */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Typography variant="subtitle2">Combine filters with:</Typography>
          <ButtonGroup size="small">
            <Button variant={filterLogic === 'AND' ? 'contained' : 'outlined'}
              onClick={() => onFilterLogicChange('AND')}>AND</Button>
            <Button variant={filterLogic === 'OR' ? 'contained' : 'outlined'}
              color="warning" onClick={() => onFilterLogicChange('OR')}>OR</Button>
          </ButtonGroup>
        </Box>

        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
            {editingFilter !== null ? 'Edit Filter' : 'Add Filter'}
          </Typography>
          <Stack spacing={1.5}>
            <Autocomplete
              options={allColumns}
              getOptionLabel={col => `${col.table}.${col.column}`}
              value={allColumns.find(c => `${c.table}.${c.column}` === newFilter.column) || null}
              onChange={(_, val) => setNewFilter({ ...newFilter, column: val ? `${val.table}.${val.column}` : '' })}
              renderOption={(props, col) => (
                <li {...props} key={`${col.table}.${col.column}`}>
                  <Typography variant="body2">{col.table}.{col.column}</Typography>
                  <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>({col.type})</Typography>
                </li>
              )}
              renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search columns..." />}
              size="small"
              fullWidth
            />
            <TextField select label="Operator" fullWidth size="small"
              value={newFilter.operator} onChange={e => setNewFilter({ ...newFilter, operator: e.target.value })}>
              {_FILTER_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
            </TextField>
            {/* Conditional value fields */}
            {!_NO_VALUE_OPS.has(newFilter.operator) && (
              newFilter.operator === 'between' ? (
                <Stack direction="row" spacing={1}>
                  <TextField label="Low value" size="small" fullWidth value={newFilter.value_low || ''}
                    onChange={e => setNewFilter({ ...newFilter, value_low: e.target.value })} />
                  <TextField label="High value" size="small" fullWidth value={newFilter.value_high || ''}
                    onChange={e => setNewFilter({ ...newFilter, value_high: e.target.value })} />
                </Stack>
              ) : (
                <TextField label="Value" fullWidth size="small" value={newFilter.value}
                  onChange={e => setNewFilter({ ...newFilter, value: e.target.value })}
                  placeholder={_LIST_OPS.has(newFilter.operator) ? 'val1, val2, val3' : 'value'} />
              )
            )}
          </Stack>
          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 1.5 }}>
            {editingFilter !== null && (
              <Button variant="outlined" size="small"
                onClick={() => { setEditingFilter(null); setNewFilter({ column: '', operator: 'eq', value: '', value_low: '', value_high: '' }); }}>
                Cancel
              </Button>
            )}
            <Button variant="contained" size="small" onClick={addFilter}
              startIcon={editingFilter !== null ? <SaveIcon /> : <AddIcon />}>
              {editingFilter !== null ? 'Update' : 'Add'}
            </Button>
          </Stack>
        </Paper>

        {filters.length > 0 && (
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Active Filters ({filters.length})</Typography>
            <Stack spacing={0.5}>
              {filters.map((filter, index) => (
                <React.Fragment key={filter.id}>
                  {index > 0 && (
                    <Typography variant="caption" color="primary" sx={{ textAlign: 'center', fontWeight: 700 }}>
                      {filterLogic}
                    </Typography>
                  )}
                  <Paper variant="outlined" sx={{ p: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                      {fmtFilter(filter)}
                    </Typography>
                    <Box>
                      <IconButton size="small" onClick={() => editFilter(index)} color="primary"><EditIcon sx={{ fontSize: 16 }} /></IconButton>
                      <IconButton size="small" onClick={() => deleteFilter(index)} color="error"><DeleteIcon sx={{ fontSize: 16 }} /></IconButton>
                    </Box>
                  </Paper>
                </React.Fragment>
              ))}
            </Stack>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// HAVING BUILDER MODAL — filter on aggregated results
// ============================================================================
const _HAVING_OPS = [
  { value: 'eq', label: '=' }, { value: 'ne', label: '!=' },
  { value: 'gt', label: '>' }, { value: 'gte', label: '>=' },
  { value: 'lt', label: '<' }, { value: 'lte', label: '<=' },
];
const _AGG_FNS = ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];

const HavingBuilderModal = ({ open, aggregations, tables, schemas, having, onUpdate, onClose }) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(having.length > 0 ? [...having] : []); }, [open]);

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => {
    const col = allCols[0] || '';
    setLocal(prev => [...prev, { column: col, function: 'SUM', operator: 'gt', value: '' }]);
  };
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: any) => setLocal(prev => prev.map((h, idx) => idx === i ? { ...h, [field]: val } : h));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>HAVING — Filter Aggregated Results</DialogTitle>
      <DialogContent dividers>
        {aggregations.length === 0 && <Alert severity="info">Add aggregations first to use HAVING.</Alert>}
        <Stack spacing={1.5}>
          {local.map((h, i) => (
            <Paper key={i} variant="outlined" sx={{ p: 1.5, display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
              <TextField select size="small" label="Function" value={h.function} sx={{ minWidth: 90 }}
                onChange={e => update(i, 'function', e.target.value)}>
                {_AGG_FNS.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
              </TextField>
              <Typography variant="body2">(</Typography>
              <Autocomplete
                options={allCols}
                value={h.column || null}
                onChange={(_, val) => update(i, 'column', val || '')}
                renderInput={(params) => <TextField {...params} label="Column" size="small" placeholder="Search..." />}
                size="small"
                sx={{ minWidth: 160 }}
                disableClearable
              />
              <Typography variant="body2">)</Typography>
              <TextField select size="small" label="Op" value={h.operator} sx={{ minWidth: 70 }}
                onChange={e => update(i, 'operator', e.target.value)}>
                {_HAVING_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
              </TextField>
              <TextField size="small" label="Value" value={h.value} sx={{ minWidth: 100 }}
                onChange={e => update(i, 'value', e.target.value)} />
              <IconButton size="small" color="error" onClick={() => remove(i)}><DeleteIcon fontSize="small" /></IconButton>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add HAVING Condition
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// COMPUTED COLUMN BUILDER — expressions, date/string functions
// ============================================================================
const ComputedColumnBuilderModal = ({ open, tables, schemas, computedColumns, onUpdate, onClose }) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(computedColumns.length > 0 ? [...computedColumns] : []); }, [open]);

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => setLocal(prev => [...prev, { expression: '', alias: '' }]);
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: string) => setLocal(prev => prev.map((c, idx) => idx === i ? { ...c, [field]: val } : c));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><ComputedIcon color="info" /> Computed Columns</Box></DialogTitle>
      <DialogContent dividers>
        <Alert severity="info" sx={{ mb: 2, fontSize: 12 }}>
          Write SQL expressions using column names and functions. Available columns: <strong>{allCols.slice(0, 10).join(', ')}{allCols.length > 10 ? '...' : ''}</strong>
          <br />Operators: <code>+ - * / %</code> | Functions: <code>YEAR(), MONTH(), DATE_TRUNC(), UPPER(), LOWER(), CONCAT(), SUBSTRING(), ROUND(), COALESCE(), CAST(), ABS(), LENGTH()</code>
        </Alert>
        <Stack spacing={1.5}>
          {local.map((cc, i) => (
            <Paper key={i} variant="outlined" sx={{ p: 1.5, display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField size="small" label="Expression" value={cc.expression} fullWidth
                placeholder="e.g. price * quantity" onChange={e => update(i, 'expression', e.target.value)} />
              <Typography variant="body2" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>AS</Typography>
              <TextField size="small" label="Alias" value={cc.alias} sx={{ minWidth: 150 }}
                placeholder="e.g. total_price" onChange={e => update(i, 'alias', e.target.value)} />
              <IconButton size="small" color="error" onClick={() => remove(i)}><DeleteIcon fontSize="small" /></IconButton>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add Computed Column
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(c => c.expression && c.alias)); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// CASE EXPRESSION BUILDER — CASE WHEN ... THEN ... ELSE ... END
// ============================================================================
const _CASE_OPS = [
  { value: 'eq', label: '=' }, { value: 'ne', label: '!=' },
  { value: 'gt', label: '>' }, { value: 'gte', label: '>=' },
  { value: 'lt', label: '<' }, { value: 'lte', label: '<=' },
  { value: 'is_null', label: 'IS NULL' }, { value: 'is_not_null', label: 'IS NOT NULL' },
];

const CaseExpressionBuilderModal = ({ open, tables, schemas, caseExpressions, onUpdate, onClose }) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(caseExpressions.length > 0 ? caseExpressions.map(ce => ({ ...ce })) : []); }, [open]);

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const addCase = () => setLocal(prev => [...prev, {
    alias: '', else_value: '',
    when_clauses: [{ when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }],
  }]);
  const removeCase = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const updateCase = (i: number, field: string, val: any) => setLocal(prev => prev.map((ce, idx) => idx === i ? { ...ce, [field]: val } : ce));

  const addWhen = (i: number) => {
    const updated = [...local];
    updated[i] = { ...updated[i], when_clauses: [...updated[i].when_clauses, { when_column: allCols[0] || '', when_operator: 'eq', when_value: '', then_value: '' }] };
    setLocal(updated);
  };
  const removeWhen = (ci: number, wi: number) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.filter((_, j) => j !== wi) };
    setLocal(updated);
  };
  const updateWhen = (ci: number, wi: number, field: string, val: string) => {
    const updated = [...local];
    updated[ci] = { ...updated[ci], when_clauses: updated[ci].when_clauses.map((w, j) => j === wi ? { ...w, [field]: val } : w) };
    setLocal(updated);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CaseIcon color="info" /> CASE WHEN Expressions</Box></DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          {local.map((ce, ci) => (
            <Paper key={ci} variant="outlined" sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', gap: 1, mb: 1.5, alignItems: 'center' }}>
                <TextField size="small" label="Result Alias" value={ce.alias} sx={{ minWidth: 160 }}
                  placeholder="e.g. category_label" onChange={e => updateCase(ci, 'alias', e.target.value)} />
                <Box sx={{ flex: 1 }} />
                <IconButton size="small" color="error" onClick={() => removeCase(ci)}><DeleteIcon fontSize="small" /></IconButton>
              </Box>
              {ce.when_clauses.map((w: any, wi: number) => (
                <Box key={wi} sx={{ display: 'flex', gap: 0.75, alignItems: 'center', mb: 1, flexWrap: 'wrap' }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, minWidth: 40 }}>WHEN</Typography>
                  <TextField select size="small" label="Column" value={w.when_column} sx={{ minWidth: 120 }}
                    onChange={e => updateWhen(ci, wi, 'when_column', e.target.value)}>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" label="Op" value={w.when_operator} sx={{ minWidth: 80 }}
                    onChange={e => updateWhen(ci, wi, 'when_operator', e.target.value)}>
                    {_CASE_OPS.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
                  </TextField>
                  {!_NO_VALUE_OPS.has(w.when_operator) && (
                    <TextField size="small" label="Value" value={w.when_value} sx={{ minWidth: 80 }}
                      onChange={e => updateWhen(ci, wi, 'when_value', e.target.value)} />
                  )}
                  <Typography variant="caption" sx={{ fontWeight: 700 }}>THEN</Typography>
                  <TextField size="small" label="Result" value={w.then_value} sx={{ minWidth: 80 }}
                    onChange={e => updateWhen(ci, wi, 'then_value', e.target.value)} />
                  <IconButton size="small" onClick={() => removeWhen(ci, wi)} disabled={ce.when_clauses.length <= 1}>
                    <CloseIcon sx={{ fontSize: 14 }} />
                  </IconButton>
                </Box>
              ))}
              <Button size="small" onClick={() => addWhen(ci)} sx={{ mb: 1 }}>+ Add WHEN</Button>
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                <Typography variant="caption" sx={{ fontWeight: 700, minWidth: 40 }}>ELSE</Typography>
                <TextField size="small" label="Default value" value={ce.else_value || ''} fullWidth
                  onChange={e => updateCase(ci, 'else_value', e.target.value)} />
              </Box>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={addCase} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add CASE Expression
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(ce => ce.alias && ce.when_clauses.length > 0)); onClose(); }}>
          Done ({local.length})
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// WINDOW FUNCTION BUILDER — ROW_NUMBER, RANK, LAG, LEAD, etc.
// ============================================================================
const _WINDOW_FNS = ['ROW_NUMBER', 'RANK', 'DENSE_RANK', 'LAG', 'LEAD', 'SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
const _WINDOW_NO_COL = new Set(['ROW_NUMBER', 'RANK', 'DENSE_RANK']);

const WindowFunctionBuilderModal = ({ open, tables, schemas, windowFunctions, onUpdate, onClose }) => {
  const [local, setLocal] = React.useState<any[]>([]);
  React.useEffect(() => { if (open) setLocal(windowFunctions.length > 0 ? windowFunctions.map(wf => ({ ...wf })) : []); }, [open]);

  const allCols = React.useMemo(() => {
    const cols: string[] = [];
    tables.forEach(t => (schemas[t.path] || []).forEach(c => { if (!cols.includes(c.name)) cols.push(c.name); }));
    return cols.sort((a, b) => a.localeCompare(b));
  }, [tables, schemas]);

  const add = () => setLocal(prev => [...prev, {
    function: 'ROW_NUMBER', alias: '', column: '', partition_by: [], order_by: [{ column: allCols[0] || '', direction: 'ASC' }],
    offset: 1, default_value: '',
  }]);
  const remove = (i: number) => setLocal(prev => prev.filter((_, idx) => idx !== i));
  const update = (i: number, field: string, val: any) => setLocal(prev => prev.map((wf, idx) => idx === i ? { ...wf, [field]: val } : wf));

  const addOrderBy = (i: number) => {
    const updated = [...local];
    updated[i] = { ...updated[i], order_by: [...(updated[i].order_by || []), { column: allCols[0] || '', direction: 'ASC' }] };
    setLocal(updated);
  };
  const removeOrderBy = (wi: number, oi: number) => {
    const updated = [...local];
    updated[wi] = { ...updated[wi], order_by: updated[wi].order_by.filter((_, j) => j !== oi) };
    setLocal(updated);
  };
  const updateOrderBy = (wi: number, oi: number, field: string, val: string) => {
    const updated = [...local];
    updated[wi] = { ...updated[wi], order_by: updated[wi].order_by.map((o, j) => j === oi ? { ...o, [field]: val } : o) };
    setLocal(updated);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle><Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><WindowIcon color="info" /> Window Functions</Box></DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          {local.map((wf, wi) => (
            <Paper key={wi} variant="outlined" sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', gap: 1, mb: 1.5, alignItems: 'center', flexWrap: 'wrap' }}>
                <TextField select size="small" label="Function" value={wf.function} sx={{ minWidth: 130 }}
                  onChange={e => update(wi, 'function', e.target.value)}>
                  {_WINDOW_FNS.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
                </TextField>
                {!_WINDOW_NO_COL.has(wf.function) && (
                  <TextField select size="small" label="Column" value={wf.column || ''} sx={{ minWidth: 140 }}
                    onChange={e => update(wi, 'column', e.target.value)}>
                    <MenuItem value="">-- select --</MenuItem>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                )}
                {['LAG', 'LEAD'].includes(wf.function) && (
                  <>
                    <TextField size="small" label="Offset" type="number" value={wf.offset || 1} sx={{ width: 80 }}
                      onChange={e => update(wi, 'offset', parseInt(e.target.value) || 1)} />
                    <TextField size="small" label="Default" value={wf.default_value || ''} sx={{ width: 100 }}
                      onChange={e => update(wi, 'default_value', e.target.value)} />
                  </>
                )}
                <Typography variant="body2" color="text.secondary">AS</Typography>
                <TextField size="small" label="Alias" value={wf.alias} sx={{ minWidth: 130 }}
                  placeholder="e.g. row_num" onChange={e => update(wi, 'alias', e.target.value)} />
                <Box sx={{ flex: 1 }} />
                <IconButton size="small" color="error" onClick={() => remove(wi)}><DeleteIcon fontSize="small" /></IconButton>
              </Box>
              {/* PARTITION BY */}
              <Box sx={{ mb: 1 }}>
                <Typography variant="caption" sx={{ fontWeight: 700 }}>PARTITION BY</Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.5 }}>
                  {allCols.map(c => (
                    <Chip key={c} label={c} size="small" variant={(wf.partition_by || []).includes(c) ? 'filled' : 'outlined'}
                      color={(wf.partition_by || []).includes(c) ? 'primary' : 'default'}
                      onClick={() => {
                        const pb = wf.partition_by || [];
                        update(wi, 'partition_by', pb.includes(c) ? pb.filter(x => x !== c) : [...pb, c]);
                      }}
                      sx={{ cursor: 'pointer' }} />
                  ))}
                </Box>
              </Box>
              {/* ORDER BY */}
              <Typography variant="caption" sx={{ fontWeight: 700 }}>ORDER BY</Typography>
              {(wf.order_by || []).map((o: any, oi: number) => (
                <Box key={oi} sx={{ display: 'flex', gap: 0.75, alignItems: 'center', mt: 0.5 }}>
                  <TextField select size="small" value={o.column} sx={{ minWidth: 120 }}
                    onChange={e => updateOrderBy(wi, oi, 'column', e.target.value)}>
                    {allCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" value={o.direction} sx={{ minWidth: 80 }}
                    onChange={e => updateOrderBy(wi, oi, 'direction', e.target.value)}>
                    <MenuItem value="ASC">ASC</MenuItem>
                    <MenuItem value="DESC">DESC</MenuItem>
                  </TextField>
                  <IconButton size="small" onClick={() => removeOrderBy(wi, oi)}><CloseIcon sx={{ fontSize: 14 }} /></IconButton>
                </Box>
              ))}
              <Button size="small" onClick={() => addOrderBy(wi)} sx={{ mt: 0.5 }}>+ Order By</Button>
            </Paper>
          ))}
          <Button size="small" startIcon={<AddIcon />} onClick={add} variant="outlined" sx={{ alignSelf: 'flex-start' }}>
            Add Window Function
          </Button>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => { setLocal([]); onUpdate([]); onClose(); }} color="warning">Clear</Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onUpdate(local.filter(wf => wf.alias)); onClose(); }}>Done ({local.length})</Button>
      </DialogActions>
    </Dialog>
  );
};

// ============================================================================
// SAVE QUERY MODAL — supports both create and update
// ============================================================================
const SaveQueryModal = ({ open, queryConfig, sqlPreview, editingQueryId, editingQueryName, onClose, onSaved }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  // Pre-fill name when editing
  useEffect(() => {
    if (open) {
      setName(editingQueryName || '');
      setDescription('');
    }
  }, [open, editingQueryName]);

  const handleSave = async () => {
    if (!name.trim()) { alert('Please enter a query name'); return; }
    try {
      const payload = { name: name.trim(), description: description || null, query_config: queryConfig };
      let result;
      if (editingQueryId) {
        result = await api.updateQuery(editingQueryId, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated successfully` });
      } else {
        result = await api.saveQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved successfully` });
      }
      if (onSaved && result) onSaved(result.id || editingQueryId, name.trim());
      onClose();
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Save Error', message: error.message });
    }
  };

  const isEditing = !!editingQueryId;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <SaveIcon />
          <span>{isEditing ? 'Update Query' : 'Save Query'}</span>
          {isEditing && <Chip label="Editing" size="small" color="warning" sx={{ ml: 1 }} />}
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField
            label="Query Name" required fullWidth
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g., Monthly Sales Report"
            onKeyDown={e => e.key === 'Enter' && handleSave()}
          />
          <TextField
            label="Description" fullWidth multiline rows={2}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Optional description"
          />
          <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
              SQL Preview
            </Typography>
            <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 12, m: 0, whiteSpace: 'pre-wrap', color: 'text.primary', maxHeight: 120, overflowY: 'auto' }}>
              {sqlPreview}
            </Box>
          </Paper>
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {isEditing ? 'Update Query' : 'Save Query'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CompleteQueryBuilder;
