"""
DuckDB view/table management — registered S3 tables, MV views, local tables.

Extracted from main.py for maintainability.

Functions:
- SQLCollector           — fake DuckDB connection that records SQL
- setup_registered_views — resolve __registered__: → DuckDB views + build SQL
- execute_registered_table_query  — stream Arrow tables from registered views
- execute_registered_table_copy_to — COPY TO parquet via subprocess
- s3_full_copy           — download full dataset from S3 (LIMIT stripped)
- join_inflight_query    — shadow execution dedup (waits for primary)
- run_base_data_local_query — re-query local parquet without S3 round-trip
- register_s3_views      — register S3/MV/local views in a DuckDB connection
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time as _time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Module-level singletons — populated by init_duckdb_views() ─────────────
_db_manager = None
_paths = None
_ws_manager = None
_mv_cfg = None
_lt_cfg = None
_limits_cfg = None


def init_duckdb_views(db_manager, paths, ws_manager, mv_cfg, lt_cfg, limits_cfg):
    """Call once from main.py _startup() after all components are initialised."""
    global _db_manager, _paths, _ws_manager, _mv_cfg, _lt_cfg, _limits_cfg
    _db_manager = db_manager
    _paths = paths
    _ws_manager = ws_manager
    _mv_cfg = mv_cfg
    _lt_cfg = lt_cfg
    _limits_cfg = limits_cfg


# ── Imports from extracted modules ──────────────────────────────────────────
from core.iceberg_cache import (
    ice_cache_key as _ice_cache_key,
    ice_cache_get as _ice_cache_get,
    ice_cache_set as _ice_cache_set,
)
from core.s3_utilities import (
    list_s3_parquet_files as _list_s3_parquet_files,
    s3_urls_to_presigned as _s3_urls_to_presigned,
    make_s3_client_for_conn as _make_s3_client_for_conn,
    filter_iceberg_files_by_partitions as _filter_iceberg_files_by_partitions,
)
from core.query_converter import strip_sql_limit as _strip_sql_limit


# ═══════════════════════════════════════════════════════════════════════════
# SQLCollector
# ═══════════════════════════════════════════════════════════════════════════

class SQLCollector:
    """Fake DuckDB connection that records SQL instead of executing it.

    Used by setup_registered_views(con=collector) to capture CREATE VIEW
    statements so they can be replayed in a crash-isolated subprocess.
    """
    def __init__(self):
        self.statements: list[str] = []

    def execute(self, sql: str):
        self.statements.append(sql)

    def close(self):
        pass


# ═══════════════════════════════════════════════════════════════════════════
# setup_registered_views
# ═══════════════════════════════════════════════════════════════════════════

def setup_registered_views(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
    con=None,
):
    """Set up DuckDB views for registered S3 tables and build query SQL.

    If *con* is provided (e.g. a SQLCollector), it is used instead of
    creating a real DuckDB connection — this lets callers capture the
    generated SQL without touching DuckDB.

    Resolves __registered__:table_name → DuckDB views backed by:
      - Iceberg: read Iceberg manifests → read_parquet([active files])
      - Parquet: read_parquet('s3://bucket/prefix/**/*.parquet')
      - CSV: read_csv_auto('s3://bucket/prefix/**/*.csv')

    Returns (con, sql, auto_partition_info).
    Caller MUST close con in a finally block.
    """
    import duckdb as _ddb
    from api.data_grid_api import _duckdb_con_with_s3

    _esc = lambda v: v.replace("'", "''")
    own_con = con is None
    if own_con:
        con = _duckdb_con_with_s3(conn_config, connection_id=connection_id)

    # ── Extract hive partition filter from query ──────────────────────────
    from core.s3_utilities import extract_partition_filters_from_query as _extract_pf
    partition_filters = _extract_pf(query_config)

    _auto_partition_applied = None

    # ── Register each table ──────────────────────────────────────────────
    for tbl in (registered_tables or []):
        tname = tbl["name"]
        tname_esc = tname.replace('"', '""')
        fmt = tbl.get("format", "parquet")
        prefix = tbl["s3_prefix"].rstrip("/")

        if fmt == "iceberg":
            try:
                cache_key = _ice_cache_key(connection_id, tname, None)
                cached = _ice_cache_get(cache_key)
                if cached:
                    data_files = cached["files"]
                else:
                    from core.iceberg_reader import get_iceberg_data_files
                    s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})
                    raw_files = get_iceberg_data_files(s3_client, bucket, tbl["s3_prefix"], keys_only=True)
                    _rc = sum(f.get("record_count", 0) for f in raw_files if isinstance(f, dict))
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in raw_files
                    ]
                    _ice_cache_set(cache_key, data_files, None, record_count=_rc)

                if data_files:
                    # Normalize cached entries
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in data_files
                    ]
                    total_all = len(data_files)
                    if partition_filters:
                        data_files = _filter_iceberg_files_by_partitions(data_files, partition_filters)
                        if data_files and len(data_files) < total_all:
                            _auto_partition_applied = {
                                "table": tname,
                                "total_files": total_all,
                                "filtered_files": len(data_files),
                                "filters": partition_filters,
                            }
                    if not data_files:
                        # All pruned — create empty view
                        s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})
                        try:
                            from core.iceberg_reader import get_iceberg_data_files as _gdf
                            _schema_files = _gdf(s3_client, bucket, tbl["s3_prefix"], keys_only=True, max_files=1)
                            if _schema_files:
                                _sf = f"s3://{bucket}/{_schema_files[0]['key']}"
                                _sf = _s3_urls_to_presigned(s3_client, [_sf], conn_config)[0]
                                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_sf)}\', hive_partitioning=true) WHERE FALSE')
                        except Exception:
                            pass
                    else:
                        # Safety cap
                        _MAX_FILES = getattr(_limits_cfg, 'max_registered_files', 5000) if _limits_cfg else 5000
                        if len(data_files) > _MAX_FILES:
                            data_files = data_files[-_MAX_FILES:]
                        s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})
                        data_files = _s3_urls_to_presigned(s3_client, data_files, conn_config)
                        paths_str = ", ".join(f"'{_esc(f)}'" for f in data_files)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true, union_by_name=true)')
                        if progress_fn:
                            progress_fn({"status": "processing",
                                         "log": f"Registered '{tname}' ({len(data_files)}/{total_all} Iceberg files)"})
            except Exception as e:
                logger.warning("Could not register Iceberg view '%s': %s", tname, e)
                if progress_fn:
                    progress_fn({"status": "processing", "log": f"Warning: {tname} — {str(e)[:200]}"})

        elif fmt == "parquet":
            try:
                s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})
                pq_files = _list_s3_parquet_files(s3_client, bucket, prefix)
                _is_onprem = conn_config.get("path_style", False)
                if pq_files:
                    total_pq = len(pq_files)
                    logger.info("REG-VIEW '%s': %d parquet files listed (on_prem=%s)", tname, total_pq, _is_onprem)
                    if partition_filters:
                        pq_files = _filter_iceberg_files_by_partitions(pq_files, partition_filters)
                        if pq_files and len(pq_files) < total_pq:
                            _auto_partition_applied = {
                                "table": tname,
                                "total_files": total_pq,
                                "filtered_files": len(pq_files),
                                "filters": partition_filters,
                            }
                            logger.info("REG-VIEW '%s': partition pruning %d→%d files", tname, total_pq, len(pq_files))
                    if not pq_files:
                        logger.info("REG-VIEW '%s': 0 files after pruning — creating empty view", tname)
                        _schema_pq = _list_s3_parquet_files(s3_client, bucket, prefix, max_files=1)
                        if _schema_pq:
                            _schema_urls = _s3_urls_to_presigned(s3_client, _schema_pq[:1], conn_config)
                            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_schema_urls[0])}\', hive_partitioning=true) WHERE FALSE')
                    else:
                        _MAX_FILES = getattr(_limits_cfg, 'max_registered_files', 5000) if _limits_cfg else 5000
                        if len(pq_files) > _MAX_FILES:
                            pq_files = pq_files[-_MAX_FILES:]
                        pq_files = _s3_urls_to_presigned(s3_client, pq_files, conn_config)
                        if _is_onprem and pq_files:
                            logger.info("REG-VIEW '%s': sample pre-signed URL (first 200 chars): %s",
                                        tname, pq_files[0][:200])
                        paths_str = ", ".join(f"'{_esc(f)}'" for f in pq_files)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true, union_by_name=true)')
                        if progress_fn:
                            progress_fn({"status": "processing",
                                         "log": f"Registered '{tname}' ({len(pq_files)} parquet files)"})
                else:
                    logger.warning("REG-VIEW '%s': no parquet files found under %s/%s — falling back to glob", tname, bucket, prefix)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.parquet\', hive_partitioning=true)')
            except Exception as e:
                logger.warning("Could not register parquet view '%s': %s", tname, e)
                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.parquet\', hive_partitioning=true)')

        elif fmt == "csv":
            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.csv\')')

    # ── Register materialized views as local VIEWs ─────────────────────
    _mv_storage = getattr(_mv_cfg, 'storage_dir', None) if _mv_cfg else None
    if _mv_storage and _db_manager:
        try:
            mv_list = _db_manager.list_materialized_views(connection_id=connection_id)
            for mv in mv_list:
                if mv["status"] != "ready" or not mv.get("is_active", True):
                    continue
                mv_name = mv["name"]
                tname_esc_mv = f"__mv__{mv_name}".replace('"', '""')
                mv_dir = os.path.join(_mv_storage, str(mv["id"]))
                import glob as _glob_mod
                pq_files = _glob_mod.glob(os.path.join(mv_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc_mv}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
        except Exception as e:
            logger.warning("Could not register MV views: %s", e)

    # ── Register local tables as local VIEWs ───────────────────────────
    _lt_storage = getattr(_lt_cfg, 'storage_dir', None) if _lt_cfg else None
    if _lt_storage and _db_manager:
        try:
            import glob as _glob_mod2
            lt_list = _db_manager.list_local_tables()
            for lt in lt_list:
                if lt["status"] != "ready" or not lt.get("is_active", True):
                    continue
                lt_name = lt["name"]
                tname_esc_lt = f"__lt__{lt_name}".replace('"', '""')
                lt_dir = os.path.join(_lt_storage, str(lt["id"]))
                pq_files = _glob_mod2.glob(os.path.join(lt_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc_lt}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    try:
                        _db_manager.touch_local_table(lt["id"])
                    except Exception:
                        pass
        except Exception as e:
            logger.warning("Could not register local table views: %s", e)

    # ── Build SQL ──────────────────────────────────────────────────────
    from core.query_converter import rewrite_registered_refs
    from_clause = engine._build_duckdb_from_clause(query_config)
    sql = engine.build_query_sql(query_config, from_clause)
    sql = rewrite_registered_refs(sql, registered_tables)
    logger.info("Registered table SQL:\n%s", sql)

    return con, sql, _auto_partition_applied


# ═══════════════════════════════════════════════════════════════════════════
# execute_registered_table_query
# ═══════════════════════════════════════════════════════════════════════════

def execute_registered_table_query(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
):
    """Execute a query against registered S3 tables, streaming results as Arrow tables."""
    import pyarrow as _pa

    con, sql, auto_part = setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn)

    if auto_part:
        query_config._auto_partition = auto_part

    try:
        if progress_fn:
            progress_fn({"status": "processing", "log": "Executing SQL query on S3 data..."})

        _t0 = _time.monotonic()
        result = con.execute(sql)
        reader = result.fetch_record_batch(rows_per_batch=engine.chunk_size)
        total = 0
        for batch in reader:
            if len(batch) == 0:
                continue
            total += len(batch)
            elapsed = _time.monotonic() - _t0
            if progress_fn:
                progress_fn({"status": "processing",
                             "log": f"Streaming: {total:,} rows [{elapsed:.1f}s]"})
            yield _pa.Table.from_batches([batch])

        elapsed = _time.monotonic() - _t0
        if progress_fn:
            progress_fn({"status": "processing",
                         "log": f"Query returned {total:,} rows [{elapsed:.1f}s]"})
    finally:
        con.close()


# ═══════════════════════════════════════════════════════════════════════════
# execute_registered_table_copy_to
# ═══════════════════════════════════════════════════════════════════════════

def execute_registered_table_copy_to(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    output_path: str,
    connection_id: int = None,
    progress_fn=None,
    cancel_event=None,
):
    """Execute registered table query using DuckDB COPY TO (fast path).

    Runs DuckDB in a **subprocess** for crash isolation — a C-level crash
    (access violation / segfault) in DuckDB only kills the child process,
    not the main backend.
    """
    import pyarrow.parquet as _pq

    # Phase 1: Resolve files + build SQL (no DuckDB, safe)
    collector = SQLCollector()
    _, sql, auto_part = setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn, con=collector)

    # Build KV metadata clause for auto_partition
    kv_meta = {}
    if auto_part:
        kv_meta["auto_partition"] = json.dumps(auto_part)
    kv_clause = ""
    if kv_meta:
        kv_pairs = ", ".join(f"'{k}': '{v}'" for k, v in kv_meta.items())
        kv_clause = f", KV_METADATA {{{kv_pairs}}}"

    setup_sql_str = ";\n".join(collector.statements)
    logger.info("COPY TO setup SQL (%d statements):\n%s", len(collector.statements), setup_sql_str[:2000])
    logger.info("COPY TO inner SQL:\n%s", sql)

    # Two-phase execution: preview + full download
    result = s3_full_copy(
        inner_sql=sql,
        output_path=output_path,
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql_str,
        connection_id=connection_id,
        progress_fn=progress_fn,
        timeout=600,
        kv_clause=kv_clause,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]

    # Write auto_partition to Parquet KV metadata
    if auto_part and os.path.exists(output_path):
        try:
            meta = _pq.read_metadata(output_path)
            if not meta.metadata or b"auto_partition" not in (meta.metadata or {}):
                tbl = _pq.read_table(output_path)
                existing = tbl.schema.metadata or {}
                existing[b"auto_partition"] = json.dumps(auto_part).encode()
                tbl = tbl.replace_schema_metadata(existing)
                _pq.write_table(tbl, output_path, compression="ZSTD")
                total_rows = len(tbl)
                file_size = os.path.getsize(output_path)
        except Exception as _meta_exc:
            logger.warning("Could not embed auto_partition metadata: %s", _meta_exc)

    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"COPY TO complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "status": "completed",
        "chunks_processed": 1,
    }


# ═══════════════════════════════════════════════════════════════════════════
# s3_full_copy
# ═══════════════════════════════════════════════════════════════════════════

def s3_full_copy(
    inner_sql: str,
    output_path: str,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str = "",
    connection_id=None,
    progress_fn=None,
    timeout: int = 600,
    kv_clause: str = "",
) -> dict:
    """Download the full dataset from S3 — LIMIT is stripped so the cache
    always contains the complete result set.
    """
    from core.duckdb_subprocess import run_duckdb_copy_to

    full_sql = _strip_sql_limit(inner_sql)
    safe_out = output_path.replace("\\", "/").replace("'", "''")

    if progress_fn:
        progress_fn({"status": "processing", "log": "Processing query from S3…"})

    copy_sql = (
        f"COPY ({full_sql}) TO '{safe_out}' "
        f"(FORMAT PARQUET, COMPRESSION ZSTD{kv_clause})"
    )
    result = run_duckdb_copy_to(
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql,
        copy_sql=copy_sql,
        output_path=output_path,
        connection_id=connection_id,
        timeout=timeout,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]
    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"Processing complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {"total_rows": total_rows, "file_size_bytes": file_size,
            "status": "completed", "chunks_processed": 1}


# ═══════════════════════════════════════════════════════════════════════════
# join_inflight_query
# ═══════════════════════════════════════════════════════════════════════════

async def join_inflight_query(shadow_id: str, cache_key: str,
                              event: "asyncio.Event", primary_id: str) -> None:
    """Wait for a primary execution to finish then serve its result to a shadow execution."""
    try:
        await asyncio.wait_for(event.wait(), timeout=660)
    except asyncio.TimeoutError:
        logger.warning("[dedup] Shadow %s timed out waiting for primary %s", shadow_id[:8], primary_id[:8])
        _db_manager.update_execution(shadow_id, status="failed",
                                     error_message="Timed out waiting for shared execution")
        await _ws_manager.broadcast({
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Timed out waiting for shared execution",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        return

    # Primary finished — check if its output file exists
    output_file = _paths.downloads_dir / f"{primary_id}.parquet"
    if output_file.exists():
        try:
            file_size = output_file.stat().st_size
        except FileNotFoundError:
            file_size = 0
            output_file = None

    if output_file and output_file.exists():
        file_id = str(uuid.uuid4())
        _primary_rec = _db_manager.get_execution(primary_id) or {}
        _db_manager.update_execution(shadow_id, status="completed",
                                     output_file=str(output_file),
                                     total_rows=_primary_rec.get("total_rows", 0),
                                     file_size_bytes=file_size)
        _db_manager.create_download_file(
            file_id=file_id, execution_id=shadow_id,
            filename=f"result_{shadow_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=file_size,
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        await _ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": shadow_id,
            "file_id": file_id,
            "shared_from": primary_id,
            "stats": {
                "total_rows": _primary_rec.get("total_rows", 0),
                "total_columns": _primary_rec.get("total_columns"),
                "duration_seconds": _primary_rec.get("duration_seconds"),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("[dedup] Shadow %s completed via primary %s (shared file)", shadow_id[:8], primary_id[:8])
    else:
        _db_manager.update_execution(shadow_id, status="failed",
                                     error_message=f"Shared execution {primary_id[:8]} failed")
        await _ws_manager.broadcast({
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Shared execution failed — please retry",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.warning("[dedup] Shadow %s failed because primary %s failed", shadow_id[:8], primary_id[:8])


# ═══════════════════════════════════════════════════════════════════════════
# run_base_data_local_query
# ═══════════════════════════════════════════════════════════════════════════

def run_base_data_local_query(
    base_parquet: Path, query_config: dict, output_path: Path,
) -> Optional[dict]:
    """Run a presentation-only SQL against an already-downloaded local parquet.

    The base_parquet contains rows matching the original FROM/WHERE/JOIN from
    a previous S3 download.  We only need SELECT / aggregation / GROUP BY /
    ORDER BY / LIMIT on top — no network round-trip.

    Returns {"total_rows": int, "file_size_bytes": int} on success, None on
    failure (e.g. missing columns in the cached file).
    """
    try:
        import duckdb as _ddb
    except ImportError:
        return None
    con = None
    try:
        con = _ddb.connect(database=":memory:")
        pq_path = str(base_parquet).replace("\\", "/")

        # ── Build presentation SQL ────────────────────────────────────
        _q = lambda c: '"' + str(c).replace('"', '""') + '"' if c != "*" else c
        select_parts: list[str] = []
        group_cols: list[str] = []

        aggs = query_config.get("aggregations") or []
        columns = query_config.get("columns") or []
        group_by = query_config.get("group_by") or []
        order_by = query_config.get("order_by") or []
        limit = query_config.get("limit")
        offset = query_config.get("offset", 0)
        distinct = query_config.get("distinct", False)
        computed = query_config.get("computed_columns") or []
        case_exprs = query_config.get("case_expressions") or []
        window_fns = query_config.get("window_functions") or []
        col_aliases = query_config.get("column_aliases") or {}

        if aggs:
            for col in group_by:
                group_cols.append(_q(col))
                select_parts.append(_q(col))
            for agg in aggs:
                fn = agg["function"].upper()
                acol = _q(agg["column"])
                alias = agg.get("alias", f"{fn}_{agg['column']}")
                select_parts.append(f'{fn}({acol}) AS "{alias}"')
        elif columns:
            for col in columns:
                alias = col_aliases.get(col)
                if alias:
                    select_parts.append(f'{_q(col)} AS "{alias}"')
                else:
                    select_parts.append(_q(col))
        else:
            select_parts.append("*")

        for cc in computed:
            expr = cc.get("expression", "")
            alias = cc.get("alias", "computed")
            _expr_upper = expr.upper().replace(" ", "")
            _blocked = ("DROP", "TRUNCATE", "ALTER", "DELETE", "INSERT",
                        "UPDATE", "CREATE", "COPY", "ATTACH", "DETACH",
                        "EXECUTE", "CALL", "PRAGMA", "EXPORT", "IMPORT",
                        "LOAD", "INSTALL")
            _safe = True
            for _bk in _blocked:
                if _bk in _expr_upper:
                    logger.warning("Blocked dangerous computed expression: %s", expr[:100])
                    _safe = False
                    break
            if _safe and expr.strip():
                select_parts.append(f'({expr}) AS {_q(alias)}')

        for ce in case_exprs:
            alias = ce.get("alias", "case_result")
            whens = ce.get("when_clauses") or []
            parts = ["CASE"]
            for w in whens:
                parts.append(f"WHEN {w.get('condition','')} THEN {w.get('result','NULL')}")
            else_val = ce.get("else_result")
            if else_val is not None:
                parts.append(f"ELSE {else_val}")
            parts.append("END")
            select_parts.append(f'{" ".join(parts)} AS "{alias}"')

        for wf in window_fns:
            fn = wf.get("function", "ROW_NUMBER")
            wcol = wf.get("column", "")
            partition = wf.get("partition_by") or []
            worder = wf.get("order_by") or []
            alias = wf.get("alias", f"win_{fn}")
            fn_arg = f"({_q(wcol)})" if wcol else "()"
            over_parts = []
            if partition:
                over_parts.append("PARTITION BY " + ", ".join(_q(c) for c in partition))
            if worder:
                over_parts.append("ORDER BY " + ", ".join(
                    f'{_q(o["column"])} {o.get("direction","ASC").upper()}'
                    if isinstance(o, dict) else _q(o)
                    for o in worder
                ))
            select_parts.append(f'{fn}{fn_arg} OVER ({" ".join(over_parts)}) AS "{alias}"')

        distinct_kw = "DISTINCT " if distinct else ""
        sql = f"SELECT {distinct_kw}{', '.join(select_parts)}\nFROM read_parquet('{pq_path}')"

        if group_cols:
            sql += f"\nGROUP BY {', '.join(group_cols)}"

        # HAVING — sanitize operator and quote column
        _HAVING_OPS = {">", "<", ">=", "<=", "=", "!=", "<>"}
        having = query_config.get("having") or []
        if having:
            hparts = []
            for h in having:
                hcol = h.get("column", "")
                hop = h.get("operator", ">")
                hval = h.get("value", 0)
                if hop not in _HAVING_OPS:
                    hop = ">"
                try:
                    hval = float(hval)
                except (TypeError, ValueError):
                    hval = 0
                hparts.append(f"{_q(hcol)} {hop} {hval}")
            sql += f"\nHAVING {' AND '.join(hparts)}"

        if order_by:
            oparts = []
            for o in order_by:
                ocol = o["column"] if isinstance(o, dict) else o
                odir = o.get("direction", "ASC").upper() if isinstance(o, dict) else "ASC"
                oparts.append(f'{_q(ocol)} {odir}')
            sql += f"\nORDER BY {', '.join(oparts)}"

        if limit:
            sql += f"\nLIMIT {limit}"
            if offset:
                sql += f" OFFSET {offset}"

        # ── Execute and write result ─────────────────────────────────
        out_str = str(output_path).replace("\\", "/")
        copy_sql = f"COPY ({sql}) TO '{out_str}' (FORMAT PARQUET, COMPRESSION ZSTD)"
        con.execute(copy_sql)

        if not output_path.exists():
            return None
        file_size = output_path.stat().st_size
        total_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet('{out_str}')"
        ).fetchone()[0]

        logger.info("[base_data_reuse] Local query OK: %d rows, %.1f MB from %s",
                     total_rows, file_size / 1024 / 1024, base_parquet.name)
        return {"total_rows": total_rows, "file_size_bytes": file_size}
    except Exception as exc:
        logger.debug("[base_data_reuse] Local query failed (will fall through to S3): %s", exc)
        try:
            output_path.unlink(missing_ok=True)
        except OSError:
            pass
        return None
    finally:
        if con:
            try:
                con.close()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════════
# register_s3_views  (used by streaming endpoints + MV refresh)
# ═══════════════════════════════════════════════════════════════════════════

def register_s3_views(con, registered_tables, bucket, connection_id, cfg,
                      referenced_tables=None, partition_filters=None):
    """Register S3 views in a DuckDB connection for registered tables.

    When `referenced_tables` is provided (set of table names), only those tables
    are registered — avoids scanning manifests for unreferenced Iceberg tables.
    Uses the L1/L2 Iceberg manifest cache to avoid redundant S3 reads.

    partition_filters: list of {col, op, val} dicts to prune Iceberg files.

    Returns: total record count from Iceberg manifests (0 if unavailable).
    """
    import time as _rv_t
    _esc = lambda v: v.replace("'", "''")
    _total_records = 0
    for tbl in (registered_tables or []):
        tname = tbl["name"]
        if referenced_tables and tname not in referenced_tables:
            continue
        tname_esc = tname.replace('"', '""')
        fmt = tbl.get("format", "parquet")
        prefix = tbl["s3_prefix"].rstrip("/")
        _rv0 = _rv_t.monotonic()
        if fmt == "iceberg":
            try:
                cache_key = _ice_cache_key(connection_id, tname, None)
                cached = _ice_cache_get(cache_key)
                if cached:
                    data_files = cached["files"]
                    _total_records += cached.get("record_count", 0)
                else:
                    from core.iceberg_reader import get_iceberg_data_files
                    s3_client = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                    raw_files = get_iceberg_data_files(s3_client, bucket, tbl["s3_prefix"], keys_only=True)
                    _rc = sum(f.get("record_count", 0) for f in raw_files if isinstance(f, dict))
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in raw_files
                    ]
                    _ice_cache_set(cache_key, data_files, None, record_count=_rc)
                    _total_records += _rc
                if data_files:
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in data_files
                    ]
                    total_all = len(data_files)
                    if partition_filters:
                        data_files = _filter_iceberg_files_by_partitions(data_files, partition_filters)
                    if not data_files:
                        logger.info("STREAM-DIAG: Iceberg '%s': 0/%d files after partition filter — empty view",
                                    tname, total_all)
                        _ice_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        try:
                            from core.iceberg_reader import get_iceberg_data_files as _gdf
                            _schema_files = _gdf(_ice_s3, bucket, tbl["s3_prefix"], keys_only=True, max_files=1)
                            if _schema_files:
                                _sf = f"s3://{bucket}/{_schema_files[0]['key']}"
                                _sf = _s3_urls_to_presigned(_ice_s3, [_sf], cfg)[0]
                                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_sf)}\', hive_partitioning=true) WHERE FALSE')
                        except Exception:
                            pass
                    else:
                        _MAX_STREAM_FILES = _limits_cfg.max_stream_files if _limits_cfg else 500
                        if len(data_files) > _MAX_STREAM_FILES:
                            logger.info("STREAM-DIAG: '%s' still has %d files after filter, capping to %d",
                                        tname, len(data_files), _MAX_STREAM_FILES)
                            data_files = data_files[-_MAX_STREAM_FILES:]
                        _ice_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        data_files = _s3_urls_to_presigned(_ice_s3, data_files, cfg)
                        paths = ", ".join(f"'{_esc(f)}'" for f in data_files)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet([{paths}], hive_partitioning=true)')
                        logger.info("STREAM-DIAG: Iceberg view '%s': %d/%d files after partition filter (%.2fs)",
                                    tname, len(data_files), total_all, _rv_t.monotonic() - _rv0)
            except Exception as e:
                logger.warning("Stream: could not register Iceberg view '%s': %s", tname, e)
        elif fmt == "parquet":
            try:
                _pq_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                _pq_files = _list_s3_parquet_files(_pq_s3, bucket, prefix)
                if _pq_files:
                    total_pq = len(_pq_files)
                    if partition_filters:
                        _pq_files = _filter_iceberg_files_by_partitions(_pq_files, partition_filters)
                    if not _pq_files:
                        _schema_pq = _list_s3_parquet_files(_pq_s3, bucket, prefix, max_files=1)
                        if _schema_pq:
                            _schema_urls = _s3_urls_to_presigned(_pq_s3, _schema_pq[:1], cfg)
                            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_schema_urls[0])}\', hive_partitioning=true) WHERE FALSE')
                        logger.info("STREAM-DIAG: Parquet view '%s': 0/%d files after partition filter — empty view", tname, total_pq)
                    else:
                        _MAX_PQ_FILES = _limits_cfg.max_stream_files if _limits_cfg else 500
                        if len(_pq_files) > _MAX_PQ_FILES:
                            logger.info("STREAM-DIAG: '%s' has %d parquet files after filter, capping to %d",
                                        tname, len(_pq_files), _MAX_PQ_FILES)
                            _pq_files = _pq_files[-_MAX_PQ_FILES:]
                        _pq_files = _s3_urls_to_presigned(_pq_s3, _pq_files, cfg)
                        _pq_paths = ", ".join(f"'{_esc(f)}'" for f in _pq_files)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet([{_pq_paths}], hive_partitioning=true, union_by_name=true)')
                        logger.info("STREAM-DIAG: Parquet view '%s': %d/%d files after partition filter (%.2fs)",
                                    tname, len(_pq_files), total_pq, _rv_t.monotonic() - _rv0)
                else:
                    logger.warning("Stream: no parquet files found for '%s' under %s/%s", tname, bucket, prefix)
            except Exception as _pq_err:
                logger.warning("Stream: boto3 listing failed for '%s', falling back to glob: %s", tname, _pq_err)
                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.parquet\', hive_partitioning=true)')
        elif fmt == "csv":
            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.csv\')')

    # Register materialized views as local parquet VIEWs
    _mv_storage = getattr(_mv_cfg, 'storage_dir', None) if _mv_cfg else None
    if _mv_storage and _db_manager:
        try:
            mv_list = _db_manager.list_materialized_views(connection_id=connection_id)
            for mv in mv_list:
                if mv["status"] != "ready" or not mv.get("is_active", True):
                    continue
                mv_name = mv["name"]
                if referenced_tables and mv_name not in referenced_tables:
                    continue
                mv_dir = os.path.join(_mv_storage, str(mv["id"]))
                import glob as _glob_mod
                pq_files = _glob_mod.glob(os.path.join(mv_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    vname = "__mv__" + mv_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    logger.info("Registered materialized view '%s' with %d local files", mv_name, len(pq_files))
        except Exception as e:
            logger.warning("Could not register materialized views: %s", e)

    # Register local tables as local parquet VIEWs
    _lt_storage = getattr(_lt_cfg, 'storage_dir', None) if _lt_cfg else None
    if _lt_storage and _db_manager:
        try:
            import glob as _glob_mod2
            lt_list = _db_manager.list_local_tables()
            for lt in lt_list:
                if lt["status"] != "ready" or not lt.get("is_active", True):
                    continue
                lt_name = lt["name"]
                if referenced_tables and lt_name not in referenced_tables and f"__lt__{lt_name}" not in referenced_tables:
                    continue
                lt_dir = os.path.join(_lt_storage, str(lt["id"]))
                pq_files = _glob_mod2.glob(os.path.join(lt_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    vname = "__lt__" + lt_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    logger.info("Registered local table '%s' with %d local files", lt_name, len(pq_files))
                    try:
                        _db_manager.touch_local_table(lt["id"])
                    except Exception:
                        pass
        except Exception as e:
            logger.warning("Could not register local tables: %s", e)

    return _total_records
