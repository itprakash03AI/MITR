"""
Error detection utilities — S3 auth errors, connection errors, JSON-safe value conversion.

Extracted from main.py to keep the main module focused on app wiring.
"""
from __future__ import annotations

import decimal
import logging
from datetime import date as _date_type, datetime

from fastapi import HTTPException

logger = logging.getLogger(__name__)


# ── JSON-safe value conversion ───────────────────────────────────────────────

def jsonify_value(v):
    """Convert a single value to a JSON-safe type."""
    if v is None:
        return None
    if isinstance(v, (datetime, _date_type)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (list, tuple)):
        return [jsonify_value(x) for x in v]
    return v


def jsonify_rows(rows: list):
    """In-place convert non-JSON-safe values in a list of dicts."""
    for row in rows:
        for k, v in row.items():
            row[k] = jsonify_value(v)


# ── S3 auth error detection ─────────────────────────────────────────────────

S3_EXPIRED_PATTERNS = (
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired',
)


def is_s3_auth_error(exc: Exception) -> bool:
    """Detect expired / invalid AWS credentials from DuckDB httpfs or boto3 errors."""
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in S3_EXPIRED_PATTERNS)


def raise_if_s3_auth_error(exc: Exception):
    """Raise HTTP 401 with TOKEN_EXPIRED code if the exception is an AWS credential issue."""
    if is_s3_auth_error(exc):
        raise HTTPException(
            status_code=401,
            detail={
                "message": "Your AWS session credentials have expired. Please update your connection with fresh credentials.",
                "error_code": "TOKEN_EXPIRED",
            },
        )


# ── Broad connection error detection (stale-result fallback) ────────────────

CONN_ERROR_PATTERNS = (
    # AWS / S3 auth
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired', 'invalidclienttokenid',
    'accessdenied', 'access denied', 'nosuchbucket', 'invalidaccesskeyid',
    # General network
    'connection refused', 'connection timed out', 'connection reset',
    'network unreachable', 'name resolution failed', 'could not connect',
    'failed to connect', 'socket timeout', 'ssl: certificate_verify_failed',
    'no route to host', 'broken pipe',
    # HTTP auth (specific status codes only — avoid matching 404 not-found)
    'http 401', 'http 403', 'status code: 401', 'status code: 403',
    '401 unauthorized', '403 forbidden',
    # Snowflake / Databricks / Trino
    'authentication failed', 'jwt token is invalid or expired',
    'token is expired', 'login failed', 'incorrect username or password',
    # DuckDB httpfs
    'failed to download', 'could not open remote file',
    'curl error', 'could not resolve host',
)


def is_connection_error(exc: Exception) -> bool:
    """True if the exception indicates a network or auth failure (not a query/data error).
    Used to decide whether a stale cached result can be served as a fallback.
    """
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in CONN_ERROR_PATTERNS)


# ── DuckDB query error classification ─────────────────────────────────────

def classify_duckdb_error(exc: Exception) -> str:
    """Return a user-friendly error message for common DuckDB query errors.

    Translates raw DuckDB exceptions into actionable guidance.
    Returns the original error string if no classification matches.
    """
    msg = str(exc)
    msg_lower = msg.lower()

    # Binder Error: column not found — most common on on-prem S3
    if 'binder error' in msg_lower and 'not found' in msg_lower:
        # Extract the column name from the error for context
        import re
        col_match = re.search(r'column\s+"?([^"]+)"?\s+not found', msg, re.IGNORECASE)
        col_name = col_match.group(1) if col_match else '(unknown)'
        return (
            f"Column '{col_name}' not found in the query result. "
            f"This can happen when: (1) the column was removed or renamed in the data source, "
            f"(2) a hive partition column (like year, month) is not detected from pre-signed URLs "
            f"on on-prem S3 — check backend logs for URL encoding details, "
            f"(3) the EXCLUDE clause references a stale column. "
            f"Try re-selecting the table or removing the missing column from your query."
        )

    # Catalog Error: table not found (view registration failed silently)
    if 'catalog error' in msg_lower and ('not found' in msg_lower or 'does not exist' in msg_lower):
        return (
            f"Table or view not found. The S3 view registration may have failed silently — "
            f"check backend logs for 'Could not register' warnings. "
            f"Original error: {msg}"
        )

    # IO Error: file access issues
    if 'io error' in msg_lower or 'httpfs' in msg_lower:
        return (
            f"Failed to read data from S3. This may be a network, SSL, or credential issue. "
            f"For on-prem S3: verify endpoint URL, SSL settings, and path_style configuration. "
            f"Original error: {msg}"
        )

    # Signature mismatch (common on on-prem S3)
    if 'signaturedoesnotmatch' in msg_lower or 'signature' in msg_lower and 'match' in msg_lower:
        return (
            f"S3 signature mismatch. For on-prem S3 (MinIO/NetApp/Ceph), ensure 'path_style' is "
            f"enabled in the connection config. Check that the endpoint URL uses the correct protocol "
            f"(https:// or http://). Original error: {msg}"
        )

    # Default: return original with DuckDB prefix stripped
    cleaned = msg
    for prefix in ('RuntimeError: DuckDB query error: ', 'DuckDB query error: '):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
    return cleaned
