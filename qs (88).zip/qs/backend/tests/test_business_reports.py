"""
Phase 56 — Business Report Builder tests.

Tests: report CRUD, parameter CRUD, execution flow, cascading LOV,
duplicate, publish, ownership checks, config endpoints.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

import pytest

# Ensure backend/ on sys.path
_backend_dir = Path(__file__).resolve().parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from core.database import DatabaseManager, BusinessReport, ReportParameter


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def db(tmp_path_factory):
    """Module-scoped temp SQLite DB for report tests."""
    tmp_db = tmp_path_factory.mktemp("reports") / "test_reports.db"
    return DatabaseManager(f"sqlite:///{tmp_db}")


@pytest.fixture(scope="module")
def sample_dataset(db):
    """Create a sample published dataset for report tests."""
    ds = db.create_dataset(
        name="Sales Dataset", description="Test dataset", subject="Sales",
        owner="admin", source_tables=[{"connection_id": 1, "table": "sales.csv", "alias": "s"}]
    )
    # Add columns
    dim1 = db.create_dataset_column(
        dataset_id=ds["id"], physical_name="country", friendly_name="Country",
        column_type="dimension", data_type="string"
    )
    dim2 = db.create_dataset_column(
        dataset_id=ds["id"], physical_name="region", friendly_name="Region",
        column_type="dimension", data_type="string"
    )
    meas1 = db.create_dataset_column(
        dataset_id=ds["id"], physical_name="revenue", friendly_name="Revenue",
        column_type="measure", data_type="number", aggregation="sum"
    )
    meas2 = db.create_dataset_column(
        dataset_id=ds["id"], physical_name="quantity", friendly_name="Quantity",
        column_type="measure", data_type="number", aggregation="sum"
    )
    # Publish
    db.update_dataset(ds["id"], is_published=True)
    return {
        "dataset": db.get_dataset(ds["id"]),
        "dim1": dim1, "dim2": dim2,
        "meas1": meas1, "meas2": meas2,
    }


# ── Report CRUD ──────────────────────────────────────────────────────────────

class TestReportCRUD:

    def test_create_report(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        report = db.create_business_report(
            name="Monthly Sales",
            owner="alice",
            dataset_id=ds["id"],
            column_ids=[sample_dataset["dim1"]["id"], sample_dataset["meas1"]["id"]],
            filter_specs=[{"column_id": sample_dataset["dim1"]["id"], "operator": "eq", "value": "US"}],
            row_limit=10000,
        )
        assert report["id"] is not None
        assert report["name"] == "Monthly Sales"
        assert report["owner"] == "alice"
        assert len(report["column_ids"]) == 2
        assert report["is_published"] is False

    def test_list_reports_by_owner(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        assert len(reports) >= 1
        assert all(r["owner"] == "alice" for r in reports)

    def test_list_reports_by_dataset(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        reports = db.list_business_reports(dataset_id=ds["id"])
        assert len(reports) >= 1

    def test_get_report(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        r = db.get_business_report(reports[0]["id"])
        assert r is not None
        assert r["name"] == "Monthly Sales"

    def test_update_report(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        updated = db.update_business_report(reports[0]["id"], description="Updated desc", row_limit=5000)
        assert updated["description"] == "Updated desc"
        assert updated["row_limit"] == 5000

    def test_update_section_definitions(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        sections = [{"name": "By Country", "break_column_id": sample_dataset["dim1"]["id"],
                      "subtotal_measure_ids": [sample_dataset["meas1"]["id"]], "show_count": True}]
        updated = db.update_business_report(reports[0]["id"], section_definitions=sections)
        assert len(updated["section_definitions"]) == 1
        assert updated["section_definitions"][0]["name"] == "By Country"

    def test_update_running_calculations(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        calcs = [{"name": "Running Revenue", "calc_type": "running_sum",
                   "measure_col_id": sample_dataset["meas1"]["id"], "partition_col_id": None, "format_pattern": ""}]
        updated = db.update_business_report(reports[0]["id"], running_calculations=calcs)
        assert len(updated["running_calculations"]) == 1

    def test_increment_execution(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        rid = reports[0]["id"]
        before = db.get_business_report(rid)
        db.increment_business_report_execution(rid)
        after = db.get_business_report(rid)
        assert after["execution_count"] == (before["execution_count"] or 0) + 1
        assert after["last_executed_at"] is not None

    def test_delete_report(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        r = db.create_business_report(name="ToDelete", owner="bob", dataset_id=ds["id"])
        assert db.delete_business_report(r["id"]) is True
        assert db.get_business_report(r["id"]) is None

    def test_delete_nonexistent(self, db):
        assert db.delete_business_report(99999) is False


# ── Parameter CRUD ───────────────────────────────────────────────────────────

class TestParameterCRUD:

    def test_create_parameter(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        rid = reports[0]["id"]
        p = db.create_report_parameter(
            report_id=rid, name="country_filter", label="Select Country",
            parameter_type="dropdown", lov_column_id=sample_dataset["dim1"]["id"],
            is_required=True, sort_order=0,
        )
        assert p["id"] is not None
        assert p["name"] == "country_filter"
        assert p["parameter_type"] == "dropdown"

    def test_create_cascading_parameter(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        rid = reports[0]["id"]
        params = db.list_report_parameters(rid)
        parent = params[0]

        child = db.create_report_parameter(
            report_id=rid, name="region_filter", label="Select Region",
            parameter_type="dropdown", lov_column_id=sample_dataset["dim2"]["id"],
            depends_on_param_id=parent["id"],
            cascade_filter_column_id=sample_dataset["dim1"]["id"],
            sort_order=1,
        )
        assert child["depends_on_param_id"] == parent["id"]
        assert child["cascade_filter_column_id"] == sample_dataset["dim1"]["id"]

    def test_list_parameters(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        params = db.list_report_parameters(reports[0]["id"])
        assert len(params) >= 2
        # Check ordering
        assert params[0]["sort_order"] <= params[1]["sort_order"]

    def test_update_parameter(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        params = db.list_report_parameters(reports[0]["id"])
        updated = db.update_report_parameter(params[0]["id"], label="Updated Label")
        assert updated["label"] == "Updated Label"

    def test_delete_parameter(self, db, sample_dataset):
        reports = db.list_business_reports(owner="alice")
        rid = reports[0]["id"]
        p = db.create_report_parameter(
            report_id=rid, name="temp_param", label="Temp",
            parameter_type="text", sort_order=99,
        )
        assert db.delete_report_parameter(p["id"]) is True
        assert db.delete_report_parameter(p["id"]) is False  # already deleted

    def test_delete_report_cascades_params(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        r = db.create_business_report(name="WithParams", owner="charlie", dataset_id=ds["id"])
        db.create_report_parameter(report_id=r["id"], name="p1", label="P1")
        db.create_report_parameter(report_id=r["id"], name="p2", label="P2")
        assert len(db.list_report_parameters(r["id"])) == 2
        db.delete_business_report(r["id"])
        assert len(db.list_report_parameters(r["id"])) == 0


# ── Published / List Visibility ──────────────────────────────────────────────

class TestPublishVisibility:

    def test_list_published(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        db.create_business_report(name="PubReport", owner="admin", dataset_id=ds["id"],
                                   is_published=True)
        published = db.list_business_reports(is_published=True)
        names = [r["name"] for r in published]
        assert "PubReport" in names

    def test_unpublished_not_in_published_list(self, db, sample_dataset):
        published = db.list_business_reports(is_published=True)
        for r in published:
            assert r["is_published"] is True


# ── Unique Constraint ────────────────────────────────────────────────────────

class TestUniqueConstraint:

    def test_duplicate_name_same_owner_fails(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        db.create_business_report(name="UniqueTest", owner="uniq_user", dataset_id=ds["id"])
        with pytest.raises(Exception):
            db.create_business_report(name="UniqueTest", owner="uniq_user", dataset_id=ds["id"])

    def test_same_name_different_owner_ok(self, db, sample_dataset):
        ds = sample_dataset["dataset"]
        r1 = db.create_business_report(name="SharedName", owner="user_a", dataset_id=ds["id"])
        r2 = db.create_business_report(name="SharedName", owner="user_b", dataset_id=ds["id"])
        assert r1["id"] != r2["id"]


# ── Report Engine (useReportEngine logic — Python-side equivalents) ──────────

class TestReportEngineLogic:
    """Verify the client-side computation logic conceptually."""

    def test_running_sum(self):
        """RunningSum: cumulative sum of a measure column."""
        rows = [{"revenue": 100}, {"revenue": 200}, {"revenue": 150}]
        cum = 0
        results = []
        for r in rows:
            cum += r["revenue"]
            results.append(cum)
        assert results == [100, 300, 450]

    def test_rank(self):
        """Rank: dense rank by measure descending."""
        values = [100, 300, 200, 300, 150]
        sorted_unique = sorted(set(values), reverse=True)
        rank_map = {v: i + 1 for i, v in enumerate(sorted_unique)}
        ranks = [rank_map[v] for v in values]
        assert ranks == [4, 1, 2, 1, 3]

    def test_percent_of_total(self):
        """PercentOfTotal: each value / grand total * 100."""
        values = [100, 200, 300]
        total = sum(values)
        percents = [round(v / total * 100, 2) for v in values]
        assert percents == [16.67, 33.33, 50.0]

    def test_previous_value(self):
        """PreviousValue: value from prior row."""
        values = [10, 20, 30]
        prev = [None] + values[:-1]
        assert prev == [None, 10, 20]

    def test_section_break_grouping(self):
        """Section break groups rows and computes subtotals."""
        rows = [
            {"country": "US", "revenue": 100},
            {"country": "US", "revenue": 200},
            {"country": "UK", "revenue": 150},
            {"country": "UK", "revenue": 50},
        ]
        # Group by country
        groups: dict = {}
        for r in rows:
            groups.setdefault(r["country"], []).append(r)

        subtotals = {k: sum(r["revenue"] for r in v) for k, v in groups.items()}
        assert subtotals == {"US": 300, "UK": 200}
        assert sum(subtotals.values()) == 500  # grand total
