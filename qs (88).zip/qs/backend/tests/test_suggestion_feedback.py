"""Tests for unified smart suggestion feedback system.

Covers:
- Chart/pivot preset feedback (save + retrieve)
- NL-to-SQL feedback loop (search + auto-return)
- Expanded correction_type validation
"""
import pytest
from unittest.mock import patch


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def db(tmp_path):
    """Create an in-memory DatabaseManager for testing."""
    import os
    os.environ["QUERYSTUDIO_CONFIG"] = str(tmp_path / "config.json")
    from core.database import DatabaseManager
    mgr = DatabaseManager(f"sqlite:///{tmp_path / 'test.db'}")
    return mgr


# ── Chart & Pivot Feedback via SuggestionCorrection ─────────────────────────

class TestChartFeedback:

    def test_save_chart_feedback(self, db):
        result = db.save_suggestion_correction(
            correction_type="chart",
            context_key="conn:1|bar|amount,region",
            corrected_value="1",
            original_value="Revenue by Region",
            context_extra='{"chartType":"bar","xCol":"region","yCol":"amount"}',
        )
        assert result["correction_type"] == "chart"
        assert result["corrected_value"] == "1"

    def test_get_chart_feedback_all(self, db):
        db.save_suggestion_correction(correction_type="chart", context_key="conn:1|bar|a,b", corrected_value="1")
        db.save_suggestion_correction(correction_type="chart", context_key="conn:2|pie|c,d", corrected_value="-1")
        feedback = db.get_chart_feedback()
        assert len(feedback) == 2

    def test_get_chart_feedback_by_connection(self, db):
        db.save_suggestion_correction(correction_type="chart", context_key="conn:1|bar|a,b", corrected_value="1")
        db.save_suggestion_correction(correction_type="chart", context_key="conn:2|pie|c,d", corrected_value="-1")
        feedback = db.get_chart_feedback(connection_id=1)
        assert len(feedback) == 1
        assert "conn:1" in feedback[0]["context_key"]

    def test_chart_feedback_upsert(self, db):
        db.save_suggestion_correction(correction_type="chart", context_key="conn:1|bar|a,b", corrected_value="1")
        db.save_suggestion_correction(correction_type="chart", context_key="conn:1|bar|a,b", corrected_value="-1")
        feedback = db.get_chart_feedback(connection_id=1)
        assert len(feedback) == 1
        assert feedback[0]["corrected_value"] == "-1"


class TestPivotFeedback:

    def test_save_pivot_feedback(self, db):
        result = db.save_suggestion_correction(
            correction_type="pivot",
            context_key="conn:1|pivot|region|date|sum:amount",
            corrected_value="-1",
            original_value="Amount by Region",
        )
        assert result["correction_type"] == "pivot"

    def test_get_pivot_feedback_by_connection(self, db):
        db.save_suggestion_correction(correction_type="pivot", context_key="conn:5|pivot|a|b|sum:c", corrected_value="1")
        db.save_suggestion_correction(correction_type="pivot", context_key="conn:9|pivot|d|e|avg:f", corrected_value="-1")
        feedback = db.get_pivot_feedback(connection_id=5)
        assert len(feedback) == 1


# ── NL-to-SQL Feedback Search ───────────────────────────────────────────────

class TestNLFeedbackSearch:

    def test_search_exact_match(self, db):
        db.save_nl_feedback(question="show total revenue by region", sql="SELECT region, SUM(revenue) FROM sales GROUP BY region", rating=1)
        results = db.search_nl_feedback("show total revenue by region", min_similarity=0.8)
        assert len(results) >= 1
        assert results[0]["_similarity"] == 1.0
        assert results[0]["rating"] == 1

    def test_search_similar_match(self, db):
        db.save_nl_feedback(question="show total revenue by region", sql="SELECT region, SUM(revenue) FROM sales GROUP BY region", rating=1)
        results = db.search_nl_feedback("total revenue by region", min_similarity=0.6)
        assert len(results) >= 1
        assert results[0]["_similarity"] >= 0.6

    def test_search_no_match(self, db):
        db.save_nl_feedback(question="show total revenue by region", sql="SELECT ...", rating=1)
        results = db.search_nl_feedback("list all customers with email", min_similarity=0.5)
        assert len(results) == 0

    def test_search_includes_disliked(self, db):
        db.save_nl_feedback(question="show sales by month", sql="SELECT ...", rating=-1)
        results = db.search_nl_feedback("show sales by month", min_similarity=0.8)
        assert len(results) >= 1
        assert results[0]["rating"] == -1

    def test_search_empty_question(self, db):
        results = db.search_nl_feedback("", min_similarity=0.5)
        assert results == []


# ── API Endpoint Tests ──────────────────────────────────────────────────────

class TestFeedbackAPI:
    """Use the shared api_client fixture from conftest.py (auth=none, full app init)."""

    def test_save_chart_correction(self, api_client):
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "chart",
            "context_key": "conn:1|bar|x,y",
            "corrected_value": "1",
        })
        assert resp.status_code == 200
        assert resp.json()["saved"] is True

    def test_save_pivot_correction(self, api_client):
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "pivot",
            "context_key": "conn:1|pivot|a|b|sum:c",
            "corrected_value": "-1",
        })
        assert resp.status_code == 200

    def test_invalid_correction_type(self, api_client):
        resp = api_client.post("/api/suggest/correction", json={
            "correction_type": "invalid",
            "context_key": "k",
            "corrected_value": "v",
        })
        assert resp.status_code == 422

    def test_get_chart_corrections(self, api_client):
        api_client.post("/api/suggest/correction", json={
            "correction_type": "chart",
            "context_key": "conn:1|bar|x,y",
            "corrected_value": "1",
        })
        resp = api_client.get("/api/suggest/corrections/chart")
        assert resp.status_code == 200
        assert len(resp.json()["corrections"]) >= 1

    def test_get_chart_corrections_filtered(self, api_client):
        api_client.post("/api/suggest/correction", json={
            "correction_type": "chart", "context_key": "conn:1|bar|x,y", "corrected_value": "1",
        })
        api_client.post("/api/suggest/correction", json={
            "correction_type": "chart", "context_key": "conn:2|pie|a,b", "corrected_value": "-1",
        })
        resp = api_client.get("/api/suggest/corrections/chart?connection_id=1")
        assert resp.status_code == 200
        data = resp.json()["corrections"]
        assert all("conn:1" in c["context_key"] for c in data)

    def test_get_pivot_corrections(self, api_client):
        api_client.post("/api/suggest/correction", json={
            "correction_type": "pivot",
            "context_key": "conn:3|pivot|r|c|sum:v",
            "corrected_value": "1",
        })
        resp = api_client.get("/api/suggest/corrections/pivot")
        assert resp.status_code == 200
        assert len(resp.json()["corrections"]) >= 1


# ── Config Tests ────────────────────────────────────────────────────────────

class TestFeedbackConfig:

    def test_config_defaults(self):
        from core import config
        assert config.suggestion_corrections.chart_feedback_enabled is True
        assert config.suggestion_corrections.pivot_feedback_enabled is True
        assert config.suggestion_corrections.nl_feedback_lookup_enabled is True
        assert config.suggestion_corrections.nl_feedback_min_similarity == 0.8
        assert config.suggestion_corrections.nl_feedback_auto_return_threshold == 0.9
