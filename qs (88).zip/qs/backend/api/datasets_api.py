"""
Semantic Layer — Business Datasets API (Phase 53)

Provides CRUD for business datasets, columns, classes, relationships,
drill hierarchies, pre-defined conditions, and aggregation awareness rules.

All endpoints require auth.  Admin-only endpoints for creation/update/delete.
Analysts/viewers can read published datasets (filtered by role column visibility).

Endpoint summary:
  GET    /api/datasets                      list datasets (published_only for non-admin)
  POST   /api/datasets                      create dataset (admin)
  GET    /api/datasets/{id}                 get dataset with all children
  PUT    /api/datasets/{id}                 update dataset (admin)
  DELETE /api/datasets/{id}                 delete dataset + cascade (admin)
  POST   /api/datasets/{id}/publish         toggle publish state (admin)
  POST   /api/datasets/preview-columns       preview auto-classified columns (no save) (admin)
  POST   /api/datasets/{id}/auto-detect     auto-detect columns from connection schema (admin)

  GET    /api/datasets/{id}/classes         list classes
  POST   /api/datasets/{id}/classes         create class (admin)
  PUT    /api/datasets/classes/{cid}        update class (admin)
  DELETE /api/datasets/classes/{cid}        delete class (admin)

  GET    /api/datasets/{id}/columns         list columns (filtered by role)
  POST   /api/datasets/{id}/columns         create column (admin)
  POST   /api/datasets/{id}/columns/bulk    bulk create columns (admin)
  PUT    /api/datasets/columns/{cid}        update column (admin)
  DELETE /api/datasets/columns/{cid}        delete column (admin)

  GET    /api/datasets/{id}/relationships   list relationships
  POST   /api/datasets/{id}/relationships   create relationship (admin)
  PUT    /api/datasets/relationships/{rid}  update relationship (admin)
  DELETE /api/datasets/relationships/{rid}  delete relationship (admin)

  GET    /api/datasets/{id}/hierarchies     list drill hierarchies
  POST   /api/datasets/{id}/hierarchies     create hierarchy (admin)
  PUT    /api/datasets/hierarchies/{hid}    update hierarchy (admin)
  DELETE /api/datasets/hierarchies/{hid}    delete hierarchy (admin)

  GET    /api/datasets/{id}/conditions      list pre-defined conditions
  POST   /api/datasets/{id}/conditions      create condition (admin)
  PUT    /api/datasets/conditions/{cid}     update condition (admin)
  DELETE /api/datasets/conditions/{cid}     delete condition (admin)

  GET    /api/datasets/{id}/agg-awareness   list aggregation awareness rules
  POST   /api/datasets/{id}/agg-awareness   create rule (admin)
  DELETE /api/datasets/agg-awareness/{aid}  delete rule (admin)

  GET    /api/admin/semantic-layer/config   get config
  PUT    /api/admin/semantic-layer/config   update config (admin)
"""
from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as FastQuery
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None


def set_datasets_dependencies(db_manager):
    """Called once from main.py startup."""
    global _db_manager
    _db_manager = db_manager


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Datasets API not initialised — call set_datasets_dependencies() first")
    return _db_manager


def _ensure_dataset_exists(dataset_id: int) -> Dict[str, Any]:
    ds = _require_db().get_dataset(dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_id} not found")
    return ds


def _filter_columns_by_role(columns: List[Dict[str, Any]], role: str) -> List[Dict[str, Any]]:
    """Respect column role_whitelist — if whitelist is empty, all roles see it."""
    return [
        c for c in columns
        if not c.get("role_whitelist") or role in c["role_whitelist"]
    ]


# ═══════════════════════════════════════════════════════════════════════════════
# Request / Response Models (Pydantic v2)
# ═══════════════════════════════════════════════════════════════════════════════

class DatasetCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    subject: str = Field(..., min_length=1, max_length=100)
    description: str = ""
    connection_ids: List[int] = []
    source_tables: List[Dict[str, Any]] = []
    base_query: str = ""
    is_published: bool = False


class DatasetUpdate(BaseModel):
    name: Optional[str] = None
    subject: Optional[str] = None
    description: Optional[str] = None
    connection_ids: Optional[List[int]] = None
    source_tables: Optional[List[Dict[str, Any]]] = None
    base_query: Optional[str] = None
    is_published: Optional[bool] = None


class PreviewColumnsRequest(BaseModel):
    connection_id: int
    table_path: str = Field(..., min_length=1)


class ClassCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    label: str = ""
    icon: str = ""
    sort_order: int = 0


class ClassUpdate(BaseModel):
    name: Optional[str] = None
    label: Optional[str] = None
    icon: Optional[str] = None
    sort_order: Optional[int] = None


class ColumnCreate(BaseModel):
    physical_name: str = Field(..., min_length=1, max_length=300)
    friendly_name: str = Field(..., min_length=1, max_length=300)
    column_type: str = Field("dimension", pattern=r"^(dimension|measure|detail|kpi)$")
    data_type: str = Field("string", pattern=r"^(string|number|date|boolean)$")
    aggregation: str = ""
    format_pattern: str = ""
    description: str = ""
    synonyms: List[str] = []
    role_whitelist: List[str] = []
    class_id: Optional[int] = None
    sort_order: int = 0
    is_hidden: bool = False


class ColumnUpdate(BaseModel):
    physical_name: Optional[str] = None
    friendly_name: Optional[str] = None
    column_type: Optional[str] = None
    data_type: Optional[str] = None
    aggregation: Optional[str] = None
    format_pattern: Optional[str] = None
    description: Optional[str] = None
    synonyms: Optional[List[str]] = None
    role_whitelist: Optional[List[str]] = None
    class_id: Optional[int] = None
    sort_order: Optional[int] = None
    is_hidden: Optional[bool] = None


class BulkColumnCreate(BaseModel):
    columns: List[ColumnCreate]


class RelationshipCreate(BaseModel):
    left_table: str = Field(..., min_length=1)
    right_table: str = Field(..., min_length=1)
    join_keys: List[Dict[str, str]]  # [{"left":"id","right":"order_id"}]
    join_type: str = Field("inner", pattern=r"^(inner|left|right|full)$")
    cardinality: str = Field("many_to_one", pattern=r"^(one_to_one|one_to_many|many_to_one|many_to_many)$")


class RelationshipUpdate(BaseModel):
    left_table: Optional[str] = None
    right_table: Optional[str] = None
    join_keys: Optional[List[Dict[str, str]]] = None
    join_type: Optional[str] = None
    cardinality: Optional[str] = None


class HierarchyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    levels: List[Dict[str, Any]]  # [{"column_id":1,"label":"Year"},{"column_id":2,"label":"Quarter"}]


class HierarchyUpdate(BaseModel):
    name: Optional[str] = None
    levels: Optional[List[Dict[str, Any]]] = None


class ConditionCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    where_clause: str = Field(..., min_length=1)
    label: str = ""
    description: str = ""
    sort_order: int = 0


class ConditionUpdate(BaseModel):
    name: Optional[str] = None
    where_clause: Optional[str] = None
    label: Optional[str] = None
    description: Optional[str] = None
    sort_order: Optional[int] = None


class AggAwarenessCreate(BaseModel):
    measure_col_id: int
    agg_table: str = Field(..., min_length=1)
    agg_dimensions: List[str] = []
    connection_id: Optional[int] = None
    is_enabled: bool = True


class SemanticLayerConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    auto_detect_column_types: Optional[bool] = None
    max_columns_per_dataset: Optional[int] = None
    max_datasets: Optional[int] = None
    cascading_prompts_enabled: Optional[bool] = None
    drill_hierarchies_enabled: Optional[bool] = None
    aggregation_awareness_enabled: Optional[bool] = None
    default_row_limit: Optional[int] = None
    synonym_matching_enabled: Optional[bool] = None


# ═══════════════════════════════════════════════════════════════════════════════
# Dataset CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets", tags=["semantic-layer"])
async def list_datasets(
    subject: Optional[str] = None,
    user: dict = Depends(get_current_user),
):
    """List datasets.  Non-admin users only see published datasets."""
    db = _require_db()
    is_admin = user.get("is_admin", False)
    datasets = db.list_datasets(subject=subject, published_only=not is_admin)
    return datasets


@router.post("/api/datasets", tags=["semantic-layer"])
async def create_dataset(body: DatasetCreate, user: dict = Depends(require_admin)):
    db = _require_db()
    from core import config
    if len(db.list_datasets()) >= config.semantic_layer.max_datasets:
        raise HTTPException(status_code=400, detail=f"Maximum {config.semantic_layer.max_datasets} datasets allowed")
    try:
        result = db.create_dataset(
            name=body.name, subject=body.subject, description=body.description,
            owner=user.get("username", "admin"), connection_ids=body.connection_ids,
            source_tables=body.source_tables, base_query=body.base_query,
            is_published=body.is_published,
        )
        logger.info("Dataset created: %s (id=%s) by %s", body.name, result["id"], user.get("username"))
        return result
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409, detail=f"Dataset name '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def get_dataset(dataset_id: int, user: dict = Depends(get_current_user)):
    db = _require_db()
    ds = db.get_dataset_full(dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    # Non-admin can only see published datasets
    if not user.get("is_admin") and not ds.get("is_published"):
        raise HTTPException(status_code=403, detail="Dataset not published")
    # Filter columns by role
    role = user.get("role", "viewer")
    ds["columns"] = _filter_columns_by_role(ds.get("columns", []), role)
    return ds


@router.put("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def update_dataset(dataset_id: int, body: DatasetUpdate,
                         user: dict = Depends(require_admin)):
    db = _require_db()
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = db.update_dataset(dataset_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Dataset not found")
    # Invalidate agg cache entries when dataset definition changes
    try:
        from core.agg_cache import invalidate_by_dataset
        invalidate_by_dataset(dataset_id)
    except Exception:
        pass
    logger.info("Dataset %s updated by %s: %s", dataset_id, user.get("username"), list(updates.keys()))
    return result


@router.delete("/api/datasets/{dataset_id}", tags=["semantic-layer"])
async def delete_dataset(dataset_id: int, user: dict = Depends(require_admin)):
    db = _require_db()
    # Invalidate agg cache entries before deleting
    try:
        from core.agg_cache import invalidate_by_dataset
        invalidate_by_dataset(dataset_id)
    except Exception:
        pass
    success = db.delete_dataset(dataset_id)
    if not success:
        raise HTTPException(status_code=404, detail="Dataset not found")
    logger.info("Dataset %s deleted by %s", dataset_id, user.get("username"))
    return {"detail": "Dataset deleted", "id": dataset_id}


@router.post("/api/datasets/{dataset_id}/publish", tags=["semantic-layer"])
async def toggle_publish(dataset_id: int, user: dict = Depends(require_admin)):
    db = _require_db()
    ds = _ensure_dataset_exists(dataset_id)
    new_state = not ds.get("is_published", False)
    result = db.update_dataset(dataset_id, is_published=new_state)
    logger.info("Dataset %s %s by %s", dataset_id,
                "published" if new_state else "unpublished", user.get("username"))
    return result


# ── Column auto-classification helpers (shared by preview + auto-detect) ─────

def _classify_column(col_name: str, col_type_str: str) -> tuple:
    """Classify a column by name/type patterns. Returns (column_type, data_type, is_hidden)."""
    from core import config as cfg
    numeric_pats = [p.lower() for p in cfg.chatbot.numeric_patterns]
    date_pats = [p.lower() for p in cfg.chatbot.date_patterns]
    id_pats = [p.lower() for p in cfg.chatbot.id_patterns]

    lower = col_name.lower()
    type_lower = col_type_str.lower() if col_type_str else ""
    # Date detection
    if any(p in lower for p in date_pats) or "date" in type_lower or "timestamp" in type_lower:
        return "dimension", "date", False
    # ID columns → hidden dimension
    if any(lower.endswith(p) or lower.startswith(p.lstrip("_")) for p in id_pats):
        return "dimension", "string", True
    # Numeric measures
    if any(p in lower for p in numeric_pats):
        return "measure", "number", False
    # Type-based numeric
    if any(t in type_lower for t in ("int", "float", "double", "decimal", "numeric", "bigint")):
        return "measure", "number", False
    return "dimension", "string", False


def _friendly_name(col_name: str) -> str:
    """Convert snake_case/camelCase to Title Case."""
    import re
    s = re.sub(r'([a-z])([A-Z])', r'\1_\2', col_name)
    return s.replace("_", " ").strip().title()


async def _read_connection_schema(db, conn_id: int, table_path: str) -> dict:
    """Read schema from a connection's table/file. Raises HTTPException on error."""
    from core.database import Connection
    with db.get_session() as session:
        conn = session.query(Connection).filter(Connection.id == conn_id).first()
        if not conn:
            raise HTTPException(status_code=404, detail=f"Connection {conn_id} not found")
    try:
        import asyncio
        from core.connection_manager import ConnectionManager
        cm = ConnectionManager(db)
        loop = asyncio.get_running_loop()
        schema_info = await loop.run_in_executor(None, cm.get_schema, conn_id, table_path)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read schema: {e}")
    if not schema_info or "columns" not in schema_info:
        raise HTTPException(status_code=500, detail="No columns found in schema")
    return schema_info


def _classify_schema_columns(schema_info: dict) -> List[Dict[str, Any]]:
    """Classify all columns in a schema dict. Returns list of column dicts."""
    columns = []
    for idx, col in enumerate(schema_info["columns"]):
        col_name = col.get("name", col.get("column_name", ""))
        col_type_str = col.get("type", col.get("data_type", ""))
        if not col_name:
            continue
        c_type, d_type, is_hidden = _classify_column(col_name, col_type_str)
        columns.append({
            "physical_name": col_name,
            "friendly_name": _friendly_name(col_name),
            "column_type": c_type,
            "data_type": d_type,
            "aggregation": "sum" if c_type == "measure" else "",
            "is_hidden": is_hidden,
            "sort_order": idx,
        })
    return columns


@router.post("/api/datasets/preview-columns", tags=["semantic-layer"])
async def preview_columns(body: PreviewColumnsRequest, user: dict = Depends(require_admin)):
    """Preview auto-classified columns from a connection's table schema WITHOUT saving.
    Use this to show users what columns will be created before committing."""
    db = _require_db()
    schema_info = await _read_connection_schema(db, body.connection_id, body.table_path)
    columns = _classify_schema_columns(schema_info)
    dims = sum(1 for c in columns if c["column_type"] == "dimension" and c["data_type"] != "date")
    measures = sum(1 for c in columns if c["column_type"] == "measure")
    dates = sum(1 for c in columns if c["data_type"] == "date")
    hidden = sum(1 for c in columns if c["is_hidden"])
    logger.info("Preview-columns: %d cols (%d dim, %d measure, %d date, %d hidden) from conn %d / %s by %s",
                len(columns), dims, measures, dates, hidden,
                body.connection_id, body.table_path, user.get("username"))
    return {
        "columns": columns,
        "summary": {"total": len(columns), "dimensions": dims, "measures": measures, "dates": dates, "hidden": hidden},
    }


@router.post("/api/datasets/{dataset_id}/auto-detect", tags=["semantic-layer"])
async def auto_detect_columns(dataset_id: int, user: dict = Depends(require_admin)):
    """Auto-detect columns from the dataset's source tables by reading connection schema.
    Uses chatbot classification patterns to auto-classify as dimension/measure/date."""
    db = _require_db()
    ds = _ensure_dataset_exists(dataset_id)
    from core import config as cfg

    source_tables = ds.get("source_tables", [])
    if not source_tables:
        raise HTTPException(status_code=400, detail="Dataset has no source_tables defined")

    first_source = source_tables[0]
    conn_id = first_source.get("connection_id")
    table_path = first_source.get("table", "")
    if not conn_id or not table_path:
        raise HTTPException(status_code=400, detail="First source table missing connection_id or table path")

    schema_info = await _read_connection_schema(db, conn_id, table_path)
    columns_to_create = _classify_schema_columns(schema_info)

    # Check limit
    existing_count = len(db.list_dataset_columns(dataset_id))
    if existing_count + len(columns_to_create) > cfg.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=f"Would exceed column limit ({cfg.semantic_layer.max_columns_per_dataset})")

    results = db.bulk_create_dataset_columns(dataset_id, columns_to_create)
    logger.info("Auto-detected %d columns for dataset %s by %s",
                len(results), dataset_id, user.get("username"))
    return {"created": len(results), "columns": results}


# ═══════════════════════════════════════════════════════════════════════════════
# Classes CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/classes", tags=["semantic-layer"])
async def list_classes(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_dataset_classes(dataset_id)


@router.post("/api/datasets/{dataset_id}/classes", tags=["semantic-layer"])
async def create_class(dataset_id: int, body: ClassCreate,
                       user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    try:
        return _require_db().create_dataset_class(
            dataset_id, name=body.name, label=body.label,
            icon=body.icon, sort_order=body.sort_order,
        )
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409, detail=f"Class '{body.name}' already exists in dataset")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/classes/{class_id}", tags=["semantic-layer"])
async def update_class(class_id: int, body: ClassUpdate,
                       user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_dataset_class(class_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Class not found")
    return result


@router.delete("/api/datasets/classes/{class_id}", tags=["semantic-layer"])
async def delete_class(class_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_dataset_class(class_id):
        raise HTTPException(status_code=404, detail="Class not found")
    return {"detail": "Class deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Columns CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/columns", tags=["semantic-layer"])
async def list_columns(dataset_id: int,
                       column_type: Optional[str] = None,
                       include_hidden: bool = False,
                       user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    cols = _require_db().list_dataset_columns(
        dataset_id, column_type=column_type, include_hidden=include_hidden or user.get("is_admin", False),
    )
    role = user.get("role", "viewer")
    return _filter_columns_by_role(cols, role)


@router.post("/api/datasets/{dataset_id}/columns", tags=["semantic-layer"])
async def create_column(dataset_id: int, body: ColumnCreate,
                        user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    from core import config
    existing = len(_require_db().list_dataset_columns(dataset_id))
    if existing >= config.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=f"Column limit reached ({config.semantic_layer.max_columns_per_dataset})")
    try:
        return _require_db().create_dataset_column(dataset_id, **body.model_dump())
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409,
                                detail=f"Column '{body.physical_name}' already exists in dataset")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/datasets/{dataset_id}/columns/bulk", tags=["semantic-layer"])
async def bulk_create_columns(dataset_id: int, body: BulkColumnCreate,
                              user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    from core import config
    existing = len(_require_db().list_dataset_columns(dataset_id))
    if existing + len(body.columns) > config.semantic_layer.max_columns_per_dataset:
        raise HTTPException(status_code=400,
                            detail=f"Would exceed column limit ({config.semantic_layer.max_columns_per_dataset})")
    cols = [c.model_dump() for c in body.columns]
    results = _require_db().bulk_create_dataset_columns(dataset_id, cols)
    return {"created": len(results), "columns": results}


@router.put("/api/datasets/columns/{column_id}", tags=["semantic-layer"])
async def update_column(column_id: int, body: ColumnUpdate,
                        user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_dataset_column(column_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Column not found")
    return result


@router.delete("/api/datasets/columns/{column_id}", tags=["semantic-layer"])
async def delete_column(column_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_dataset_column(column_id):
        raise HTTPException(status_code=404, detail="Column not found")
    return {"detail": "Column deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Relationships CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/relationships", tags=["semantic-layer"])
async def list_relationships(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_dataset_relationships(dataset_id)


@router.post("/api/datasets/{dataset_id}/relationships", tags=["semantic-layer"])
async def create_relationship(dataset_id: int, body: RelationshipCreate,
                              user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().create_dataset_relationship(
        dataset_id, left_table=body.left_table, right_table=body.right_table,
        join_keys=[jk for jk in body.join_keys], join_type=body.join_type,
        cardinality=body.cardinality,
    )


@router.put("/api/datasets/relationships/{rel_id}", tags=["semantic-layer"])
async def update_relationship(rel_id: int, body: RelationshipUpdate,
                              user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_dataset_relationship(rel_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Relationship not found")
    return result


@router.delete("/api/datasets/relationships/{rel_id}", tags=["semantic-layer"])
async def delete_relationship(rel_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_dataset_relationship(rel_id):
        raise HTTPException(status_code=404, detail="Relationship not found")
    return {"detail": "Relationship deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Drill Hierarchies CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/hierarchies", tags=["semantic-layer"])
async def list_hierarchies(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_drill_hierarchies(dataset_id)


@router.post("/api/datasets/{dataset_id}/hierarchies", tags=["semantic-layer"])
async def create_hierarchy(dataset_id: int, body: HierarchyCreate,
                           user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    try:
        return _require_db().create_drill_hierarchy(
            dataset_id, name=body.name, levels=body.levels,
        )
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409, detail=f"Hierarchy '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/hierarchies/{hierarchy_id}", tags=["semantic-layer"])
async def update_hierarchy(hierarchy_id: int, body: HierarchyUpdate,
                           user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_drill_hierarchy(hierarchy_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Hierarchy not found")
    return result


@router.delete("/api/datasets/hierarchies/{hierarchy_id}", tags=["semantic-layer"])
async def delete_hierarchy(hierarchy_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_drill_hierarchy(hierarchy_id):
        raise HTTPException(status_code=404, detail="Hierarchy not found")
    return {"detail": "Hierarchy deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Pre-Defined Conditions CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/conditions", tags=["semantic-layer"])
async def list_conditions(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_predefined_conditions(dataset_id)


@router.post("/api/datasets/{dataset_id}/conditions", tags=["semantic-layer"])
async def create_condition(dataset_id: int, body: ConditionCreate,
                           user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    try:
        return _require_db().create_predefined_condition(
            dataset_id, name=body.name, where_clause=body.where_clause,
            label=body.label, description=body.description, sort_order=body.sort_order,
        )
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409, detail=f"Condition '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/conditions/{condition_id}", tags=["semantic-layer"])
async def update_condition(condition_id: int, body: ConditionUpdate,
                           user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_predefined_condition(condition_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Condition not found")
    return result


@router.delete("/api/datasets/conditions/{condition_id}", tags=["semantic-layer"])
async def delete_condition(condition_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_predefined_condition(condition_id):
        raise HTTPException(status_code=404, detail="Condition not found")
    return {"detail": "Condition deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Aggregation Awareness CRUD
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/datasets/{dataset_id}/agg-awareness", tags=["semantic-layer"])
async def list_agg_awareness(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_aggregation_awareness(dataset_id)


@router.post("/api/datasets/{dataset_id}/agg-awareness", tags=["semantic-layer"])
async def create_agg_awareness(dataset_id: int, body: AggAwarenessCreate,
                               user: dict = Depends(require_admin)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().create_aggregation_awareness(
        dataset_id, measure_col_id=body.measure_col_id, agg_table=body.agg_table,
        agg_dimensions=body.agg_dimensions, connection_id=body.connection_id,
        is_enabled=body.is_enabled,
    )


@router.delete("/api/datasets/agg-awareness/{agg_id}", tags=["semantic-layer"])
async def delete_agg_awareness(agg_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_aggregation_awareness(agg_id):
        raise HTTPException(status_code=404, detail="Aggregation awareness rule not found")
    return {"detail": "Aggregation awareness rule deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Admin Config
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/api/admin/semantic-layer/config", tags=["semantic-layer"])
async def get_semantic_layer_config(user: dict = Depends(require_admin)):
    from core import config
    return {
        "enabled":                       config.semantic_layer.enabled,
        "auto_detect_column_types":      config.semantic_layer.auto_detect_column_types,
        "max_columns_per_dataset":       config.semantic_layer.max_columns_per_dataset,
        "max_datasets":                  config.semantic_layer.max_datasets,
        "cascading_prompts_enabled":     config.semantic_layer.cascading_prompts_enabled,
        "drill_hierarchies_enabled":     config.semantic_layer.drill_hierarchies_enabled,
        "aggregation_awareness_enabled": config.semantic_layer.aggregation_awareness_enabled,
        "default_row_limit":             config.semantic_layer.default_row_limit,
        "synonym_matching_enabled":      config.semantic_layer.synonym_matching_enabled,
    }


@router.put("/api/admin/semantic-layer/config", tags=["semantic-layer"])
async def update_semantic_layer_config(body: SemanticLayerConfigUpdate,
                                       user: dict = Depends(require_admin)):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("semantic_layer", k, v)
    logger.info("Semantic layer config updated by %s: %s", user.get("username"), list(updates.keys()))
    return await get_semantic_layer_config(user=user)


# ═══════════════════════════════════════════════════════════════════════════════
# Federation Config (admin)
# ═══════════════════════════════════════════════════════════════════════════════

class FederationConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    max_concurrent_executions: Optional[int] = None
    execution_timeout_seconds: Optional[int] = None
    max_result_rows: Optional[int] = None
    named_secrets_enabled: Optional[bool] = None
    fallback_to_pragmas: Optional[bool] = None
    execution_history_retention_days: Optional[int] = None
    merge_max_datasets: Optional[int] = None
    preview_row_limit: Optional[int] = None
    distinct_values_limit: Optional[int] = None


@router.get("/api/admin/federation/config", tags=["federation"])
async def get_federation_config(user: dict = Depends(require_admin)):
    from core import config
    return {
        "enabled":                       config.federation.enabled,
        "max_concurrent_executions":     config.federation.max_concurrent_executions,
        "execution_timeout_seconds":     config.federation.execution_timeout_seconds,
        "max_result_rows":               config.federation.max_result_rows,
        "named_secrets_enabled":         config.federation.named_secrets_enabled,
        "fallback_to_pragmas":           config.federation.fallback_to_pragmas,
        "execution_history_retention_days": config.federation.execution_history_retention_days,
        "merge_max_datasets":            config.federation.merge_max_datasets,
        "preview_row_limit":             config.federation.preview_row_limit,
        "distinct_values_limit":         config.federation.distinct_values_limit,
    }


@router.put("/api/admin/federation/config", tags=["federation"])
async def update_federation_config(body: FederationConfigUpdate,
                                    user: dict = Depends(require_admin)):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("federation", k, v)
    logger.info("Federation config updated by %s: %s", user.get("username"), list(updates.keys()))
    return await get_federation_config(user=user)


# ═══════════════════════════════════════════════════════════════════════════════
# Dataset Execution (Phase 54 — Federation Engine)
# ═══════════════════════════════════════════════════════════════════════════════

_federation_engine = None


def set_federation_dependencies(federation_engine):
    """Called from main.py startup to inject the FederationEngine instance."""
    global _federation_engine
    _federation_engine = federation_engine


def _require_federation():
    if _federation_engine is None:
        raise RuntimeError("Federation engine not initialised — call set_federation_dependencies() first")
    return _federation_engine


class DatasetExecuteRequest(BaseModel):
    """Request body for executing a dataset query."""
    column_ids: List[int] = Field(..., min_length=1)
    filters: List[Dict[str, Any]] = []
    condition_ids: List[int] = []
    order_by: List[Dict[str, Any]] = []   # [{column_id, direction}]
    limit: Optional[int] = None


class DatasetMergeRequest(BaseModel):
    """Request body for merged (multi-dataset) query execution."""
    primary_dataset_id: int
    secondary_dataset_id: int
    primary_column_ids: List[int] = Field(..., min_length=1)
    secondary_column_ids: List[int] = Field(..., min_length=1)
    merge_keys: List[Dict[str, str]] = Field(..., min_length=1)  # [{"left":"col","right":"col"}]
    merge_type: str = Field("inner", pattern=r"^(inner|left|right|full)$")
    primary_filters: List[Dict[str, Any]] = []
    secondary_filters: List[Dict[str, Any]] = []
    primary_condition_ids: List[int] = []
    secondary_condition_ids: List[int] = []
    limit: Optional[int] = None


class MergedDimensionCreate(BaseModel):
    primary_dataset_id: int
    secondary_dataset_id: int
    name: str = Field(..., min_length=1, max_length=200)
    merge_keys: List[Dict[str, str]] = Field(..., min_length=1)
    merge_type: str = Field("inner", pattern=r"^(inner|left|right|full)$")
    is_active: bool = True


class MergedDimensionUpdate(BaseModel):
    name: Optional[str] = None
    merge_keys: Optional[List[Dict[str, str]]] = None
    merge_type: Optional[str] = Field(None, pattern=r"^(inner|left|right|full)$")
    is_active: Optional[bool] = None


class ColumnValuesRequest(BaseModel):
    column_id: int
    parent_filters: List[Dict[str, Any]] = []
    limit: int = 500


@router.post("/api/datasets/{dataset_id}/execute", tags=["federation"])
async def execute_dataset(dataset_id: int, body: DatasetExecuteRequest,
                           user: dict = Depends(get_current_user)):
    """Execute a semantic layer query against a single dataset."""
    from core import config
    if not config.federation.enabled:
        raise HTTPException(status_code=403, detail="Federation execution is disabled")

    db = _require_db()
    ds = _ensure_dataset_exists(dataset_id)
    # Non-admin can only execute published datasets
    if not user.get("is_admin") and not ds.get("is_published"):
        raise HTTPException(status_code=403, detail="Dataset not published")

    engine = _require_federation()
    execution_id = str(uuid.uuid4())
    user_role = user.get("role", "viewer")
    username = user.get("username", "anonymous")

    # Create execution record
    db.create_federation_execution(
        execution_id=execution_id, dataset_id=dataset_id,
        sql_generated="", column_ids=body.column_ids,
        filters=body.filters, condition_ids=body.condition_ids,
        executed_by=username,
    )

    try:
        result = engine.execute_dataset_query(
            dataset_id=dataset_id,
            column_ids=body.column_ids,
            filters=body.filters,
            condition_ids=body.condition_ids,
            order_by=body.order_by,
            limit=body.limit,
            execution_id=execution_id,
            user_role=user_role,
        )
        # Update execution record
        db.update_federation_execution(execution_id,
            status="completed", output_path=result.output_path,
            total_rows=result.total_rows, duration_seconds=result.duration_seconds,
            sql_generated=result.sql_generated, sources_used=result.sources_used,
        )
        logger.info("Dataset %d executed by %s: %d rows (exec=%s)",
                     dataset_id, username, result.total_rows, execution_id)
        return result.to_dict()

    except Exception as exc:
        db.update_federation_execution(execution_id,
            status="failed", error_message=str(exc),
        )
        logger.error("Dataset %d execution failed: %s", dataset_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Execution failed")


@router.post("/api/datasets/federation/execute", tags=["federation"])
async def execute_merged_datasets(body: DatasetMergeRequest,
                                   user: dict = Depends(get_current_user)):
    """Execute a merged query across two datasets (BO multiple data providers)."""
    from core import config
    if not config.federation.enabled:
        raise HTTPException(status_code=403, detail="Federation execution is disabled")

    db = _require_db()
    engine = _require_federation()
    execution_id = str(uuid.uuid4())
    user_role = user.get("role", "viewer")
    username = user.get("username", "anonymous")

    # Validate both datasets exist and are accessible
    for ds_id in (body.primary_dataset_id, body.secondary_dataset_id):
        ds = _ensure_dataset_exists(ds_id)
        if not user.get("is_admin") and not ds.get("is_published"):
            raise HTTPException(status_code=403, detail=f"Dataset {ds_id} not published")

    # Create execution record
    db.create_federation_execution(
        execution_id=execution_id, dataset_id=body.primary_dataset_id,
        merged_dataset_id=body.secondary_dataset_id,
        column_ids=body.primary_column_ids + body.secondary_column_ids,
        filters=body.primary_filters + body.secondary_filters,
        condition_ids=body.primary_condition_ids + body.secondary_condition_ids,
        executed_by=username,
    )

    try:
        result = engine.execute_merged_query(
            primary_dataset_id=body.primary_dataset_id,
            secondary_dataset_id=body.secondary_dataset_id,
            primary_column_ids=body.primary_column_ids,
            secondary_column_ids=body.secondary_column_ids,
            merge_keys=body.merge_keys,
            merge_type=body.merge_type,
            primary_filters=body.primary_filters,
            secondary_filters=body.secondary_filters,
            primary_condition_ids=body.primary_condition_ids,
            secondary_condition_ids=body.secondary_condition_ids,
            limit=body.limit,
            execution_id=execution_id,
            user_role=user_role,
        )
        db.update_federation_execution(execution_id,
            status="completed", output_path=result.output_path,
            total_rows=result.total_rows, duration_seconds=result.duration_seconds,
            sql_generated=result.sql_generated, sources_used=result.sources_used,
        )
        logger.info("Merged execution %s+%s by %s: %d rows",
                     body.primary_dataset_id, body.secondary_dataset_id,
                     username, result.total_rows)
        return result.to_dict()

    except Exception as exc:
        db.update_federation_execution(execution_id,
            status="failed", error_message=str(exc),
        )
        logger.error("Merged execution failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Execution failed")


@router.get("/api/datasets/{dataset_id}/preview", tags=["federation"])
async def preview_dataset(dataset_id: int, user: dict = Depends(get_current_user)):
    """Quick preview of first N rows from a dataset."""
    from core import config
    db = _require_db()
    ds = _ensure_dataset_exists(dataset_id)
    if not user.get("is_admin") and not ds.get("is_published"):
        raise HTTPException(status_code=403, detail="Dataset not published")

    engine = _require_federation()
    try:
        return engine.preview_dataset(
            dataset_id=dataset_id,
            limit=config.federation.preview_row_limit,
            user_role=user.get("role", "viewer"),
        )
    except Exception as exc:
        logger.error("Preview failed for dataset %d: %s", dataset_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Preview failed: {exc}")


@router.post("/api/datasets/{dataset_id}/column-values", tags=["federation"])
async def get_column_values(dataset_id: int, body: ColumnValuesRequest,
                             user: dict = Depends(get_current_user)):
    """Get distinct values for a column (cascading prompts / LOV)."""
    from core import config
    db = _require_db()
    ds = _ensure_dataset_exists(dataset_id)
    if not user.get("is_admin") and not ds.get("is_published"):
        raise HTTPException(status_code=403, detail="Dataset not published")

    engine = _require_federation()
    max_limit = config.federation.distinct_values_limit
    try:
        values = engine.get_column_distinct_values(
            dataset_id=dataset_id,
            column_id=body.column_id,
            parent_filters=body.parent_filters,
            limit=min(body.limit, max_limit),
        )
        return {"column_id": body.column_id, "values": values, "count": len(values)}
    except Exception as exc:
        logger.error("Column values failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get values: {exc}")


# ── Execution History ─────────────────────────────────────────────────────────

def _check_dataset_access(dataset_id: int, user: dict) -> None:
    """Verify user can access a dataset (published or admin)."""
    ds = _require_db().get_dataset(dataset_id)
    if ds and not user.get("is_admin") and not ds.get("is_published"):
        raise HTTPException(status_code=403, detail="Dataset not published")


def _check_execution_access(fe: dict, user: dict) -> None:
    """Verify user can access an execution's parent dataset."""
    ds_id = fe.get("dataset_id")
    if ds_id:
        _check_dataset_access(ds_id, user)


@router.get("/api/datasets/{dataset_id}/executions", tags=["federation"])
async def list_dataset_executions(dataset_id: int,
                                   limit: int = FastQuery(50, ge=1, le=200),
                                   user: dict = Depends(get_current_user)):
    """List recent executions for a dataset."""
    _ensure_dataset_exists(dataset_id)
    _check_dataset_access(dataset_id, user)
    return _require_db().list_federation_executions(dataset_id=dataset_id, limit=limit)


@router.get("/api/datasets/executions/{execution_id}", tags=["federation"])
async def get_execution_detail(execution_id: str, user: dict = Depends(get_current_user)):
    """Get execution detail including generated SQL."""
    result = _require_db().get_federation_execution(execution_id)
    if not result:
        raise HTTPException(status_code=404, detail="Execution not found")
    _check_execution_access(result, user)
    return result


@router.get("/api/datasets/executions/{execution_id}/results", tags=["federation"])
async def get_execution_results(execution_id: str,
                                 offset: int = FastQuery(0, ge=0),
                                 limit: int = FastQuery(500, ge=1, le=10000),
                                 user: dict = Depends(get_current_user)):
    """Read paginated results from a completed execution's parquet file."""
    import pandas as _pd
    fe = _require_db().get_federation_execution(execution_id)
    if not fe:
        raise HTTPException(status_code=404, detail="Execution not found")
    _check_execution_access(fe, user)
    if fe.get("status") != "completed":
        raise HTTPException(status_code=400, detail=f"Execution status: {fe.get('status')}")
    output_path = fe.get("output_path", "")
    if not output_path or not Path(output_path).exists():
        raise HTTPException(status_code=404, detail="Result file not found")

    df = _pd.read_parquet(output_path)
    total = len(df)
    page = df.iloc[offset:offset + limit]
    return {
        "rows": page.to_dict(orient="records"),
        "total_rows": total,
        "offset": offset,
        "limit": limit,
        "columns": df.columns.tolist(),
    }


# ── Merged Dimensions CRUD ───────────────────────────────────────────────────

@router.get("/api/datasets/{dataset_id}/merged-dimensions", tags=["federation"])
async def list_merged_dimensions(dataset_id: int, user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    return _require_db().list_merged_dimensions(dataset_id=dataset_id)


@router.post("/api/datasets/merged-dimensions", tags=["federation"])
async def create_merged_dimension(body: MergedDimensionCreate,
                                   user: dict = Depends(require_admin)):
    if body.primary_dataset_id == body.secondary_dataset_id:
        raise HTTPException(status_code=400, detail="Cannot merge a dataset with itself")
    _ensure_dataset_exists(body.primary_dataset_id)
    _ensure_dataset_exists(body.secondary_dataset_id)
    try:
        return _require_db().create_merged_dimension(
            primary_dataset_id=body.primary_dataset_id,
            secondary_dataset_id=body.secondary_dataset_id,
            name=body.name, merge_keys=body.merge_keys,
            merge_type=body.merge_type, is_active=body.is_active,
        )
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            raise HTTPException(status_code=409, detail="Merged dimension already exists")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/datasets/merged-dimensions/{md_id}", tags=["federation"])
async def update_merged_dimension(md_id: int, body: MergedDimensionUpdate,
                                   user: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = _require_db().update_merged_dimension(md_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Merged dimension not found")
    return result


@router.delete("/api/datasets/merged-dimensions/{md_id}", tags=["federation"])
async def delete_merged_dimension(md_id: int, user: dict = Depends(require_admin)):
    if not _require_db().delete_merged_dimension(md_id):
        raise HTTPException(status_code=404, detail="Merged dimension not found")
    return {"detail": "Merged dimension deleted"}


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 55 — Aggregation Cache Endpoints
# ═══════════════════════════════════════════════════════════════════════════════

class AggCacheCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    dimension_col_ids: List[int] = Field(default_factory=list)
    measure_col_ids: List[int] = Field(default_factory=list)
    grain_label: str = Field("custom",
                             pattern=r"^(yearly|quarterly|monthly|weekly|daily|custom)$")
    condition_ids: List[int] = Field(default_factory=list)
    schedule_config: Optional[Dict[str, Any]] = None
    is_enabled: bool = True
    incremental_enabled: bool = False
    incremental_column: Optional[str] = None


class AggCacheUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    dimension_col_ids: Optional[List[int]] = None
    measure_col_ids: Optional[List[int]] = None
    grain_label: Optional[str] = Field(
        None, pattern=r"^(yearly|quarterly|monthly|weekly|daily|custom)$")
    condition_ids: Optional[List[int]] = None
    schedule_config: Optional[Dict[str, Any]] = None
    is_enabled: Optional[bool] = None
    incremental_enabled: Optional[bool] = None
    incremental_column: Optional[str] = None


class AggCacheConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    max_storage_mb: Optional[int] = Field(None, ge=100)
    max_entries_per_dataset: Optional[int] = Field(None, ge=1)
    default_ttl_hours: Optional[int] = Field(None, ge=1)
    hard_expiry_hours: Optional[int] = Field(None, ge=1)
    stale_serve_enabled: Optional[bool] = None
    write_through_enabled: Optional[bool] = None
    refresh_timeout_seconds: Optional[int] = Field(None, ge=60)
    cleanup_interval_hours: Optional[int] = Field(None, ge=1)
    suggestion_enabled: Optional[bool] = None
    suggestion_min_queries: Optional[int] = Field(None, ge=1)
    suggestion_analysis_window_days: Optional[int] = Field(None, ge=1)


# ── Agg Cache CRUD (per dataset) ─────────────────────────────────────────────

@router.get("/api/datasets/{dataset_id}/agg-cache", tags=["agg-cache"])
async def list_agg_cache_entries(dataset_id: int,
                                  user: dict = Depends(get_current_user)):
    _ensure_dataset_exists(dataset_id)
    entries = _require_db().list_agg_cache_entries(dataset_id=dataset_id)
    return {"entries": entries, "total": len(entries)}


@router.post("/api/datasets/{dataset_id}/agg-cache", tags=["agg-cache"])
async def create_agg_cache_entry(dataset_id: int, body: AggCacheCreate,
                                  user: dict = Depends(require_admin)):
    from core import config
    db = _require_db()
    _ensure_dataset_exists(dataset_id)

    # Validate quota
    existing = db.list_agg_cache_entries(dataset_id=dataset_id)
    if len(existing) >= config.agg_cache.max_entries_per_dataset:
        raise HTTPException(
            status_code=400,
            detail=f"Max {config.agg_cache.max_entries_per_dataset} cache entries per dataset")

    # Validate column IDs belong to dataset
    all_cols = db.list_dataset_columns(dataset_id)
    valid_ids = {c["id"] for c in all_cols}
    for cid in body.dimension_col_ids + body.measure_col_ids:
        if cid not in valid_ids:
            raise HTTPException(status_code=400,
                                detail=f"Column {cid} not found in dataset")

    try:
        entry = db.create_agg_cache_entry(
            dataset_id=dataset_id,
            name=body.name,
            description=body.description,
            dimension_col_ids=body.dimension_col_ids,
            measure_col_ids=body.measure_col_ids,
            grain_label=body.grain_label,
            condition_ids=body.condition_ids,
            schedule_config=body.schedule_config,
            is_enabled=body.is_enabled,
            incremental_enabled=body.incremental_enabled,
            incremental_column=body.incremental_column,
            created_by=user.get("username", "admin"),
        )
    except Exception as exc:
        if "UNIQUE constraint" in str(exc):
            raise HTTPException(status_code=409,
                                detail="Cache entry with this name already exists")
        raise HTTPException(status_code=500, detail="Failed to create cache entry")

    # Register schedule if provided
    if body.schedule_config:
        try:
            from core.agg_cache import register_cache_entry_schedule
            from core.scheduler import _scheduler
            if _scheduler:
                register_cache_entry_schedule(_scheduler, entry["id"])
        except Exception:
            pass

    logger.info("Agg cache entry %d created for dataset %d by %s",
                entry["id"], dataset_id, user.get("username"))
    return entry


@router.get("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def get_agg_cache_entry(entry_id: int,
                               user: dict = Depends(get_current_user)):
    entry = _require_db().get_agg_cache_entry(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")
    return entry


@router.put("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def update_agg_cache_entry(entry_id: int, body: AggCacheUpdate,
                                  user: dict = Depends(require_admin)):
    db = _require_db()
    existing = db.get_agg_cache_entry(entry_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Validate column IDs if changed
    ds_id = existing["dataset_id"]
    if "dimension_col_ids" in updates or "measure_col_ids" in updates:
        all_cols = db.list_dataset_columns(ds_id)
        valid_ids = {c["id"] for c in all_cols}
        for cid in (updates.get("dimension_col_ids") or []) + (updates.get("measure_col_ids") or []):
            if cid not in valid_ids:
                raise HTTPException(status_code=400,
                                    detail=f"Column {cid} not found in dataset")
        # Invalidate current cache when columns change
        updates["status"] = "pending"
        updates["file_path"] = None
        updates["file_size_bytes"] = 0
        updates["row_count"] = 0

    result = db.update_agg_cache_entry(entry_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    # Update schedule if changed
    if "schedule_config" in updates:
        try:
            from core.agg_cache import register_cache_entry_schedule, unregister_cache_entry_schedule
            from core.scheduler import _scheduler
            if _scheduler:
                if updates["schedule_config"]:
                    register_cache_entry_schedule(_scheduler, entry_id)
                else:
                    unregister_cache_entry_schedule(_scheduler, entry_id)
        except Exception:
            pass

    logger.info("Agg cache entry %d updated by %s", entry_id, user.get("username"))
    return result


@router.delete("/api/datasets/agg-cache/{entry_id}", tags=["agg-cache"])
async def delete_agg_cache_entry(entry_id: int,
                                  user: dict = Depends(require_admin)):
    db = _require_db()
    entry = db.get_agg_cache_entry(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    # Remove parquet file
    fp = entry.get("file_path")
    if fp:
        import os
        if os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError:
                pass

    # Unregister schedule
    try:
        from core.agg_cache import unregister_cache_entry_schedule
        from core.scheduler import _scheduler
        if _scheduler:
            unregister_cache_entry_schedule(_scheduler, entry_id)
    except Exception:
        pass

    db.delete_agg_cache_entry(entry_id)
    logger.info("Agg cache entry %d deleted by %s", entry_id, user.get("username"))
    return {"detail": "Cache entry deleted"}


@router.post("/api/datasets/agg-cache/{entry_id}/build", tags=["agg-cache"])
async def trigger_agg_cache_build(entry_id: int,
                                   user: dict = Depends(require_admin)):
    entry = _require_db().get_agg_cache_entry(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Cache entry not found")

    import asyncio
    from core.agg_cache import build_cache_entry
    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, build_cache_entry, entry_id, True)

    return {"detail": f"Build triggered for cache entry {entry_id}",
            "entry_id": entry_id}


# ── Agg Cache Stats ──────────────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/stats", tags=["agg-cache"])
async def get_agg_cache_stats(user: dict = Depends(require_admin)):
    from core.agg_cache import get_cache_stats
    return get_cache_stats()


@router.get("/api/admin/agg-cache/stats/{dataset_id}", tags=["agg-cache"])
async def get_agg_cache_dataset_stats(dataset_id: int,
                                       user: dict = Depends(require_admin)):
    from core.agg_cache import get_cache_stats
    return get_cache_stats(dataset_id=dataset_id)


# ── Agg Cache Suggestions ────────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/suggestions", tags=["agg-cache"])
async def list_agg_cache_suggestions(user: dict = Depends(require_admin)):
    suggestions = _require_db().list_agg_cache_suggestions()
    return {"suggestions": suggestions, "total": len(suggestions)}


@router.post("/api/admin/agg-cache/analyze", tags=["agg-cache"])
async def trigger_usage_analysis(user: dict = Depends(require_admin)):
    from core.agg_cache import analyze_usage_patterns
    new_suggestions = analyze_usage_patterns()
    return {"detail": f"Analysis complete: {len(new_suggestions)} new suggestions",
            "suggestions": new_suggestions}


@router.post("/api/admin/agg-cache/suggestions/{suggestion_id}/approve",
             tags=["agg-cache"])
async def approve_agg_cache_suggestion(suggestion_id: int,
                                        user: dict = Depends(require_admin)):
    from core.agg_cache import approve_suggestion
    entry = approve_suggestion(suggestion_id,
                               created_by=user.get("username", "admin"))
    if not entry:
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion approved and cache entry created", "entry": entry}


@router.post("/api/admin/agg-cache/suggestions/{suggestion_id}/reject",
             tags=["agg-cache"])
async def reject_agg_cache_suggestion(suggestion_id: int,
                                       user: dict = Depends(require_admin)):
    from core.agg_cache import reject_suggestion
    result = reject_suggestion(suggestion_id,
                               reviewed_by=user.get("username", "admin"))
    if not result:
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion rejected"}


@router.delete("/api/admin/agg-cache/suggestions/{suggestion_id}",
               tags=["agg-cache"])
async def delete_agg_cache_suggestion(suggestion_id: int,
                                       user: dict = Depends(require_admin)):
    if not _require_db().delete_agg_cache_suggestion(suggestion_id):
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return {"detail": "Suggestion deleted"}


# ── Agg Cache Config (admin) ─────────────────────────────────────────────────

@router.get("/api/admin/agg-cache/config", tags=["agg-cache"])
async def get_agg_cache_config(user: dict = Depends(require_admin)):
    from core import config
    return {
        "enabled": config.agg_cache.enabled,
        "storage_dir": config.agg_cache.storage_dir,
        "max_storage_mb": config.agg_cache.max_storage_mb,
        "max_entries_per_dataset": config.agg_cache.max_entries_per_dataset,
        "default_ttl_hours": config.agg_cache.default_ttl_hours,
        "hard_expiry_hours": config.agg_cache.hard_expiry_hours,
        "stale_serve_enabled": config.agg_cache.stale_serve_enabled,
        "write_through_enabled": config.agg_cache.write_through_enabled,
        "refresh_timeout_seconds": config.agg_cache.refresh_timeout_seconds,
        "suggestion_enabled": config.agg_cache.suggestion_enabled,
        "suggestion_min_queries": config.agg_cache.suggestion_min_queries,
        "suggestion_analysis_window_days": config.agg_cache.suggestion_analysis_window_days,
    }


@router.put("/api/admin/agg-cache/config", tags=["agg-cache"])
async def update_agg_cache_config(body: AggCacheConfigUpdate,
                                   user: dict = Depends(require_admin)):
    from core import config
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    for k, v in updates.items():
        config.set("agg_cache", k, v)
    logger.info("Agg cache config updated by %s: %s",
                user.get("username"), list(updates.keys()))
    return await get_agg_cache_config(user=user)


# ── Agg Cache Maintenance (admin) ────────────────────────────────────────────

@router.post("/api/admin/agg-cache/cleanup", tags=["agg-cache"])
async def trigger_agg_cache_cleanup(user: dict = Depends(require_admin)):
    from core.agg_cache import cleanup_expired, enforce_storage_quota
    expired = cleanup_expired()
    evicted = enforce_storage_quota()
    return {"detail": f"Cleanup complete: {expired} expired, {evicted} evicted"}


@router.post("/api/admin/agg-cache/invalidate/{dataset_id}", tags=["agg-cache"])
async def invalidate_dataset_agg_cache(dataset_id: int,
                                        user: dict = Depends(require_admin)):
    from core.agg_cache import invalidate_by_dataset
    count = invalidate_by_dataset(dataset_id)
    return {"detail": f"Invalidated {count} cache entries for dataset {dataset_id}"}
