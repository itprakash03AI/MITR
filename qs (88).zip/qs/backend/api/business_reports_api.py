"""Phase 56+58+62 — Business Report Builder, Report Catalog & Export API.

Provides CRUD for BusinessReport + ReportParameter, report execution via
FederationEngine, cascading parameter LOV resolution, certification,
clone from template, share tokens, embed tokens, PDF/Excel export,
and admin config.
"""
from __future__ import annotations

import io
import logging
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, List, Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Dependency injection (set from main.py startup) ─────────────────────────
_db_manager = None
_federation_engine = None


def set_business_reports_dependencies(db_manager, federation_engine):
    """Called once from main.py _startup()."""
    global _db_manager, _federation_engine
    _db_manager = db_manager
    _federation_engine = federation_engine


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Business reports API not initialised — call set_business_reports_dependencies() first")
    return _db_manager


def _require_federation():
    if _federation_engine is None:
        raise RuntimeError("Federation engine not available for business reports")
    return _federation_engine


# ── Pydantic models ─────────────────────────────────────────────────────────

class ReportCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    dataset_id: int
    merged_dataset_id: Optional[int] = None
    merge_config: Optional[dict] = None
    column_ids: List[int] = []
    filter_specs: List[dict] = []
    condition_ids: List[int] = []
    order_by: List[dict] = []
    row_limit: int = 50000
    section_definitions: List[dict] = []
    running_calculations: List[dict] = []
    slicer_column_ids: List[int] = []
    drill_hierarchy_id: Optional[int] = None
    layout_config: Optional[dict] = None
    role_whitelist: Optional[List[str]] = None


class ReportUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    column_ids: Optional[List[int]] = None
    filter_specs: Optional[List[dict]] = None
    condition_ids: Optional[List[int]] = None
    order_by: Optional[List[dict]] = None
    row_limit: Optional[int] = None
    section_definitions: Optional[List[dict]] = None
    running_calculations: Optional[List[dict]] = None
    slicer_column_ids: Optional[List[int]] = None
    drill_hierarchy_id: Optional[int] = None
    layout_config: Optional[dict] = None
    merged_dataset_id: Optional[int] = None
    merge_config: Optional[dict] = None
    role_whitelist: Optional[List[str]] = None


class ReportExecuteRequest(BaseModel):
    parameter_values: dict = {}  # {param_name: value}
    extra_filters: List[dict] = []
    limit_override: Optional[int] = None


class ReportParameterCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    label: str = Field(..., min_length=1, max_length=200)
    parameter_type: str = "dropdown"
    lov_column_id: Optional[int] = None
    depends_on_param_id: Optional[int] = None
    cascade_filter_column_id: Optional[int] = None
    default_value: Optional[str] = None
    is_required: bool = True
    sort_order: int = 0


class ReportParameterUpdate(BaseModel):
    name: Optional[str] = None
    label: Optional[str] = None
    parameter_type: Optional[str] = None
    lov_column_id: Optional[int] = None
    depends_on_param_id: Optional[int] = None
    cascade_filter_column_id: Optional[int] = None
    default_value: Optional[str] = None
    is_required: Optional[bool] = None
    sort_order: Optional[int] = None


class ParameterValuesRequest(BaseModel):
    parameter_id: int
    parent_values: dict = {}  # {parent_param_name: selected_value}


class CertifyRequest(BaseModel):
    template_category: str = Field(..., min_length=1, max_length=100)


class ShareCreateRequest(BaseModel):
    expires_hours: Optional[int] = None  # None = use config default


class EmbedTokenCreateRequest(BaseModel):
    expires_in_days: Optional[int] = None  # None = use config default


class EmbedExecuteRequest(BaseModel):
    parameter_values: dict = {}
    limit: Optional[int] = 1000


# ── Report CRUD ──────────────────────────────────────────────────────────────

@router.get("/api/business-reports")
async def list_reports(
    owner: Optional[str] = Query(None),
    dataset_id: Optional[int] = Query(None),
    published_only: bool = Query(False),
    user: dict = Depends(get_current_user),
):
    """List business reports. Non-admins see own + published reports."""
    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    if published_only:
        return db.list_business_reports(is_published=True, dataset_id=dataset_id)

    if role == "admin":
        return db.list_business_reports(owner=owner, dataset_id=dataset_id)

    # Non-admin: own reports + published
    own = db.list_business_reports(owner=username, dataset_id=dataset_id)
    published = db.list_business_reports(is_published=True, dataset_id=dataset_id)
    seen_ids = {r["id"] for r in own}
    combined = list(own)
    for r in published:
        if r["id"] not in seen_ids:
            combined.append(r)
    combined.sort(key=lambda r: r.get("updated_at", ""), reverse=True)
    return combined


@router.post("/api/business-reports")
async def create_report(body: ReportCreate, user: dict = Depends(get_current_user)):
    """Create a new business report."""
    db = _require_db()
    from core import config
    username = (user or {}).get("username", "admin")

    # Quota check
    existing = db.list_business_reports(owner=username)
    max_reports = config.business_reports.max_reports_per_user
    if len(existing) >= max_reports:
        raise HTTPException(status_code=400,
                            detail=f"Report quota exceeded ({max_reports} max per user)")

    # Validate dataset exists
    ds = db.get_dataset(body.dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail=f"Dataset {body.dataset_id} not found")

    # Validate section/calc limits
    _cfg = config.business_reports
    if len(body.section_definitions) > _cfg.max_sections_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_sections_per_report} sections per report")
    if len(body.running_calculations) > _cfg.max_running_calcs_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_running_calcs_per_report} running calculations per report")

    data = body.model_dump(exclude_none=True)
    data["owner"] = username
    report = db.create_business_report(**data)
    logger.info("Created business report '%s' (id=%s) by user '%s'", body.name, report["id"], username)
    return report


# ── Templates (static paths — must be before {report_id}) ────────────────────

@router.get("/api/business-reports/templates")
async def list_templates(
    category: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(get_current_user),
):
    """List certified business report templates, optionally filtered by category."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.template_gallery_enabled:
        raise HTTPException(status_code=400, detail="Template gallery is disabled")
    return db.list_certified_templates(category=category, limit=limit)


@router.get("/api/business-reports/template-categories")
async def list_categories(user: dict = Depends(get_current_user)):
    """List all template categories that have at least one certified report."""
    db = _require_db()
    return {"categories": db.list_template_categories()}


@router.get("/api/business-reports/{report_id}")
async def get_report(report_id: int, user: dict = Depends(get_current_user)):
    """Get report definition with its parameters."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if not report["is_published"] and report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    report["parameters"] = db.list_report_parameters(report_id)
    return report


@router.put("/api/business-reports/{report_id}")
async def update_report(report_id: int, body: ReportUpdate, user: dict = Depends(get_current_user)):
    """Update report definition. Only owner or admin can update."""
    db = _require_db()
    existing = db.get_business_report(report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if existing["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Only the report owner or admin can update")

    from core import config
    _cfg = config.business_reports
    updates = body.model_dump(exclude_none=True)
    if "section_definitions" in updates and len(updates["section_definitions"]) > _cfg.max_sections_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_sections_per_report} sections per report")
    if "running_calculations" in updates and len(updates["running_calculations"]) > _cfg.max_running_calcs_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {_cfg.max_running_calcs_per_report} running calculations per report")

    updated = db.update_business_report(report_id, **updates)
    return updated


@router.delete("/api/business-reports/{report_id}")
async def delete_report(report_id: int, user: dict = Depends(get_current_user)):
    """Delete report. Only owner or admin."""
    db = _require_db()
    existing = db.get_business_report(report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if existing["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Only the report owner or admin can delete")

    db.delete_business_report(report_id)
    logger.info("Deleted business report id=%d by user '%s'", report_id, username)
    return {"detail": "deleted"}


# ── Report Execution ─────────────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/execute")
async def execute_report(report_id: int, body: ReportExecuteRequest,
                         user: dict = Depends(get_current_user)):
    """Execute a business report via the Federation Engine.

    Merges report's static filters with parameter-derived filters,
    then calls execute_dataset_query (or execute_merged_query for dual-dataset).
    """
    db = _require_db()
    fed = _require_federation()

    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if not report["is_published"] and report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    # Build combined filters: report defaults + parameter values + extra
    combined_filters = list(report.get("filter_specs") or [])

    # Resolve parameter values → filters
    params = db.list_report_parameters(report_id)
    for param in params:
        pname = param["name"]
        pval = body.parameter_values.get(pname)
        if pval is not None and param.get("lov_column_id"):
            if param["parameter_type"] == "multi_select" and isinstance(pval, list):
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "in",
                    "value": pval,
                })
            elif param["parameter_type"] == "date_range" and isinstance(pval, dict):
                if pval.get("from"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "gte",
                        "value": pval["from"],
                    })
                if pval.get("to"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "lte",
                        "value": pval["to"],
                    })
            else:
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "eq",
                    "value": pval,
                })

    # Add any extra filters from the request
    combined_filters.extend(body.extra_filters)

    row_limit = body.limit_override or report.get("row_limit") or 50000
    execution_id = str(uuid.uuid4())

    try:
        if report.get("merged_dataset_id") and report.get("merge_config"):
            mc = report["merge_config"]
            result = fed.execute_merged_query(
                primary_dataset_id=report["dataset_id"],
                secondary_dataset_id=report["merged_dataset_id"],
                primary_column_ids=report["column_ids"],
                secondary_column_ids=[],
                merge_keys=mc.get("merge_keys", []),
                merge_type=mc.get("merge_type", "inner"),
                primary_filters=combined_filters,
                limit=row_limit,
                primary_condition_ids=report.get("condition_ids"),
                execution_id=execution_id,
                user_role=role,
            )
        else:
            result = fed.execute_dataset_query(
                dataset_id=report["dataset_id"],
                column_ids=report["column_ids"],
                filters=combined_filters if combined_filters else None,
                condition_ids=report.get("condition_ids") or None,
                order_by=report.get("order_by") or None,
                limit=row_limit,
                execution_id=execution_id,
                user_role=role,
            )

        db.increment_business_report_execution(report_id)

        return result.to_dict() if hasattr(result, "to_dict") else result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.error("Report execution failed (report_id=%d): %s", report_id, exc)
        raise HTTPException(status_code=500, detail=f"Report execution failed: {exc}")


# ── Export (PDF / Excel) — Phase 62 ──────────────────────────────────────────

def _execute_report_internal(report_id: int, username: str, role: str,
                             param_values: dict | None = None,
                             limit_override: int | None = None) -> tuple:
    """Execute a business report and return (rows: list[dict], columns: list[str], report_meta: dict).

    Shared helper for PDF/Excel export endpoints.
    """
    db = _require_db()
    fed = _require_federation()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not report["is_published"] and report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    combined_filters = list(report.get("filter_specs") or [])
    params = db.list_report_parameters(report_id)
    pv = param_values or {}
    for param in params:
        pname = param["name"]
        pval = pv.get(pname)
        if pval is not None and param.get("lov_column_id"):
            if param["parameter_type"] == "multi_select" and isinstance(pval, list):
                combined_filters.append({"column_id": param["lov_column_id"], "operator": "in", "value": pval})
            elif param["parameter_type"] == "date_range" and isinstance(pval, dict):
                if pval.get("from"):
                    combined_filters.append({"column_id": param["lov_column_id"], "operator": "gte", "value": pval["from"]})
                if pval.get("to"):
                    combined_filters.append({"column_id": param["lov_column_id"], "operator": "lte", "value": pval["to"]})
            else:
                combined_filters.append({"column_id": param["lov_column_id"], "operator": "eq", "value": pval})

    row_limit = limit_override or report.get("row_limit") or 50000
    execution_id = str(uuid.uuid4())

    if report.get("merged_dataset_id") and report.get("merge_config"):
        mc = report["merge_config"]
        result = fed.execute_merged_query(
            primary_dataset_id=report["dataset_id"],
            secondary_dataset_id=report["merged_dataset_id"],
            primary_column_ids=report["column_ids"],
            secondary_column_ids=[],
            merge_keys=mc.get("merge_keys", []),
            merge_type=mc.get("merge_type", "inner"),
            primary_filters=combined_filters,
            limit=row_limit,
            primary_condition_ids=report.get("condition_ids"),
            execution_id=execution_id,
            user_role=role,
        )
    else:
        result = fed.execute_dataset_query(
            dataset_id=report["dataset_id"],
            column_ids=report["column_ids"],
            filters=combined_filters if combined_filters else None,
            condition_ids=report.get("condition_ids") or None,
            order_by=report.get("order_by") or None,
            limit=row_limit,
            execution_id=execution_id,
            user_role=role,
        )

    # Read result rows from parquet
    output_path = result.output_path if hasattr(result, "output_path") else result.get("output_path", "")
    columns = result.columns if hasattr(result, "columns") else result.get("columns", [])
    rows: list[dict] = []
    if output_path and Path(output_path).exists():
        import pandas as _pd
        df = _pd.read_parquet(output_path)
        columns = list(df.columns)
        rows = df.to_dict(orient="records")

    return rows, columns, report


@router.get("/api/business-reports/{report_id}/download-pdf")
async def download_business_report_pdf(
    report_id: int,
    user: dict = Depends(get_current_user),
    limit: int = Query(default=10000, ge=1, le=100000),
):
    """Execute business report and return PDF download."""
    try:
        import weasyprint as _wp
    except ImportError:
        raise HTTPException(status_code=501, detail="PDF export requires WeasyPrint. Install with: pip install weasyprint")

    import html as _html_mod
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    try:
        rows, columns, report = _execute_report_internal(report_id, username, role, limit_override=limit)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Report execution failed: {exc}")

    report_name = report.get("name", f"Report {report_id}")
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Build HTML
    thead = "".join(f"<th>{_html_mod.escape(str(c))}</th>" for c in columns)
    tbody_rows = []
    for row in rows[:limit]:
        cells = "".join(
            f"<td>{_html_mod.escape(str(row.get(c, '')) if row.get(c) is not None else '')}</td>"
            for c in columns
        )
        tbody_rows.append(f"<tr>{cells}</tr>")

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{_html_mod.escape(report_name)}</title></head>
<body>
<div class="page-header"><span class="header-title">{_html_mod.escape(report_name)}</span>
<span class="run-date">{now_str}</span></div>
<table><thead><tr>{thead}</tr></thead><tbody>{''.join(tbody_rows)}</tbody></table>
<p class="row-count">{len(tbody_rows):,} row(s)</p>
</body></html>"""

    css = """@page { size: A4 landscape; margin: 15mm 12mm 18mm 12mm;
  @bottom-center { content: "Generated by QueryStudio | Page " counter(page) " of " counter(pages);
                   font-size: 8pt; color: #888; } }
body { font-family: Arial, sans-serif; font-size: 10pt; color: #222; }
table { border-collapse: collapse; width: 100%; font-size: 9pt; }
thead tr { background: #1976d2; color: #fff; }
th { padding: 5pt 6pt; text-align: left; font-weight: bold; white-space: nowrap; }
td { padding: 3pt 6pt; border-bottom: 1px solid #e0e0e0; }
tr:nth-child(even) { background: #f5f7fa; }
.page-header { display: flex; justify-content: space-between; margin-bottom: 6pt;
               font-size: 9pt; color: #555; border-bottom: 1px solid #ccc; padding-bottom: 3pt; }
.header-title { font-weight: bold; }
.row-count { font-size: 8pt; color: #999; margin-top: 6pt; }"""

    try:
        pdf_bytes = _wp.HTML(string=html).write_pdf(stylesheets=[_wp.CSS(string=css)])
    except Exception as exc:
        logger.error("WeasyPrint render failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"PDF render failed: {exc}")

    filename = f"{report_name.replace(' ', '_')}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/api/business-reports/{report_id}/download-excel")
async def download_business_report_excel(
    report_id: int,
    user: dict = Depends(get_current_user),
    limit: int = Query(default=50000, ge=1, le=200000),
):
    """Execute business report and return Excel (.xlsx) download."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    try:
        rows, columns, report = _execute_report_internal(report_id, username, role, limit_override=limit)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Report execution failed: {exc}")

    report_name = report.get("name", f"Report {report_id}")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = report_name[:31]  # Excel sheet name max 31 chars

    # Header row — styled
    header_font = Font(bold=True, color="FFFFFF", size=10)
    header_fill = PatternFill(start_color="1976D2", end_color="1976D2", fill_type="solid")
    for col_idx, col_name in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="left")

    # Data rows
    for row_idx, row in enumerate(rows[:limit], 2):
        for col_idx, col_name in enumerate(columns, 1):
            ws.cell(row=row_idx, column=col_idx, value=row.get(col_name))

    # Auto-fit column widths (approximate)
    for col_idx, col_name in enumerate(columns, 1):
        max_len = len(str(col_name))
        for row in rows[:100]:
            val = str(row.get(col_name, ""))
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = min(max_len + 2, 40)

    # Freeze top row
    ws.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    filename = f"{report_name.replace(' ', '_')}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ── Duplicate & Publish ──────────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/duplicate")
async def duplicate_report(report_id: int, user: dict = Depends(get_current_user)):
    """Clone a report (including parameters) for the current user."""
    db = _require_db()
    source = db.get_business_report(report_id)
    if not source:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "admin")
    # Build new report data from source
    clone_data = {
        "name": f"{source['name']} (Copy)",
        "owner": username,
        "dataset_id": source["dataset_id"],
        "description": source.get("description", ""),
        "merged_dataset_id": source.get("merged_dataset_id"),
        "merge_config": source.get("merge_config"),
        "column_ids": source.get("column_ids", []),
        "filter_specs": source.get("filter_specs", []),
        "condition_ids": source.get("condition_ids", []),
        "order_by": source.get("order_by", []),
        "row_limit": source.get("row_limit", 50000),
        "section_definitions": source.get("section_definitions", []),
        "running_calculations": source.get("running_calculations", []),
        "slicer_column_ids": source.get("slicer_column_ids", []),
        "drill_hierarchy_id": source.get("drill_hierarchy_id"),
        "layout_config": source.get("layout_config"),
        "role_whitelist": source.get("role_whitelist"),
    }
    new_report = db.create_business_report(**clone_data)

    # Clone parameters
    source_params = db.list_report_parameters(report_id)
    param_id_map = {}  # old_id → new_id (for remapping depends_on)
    for p in source_params:
        new_p = db.create_report_parameter(
            report_id=new_report["id"],
            name=p["name"],
            label=p["label"],
            parameter_type=p["parameter_type"],
            lov_column_id=p.get("lov_column_id"),
            cascade_filter_column_id=p.get("cascade_filter_column_id"),
            default_value=p.get("default_value"),
            is_required=p.get("is_required", True),
            sort_order=p.get("sort_order", 0),
        )
        param_id_map[p["id"]] = new_p["id"]

    # Remap depends_on_param_id
    for old_p in source_params:
        if old_p.get("depends_on_param_id") and old_p["depends_on_param_id"] in param_id_map:
            new_pid = param_id_map[old_p["id"]]
            db.update_report_parameter(new_pid,
                                        depends_on_param_id=param_id_map[old_p["depends_on_param_id"]])

    new_report["parameters"] = db.list_report_parameters(new_report["id"])
    logger.info("Duplicated report %d → %d by user '%s'", report_id, new_report["id"], username)
    return new_report


@router.post("/api/business-reports/{report_id}/publish")
async def toggle_publish(report_id: int, user: dict = Depends(require_admin)):
    """Toggle report published status. Admin only."""
    db = _require_db()
    existing = db.get_business_report(report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")
    new_val = not existing["is_published"]
    updated = db.update_business_report(report_id, is_published=new_val)
    logger.info("Report %d publish toggled to %s", report_id, new_val)
    return updated


# ── Report Parameters CRUD ───────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/parameters")
async def list_parameters(report_id: int, user: dict = Depends(get_current_user)):
    """List parameters for a report."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return db.list_report_parameters(report_id)


@router.post("/api/business-reports/{report_id}/parameters")
async def create_parameter(report_id: int, body: ReportParameterCreate,
                           user: dict = Depends(get_current_user)):
    """Add a parameter to a report. Only owner or admin."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Only report owner or admin can add parameters")

    from core import config
    existing = db.list_report_parameters(report_id)
    if len(existing) >= config.business_reports.max_parameters_per_report:
        raise HTTPException(status_code=400,
                            detail=f"Max {config.business_reports.max_parameters_per_report} parameters per report")

    data = body.model_dump(exclude_none=True)
    data["report_id"] = report_id
    return db.create_report_parameter(**data)


@router.put("/api/business-reports/parameters/{param_id}")
async def update_parameter(param_id: int, body: ReportParameterUpdate,
                           user: dict = Depends(get_current_user)):
    """Update a report parameter."""
    db = _require_db()
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = db.update_report_parameter(param_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Parameter not found")
    return result


@router.delete("/api/business-reports/parameters/{param_id}")
async def delete_parameter(param_id: int, user: dict = Depends(get_current_user)):
    """Delete a report parameter."""
    db = _require_db()
    if not db.delete_report_parameter(param_id):
        raise HTTPException(status_code=404, detail="Parameter not found")
    return {"detail": "deleted"}


# ── Parameter LOV (Cascading Prompts) ────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/parameter-values")
async def get_parameter_values(report_id: int, body: ParameterValuesRequest,
                               user: dict = Depends(get_current_user)):
    """Get distinct values for a parameter's LOV column.

    Supports cascading: if the parameter depends on a parent, the parent's
    selected value is used as a filter on the LOV query.
    """
    db = _require_db()
    fed = _require_federation()

    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    params = db.list_report_parameters(report_id)
    param = next((p for p in params if p["id"] == body.parameter_id), None)
    if not param:
        raise HTTPException(status_code=404, detail="Parameter not found")

    if not param.get("lov_column_id"):
        return {"values": []}

    # Build cascade filters from parent param values
    parent_filters = []
    if param.get("depends_on_param_id") and param.get("cascade_filter_column_id"):
        parent_param = next((p for p in params if p["id"] == param["depends_on_param_id"]), None)
        if parent_param:
            parent_val = body.parent_values.get(parent_param["name"])
            if parent_val is not None:
                parent_filters.append({
                    "column_id": param["cascade_filter_column_id"],
                    "operator": "in" if isinstance(parent_val, list) else "eq",
                    "value": parent_val,
                })

    from core import config
    try:
        values = fed.get_column_distinct_values(
            dataset_id=report["dataset_id"],
            column_id=param["lov_column_id"],
            parent_filters=parent_filters if parent_filters else None,
            limit=config.business_reports.cascade_lov_limit,
        )
        return {"values": values}
    except Exception as exc:
        logger.warning("LOV fetch failed for param %d: %s", param["id"], exc)
        return {"values": [], "error": str(exc)}


# ── Admin Config ─────────────────────────────────────────────────────────────

@router.get("/api/admin/reports/config")
async def get_reports_config(user: dict = Depends(require_admin)):
    """Return current business reports configuration."""
    from core import config as _cfg
    return {
        "enabled":                      _cfg.business_reports.enabled,
        "max_reports_per_user":         _cfg.business_reports.max_reports_per_user,
        "max_sections_per_report":      _cfg.business_reports.max_sections_per_report,
        "max_parameters_per_report":    _cfg.business_reports.max_parameters_per_report,
        "max_running_calcs_per_report": _cfg.business_reports.max_running_calcs_per_report,
        "default_row_limit":            _cfg.business_reports.default_row_limit,
        "cascade_lov_limit":            _cfg.business_reports.cascade_lov_limit,
        "auto_save_interval_seconds":   _cfg.business_reports.auto_save_interval_seconds,
        "export_formats":               _cfg.business_reports.export_formats,
    }


@router.put("/api/admin/reports/config")
async def set_reports_config(body: dict, user: dict = Depends(require_admin)):
    """Update business reports configuration."""
    from core import config as _cfg
    allowed = {
        "enabled", "max_reports_per_user", "max_sections_per_report",
        "max_parameters_per_report", "max_running_calcs_per_report",
        "default_row_limit", "cascade_lov_limit", "auto_save_interval_seconds",
        "export_formats",
    }
    for k, v in body.items():
        if k in allowed:
            _cfg.set("business_reports", k, v)
    username = (user or {}).get("username", "admin")
    _db_manager.audit(username, "update_reports_config", resource_type="config",
                      resource_id="business_reports")
    return await get_reports_config(user)


# ── Certification (Phase 58) ─────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/certify")
async def certify_report(report_id: int, body: CertifyRequest,
                         user: dict = Depends(require_admin)):
    """Certify a business report as an official template. Admin only."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.certification_enabled:
        raise HTTPException(status_code=400, detail="Certification is disabled")

    existing = db.get_business_report(report_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Report not found")

    # Validate category against configured list
    allowed_cats = _cfg.report_catalog.template_categories
    if allowed_cats and body.template_category not in allowed_cats:
        raise HTTPException(status_code=400,
                            detail=f"Invalid category. Allowed: {allowed_cats}")

    username = (user or {}).get("username", "admin")
    updated = db.certify_business_report(report_id, username, body.template_category)
    if not updated:
        raise HTTPException(status_code=404, detail="Report not found")

    logger.info("Report %d certified by '%s' in category '%s'",
                report_id, username, body.template_category)
    return updated


@router.delete("/api/business-reports/{report_id}/certify")
async def uncertify_report(report_id: int, user: dict = Depends(require_admin)):
    """Remove certification from a business report. Admin only."""
    db = _require_db()
    updated = db.uncertify_business_report(report_id)
    if not updated:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "admin")
    logger.info("Report %d uncertified by '%s'", report_id, username)
    return updated


# ── Clone from Template (Phase 58) ───────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/clone")
async def clone_template(report_id: int, user: dict = Depends(get_current_user)):
    """Clone a certified template to the current user's workspace.

    Similar to duplicate, but only works on certified reports and tracks
    ``cloned_from_id`` for lineage.
    """
    db = _require_db()
    source = db.get_business_report(report_id)
    if not source:
        raise HTTPException(status_code=404, detail="Report not found")
    if not source.get("is_certified"):
        raise HTTPException(status_code=400, detail="Only certified templates can be cloned")

    username = (user or {}).get("username", "admin")

    # Quota check
    from core import config
    existing = db.list_business_reports(owner=username)
    max_reports = config.business_reports.max_reports_per_user
    if len(existing) >= max_reports:
        raise HTTPException(status_code=400,
                            detail=f"Report quota exceeded ({max_reports} max per user)")

    clone_data = {
        "name": f"{source['name']} (My Copy)",
        "owner": username,
        "dataset_id": source["dataset_id"],
        "description": source.get("description", ""),
        "merged_dataset_id": source.get("merged_dataset_id"),
        "merge_config": source.get("merge_config"),
        "column_ids": source.get("column_ids", []),
        "filter_specs": source.get("filter_specs", []),
        "condition_ids": source.get("condition_ids", []),
        "order_by": source.get("order_by", []),
        "row_limit": source.get("row_limit", 50000),
        "section_definitions": source.get("section_definitions", []),
        "running_calculations": source.get("running_calculations", []),
        "slicer_column_ids": source.get("slicer_column_ids", []),
        "drill_hierarchy_id": source.get("drill_hierarchy_id"),
        "layout_config": source.get("layout_config"),
        "role_whitelist": source.get("role_whitelist"),
    }
    new_report = db.create_business_report(**clone_data)

    # Set cloned_from_id
    db.update_business_report(new_report["id"], cloned_from_id=report_id)
    new_report["cloned_from_id"] = report_id

    # Clone parameters
    source_params = db.list_report_parameters(report_id)
    param_id_map = {}
    for p in source_params:
        new_p = db.create_report_parameter(
            report_id=new_report["id"],
            name=p["name"],
            label=p["label"],
            parameter_type=p["parameter_type"],
            lov_column_id=p.get("lov_column_id"),
            cascade_filter_column_id=p.get("cascade_filter_column_id"),
            default_value=p.get("default_value"),
            is_required=p.get("is_required", True),
            sort_order=p.get("sort_order", 0),
        )
        param_id_map[p["id"]] = new_p["id"]

    for old_p in source_params:
        if old_p.get("depends_on_param_id") and old_p["depends_on_param_id"] in param_id_map:
            new_pid = param_id_map[old_p["id"]]
            db.update_report_parameter(new_pid,
                                       depends_on_param_id=param_id_map[old_p["depends_on_param_id"]])

    new_report["parameters"] = db.list_report_parameters(new_report["id"])
    logger.info("Cloned certified template %d → %d by user '%s'",
                report_id, new_report["id"], username)
    return new_report


# ── Share Tokens (Phase 58) ──────────────────────────────────────────────────

@router.post("/api/business-reports/{report_id}/share")
async def create_share_token(report_id: int, body: ShareCreateRequest,
                             user: dict = Depends(get_current_user)):
    """Create a public share link for a business report."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.sharing_enabled:
        raise HTTPException(status_code=400, detail="Report sharing is disabled")

    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Only report owner or admin can share")

    # Enforce max shares per report
    existing_shares = db.list_business_report_shares(report_id)
    max_shares = _cfg.report_catalog.max_shares_per_report
    if len(existing_shares) >= max_shares:
        raise HTTPException(status_code=400,
                            detail=f"Max {max_shares} share links per report")

    hours = body.expires_hours or _cfg.report_catalog.share_default_expiry_hours
    expires_at = datetime.now(timezone.utc) + timedelta(hours=hours)

    share = db.create_business_report_share(report_id, username, expires_at)
    logger.info("Created share token for report %d by '%s'", report_id, username)
    return share


@router.get("/api/business-reports/{report_id}/shares")
async def list_share_tokens(report_id: int, user: dict = Depends(get_current_user)):
    """List active share tokens for a business report."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    return {"shares": db.list_business_report_shares(report_id)}


@router.delete("/api/business-reports/{report_id}/shares/{token}")
async def revoke_share_token(report_id: int, token: str,
                             user: dict = Depends(get_current_user)):
    """Revoke a share token."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    if not db.deactivate_business_report_share(token):
        raise HTTPException(status_code=404, detail="Share token not found")

    logger.info("Revoked share token for report %d by '%s'", report_id, username)
    return {"detail": "revoked"}


# ── Public Share Endpoint (NO AUTH) ──────────────────────────────────────────

@router.get("/api/shared-business-report/{token}")
async def get_shared_report(token: str):
    """PUBLIC — Return report metadata for a share token (no auth required)."""
    db = _require_db()
    share = db.get_business_report_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")

    # Check expiry
    if share.get("expires_at"):
        expires = share["expires_at"]
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if hasattr(expires, 'tzinfo') and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(status_code=410, detail="Share link has expired")

    report = db.get_business_report(share["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    db.increment_business_report_share_access(token)

    report["parameters"] = db.list_report_parameters(share["report_id"])
    return {
        "token": token,
        "report": report,
    }


@router.post("/api/shared-business-report/{token}/execute")
async def execute_shared_report(token: str, body: ReportExecuteRequest):
    """PUBLIC — Execute a shared business report (no auth required)."""
    db = _require_db()
    fed = _require_federation()

    share = db.get_business_report_share_by_token(token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found or revoked")

    if share.get("expires_at"):
        expires = share["expires_at"]
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if hasattr(expires, 'tzinfo') and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(status_code=410, detail="Share link has expired")

    report = db.get_business_report(share["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Build combined filters (same logic as execute_report)
    combined_filters = list(report.get("filter_specs") or [])
    params = db.list_report_parameters(share["report_id"])
    for param in params:
        pname = param["name"]
        pval = body.parameter_values.get(pname)
        if pval is not None and param.get("lov_column_id"):
            if param["parameter_type"] == "multi_select" and isinstance(pval, list):
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "in", "value": pval,
                })
            elif param["parameter_type"] == "date_range" and isinstance(pval, dict):
                if pval.get("from"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "gte", "value": pval["from"],
                    })
                if pval.get("to"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "lte", "value": pval["to"],
                    })
            else:
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "eq", "value": pval,
                })

    combined_filters.extend(body.extra_filters)
    row_limit = body.limit_override or report.get("row_limit") or 50000
    execution_id = str(uuid.uuid4())

    try:
        if report.get("merged_dataset_id") and report.get("merge_config"):
            mc = report["merge_config"]
            result = fed.execute_merged_query(
                primary_dataset_id=report["dataset_id"],
                secondary_dataset_id=report["merged_dataset_id"],
                primary_column_ids=report["column_ids"],
                secondary_column_ids=[],
                merge_keys=mc.get("merge_keys", []),
                merge_type=mc.get("merge_type", "inner"),
                primary_filters=combined_filters,
                limit=row_limit,
                primary_condition_ids=report.get("condition_ids"),
                execution_id=execution_id,
                user_role="viewer",
            )
        else:
            result = fed.execute_dataset_query(
                dataset_id=report["dataset_id"],
                column_ids=report["column_ids"],
                filters=combined_filters if combined_filters else None,
                condition_ids=report.get("condition_ids") or None,
                order_by=report.get("order_by") or None,
                limit=row_limit,
                execution_id=execution_id,
                user_role="viewer",
            )

        db.increment_report_execution(share["report_id"])
        return result.to_dict() if hasattr(result, "to_dict") else result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.error("Shared report execution failed (token=%s): %s", token[:8], exc)
        raise HTTPException(status_code=500, detail=f"Report execution failed: {exc}")


# ── Embed Tokens for Business Reports (Phase 58) ────────────────────────────

@router.post("/api/business-reports/{report_id}/embed-tokens")
async def create_embed_token(report_id: int, body: EmbedTokenCreateRequest,
                             user: dict = Depends(get_current_user)):
    """Create an embed token for a business report."""
    db = _require_db()
    from core import config as _cfg
    if not _cfg.report_catalog.embed_enabled:
        raise HTTPException(status_code=400, detail="Report embedding is disabled")

    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Only report owner or admin can create embed tokens")

    existing_tokens = db.list_embed_tokens(report_id, report_type="business")
    max_tokens = _cfg.report_catalog.max_embed_tokens_per_report
    if len(existing_tokens) >= max_tokens:
        raise HTTPException(status_code=400,
                            detail=f"Max {max_tokens} embed tokens per report")

    days = body.expires_in_days or _cfg.report_catalog.embed_default_expiry_days
    expires_at = datetime.now(timezone.utc) + timedelta(days=days) if days else None

    token = db.create_report_embed_token(
        report_id=report_id,
        created_by=username,
        expires_at=expires_at,
        report_type="business",
    )
    logger.info("Created embed token for business report %d by '%s'", report_id, username)
    return token


@router.get("/api/business-reports/{report_id}/embed-tokens")
async def list_embed_tokens(report_id: int, user: dict = Depends(get_current_user)):
    """List embed tokens for a business report."""
    db = _require_db()
    report = db.get_business_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")
    if report["owner"] != username and role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    return {"tokens": db.list_embed_tokens(report_id, report_type="business")}


@router.delete("/api/business-reports/embed-tokens/{token}")
async def revoke_embed_token(token: str, user: dict = Depends(get_current_user)):
    """Revoke an embed token for a business report."""
    db = _require_db()
    # Verify it's a business report embed token
    tok = db.get_embed_token(token)
    if not tok or tok.get("report_type") != "business":
        raise HTTPException(status_code=404, detail="Token not found")

    if not db.revoke_embed_token(token):
        raise HTTPException(status_code=404, detail="Token not found")

    username = (user or {}).get("username", "admin")
    logger.info("Revoked embed token for business report by '%s'", username)
    return {"detail": "revoked"}


# ── Public Embed Endpoints (NO AUTH) ─────────────────────────────────────────

def _validate_business_embed_token(db, token: str) -> dict:
    """Validate an embed token is active, unexpired, and for a business report."""
    t = db.get_embed_token(token)
    if not t or not t.get("is_active"):
        raise HTTPException(status_code=404, detail="Embed token not found or revoked")
    if t.get("report_type") != "business":
        raise HTTPException(status_code=404, detail="Embed token not found or revoked")
    if t.get("expires_at"):
        expires = t["expires_at"]
        if isinstance(expires, str):
            expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        if hasattr(expires, 'tzinfo') and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(status_code=410, detail="Embed token has expired")
    return t


@router.get("/api/embedded-business-report/{token}")
async def get_embedded_report(token: str):
    """PUBLIC — Return business report metadata for an embed token (no auth)."""
    db = _require_db()
    t = _validate_business_embed_token(db, token)
    report = db.get_business_report(t["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    db.increment_embed_token_access(token)

    report["parameters"] = db.list_report_parameters(t["report_id"])
    return {
        "token": token,
        "report": {
            "id": report["id"],
            "name": report["name"],
            "description": report.get("description"),
            "parameters": report["parameters"],
            "section_definitions": report.get("section_definitions", []),
            "running_calculations": report.get("running_calculations", []),
            "layout_config": report.get("layout_config"),
        },
    }


@router.post("/api/embedded-business-report/{token}/execute")
async def execute_embedded_report(token: str, body: EmbedExecuteRequest):
    """PUBLIC — Execute a business report via embed token (no auth)."""
    db = _require_db()
    fed = _require_federation()
    from core import config as _cfg

    t = _validate_business_embed_token(db, token)
    report = db.get_business_report(t["report_id"])
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Build combined filters
    combined_filters = list(report.get("filter_specs") or [])
    params = db.list_report_parameters(t["report_id"])
    for param in params:
        pname = param["name"]
        pval = body.parameter_values.get(pname)
        if pval is not None and param.get("lov_column_id"):
            if param["parameter_type"] == "multi_select" and isinstance(pval, list):
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "in", "value": pval,
                })
            elif param["parameter_type"] == "date_range" and isinstance(pval, dict):
                if pval.get("from"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "gte", "value": pval["from"],
                    })
                if pval.get("to"):
                    combined_filters.append({
                        "column_id": param["lov_column_id"],
                        "operator": "lte", "value": pval["to"],
                    })
            else:
                combined_filters.append({
                    "column_id": param["lov_column_id"],
                    "operator": "eq", "value": pval,
                })

    # Cap row limit to configured max for embeds
    max_rows = _cfg.report_catalog.embed_max_row_limit
    row_limit = min(body.limit or 1000, max_rows)
    execution_id = str(uuid.uuid4())

    try:
        if report.get("merged_dataset_id") and report.get("merge_config"):
            mc = report["merge_config"]
            result = fed.execute_merged_query(
                primary_dataset_id=report["dataset_id"],
                secondary_dataset_id=report["merged_dataset_id"],
                primary_column_ids=report["column_ids"],
                secondary_column_ids=[],
                merge_keys=mc.get("merge_keys", []),
                merge_type=mc.get("merge_type", "inner"),
                primary_filters=combined_filters,
                limit=row_limit,
                primary_condition_ids=report.get("condition_ids"),
                execution_id=execution_id,
                user_role="viewer",
            )
        else:
            result = fed.execute_dataset_query(
                dataset_id=report["dataset_id"],
                column_ids=report["column_ids"],
                filters=combined_filters if combined_filters else None,
                condition_ids=report.get("condition_ids") or None,
                order_by=report.get("order_by") or None,
                limit=row_limit,
                execution_id=execution_id,
                user_role="viewer",
            )

        return result.to_dict() if hasattr(result, "to_dict") else result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.error("Embedded business report execution failed (token=%s): %s",
                     token[:8], exc)
        raise HTTPException(status_code=500, detail=f"Report execution failed: {exc}")
