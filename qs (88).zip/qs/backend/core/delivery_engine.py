"""
Delivery Engine — Phase 60

Handles subscription-based report delivery:
  - Render report output as PDF/Excel/CSV
  - Email to recipients with attachment
  - Evaluate alert rules post-execution
  - Process pending subscriptions (called by scheduler)

Dependencies injected via init_delivery_engine().
"""
from __future__ import annotations

import io
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from croniter import croniter

from core import config

logger = logging.getLogger(__name__)

# ── Injected dependencies ─────────────────────────────────────────────────────

_db_manager = None
_email_send_fn: Optional[Callable] = None
_report_execute_fn: Optional[Callable] = None       # (report_id, params, username, limit) -> pd.DataFrame
_pdf_render_fn: Optional[Callable] = None            # (df, report_name, params) -> bytes
_webhook_fire_fn: Optional[Callable] = None


def init_delivery_engine(db_manager, email_send_fn, report_execute_fn,
                         pdf_render_fn=None, webhook_fire_fn=None):
    """Wire up dependencies from _startup()."""
    global _db_manager, _email_send_fn, _report_execute_fn, _pdf_render_fn, _webhook_fire_fn
    _db_manager = db_manager
    _email_send_fn = email_send_fn
    _report_execute_fn = report_execute_fn
    _pdf_render_fn = pdf_render_fn
    _webhook_fire_fn = webhook_fire_fn
    logger.info("DeliveryEngine initialised")


# ── Public API ────────────────────────────────────────────────────────────────

def deliver_subscription(sub_id: int) -> Dict[str, Any]:
    """Execute one subscription: run report → render → email to all recipients.

    Returns summary dict with sent/failed counts.
    """
    cfg = config.delivery
    sub = _db_manager.get_subscription(sub_id)
    if not sub:
        return {"error": "Subscription not found"}

    report_id = sub["report_id"]
    report_type = sub["report_type"]
    output_format = sub["output_format"]
    params = sub.get("param_values") or {}
    recipients = sub.get("recipient_emails") or []

    if not recipients:
        return {"error": "No recipients configured"}

    # ── 1. Execute the report ────────────────────────────────────────────
    try:
        df = _report_execute_fn(
            report_id, params, sub["created_by"],
            limit=cfg.max_pdf_rows,
        )
    except Exception as exc:
        logger.error("Subscription %d: report execution failed: %s", sub_id, exc)
        _record_failures(sub_id, recipients, f"Report execution failed: {exc}")
        return {"error": str(exc), "sent": 0, "failed": len(recipients)}

    # ── 2. Render output ─────────────────────────────────────────────────
    try:
        data_bytes, filename, content_type = _render_output(
            df, sub["name"], params, output_format, report_id,
        )
    except Exception as exc:
        logger.error("Subscription %d: render failed: %s", sub_id, exc)
        _record_failures(sub_id, recipients, f"Render failed: {exc}")
        return {"error": str(exc), "sent": 0, "failed": len(recipients)}

    # ── 3. Send to all recipients ────────────────────────────────────────
    sent, failed = _send_to_recipients(sub, data_bytes, filename, content_type)

    # ── 4. Update subscription metadata ──────────────────────────────────
    now = datetime.now(timezone.utc)
    next_at = compute_next_send(sub["frequency"], sub.get("timezone", "UTC"))
    _db_manager.update_subscription(sub_id, last_sent_at=now, next_send_at=next_at, retry_count=0)

    logger.info("Subscription %d delivered: %d sent, %d failed", sub_id, sent, failed)
    return {"sent": sent, "failed": failed, "next_send_at": next_at.isoformat() if next_at else None}


def process_pending_subscriptions() -> Dict[str, Any]:
    """Batch-process all subscriptions whose next_send_at has passed.

    Called periodically by the scheduler system job.
    """
    cfg = config.delivery
    if not cfg.enabled:
        return {"skipped": True, "reason": "delivery disabled"}

    now = datetime.now(timezone.utc)
    pending = _db_manager.get_pending_subscriptions(before=now)
    batch = pending[:cfg.batch_size]

    results = []
    for sub in batch:
        try:
            result = deliver_subscription(sub["id"])
            results.append({"id": sub["id"], **result})
        except Exception as exc:
            logger.error("Subscription %d processing failed: %s", sub["id"], exc, exc_info=True)
            # Increment retry count; deactivate after max retries
            retry = (sub.get("retry_count") or 0) + 1
            updates: Dict[str, Any] = {"retry_count": retry}
            if retry >= cfg.retry_max_attempts:
                updates["is_active"] = False
                logger.warning("Subscription %d deactivated after %d retries", sub["id"], retry)
            _db_manager.update_subscription(sub["id"], **updates)
            results.append({"id": sub["id"], "error": str(exc)})

    logger.info("Processed %d/%d pending subscriptions", len(batch), len(pending))
    return {"processed": len(batch), "total_pending": len(pending), "results": results}


def evaluate_alerts_for_schedule(schedule_id: int, execution_result: Dict[str, Any]) -> List[Dict]:
    """Post-execution: check alert rules for the given schedule's source report.

    Returns list of triggered alerts.
    """
    if not _db_manager:
        return []

    schedule = _db_manager.get_schedule(schedule_id)
    if not schedule or not schedule.get("auto_evaluate_alerts"):
        return []

    report_id = schedule.get("source_id")
    source_type = schedule.get("source_type", "")
    if source_type not in ("report", "business_report"):
        return []

    # Get alert rules for this report
    try:
        rules = [r for r in _db_manager.list_alert_rules(report_id=report_id) if r.get("is_enabled", True)]
    except Exception:
        rules = []

    if not rules:
        return []

    triggered = []
    for rule in rules:
        try:
            col = rule.get("column_name", "")
            agg_fn = rule.get("aggregation", "").upper()
            operator = rule.get("operator", "")
            threshold = float(rule.get("threshold_value", 0))

            # Extract value from execution result summary
            actual = _extract_metric(execution_result, col, agg_fn)
            if actual is None:
                continue

            if _check_condition(actual, operator, threshold):
                triggered.append({
                    "rule_id": rule["id"],
                    "actual_value": actual,
                    "threshold_value": threshold,
                    "column": col,
                    "operator": operator,
                })
                _fire_alert(rule, actual, threshold)

        except Exception as exc:
            logger.warning("Alert rule %s evaluation failed: %s", rule.get("id"), exc)

    return triggered


def compute_next_send(cron_expr: str, tz: str = "UTC") -> Optional[datetime]:
    """Compute the next send time from a cron expression."""
    try:
        from zoneinfo import ZoneInfo
        local_tz = ZoneInfo(tz)
        now_local = datetime.now(timezone.utc).astimezone(local_tz)
        cron = croniter(cron_expr, now_local)
        next_local = cron.get_next(datetime)
        if next_local.tzinfo is None:
            next_local = next_local.replace(tzinfo=local_tz)
        return next_local.astimezone(timezone.utc)
    except Exception as exc:
        logger.warning("Failed to compute next_send for cron='%s' tz='%s': %s", cron_expr, tz, exc)
        return None


# ── Internal helpers ──────────────────────────────────────────────────────────

def _render_output(df, name: str, params: dict, fmt: str,
                   report_id: int) -> Tuple[bytes, str, str]:
    """Render a DataFrame to bytes in the requested format.

    Returns (data_bytes, filename, content_type).
    """
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_name = name.replace(" ", "_").replace("/", "_")[:80]

    if fmt == "pdf":
        if _pdf_render_fn:
            pdf_bytes = _pdf_render_fn(df, name, params, report_id)
        else:
            # Fallback: simple HTML table
            try:
                import weasyprint as _wp
                html = f"<h2>{name}</h2>" + df.head(config.delivery.max_pdf_rows).to_html(index=False)
                pdf_bytes = _wp.HTML(string=html).write_pdf()
            except ImportError:
                raise RuntimeError("WeasyPrint not installed — cannot render PDF")
        return pdf_bytes, f"{safe_name}_{ts}.pdf", "application/pdf"

    elif fmt == "excel":
        buf = io.BytesIO()
        df.to_excel(buf, index=False, engine="openpyxl")
        return buf.getvalue(), f"{safe_name}_{ts}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    else:  # csv
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        return buf.getvalue().encode("utf-8"), f"{safe_name}_{ts}.csv", "text/csv"


def _send_to_recipients(sub: dict, data_bytes: bytes, filename: str,
                        content_type: str) -> Tuple[int, int]:
    """Email the attachment to each recipient, recording delivery records."""
    recipients = sub.get("recipient_emails") or []
    sent_count = 0
    fail_count = 0
    sub_id = sub["id"]

    subject = f"Report Delivery: {sub['name']}"
    html_body = _build_delivery_html(sub, filename)

    for email_addr in recipients:
        try:
            ok = _email_send_fn(
                to_addresses=[email_addr],
                subject=subject,
                html_body=html_body,
                attachments=[(data_bytes, filename, content_type)],
            )
            if ok:
                _db_manager.record_subscription_delivery(
                    subscription_id=sub_id,
                    recipient_email=email_addr,
                    status="sent",
                    sent_at=datetime.now(timezone.utc),
                    file_size_bytes=len(data_bytes),
                )
                sent_count += 1
            else:
                _db_manager.record_subscription_delivery(
                    subscription_id=sub_id,
                    recipient_email=email_addr,
                    status="failed",
                    error_message="Email send returned False",
                )
                fail_count += 1
        except Exception as exc:
            _db_manager.record_subscription_delivery(
                subscription_id=sub_id,
                recipient_email=email_addr,
                status="failed",
                error_message=str(exc)[:500],
            )
            fail_count += 1

    return sent_count, fail_count


def _record_failures(sub_id: int, recipients: list, error: str):
    """Record failure delivery records for all recipients."""
    for email_addr in recipients:
        try:
            _db_manager.record_subscription_delivery(
                subscription_id=sub_id,
                recipient_email=email_addr,
                status="failed",
                error_message=error[:500],
            )
        except Exception:
            pass


def _build_delivery_html(sub: dict, filename: str) -> str:
    """Build the HTML email body for a subscription delivery."""
    return f"""
    <div style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: #1e40af; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
        <h2 style="margin: 0;">QueryStudio Report Delivery</h2>
      </div>
      <div style="background: #f8fafc; padding: 20px; border: 1px solid #e2e8f0;">
        <p>Your scheduled report <strong>{sub['name']}</strong> is attached.</p>
        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
          <tr><td style="padding: 6px 12px; color: #64748b;">Report</td><td style="padding: 6px 12px; font-weight: 600;">{sub['name']}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">Format</td><td style="padding: 6px 12px;">{sub.get('output_format', 'csv').upper()}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">File</td><td style="padding: 6px 12px;">{filename}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">Delivered</td><td style="padding: 6px 12px;">{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}</td></tr>
        </table>
        <p style="font-size: 12px; color: #94a3b8;">
          To unsubscribe, click <a href="{{{{unsubscribe_url}}}}">here</a> or contact your administrator.
        </p>
      </div>
    </div>
    """


def _extract_metric(result: Dict, column: str, agg_fn: str) -> Optional[float]:
    """Extract a metric value from an execution result for alert evaluation."""
    summary = result.get("summary") or result.get("stats") or {}
    if column in summary:
        return float(summary[column])

    # Try to compute from rows
    rows = result.get("rows") or result.get("data") or []
    if not rows or column not in (rows[0] if rows else {}):
        return None

    values = [r[column] for r in rows if r.get(column) is not None]
    if not values:
        return None

    try:
        nums = [float(v) for v in values]
    except (ValueError, TypeError):
        return None

    if agg_fn == "SUM":
        return sum(nums)
    elif agg_fn == "AVG":
        return sum(nums) / len(nums) if nums else None
    elif agg_fn == "MAX":
        return max(nums)
    elif agg_fn == "MIN":
        return min(nums)
    elif agg_fn == "COUNT":
        return float(len(nums))
    return None


def _check_condition(actual: float, operator: str, threshold: float) -> bool:
    """Evaluate an alert condition."""
    if operator == ">":
        return actual > threshold
    elif operator == ">=":
        return actual >= threshold
    elif operator == "<":
        return actual < threshold
    elif operator == "<=":
        return actual <= threshold
    elif operator == "==":
        return actual == threshold
    elif operator == "!=":
        return actual != threshold
    return False


def _fire_alert(rule: dict, actual: float, threshold: float):
    """Send alert notification via configured channels."""
    channels = rule.get("channels") or []
    rule_id = rule.get("id")
    col = rule.get("column_name", "")
    op = rule.get("operator", "")

    msg = f"Alert: {col} {op} {threshold} (actual: {actual:.2f})"

    # Record in alert history
    try:
        _db_manager.record_alert(
            rule_id=rule_id,
            actual_value=actual,
            threshold_value=threshold,
            channel=",".join(channels),
            sent_to=rule.get("recipients", ""),
            suppressed=False,
        )
    except Exception as exc:
        logger.warning("Failed to record alert history: %s", exc)

    # Email
    if "email" in channels and rule.get("recipients"):
        recipients = [r.strip() for r in rule["recipients"].split(",") if r.strip()]
        try:
            from core.email_service import send_email
            send_email(
                to_addresses=recipients,
                subject=f"QueryStudio Alert: {col}",
                html_body=f"<p>{msg}</p><p>Rule ID: {rule_id}</p>",
            )
        except Exception as exc:
            logger.warning("Alert email failed: %s", exc)

    # Webhook
    if "webhook" in channels and rule.get("slack_webhook") and _webhook_fire_fn:
        try:
            _webhook_fire_fn(
                url=rule["slack_webhook"],
                payload={"text": msg, "rule_id": rule_id},
            )
        except Exception as exc:
            logger.warning("Alert webhook failed: %s", exc)
