"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

import json
import time as _time
import uuid
import logging
import traceback
from pathlib import Path
import asyncio
import os
import sys

# Note: faulthandler intentionally NOT enabled.
# DuckDB uses Structured Exception Handlers (SEH) on Windows; faulthandler's
# Vectored Exception Handler intercepts those and causes fatal crashes.
# Python-level crashes are caught by sys.excepthook / threading.excepthook.
# C-level crashes (segfaults) are isolated via subprocess execution (duckdb_subprocess.py).

# ══════════════════════════════════════════════════════════════════════════════
# FIRST: Set up logging + crash handler BEFORE any app imports.
# This ensures every error — including import failures — is captured.
# ══════════════════════════════════════════════════════════════════════════════
def _configure_logging():
    try:
        # Try to read log_format from config — but config may not be loadable yet
        from core.config import server as _srv
        use_json = _srv.log_format == "json"
    except Exception:
        use_json = True  # default to JSON if config not available

    if use_json:
        try:
            from pythonjsonlogger import jsonlogger
            handler = logging.StreamHandler()
            handler.setFormatter(jsonlogger.JsonFormatter(
                fmt="%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)d %(funcName)s",
                rename_fields={
                    "asctime": "timestamp", "levelname": "level", "name": "logger",
                    "pathname": "file", "lineno": "line", "funcName": "func",
                },
            ))
            logging.root.handlers = [handler]
            logging.root.setLevel(logging.INFO)
            return
        except ImportError:
            pass  # fall through to text format
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s [%(pathname)s:%(lineno)d]',
    )

_configure_logging()
logger = logging.getLogger(__name__)

# Global unhandled exception hook — log with full traceback before exit
def _global_exception_hook(exc_type, exc_value, exc_tb):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    logger.critical("Unhandled exception — backend crash", exc_info=(exc_type, exc_value, exc_tb))
    # Also print to stderr as fallback in case logger is broken
    traceback.print_exception(exc_type, exc_value, exc_tb, file=sys.stderr)

sys.excepthook = _global_exception_hook

# Thread exception hook — catches unhandled exceptions in thread-pool threads
def _thread_exception_hook(args):
    logger.critical("Unhandled exception in thread '%s'", args.thread.name if args.thread else "?", exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback, file=sys.stderr)

import threading
threading.excepthook = _thread_exception_hook

# Unraisable exception hook — catches errors Python can't propagate (GC, __del__, etc.)
def _unraisable_hook(unraisable):
    logger.critical("Unraisable exception in %s: %s", unraisable.object, unraisable.exc_value,
                    exc_info=(type(unraisable.exc_value), unraisable.exc_value, unraisable.exc_value.__traceback__) if unraisable.exc_value else True)

sys.unraisablehook = _unraisable_hook

# ══════════════════════════════════════════════════════════════════════════════
# Now safe to import app modules — any error will be logged with full traceback
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# Startup with step-by-step tracing — print() always works, even if logging is broken
# ══════════════════════════════════════════════════════════════════════════════
def _startup_step(label):
    """Print + log a startup step — print goes to stdout even if logger is broken."""
    print(f"[STARTUP] {label}", flush=True)
    logger.info("[STARTUP] %s", label)

try:
    _startup_step("1/12 Importing FastAPI + stdlib...")
    from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends, Header, Body, Query
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.gzip import GZipMiddleware
    from fastapi.responses import FileResponse
    from pydantic import BaseModel, Field
    from typing import List, Dict, Any, Optional, Tuple, Union
    from datetime import datetime, timedelta, timezone
    from concurrent.futures import ThreadPoolExecutor
    from dotenv import load_dotenv

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    _startup_step("2/12 Importing API routers...")
    from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
    from api.sql_query_api import router as sql_router, set_sql_dependencies
    from api.reports_api import router as reports_router, set_report_dependencies, set_reports_auth
    from api.schedules_api import router as schedules_router, set_schedule_dependencies, set_schedules_auth
    from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
    # Phase 23: Enterprise reporting (additive — no existing code modified)
    from api.catalog_api import router as catalog_router, set_catalog_dependencies
    from api.portal_api import router as portal_router, set_portal_dependencies
    from api.enterprise_reports_api import router as enterprise_router, set_enterprise_dependencies
    from api.pdf_export_api import router as pdf_router, set_pdf_dependencies
    from api.burst_api import router as burst_router, set_burst_dependencies
    from api.connection_profiles_api import router as profiles_router, set_profile_dependencies
    from api.workspaces_api import router as workspaces_router, set_workspace_dependencies
    from api.lineage_api import router as lineage_router, set_lineage_dependencies
    from api.embed_api import router as embed_router, set_embed_dependencies
    # Phase 29: Domain routers extracted from main.py
    from api.auth_api import router as auth_router, set_auth_dependencies
    from api.notifications_api import router as notifications_router, set_notification_dependencies
    from api.system_api import router as system_router, set_system_dependencies
    from api.admin_api import router as admin_router, set_admin_dependencies
    from api.connections_api import router as connections_router, set_connection_dependencies
    from api.queries_api import router as queries_router, set_query_dependencies
    from api.materialized_views_api import router as mv_router, set_mv_dependencies
    from api.local_tables_api import router as local_tables_router, set_local_table_dependencies
    import api.materialized_views_api as _mv_api_module
    # Phase 42: Arrow IPC response format
    from api.arrow_api import router as arrow_router, set_arrow_dependencies
    # Phases 46/47/48: Auto-suggest, query analysis, NL-to-SQL
    from api.suggest_api import router as suggest_router, set_suggest_dependencies
    # Phase 53: Semantic Layer — Business Datasets
    from api.datasets_api import router as datasets_router, set_datasets_dependencies
    # Phase 54: Federation Engine
    from api.datasets_api import set_federation_dependencies
    # Phase 56: Business Report Builder
    from api.business_reports_api import router as business_reports_router, set_business_reports_dependencies
    # Phase 60: Subscription/Delivery
    from api.subscription_api import router as subscription_router, set_subscription_dependencies
    # A3: Execute stream router (extracted from main.py)
    from api.execute_stream_api import router as stream_router, set_stream_dependencies
    # A3: Execute API router (extracted from main.py)
    from api.execute_api import router as execute_router, set_execute_dependencies

    # Phase 22F: GraphQL API (optional — requires strawberry-graphql)
    try:
        from api.graphql_api import get_graphql_router, set_graphql_dependencies
        _graphql_available = True
    except ImportError:
        _graphql_available = False

    load_dotenv()

    _startup_step("3/12 Importing parquet_engine_v2...")
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType, AggregationConfig

    _startup_step("4/12 Importing s3_storage...")
    from core.s3_storage import S3Config, build_s3_config, TokenExpiredError

    _startup_step("5/12 Importing database...")
    from core.database import DatabaseManager

    _startup_step("6/12 Importing websocket + connection manager...")
    from core.websocket_manager import WebSocketManager
    from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES

    _startup_step("7/12 Loading config...")
    from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg, limits as _limits_cfg, features as _features_cfg, materialized_views as _mv_cfg, local_tables as _lt_cfg

    _startup_step("8/12 Creating data directories...")
    _paths.data_dir.mkdir(parents=True, exist_ok=True)
    _paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _paths.upload_dir.mkdir(parents=True, exist_ok=True)
    Path(_mv_cfg.storage_dir).mkdir(parents=True, exist_ok=True)
    Path(_lt_cfg.storage_dir).mkdir(parents=True, exist_ok=True)

    _startup_step("9/12 Creating FastAPI app...")
    _DATA_DIR = _paths.data_dir
    _DB_URL   = _db_cfg.db_url

    _startup_step("10/12 Importing slowapi (rate limiter)...")
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded

    _startup_step("11/12 Importing prometheus_client...")
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

    _startup_step("12/12 All imports OK")

except Exception:
    print("[STARTUP] FATAL ERROR during startup:", flush=True)
    traceback.print_exc()
    traceback.print_exc(file=sys.stderr)
    logger.critical("FATAL: Startup failed", exc_info=True)
    sys.exit(1)

import re as _re
import atexit as _atexit

# Register atexit handler — catches silent process exits (e.g. DLL load failure, C-level crash)
def _atexit_handler():
    print("[ATEXIT] Backend process exiting", flush=True)
    try:
        logger.warning("[ATEXIT] Backend process exiting — check above for errors")
    except Exception:
        pass
    # Ensure thread pools don't block process exit
    try:
        query_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
    try:
        _streaming_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
_atexit.register(_atexit_handler)

# ── API versioning (22E) ──────────────────────────────────────────────────────
API_VERSION = "2.0.0"         # Semantic version exposed via header + endpoint
API_MAJOR   = "v2"            # URL prefix used in header (X-API-Version: v2)

# Initialize FastAPI app
app = FastAPI(
    title="QueryStudio API",
    description="Enterprise-grade analytics platform — S3, Iceberg, Snowflake, Trino, Databricks",
    version=API_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "auth",           "description": "Authentication — login, logout, session, OIDC/SAML"},
        {"name": "queries",        "description": "Saved queries, SQL editor, file browser, executions"},
        {"name": "connections",    "description": "Data source connections (S3, Snowflake, Trino, Databricks, Oracle, local)"},
        {"name": "reports",        "description": "Report builder — create, schedule, and share reports"},
        {"name": "dashboards",     "description": "Dashboard builder — compose multi-report dashboards"},
        {"name": "schedules",      "description": "Scheduled query / report execution"},
        {"name": "admin",          "description": "Admin — users, storage, audit log, compliance, cache"},
        {"name": "system",         "description": "Health, metrics, version"},
        {"name": "materialized-views", "description": "Materialized views — cached S3 data in local DuckDB"},
        {"name": "local-tables",   "description": "Local upload tables and table operations"},
        {"name": "lineage",        "description": "Data lineage graph"},
        {"name": "workspaces",     "description": "Workspace isolation (multi-tenant namespacing)"},
        {"name": "notifications",  "description": "In-app notification history"},
        {"name": "embed",          "description": "Embedded report tokens and rendering"},
        {"name": "graphql",        "description": "GraphQL API — Strawberry schema (optional)"},
    ],
)

# GZip compression (~70% payload reduction for JSON responses)
app.add_middleware(GZipMiddleware, minimum_size=1024)

# CORS middleware — origins/methods/headers driven by config.json / env vars
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_cfg.allow_origins,
    allow_credentials=True,
    allow_methods=_cors_cfg.allow_methods,
    allow_headers=_cors_cfg.allow_headers,
)

# Rate limiter setup
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

_prom_requests_total = Counter(
    "http_requests_total", "Total HTTP requests",
    ["method", "path_template", "status"],
)
_prom_request_duration = Histogram(
    "http_request_duration_seconds", "Request latency",
    ["method", "path_template"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30],
)
_prom_pool_active = Gauge("worker_pool_active_tasks", "Active tasks by type", ["work_type"])
_prom_pool_queued = Gauge("worker_pool_queued_tasks", "Queued tasks by type", ["work_type"])
_prom_websockets = Gauge("active_websocket_connections", "Active WebSocket connections")

# ── OpenTelemetry Tracing (21C) — optional, auto-disabled if not installed ──
def _setup_otel():
    """Configure OpenTelemetry if the SDK is installed and an endpoint is configured."""
    try:
        from core.config import server as _srv_cfg
        otel_endpoint = getattr(_srv_cfg, "otel_endpoint", "") or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "")
        if not otel_endpoint:
            return  # No endpoint configured — skip silently

        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

        resource = Resource.create({
            "service.name": os.environ.get("OTEL_SERVICE_NAME", "querystudio"),
            "service.version": "2.0.0",
        })
        provider = TracerProvider(resource=resource)
        exporter = OTLPSpanExporter(endpoint=otel_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor.instrument_app(app, tracer_provider=provider)
        logger.info("OpenTelemetry tracing enabled → %s", otel_endpoint)
    except ImportError:
        logger.debug("OpenTelemetry SDK not installed — tracing disabled")
    except Exception as exc:
        logger.warning("OpenTelemetry setup failed (non-fatal): %s", exc)

_setup_otel()

# Collapse UUIDs / numeric IDs in paths to prevent metric cardinality explosion
_UUID_RE = _re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", _re.I)
_NUMERIC_ID_RE = _re.compile(r"/\d+(?=/|$)")

def _normalize_metric_path(path: str) -> str:
    """Collapse /api/queries/abc-123-... → /api/queries/{id}"""
    path = _UUID_RE.sub("{id}", path)
    path = _NUMERIC_ID_RE.sub("/{id}", path)
    return path


# ── Middleware: security headers + request logging + Prometheus + origin check ─
@app.middleware("http")
async def _enterprise_middleware(request: Request, call_next):
    start = _time.time()
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])

    # ── Origin check (CSRF defense-in-depth) ──
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        origin = request.headers.get("origin") or request.headers.get("referer", "")
        allowed = _cors_cfg.allow_origins
        if allowed != ["*"] and origin:
            from urllib.parse import urlparse
            origin_host = urlparse(origin).netloc
            if origin_host and not any(origin_host in ao for ao in allowed):
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=403, content={"detail": "Origin not allowed"})

    try:
        response = await call_next(request)
    except BaseException as exc:
        # GLOBAL SAFETY NET — no endpoint crash should ever kill the backend.
        # Log the full traceback and return 500 instead of letting it propagate.
        duration_s = _time.time() - start
        logger.critical("Unhandled crash in %s %s: %s", request.method, request.url.path, exc, exc_info=True)
        from starlette.responses import JSONResponse as _JSONResp
        return _JSONResp(status_code=500, content={"detail": f"Internal server error: {type(exc).__name__}"})
    duration_s = _time.time() - start

    # ── Security headers ──
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "connect-src 'self' ws: wss:; "
        "font-src 'self' data:; "
        "object-src 'none'; "
        "frame-ancestors 'self'"
    )
    response.headers["X-Request-ID"] = request_id
    response.headers["X-API-Version"] = API_MAJOR

    # ── Request logging (structured JSON or text) ──
    path = request.url.path
    if path not in ("/health", "/metrics"):  # skip noisy health/metric polls
        logger.info("request", extra={
            "request_id": request_id,
            "method": request.method,
            "path": path,
            "status": response.status_code,
            "duration_ms": round(duration_s * 1000, 1),
            "client": request.client.host if request.client else None,
        })

    # ── Prometheus metrics ──
    path_tmpl = _normalize_metric_path(path)
    _prom_requests_total.labels(
        method=request.method, path_template=path_tmpl, status=response.status_code,
    ).inc()
    _prom_request_duration.labels(
        method=request.method, path_template=path_tmpl,
    ).observe(duration_s)

    return response


# Thread pool for CPU-bound query execution (heavy: COPY TO parquet, etc.)
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)

# Dedicated thread pool for lightweight operations: streaming, schema,
# file listing, metadata.  This is a SEPARATE pool from both query_executor
# and the WorkerPool so heavy background queries can never starve it.
# Sized for I/O-bound work (S3 HTTP calls, parquet footer reads).
_streaming_executor = ThreadPoolExecutor(
    max_workers=min(20, (os.cpu_count() or 4) * 2),
    thread_name_prefix="stream"
)

def _get_light_executor():
    """Return the dedicated streaming/metadata executor.

    Streaming pagination, schema discovery, file listing, metadata reads
    all go through this pool. It is completely isolated from the heavy
    query_executor and the WorkerPool, so it is never blocked by
    long-running background queries.
    """
    return _streaming_executor

# Notification poller asyncio task — set in _startup() when scheduler.mode = "external"
_notification_poller_task = None
# Executor poller asyncio task — set in _startup() when executor.mode = "external"
_executor_poller_task = None
app.include_router(data_grid_router,   tags=["queries"])
app.include_router(sql_router,          tags=["queries"])
app.include_router(catalog_router,      tags=["reports"])  # Must be before reports_router (static paths)
app.include_router(portal_router,      tags=["portal"])
app.include_router(reports_router,      tags=["reports"])
app.include_router(schedules_router,    tags=["schedules"])
app.include_router(dashboards_router,   tags=["dashboards"])
# Phase 23: Enterprise reporting routers (additive)
app.include_router(enterprise_router,   tags=["reports"])
app.include_router(pdf_router,          tags=["reports"])
app.include_router(burst_router,        tags=["reports"])
app.include_router(profiles_router,     tags=["queries"])
app.include_router(workspaces_router,   tags=["workspaces"])
app.include_router(lineage_router,      tags=["lineage"])
app.include_router(embed_router,        tags=["embed"])
# Phase 29: Domain routers
app.include_router(auth_router)
app.include_router(notifications_router)
app.include_router(system_router)
app.include_router(admin_router)
app.include_router(connections_router)
app.include_router(queries_router)
app.include_router(mv_router)
app.include_router(local_tables_router)
# Phase 42: Arrow IPC
app.include_router(arrow_router)
# Phases 46/47/48: Suggest, query analysis, NL-to-SQL
app.include_router(suggest_router, tags=["intelligence"])
# Phase 53: Semantic Layer — Business Datasets
app.include_router(datasets_router, tags=["semantic-layer"])
# Phase 56: Business Report Builder
app.include_router(business_reports_router, tags=["business-reports"])
# Phase 60: Subscription/Delivery
app.include_router(subscription_router, tags=["delivery"])
# A3: Execute stream router
app.include_router(stream_router, tags=["streaming"])
# A3: Execute API router
app.include_router(execute_router, tags=["execution"])

# Phase 22F: GraphQL endpoint (optional — requires strawberry-graphql)
if _graphql_available:
    try:
        _gql_router = get_graphql_router()
        app.include_router(_gql_router, prefix="/graphql", tags=["graphql"])
        logger.info("GraphQL endpoint enabled at /graphql")
    except Exception as _gql_exc:
        logger.debug("GraphQL setup skipped: %s", _gql_exc)

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        auth_mode=os.getenv('S3_AUTH_MODE', 'keys'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        aws_profile=os.getenv('AWS_PROFILE'),
        role_arn=os.getenv('AWS_ROLE_ARN'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL'),
        ssl_verify=os.getenv('S3_SSL_VERIFY', 'true').lower() != 'false',
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# ── Notification logging helper ─────────────────────────────────────────────
def _log_ws_notification(event_type: str, recipient: str, title: str,
                         message: str = "", execution_id: str = None,
                         schedule_id: int = None, payload: dict = None):
    """Persist a WebSocket notification to DB for history / bell icon."""
    try:
        db_manager.log_notification(
            event_type=event_type,
            channel="websocket",
            recipient=recipient,
            status="sent",
            title=title,
            message=message,
            payload=payload,
            execution_id=execution_id,
            schedule_id=schedule_id,
        )
    except Exception as exc:
        logger.debug("Failed to log notification: %s", exc)


# Per-execution cancellation registry (used by shutdown handler)
import threading as _threading
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency + in-flight dedup — moved to api/execute_api.py

# Global concurrency gate — asyncio.Semaphore limits system-wide active queries.
import asyncio as _asyncio
_global_query_sem: _asyncio.Semaphore | None = None   # initialised at startup

def _init_query_semaphore():
    global _global_query_sem
    _global_query_sem = _asyncio.Semaphore(_qe_cfg.max_concurrent_global)

@app.on_event("startup")
async def _startup_init_semaphore():
    _init_query_semaphore()


# ── Active Directory / Auth helpers ───────────────────────────────────────────

from api.models.query_models import LoginRequest as _LoginRequest


# ── Server-side session store (in-memory, TTL-based) ─────────────────────────
# Stores opaque tokens → user info so that AD/LDAP passwords are NEVER persisted
# or sent after the initial login.

# ── Session management — delegates to core/sessions.py (single source of truth) ──
from core.sessions import create_session as _core_create_session
from core.sessions import get_session as _core_get_session
from core.sessions import destroy_session as _core_destroy_session


def _create_session(user_info: dict) -> str:
    """Create a session token and store user info server-side."""
    return _core_create_session(user_info)


def _get_session(token: str) -> Optional[dict]:
    """Look up a session token. Returns user info or None if expired/missing."""
    return _core_get_session(token)


def _destroy_session(token: str):
    """Remove a session token (logout)."""
    _core_destroy_session(token)


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none"  → always returns a guest admin (no login required)
    - "Bearer <session_token>" → look up server-side session (preferred)
    - "Basic <base64>" → authenticate directly (fallback / backward compat)
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True,
                "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Prefer session tokens — no password stored or transmitted after login
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        user = _core_get_session(token)
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Fallback: Basic auth (used by legacy clients / API testing)
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _require_admin(user: dict = Depends(_get_current_user)) -> dict:
    """FastAPI dependency that enforces admin access on admin endpoints."""
    if _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def _require_role(*allowed_roles: str):
    """Factory: returns a FastAPI dependency that checks user role."""
    def dep(user: dict = Depends(_get_current_user)) -> dict:
        if _auth_cfg.type == "none":
            return user  # dev mode — no restriction
        role = (user or {}).get("role", "viewer")
        if role not in allowed_roles:
            raise HTTPException(403, f"Requires role: {', '.join(allowed_roles)}")
        return user
    return dep


def _require_execute_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    x_embed_token: Optional[str] = Header(None),
    _user: Optional[dict] = Depends(_get_current_user),
) -> dict:
    """Dependency for execute_query: allows access via normal auth OR a valid share/embed token.

    Used on /api/queries/execute so that shared-URL pages and embedded report
    pages can execute queries without requiring the viewer to be logged in.
    """
    if _auth_cfg.type == "none":
        return _user or {"username": "guest", "role": "admin", "is_admin": True}
    # Authenticated user with proper role
    if _user and _user.get("role") in ("admin", "analyst"):
        return _user
    # Share-token alternative — lets SharedQueryPage & SharedDashboardPage execute
    if x_share_token:
        try:
            # Check query share token first, then dashboard share token
            share = db_manager.get_share_by_token(x_share_token)
            if not share:
                share = db_manager.get_dashboard_share_by_token(x_share_token)
            if share and share.get("is_active"):
                return {
                    "username": f"shared:{x_share_token[:8]}",
                    "role": "analyst",
                    "is_admin": False,
                }
        except Exception:
            pass
    # Embed-token alternative — lets EmbeddedReportPage execute (Phase 27)
    if x_embed_token and db_manager:
        try:
            from datetime import datetime, timezone as _tz
            t = db_manager.get_embed_token(x_embed_token)
            if t and t.get("is_active"):
                expires = t.get("expires_at")
                if expires:
                    if isinstance(expires, str):
                        expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    if expires.tzinfo is None:
                        expires = expires.replace(tzinfo=_tz.utc)
                    if datetime.now(_tz.utc) <= expires:
                        return {
                            "username": f"embed:{x_embed_token[:8]}",
                            "role": "analyst",
                            "is_admin": False,
                        }
                else:
                    return {
                        "username": f"embed:{x_embed_token[:8]}",
                        "role": "analyst",
                        "is_admin": False,
                    }
        except Exception:
            pass
    raise HTTPException(status_code=403, detail="Authorization header required")


def _is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if the user owns this item or it's marked as shared."""
    if not user or user.get("is_admin"):
        return True  # admins see everything
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )


def _is_container_env() -> bool:
    """Detect if running inside Docker/OpenShift/Kubernetes."""
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


# Pydantic Models — extracted to api/models/query_models.py
from api.models.query_models import (  # noqa: E402
    ALL_CONN_TYPES as _ALL_CONN_TYPES,
    S3ConfigModel, JoinConfigModel, FilterModel, OrderByModel,
    AggregationModel, HavingModel, ComputedColumnModel,
    CaseWhenClauseModel, CaseExpressionModel, WindowFunctionModel,
    QueryConfigModel, SaveQueryRequest, ExecuteQueryRequest,
    ConnectionConfigModel, ConnectionTestRequest,
    StreamQueryRequest, StreamPaginateRequest, StreamSchemaRequest,
    StreamChartRequest, StreamPivotRequest, EstimateRequest,
    PreviewSqlRequest, JoinPreviewRequest,
    BatchQueryItem, BatchSubmitRequest,
    WorkerPoolConfigUpdate, AppConfigUpdateRequest, QueueConfigUpdateRequest,
    CacheInvalidateSourceRequest, RegisteredTableModel,
    MaterializedViewCreateModel, MaterializedViewUpdateModel,
    LocalTableCreateModel, LocalTableUpdateModel, LocalTablePromoteModel,
    UpdateQueryRequest, ShareQueryRequest, ShareDashboardRequest,
    SubjectExportRequest as _SubjectExportRequest,
    UserPayload as _UserPayload,
)

# Helper functions
# build_s3_config is imported from core.s3_storage — single source of truth


# Query conversion — extracted to core/query_converter.py
from core.query_converter import (
    convert_query_config_to_engine,
    translate_join_columns as _translate_join_columns,
    rewrite_registered_refs as _rewrite_registered_refs,
)


# ── Iceberg / schema / partition caches — extracted to core/iceberg_cache.py ──
from core.iceberg_cache import (
    ICE_FILE_CACHE as _ICE_FILE_CACHE,
    ICE_FILE_CACHE_TTL as _ICE_FILE_CACHE_TTL,
    ice_cache_key as _ice_cache_key,
    ice_cache_get as _ice_cache_get,
    ice_cache_set as _ice_cache_set,
    schema_cache_get as _schema_cache_get,
    schema_cache_set as _schema_cache_set,
    partition_l1_get as _partition_l1_get,
    partition_l1_set as _partition_l1_set,
    partition_l2_get as _partition_l2_get,
    partition_store as _partition_store,
    init_iceberg_cache,
)


# ── DuckDB views — extracted to core/duckdb_views.py ─────────────────────────
from core.duckdb_views import (
    SQLCollector as _SQLCollector,
    setup_registered_views as _setup_registered_views,
    execute_registered_table_query as _execute_registered_table_query,
    execute_registered_table_copy_to as _execute_registered_table_copy_to,
    s3_full_copy as _s3_full_copy,
    join_inflight_query as _join_inflight_query,
    run_base_data_local_query as _run_base_data_local_query,
    init_duckdb_views,
)



# ── Old function bodies removed — now in core/duckdb_views.py ─────────────

# ── Execute background workers + endpoints — extracted to api/execute_api.py ──
# _run_query_and_signal, execute_query_background, execute_sql_connector_background,
# execute_cross_query_background, _audit, estimate_query, execute_query
# ── SPA static file serving ───────────────────────────────────────────────────
_STATIC_CANDIDATES = [
    Path(__file__).resolve().parent / "static",          # Docker / production
    Path(__file__).resolve().parent.parent / "frontend" / "build",  # local dev
    Path(__file__).resolve().parent.parent / "frontend" / "dist",   # legacy Vite
]
_STATIC_DIR: Optional[Path] = next((p for p in _STATIC_CANDIDATES if p.is_dir()), None)

if _STATIC_DIR:
    from fastapi.staticfiles import StaticFiles
    # Mount /assets (hashed JS/CSS bundles) — short cache for CDN
    _assets = _STATIC_DIR / "assets"
    if _assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")
    logger.info("Serving built frontend from %s", _STATIC_DIR)
else:
    logger.info("No built frontend found — API-only mode")


def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest: oldest = mt
                    if newest is None or mt > newest: newest = mt
                except OSError as exc:
                    logger.debug("Recoverable error: %s", exc, exc_info=True)
    return {
        "path": str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb": round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


def _oldest_age_secs(tasks: list) -> float:
    """Return age in seconds of oldest task by created_at."""
    from datetime import datetime, timezone
    oldest = None
    for t in tasks:
        ca = t.get("created_at")
        if not ca:
            continue
        try:
            dt = datetime.fromisoformat(ca)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if oldest is None or dt < oldest:
                oldest = dt
        except Exception:
            pass
    if oldest is None:
        return 0.0
    now = datetime.now(timezone.utc)
    return (now - oldest).total_seconds()



# ── Batch Submit API (19H) ────────────────────────────────────────────────────

async def _scheduler_worker_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Proxy a request to the scheduler worker's internal HTTP API.

    Used when ``scheduler.mode = "external"`` — the scheduler runs in a
    separate process (``scheduler_worker.py``) and exposes a small FastAPI
    control API on ``scheduler.worker_host:scheduler.worker_port``.
    """
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")

_MAX_UPLOAD_SIZE = _limits_cfg.max_upload_size_bytes  # configurable via admin
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}


def _conn_upload_dir(connection_id: int) -> Path:
    """Get the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── S3 utilities — extracted to core/s3_utilities.py ─────────────────────────
from core.s3_utilities import (
    extract_hive_parts as _extract_hive_parts,
    filter_iceberg_files_by_partitions as _filter_iceberg_files_by_partitions,
    extract_partition_filters_from_query as _extract_partition_filters_from_query,
    list_s3_parquet_files as _list_s3_parquet_files,
    s3_urls_to_presigned as _s3_urls_to_presigned,
    make_s3_client_for_conn as _make_s3_client_for_conn,
    init_s3_utilities,
)


# ── register_s3_views — extracted to core/duckdb_views.py ─────────────────────
from core.duckdb_views import register_s3_views as _register_s3_views


# ─────────────────────────────────────────────────────────────────────────────
# Error detection — extracted to core/error_detection.py
# ─────────────────────────────────────────────────────────────────────────────
from core.error_detection import (
    jsonify_value as _jsonify_value,
    jsonify_rows as _jsonify_rows,
    is_s3_auth_error as _is_s3_auth_error,
    raise_if_s3_auth_error as _raise_if_s3_auth_error,
    is_connection_error as _is_connection_error,
    CONN_ERROR_PATTERNS as _CONN_ERROR_PATTERNS,
)

# Streaming endpoints extracted to api/execute_stream_api.py (A3 refactoring)
# _fix_stale_excludes → api/execute_stream_api.py
# _strip_sql_limit → core/query_converter.py as strip_sql_limit




# estimate_query + execute_query endpoints → api/execute_api.py

def _update_config_users(username: str, password: Optional[str], role: Optional[str], action: str):
    """Persist user change to config.json and reload config in-memory.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    import json as _json
    config_file = Path(__file__).resolve().parent / "config.json"
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = _json.load(f)

    auth_section = cfg.setdefault("auth", {})

    # Parse current local_users and user_roles
    raw_users = auth_section.get("local_users", "")
    users_dict = {}
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            users_dict[u.strip()] = p.strip()

    raw_roles = auth_section.get("user_roles", "")
    roles_dict = {}
    for pair in raw_roles.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, r = pair.split(":", 1)
            roles_dict[u.strip().lower()] = r.strip().lower()

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    auth_section["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
    auth_section["user_roles"] = ",".join(f"{u}:{r}" for u, r in roles_dict.items())

    with open(config_file, "w", encoding="utf-8") as f:
        _json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Reload in-memory config
    from core import config as _config_mod
    _config_mod.reload()
    logger.info("Config reloaded after user %s: %s", action, username)




# ── Registered Tables (Enterprise S3 Table Registry) ─────────────────────

def _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix):
    """Fetch schema from S3 — Iceberg reads metadata JSON, Parquet/CSV uses DuckDB DESCRIBE."""
    logger.info("Loading schema from S3 for table '%s' (format=%s)", table_name, fmt)
    if fmt == "iceberg":
        from core.iceberg_reader import _latest_metadata_key, _read_s3_json
        s3 = _make_s3_client_for_conn(conn_raw)
        meta_prefix = table_def["s3_prefix"].rstrip("/") + "/metadata/"
        try:
            meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
            metadata = _read_s3_json(s3, bucket, meta_key)
        except Exception as e:
            logger.error("Failed to read Iceberg metadata for %s: %s", table_name, e, exc_info=True)
            raise ValueError(f"Cannot read Iceberg metadata: {e}")

        # Extract schema from metadata JSON
        schemas_list = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
        current_schema_id = metadata.get("current-schema-id", 0)
        schema_obj = next((s for s in schemas_list if s.get("schema-id") == current_schema_id), schemas_list[0] if schemas_list else {})
        columns = []
        for field in schema_obj.get("fields", []):
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                ftype = ftype.get("type", "struct")
            columns.append({
                "name": field.get("name", ""),
                "type": str(ftype),
                "nullable": not field.get("required", False),
                "field_id": field.get("id") or field.get("field-id"),
            })

        # Extract partition spec
        specs = metadata.get("partition-specs") or ([metadata["partition-spec"]] if "partition-spec" in metadata else [])
        default_spec_id = metadata.get("default-spec-id", 0)
        active_spec = next((s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {})
        field_names = {f.get("id") or f.get("field-id"): f.get("name", "") for f in schema_obj.get("fields", [])}
        partition_spec = []
        for pf in active_spec.get("fields", []):
            src_id = pf.get("source-id") or pf.get("source_id")
            partition_spec.append({
                "name": pf.get("name", ""),
                "transform": pf.get("transform", "identity"),
                "source_column": field_names.get(src_id, str(src_id)),
            })

        # Snapshot info
        current_snap_id = metadata.get("current-snapshot-id")
        snapshots = metadata.get("snapshots", [])
        snap = next((s for s in snapshots if s.get("snapshot-id") == current_snap_id), None) if current_snap_id else None

        summary = snap.get("summary", {}) if snap else {}
        data_file_count = int(summary.get("total-data-files", 0))
        total_records = int(summary.get("total-records", 0))

        return {
            "table_name": table_name,
            "format": "iceberg",
            "s3_prefix": table_def["s3_prefix"],
            "columns": columns,
            "num_rows": total_records,
            "data_file_count": data_file_count,
            "partition_spec": partition_spec,
            "snapshot_id": current_snap_id,
            "format_version": metadata.get("format-version", 1),
        }
    else:
        # Parquet or CSV — use DuckDB DESCRIBE
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(config, connection_id=connection_id)
        try:
            if fmt == "csv":
                _is_onprem_csv = config.get("path_style", False)
                if _is_onprem_csv:
                    # On-prem S3: glob crashes DuckDB — pre-list + pre-sign CSV files
                    from core.s3_utilities import list_s3_csv_files as _list_csv_main
                    _csv_s3 = _make_s3_client_for_conn({"id": connection_id, "config": config})
                    _csv_files = _list_csv_main(_csv_s3, bucket, prefix)
                    if not _csv_files:
                        raise ValueError(f"No CSV files found under s3://{bucket}/{prefix}")
                    _csv_files = _s3_urls_to_presigned(_csv_s3, _csv_files[:5], config)
                    _esc_csv = lambda v: v.replace("'", "''")
                    _csv_paths = ", ".join(f"'{_esc_csv(f)}'" for f in _csv_files)
                    src = f"read_csv_auto([{_csv_paths}])"
                else:
                    src = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
            else:
                # Pre-list files via boto3 (robust) instead of DuckDB glob
                _esc_pq = lambda v: v.replace("'", "''")
                try:
                    _pq_s3 = _make_s3_client_for_conn({"id": connection_id, "config": config})
                    _pq_files = _list_s3_parquet_files(_pq_s3, bucket, prefix)
                    # On-prem S3: pre-sign to avoid DuckDB '=' URL-encoding issue
                    _pq_files = _s3_urls_to_presigned(_pq_s3, _pq_files, config)
                except Exception as _pq_list_err:
                    _pq_files = []
                    if config.get("path_style", False):
                        raise RuntimeError(
                            f"Failed to list parquet files for '{table_name}' on on-prem S3: {_pq_list_err}. "
                            f"Check S3 prefix, credentials, and endpoint URL."
                        ) from _pq_list_err
                if _pq_files:
                    _pq_paths = ", ".join(f"'{_esc_pq(f)}'" for f in _pq_files)
                    src = f"read_parquet([{_pq_paths}], hive_partitioning=true, union_by_name=true)"
                else:
                    if config.get("path_style", False):
                        raise RuntimeError(
                            f"No parquet files found for '{table_name}' on on-prem S3 under s3://{bucket}/{prefix}/. "
                            f"Check that the S3 prefix is correct and contains .parquet files."
                        )
                    src = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
            cols_raw = con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()
            # Row count: use file count as estimate for pre-listed files to avoid full scan
            row_count = 0
            try:
                row_count = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
            except Exception:
                row_count = len(_pq_files) if fmt != "csv" and _pq_files else 0
            return {
                "table_name": table_name,
                "format": fmt,
                "s3_prefix": table_def["s3_prefix"],
                "columns": [
                    {"name": c[0], "type": c[1], "nullable": True}
                    for c in cols_raw
                ],
                "num_rows": row_count,
            }
        finally:
            con.close()


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    # Initialise extracted modules with shared dependencies
    init_iceberg_cache(db_manager)
    init_s3_utilities(conn_manager)
    # Phase 29: initialise unified auth dependency (api/deps.py)
    from api.deps import init_deps as _init_deps
    _init_deps(_auth_cfg, db_manager)
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=_auth_cfg)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_reports_auth(_auth_cfg)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_schedules_auth(_auth_cfg)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Phase 23: Enterprise reporting wiring
    try:
        from core.email_service import EmailService as _EmailSvc
        _esvc = _EmailSvc()
    except Exception:
        _esvc = None

    set_catalog_dependencies(db_manager, _auth_cfg)
    set_portal_dependencies(db_manager, _auth_cfg)
    set_enterprise_dependencies(db_manager, _auth_cfg, email_service=_esvc)

    # PDF export: provide a sync execute function from reports_api
    def _pdf_execute_fn(report_id, param_values, username, limit=10000):
        from api.reports_api import _execute_report_sync
        return _execute_report_sync(report_id, param_values, username, limit=limit)

    set_pdf_dependencies(db_manager, _auth_cfg, _pdf_execute_fn)
    set_burst_dependencies(db_manager, _auth_cfg, _pdf_execute_fn, email_service=_esvc)
    set_profile_dependencies(db_manager, _auth_cfg)
    set_workspace_dependencies(db_manager, _auth_cfg)
    db_manager.ensure_default_workspace()
    set_lineage_dependencies(db_manager)
    set_embed_dependencies(db_manager, _auth_cfg)
    set_suggest_dependencies(db_manager)
    set_datasets_dependencies(db_manager)
    # Phase 54: Federation Engine
    from core.federation_engine import FederationEngine as _FedEngine
    from core import config as _fed_cfg_ref
    _federation_engine = _FedEngine(db_manager, output_dir=str(_paths.downloads_dir))
    set_federation_dependencies(_federation_engine)

    # Phase 55: Aggregation Cache
    try:
        from core.agg_cache import init_agg_cache, register_scheduled_refreshes
        _agg_cache_dir = str(_paths.data_dir / "agg_cache") if hasattr(_paths, "data_dir") else "data/agg_cache"
        init_agg_cache(db_manager, _federation_engine, _agg_cache_dir,
                       enabled=_fed_cfg_ref.agg_cache.enabled)
        from core.scheduler import _scheduler as _agg_sched
        if _agg_sched:
            _n_agg_jobs = register_scheduled_refreshes(_agg_sched)
            if _n_agg_jobs:
                logger.info("Registered %d agg cache refresh jobs", _n_agg_jobs)
    except Exception as _agg_init_err:
        logger.warning("Agg cache init skipped: %s", _agg_init_err)

    # Phase 56: Business Report Builder
    set_business_reports_dependencies(db_manager, _federation_engine)

    # Phase 60: Subscription/Delivery
    set_subscription_dependencies(db_manager)
    try:
        from core.delivery_engine import init_delivery_engine
        from core.email_service import send_email_with_attachment as _email_attach_fn
        init_delivery_engine(
            db_manager=db_manager,
            email_send_fn=_email_attach_fn,
            report_execute_fn=_pdf_execute_fn,
            pdf_render_fn=None,        # uses built-in WeasyPrint fallback
            webhook_fire_fn=None,      # added lazily via webhook_service
        )
        try:
            from core.webhook_service import fire_webhook as _wh_fire
            from core import delivery_engine as _de_mod
            _de_mod._webhook_fire_fn = _wh_fire
        except ImportError:
            pass
        logger.info("Phase 60 delivery engine initialised")
    except Exception as _del_err:
        logger.warning("Delivery engine init skipped: %s", _del_err)

    # A2: Initialise extracted modules
    init_duckdb_views(db_manager, _paths, ws_manager, _mv_cfg, _lt_cfg, _limits_cfg)
    from core.mv_manager import init_mv_manager
    init_mv_manager(db_manager, ws_manager, _mv_cfg, _lt_cfg)

    # A3: Execute stream router
    set_stream_dependencies(db_manager, _paths, _qe_cfg, _limits_cfg,
                            register_s3_views_fn=_register_s3_views,
                            get_light_executor_fn=_get_light_executor)

    # A3: Execute API router (background workers + /api/execute endpoints)
    set_execute_dependencies(db_manager, ws_manager, engine, _paths, _qe_cfg,
                             _limits_cfg, s3_config, query_executor,
                             _get_light_executor)

    # Phase 29: wire domain routers
    from core.execution_state import set_global_sem as _set_sem
    _set_sem(_global_query_sem)
    set_auth_dependencies(limiter, _auth_cfg)
    set_notification_dependencies(db_manager)
    set_system_dependencies(db_manager, engine, _paths, _qe_cfg,
                             prom_pool_active=_prom_pool_active,
                             prom_pool_queued=_prom_pool_queued)
    set_admin_dependencies(db_manager, engine, _paths, _qe_cfg, _auth_cfg, ws_manager)
    set_connection_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg, _lt_cfg)
    set_query_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg,
                           _qe_cfg, _limits_cfg, _features_cfg, ws_manager=ws_manager)
    set_mv_dependencies(db_manager, engine, conn_manager, ws_manager, _mv_cfg)
    set_local_table_dependencies(db_manager, engine, ws_manager, _lt_cfg, _mv_cfg, _paths,
                                  light_executor=_get_light_executor())
    # Provide the _register_s3_views function to mv_router (defined at module level below)
    _mv_api_module._register_s3_views = _register_s3_views

    # Phase 42: Arrow IPC
    set_arrow_dependencies(db_manager, _auth_cfg)

    # Phase 22F: Wire GraphQL dependencies
    if _graphql_available:
        try:
            set_graphql_dependencies(db_manager, _auth_cfg)
            # Inject execute callback so GraphQL mutations can submit queries
            from api.graphql_api import set_execute_callback as _set_gql_exec
            from core.config import server as _srv_cfg
            _gql_port = getattr(_srv_cfg, "port", 8000)

            async def _gql_execute_fn(sql: str, connection_id: int,
                                       limit: int = 1000, executed_by: str = "graphql") -> str:
                """Submit a SQL query via the internal REST execute endpoint."""
                try:
                    import httpx as _httpx
                except ImportError:
                    raise RuntimeError("httpx not installed — run: pip install httpx")
                payload = {
                    "query_type": "sql_query",
                    "connection_id": connection_id,
                    "raw_sql": sql,
                    "limit": limit,
                    "executed_by": executed_by,
                    "cache_strategy": "disabled",
                }
                async with _httpx.AsyncClient(timeout=10.0) as _cli:
                    resp = await _cli.post(
                        f"http://localhost:{_gql_port}/api/queries/execute",
                        json=payload,
                    )
                data = resp.json()
                eid = data.get("execution_id") or data.get("id")
                if not eid:
                    raise RuntimeError(f"Execute failed: {data.get('detail', resp.text[:200])}")
                return eid
            _set_gql_exec(_gql_execute_fn)
        except Exception as _gql_exc:
            logger.debug("GraphQL dependency wiring skipped: %s", _gql_exc)

    # Initialise unified worker pool
    from core.config import worker_pool as _wp_cfg
    from core.worker_pool import init_pool
    init_pool(
        total_workers=_wp_cfg.total_workers,
        type_configs=_wp_cfg.build_type_configs(),
        drain_timeout=_wp_cfg.drain_timeout_seconds,
    )

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # ── Circuit breaker initialisation ───────────────────────────────────
    from core.circuit_breaker import init_circuit_breaker, set_broadcast_fn as cb_set_broadcast
    from core.config import circuit_breaker as _cb_cfg
    init_circuit_breaker(
        enabled=_cb_cfg.enabled,
        failure_threshold=_cb_cfg.failure_threshold,
        cooldown_seconds=_cb_cfg.cooldown_seconds,
    )

    def _cb_ws_broadcast(payload):
        """Sync broadcast helper for circuit breaker (called from thread-locked code)."""
        asyncio.run_coroutine_threadsafe(ws_manager.broadcast(payload), loop)

    cb_set_broadcast(_cb_ws_broadcast)

    # ── Anomaly detection initialisation (Phase 38) ──────────────────────
    from core.anomaly_detector import init_anomaly_detector
    from core.config import anomaly_detection as _anom_cfg
    init_anomaly_detector(
        enabled=_anom_cfg.enabled,
        z_score_threshold=_anom_cfg.z_score_threshold,
        min_history_runs=_anom_cfg.min_history_runs,
        window_size=_anom_cfg.window_size,
    )

    # ── Connection pool initialisation (Phase 40) ─────────────────────────
    from core.connection_pool import init_connection_pool
    from core.config import connection_pool as _pool_cfg
    init_connection_pool(
        enabled=_pool_cfg.enabled,
        max_size=_pool_cfg.max_size,
        idle_timeout_seconds=_pool_cfg.idle_timeout_seconds,
    )

    # ── Checkpoint recovery (Phase 41) ────────────────────────────────────
    from core.checkpoint import init_checkpoint, recover_incomplete
    init_checkpoint(db_manager)
    _recovered = recover_incomplete()
    if _recovered:
        logger.info("Checkpoint: recovered %d orphaned executions", _recovered)

    # ── Queue backend initialisation ─────────────────────────────────────
    from core.queue_backend import init_queue_backend
    init_queue_backend(db_manager)
    logger.info("Queue backend initialised")

    # ── Scheduler initialisation (mode-dependent) ──────────────────────────
    from core.config import scheduler as _sched_cfg
    import threading as _threading

    if _sched_cfg.mode == "external":
        # External mode: scheduler runs in scheduler_worker.py.
        # Start a notification poller/subscriber to relay WS notifications.
        from core.config import queue as _queue_cfg
        global _notification_poller_task
        if _queue_cfg.backend == "redis":
            from core.notification_poller import run_notification_subscriber
            from core.queue_backend import get_notification_queue
            _notification_poller_task = asyncio.create_task(
                run_notification_subscriber(get_notification_queue(), ws_manager)
            )
            logger.info("Scheduler mode=external — notification subscriber started (Redis pub/sub)")
        else:
            from core.notification_poller import run_notification_poller
            _notification_poller_task = asyncio.create_task(
                run_notification_poller(
                    db_manager.SessionLocal,
                    ws_manager,
                    interval=_sched_cfg.notification_poll_interval,
                )
            )
            logger.info("Scheduler mode=external — notification poller started (%.1fs interval)",
                         _sched_cfg.notification_poll_interval)
    else:
        # Embedded mode (default): start APScheduler in-process, same as before.
        from core.scheduler import init_scheduler, set_broadcast_fn

        def _ws_broadcast(payload):
            asyncio.run_coroutine_threadsafe(ws_manager.broadcast(payload), loop)

        set_broadcast_fn(_ws_broadcast)

        def _start_scheduler():
            try:
                init_scheduler(db_manager, db_url=_DB_URL)
            except Exception as exc:
                logger.error("APScheduler startup failed (non-fatal): %s", exc, exc_info=True)

        _threading.Thread(target=_start_scheduler, daemon=True).start()

    # ── Executor poller (external mode only) ──────────────────────────────
    from core.config import executor as _exec_cfg
    if _exec_cfg.mode == "external":
        from core.config import queue as _queue_cfg2
        global _executor_poller_task
        if _queue_cfg2.backend == "redis":
            from core.executor_poller import run_executor_subscriber
            from core.queue_backend import get_task_queue
            _executor_poller_task = asyncio.create_task(
                run_executor_subscriber(get_task_queue(), ws_manager)
            )
            logger.info("Executor mode=external — subscriber started (Redis pub/sub)")
        else:
            from core.executor_poller import run_executor_poller
            _executor_poller_task = asyncio.create_task(
                run_executor_poller(db_manager, ws_manager, _exec_cfg.notification_poll_interval)
            )
            logger.info("Executor mode=external — poller started (%.1fs interval)",
                         _exec_cfg.notification_poll_interval)

    # ── WebSocket heartbeat (detect dead connections) ─────────────────────
    await ws_manager.start_heartbeat(interval=30)
    logger.info("WebSocket heartbeat started (30s interval)")

    # Mark any executions stuck in "running" state as failed.
    # These are orphaned by a previous server crash or forced restart.
    try:
        stuck = db_manager.list_executions(status="running", limit=1000, offset=0)
        for ex in stuck:
            db_manager.update_execution(
                ex["execution_id"],
                status="failed",
                error_message="Server restarted while execution was in progress",
            )
        if stuck:
            logger.warning(
                "Startup: marked %d orphaned 'running' execution(s) as failed", len(stuck)
            )
    except Exception as _e:
        logger.warning("Startup: orphan execution cleanup failed: %s", _e)

    # Auto-migrate plain-text passwords → PBKDF2 hashes
    if _auth_cfg.type == "local":
        _migrate_plaintext_passwords()


def _migrate_plaintext_passwords():
    """One-time migration: hash any plain-text passwords found in config.json."""
    import json as _json
    from core.ad_auth import hash_password as _hash_pw, _PBKDF2_PREFIX

    config_file = Path(__file__).resolve().parent / "config.json"
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = _json.load(f)
    except Exception:
        return

    raw_users = cfg.get("auth", {}).get("local_users", "")
    if not raw_users:
        return

    users_dict = {}
    migrated_count = 0
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            u, p = u.strip(), p.strip()
            if not p.startswith(_PBKDF2_PREFIX):
                users_dict[u] = _hash_pw(p)
                migrated_count += 1
            else:
                users_dict[u] = p

    if migrated_count > 0:
        cfg["auth"]["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
        with open(config_file, "w", encoding="utf-8") as f:
            _json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Reload in-memory config
        from core import config as _config_mod
        _config_mod._file_cfg = _config_mod._load_file()
        _config_mod._merged = _config_mod._deep_merge(_config_mod._DEFAULTS, _config_mod._file_cfg)
        _config_mod._cfg = _config_mod._apply_env(_config_mod._merged)
        logger.info("Migrated %d plain-text password(s) to PBKDF2 hashes", migrated_count)


@app.on_event("shutdown")
async def _shutdown():
    logger.info("Shutdown: draining %d in-flight queries (5 s grace)…", len(_running_tasks))
    # Signal all threads to stop at next chunk boundary
    for _ev in list(_cancellation_flags.values()):
        _ev.set()
    # Cancel all asyncio tasks
    _pending = [t for t in _running_tasks.values() if not t.done()]
    for t in _pending:
        t.cancel()
    if _pending:
        await asyncio.gather(*_pending, return_exceptions=True)

    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "embedded":
        from core.scheduler import shutdown_scheduler
        shutdown_scheduler()
    else:
        # External mode — cancel the notification poller task
        if _notification_poller_task and not _notification_poller_task.done():
            _notification_poller_task.cancel()

    # Cancel executor poller if running (external mode)
    if _executor_poller_task and not _executor_poller_task.done():
        _executor_poller_task.cancel()

    # Stop WebSocket heartbeat
    await ws_manager.stop_heartbeat()

    # Don't wait=True — it blocks forever if threads hold locks
    query_executor.shutdown(wait=False, cancel_futures=True)
    _streaming_executor.shutdown(wait=False, cancel_futures=True)

    # Shut down the unified worker pool
    from core.worker_pool import get_pool
    try:
        await get_pool().shutdown()
    except RuntimeError:
        pass  # pool not initialised (tests, etc.)


# ── Forced exit on Ctrl+C ──────────────────────────────────────────────────
# On Windows, uvicorn sometimes can't cleanly terminate threads (DuckDB
# connections, APScheduler, etc.). After the first SIGINT the graceful
# shutdown runs; a second SIGINT (or 5 s timeout) force-kills the process.
import signal as _signal

_SIGINT_COUNT = 0

def _force_exit_handler(signum, frame):
    global _SIGINT_COUNT
    _SIGINT_COUNT += 1
    if _SIGINT_COUNT == 1:
        print("\n[SHUTDOWN] Ctrl+C — stopping server…", flush=True)
        # Give uvicorn 3 seconds to drain, then force-exit cleanly.
        # Don't raise KeyboardInterrupt — it causes noisy asyncio tracebacks.
        def _delayed_exit():
            import time; time.sleep(3)
            print("[SHUTDOWN] Done.", flush=True)
            os._exit(0)
        _threading.Thread(target=_delayed_exit, daemon=True).start()
    else:
        print("[SHUTDOWN] Force exit!", flush=True)
        os._exit(1)

if sys.platform == "win32":
    _signal.signal(_signal.SIGINT, _force_exit_handler)
    try:
        _signal.signal(_signal.SIGBREAK, _force_exit_handler)
    except (AttributeError, OSError):
        pass
else:
    # Linux/Docker: handle SIGTERM (sent by `docker stop`, k8s pod termination)
    _signal.signal(_signal.SIGINT, _force_exit_handler)
    _signal.signal(_signal.SIGTERM, _force_exit_handler)


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        logger.warning("WebSocket connection closed unexpectedly: %s", e)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    await _handle_ws(websocket)


# ── Materialized Views — extracted to core/mv_manager.py ──────────────────────
from core.mv_manager import (
    refresh_materialized_view_sync as _refresh_materialized_view_sync,
    setup_mv_schedule as _setup_mv_schedule,
    remove_mv_schedule as _remove_mv_schedule,
    promote_download_sync as _promote_download_sync,
    upload_file_to_local_table_sync as _upload_file_to_local_table_sync,
    cleanup_expired_local_tables as _cleanup_expired_local_tables,
    resolve_table_duckdb_sql as _resolve_table_duckdb_sql,
)
if _STATIC_DIR:
    @app.get("/", include_in_schema=False)
    async def _spa_root():
        return FileResponse(str(_STATIC_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def _spa_catch_all(full_path: str):
        return FileResponse(str(_STATIC_DIR / "index.html"))
else:
    @app.get("/")
    async def _api_root():
        return {
            "name": "QueryStudio API",
            "version": API_VERSION,
            "api_version": API_MAJOR,
            "status": "operational",
            "note": "Build the frontend (`npm run build` in frontend/) to enable SPA serving.",
        }


def run_server(host=None, port=None, workers=None, log_level=None):
    """Start the FastAPI webserver.  Called by ``querystudio`` CLI."""
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    uvicorn.run(
        app,
        host=host or _server_cfg.host,
        port=port or _server_cfg.port,
        log_level=log_level or _server_cfg.log_level,
        workers=workers or _server_cfg.workers,
    )


if __name__ == "__main__":
    run_server()
