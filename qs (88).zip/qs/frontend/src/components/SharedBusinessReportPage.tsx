/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-nocheck
/**
 * SharedBusinessReportPage — Public share-link page for business reports (no auth required).
 *
 * Route: /shared-business-report/:token
 *
 * Features:
 *  - Report info card (name, description)
 *  - Parameter prompt (if report has parameters)
 *  - Execute via public endpoint
 *  - Results table with pagination
 *  - Export CSV
 */
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { getUserFriendlyError } from '../utils/errorMessages';
import { useParams } from 'react-router-dom';
import {
  Alert, Box, Button, CircularProgress, Divider, IconButton,
  InputAdornment, Paper, TableContainer, Table, TableHead,
  TableRow, TableCell, TableBody, TablePagination, TextField,
  Typography,
} from '@mui/material';
import {
  BoltOutlined as BoltIcon,
  ContentCopy as CopyIcon,
  Download as DownloadIcon,
  LinkOff as LinkOffIcon,
  PlayArrow as RunIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import api from '../services/api';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100, 250];

function exportCsv(columns: string[], rows: any[][], filename: string) {
  const header = columns.join(',');
  const body = rows.map(r =>
    r.map(v => {
      const s = v === null || v === undefined ? '' : String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n')
        ? `"${s.replace(/"/g, '""')}"` : s;
    }).join(',')
  ).join('\n');
  const blob = new Blob([header + '\n' + body], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

export default function SharedBusinessReportPage() {
  const { token } = useParams<{ token: string }>();

  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Execution
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [execError, setExecError] = useState('');

  // Parameter values
  const [paramValues, setParamValues] = useState<Record<string, any>>({});

  // Table
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [searchQ, setSearchQ] = useState('');
  const [copied, setCopied] = useState(false);

  // Load report metadata
  useEffect(() => {
    if (!token) return;
    (async () => {
      setLoading(true);
      try {
        const res = await api.getSharedBusinessReport(token);
        setReport(res.report);
        // Set default param values
        const defaults: Record<string, any> = {};
        (res.report.parameters || []).forEach((p: any) => {
          if (p.default_value != null) defaults[p.name] = p.default_value;
        });
        setParamValues(defaults);
      } catch (e: any) {
        setError(getUserFriendlyError(e, 'Share link not found or expired'));
      } finally { setLoading(false); }
    })();
  }, [token]);

  const handleExecute = useCallback(async () => {
    if (!token) return;
    setExecuting(true);
    setExecError('');
    try {
      const res = await api.executeSharedBusinessReport(token, {
        parameter_values: paramValues,
      });
      setResult(res);
      setPage(0);
    } catch (e: any) {
      setExecError(getUserFriendlyError(e, 'Execution failed'));
    } finally { setExecuting(false); }
  }, [token, paramValues]);

  // Auto-execute if no params
  useEffect(() => {
    if (report && (report.parameters || []).length === 0 && !result && !executing) {
      handleExecute();
    }
  }, [report]); // eslint-disable-line react-hooks/exhaustive-deps

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filter rows by search
  const columns = result?.columns || [];
  const allRows = result?.rows || [];
  const filteredRows = useMemo(() => {
    if (!searchQ.trim()) return allRows;
    const q = searchQ.toLowerCase();
    return allRows.filter((row: any[]) =>
      row.some(v => String(v ?? '').toLowerCase().includes(q))
    );
  }, [allRows, searchQ]);

  const paginatedRows = filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh', flexDirection: 'column', gap: 2 }}>
        <LinkOffIcon sx={{ fontSize: 64, color: 'text.disabled' }} />
        <Typography variant="h5" color="text.secondary">Share Link Unavailable</Typography>
        <Typography variant="body2" color="text.disabled">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: 3 }}>
      {/* Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
          <BoltIcon sx={{ color: 'primary.main' }} />
          <Typography variant="h5" fontWeight={600}>{report?.name}</Typography>
          <Box sx={{ flex: 1 }} />
          <Button size="small" startIcon={<CopyIcon />} onClick={copyLink}>
            {copied ? 'Copied!' : 'Copy Link'}
          </Button>
        </Box>
        {report?.description && (
          <Typography variant="body2" color="text.secondary" sx={{ ml: 5 }}>
            {report.description}
          </Typography>
        )}
      </Paper>

      {/* Parameters */}
      {(report?.parameters || []).length > 0 && (
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Parameters</Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            {report.parameters.map((p: any) => (
              <TextField
                key={p.id}
                label={p.label}
                size="small"
                value={paramValues[p.name] || ''}
                onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                required={p.is_required}
                sx={{ minWidth: 180 }}
              />
            ))}
            <Button variant="contained" startIcon={<RunIcon />}
              onClick={handleExecute} disabled={executing}>
              {executing ? <CircularProgress size={16} /> : 'Run Report'}
            </Button>
          </Box>
        </Paper>
      )}

      {execError && <Alert severity="error" sx={{ mb: 2 }}>{execError}</Alert>}

      {/* Results */}
      {result && (
        <Paper sx={{ overflow: 'hidden' }}>
          <Box sx={{ px: 2, py: 1, display: 'flex', alignItems: 'center', gap: 1,
            borderBottom: '1px solid', borderColor: 'divider' }}>
            <TextField
              size="small" placeholder="Filter rows..." value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              sx={{ flex: 1, maxWidth: 300 }}
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
                endAdornment: searchQ ? (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSearchQ('')}><ClearIcon fontSize="small" /></IconButton>
                  </InputAdornment>
                ) : null,
              }}
            />
            <Typography variant="body2" color="text.secondary">
              {filteredRows.length} row{filteredRows.length !== 1 ? 's' : ''}
            </Typography>
            <Button size="small" startIcon={<DownloadIcon />}
              onClick={() => exportCsv(columns, filteredRows, `${report?.name || 'report'}.csv`)}>
              Export CSV
            </Button>
          </Box>

          <TableContainer sx={{ maxHeight: 600 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((col: string, i: number) => (
                    <TableCell key={i} sx={{
                      fontWeight: 600, bgcolor: '#00aeef', color: '#fff',
                      textTransform: 'uppercase', fontSize: 11,
                    }}>{col}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRows.map((row: any[], ri: number) => (
                  <TableRow key={ri} hover>
                    {row.map((v: any, ci: number) => (
                      <TableCell key={ci} sx={{ fontSize: 12 }}>
                        {v === null || v === undefined ? '' : String(v)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={filteredRows.length}
            page={page} onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </Paper>
      )}
    </Box>
  );
}
