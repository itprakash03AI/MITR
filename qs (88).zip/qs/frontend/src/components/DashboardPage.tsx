// @ts-nocheck
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import GridLayout from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import {
  Box, Button, Typography, IconButton, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Select, MenuItem,
  FormControl, InputLabel, Paper, CircularProgress, Chip,
  Tooltip, Menu, Divider, Alert, Snackbar, alpha, Skeleton,
  ToggleButtonGroup, ToggleButton, Stack,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Dashboard as DashboardIcon, BarChart as BarChartIcon,
  PieChart as PieChartIcon, ShowChart as LineIcon,
  TableChart as TableIcon, Refresh as RefreshIcon,
  MoreVert as MoreIcon, GridView as GridIcon,
  DragIndicator as DragIcon, AreaChart as AreaChartIcon,
  Settings as ConfigIcon, TrendingUp as KpiIcon,
  Link as LinkIcon, ContentCopy as CopyIcon,
  ViewModule as LayoutIcon, Palette as PaletteIcon,
  Print as PrintIcon, FilterList as FilterIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  Legend, ResponsiveContainer,
} from 'recharts';
import api from '../services/api';

// ── Palette ────────────────────────────────────────────────────────────────────
const COLORS = ['#1565c0','#2e7d32','#c62828','#e65100','#6a1b9a',
                '#00838f','#ff6f00','#558b2f','#ad1457','#4527a0'];
const fmtNum = (n) => {
  if (typeof n !== 'number' && isNaN(Number(n))) return String(n ?? '');
  const num = Number(n);
  const abs = Math.abs(num);
  const s = abs >= 1_000_000 ? `${(abs/1_000_000).toFixed(1)}M`
           : abs >= 1_000   ? `${(abs/1_000).toFixed(1)}K`
           : abs.toLocaleString();
  return num < 0 ? `(${s})` : s;
};

// JSX helper: renders negative numbers in red with () notation
const FmtCell = ({ v, isNum }) => {
  if (!isNum) return v == null
    ? <span style={{ color:'#94a3b8', fontStyle:'italic' }}>null</span>
    : <>{String(v)}</>;
  const n = Number(v);
  if (isNaN(n)) return <>{String(v ?? '')}</>;
  const formatted = fmtNum(n);
  if (n < 0) return <span style={{ color:'#c62828', fontWeight:600 }}>{formatted}</span>;
  return <>{formatted}</>;
};

// ── Helpers ────────────────────────────────────────────────────────────────────
function isNumCol(rows, col) {
  const sample = rows.slice(0, 20).map(r => r[col]).filter(v => v != null);
  return sample.length > 0 && sample.every(v => !isNaN(Number(v)));
}

function aggregateRows(rows, xKey, yKey, aggFn = 'sum') {
  const map = new Map();
  rows.forEach(r => {
    const k = String(r[xKey] ?? '(blank)');
    const v = Number(r[yKey]);
    if (!map.has(k)) map.set(k, []);
    if (!isNaN(v)) map.get(k).push(v);
  });
  return Array.from(map.entries())
    .map(([name, vals]) => {
      let value = 0;
      if (aggFn === 'sum')   value = vals.reduce((a, b) => a + b, 0);
      if (aggFn === 'avg')   value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      if (aggFn === 'count') value = vals.length;
      if (aggFn === 'max')   value = vals.length ? Math.max(...vals) : 0;
      if (aggFn === 'min')   value = vals.length ? Math.min(...vals) : 0;
      return { name, value: Math.round(value * 100) / 100 };
    })
    .sort((a, b) => b.value - a.value)
    .slice(0, 40);
}

// ── Layout presets ─────────────────────────────────────────────────────────────
const PRESET_LAYOUTS = [
  {
    id: 'full',     name: 'Full Width',   desc: 'One widget per row, full width',
    slots: [{ x:0,y:0,w:12,h:6 },{ x:0,y:6,w:12,h:6 },{ x:0,y:12,w:12,h:6 }],
  },
  {
    id: '2col',     name: '2 Column',     desc: 'Two equal columns side by side',
    slots: [{ x:0,y:0,w:6,h:5 },{ x:6,y:0,w:6,h:5 },{ x:0,y:5,w:6,h:5 },{ x:6,y:5,w:6,h:5 }],
  },
  {
    id: '3col',     name: '3 Column',     desc: 'Three equal columns',
    slots: [{ x:0,y:0,w:4,h:5 },{ x:4,y:0,w:4,h:5 },{ x:8,y:0,w:4,h:5 },
            { x:0,y:5,w:4,h:5 },{ x:4,y:5,w:4,h:5 },{ x:8,y:5,w:4,h:5 }],
  },
  {
    id: 'kpi-row',  name: 'KPI + Chart',  desc: '4 metric cards on top, large chart below',
    slots: [{ x:0,y:0,w:3,h:3 },{ x:3,y:0,w:3,h:3 },{ x:6,y:0,w:3,h:3 },{ x:9,y:0,w:3,h:3 },
            { x:0,y:3,w:12,h:7 }],
  },
  {
    id: 'featured', name: 'Featured',     desc: 'Hero widget on top, three panels below',
    slots: [{ x:0,y:0,w:12,h:6 },{ x:0,y:6,w:4,h:5 },{ x:4,y:6,w:4,h:5 },{ x:8,y:6,w:4,h:5 }],
  },
  {
    id: 'sidebar',  name: 'Wide + Sidebar', desc: 'Large main content, two sidebar widgets',
    slots: [{ x:0,y:0,w:8,h:10 },{ x:8,y:0,w:4,h:5 },{ x:8,y:5,w:4,h:5 }],
  },
  {
    id: 'mosaic',   name: 'Mosaic',       desc: 'Varied sizes for visual richness',
    slots: [{ x:0,y:0,w:7,h:6 },{ x:7,y:0,w:5,h:3 },{ x:7,y:3,w:5,h:3 },
            { x:0,y:6,w:4,h:4 },{ x:4,y:6,w:4,h:4 },{ x:8,y:6,w:4,h:4 }],
  },
  {
    id: 'exec',     name: 'Executive',    desc: 'Wide overview + two detail panels',
    slots: [{ x:0,y:0,w:12,h:5 },{ x:0,y:5,w:6,h:6 },{ x:6,y:5,w:6,h:6 }],
  },
];

// ── Dashboard style themes ─────────────────────────────────────────────────────
const DASH_STYLES = [
  { id:'default',  name:'Classic',    dot:'#e2e8f0', canvasBg:'#f0f4f8',     headerBg:'linear-gradient(135deg,#f8fafc,#f1f5f9)',  dark:false },
  { id:'indigo',   name:'Indigo',     dot:'#818cf8', canvasBg:'#eef2ff',     headerBg:'linear-gradient(135deg,#e0e7ff,#c7d2fe)',  dark:false },
  { id:'teal',     name:'Teal',       dot:'#2dd4bf', canvasBg:'#f0fdfa',     headerBg:'linear-gradient(135deg,#ccfbf1,#99f6e4)',  dark:false },
  { id:'rose',     name:'Rose',       dot:'#fb7185', canvasBg:'#fff1f2',     headerBg:'linear-gradient(135deg,#ffe4e6,#fecdd3)',  dark:false },
  { id:'amber',    name:'Amber',      dot:'#fbbf24', canvasBg:'#fffbeb',     headerBg:'linear-gradient(135deg,#fef3c7,#fde68a)',  dark:false },
  { id:'slate',    name:'Slate',      dot:'#94a3b8', canvasBg:'#e9eff6',     headerBg:'linear-gradient(135deg,#dde6f0,#c8d7e8)',  dark:false },
  { id:'charcoal', name:'Dark',       dot:'#334155', canvasBg:'#0f172a',     headerBg:'linear-gradient(135deg,#1e293b,#0f172a)',  dark:true  },
  { id:'midnight', name:'Midnight',   dot:'#312e81', canvasBg:'#1e1b4b',     headerBg:'linear-gradient(135deg,#312e81,#1e1b4b)',  dark:true  },
];

// ── Layout visual preview ──────────────────────────────────────────────────────
function LayoutPreview({ slots, active }) {
  const maxY = Math.max(...slots.map(s => s.y + s.h));
  const W = 150, H = 80;
  return (
    <Box sx={{ position:'relative', width:W, height:H, bgcolor:'#f1f5f9',
               borderRadius:1, overflow:'hidden', flexShrink:0 }}>
      {slots.map((s, i) => (
        <Box key={i} sx={{
          position:'absolute',
          left:  `${(s.x/12)*100}%`,  top:  `${(s.y/maxY)*100}%`,
          width: `${(s.w/12)*100}%`,  height:`${(s.h/maxY)*100}%`,
          p:'2px',
        }}>
          <Box sx={{ width:'100%', height:'100%', borderRadius:0.5,
                     bgcolor: active ? 'primary.main' : '#94a3b8',
                     opacity: 0.7 + i * 0.03, display:'flex',
                     alignItems:'center', justifyContent:'center' }}>
            <Typography sx={{ color:'#fff', fontSize:9, fontWeight:700, lineHeight:1 }}>{i+1}</Typography>
          </Box>
        </Box>
      ))}
    </Box>
  );
}

// ── Layout Picker Dialog ───────────────────────────────────────────────────────
function LayoutPickerDialog({ open, onClose, onApply, currentLayout }) {
  const [hovered, setHovered] = useState(null);
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight:700, pb:1 }}>
        Choose Layout
        <Typography variant="body2" color="text.secondary" sx={{ fontWeight:400, mt:0.5 }}>
          Selecting a layout will rearrange your existing widgets to fit the chosen grid.
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:1.5 }}>
          {PRESET_LAYOUTS.map(preset => (
            <Paper key={preset.id} elevation={hovered === preset.id ? 4 : 1}
              onMouseEnter={() => setHovered(preset.id)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => { onApply(preset); onClose(); }}
              sx={{ p:1.5, cursor:'pointer', border:2,
                    borderColor: hovered === preset.id ? 'primary.main' : 'transparent',
                    borderRadius:2, transition:'all .15s', display:'flex',
                    flexDirection:'column', gap:1, alignItems:'center' }}>
              <LayoutPreview slots={preset.slots} active={hovered === preset.id} />
              <Box sx={{ textAlign:'center' }}>
                <Typography variant="body2" fontWeight={700} sx={{ fontSize:13 }}>{preset.name}</Typography>
                <Typography variant="caption" color="text.secondary">{preset.desc}</Typography>
              </Box>
            </Paper>
          ))}
        </Box>
      </DialogContent>
      <DialogActions sx={{ px:3, pb:2 }}>
        <Button onClick={onClose}>Cancel</Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Cross-filter types ────────────────────────────────────────────────────────
// A cross-filter says "column X has value Y, applied by widget Z"
type CrossFilter = { column: string; value: string; sourceWidgetId: number };

// Apply active cross-filters to a widget's rows (exclude filters from self)
function applyCrossFilters(rows: any[], filters: CrossFilter[], widgetId: number) {
  const applicable = filters.filter(f => f.sourceWidgetId !== widgetId);
  if (applicable.length === 0) return rows;
  return rows.filter(row =>
    applicable.every(f => String(row[f.column] ?? '') === f.value)
  );
}

// ── Chart renderer ─────────────────────────────────────────────────────────────
function ChartRenderer({ chartType, rows, config, onNeedConfig, onCrossFilter }: any) {
  if (!rows || rows.length === 0) {
    return (
      <Box sx={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%' }}>
        <Typography variant="caption" color="text.disabled">No data loaded</Typography>
      </Box>
    );
  }

  const cols   = Object.keys(rows[0] || {});
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));

  const xKey  = config?.x_field  || strCols[0] || cols[0];
  const yKey  = config?.y_field  || numCols[0] || cols[1] || cols[0];
  const aggFn = config?.agg_fn   || 'sum';

  // Table view — no config needed
  if (chartType === 'grid') {
    return (
      <Box sx={{ overflowX:'auto', overflowY:'auto', height:'100%' }}>
        <Box sx={{ mb: 0.5, px: 1 }}>
          <Typography variant="caption" color="text.secondary">
            {rows.length.toLocaleString()} rows · {cols.length} columns
          </Typography>
        </Box>
        <table style={{ borderCollapse:'collapse', fontSize:12, width:'100%' }}>
          <thead>
            <tr>
              {cols.map(c => (
                <th key={c} style={{ background:'#f8fafc', padding:'5px 10px',
                  borderBottom:'2px solid #e2e8f0', textAlign:'left',
                  whiteSpace:'nowrap', fontWeight:700, fontSize:11, color:'#64748b' }}>
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 100).map((row, i) => (
              <tr key={i} style={{ background: i % 2 ? '#f8fafc' : '#fff' }}>
                {cols.map(c => (
                  <td key={c} style={{ padding:'4px 10px', borderBottom:'1px solid #f1f5f9',
                    maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
                    textAlign: isNumCol(rows, c) ? 'right' : 'left' }}>
                    <FmtCell v={row[c]} isNum={isNumCol(rows, c)} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > 100 && (
          <Box sx={{ p: 1, textAlign:'center' }}>
            <Typography variant="caption" color="text.disabled">
              Showing first 100 of {rows.length.toLocaleString()} rows
            </Typography>
          </Box>
        )}
      </Box>
    );
  }

  // KPI metric
  if (chartType === 'metric') {
    const val = rows[0]?.[yKey] ?? rows[0]?.[cols[0]] ?? '—';
    const label = yKey || cols[0];
    const total = numCols.includes(yKey)
      ? rows.reduce((s, r) => s + Number(r[yKey] || 0), 0)
      : null;
    return (
      <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                 justifyContent:'center', height:'100%', gap:1, p:2 }}>
        <Typography variant="h2" fontWeight={800} color="primary.main" sx={{ lineHeight:1 }}>
          {fmtNum(typeof val === 'number' ? val : Number(val) || val)}
        </Typography>
        <Typography variant="body2" color="text.secondary" fontWeight={600}>{label}</Typography>
        {total !== null && rows.length > 1 && (
          <Chip label={`Total: ${fmtNum(total)} across ${rows.length} rows`}
                size="small" variant="outlined" sx={{ fontSize:11 }} />
        )}
      </Box>
    );
  }

  // Charts need a numeric y column
  if (!numCols.includes(yKey) && numCols.length === 0) {
    return (
      <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                 justifyContent:'center', height:'100%', gap:1, p:2 }}>
        <ConfigIcon sx={{ fontSize:32, color:'text.disabled' }} />
        <Typography variant="caption" color="text.secondary" textAlign="center">
          No numeric columns found. Switch to Table view or edit the widget to configure columns.
        </Typography>
        <Button size="small" startIcon={<ConfigIcon />} onClick={onNeedConfig}>Configure</Button>
      </Box>
    );
  }

  // Aggregate
  const agg = aggregateRows(rows, xKey, yKey, aggFn);
  const xProps = { dataKey:'name', tick:{ fontSize:11 }, angle:-30, textAnchor:'end', interval:0 };
  const yProps = { tick:{ fontSize:11 }, tickFormatter: fmtNum, width:58 };
  const tip    = <ReTooltip formatter={(v) => [fmtNum(Number(v)), `${aggFn.toUpperCase()}(${yKey})`]}
                             labelFormatter={(l) => `${xKey}: ${l}`} />;
  const common = { data:agg, margin:{ top:8, right:12, left:0, bottom:56 } };
  const handleChartClick = (data: any) => {
    if (onCrossFilter && data?.name) onCrossFilter(xKey, data.name);
  };

  if (chartType === 'bar') return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart {...common} onClick={(e) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Bar dataKey="value" radius={[4,4,0,0]} maxBarSize={48} style={{ cursor:'pointer' }}>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  if (chartType === 'line') return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart {...common} onClick={(e) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Line type="monotone" dataKey="value" stroke={COLORS[0]} strokeWidth={2}
              dot={{ r:3, fill:COLORS[0] }} style={{ cursor:'pointer' }} />
      </LineChart>
    </ResponsiveContainer>
  );

  if (chartType === 'area') return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart {...common} onClick={(e) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <defs>
          <linearGradient id={`ag_${yKey}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={COLORS[0]} stopOpacity={0.3} />
            <stop offset="95%" stopColor={COLORS[0]} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Area type="monotone" dataKey="value" stroke={COLORS[0]}
              fill={`url(#ag_${yKey})`} strokeWidth={2} style={{ cursor:'pointer' }} />
      </AreaChart>
    </ResponsiveContainer>
  );

  if (chartType === 'pie') return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart margin={{ top:8, right:8, bottom:8, left:8 }}>
        <Pie data={agg} dataKey="value" nameKey="name" cx="50%" cy="45%"
             outerRadius="65%"
             label={({ name, percent }) => `${name}: ${(percent*100).toFixed(1)}%`}
             labelLine onClick={(_, idx) => handleChartClick(agg[idx])}>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} style={{ cursor:'pointer' }} />)}
        </Pie>
        <ReTooltip formatter={(v) => [fmtNum(v), yKey]} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );

  return null;
}

// ── Edit Widget Dialog ─────────────────────────────────────────────────────────
function EditWidgetDialog({ open, widget, rows, onClose, onSave }) {
  const [title,     setTitle]     = useState('');
  const [chartType, setChartType] = useState('grid');
  const [xField,    setXField]    = useState('');
  const [yField,    setYField]    = useState('');
  const [aggFn,     setAggFn]     = useState('sum');
  const [saving,    setSaving]    = useState(false);

  const cols    = rows?.length ? Object.keys(rows[0]) : [];
  const numCols = cols.filter(c => isNumCol(rows || [], c));
  const strCols = cols.filter(c => !isNumCol(rows || [], c));

  useEffect(() => {
    if (!open || !widget) return;
    setTitle(widget.title || '');
    setChartType(widget.chart_type || 'grid');
    setXField(widget.chart_config?.x_field || strCols[0] || cols[0] || '');
    setYField(widget.chart_config?.y_field || numCols[0] || '');
    setAggFn(widget.chart_config?.agg_fn   || 'sum');
  }, [open, widget]);

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      title:        title || widget.title,
      chart_type:   chartType,
      chart_config: { x_field: xField, y_field: yField, agg_fn: aggFn },
    });
    setSaving(false);
    onClose();
  };

  const needsAxes = chartType !== 'grid';

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight:700, pb:1 }}>Edit Widget</DialogTitle>
      <DialogContent sx={{ display:'flex', flexDirection:'column', gap:2, pt:2 }}>

        <TextField label="Widget Title" size="small" fullWidth
                   value={title} onChange={e => setTitle(e.target.value)} />

        <FormControl size="small" fullWidth>
          <InputLabel>Chart Type</InputLabel>
          <Select value={chartType} label="Chart Type" onChange={e => setChartType(e.target.value)}>
            <MenuItem value="grid">   📋  Table / Grid</MenuItem>
            <MenuItem value="bar">    📊  Bar Chart</MenuItem>
            <MenuItem value="line">   📈  Line Chart</MenuItem>
            <MenuItem value="area">   🏔   Area Chart</MenuItem>
            <MenuItem value="pie">    🥧  Pie Chart</MenuItem>
            <MenuItem value="metric"> 🔢  KPI / Single Metric</MenuItem>
          </Select>
        </FormControl>

        {needsAxes && (
          <>
            <Divider><Typography variant="caption" color="text.secondary">Axis Configuration</Typography></Divider>

            <FormControl size="small" fullWidth>
              <InputLabel>X-Axis / Category column</InputLabel>
              <Select value={xField} label="X-Axis / Category column"
                      onChange={e => setXField(e.target.value)}>
                {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
              </Select>
            </FormControl>

            <FormControl size="small" fullWidth>
              <InputLabel>Y-Axis / Value column</InputLabel>
              <Select value={yField} label="Y-Axis / Value column"
                      onChange={e => setYField(e.target.value)}>
                {numCols.length > 0
                  ? numCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)
                  : cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)
                }
              </Select>
            </FormControl>

            <FormControl size="small" fullWidth>
              <InputLabel>Aggregation</InputLabel>
              <Select value={aggFn} label="Aggregation"
                      onChange={e => setAggFn(e.target.value)}>
                <MenuItem value="sum">Sum</MenuItem>
                <MenuItem value="avg">Average</MenuItem>
                <MenuItem value="count">Count</MenuItem>
                <MenuItem value="max">Maximum</MenuItem>
                <MenuItem value="min">Minimum</MenuItem>
              </Select>
            </FormControl>

            {xField && yField && (
              <Alert severity="info" sx={{ fontSize:12 }}>
                Will show: <strong>{aggFn.toUpperCase()}({yField})</strong> grouped by <strong>{xField}</strong> · top 40 groups
              </Alert>
            )}
          </>
        )}
      </DialogContent>
      <DialogActions sx={{ px:3, pb:2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={saving}
                startIcon={saving ? <CircularProgress size={14} /> : null}>
          Save Changes
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Widget card ────────────────────────────────────────────────────────────────
function WidgetCard({ widget, loadDelay = 0, onDelete, onEdit, onChartTypeChange, cardStyle,
                      crossFilters = [], onCrossFilter }: any) {
  const [rows,      setRows]      = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState('');
  const [chartType, setChartType] = useState(widget.chart_type || 'grid');
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    if (loadDelay === 0) { loadData(); return; }
    const t = setTimeout(() => loadData(), loadDelay);
    return () => clearTimeout(t);
  }, [widget.source_id, widget.widget_type]);

  // Sync chart type when parent updates it
  useEffect(() => { setChartType(widget.chart_type || 'grid'); }, [widget.chart_type]);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      let execResp;
      if (widget.widget_type === 'saved_query')
        execResp = await api.executeQuery({ query_id: widget.source_id });
      else if (widget.widget_type === 'sql_query')
        execResp = await api.executeSqlQuery({ query_id: widget.source_id });
      else if (widget.widget_type === 'report')
        execResp = await api.executeReport(widget.source_id, widget.param_values || {});

      if (!execResp) { setLoading(false); return; }

      const fetchResults = async (execId) => {
        const res = await api.getExecutionResults(execId, 1, 500);
        setRows(res?.rows || res?.data || []);
        setLastUpdated(new Date());
      };

      if (execResp.status === 'completed' || execResp.cache_hit) {
        await fetchResults(execResp.execution_id);
        setLoading(false);
        return;
      }

      const execId = execResp.execution_id;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 1000));
        const status = await api.getExecutionStatus(execId);
        if (status?.status === 'completed') { await fetchResults(execId); break; }
        if (status?.status === 'failed') { setError(status.error_message || 'Query failed'); break; }
      }
    } catch (e) {
      setError(e.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  const handleChartType = (_, val) => {
    if (!val) return;
    setChartType(val);
    onChartTypeChange(widget.id, val);
  };

  const cols    = rows.length ? Object.keys(rows[0]) : [];
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));

  // Summary stat / axis description for header
  const headerStat = useMemo(() => {
    if (!rows.length) return null;
    const cfg = widget.chart_config || {};
    const ct  = widget.chart_type || chartType;
    const xKey = cfg.x_field || strCols[0] || cols[0];
    const yKey = cfg.y_field || numCols[0] || cols[1] || cols[0];
    const aggFn = cfg.agg_fn || 'sum';
    // For chart types show "SUM(col) by col · N groups"
    if (ct !== 'grid' && ct !== 'metric' && xKey && yKey && numCols.includes(yKey)) {
      const agg = aggregateRows(rows, xKey, yKey, aggFn);
      const total = agg.reduce((s, r) => s + r.value, 0);
      return `${aggFn.toUpperCase()}(${yKey}) by ${xKey} · ${agg.length} groups · ${fmtNum(Math.round(total * 100) / 100)} total`;
    }
    if (cfg.y_field && numCols.includes(cfg.y_field)) {
      const sum = rows.reduce((s, r) => s + Number(r[cfg.y_field] || 0), 0);
      return `${fmtNum(Math.round(sum * 100) / 100)} total · ${rows.length.toLocaleString()} rows`;
    }
    return `${rows.length.toLocaleString()} rows · ${cols.length} columns`;
  }, [rows, widget.chart_config, widget.chart_type, chartType]);

  const hdrBg   = cardStyle?.headerBg || 'linear-gradient(135deg,#f8fafc 0%,#f1f5f9 100%)';
  const isDark  = cardStyle?.dark || false;
  const txtCol  = isDark ? '#f1f5f9' : undefined;
  const subCol  = isDark ? '#94a3b8' : 'text.secondary';

  return (
    <Paper elevation={2} sx={{ height:'100%', display:'flex', flexDirection:'column',
                                overflow:'hidden', borderRadius:2,
                                bgcolor: isDark ? '#1e293b' : undefined }}>
      {/* Header */}
      <Box sx={{ px:1.5, py:0.75, borderBottom:1,
                 borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'divider',
                 display:'flex', alignItems:'center', gap:0.5, minHeight:42,
                 background: hdrBg }}>
        <DragIcon fontSize="small" sx={{ color:'text.disabled', cursor:'grab', flexShrink:0 }}
                  className="drag-handle" />

        <Box sx={{ flex:1, overflow:'hidden', mr:0.5 }}>
          <Typography variant="subtitle2" fontWeight={700} fontSize={13} noWrap
                      sx={{ color: txtCol }}>
            {widget.title || 'Untitled Widget'}
          </Typography>
          {!loading && headerStat && (
            <Typography variant="caption" color={subCol}
                        sx={{ display:'block', lineHeight:1.2 }}>
              {headerStat}
              {lastUpdated && ` · ${lastUpdated.toLocaleTimeString()}`}
            </Typography>
          )}
        </Box>

        {/* Chart type toggles */}
        <ToggleButtonGroup size="small" value={chartType} exclusive onChange={handleChartType}
                           sx={{ '& .MuiToggleButton-root':{ py:0, px:0.4, minWidth:26, fontSize:11 } }}>
          <ToggleButton value="grid"   ><Tooltip title="Table"><TableIcon    sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="bar"    ><Tooltip title="Bar Chart"><BarChartIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="line"   ><Tooltip title="Line Chart"><LineIcon      sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="area"   ><Tooltip title="Area Chart"><AreaChartIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="pie"    ><Tooltip title="Pie Chart"><PieChartIcon  sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="metric" ><Tooltip title="KPI"><Typography variant="caption" fontWeight={700}>KPI</Typography></Tooltip></ToggleButton>
        </ToggleButtonGroup>

        <Tooltip title="Refresh"><IconButton size="small" onClick={loadData}><RefreshIcon sx={{ fontSize:14 }} /></IconButton></Tooltip>
        <IconButton size="small" onClick={e => setMenuAnchor(e.currentTarget)}><MoreIcon sx={{ fontSize:14 }} /></IconButton>

        <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={() => setMenuAnchor(null)}>
          <MenuItem onClick={() => { setMenuAnchor(null); onEdit(widget, rows); }}>
            <EditIcon fontSize="small" sx={{ mr:1 }} /> Edit &amp; Configure
          </MenuItem>
          <MenuItem onClick={() => { setMenuAnchor(null); loadData(); }}>
            <RefreshIcon fontSize="small" sx={{ mr:1 }} /> Refresh data
          </MenuItem>
          <Divider />
          <MenuItem onClick={() => { setMenuAnchor(null); onDelete(widget.id); }}
                    sx={{ color:'error.main' }}>
            <DeleteIcon fontSize="small" sx={{ mr:1 }} /> Remove widget
          </MenuItem>
        </Menu>
      </Box>

      {/* Config hint banner — shown when chart needs axes but none configured */}
      {!loading && !error && rows.length > 0 && chartType !== 'grid' &&
       !widget.chart_config?.x_field && (
        <Box sx={{ px:1.5, py:0.5, bgcolor:'info.50', borderBottom:1, borderColor:'info.200',
                   display:'flex', alignItems:'center', justifyContent:'space-between', gap:1 }}>
          <Typography variant="caption" color="info.dark">
            Auto-detected axes — click <strong>Edit &amp; Configure</strong> to set precise columns
          </Typography>
          <Button size="small" variant="text" sx={{ py:0, fontSize:11 }}
                  onClick={() => onEdit(widget, rows)}>Configure</Button>
        </Box>
      )}

      {/* Content */}
      <Box sx={{ flex:1, overflow:'hidden', p: chartType === 'grid' ? 0 : 1, minHeight:0 }}>
        {loading ? (
          <Box sx={{ p:1.5 }}>
            <Skeleton variant="rectangular" height={30} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={80} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={50} sx={{ borderRadius:1 }} />
          </Box>
        ) : error ? (
          <Box sx={{ p:1 }}>
            <Alert severity="error" sx={{ fontSize:12 }}>{error}</Alert>
          </Box>
        ) : (
          <ChartRenderer
            chartType={chartType}
            rows={applyCrossFilters(rows, crossFilters || [], widget.id)}
            config={widget.chart_config || {}}
            onNeedConfig={() => onEdit(widget, rows)}
            onCrossFilter={onCrossFilter ? (col: string, val: string) => onCrossFilter(widget.id, col, val) : undefined}
          />
        )}
      </Box>
    </Paper>
  );
}

// ── Placeholder slot card ──────────────────────────────────────────────────────
function PlaceholderCard({ slotIndex, onAdd, isDark }) {
  return (
    <Box onClick={onAdd} sx={{
      height: '100%', borderRadius: 2, cursor: 'pointer',
      border: '2px dashed', borderColor: isDark ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.15)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 1, bgcolor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.55)',
      transition: 'all .2s',
      '&:hover': {
        borderColor: 'primary.main', bgcolor: 'primary.50',
        '& .slot-icon': { transform: 'scale(1.15)', color: 'primary.main' },
      },
    }}>
      <Box className="slot-icon" sx={{
        width: 44, height: 44, borderRadius: '50%',
        bgcolor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all .2s',
      }}>
        <AddIcon sx={{ fontSize: 22, color: isDark ? 'rgba(255,255,255,0.4)' : 'text.disabled' }} />
      </Box>
      <Typography variant="caption" fontWeight={600}
                  sx={{ color: isDark ? 'rgba(255,255,255,0.5)' : 'text.secondary' }}>
        Slot {slotIndex + 1}
      </Typography>
      <Typography variant="caption" sx={{ fontSize: 10,
                  color: isDark ? 'rgba(255,255,255,0.3)' : 'text.disabled' }}>
        Click to add widget
      </Typography>
    </Box>
  );
}

// ── Add Widget Dialog ──────────────────────────────────────────────────────────
function AddWidgetDialog({ open, onClose, onAdd, slotPosition }) {
  const [queries,    setQueries]    = useState([]);
  const [reports,    setReports]    = useState([]);
  const [sqlQueries, setSqlQueries] = useState([]);
  const [type,       setType]       = useState('saved_query');
  const [sourceId,   setSourceId]   = useState('');
  const [title,      setTitle]      = useState('');
  const [chartType,  setChartType]  = useState('grid');

  useEffect(() => {
    if (!open) return;
    api.listQueries().then(setQueries).catch(() => {});
    api.listReports().then(setReports).catch(() => {});
    api.listSqlQueries().then(setSqlQueries).catch(() => {});
    setSourceId(''); setTitle(''); setChartType('grid');
  }, [open]);

  const sources = type === 'saved_query' ? queries
    : type === 'report' ? reports : sqlQueries;

  const handleAdd = () => {
    if (!sourceId) return;
    const src = sources.find(s => String(s.id) === String(sourceId));
    const layout = slotPosition
      ? { x: slotPosition.x, y: slotPosition.y, w: slotPosition.w, h: slotPosition.h }
      : { x: 0, y: 0, w: 6, h: 5 };
    onAdd({
      widget_type:  type,
      source_id:    Number(sourceId),
      title:        title || src?.name || 'Widget',
      chart_type:   chartType,
      chart_config: {},
      layout,
    });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight:700 }}>
        {slotPosition ? `Fill Slot — ${slotPosition.w}×${slotPosition.h} panel` : 'Add Widget'}
      </DialogTitle>
      <DialogContent sx={{ display:'flex', flexDirection:'column', gap:2, pt:2 }}>
        <FormControl size="small" fullWidth>
          <InputLabel>Source Type</InputLabel>
          <Select value={type} label="Source Type"
                  onChange={e => { setType(e.target.value); setSourceId(''); }}>
            <MenuItem value="saved_query">Parquet / S3 Query</MenuItem>
            <MenuItem value="sql_query">SQL Query</MenuItem>
            <MenuItem value="report">Parametric Report</MenuItem>
          </Select>
        </FormControl>

        <FormControl size="small" fullWidth>
          <InputLabel>Select Query / Report</InputLabel>
          <Select value={sourceId} label="Select Query / Report"
                  onChange={e => setSourceId(e.target.value)}>
            {sources.map(s => (
              <MenuItem key={s.id} value={String(s.id)}>
                {s.name}
                {s.description && (
                  <Typography variant="caption" color="text.secondary" sx={{ ml:1 }}>
                    — {s.description}
                  </Typography>
                )}
              </MenuItem>
            ))}
            {sources.length === 0 && (
              <MenuItem disabled>No {type.replace('_', ' ')}s found</MenuItem>
            )}
          </Select>
        </FormControl>

        <TextField label="Widget Title (optional)" size="small" fullWidth
                   value={title} onChange={e => setTitle(e.target.value)}
                   placeholder="Leave blank to use query name" />

        <FormControl size="small" fullWidth>
          <InputLabel>Initial View</InputLabel>
          <Select value={chartType} label="Initial View"
                  onChange={e => setChartType(e.target.value)}>
            <MenuItem value="grid">   📋  Table (recommended — configure chart after)</MenuItem>
            <MenuItem value="bar">    📊  Bar Chart</MenuItem>
            <MenuItem value="line">   📈  Line Chart</MenuItem>
            <MenuItem value="area">   🏔   Area Chart</MenuItem>
            <MenuItem value="pie">    🥧  Pie Chart</MenuItem>
            <MenuItem value="metric"> 🔢  KPI / Single Metric</MenuItem>
          </Select>
        </FormControl>

        <Alert severity="info" sx={{ fontSize:12 }}>
          After adding the widget, use <strong>⋮ → Edit &amp; Configure</strong> to set exact X/Y axes and aggregation for charts.
        </Alert>
      </DialogContent>
      <DialogActions sx={{ px:3, pb:2 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleAdd} variant="contained" disabled={!sourceId}>
          Add Widget
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Main DashboardPage ─────────────────────────────────────────────────────────
export default function DashboardPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [dashboards,    setDashboards]    = useState([]);
  const [selected,      setSelected]      = useState(null);
  const [widgets,       setWidgets]       = useState([]);
  const [layouts,       setLayouts]       = useState([]);
  const [addOpen,       setAddOpen]       = useState(false);
  const [createOpen,    setCreateOpen]    = useState(false);
  const [editWidget,    setEditWidget]    = useState(null);   // {widget, rows}
  const [newName,       setNewName]       = useState('');
  const [newDesc,       setNewDesc]       = useState('');
  const [snack,         setSnack]         = useState('');
  const [containerWidth, setContainerWidth] = useState(1200);
  const [layoutOpen,    setLayoutOpen]    = useState(false);
  const [pendingSlot,   setPendingSlot]   = useState(null);   // slot clicked from placeholder
  const [newTemplate,   setNewTemplate]   = useState(null);   // chosen during create dialog
  const [crossFilters, setCrossFilters] = useState<CrossFilter[]>([]);
  const [styleMenuAnchor, setStyleMenuAnchor] = useState(null);
  const [dashStyle,     setDashStyle]     = useState(() => {
    try { return JSON.parse(localStorage.getItem('qs_dash_style') || 'null') || DASH_STYLES[0]; }
    catch { return DASH_STYLES[0]; }
  });
  const containerRef = useRef(null);

  useEffect(() => { loadDashboards(); }, []);

  // Auto-select dashboard from URL param ?dashboard=ID
  const urlDashId = searchParams.get('dashboard');
  useEffect(() => {
    if (!urlDashId || !dashboards.length) return;
    const target = dashboards.find(d => String(d.id) === urlDashId);
    if (target) setSelected(target);
  }, [urlDashId, dashboards]);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(entries => {
      setContainerWidth(entries[0]?.contentRect.width || 1200);
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (selected) { loadWidgets(selected.id); setCrossFilters([]); }
  }, [selected]);

  const loadDashboards = async () => {
    try {
      const list = await api.listDashboards();
      setDashboards(list);
      if (list.length && !selected) setSelected(list[0]);
    } catch (_) {}
  };

  const loadWidgets = async (dashId) => {
    try {
      const wList = await api.listDashboardWidgets(dashId);
      setWidgets(wList);
      setLayouts(wList.map(w => ({
        i: String(w.id),
        x: w.layout?.x ?? 0, y: w.layout?.y ?? 0,
        w: w.layout?.w ?? 6,  h: w.layout?.h ?? 5,
        minW: 2, minH: 3,
      })));
    } catch (_) {}
  };

  const handleLayoutChange = useCallback(async (newLayout) => {
    setLayouts(newLayout);
    if (!selected) return;
    try { await api.updateDashboardLayout(selected.id, newLayout); } catch (_) {}
  }, [selected]);

  const handleAddWidget = async (data) => {
    if (!selected) return;
    try {
      const w = await api.createWidget(selected.id, data);
      setWidgets(prev => [...prev, w]);
      setLayouts(prev => [...prev, {
        i: String(w.id), x:0, y:Infinity,
        w: data.layout?.w || 6, h: data.layout?.h || 5, minW:2, minH:3,
      }]);
      setSnack('Widget added');
    } catch (e) { setSnack('Failed to add widget'); }
  };

  const handleDeleteWidget = async (widgetId) => {
    if (!selected) return;
    try {
      await api.deleteWidget(selected.id, widgetId);
      setWidgets(prev => prev.filter(w => w.id !== widgetId));
      setLayouts(prev => prev.filter(l => l.i !== String(widgetId)));
      setSnack('Widget removed');
    } catch (_) {}
  };

  const handleChartTypeChange = async (widgetId, chartType) => {
    if (!selected) return;
    try {
      await api.updateWidget(selected.id, widgetId, { chart_type: chartType });
      setWidgets(prev => prev.map(w =>
        w.id === widgetId ? { ...w, chart_type: chartType } : w
      ));
    } catch (_) {}
  };

  const handleEditOpen = (widget, rows) => {
    setEditWidget({ widget, rows });
  };

  const handleEditSave = async (updates) => {
    if (!editWidget || !selected) return;
    const { widget } = editWidget;
    try {
      const updated = await api.updateWidget(selected.id, widget.id, updates);
      setWidgets(prev => prev.map(w => w.id === widget.id ? { ...w, ...updates } : w));
      setSnack('Widget updated');
    } catch (_) { setSnack('Failed to save'); }
  };

  const handleCreateDashboard = async () => {
    if (!newName.trim()) return;
    try {
      const d = await api.createDashboard({ name: newName.trim(), description: newDesc.trim() });
      // Store chosen template for this dashboard
      if (newTemplate) localStorage.setItem(`qs_dash_tpl_${d.id}`, newTemplate.id);
      setDashboards(prev => [...prev, d]);
      setSelected(d);
      setWidgets([]); setLayouts([]);
      setNewName(''); setNewDesc(''); setNewTemplate(null);
      setCreateOpen(false);
      setSnack(newTemplate ? `Dashboard created with ${newTemplate.name} layout` : 'Dashboard created');
    } catch (_) {}
  };

  const handleApplyLayout = async (preset) => {
    if (!selected) return;
    // Store as active template for placeholders
    localStorage.setItem(`qs_dash_tpl_${selected.id}`, preset.id);
    if (widgets.length) {
      const newLayouts = widgets.map((w, i) => {
        const slot = preset.slots[i] || { x:0, y: Math.floor(i/2)*5, w:6, h:5 };
        return { i: String(w.id), ...slot, minW:2, minH:3 };
      });
      setLayouts(newLayouts);
      try { await api.updateDashboardLayout(selected.id, newLayouts); } catch (_) {}
    }
    setSnack(`Template applied: ${preset.name} — click slots to fill them`);
  };

  const handleSetStyle = (style) => {
    setDashStyle(style);
    localStorage.setItem('qs_dash_style', JSON.stringify(style));
    setStyleMenuAnchor(null);
  };

  const handleCrossFilter = useCallback((sourceWidgetId: number, column: string, value: string) => {
    setCrossFilters(prev => {
      // Toggle: if same filter exists, remove it; otherwise add it
      const existing = prev.findIndex(f => f.column === column && f.value === value && f.sourceWidgetId === sourceWidgetId);
      if (existing >= 0) return prev.filter((_, i) => i !== existing);
      return [...prev, { column, value, sourceWidgetId }];
    });
  }, []);

  const clearCrossFilters = useCallback(() => setCrossFilters([]), []);

  const handleCopyLink = async () => {
    if (!selected) return;
    try {
      const share = await api.createDashboardShare(selected.id);
      const url = `${window.location.origin}/shared-dashboard/${share.token}`;
      await navigator.clipboard.writeText(url);
      setSnack('Public dashboard link copied! Anyone with the link can view it.');
    } catch (_) {
      setSnack('Failed to generate share link');
    }
  };

  const handleDeleteDashboard = async () => {
    if (!selected) return;
    try {
      await api.deleteDashboard(selected.id);
      const remaining = dashboards.filter(d => d.id !== selected.id);
      setDashboards(remaining);
      setSelected(remaining[0] || null);
      setWidgets([]); setLayouts([]);
      setSnack('Dashboard deleted');
    } catch (_) {}
  };

  return (
    <Box sx={{ p: { xs: 1, sm: 2 }, height:'100%', display:'flex', flexDirection:'column', gap:0, overflow:'auto' }}>

      {/* Header */}
      <Box sx={{ display:'flex', alignItems:'center', gap:1, mb:1.5, flexWrap:'wrap' }}>
        <DashboardIcon color="primary" />
        <Typography variant="h5" fontWeight={700} sx={{ flex:1 }}>Dashboards</Typography>

        {/* Dashboard selector chips */}
        <Box sx={{ display:'flex', gap:0.5, flexWrap:'wrap', alignItems:'center' }}>
          {dashboards.map(d => (
            <Chip key={d.id} label={d.name}
                  onClick={() => setSelected(d)}
                  variant={selected?.id === d.id ? 'filled' : 'outlined'}
                  color={selected?.id === d.id ? 'primary' : 'default'}
                  size="small" />
          ))}
        </Box>

        {/* Style selector */}
        <Tooltip title={`Dashboard style: ${dashStyle.name}`}>
          <Button size="small" variant="outlined" startIcon={<PaletteIcon />}
                  onClick={e => setStyleMenuAnchor(e.currentTarget)}
                  sx={{ minWidth:0, gap:0.5 }}>
            <Box sx={{ width:12, height:12, borderRadius:'50%', bgcolor:dashStyle.dot, flexShrink:0 }} />
            {dashStyle.name}
          </Button>
        </Tooltip>
        <Menu anchorEl={styleMenuAnchor} open={Boolean(styleMenuAnchor)}
              onClose={() => setStyleMenuAnchor(null)}>
          {DASH_STYLES.map(s => (
            <MenuItem key={s.id} selected={s.id === dashStyle.id}
                      onClick={() => handleSetStyle(s)}
                      sx={{ display:'flex', alignItems:'center', gap:1.5, minWidth:160 }}>
              <Box sx={{ width:18, height:18, borderRadius:'50%', bgcolor:s.dot,
                         border:2, borderColor: s.id===dashStyle.id ? 'primary.main' : 'transparent',
                         flexShrink:0 }} />
              <Box>
                <Typography variant="body2" fontWeight={s.id===dashStyle.id ? 700 : 400}>{s.name}</Typography>
                <Box sx={{ width:80, height:6, borderRadius:1,
                           background: s.headerBg, mt:0.3 }} />
              </Box>
            </MenuItem>
          ))}
        </Menu>

        <Button startIcon={<AddIcon />} variant="outlined" size="small"
                onClick={() => setCreateOpen(true)}>
          New Dashboard
        </Button>

        {selected && (
          <>
            <Button startIcon={<AddIcon />} variant="contained" size="small"
                    onClick={() => { setPendingSlot(null); setAddOpen(true); }}>
              Add Widget
            </Button>
            <Tooltip title="Apply a layout template to arrange widgets">
              <Button startIcon={<LayoutIcon />} variant="outlined" size="small"
                      onClick={() => setLayoutOpen(true)}>
                Layout
              </Button>
            </Tooltip>
            <Tooltip title="Print dashboard as PDF (browser print dialog)">
              <Button startIcon={<PrintIcon />} variant="outlined" size="small"
                      onClick={() => window.print()}>
                Print
              </Button>
            </Tooltip>
            <Tooltip title="Copy shareable link to this dashboard">
              <Button startIcon={<LinkIcon />} variant="outlined" size="small"
                      onClick={handleCopyLink}>
                Share
              </Button>
            </Tooltip>
            <Tooltip title="Delete this dashboard">
              <IconButton size="small" color="error" onClick={handleDeleteDashboard}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </>
        )}
      </Box>

      {/* Selected dashboard description */}
      {selected?.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb:1, pl:0.5 }}>
          {selected.description}
        </Typography>
      )}

      {/* Cross-filter chips bar — Phase 63 */}
      {crossFilters.length > 0 && (
        <Box sx={{ display:'flex', gap:0.5, mb:1, flexWrap:'wrap', alignItems:'center', px:0.5 }}>
          <FilterIcon sx={{ fontSize:16, color:'text.secondary' }} />
          <Typography variant="caption" color="text.secondary" sx={{ mr:0.5 }}>Filters:</Typography>
          {crossFilters.map((f, i) => (
            <Chip key={`${f.column}-${f.value}-${i}`} size="small" variant="outlined" color="primary"
                  label={`${f.column} = ${f.value}`}
                  onDelete={() => setCrossFilters(prev => prev.filter((_, j) => j !== i))} />
          ))}
          <Chip size="small" label="Clear all" onClick={clearCrossFilters} variant="outlined" color="default" />
        </Box>
      )}

      {/* Canvas */}
      {(() => {
        const tplId = selected ? localStorage.getItem(`qs_dash_tpl_${selected.id}`) : null;
        const activeTpl = tplId ? PRESET_LAYOUTS.find(p => p.id === tplId) : null;
        // Slots not yet occupied — widgets fill from slot[0] upwards
        const emptySlots = activeTpl ? activeTpl.slots.slice(widgets.length) : [];
        const placeholderLayouts = emptySlots.map((slot, i) => ({
          i: `slot-${i}`, x: slot.x, y: slot.y, w: slot.w, h: slot.h, minW:2, minH:3,
        }));
        const combinedLayouts = [...layouts, ...placeholderLayouts];
        const showGrid = widgets.length > 0 || emptySlots.length > 0;

        return (
          <Box ref={containerRef} sx={{ flex:1, overflow:'auto', borderRadius:2, p:1, minHeight:0,
                                         background: dashStyle.canvasBg, transition:'background .3s' }}>
            {!selected ? (
              <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                         justifyContent:'center', height:300, gap:2 }}>
                <DashboardIcon sx={{ fontSize:56, color:'text.disabled' }} />
                <Typography color="text.secondary">No dashboards yet — create one to get started</Typography>
                <Button variant="contained" startIcon={<AddIcon />} onClick={() => setCreateOpen(true)}>
                  Create Dashboard
                </Button>
              </Box>
            ) : !showGrid ? (
              /* No template, no widgets — prompt to pick a template or add freely */
              <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                         justifyContent:'center', height:300, gap:2 }}>
                <GridIcon sx={{ fontSize:56, color:'text.disabled' }} />
                <Typography color="text.secondary" textAlign="center">
                  Start by picking a layout template, or add widgets freely
                </Typography>
                <Box sx={{ display:'flex', gap:1 }}>
                  <Button variant="contained" startIcon={<LayoutIcon />}
                          onClick={() => setLayoutOpen(true)}>
                    Pick Template
                  </Button>
                  <Button variant="outlined" startIcon={<AddIcon />} onClick={() => { setPendingSlot(null); setAddOpen(true); }}>
                    Add Widget
                  </Button>
                </Box>
              </Box>
            ) : (
              <GridLayout
                className="layout"
                layout={combinedLayouts}
                cols={12}
                rowHeight={55}
                width={containerWidth - 16}
                onLayoutChange={newLayout => {
                  // Only persist real widget positions
                  const widgetLayouts = newLayout.filter(l => !l.i.startsWith('slot-'));
                  handleLayoutChange(widgetLayouts);
                }}
                draggableHandle=".drag-handle"
                margin={[10, 10]}
              >
                {widgets.map((w, i) => (
                  <div key={String(w.id)}>
                    <WidgetCard
                      widget={w}
                      loadDelay={i * 400}
                      onDelete={handleDeleteWidget}
                      onEdit={handleEditOpen}
                      onChartTypeChange={handleChartTypeChange}
                      cardStyle={dashStyle}
                      crossFilters={crossFilters}
                      onCrossFilter={handleCrossFilter}
                    />
                  </div>
                ))}
                {emptySlots.map((slot, i) => (
                  <div key={`slot-${i}`}>
                    <PlaceholderCard
                      slotIndex={widgets.length + i}
                      isDark={dashStyle.dark}
                      onAdd={() => { setPendingSlot(slot); setAddOpen(true); }}
                    />
                  </div>
                ))}
              </GridLayout>
            )}
          </Box>
        );
      })()}

      {/* Create Dashboard — name + template picker */}
      <Dialog open={createOpen} onClose={() => { setCreateOpen(false); setNewTemplate(null); }}
              maxWidth="md" fullWidth>
        <DialogTitle sx={{ fontWeight:700, pb:0.5 }}>New Dashboard</DialogTitle>
        <DialogContent sx={{ display:'flex', flexDirection:'column', gap:2, pt:1.5 }}>
          <Box sx={{ display:'flex', gap:2 }}>
            <TextField label="Dashboard Name" size="small" required sx={{ flex:1 }}
                       value={newName} onChange={e => setNewName(e.target.value)}
                       onKeyDown={e => e.key === 'Enter' && handleCreateDashboard()} />
            <TextField label="Description (optional)" size="small" sx={{ flex:1 }}
                       value={newDesc} onChange={e => setNewDesc(e.target.value)} />
          </Box>

          <Typography variant="subtitle2" fontWeight={700} sx={{ mt:0.5 }}>
            Choose a Layout Template
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ mt:-1.5 }}>
            Pick a frame for your dashboard. You'll click each slot to fill it with data.
          </Typography>

          <Box sx={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(170px,1fr))', gap:1.5 }}>
            {/* Blank option */}
            <Paper elevation={newTemplate === null ? 3 : 1}
              onClick={() => setNewTemplate(null)}
              sx={{ p:1.5, cursor:'pointer', border:2, borderRadius:2,
                    borderColor: newTemplate === null ? 'primary.main' : 'transparent',
                    display:'flex', flexDirection:'column', gap:1, alignItems:'center',
                    transition:'all .15s' }}>
              <Box sx={{ width:150, height:80, bgcolor:'#f1f5f9', borderRadius:1,
                         display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Typography variant="caption" color="text.secondary">Free-form (no template)</Typography>
              </Box>
              <Typography variant="body2" fontWeight={700} fontSize={13}>Blank</Typography>
              <Typography variant="caption" color="text.secondary">Drag widgets freely</Typography>
            </Paper>

            {PRESET_LAYOUTS.map(preset => (
              <Paper key={preset.id} elevation={newTemplate?.id === preset.id ? 3 : 1}
                onClick={() => setNewTemplate(preset)}
                sx={{ p:1.5, cursor:'pointer', border:2, borderRadius:2,
                      borderColor: newTemplate?.id === preset.id ? 'primary.main' : 'transparent',
                      display:'flex', flexDirection:'column', gap:1, alignItems:'center',
                      transition:'all .15s' }}>
                <LayoutPreview slots={preset.slots} active={newTemplate?.id === preset.id} />
                <Box sx={{ textAlign:'center' }}>
                  <Typography variant="body2" fontWeight={700} fontSize={13}>{preset.name}</Typography>
                  <Typography variant="caption" color="text.secondary">{preset.desc}</Typography>
                </Box>
              </Paper>
            ))}
          </Box>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2 }}>
          <Button onClick={() => { setCreateOpen(false); setNewTemplate(null); }}>Cancel</Button>
          <Button onClick={handleCreateDashboard} variant="contained" disabled={!newName.trim()}>
            Create Dashboard
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Widget */}
      <AddWidgetDialog
        open={addOpen}
        onClose={() => { setAddOpen(false); setPendingSlot(null); }}
        onAdd={handleAddWidget}
        slotPosition={pendingSlot}
      />

      {/* Layout Picker */}
      <LayoutPickerDialog
        open={layoutOpen}
        onClose={() => setLayoutOpen(false)}
        onApply={handleApplyLayout}
      />

      {/* Edit Widget */}
      <EditWidgetDialog
        open={Boolean(editWidget)}
        widget={editWidget?.widget}
        rows={editWidget?.rows || []}
        onClose={() => setEditWidget(null)}
        onSave={handleEditSave}
      />

      <Snackbar open={!!snack} autoHideDuration={3000} onClose={() => setSnack('')}
                message={snack} anchorOrigin={{ vertical:'bottom', horizontal:'right' }} />
    </Box>
  );
}
