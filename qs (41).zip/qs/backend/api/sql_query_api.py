"""
SQL Query API — Trino / Starburst / Snowflake / Databricks

Endpoints:
  GET    /api/sql/queries                      – list saved SQL queries
  POST   /api/sql/queries                      – create saved SQL query
  GET    /api/sql/queries/{id}                 – get single SQL query
  PUT    /api/sql/queries/{id}                 – update SQL query
  DELETE /api/sql/queries/{id}                 – delete SQL query
  POST   /api/sql/execute                      – execute (single or cross-source)
  GET    /api/sql/connections/{id}/catalogs    – list catalogs
  GET    /api/sql/connections/{id}/schemas     – list schemas in a catalog
  GET    /api/sql/connections/{id}/tables      – list tables in catalog.schema
  GET    /api/sql/connections/{id}/columns     – list columns in catalog.schema.table
  POST   /api/sql/connections/{id}/test        – test SQL connection
  GET    /api/sql/connector-types              – list supported connector types + field defs
"""

from __future__ import annotations

import asyncio
import functools
import logging
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

# ── Injected from main.py startup ─────────────────────────────────────────────
_db_manager  = None
_ws_manager  = None
_main_loop   = None
_auth_cfg    = None   # core.config.auth singleton
_sql_executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix="sql_query")  # legacy, phasing out


def set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=None):
    global _db_manager, _ws_manager, _main_loop, _auth_cfg
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop
    _auth_cfg   = auth_cfg


def _get_current_user_sql(request: Request) -> Optional[dict]:
    """Local version of _get_current_user for the SQL router."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True, "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    # Session token (Bearer) — look up server-side session
    if auth_header.startswith("Bearer "):
        from main import _get_session
        user = _get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user
    # Basic auth fallback
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _is_owner_or_shared_sql(item: dict, user: dict) -> bool:
    if not user or user.get("is_admin"):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        from core.worker_pool import get_pool
        _exec = get_pool().executor
    except RuntimeError:
        _exec = _sql_executor
    if kwargs:
        return await loop.run_in_executor(_exec, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_exec, fn, *args)


def _get_connection_record(connection_id: int) -> Dict[str, Any]:
    """Fetch connection with credentials decrypted — for internal engine use only.
    Never return this dict to API clients."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    conn = _db_manager.get_connection_raw(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail=f"Connection {connection_id} not found")
    return conn


def _require_sql_connector_type(conn: Dict[str, Any]) -> str:
    """Return the connection_type and raise if it's not a SQL connector type."""
    from core.connectors import SQL_CONNECTOR_TYPES
    ctype = conn.get("connection_type", "").lower()
    if ctype not in SQL_CONNECTOR_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Connection type '{ctype}' is not a SQL connector. "
                   f"Supported SQL types: {', '.join(SQL_CONNECTOR_TYPES)}"
        )
    return ctype


def _make_connector(conn: Dict[str, Any]):
    from core.connectors import get_connector
    ctype = _require_sql_connector_type(conn)
    return get_connector(ctype, conn.get("config") or {})


def _broadcast(payload: dict):
    if _ws_manager and _main_loop:
        asyncio.run_coroutine_threadsafe(
            _ws_manager.broadcast(payload), _main_loop
        )


# ── Pydantic models ───────────────────────────────────────────────────────────

class CreateSqlQueryRequest(BaseModel):
    name:                   str
    description:            Optional[str] = None
    primary_connection_id:  int
    primary_sql:            str
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None
    created_by:             Optional[str] = None


class UpdateSqlQueryRequest(BaseModel):
    name:                   Optional[str] = None
    description:            Optional[str] = None
    primary_connection_id:  Optional[int] = None
    primary_sql:            Optional[str] = None
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None


class ExecuteSqlRequest(BaseModel):
    query_id:               Optional[int] = None
    primary_connection_id:  Optional[int] = None
    primary_sql:            Optional[str] = None
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None
    row_limit:              Optional[int] = None


# ── Connector types ───────────────────────────────────────────────────────────

@router.get("/api/sql/connector-types")
async def get_connector_types():
    """Return all supported SQL connector types and their config field definitions."""
    from core.connectors import CONNECTOR_FIELDS, CONNECTOR_DISPLAY_NAMES, SQL_CONNECTOR_TYPES
    return {
        "types": SQL_CONNECTOR_TYPES,
        "display_names": CONNECTOR_DISPLAY_NAMES,
        "fields": CONNECTOR_FIELDS,
    }


# ── Saved SQL Queries CRUD ────────────────────────────────────────────────────

@router.get("/api/sql/queries")
async def list_sql_queries(
    request: Request,
    active_only: bool = True,
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    items = await _run_in_executor(
        _db_manager.list_sql_queries, active_only, limit, offset
    )
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sql(request)
        items = [i for i in items if _is_owner_or_shared_sql(i, user)]
    return items


@router.post("/api/sql/queries", status_code=201)
async def create_sql_query(req: CreateSqlQueryRequest, request: Request):
    user = _get_current_user_sql(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    return await _run_in_executor(
        _db_manager.create_sql_query,
        name=req.name,
        description=req.description,
        primary_connection_id=req.primary_connection_id,
        primary_sql=req.primary_sql,
        secondary_connection_id=req.secondary_connection_id,
        secondary_sql=req.secondary_sql,
        join_config=req.join_config,
        created_by=(user or {}).get("username") or req.created_by or "guest",
    )


@router.get("/api/sql/queries/{query_id}")
async def get_sql_query(query_id: int, request: Request):
    q = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not q:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only see own or shared queries
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sql(request)
        if not _is_owner_or_shared_sql(q, user):
            raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    return q


@router.put("/api/sql/queries/{query_id}")
async def update_sql_query(query_id: int, req: UpdateSqlQueryRequest, request: Request):
    user = _get_current_user_sql(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only update their own queries
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(status_code=403, detail="Permission denied")
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    result = await _run_in_executor(_db_manager.update_sql_query, query_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    return result


@router.delete("/api/sql/queries/{query_id}")
async def delete_sql_query(query_id: int, request: Request, permanent: bool = False):
    user = _get_current_user_sql(request)
    if _auth_cfg and _auth_cfg.type != "none":
        role = (user or {}).get("role", "viewer")
        if role not in ("admin", "analyst"):
            raise HTTPException(403, "Requires role: admin, analyst")
    existing = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only delete their own queries
    if _auth_cfg and _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(status_code=403, detail="Permission denied")
    success = await _run_in_executor(
        _db_manager.delete_sql_query, query_id, not permanent
    )
    if not success:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    return {"message": "Deleted", "query_id": query_id}


# ── SQL Query Execution ───────────────────────────────────────────────────────

@router.post("/api/sql/execute")
async def execute_sql_query(req: ExecuteSqlRequest, background_tasks: BackgroundTasks):
    """
    Execute a SQL query on one or two SQL sources.

    Modes:
      1. Saved query by ID:         { "query_id": 5 }
      2. Inline single source:      { "primary_connection_id": 1, "primary_sql": "SELECT ..." }
      3. Inline cross-source join:  { "primary_connection_id": 1, "primary_sql": "...",
                                      "secondary_connection_id": 2, "secondary_sql": "...",
                                      "join_config": { "how": "inner", "left_on": "id", "right_on": "customer_id" } }
    """
    execution_id = str(uuid.uuid4())

    # Resolve the query config
    if req.query_id:
        saved = await _run_in_executor(_db_manager.get_sql_query, req.query_id)
        if not saved:
            raise HTTPException(status_code=404, detail=f"SQL query {req.query_id} not found")
        primary_conn_id    = saved["primary_connection_id"]
        primary_sql        = saved["primary_sql"]
        secondary_conn_id  = saved.get("secondary_connection_id")
        secondary_sql      = saved.get("secondary_sql")
        join_config        = saved.get("join_config")
    else:
        if not req.primary_connection_id or not req.primary_sql:
            raise HTTPException(
                status_code=400,
                detail="Must provide either query_id or (primary_connection_id + primary_sql)"
            )
        primary_conn_id   = req.primary_connection_id
        primary_sql       = req.primary_sql
        secondary_conn_id = req.secondary_connection_id
        secondary_sql     = req.secondary_sql
        join_config       = req.join_config

    # Validate connections
    primary_conn = _get_connection_record(primary_conn_id)
    primary_conn_type   = _require_sql_connector_type(primary_conn)
    primary_conn_config = primary_conn.get("config") or {}

    secondary_conn_type   = None
    secondary_conn_config = None
    if secondary_conn_id:
        secondary_conn = _get_connection_record(secondary_conn_id)
        secondary_conn_type   = _require_sql_connector_type(secondary_conn)
        secondary_conn_config = secondary_conn.get("config") or {}

    # Create DB execution record
    exec_record = await _run_in_executor(
        _db_manager.create_execution,
        execution_id=execution_id,
        query_config={
            "primary_connection_id": primary_conn_id,
            "primary_sql":           primary_sql,
            "secondary_connection_id": secondary_conn_id,
            "secondary_sql":         secondary_sql,
            "join_config":           join_config,
            "query_type":            "sql",
        },
    )

    # Capture event loop for background thread broadcasts
    try:
        current_loop = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    is_cross_source = bool(secondary_conn_id and secondary_sql)

    def _run(cancel_event=None):
        from core.cross_source_engine import (
            execute_cross_source_query,
            execute_single_source_query,
        )

        def _emit(payload):
            loop = current_loop or _main_loop
            if _ws_manager and loop:
                asyncio.run_coroutine_threadsafe(
                    _ws_manager.broadcast({**payload, "execution_id": execution_id}),
                    loop,
                )

        try:
            _emit({"type": "execution_progress", "data": {"status": "starting"}})

            def _progress(info):
                _emit({"type": "execution_progress", "data": {"status": info.get("step"), **info}})

            if is_cross_source:
                result = execute_cross_source_query(
                    primary_conn_type=primary_conn_type,
                    primary_conn_config=primary_conn_config,
                    primary_sql=primary_sql,
                    secondary_conn_type=secondary_conn_type,
                    secondary_conn_config=secondary_conn_config,
                    secondary_sql=secondary_sql,
                    join_config=join_config or {},
                    execution_id=execution_id,
                    row_limit=req.row_limit,
                    progress_callback=_progress,
                )
            else:
                result = execute_single_source_query(
                    conn_type=primary_conn_type,
                    conn_config=primary_conn_config,
                    sql=primary_sql,
                    execution_id=execution_id,
                    row_limit=req.row_limit,
                    progress_callback=_progress,
                )

            # Update execution record
            _db_manager.update_execution(
                execution_id=execution_id,
                status="completed",
                total_rows=result.total_rows,
                output_file=result.output_path,
            )

            # NOTE: raw execution CSVs are temporary grid-pagination files.
            # They are NOT registered in the Download Center.
            # The user exports explicitly via the Export button, which creates a named download.

            # Bump execution count if from saved query
            if req.query_id:
                _db_manager.increment_sql_query_execution(req.query_id)

            _emit({
                "type": "execution_completed",
                "stats": {
                    "total_rows": result.total_rows,
                    "duration_seconds": result.duration_seconds,
                    "primary_rows": result.primary_rows,
                    "secondary_rows": result.secondary_rows,
                }
            })
            logger.info(
                f"[{execution_id}] SQL execution completed: "
                f"{result.total_rows} rows in {result.duration_seconds:.2f}s"
            )

        except Exception as exc:
            logger.exception(f"[{execution_id}] SQL execution failed")
            try:
                _db_manager.update_execution(
                    execution_id=execution_id,
                    status="failed",
                    error_message=str(exc),
                )
            except Exception:
                pass
            _emit({"type": "execution_failed", "error": str(exc)})

    # Submit via unified worker pool (falls back to legacy executor)
    try:
        from core.worker_pool import get_pool, WorkType
        get_pool().submit_sync(WorkType.INTERACTIVE, _run,
                               execution_id=execution_id, username="system")
    except RuntimeError:
        background_tasks.add_task(lambda: _sql_executor.submit(_run))

    return {
        "execution_id": execution_id,
        "status": "running",
        "message": "SQL execution started",
        "is_cross_source": is_cross_source,
    }


# ── Schema browsing ───────────────────────────────────────────────────────────

@router.get("/api/sql/connections/{connection_id}/catalogs")
async def list_catalogs(connection_id: int):
    conn = _get_connection_record(connection_id)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_catalogs()
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing catalogs: {e}")


@router.get("/api/sql/connections/{connection_id}/schemas")
async def list_schemas(connection_id: int, catalog: str = Query(...)):
    conn = _get_connection_record(connection_id)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_schemas(catalog)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing schemas: {e}")


@router.get("/api/sql/connections/{connection_id}/tables")
async def list_tables(
    connection_id: int,
    catalog: str = Query(...),
    schema: str  = Query(...),
):
    conn = _get_connection_record(connection_id)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_tables(catalog, schema)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing tables: {e}")


@router.get("/api/sql/connections/{connection_id}/columns")
async def list_columns(
    connection_id: int,
    catalog: str = Query(...),
    schema:  str = Query(...),
    table:   str = Query(...),
):
    conn = _get_connection_record(connection_id)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_columns(catalog, schema, table)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing columns: {e}")


@router.post("/api/sql/connections/{connection_id}/test")
async def test_sql_connection(connection_id: int):
    conn = _get_connection_record(connection_id)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.test_connection()
        finally:
            connector.close()
    try:
        result = await _run_in_executor(_do)
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("message", "Connection failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Connection test error: {e}")
