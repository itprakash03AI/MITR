"""
Query Studio Scheduler — APScheduler 3.x wrapper.

Runs a BackgroundScheduler backed by SQLAlchemyJobStore (same SQLite DB).
Jobs are submitted to a dedicated 20-thread pool, isolated from the interactive
query_executor so scheduled jobs never starve interactive users.

Job dispatch pattern:
  parquet saved_query  → OptimizedParquetEngine.execute_query → .parquet
  sql_query            → cross_source_engine.execute_single_source_query
  report               → reports_api._run_parquet_report / _run_sql_report

All jobs:
  - record start / completion / failure in the Schedule DB record
  - register the output CSV in DownloadFile
  - broadcast a WebSocket notification
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Module-level references injected at startup ───────────────────────────────
_db_manager  = None
_ws_manager  = None
_main_loop: Optional[asyncio.AbstractEventLoop] = None
_scheduler   = None


def init_scheduler(db_manager, ws_manager, main_loop, db_url: str):
    """
    Create and start the APScheduler BackgroundScheduler.
    Called once during FastAPI startup.
    """
    global _db_manager, _ws_manager, _main_loop, _scheduler

    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = main_loop

    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
    from apscheduler.executors.pool import ThreadPoolExecutor as APSThreadPool
    from sqlalchemy import create_engine
    from sqlalchemy import event as _sa_event

    # Build a dedicated SQLAlchemy engine for the APS jobstore that has
    # the same SQLite pragmas as DatabaseManager: WAL mode + 30-second
    # busy_timeout so APS never fails with SQLITE_BUSY on restart.
    _aps_engine = create_engine(
        db_url,
        connect_args={"check_same_thread": False},
    )

    @_sa_event.listens_for(_aps_engine, "connect")
    def _set_aps_pragmas(dbapi_conn, _conn_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.close()

    jobstore  = SQLAlchemyJobStore(engine=_aps_engine)
    # Limit worker threads so scheduled jobs never starve interactive queries.
    executor  = APSThreadPool(max_workers=4)

    _scheduler = BackgroundScheduler(
        jobstores={"default": jobstore},
        executors={"default": executor},
        job_defaults={
            "coalesce": True,       # collapse missed fires into one
            "max_instances": 1,     # no overlapping runs for the same job
            # Short grace time: skip jobs missed while the server was down for
            # more than 30 s — prevents bulk-firing on restart which would
            # compete with interactive queries for CPU/IO.
            "misfire_grace_time": 30,
        },
        timezone="UTC",
    )
    _scheduler.start()
    logger.info("QueryScheduler started (APScheduler %s)", _aps_version())

    # Re-register all active schedules from DB (APScheduler jobstore already has
    # their trigger state from the previous run; this just refreshes next_run_at)
    schedules = db_manager.list_schedules(active_only=True, limit=1000)
    _bootstrap_schedules(schedules)
    logger.info("Loaded %d active schedule(s) from DB", len(schedules))

    # Add periodic temp-file cleanup — runs every 30 minutes.
    # Deletes raw execution CSVs not registered in the Download Center
    # and any Download Center files whose expiry has passed.
    try:
        from apscheduler.triggers.interval import IntervalTrigger as _IT
        _scheduler.add_job(
            func=_cleanup_temp_files,
            trigger=_IT(minutes=30),
            id="__temp_file_cleanup__",
            name="Temp file cleanup",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered temp-file cleanup job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register cleanup job: %s", _ce)

    # Register query result cache cleanup — runs every 30 minutes
    try:
        from core.query_cache import cleanup_expired as _cache_cleanup
        _scheduler.add_job(
            func=_cache_cleanup,
            trigger=_IT(minutes=30),
            id="__query_cache_cleanup__",
            name="Query cache cleanup",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered query cache cleanup job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register cache cleanup job: %s", _ce)

    # Enforce disk quota on cache + downloads — runs every 30 minutes
    try:
        _scheduler.add_job(
            func=_enforce_storage_quotas,
            trigger=_IT(minutes=30),
            id="__storage_quota__",
            name="Storage quota enforcement",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered storage quota job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register storage quota job: %s", _ce)

    # Prune old execution history — runs once daily
    try:
        from apscheduler.triggers.interval import IntervalTrigger as _DIT
        _scheduler.add_job(
            func=_cleanup_execution_history,
            trigger=_DIT(hours=24),
            id="__execution_history_cleanup__",
            name="Execution history cleanup",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered execution history cleanup job (every 24 h)")
    except Exception as _ce:
        logger.warning("Could not register execution history cleanup job: %s", _ce)

    # Auto-refresh stale partition caches — runs every 5 hours
    try:
        _scheduler.add_job(
            func=_refresh_partition_caches,
            trigger=_IT(hours=5),
            id="__partition_cache_refresh__",
            name="Partition cache refresh",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered partition cache refresh job (every 5 h)")
    except Exception as _pce:
        logger.warning("Could not register partition cache refresh job: %s", _pce)

    return _scheduler


def shutdown_scheduler():
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("QueryScheduler stopped")


def _aps_version() -> str:
    try:
        import apscheduler
        return apscheduler.__version__
    except Exception:
        return "unknown"


def _bootstrap_schedules(schedules: list):
    """After restart, ensure all active schedules have a live APScheduler job."""
    for s in schedules:
        try:
            if s.get("apscheduler_job_id") and _scheduler.get_job(s["apscheduler_job_id"]):
                # Job already exists in jobstore — refresh next_run_at in DB
                job = _scheduler.get_job(s["apscheduler_job_id"])
                if job and job.next_run_time:
                    _db_manager.update_schedule(s["id"], next_run_at=job.next_run_time)
            else:
                # Missing from jobstore (e.g. memory store) — re-add
                job_id = add_schedule(s)
                _db_manager.update_schedule(s["id"], apscheduler_job_id=job_id)
        except Exception as e:
            logger.warning("Could not bootstrap schedule %s: %s", s["id"], e)


# ── Public API called from schedules_api.py ───────────────────────────────────

def add_schedule(schedule_record: dict) -> str:
    """Register a new APScheduler job. Returns the APS job_id."""
    job_id  = f"qs_{schedule_record['id']}_{uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_record["trigger_config"])
    _scheduler.add_job(
        func=_run_scheduled_job,
        trigger=trigger,
        id=job_id,
        args=[schedule_record["id"]],
        name=schedule_record.get("name", job_id),
        replace_existing=True,
    )
    job = _scheduler.get_job(job_id)
    if job and job.next_run_time:
        _db_manager.update_schedule(schedule_record["id"], next_run_at=job.next_run_time)
    return job_id


def remove_schedule(job_id: str):
    if _scheduler and job_id and _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)


def pause_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.pause_job(job_id)


def resume_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.resume_job(job_id)
        job = _scheduler.get_job(job_id)
        return job.next_run_time if job else None


def run_now(schedule_id: int):
    """Submit an immediate (out-of-schedule) run without affecting the trigger."""
    try:
        from core.worker_pool import get_pool, WorkType
        get_pool().submit_sync(WorkType.SCHEDULED, _run_scheduled_job, schedule_id,
                               username="scheduler")
    except RuntimeError:
        _rpt_executor().submit(_run_scheduled_job, schedule_id)


def get_next_run(job_id: str) -> Optional[datetime]:
    if not _scheduler or not job_id:
        return None
    job = _scheduler.get_job(job_id)
    return job.next_run_time if job else None


def get_scheduler_status() -> Dict[str, Any]:
    if not _scheduler:
        return {"running": False}
    jobs = _scheduler.get_jobs()
    return {
        "running": _scheduler.running,
        "total_jobs": len(jobs),
        "jobs": [
            {
                "id": j.id,
                "name": j.name,
                "next_run_time": j.next_run_time.isoformat() if j.next_run_time else None,
            }
            for j in jobs
        ],
    }


# ── Trigger builder ───────────────────────────────────────────────────────────

def _build_trigger(trigger_config: dict):
    from apscheduler.triggers.cron     import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger

    ttype = trigger_config.get("type")
    if ttype == "cron":
        expr = trigger_config.get("cron_expr", "")
        return CronTrigger.from_crontab(expr, timezone="UTC")
    elif ttype == "interval":
        kwargs = {k: v for k, v in trigger_config.items() if k not in ("type",)}
        return IntervalTrigger(**kwargs, timezone="UTC")
    raise ValueError(f"Unknown trigger type '{ttype}'. Use 'cron' or 'interval'.")


# ── Lazy executor reference (avoids circular import) ─────────────────────────

def _rpt_executor():
    from concurrent.futures import ThreadPoolExecutor
    # Use a module-level singleton so we don't create new pools each call
    if not hasattr(_rpt_executor, "_pool"):
        _rpt_executor._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_run_now")
    return _rpt_executor._pool


# ── WS broadcast helper ───────────────────────────────────────────────────────

def _broadcast(payload: dict):
    if _ws_manager and _main_loop:
        try:
            asyncio.run_coroutine_threadsafe(_ws_manager.broadcast(payload), _main_loop)
        except Exception:
            pass


# ── Email helper ──────────────────────────────────────────────────────────────

def _send_schedule_email(
    schedule: dict,
    status: str,
    output_path: Optional[str] = None,
    row_count: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    error_message: Optional[str] = None,
    run_at: Optional[str] = None,
) -> None:
    """Send email notification for a scheduled job if addresses are configured."""
    raw_emails = (schedule.get("notify_emails") or "").strip()
    if not raw_emails:
        return

    to_addresses = [e.strip() for e in raw_emails.split(",") if e.strip()]
    if not to_addresses:
        return

    try:
        from core.email_service import send_email, build_schedule_completion_email, is_email_enabled
        if not is_email_enabled():
            return
        subject, html = build_schedule_completion_email(
            schedule_name=schedule.get("name", "Unknown"),
            status=status,
            output_file=output_path,
            row_count=row_count,
            duration_seconds=duration_seconds,
            error_message=error_message,
            run_at=run_at,
        )
        send_email(to_addresses, subject, html)
    except Exception as exc:
        logger.warning("[scheduler] Email notification failed: %s", exc)


# ── Webhook helper ─────────────────────────────────────────────────────────────

def _send_schedule_webhook(
    schedule: dict,
    status: str,
    output_path: Optional[str] = None,
    row_count: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    error_message: Optional[str] = None,
    run_at: Optional[str] = None,
) -> None:
    """Fire webhook notification for a scheduled job if a webhook URL is configured."""
    url = (schedule.get("notify_webhook") or "").strip()
    if not url:
        return
    try:
        from core.webhook_service import fire_webhook
        fire_webhook(
            webhook_url=url,
            schedule_name=schedule.get("name", "Unknown"),
            status=status,
            output_file=output_path,
            row_count=row_count,
            duration_seconds=duration_seconds,
            error_message=error_message,
            run_at=run_at,
        )
    except Exception as exc:
        logger.warning("[scheduler] Webhook notification failed: %s", exc)


# ── Job body — runs inside APScheduler's thread pool ─────────────────────────

def _run_scheduled_job(schedule_id: int, cancel_event=None):
    """
    Called by APScheduler in a worker thread (or via the unified WorkerPool).
    1. Loads schedule from DB
    2. Executes the source query with param_values
    3. Saves output to downloads directory
    4. Registers DownloadFile record
    5. Updates Schedule run tracking
    6. Broadcasts WebSocket notification
    """
    schedule = _db_manager.get_schedule(schedule_id)
    if not schedule or not schedule.get("is_active"):
        return

    execution_id  = str(uuid.uuid4())
    source_type   = schedule["source_type"]
    source_id     = schedule["source_id"]
    param_values  = schedule.get("param_values") or {}
    name          = schedule.get("name", f"schedule:{schedule_id}")

    logger.info("[scheduler] Starting schedule %s '%s' → exec %s", schedule_id, name, execution_id[:8])

    _broadcast({
        "type":          "scheduled_job_started",
        "schedule_id":   schedule_id,
        "schedule_name": name,
        "execution_id":  execution_id,
        "timestamp":     datetime.now(timezone.utc).isoformat(),
    })

    output_dir = Path("./data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Resolve business date shortcuts at job run time (today, month_start, -7d, etc.)
        from api.reports_api import resolve_business_dates
        param_values = resolve_business_dates(param_values)

        if source_type == "saved_query":
            output_path, total_rows = _exec_parquet_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "sql_query":
            output_path, total_rows = _exec_sql_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "report":
            output_path, total_rows = _exec_report(source_id, param_values, execution_id, output_dir)
        else:
            raise ValueError(f"Unknown source_type '{source_type}'")

        # Build filename from template
        template = schedule.get("output_filename_template") or \
                   f"sched_{{name}}_{{date}}.csv"
        filename = (
            template
            .replace("{name}", name.replace(" ", "_"))
            .replace("{date}", datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"))
        )

        # Register in DownloadFile
        file_id = str(uuid.uuid4())
        csv_path = Path(output_path)
        if csv_path.exists():
            _db_manager.create_download_file(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=str(csv_path),
                file_size_bytes=csv_path.stat().st_size,
                expires_at=datetime.now(timezone.utc) + timedelta(days=7),
                created_by=f"scheduler:{name}",
            )

        # Update schedule run status
        next_run = get_next_run(schedule.get("apscheduler_job_id", ""))
        _db_manager.update_schedule(
            schedule_id,
            last_run_at=datetime.now(timezone.utc),
            last_run_status="success",
            last_run_file_id=file_id,
            last_error=None,
            next_run_at=next_run,
        )
        _db_manager.increment_schedule_run_count(schedule_id)

        _broadcast({
            "type":          "scheduled_job_completed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "execution_id":  execution_id,
            "file_id":       file_id,
            "total_rows":    total_rows,
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })
        logger.info(
            "[scheduler] Schedule %s completed: %d rows → %s",
            schedule_id, total_rows, filename,
        )
        _send_schedule_email(schedule, "completed",
                             output_path=str(csv_path),
                             row_count=total_rows,
                             run_at=datetime.now(timezone.utc).isoformat())
        _send_schedule_webhook(schedule, "completed",
                               output_path=str(csv_path),
                               row_count=total_rows,
                               run_at=datetime.now(timezone.utc).isoformat())

    except Exception as exc:
        logger.exception("[scheduler] Schedule %s failed: %s", schedule_id, exc)
        _db_manager.update_schedule(
            schedule_id,
            last_run_at=datetime.now(timezone.utc),
            last_run_status="failed",
            last_error=str(exc),
        )
        _broadcast({
            "type":          "scheduled_job_failed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "error":         str(exc),
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })
        _send_schedule_email(schedule, "failed",
                             error_message=str(exc),
                             run_at=datetime.now(timezone.utc).isoformat())
        _send_schedule_webhook(schedule, "failed",
                               error_message=str(exc),
                               run_at=datetime.now(timezone.utc).isoformat())


# ── Temp-file cleanup ─────────────────────────────────────────────────────────

def _cleanup_temp_files():
    """
    Delete stale files from the downloads directory:

    1. Raw execution CSVs/parquets (not registered in Download Center) older than 1 hour.
       These are temp files created by interactive SQL report runs for grid pagination.
       They accumulate fast with many users and are useless after the user closes
       the result grid.

    2. Download Center files whose expires_at has passed (user exports kept 7 days).
    """
    import re as _re
    # Use the configured path rather than a hardcoded relative path
    try:
        from core.config import paths as _cfg_paths
        downloads_dir = Path(_cfg_paths.downloads_dir)
    except Exception:
        downloads_dir = Path("./data/downloads")
    if not downloads_dir.exists():
        return

    now        = datetime.now(timezone.utc)
    cutoff     = now - timedelta(hours=1)   # raw temp files older than 1 hour
    deleted    = 0
    uuid_pat   = _re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(csv|parquet|xlsx|json)$",
        _re.IGNORECASE,
    )

    # Build set of file paths currently tracked in Download Center
    try:
        tracked = {
            r["file_path"]
            for r in (_db_manager.list_download_files(status="available", limit=10000, offset=0) or [])
        }
    except Exception:
        tracked = set()

    for f in downloads_dir.iterdir():
        if not f.is_file():
            continue
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc)
            str_path = str(f)

            # Case 1: UUID-named file not in Download Center → raw temp → delete if old
            if uuid_pat.match(f.name) and str_path not in tracked and mtime < cutoff:
                f.unlink()
                deleted += 1
                continue

            # Case 2: tracked but expired (expires_at column checked separately below)
        except OSError:
            pass

    # Case 2: Delete expired Download Center records + their files
    try:
        expired_records = _db_manager.list_download_files(status="expired", limit=10000, offset=0) or []
        for rec in expired_records:
            fp = Path(rec.get("file_path", ""))
            if fp.exists():
                try:
                    fp.unlink()
                    deleted += 1
                except OSError:
                    pass
    except Exception:
        pass

    if deleted:
        logger.info("[cleanup] Deleted %d stale file(s) from downloads/", deleted)


def _enforce_storage_quotas():
    """Enforce configurable disk quotas on cache and downloads directories.

    Called by APScheduler every 30 minutes.  Non-fatal — any exception is logged
    and swallowed so it never disrupts the scheduler thread.
    """
    try:
        from core.config import storage as _stg_cfg, cache as _cache_cfg
        from core.query_cache import enforce_size_limit as _cache_quota

        # ── Cache quota ───────────────────────────────────────────────────────
        max_cache = _stg_cfg.max_cache_size_mb
        if max_cache > 0:
            freed = _cache_quota(max_cache)
            if freed:
                logger.info("[quota] Cache: freed %d MB (limit %d MB)", freed, max_cache)

        # ── Downloads quota ───────────────────────────────────────────────────
        max_dl = _stg_cfg.max_downloads_size_mb
        if _db_manager and max_dl > 0:
            dl_bytes = _db_manager.get_downloads_size_bytes()
            dl_mb    = dl_bytes // (1024 * 1024)
            if dl_mb > max_dl:
                # Expire oldest tracked downloads until we're under the limit.
                # Aim to keep at most (max_dl / avg_file_size) files; use a
                # conservative estimate of 50 MB per file if no data available.
                import math
                records = _db_manager.list_download_files(status="available",
                                                          limit=10000, offset=0) or []
                if records:
                    avg_bytes = dl_bytes / len(records)
                    keep = max(0, math.floor(max_dl * 1024 * 1024 / avg_bytes))
                    expired = _db_manager.expire_oldest_downloads(keep)
                    if expired:
                        logger.warning(
                            "[quota] Downloads: expired %d records to stay under %d MB "
                            "(was %d MB)", expired, max_dl, dl_mb
                        )
    except Exception as exc:
        logger.warning("[quota] Storage quota enforcement error: %s", exc)


def _cleanup_execution_history():
    """Delete old QueryExecution rows AND their output parquet files.

    Called by APScheduler once daily.
    """
    try:
        from core.config import scheduler as _sched_cfg
        retention = _sched_cfg.execution_retention_days
        if _db_manager and retention > 0:
            deleted, file_paths = _db_manager.cleanup_old_executions(retention_days=retention)
            # Delete the actual parquet output files so disk doesn't grow unbounded
            files_deleted = 0
            bytes_freed = 0
            for fp in file_paths:
                try:
                    p = Path(fp)
                    if p.exists():
                        bytes_freed += p.stat().st_size
                        p.unlink()
                        files_deleted += 1
                except OSError:
                    pass
            if deleted:
                logger.info(
                    "[cleanup] Pruned %d execution records older than %d days; "
                    "deleted %d file(s) (%.1f MB freed)",
                    deleted, retention, files_deleted, bytes_freed / (1024 * 1024),
                )
    except Exception as exc:
        logger.warning("[cleanup] Execution history cleanup error: %s", exc)


def _refresh_partition_caches():
    """Auto-refresh stale partition caches from S3.

    Called by APScheduler every 5 hours.  Iterates all cached entries in
    SQLite, re-scans each from S3 (full_scan), and updates both the DB
    and the in-memory L1 cache.
    """
    if not _db_manager:
        return
    try:
        entries = _db_manager.list_partition_cache_entries()
        if not entries:
            return
        # Only refresh entries older than 4.5 hours (avoid double-refreshing near boundary)
        stale_cutoff = datetime.now(timezone.utc) - timedelta(hours=4, minutes=30)
        stale = []
        for e in entries:
            updated = e.get("updated_at")
            if isinstance(updated, str):
                updated = datetime.fromisoformat(updated).replace(tzinfo=timezone.utc)
            if updated and updated < stale_cutoff:
                stale.append(e)

        if not stale:
            logger.debug("[partition-cache] No stale entries to refresh")
            return

        # De-duplicate by (connection_id, table_name) — refresh once per table
        seen = set()
        tables_to_refresh = []
        for e in stale:
            key = (e["connection_id"], e["table_name"])
            if key not in seen:
                seen.add(key)
                tables_to_refresh.append(key)

        refreshed = 0
        for conn_id, tname in tables_to_refresh:
            try:
                conn_raw = _db_manager.get_connection_raw(conn_id)
                if not conn_raw:
                    continue
                cfg = conn_raw.get("config", {})
                reg_tables = cfg.get("registered_tables", [])
                tdef = next((t for t in reg_tables if t["name"] == tname), None)
                if not tdef or tdef.get("format") != "iceberg":
                    continue

                from core.iceberg_reader import get_iceberg_partition_values
                # Build S3 client — import from main to reuse cached handlers
                try:
                    from main import _make_s3_client_for_conn
                    s3 = _make_s3_client_for_conn(conn_raw)
                except Exception:
                    continue

                bucket = cfg["bucket_name"]
                result = get_iceberg_partition_values(
                    s3, bucket, tdef["s3_prefix"], full_scan=True
                )
                now_iso = datetime.now(timezone.utc).isoformat()
                stamped = {**result, "cached_at": now_iso}
                for stype in ("fast", "full"):
                    _db_manager.set_partition_cache(conn_id, tname, stype, stamped)

                # Update L1 in-memory cache too
                try:
                    from main import _partition_l1_set
                    for stype in ("fast", "full"):
                        _partition_l1_set(f"{conn_id}:{tname}::{stype}", stamped)
                except Exception:
                    pass

                refreshed += 1
                logger.info("[partition-cache] Refreshed %d/%d: %s",
                            refreshed, len(tables_to_refresh), tname)
            except Exception as exc:
                logger.warning("[partition-cache] Error refreshing %s:%s — %s",
                               conn_id, tname, exc)

        if refreshed:
            logger.info("[partition-cache] Refresh complete: %d/%d tables refreshed",
                        refreshed, len(tables_to_refresh))
    except Exception as exc:
        logger.warning("[partition-cache] Partition cache refresh error: %s", exc)


# ── Per-source execution helpers ──────────────────────────────────────────────

def _exec_parquet_query(query_id: int, param_values: dict,
                        execution_id: str, output_dir: Path):
    from api.reports_api import substitute_filter_params

    saved_q = _db_manager.get_query(query_id)
    if not saved_q:
        raise ValueError(f"Saved query {query_id} not found")

    qc = dict(saved_q["query_config"])
    if param_values and qc.get("filters"):
        qc["filters"] = substitute_filter_params(qc["filters"], param_values)

    import pandas as _pd

    # If the saved query was built against a SQL connector (Trino/Starburst etc.)
    # route it through the connector instead of the local parquet engine.
    conn_id = qc.get("connection_id")
    if conn_id:
        conn_record = _db_manager.get_connection_raw(conn_id)
        if conn_record:
            _conn_type = conn_record.get("connection_type", "")
            _SQL_TYPES = {"trino", "starburst", "snowflake", "databricks", "oracle"}
            if _conn_type in _SQL_TYPES:
                from core.connectors import get_connector
                from core.parquet_engine_v2 import ParquetQueryEngine as _PQE, QueryConfig as _PQC
                connector = get_connector(_conn_type, conn_record.get("config", {}))
                table_ref = qc.get("files", [None])[0]
                if not table_ref:
                    raise ValueError("No table specified in saved query config")
                # Build SQL using the parquet engine's SQL builder (safe — no file I/O)
                _build_eng = _PQE(base_path=".")
                engine_cfg = _PQC(
                    files=[table_ref],
                    columns=qc.get("columns"),
                    filters=qc.get("filters"),
                    joins=qc.get("joins"),
                    order_by=qc.get("order_by"),
                    limit=qc.get("limit") or 1_000_000,
                    offset=qc.get("offset", 0),
                    group_by=qc.get("group_by"),
                    aggregations=qc.get("aggregations"),
                )
                sql_str = _build_eng.build_query_sql(engine_cfg, table_ref)
                result = connector.execute_query(sql_str)
                rows = result.get("rows", [])
                col_names = [c["name"] for c in result.get("columns", [])]
                df = _pd.DataFrame(rows, columns=col_names) if rows else _pd.DataFrame(columns=col_names)
                output_path = str(output_dir / f"{execution_id}.parquet")
                df.to_parquet(output_path, index=False, engine="pyarrow")
                return output_path, len(df)
            elif _conn_type in ("local", "s3"):
                from core.s3_storage import build_s3_config
                from core.parquet_engine_v2 import ParquetQueryEngine
                _cfg = conn_record.get("config", {})
                if _conn_type == "s3":
                    active_engine = ParquetQueryEngine(
                        base_path="./data/parquet",
                        s3_config=build_s3_config(_cfg),
                    )
                else:
                    import os
                    active_engine = ParquetQueryEngine(
                        base_path=_cfg.get("base_path", "./data/parquet"),
                    )
                from core.parquet_engine_v2 import QueryConfig as PQC
                config = PQC(
                    files=qc.get("files", []),
                    columns=qc.get("columns"),
                    filters=qc.get("filters"),
                    joins=qc.get("joins"),
                    order_by=qc.get("order_by"),
                    limit=qc.get("limit") or 1_000_000,
                    offset=qc.get("offset", 0),
                )
                chunks = list(active_engine.execute_query(config))
                df = _pd.concat(chunks, ignore_index=True) if chunks else _pd.DataFrame()
                output_path = str(output_dir / f"{execution_id}.parquet")
                df.to_parquet(output_path, index=False, engine="pyarrow")
                return output_path, len(df)

    # Default: local parquet engine
    from core.optimized_engine import OptimizedParquetEngine, QueryConfig as OptQC
    engine = OptimizedParquetEngine(data_dir="./data/parquet")
    config = OptQC(
        files=qc.get("files", []),
        columns=qc.get("columns"),
        filters=qc.get("filters"),
        joins=qc.get("joins"),
        order_by=qc.get("order_by"),
        limit=qc.get("limit") or 1_000_000,
        offset=qc.get("offset", 0),
    )
    chunks = list(engine.execute_query(config))
    df = _pd.concat(chunks, ignore_index=True) if chunks else _pd.DataFrame()
    output_path = str(output_dir / f"{execution_id}.parquet")
    df.to_parquet(output_path, index=False, engine="pyarrow")
    return output_path, len(df)


def _exec_sql_query(query_id: int, param_values: dict,
                    execution_id: str, output_dir: Path):
    from core.cross_source_engine import execute_single_source_query, execute_cross_source_query
    from api.reports_api import substitute_sql_params

    sql_q = _db_manager.get_sql_query(query_id)
    if not sql_q:
        raise ValueError(f"SQL query {query_id} not found")

    primary_conn = _db_manager.get_connection_raw(sql_q["primary_connection_id"])
    if not primary_conn:
        raise ValueError(f"Connection {sql_q['primary_connection_id']} not found")

    primary_sql = substitute_sql_params(sql_q["primary_sql"], param_values, [])

    is_cross = bool(sql_q.get("secondary_connection_id") and sql_q.get("secondary_sql"))
    if is_cross:
        secondary_conn = _db_manager.get_connection_raw(sql_q["secondary_connection_id"])
        secondary_sql  = substitute_sql_params(sql_q["secondary_sql"], param_values, [])
        result = execute_cross_source_query(
            primary_conn_type=primary_conn["connection_type"],
            primary_conn_config=primary_conn["config"],
            primary_sql=primary_sql,
            secondary_conn_type=secondary_conn["connection_type"],
            secondary_conn_config=secondary_conn["config"],
            secondary_sql=secondary_sql,
            join_config=sql_q.get("join_config") or {},
            execution_id=execution_id,
            output_dir=str(output_dir),
        )
    else:
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            execution_id=execution_id,
            output_dir=str(output_dir),
        )
    return result.output_path, result.total_rows


def _exec_report(report_id: int, param_values: dict,
                 execution_id: str, output_dir: Path):
    from api.reports_api import (
        _run_parquet_report, _run_sql_report, substitute_filter_params
    )

    report = _db_manager.get_report(report_id)
    if not report:
        raise ValueError(f"Report {report_id} not found")

    # Both parquet-backed and SQL-backed reports write .parquet
    output_path = str(output_dir / f"{execution_id}.parquet")
    noop_emit = lambda _: None

    if report["saved_query_id"]:
        total_rows = _run_parquet_report(report, param_values, None, output_path, noop_emit)
    elif report["sql_saved_query_id"]:
        total_rows = _run_sql_report(report, param_values, None, execution_id, noop_emit)
        # SQL engine writes {execution_id}.parquet via cross_source_engine
    else:
        raise ValueError(f"Report {report_id} has no source configured")

    return output_path, total_rows
