/**
 * columnPatterns.ts — Column classification, FAQ, and glossary for the AI Assistant.
 *
 * All values are loaded at runtime from GET /api/suggest/chatbot-patterns,
 * which reads from backend/config.json under the "chatbot" section.
 *
 * To teach the chatbot — edit backend/config.json:
 *   "chatbot.numeric_patterns"  / "category_patterns" / "date_patterns" / "id_patterns"
 *     → column name substrings for chip suggestions
 *   "chatbot.faq"
 *     → { "keyword phrase": "answer text" } — instant answers for org-specific Q&A
 *   "chatbot.glossary"
 *     → { "business term": "column_name" } — substituted before NL-to-SQL runs
 *
 * Local arrays below are DEFAULT FALLBACKS (active before the API responds or on error).
 */

// ── Default fallback patterns (used before API responds or on error) ──────────

const DEFAULT_NUMERIC: string[] = [
  'amount', 'balance', 'debit', 'credit', 'payment', 'charge',
  'revenue', 'income', 'expense', 'cost', 'price', 'fee', 'tax',
  'profit', 'margin', 'discount', 'interest', 'principal', 'penalty',
  'salary', 'wage', 'bonus', 'commission',
  'total', 'subtotal', 'value', 'rate', 'ratio', 'percentage', 'percent',
  'qty', 'quantity', 'count', 'number', 'num', 'volume', 'weight', 'size',
  'score', 'rank', 'metric', 'measure', 'kpi',
];

const DEFAULT_CATEGORY: string[] = [
  'status', 'state', 'flag', 'indicator', 'active', 'enabled',
  'type', 'category', 'class', 'kind', 'level', 'tier', 'grade', 'segment',
  'dept', 'department', 'division', 'team', 'group', 'unit', 'branch',
  'entity', 'company', 'organisation', 'organization', 'business',
  'country', 'region', 'city', 'zone', 'area', 'location', 'site',
  'currency', 'ccy', 'source', 'channel', 'product',
  'brand', 'vendor', 'supplier', 'customer', 'client',
];

const DEFAULT_DATE: string[] = [
  'date', 'dt', 'time', 'ts', 'timestamp',
  'period', 'month', 'year', 'day', 'week', 'quarter',
  'fiscal', 'posted', 'effective', 'settlement', 'maturity', 'created',
  'updated', 'modified', 'processed', 'received', 'booked',
];

const DEFAULT_ID: string[] = [
  '_id', '_key', '_ref', '_uuid', '_guid', '_code', '_num', '_no',
  '_hash', '_token', '_seq', 'id_', 'key_', 'ref_', 'uuid_',
];

// ── Live stores (populated by fetchChatbotPatterns) ──────────────────────────

let NUMERIC_PATTERNS:   string[] = [...DEFAULT_NUMERIC];
let CATEGORY_PATTERNS:  string[] = [...DEFAULT_CATEGORY];
let DATE_PATTERNS:      string[] = [...DEFAULT_DATE];
let ID_PATTERNS:        string[] = [...DEFAULT_ID];
let FAQ_STORE:          Record<string, string> = {};
let GLOSSARY_STORE:     Record<string, string> = {};

/** Merge API patterns with local defaults (dedup, keep all). */
function mergeUnique(base: string[], extra: string[]): string[] {
  const set = new Set(base.map(s => s.toLowerCase()));
  const result = [...base];
  for (const p of extra) {
    if (!set.has(p.toLowerCase())) {
      result.push(p);
      set.add(p.toLowerCase());
    }
  }
  return result;
}

/** Fetch patterns from backend and merge into live store. Call once on app init. */
export async function fetchChatbotPatterns(): Promise<void> {
  try {
    // Import getAuthHeader lazily to avoid circular dependency issues at module load time
    const { getAuthHeader } = await import('../context/AuthContext');
    const authHeader = getAuthHeader();
    const headers: Record<string, string> = {};
    if (authHeader) headers['Authorization'] = authHeader;
    const res = await fetch('/api/suggest/chatbot-patterns', { headers });
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data.numeric_patterns))  NUMERIC_PATTERNS  = mergeUnique(DEFAULT_NUMERIC,   data.numeric_patterns);
    if (Array.isArray(data.category_patterns)) CATEGORY_PATTERNS = mergeUnique(DEFAULT_CATEGORY, data.category_patterns);
    if (Array.isArray(data.date_patterns))     DATE_PATTERNS     = mergeUnique(DEFAULT_DATE,     data.date_patterns);
    if (Array.isArray(data.id_patterns))       ID_PATTERNS       = mergeUnique(DEFAULT_ID,       data.id_patterns);
    if (data.faq && typeof data.faq === 'object')         FAQ_STORE     = data.faq;
    if (data.glossary && typeof data.glossary === 'object') GLOSSARY_STORE = data.glossary;
  } catch {
    // Network error or auth error — keep defaults, no action needed
  }
}

// ── Exported accessors (always up-to-date after fetchChatbotPatterns resolves) ─

export function getNumericPatterns():  string[] { return NUMERIC_PATTERNS; }
export function getCategoryPatterns(): string[] { return CATEGORY_PATTERNS; }
export function getDatePatterns():     string[] { return DATE_PATTERNS; }
export function getIdPatterns():       string[] { return ID_PATTERNS; }
export function getFaq():              Record<string, string> { return FAQ_STORE; }
export function getGlossary():         Record<string, string> { return GLOSSARY_STORE; }

/**
 * Find a FAQ answer for the user's input.
 * Returns the answer string if any FAQ key is a substring of the input, or null.
 * Longer keys are tried first (most specific match wins).
 */
export function findFaqAnswer(input: string): string | null {
  const q = input.toLowerCase().trim();
  const entries = Object.entries(FAQ_STORE).sort((a, b) => b[0].length - a[0].length);
  for (const [key, answer] of entries) {
    if (q.includes(key.toLowerCase())) return answer;
  }
  return null;
}

// ── Helpers used by GlobalAssistantPanel ──────────────────────────────────────

/** Returns true if col name matches any pattern in the list (case-insensitive). */
export function matchesAny(col: string, patterns: string[]): boolean {
  const cl = col.toLowerCase();
  return patterns.some(p => cl.includes(p.toLowerCase()));
}

export function isNumericCol(col: string): boolean {
  return matchesAny(col, NUMERIC_PATTERNS) && !isDateCol(col) && !isIdCol(col);
}
export function isCategoryCol(col: string): boolean {
  return matchesAny(col, CATEGORY_PATTERNS) && !isNumericCol(col) && !isDateCol(col);
}
export function isDateCol(col: string): boolean {
  return matchesAny(col, DATE_PATTERNS);
}
export function isIdCol(col: string): boolean {
  return matchesAny(col, ID_PATTERNS);
}
