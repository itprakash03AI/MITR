/**
 * Admin Panel — QueryStudio Enterprise
 * Two-panel layout: left nav sidebar + right content area.
 * Only the active section loads data & polls.
 */
// @ts-nocheck
import React, { useState, useEffect, useCallback, useRef, Fragment } from 'react';
import {
  Box, Typography, Paper, Chip, Button, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TextField, InputAdornment, Divider, Alert, MenuItem,
  FormControl, InputLabel, Select,
  LinearProgress, Tooltip, Stack, IconButton, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions, Avatar, Collapse,
  List, ListItemButton, ListItemIcon, ListItemText,
  Switch, FormControlLabel,
  useTheme,
} from '@mui/material';
import {
  CheckCircle as OkIcon,
  Error as ErrIcon,
  Warning as WarnIcon,
  Refresh as RefreshIcon,
  CleaningServices as CleanupIcon,
  DeleteSweep as ClearCacheIcon,
  Storage as StorageIcon,
  FolderOpen as FolderIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Security as AuditIcon,
  Memory as CacheIcon,
  MonitorHeart as HealthIcon,
  Cancel as CancelIcon,
  PlayCircleOutline as ActiveIcon,
  AccessTime as DurationIcon,
  Block as BlockedIcon,
  Groups as UsersIcon,
  HourglassTop as RunningIcon,
  Settings as SettingsIcon,
  Save as SaveIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  PauseCircle as PauseIcon,
  Schedule as ScheduleIcon,
  Assessment as ActivityIcon,
  History as HistoryIcon,
  Hub as QueueIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  SwapHoriz as SwapHorizIcon,
  Edit as EditIconMui,
  Workspaces as WorkspacesIcon,
  PersonAdd as PersonAddIcon,
  GppGood as GppGoodIcon,
  VisibilityOff as VisibilityOffIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { getAuthHeader } from '../context/AuthContext';
import api from '../services/api';

const API_BASE = import.meta.env.VITE_API_URL || '';

/** Authenticated fetch — injects Authorization header automatically. */
const authFetch = (url: string, opts: RequestInit = {}) => {
  const h = getAuthHeader();
  const headers: Record<string, string> = { ...(opts.headers as any) };
  if (h) headers['Authorization'] = h;
  return fetch(url, { ...opts, headers });
};

// ── Formatters ──────────────────────────────────────────────────────────────
const fmtSize = (bytes: number) => {
  if (!bytes) return '0 B';
  const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${s[i]}`;
};
const fmtMb   = (mb: number) => mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb} MB`;
const fmtDate = (s: string)  => s ? new Date(s).toLocaleString() : '—';
const fmtDuration = (secs: number) => {
  if (secs < 60)   return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
};

// ── Stat card ───────────────────────────────────────────────────────────────
const StatCard = ({ label, value, sub = '', warn = false }) => (
  <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 120 }}>
    <Typography variant="caption" color="text.secondary">{label}</Typography>
    <Typography variant="h5" fontWeight={700}
      color={warn ? 'error.main' : 'text.primary'}>
      {value}
    </Typography>
    {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
  </Paper>
);

// ── Status chip ─────────────────────────────────────────────────────────────
const StatusChip = ({ ok, label = '' }) => (
  <Chip
    size="small"
    icon={ok
      ? <OkIcon  sx={{ fontSize: '14px !important' }} />
      : <ErrIcon sx={{ fontSize: '14px !important' }} />}
    label={label || (ok ? 'OK' : 'Error')}
    color={ok ? 'success' : 'error'}
    variant="outlined"
  />
);

// ── Live duration ticker ────────────────────────────────────────────────────
const LiveDuration = ({ seconds: initial, warn }) => {
  const [secs, setSecs] = useState(initial);
  useEffect(() => {
    setSecs(initial);
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [initial]);
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <DurationIcon sx={{ fontSize: 14, color: warn ? 'error.main' : 'text.secondary' }} />
      <Typography variant="body2" fontWeight={warn ? 700 : 400}
        color={warn ? 'error.main' : 'text.primary'}>
        {fmtDuration(secs)}
      </Typography>
    </Box>
  );
};

// ── Admin sections definition ───────────────────────────────────────────────
type AdminSection =
  | 'activeQueries' | 'systemHealth' | 'workerPool'
  | 'appConfig' | 'scheduler' | 'queueConfig'
  | 'userManagement' | 'userActivity'
  | 'storage' | 'cache' | 'auditLog'
  | 'rlsPolicies' | 'connectionProfiles' | 'workspaces'
  | 'auditCompliance' | 'uiVisibility';

const ADMIN_SECTIONS: { group: string; items: { id: AdminSection; label: string; icon: React.ReactNode }[] }[] = [
  { group: 'MONITORING', items: [
    { id: 'activeQueries', label: 'Active Queries', icon: <ActiveIcon fontSize="small" /> },
    { id: 'systemHealth',  label: 'System Health',  icon: <HealthIcon fontSize="small" /> },
    { id: 'workerPool',    label: 'Worker Pool',    icon: <RunningIcon fontSize="small" /> },
  ]},
  { group: 'CONFIGURATION', items: [
    { id: 'appConfig',   label: 'App Config',    icon: <SettingsIcon fontSize="small" /> },
    { id: 'queueConfig', label: 'Queue Backend',  icon: <QueueIcon fontSize="small" /> },
    { id: 'scheduler',   label: 'Scheduler',     icon: <ScheduleIcon fontSize="small" /> },
  ]},
  { group: 'USERS', items: [
    { id: 'userManagement', label: 'User Management', icon: <AuditIcon fontSize="small" /> },
    { id: 'userActivity',   label: 'User Activity',   icon: <ActivityIcon fontSize="small" /> },
  ]},
  { group: 'SYSTEM', items: [
    { id: 'storage',         label: 'Storage',             icon: <StorageIcon fontSize="small" /> },
    { id: 'cache',           label: 'Cache',               icon: <CacheIcon fontSize="small" /> },
    { id: 'auditLog',        label: 'Audit Log',           icon: <HistoryIcon fontSize="small" /> },
    { id: 'auditCompliance', label: 'Audit & Compliance',  icon: <GppGoodIcon fontSize="small" /> },
  ]},
  { group: 'REPORTING', items: [
    { id: 'rlsPolicies',        label: 'Row-Level Security',   icon: <AuditIcon fontSize="small" /> },
    { id: 'connectionProfiles', label: 'Connection Profiles',  icon: <SwapHorizIcon fontSize="small" /> },
    { id: 'workspaces',         label: 'Workspaces',           icon: <WorkspacesIcon fontSize="small" /> },
  ]},
  { group: 'ACCESS CONTROL', items: [
    { id: 'uiVisibility', label: 'UI Visibility', icon: <VisibilityOffIcon fontSize="small" /> },
  ]},
];

// Sections that auto-poll when active
const POLL_CONFIG: Partial<Record<AdminSection, { keys: string[]; interval: number }>> = {
  activeQueries: { keys: ['activeQ'],    interval: 10_000 },
  systemHealth:  { keys: ['health'],     interval: 15_000 },
  workerPool:    { keys: ['pool'],       interval: 10_000 },
  scheduler:     { keys: ['scheduler'],  interval: 15_000 },
  userActivity:  { keys: ['userStats'],  interval: 10_000 },
};

// ── RLS Policies Section ─────────────────────────────────────────────────────

const RLSAdminSection: React.FC = () => {
  const [reports, setReports]         = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [policies, setPolicies]       = useState<any[]>([]);
  const [loading, setLoading]         = useState(false);
  const [addOpen, setAddOpen]         = useState(false);
  const [form, setForm]               = useState({ column_name: '', operator: '=', value_template: '', description: '' });
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState('');

  useEffect(() => {
    api.listReports(false).then(r => setReports(Array.isArray(r) ? r : [])).catch(() => {});
  }, []);

  const loadPolicies = useCallback(async (reportId: number) => {
    setLoading(true);
    try { const res = await api.listRLSPolicies(reportId); setPolicies(res.policies || []); }
    finally { setLoading(false); }
  }, []);

  const handleSelectReport = (r: any) => {
    setSelectedReport(r);
    loadPolicies(r.id);
    setAddOpen(false);
    setError('');
  };

  const handleCreate = async () => {
    if (!form.column_name || !form.value_template) { setError('Column and value template are required'); return; }
    setSaving(true); setError('');
    try {
      await api.createRLSPolicy(selectedReport.id, form);
      setForm({ column_name: '', operator: '=', value_template: '', description: '' });
      setAddOpen(false);
      loadPolicies(selectedReport.id);
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  };

  const handleDelete = async (policyId: number) => {
    try { await api.deleteRLSPolicy(policyId); loadPolicies(selectedReport.id); }
    catch (e: any) { alert(e.message); }
  };

  const handleToggle = async (policy: any) => {
    try {
      await api.updateRLSPolicy(policy.id, { is_enabled: !policy.is_enabled });
      loadPolicies(selectedReport.id);
    } catch (e: any) { alert(e.message); }
  };

  const RLS_OPERATORS = ['=', '!=', 'IN', 'NOT IN', 'LIKE', '>', '<', '>=', '<='];

  return (
    <Box sx={{ display: 'flex', gap: 3, height: '100%' }}>
      {/* Report selector */}
      <Box sx={{ width: 260, flexShrink: 0 }}>
        <Typography variant="subtitle2" fontWeight={600} sx={{ mb: 1 }}>Select Report</Typography>
        <Paper variant="outlined" sx={{ overflow: 'hidden', maxHeight: 600, overflowY: 'auto' }}>
          {reports.length === 0 ? (
            <Typography variant="body2" color="text.secondary" sx={{ p: 2 }}>No reports found.</Typography>
          ) : reports.map((r: any) => (
            <Box key={r.id}
              onClick={() => handleSelectReport(r)}
              sx={{
                px: 2, py: 1.25, cursor: 'pointer', borderBottom: '1px solid', borderColor: 'divider',
                bgcolor: selectedReport?.id === r.id ? 'primary.50' : 'transparent',
                borderLeft: '3px solid',
                borderLeftColor: selectedReport?.id === r.id ? 'primary.main' : 'transparent',
                '&:hover': { bgcolor: 'action.hover' },
              }}
            >
              <Typography variant="body2" fontWeight={selectedReport?.id === r.id ? 600 : 400} noWrap>
                {r.name}
              </Typography>
            </Box>
          ))}
        </Paper>
      </Box>

      {/* Policy editor */}
      <Box sx={{ flex: 1 }}>
        {!selectedReport ? (
          <Typography variant="body2" color="text.secondary">Select a report to manage its RLS policies.</Typography>
        ) : (
          <>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
              <Typography variant="subtitle1" fontWeight={600}>{selectedReport.name}</Typography>
              <Chip label="Row-Level Security" size="small" color="warning" variant="outlined" sx={{ height: 20, fontSize: 10 }} />
              <Box sx={{ flex: 1 }} />
              <Button size="small" startIcon={<AddIcon />} variant="outlined" onClick={() => setAddOpen(v => !v)}>
                Add Policy
              </Button>
            </Box>

            {error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}

            <Collapse in={addOpen}>
              <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
                <Typography variant="subtitle2" sx={{ mb: 1.5 }}>New RLS Policy</Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
                  <TextField label="Column name" size="small" value={form.column_name}
                    onChange={e => setForm(f => ({ ...f, column_name: e.target.value }))} sx={{ flex: '1 1 160px' }} />
                  <FormControl size="small" sx={{ flex: '0 0 120px' }}>
                    <InputLabel>Operator</InputLabel>
                    <Select value={form.operator} label="Operator"
                      onChange={e => setForm(f => ({ ...f, operator: e.target.value }))}>
                      {RLS_OPERATORS.map(op => <MenuItem key={op} value={op}>{op}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <TextField label="Value template" size="small" value={form.value_template}
                    onChange={e => setForm(f => ({ ...f, value_template: e.target.value }))}
                    placeholder="{username} or fixed value"
                    helperText="Use {username}, {role} tokens"
                    sx={{ flex: '1 1 200px' }} />
                  <TextField label="Description (optional)" size="small" value={form.description}
                    onChange={e => setForm(f => ({ ...f, description: e.target.value }))} sx={{ flex: '1 1 200px' }} />
                </Box>
                <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  <Button size="small" onClick={() => setAddOpen(false)}>Cancel</Button>
                  <Button size="small" variant="contained" onClick={handleCreate} disabled={saving}>
                    {saving ? <CircularProgress size={14} /> : 'Create Policy'}
                  </Button>
                </Box>
              </Paper>
            </Collapse>

            {loading ? <CircularProgress size={20} /> : policies.length === 0 ? (
              <Typography variant="body2" color="text.secondary">No RLS policies. This report shows all rows to all users.</Typography>
            ) : (
              <Paper variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Column</TableCell>
                      <TableCell>Operator</TableCell>
                      <TableCell>Value Template</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {policies.map((p: any) => (
                      <TableRow key={p.id}>
                        <TableCell><Typography variant="body2" fontFamily="monospace">{p.column_name}</Typography></TableCell>
                        <TableCell><Chip label={p.operator} size="small" variant="outlined" sx={{ height: 20, fontSize: 10 }} /></TableCell>
                        <TableCell><Typography variant="body2" fontFamily="monospace">{p.value_template}</Typography></TableCell>
                        <TableCell><Typography variant="caption" color="text.secondary">{p.description || '—'}</Typography></TableCell>
                        <TableCell>
                          <Chip
                            label={p.is_enabled ? 'Active' : 'Disabled'}
                            size="small" color={p.is_enabled ? 'success' : 'default'} variant="outlined"
                            sx={{ height: 20, fontSize: 10, cursor: 'pointer' }}
                            onClick={() => handleToggle(p)}
                          />
                        </TableCell>
                        <TableCell>
                          <Tooltip title="Delete policy">
                            <IconButton size="small" color="error" onClick={() => handleDelete(p.id)}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Paper>
            )}

            <Alert severity="info" sx={{ mt: 2 }} icon={false}>
              <Typography variant="caption">
                RLS policies inject WHERE clauses at query execution time.
                Use <code>{'{username}'}</code> and <code>{'{role}'}</code> tokens to filter by the current user's attributes.
              </Typography>
            </Alert>
          </>
        )}
      </Box>
    </Box>
  );
};

// ── Connection Profiles Section ───────────────────────────────────────────────

const ConnectionProfilesAdminSection: React.FC = () => {
  const [profiles, setProfiles]         = useState<any[]>([]);
  const [connections, setConnections]   = useState<any[]>([]);
  const [loading, setLoading]           = useState(false);
  const [profileDlgOpen, setProfileDlgOpen] = useState(false);
  const [profileForm, setProfileForm]   = useState({ name: '', description: '' });
  const [mappingProfile, setMappingProfile] = useState<any>(null);
  const [mappings, setMappings]         = useState<any[]>([]);
  const [mappingLoading, setMappingLoading] = useState(false);

  const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 'oracle'];

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([
      api.listConnectionProfiles(),
      api.listConnections(true),
    ]).then(([pr, cr]: any[]) => {
      setProfiles((pr?.profiles || pr) || []);
      setConnections((cr || []).filter((c: any) => SQL_TYPES.includes(c.connection_type)));
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleActivate = async (id: number) => {
    await api.activateConnectionProfile(id);
    load();
  };
  const handleDeactivate = async () => {
    await api.deactivateAllProfiles();
    load();
  };
  const handleDelete = async (id: number) => {
    await api.deleteConnectionProfile(id);
    load();
  };
  const handleCreate = async () => {
    if (!profileForm.name.trim()) return;
    await api.createConnectionProfile(profileForm);
    setProfileDlgOpen(false);
    setProfileForm({ name: '', description: '' });
    load();
  };
  const openMappings = async (profile: any) => {
    setMappingProfile(profile);
    setMappingLoading(true);
    try {
      const r: any = await api.getProfileMappings(profile.id);
      setMappings((r?.mappings || r) || []);
    } finally { setMappingLoading(false); }
  };
  const handleSaveMappings = async () => {
    await api.setProfileMappings(mappingProfile.id, mappings);
    setMappingProfile(null);
    load();
  };

  const connName = (id: number) => connections.find((c: any) => c.id === id)?.name || `ID ${id}`;

  return (
    <Box sx={{ display: 'flex', height: '100%', gap: 2, p: 2 }}>
      {/* Profile list */}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography variant="subtitle1" fontWeight={600}>Connection Profiles</Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button size="small" variant="outlined" onClick={handleDeactivate}>Clear Active</Button>
            <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => setProfileDlgOpen(true)}>
              New Profile
            </Button>
          </Box>
        </Box>
        {loading ? <CircularProgress size={24} /> : (
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Description</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {profiles.length === 0 && (
                  <TableRow><TableCell colSpan={4} align="center"><Typography variant="caption" color="text.disabled">No profiles yet</Typography></TableCell></TableRow>
                )}
                {profiles.map((p: any) => (
                  <TableRow key={p.id} selected={p.is_active}>
                    <TableCell><Typography variant="body2" fontWeight={p.is_active ? 700 : 400}>{p.name}</Typography></TableCell>
                    <TableCell>
                      {p.is_active
                        ? <Chip label="ACTIVE" size="small" color="success" />
                        : <Chip label="inactive" size="small" variant="outlined" />}
                    </TableCell>
                    <TableCell><Typography variant="caption" color="text.secondary">{p.description || '—'}</Typography></TableCell>
                    <TableCell align="right">
                      <Tooltip title="Edit mappings">
                        <IconButton size="small" onClick={() => openMappings(p)}><EditIconMui fontSize="small" /></IconButton>
                      </Tooltip>
                      {!p.is_active && (
                        <Tooltip title="Activate this profile">
                          <IconButton size="small" color="primary" onClick={() => handleActivate(p.id)}>
                            <SwapHorizIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Delete profile">
                        <IconButton size="small" color="error" onClick={() => handleDelete(p.id)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
        <Alert severity="info" sx={{ mt: 1, fontSize: 12 }}>
          When a profile is active, all report executions swap matched connections to their targets. Only one profile can be active at a time.
        </Alert>
      </Box>

      {/* New profile dialog */}
      <Dialog open={profileDlgOpen} onClose={() => setProfileDlgOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>New Connection Profile</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
          <TextField label="Profile Name" size="small" fullWidth value={profileForm.name}
            onChange={e => setProfileForm(f => ({ ...f, name: e.target.value }))}
            placeholder="e.g. Production, Development, Staging" />
          <TextField label="Description (optional)" size="small" fullWidth value={profileForm.description}
            onChange={e => setProfileForm(f => ({ ...f, description: e.target.value }))} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setProfileDlgOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!profileForm.name.trim()}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* Mapping editor dialog */}
      <Dialog open={!!mappingProfile} onClose={() => setMappingProfile(null)} maxWidth="md" fullWidth>
        <DialogTitle>Edit Mappings — {mappingProfile?.name}</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            Each row maps a source connection to a target. When this profile is active, any report using the source will instead use the target.
          </Typography>
          {mappingLoading ? <CircularProgress size={24} /> : (
            <TableContainer component={Paper} variant="outlined">
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Source Connection</TableCell>
                    <TableCell>→</TableCell>
                    <TableCell>Target Connection</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell />
                  </TableRow>
                </TableHead>
                <TableBody>
                  {mappings.map((m: any, idx: number) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <FormControl size="small" fullWidth>
                          <Select value={m.source_connection_id || ''} onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, source_connection_id: Number(e.target.value) } : r))}>
                            {connections.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name} ({c.connection_type})</MenuItem>)}
                          </Select>
                        </FormControl>
                      </TableCell>
                      <TableCell>→</TableCell>
                      <TableCell>
                        <FormControl size="small" fullWidth>
                          <Select value={m.target_connection_id || ''} onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, target_connection_id: Number(e.target.value) } : r))}>
                            {connections.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name} ({c.connection_type})</MenuItem>)}
                          </Select>
                        </FormControl>
                      </TableCell>
                      <TableCell>
                        <TextField size="small" placeholder="optional note" value={m.description || ''}
                          onChange={e => setMappings(ms => ms.map((r, i) => i === idx ? { ...r, description: e.target.value } : r))} />
                      </TableCell>
                      <TableCell>
                        <IconButton size="small" color="error" onClick={() => setMappings(ms => ms.filter((_, i) => i !== idx))}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={5}>
                      <Button size="small" startIcon={<AddIcon />}
                        onClick={() => setMappings(ms => [...ms, { source_connection_id: '', target_connection_id: '', description: '' }])}>
                        Add Mapping
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setMappingProfile(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveMappings}>Save Mappings</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

// ══ Workspaces Admin Section (Phase 25) ═════════════════════════════════════
const WorkspaceAdminSection: React.FC = () => {
  const [workspaces, setWorkspaces] = React.useState<any[]>([]);
  const [members, setMembers] = React.useState<any[]>([]);
  const [selectedWs, setSelectedWs] = React.useState<any | null>(null);
  const [newWsOpen, setNewWsOpen] = React.useState(false);
  const [memberOpen, setMemberOpen] = React.useState(false);
  const [newWsName, setNewWsName] = React.useState('');
  const [newWsDesc, setNewWsDesc] = React.useState('');
  const [newMember, setNewMember] = React.useState('');
  const [newMemberRole, setNewMemberRole] = React.useState('member');
  const { addNotification } = useNotifications();

  const loadWorkspaces = async () => {
    const data = await api.listWorkspaces().catch(() => ({ workspaces: [] }));
    setWorkspaces(data.workspaces || []);
  };

  React.useEffect(() => { loadWorkspaces(); }, []);

  const loadMembers = async (wsId: number) => {
    const data = await api.listWorkspaceMembers(wsId).catch(() => ({ members: [] }));
    setMembers(data.members || []);
  };

  const handleCreate = async () => {
    if (!newWsName.trim()) return;
    try {
      await api.createWorkspace({ name: newWsName.trim(), description: newWsDesc.trim() || null });
      setNewWsOpen(false); setNewWsName(''); setNewWsDesc('');
      loadWorkspaces();
    } catch (e: any) { addNotification(e.message || 'Failed to create workspace', 'error'); }
  };

  const handleDelete = async (wsId: number) => {
    if (!confirm('Delete this workspace?')) return;
    await api.deleteWorkspace(wsId).catch(() => {});
    loadWorkspaces();
    if (selectedWs?.id === wsId) { setSelectedWs(null); setMemberOpen(false); }
  };

  const handleOpenMembers = (ws: any) => {
    setSelectedWs(ws);
    loadMembers(ws.id);
    setMemberOpen(true);
  };

  const handleAddMember = async () => {
    if (!newMember.trim() || !selectedWs) return;
    try {
      await api.addWorkspaceMember(selectedWs.id, { username: newMember.trim(), role: newMemberRole });
      setNewMember(''); loadMembers(selectedWs.id);
    } catch (e: any) { addNotification(e.message || 'Failed to add member', 'error'); }
  };

  const handleRemoveMember = async (username: string) => {
    if (!selectedWs) return;
    await api.removeWorkspaceMember(selectedWs.id, username).catch(() => {});
    loadMembers(selectedWs.id);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Workspaces</Typography>
        <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => setNewWsOpen(true)}>
          New Workspace
        </Button>
      </Box>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Members</TableCell>
            <TableCell>Created By</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {workspaces.map(ws => (
            <TableRow key={ws.id} hover>
              <TableCell><Typography variant="body2" fontWeight={500}>{ws.name}</Typography>
                {ws.description && <Typography variant="caption" color="text.secondary">{ws.description}</Typography>}
              </TableCell>
              <TableCell>{ws.member_count ?? 0}</TableCell>
              <TableCell>{ws.created_by || '—'}</TableCell>
              <TableCell align="right">
                <Tooltip title="Manage members"><IconButton size="small" onClick={() => handleOpenMembers(ws)}><PersonAddIcon fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Delete workspace"><IconButton size="small" color="error" onClick={() => handleDelete(ws.id)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* New workspace dialog */}
      <Dialog open={newWsOpen} onClose={() => setNewWsOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>New Workspace</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '12px !important' }}>
          <TextField label="Name" value={newWsName} onChange={e => setNewWsName(e.target.value)} size="small" autoFocus required />
          <TextField label="Description (optional)" value={newWsDesc} onChange={e => setNewWsDesc(e.target.value)} size="small" />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNewWsOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!newWsName.trim()}>Create</Button>
        </DialogActions>
      </Dialog>

      {/* Members dialog */}
      <Dialog open={memberOpen} onClose={() => setMemberOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Members — {selectedWs?.name}</DialogTitle>
        <DialogContent>
          <Table size="small" sx={{ mb: 2 }}>
            <TableHead>
              <TableRow>
                <TableCell>Username</TableCell>
                <TableCell>Role</TableCell>
                <TableCell align="right">Remove</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {members.map(m => (
                <TableRow key={m.username}>
                  <TableCell>{m.username}</TableCell>
                  <TableCell><Chip label={m.role} size="small" color={m.role === 'owner' ? 'primary' : 'default'} /></TableCell>
                  <TableCell align="right">
                    {m.role !== 'owner' && (
                      <IconButton size="small" color="error" onClick={() => handleRemoveMember(m.username)}><DeleteIcon fontSize="small" /></IconButton>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <TextField label="Username" value={newMember} onChange={e => setNewMember(e.target.value)} size="small" sx={{ flex: 1 }} />
            <Select value={newMemberRole} onChange={e => setNewMemberRole(e.target.value)} size="small" sx={{ minWidth: 110 }}>
              <MenuItem value="member">Member</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
              <MenuItem value="owner">Owner</MenuItem>
            </Select>
            <Button variant="outlined" size="small" onClick={handleAddMember} disabled={!newMember.trim()}>Add</Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setMemberOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

// ── UI Component Visibility Section ───────────────────────────────────────────

const UIVisibilityAdminSection: React.FC = () => {
  const [matrix, setMatrix]     = useState<any[]>([]);
  const [components, setComponents] = useState<any[]>([]);
  const [roles, setRoles]       = useState<string[]>([]);
  const [saving, setSaving]     = useState(false);
  const [saved, setSaved]       = useState(false);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const auth = getAuthHeader();
      if (auth) headers['Authorization'] = auth;
      const res = await fetch('/api/admin/ui-visibility', { headers });
      if (res.ok) {
        const d = await res.json();
        setMatrix(d.visibility || []);
        setComponents(d.components || []);
        setRoles(d.roles || []);
      } else {
        setError(`API error ${res.status}: ${res.statusText} — restart the backend to apply new model.`);
      }
    } catch (e: any) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Build a mutable map: { componentKey_role: enabled }
  const [overrides, setOverrides] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const map: Record<string, boolean> = {};
    for (const row of matrix) {
      map[`${row.component_key}__${row.role}`] = row.enabled;
    }
    setOverrides(map);
  }, [matrix]);

  const getValue = (key: string, role: string) => {
    const k = `${key}__${role}`;
    return k in overrides ? overrides[k] : true;
  };

  const toggle = (key: string, role: string) => {
    const k = `${key}__${role}`;
    setOverrides(prev => ({ ...prev, [k]: !(prev[k] ?? true) }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const auth = getAuthHeader();
      if (auth) headers['Authorization'] = auth;
      // Only send rows that differ from default (true) or are explicitly set
      const rules = [];
      for (const [k, v] of Object.entries(overrides)) {
        const [componentKey, role] = k.split('__');
        rules.push({ component_key: componentKey, role, enabled: v });
      }
      const res = await fetch('/api/admin/ui-visibility', {
        method: 'PUT',
        headers,
        body: JSON.stringify({ rules }),
      });
      if (res.ok) { setSaved(true); }
    } finally {
      setSaving(false);
    }
  };

  // Group components by group
  const grouped: Record<string, any[]> = {};
  for (const [key, label, group] of components) {
    if (!grouped[group]) grouped[group] = [];
    grouped[group].push({ key, label });
  }

  if (loading) return <Box sx={{ p: 3 }}><CircularProgress size={24} /></Box>;

  return (
    <Box sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
        <VisibilityOffIcon color="action" />
        <Typography variant="h6" fontWeight={600}>UI Component Visibility</Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" startIcon={<RefreshIcon />} onClick={load} disabled={loading}>Refresh</Button>
        <Button size="small" variant="contained" startIcon={<SaveIcon />} onClick={handleSave} disabled={saving || components.length === 0}>
          {saving ? 'Saving…' : 'Save Changes'}
        </Button>
      </Box>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {saved && <Alert severity="success" sx={{ mb: 2 }}>Visibility settings saved.</Alert>}

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Toggle which pages/features are accessible to each role. Admins always retain full access.
        Changes take effect on the user's next page load.
      </Typography>

      {Object.entries(grouped).map(([group, items]) => (
        <Box key={group} sx={{ mb: 3 }}>
          <Typography variant="overline" color="text.disabled" sx={{ letterSpacing: 1.2 }}>{group}</Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ mt: 0.5 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600, width: 220 }}>Component</TableCell>
                  {roles.map(r => (
                    <TableCell key={r} align="center" sx={{ fontWeight: 600, textTransform: 'capitalize' }}>
                      {r}
                      {r === 'admin' && (
                        <Typography variant="caption" display="block" color="text.disabled">(always on)</Typography>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {items.map(({ key, label }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{label}</TableCell>
                    {roles.map(role => (
                      <TableCell key={role} align="center">
                        <Switch
                          size="small"
                          checked={role === 'admin' ? true : getValue(key, role)}
                          disabled={role === 'admin'}
                          onChange={() => toggle(key, role)}
                          color="primary"
                        />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      ))}
    </Box>
  );
};

// ── Audit & Compliance Section ────────────────────────────────────────────────

const AuditComplianceAdminSection: React.FC = () => {
  const [tab, setTab] = useState(0);

  // Audit Log tab state
  const [auditRows, setAuditRows] = useState<any[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditUsername, setAuditUsername] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [auditResourceType, setAuditResourceType] = useState('');
  const [auditDateFrom, setAuditDateFrom] = useState('');
  const [auditDateTo, setAuditDateTo] = useState('');
  const [auditOffset, setAuditOffset] = useState(0);
  const PAGE_SIZE = 100;

  // Data Access tab state
  const [accessSummary, setAccessSummary] = useState<any[]>([]);
  const [accessLoading, setAccessLoading] = useState(false);

  // GDPR tab state
  const [gdprUsername, setGdprUsername] = useState('');
  const [gdprLoading, setGdprLoading] = useState(false);

  const loadAudit = useCallback(async (offset = 0) => {
    setAuditLoading(true);
    try {
      const rows = await (api as any).getAuditLogFiltered({
        username: auditUsername || undefined,
        action: auditAction || undefined,
        resource_type: auditResourceType || undefined,
        date_from: auditDateFrom || undefined,
        date_to: auditDateTo || undefined,
        limit: PAGE_SIZE,
        offset,
      });
      setAuditRows(Array.isArray(rows) ? rows : []);
      setAuditOffset(offset);
    } finally { setAuditLoading(false); }
  }, [auditUsername, auditAction, auditResourceType, auditDateFrom, auditDateTo]);

  const loadAccessSummary = useCallback(async () => {
    setAccessLoading(true);
    try {
      const res = await (api as any).getDataAccessSummary();
      setAccessSummary(res?.summary || []);
    } finally { setAccessLoading(false); }
  }, []);

  useEffect(() => {
    if (tab === 0) loadAudit(0);
    if (tab === 1) loadAccessSummary();
  }, [tab]);

  const handleExportCSV = () => {
    const params = new URLSearchParams();
    if (auditUsername) params.set('username', auditUsername);
    if (auditAction) params.set('action', auditAction);
    if (auditResourceType) params.set('resource_type', auditResourceType);
    if (auditDateFrom) params.set('date_from', auditDateFrom);
    if (auditDateTo) params.set('date_to', auditDateTo);
    const base = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
    const url = `${base}/api/admin/audit-log/export?${params.toString()}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = 'audit_log.csv';
    a.click();
  };

  const handleGdprExport = async () => {
    if (!gdprUsername.trim()) return;
    setGdprLoading(true);
    try { await (api as any).generateSubjectExport(gdprUsername.trim()); }
    finally { setGdprLoading(false); }
  };

  return (
    <Box>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        {['Audit Log', 'Data Access', 'GDPR Export'].map((label, i) => (
          <Button key={label} variant={tab === i ? 'contained' : 'text'} size="small"
            sx={{ mr: 1, mb: 1 }} onClick={() => setTab(i)}>
            {label}
          </Button>
        ))}
      </Box>

      {/* Tab 0: Audit Log */}
      {tab === 0 && (
        <Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2, alignItems: 'flex-end' }}>
            <TextField size="small" label="Username" value={auditUsername} onChange={e => setAuditUsername(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Action" value={auditAction} onChange={e => setAuditAction(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Resource Type" value={auditResourceType} onChange={e => setAuditResourceType(e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="From (YYYY-MM-DD)" value={auditDateFrom} onChange={e => setAuditDateFrom(e.target.value)} sx={{ width: 160 }} />
            <TextField size="small" label="To (YYYY-MM-DD)" value={auditDateTo} onChange={e => setAuditDateTo(e.target.value)} sx={{ width: 160 }} />
            <Button variant="contained" size="small" onClick={() => loadAudit(0)} disabled={auditLoading}>Search</Button>
            <Button variant="outlined" size="small" onClick={handleExportCSV}>Export CSV</Button>
          </Box>
          {auditLoading ? <CircularProgress size={20} /> : (
            <Box sx={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr>
                    {['Timestamp', 'Username', 'Action', 'Resource Type', 'Resource ID', 'IP Address'].map(h => (
                      <th key={h} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: '2px solid rgba(0,0,0,0.12)', background: 'rgba(0,0,0,0.04)', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {auditRows.map((r, i) => (
                    <tr key={r.id ?? i} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                      <td style={{ padding: '4px 10px', whiteSpace: 'nowrap' }}>{r.timestamp ? new Date(r.timestamp).toLocaleString() : '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.username}</td>
                      <td style={{ padding: '4px 10px' }}>{r.action}</td>
                      <td style={{ padding: '4px 10px' }}>{r.resource_type || '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.resource_id || '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.ip_address || '—'}</td>
                    </tr>
                  ))}
                  {auditRows.length === 0 && (
                    <tr><td colSpan={6} style={{ padding: 16, textAlign: 'center', color: '#888' }}>No entries found</td></tr>
                  )}
                </tbody>
              </table>
              <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                <Button size="small" disabled={auditOffset === 0} onClick={() => loadAudit(Math.max(0, auditOffset - PAGE_SIZE))}>Previous</Button>
                <Button size="small" disabled={auditRows.length < PAGE_SIZE} onClick={() => loadAudit(auditOffset + PAGE_SIZE)}>Next</Button>
              </Box>
            </Box>
          )}
        </Box>
      )}

      {/* Tab 1: Data Access Summary */}
      {tab === 1 && (
        <Box>
          {accessLoading ? <CircularProgress size={20} /> : (
            <Box sx={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr>
                    {['Username', 'Total Executions', 'Total Rows', 'Last Active', 'Exports'].map(h => (
                      <th key={h} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: '2px solid rgba(0,0,0,0.12)', background: 'rgba(0,0,0,0.04)', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {accessSummary.map((r, i) => (
                    <tr key={r.username ?? i} style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
                      <td style={{ padding: '4px 10px', fontWeight: 600 }}>{r.username}</td>
                      <td style={{ padding: '4px 10px' }}>{(r.total_executions || 0).toLocaleString()}</td>
                      <td style={{ padding: '4px 10px' }}>{(r.total_rows || 0).toLocaleString()}</td>
                      <td style={{ padding: '4px 10px', whiteSpace: 'nowrap' }}>{r.last_active ? new Date(r.last_active).toLocaleString() : '—'}</td>
                      <td style={{ padding: '4px 10px' }}>{r.export_count || 0}</td>
                    </tr>
                  ))}
                  {accessSummary.length === 0 && (
                    <tr><td colSpan={5} style={{ padding: 16, textAlign: 'center', color: '#888' }}>No data</td></tr>
                  )}
                </tbody>
              </table>
            </Box>
          )}
        </Box>
      )}

      {/* Tab 2: GDPR Export */}
      {tab === 2 && (
        <Box sx={{ maxWidth: 480 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Generate a ZIP archive containing all data QueryStudio holds for a specific user (saved queries, executions, downloads, schedules, and audit log).
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <TextField
              size="small" label="Username" value={gdprUsername}
              onChange={e => setGdprUsername(e.target.value)}
              sx={{ flex: 1 }}
            />
            <Button
              variant="contained" size="small" startIcon={gdprLoading ? <CircularProgress size={14} color="inherit" /> : <GppGoodIcon />}
              onClick={handleGdprExport} disabled={!gdprUsername.trim() || gdprLoading}
            >
              Generate ZIP
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
};

// ══ Main component ══════════════════════════════════════════════════════════
const AdminPage = () => {
  const { addNotification } = useNotifications();
  const theme = useTheme();

  // ── Active section ──
  const [activeSection, setActiveSection] = useState<AdminSection>('activeQueries');

  const [health,      setHealth]      = useState<any>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [storage,     setStorage]     = useState<any>(null);
  const [cache,       setCache]       = useState<any>(null);
  const [activeQ,     setActiveQ]     = useState<any[]>([]);
  const [userStats,   setUserStats]   = useState<any[]>([]);
  const [auditLog,    setAuditLog]    = useState<any[]>([]);
  const [poolStats,   setPoolStats]   = useState<any>(null);
  const [poolTasks,   setPoolTasks]   = useState<any[]>([]);
  const [auditPage,   setAuditPage]   = useState(0);
  const [auditTotal,  setAuditTotal]  = useState(0);
  const [auditSearch, setAuditSearch] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [loading,     setLoading]     = useState({
    health: true, storage: true, cache: true,
    activeQ: true, userStats: true, audit: true, pool: true,
  });
  const [cleanupBusy, setCleanupBusy] = useState(false);
  const [cacheBusy,   setCacheBusy]   = useState(false);
  const [cancelTarget, setCancelTarget] = useState<any>(null);
  const [cancelBusy,   setCancelBusy]   = useState(false);
  const [poolCfgOpen,  setPoolCfgOpen]  = useState(false);
  const [poolCfg,      setPoolCfg]      = useState<any>(null);
  const [poolCfgDraft, setPoolCfgDraft] = useState<any>({});
  const [poolCfgSaving, setPoolCfgSaving] = useState(false);

  // Scheduler state
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null);
  const [schedulerBusy, setSchedulerBusy]     = useState(false);

  // Circuit breaker health
  const [circuitBreakers, setCircuitBreakers] = useState<any[]>([]);

  // App Configuration state (limits + features)
  const [appCfg,        setAppCfg]        = useState<any>(null);
  const [appCfgDraft,   setAppCfgDraft]   = useState<any>({ limits: {}, features: {} });
  const [appCfgSaving,  setAppCfgSaving]  = useState(false);
  const [appCfgLoading, setAppCfgLoading] = useState(false);

  // Queue config state
  const [queueCfg,        setQueueCfg]        = useState<any>(null);
  const [queueCfgDraft,   setQueueCfgDraft]   = useState<any>({});
  const [queueCfgSaving,  setQueueCfgSaving]  = useState(false);
  const [queueCfgLoading, setQueueCfgLoading] = useState(false);
  const [redisTestResult, setRedisTestResult]  = useState<any>(null);
  const [redisTestBusy,   setRedisTestBusy]    = useState(false);

  // User management state
  const [userList, setUserList] = useState<any[]>([]);
  const [userMgmtLoading, setUserMgmtLoading] = useState(true);
  const [userDlg, setUserDlg] = useState<any>({ open: false, mode: 'add', username: '', password: '', role: 'analyst' });
  const [authType, setAuthType] = useState<string>('none');
  const [adLookup, setAdLookup] = useState<any>(null);
  const [adLookupLoading, setAdLookupLoading] = useState(false);
  const [adLookupError, setAdLookupError] = useState('');

  const AUDIT_PER_PAGE = 25;
  const WARN_SECS = 300;

  const setOne = (k: string, v: boolean) =>
    setLoading(prev => ({ ...prev, [k]: v }));

  // ── Data loading ──────────────────────────────────────────────────────────
  const loadSection = useCallback(async (section: string) => {
    setOne(section, true);
    try {
      switch (section) {
        case 'health': {
          setHealthError(null);
          const res = await authFetch(`${API_BASE}/health`);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const d = await res.json();
          setHealth(d);
          // Also load circuit breaker data
          authFetch(`${API_BASE}/api/admin/circuit-breakers`)
            .then(r => r.json())
            .then((data: any) => setCircuitBreakers(data.circuit_breakers || []))
            .catch(() => {});
          break;
        }
        case 'storage': {
          const d = await authFetch(`${API_BASE}/api/admin/storage`).then(r => r.json());
          setStorage(d);
          break;
        }
        case 'cache': {
          const d = await authFetch(`${API_BASE}/api/cache/stats`).then(r => r.json());
          setCache(d);
          break;
        }
        case 'activeQ': {
          const d = await authFetch(`${API_BASE}/api/admin/active-queries`).then(r => r.json());
          setActiveQ(Array.isArray(d) ? d : []);
          break;
        }
        case 'userStats': {
          const d = await authFetch(`${API_BASE}/api/admin/user-stats`).then(r => r.json());
          setUserStats(Array.isArray(d) ? d : []);
          break;
        }
        case 'pool': {
          const [stats, tasks] = await Promise.all([
            authFetch(`${API_BASE}/api/admin/worker-pool`).then(r => r.json()),
            authFetch(`${API_BASE}/api/admin/worker-pool/tasks`).then(r => r.json()),
          ]);
          setPoolStats(stats);
          setPoolTasks(Array.isArray(tasks) ? tasks : []);
          break;
        }
        case 'scheduler': {
          const d = await authFetch(`${API_BASE}/api/admin/scheduler`).then(r => r.json());
          setSchedulerStatus(d);
          break;
        }
        case 'audit': {
          const qs = new URLSearchParams({
            limit:  String(AUDIT_PER_PAGE),
            offset: String(auditPage * AUDIT_PER_PAGE),
            ...(auditSearch ? { username: auditSearch } : {}),
            ...(auditAction ? { action:   auditAction } : {}),
          });
          const res  = await authFetch(`${API_BASE}/api/admin/audit-log?${qs}`);
          const data = await res.json();
          setAuditLog(Array.isArray(data) ? data : data.items || []);
          setAuditTotal(data.total || (Array.isArray(data) ? data.length : 0));
          break;
        }
      }
    } catch (err: any) {
      if (section === 'health') setHealthError(String(err?.message || err));
    }
    setOne(section, false);
  }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  // ── Fetch active query count on mount (for nav badge) ──────────────────────
  useEffect(() => {
    loadSection('activeQ');
  }, []); // eslint-disable-line

  // ── Section-aware polling (only active section polls) ─────────────────────
  useEffect(() => {
    const cfg = POLL_CONFIG[activeSection];
    if (!cfg) return;
    // Immediate load
    cfg.keys.forEach(k => loadSection(k));
    const timer = setInterval(() => {
      cfg.keys.forEach(k => loadSection(k));
    }, cfg.interval);
    return () => clearInterval(timer);
  }, [activeSection, loadSection]);

  // Load non-polling sections on first visit
  const loadedRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (loadedRef.current.has(activeSection)) return;
    loadedRef.current.add(activeSection);
    switch (activeSection) {
      case 'appConfig':      loadAppConfig(); break;
      case 'queueConfig':    loadQueueConfig(); break;
      case 'userManagement': loadUsers(); break;
      case 'storage':        loadSection('storage'); break;
      case 'cache':          loadSection('cache'); break;
      case 'auditLog':       loadSection('audit'); break;
    }
  }, [activeSection]); // eslint-disable-line

  // Re-load audit when filters/page change (only if audit is active)
  useEffect(() => {
    if (activeSection === 'auditLog') loadSection('audit');
  }, [auditPage, auditSearch, auditAction]); // eslint-disable-line

  // ── Handlers ────────────────────────────────────────────────────────────
  const handleCleanup = async () => {
    setCleanupBusy(true);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/storage/cleanup`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      addNotification({ type: 'success', title: 'Cleanup Complete', message: 'Stale files removed' });
      loadSection('storage');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cleanup Failed', message: e.message });
    } finally { setCleanupBusy(false); }
  };

  const handleClearCache = async () => {
    setCacheBusy(true);
    try {
      await authFetch(`${API_BASE}/api/cache`, { method: 'DELETE' });
      addNotification({ type: 'success', title: 'Cache Cleared', message: 'Query result cache cleared' });
      loadSection('cache');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Clear Failed', message: e.message });
    } finally { setCacheBusy(false); }
  };

  const handleAdminCancel = async () => {
    if (!cancelTarget) return;
    setCancelBusy(true);
    try {
      const res  = await authFetch(`${API_BASE}/api/admin/queries/${cancelTarget.execution_id}`, { method: 'DELETE' });
      const body = await res.json();
      addNotification({ type: 'success', title: 'Query Cancelled', message: body.message });
      setCancelTarget(null);
      await Promise.all([loadSection('activeQ'), loadSection('userStats')]);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cancel Failed', message: e.message });
    } finally { setCancelBusy(false); }
  };

  // ── Scheduler toggle ──────────────────────────────────────────────────
  const handleSchedulerToggle = async () => {
    if (!schedulerStatus) return;
    setSchedulerBusy(true);
    try {
      const action = schedulerStatus.paused ? 'resume' : 'pause';
      const res = await authFetch(`${API_BASE}/api/admin/scheduler/${action}`, { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = await res.json();
      addNotification({ type: 'success', title: `Scheduler ${action === 'pause' ? 'Paused' : 'Resumed'}`, message: body.message });
      loadSection('scheduler');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Scheduler Toggle Failed', message: e.message });
    } finally { setSchedulerBusy(false); }
  };

  // ── Worker Pool Config ─────────────────────────────────────────────────
  const loadPoolConfig = useCallback(async () => {
    try {
      const data = await authFetch(`${API_BASE}/api/admin/worker-pool/config`).then(r => r.json());
      setPoolCfg(data);
      const draft: any = {};
      if (data?.types) {
        for (const [typeName, cfg] of Object.entries(data.types) as any) {
          const prefix = typeName.toLowerCase();
          draft[`${prefix}_max_concurrent`] = cfg.max_concurrent;
          draft[`${prefix}_default_timeout`] = cfg.default_timeout;
          draft[`${prefix}_max_queue`] = cfg.max_queue;
        }
      }
      setPoolCfgDraft(draft);
    } catch { /* silent */ }
  }, []);

  const handlePoolCfgSave = async () => {
    setPoolCfgSaving(true);
    try {
      const changed: any = {};
      if (poolCfg?.types) {
        for (const [typeName, cfg] of Object.entries(poolCfg.types) as any) {
          const prefix = typeName.toLowerCase();
          for (const field of ['max_concurrent', 'default_timeout', 'max_queue']) {
            const key = `${prefix}_${field}`;
            const newVal = Number(poolCfgDraft[key]);
            if (!isNaN(newVal) && newVal !== cfg[field]) {
              changed[key] = newVal;
            }
          }
        }
      }
      if (Object.keys(changed).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'Configuration unchanged' });
        setPoolCfgSaving(false);
        return;
      }
      const res = await authFetch(`${API_BASE}/api/admin/worker-pool/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changed),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || `HTTP ${res.status}`);
      }
      const result = await res.json();
      addNotification({ type: 'success', title: 'Config Saved', message: `Applied ${Object.keys(result.changes || {}).length} change(s)` });
      await loadPoolConfig();
      loadSection('pool');
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Config Save Failed', message: e.message });
    } finally { setPoolCfgSaving(false); }
  };

  const updateDraft = (key: string, value: string) => {
    setPoolCfgDraft((prev: any) => ({ ...prev, [key]: value }));
  };

  useEffect(() => {
    if (poolCfgOpen && !poolCfg) loadPoolConfig();
  }, [poolCfgOpen]); // eslint-disable-line

  // ── App Configuration (limits + features) ─────────────────────────────
  const loadAppConfig = useCallback(async () => {
    setAppCfgLoading(true);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/app-config`);
      if (res.ok) {
        const data = await res.json();
        setAppCfg(data);
        setAppCfgDraft({ limits: { ...data.limits }, features: { ...data.features }, s3_results: { ...(data.s3_results || {}) } });
      }
    } catch {}
    finally { setAppCfgLoading(false); }
  }, []);

  const handleAppCfgSave = async () => {
    setAppCfgSaving(true);
    try {
      const changedLimits: any = {};
      const changedFeatures: any = {};
      const changedS3Results: any = {};
      if (appCfg) {
        for (const [k, v] of Object.entries(appCfgDraft.limits || {})) {
          if (v !== appCfg.limits?.[k]) changedLimits[k] = typeof appCfg.limits?.[k] === 'number' ? Number(v) : v;
        }
        for (const [k, v] of Object.entries(appCfgDraft.features || {})) {
          if (v !== appCfg.features?.[k]) changedFeatures[k] = v;
        }
        for (const [k, v] of Object.entries(appCfgDraft.s3_results || {})) {
          if (v !== appCfg.s3_results?.[k]) changedS3Results[k] = typeof appCfg.s3_results?.[k] === 'number' ? Number(v) : v;
        }
      }
      const payload: any = {};
      if (Object.keys(changedLimits).length > 0) payload.limits = changedLimits;
      if (Object.keys(changedFeatures).length > 0) payload.features = changedFeatures;
      if (Object.keys(changedS3Results).length > 0) payload.s3_results = changedS3Results;
      if (Object.keys(payload).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'No configuration values were changed' });
        setAppCfgSaving(false);
        return;
      }
      const res = await authFetch(`${API_BASE}/api/admin/app-config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) { const err = await res.json().catch(() => ({})); throw new Error(err.detail || 'Save failed'); }
      addNotification({ type: 'success', title: 'Config Saved', message: 'Application configuration updated. Changes apply immediately.' });
      await loadAppConfig();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save Failed', message: e.message });
    } finally { setAppCfgSaving(false); }
  };

  const updateAppCfgDraft = (section: 'limits' | 'features' | 's3_results', key: string, value: any) => {
    setAppCfgDraft((prev: any) => ({
      ...prev,
      [section]: { ...prev[section], [key]: value },
    }));
  };

  // ── Queue Configuration ─────────────────────────────────────────────────
  const loadQueueConfig = useCallback(async () => {
    setQueueCfgLoading(true);
    setRedisTestResult(null);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/queue-config`);
      if (res.ok) {
        const data = await res.json();
        setQueueCfg(data);
        setQueueCfgDraft({ ...data.config });
      }
    } catch {}
    finally { setQueueCfgLoading(false); }
  }, []);

  const handleQueueCfgSave = async () => {
    setQueueCfgSaving(true);
    try {
      const changed: any = {};
      if (queueCfg?.config) {
        for (const [k, v] of Object.entries(queueCfgDraft)) {
          if (k === 'redis_password' && v === '***') continue; // skip masked pw
          if (v !== queueCfg.config[k]) changed[k] = v;
        }
      }
      if (Object.keys(changed).length === 0) {
        addNotification({ type: 'info', title: 'No Changes', message: 'Queue configuration unchanged' });
        setQueueCfgSaving(false);
        return;
      }
      const res = await authFetch(`${API_BASE}/api/admin/queue-config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changed),
      });
      if (!res.ok) { const err = await res.json().catch(() => ({})); throw new Error(err.detail || 'Save failed'); }
      const result = await res.json();
      addNotification({
        type: 'success',
        title: 'Queue Config Saved',
        message: result.restart_required
          ? 'Backend switch requires restart to take effect.'
          : 'Queue configuration updated.',
      });
      await loadQueueConfig();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Save Failed', message: e.message });
    } finally { setQueueCfgSaving(false); }
  };

  const handleTestRedis = async () => {
    setRedisTestBusy(true);
    setRedisTestResult(null);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/queue-config/test-redis`, { method: 'POST' });
      const data = await res.json();
      setRedisTestResult(data);
    } catch (e: any) {
      setRedisTestResult({ connected: false, error: e.message });
    } finally { setRedisTestBusy(false); }
  };

  const updateQueueDraft = (key: string, value: any) => {
    setQueueCfgDraft((prev: any) => ({ ...prev, [key]: value }));
  };

  // ── User management ────────────────────────────────────────────────────
  const loadUsers = useCallback(async () => {
    setUserMgmtLoading(true);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users`);
      const data = await res.json();
      setUserList(Array.isArray(data) ? data : []);
    } catch { setUserList([]); }
    finally { setUserMgmtLoading(false); }
  }, []);

  useEffect(() => {
    // Fetch auth type on mount (lightweight, always needed)
    authFetch(`${API_BASE}/auth/config`).then(r => r.json()).then(cfg => {
      setAuthType(cfg.type || 'none');
    }).catch(() => {});
  }, []);

  const isAdMode = authType === 'ad';

  const handleAdLookup = async () => {
    const username = userDlg.username.trim();
    if (!username) return;
    setAdLookupLoading(true);
    setAdLookupError('');
    setAdLookup(null);
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users/lookup/${encodeURIComponent(username)}`);
      if (!res.ok) {
        const e = await res.json();
        throw new Error(e.detail || 'User not found');
      }
      const data = await res.json();
      setAdLookup(data);
    } catch (e: any) {
      setAdLookupError(e.message);
    } finally {
      setAdLookupLoading(false);
    }
  };

  const handleSaveUser = async () => {
    const { mode, username, password, role } = userDlg;
    if (!username.trim()) return;
    try {
      const url = mode === 'add'
        ? `${API_BASE}/api/admin/users`
        : `${API_BASE}/api/admin/users/${encodeURIComponent(username)}`;
      const method = mode === 'add' ? 'POST' : 'PUT';
      const body: any = { username: username.trim(), role };
      if (!isAdMode && password) body.password = password;
      const res = await authFetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || 'Failed'); }
      addNotification({ type: 'success', title: mode === 'add' ? 'User Added' : 'User Updated', message: `${username} (${role})` });
      setUserDlg({ ...userDlg, open: false });
      setAdLookup(null);
      setAdLookupError('');
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  const handleDeleteUser = async (username: string) => {
    if (!confirm(`Remove user "${username}"? This cannot be undone.`)) return;
    try {
      const res = await authFetch(`${API_BASE}/api/admin/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || 'Failed'); }
      addNotification({ type: 'success', title: 'User Removed', message: username });
      loadUsers();
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Error', message: e.message });
    }
  };

  // ── Derived ──────────────────────────────────────────────────────────────
  const longRunning  = activeQ.filter(q => q.duration_seconds >= WARN_SECS);
  const totalActive  = activeQ.length;

  // ── Section-specific refresh ──────────────────────────────────────────────
  const handleRefresh = useCallback(() => {
    switch (activeSection) {
      case 'activeQueries':  loadSection('activeQ'); break;
      case 'systemHealth':   loadSection('health'); break;
      case 'workerPool':     loadSection('pool'); break;
      case 'appConfig':      loadAppConfig(); break;
      case 'queueConfig':    loadQueueConfig(); break;
      case 'scheduler':      loadSection('scheduler'); break;
      case 'userManagement': loadUsers(); break;
      case 'userActivity':   loadSection('userStats'); break;
      case 'storage':        loadSection('storage'); break;
      case 'cache':          loadSection('cache'); break;
      case 'auditLog':       loadSection('audit'); break;
    }
  }, [activeSection, loadSection, loadAppConfig, loadUsers]);

  // ══════════════════════════════════════════════════════════════════════════
  // ── Section renderers (closures over state) ──────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════

  const renderActiveQueries = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {/* Long-running alert */}
      {longRunning.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }} icon={<BlockedIcon />}>
          <strong>{longRunning.length}</strong> quer{longRunning.length > 1 ? 'ies' : 'y'} running
          longer than {WARN_SECS / 60} minutes — consider cancelling to free resources.
        </Alert>
      )}

      {loading.activeQ && <LinearProgress sx={{ mb: 1 }} />}

      {!loading.activeQ && activeQ.length === 0 ? (
        <Box sx={{ py: 4, textAlign: 'center', color: 'text.secondary' }}>
          <RunningIcon sx={{ fontSize: 36, mb: 1, opacity: 0.3 }} />
          <Typography variant="body2">No active queries — system is idle</Typography>
        </Box>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                {['User', 'Status', 'Duration', 'Progress', 'Connection', 'Started', 'Actions'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {activeQ.map((row) => {
                const isWarn   = row.duration_seconds >= WARN_SECS;
                const progress = row.chunks_processed > 0
                  ? Math.min(99, Math.round(row.chunks_processed * 5)) : null;
                return (
                  <TableRow key={row.execution_id} hover
                    sx={isWarn ? { bgcolor: 'rgba(255,152,0,0.06)' } : {}}>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                        <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                          bgcolor: theme.palette.primary.light }}>
                          {(row.executed_by || 'G')[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2">{row.executed_by || 'guest'}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip size="small" label={row.status}
                        color={row.status === 'processing' ? 'primary' : 'default'}
                        variant="outlined"
                        icon={row.status === 'processing'
                          ? <RunningIcon sx={{ fontSize: '12px !important',
                              animation: 'spin 1.4s linear infinite',
                              '@keyframes spin': { '0%': { transform: 'rotate(0deg)' }, '100%': { transform: 'rotate(360deg)' } } }} />
                          : undefined}
                        sx={{ fontSize: '0.7rem', height: 20 }}
                      />
                    </TableCell>
                    <TableCell>
                      <LiveDuration seconds={row.duration_seconds} warn={isWarn} />
                    </TableCell>
                    <TableCell sx={{ minWidth: 110 }}>
                      {progress != null ? (
                        <Box>
                          <LinearProgress variant="determinate" value={progress}
                            sx={{ height: 6, borderRadius: 3, mb: 0.3 }} />
                          <Typography variant="caption" color="text.secondary">
                            {row.chunks_processed} chunks
                          </Typography>
                        </Box>
                      ) : (
                        <LinearProgress sx={{ height: 6, borderRadius: 3 }} />
                      )}
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                      {row.connection_name || '—'}
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap', color: 'text.secondary' }}>
                      {fmtDate(row.started_at)}
                    </TableCell>
                    <TableCell>
                      <Tooltip title="Cancel this query (admin override)">
                        <IconButton size="small" color="error"
                          onClick={() => setCancelTarget(row)}>
                          <CancelIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );

  const renderSystemHealth = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading.health && <LinearProgress sx={{ mb: 2 }} />}
      {healthError && (
        <Alert severity="error" sx={{ mb: 2 }} action={
          <Button size="small" onClick={() => loadSection('health')}>Retry</Button>
        }>
          Failed to load health data: {healthError}
        </Alert>
      )}
      {!loading.health && !health && !healthError && (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <Typography color="text.secondary">No health data — click Refresh to load.</Typography>
          <Button size="small" startIcon={<RefreshIcon />} onClick={() => loadSection('health')} sx={{ mt: 1 }}>
            Refresh
          </Button>
        </Box>
      )}
      {health && (
        <>
          <Stack direction="row" spacing={1} mb={2} flexWrap="wrap" useFlexGap>
            <StatusChip ok={health.status === 'healthy'} label={health.status?.toUpperCase()} />
            <StatusChip ok={health.database?.ok} label={`DB: ${health.database?.ok ? 'OK' : 'Error'}`} />
            <StatusChip ok={health.s3?.status === 'connected'} label={`S3: ${health.s3?.status || 'n/a'}`} />
            {health.disk?.warning && <Chip size="small" icon={<WarnIcon />} label="Low Disk" color="warning" />}
          </Stack>
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Active Queries"  value={health.queries?.active ?? totalActive}
              warn={(health.queries?.active ?? totalActive) >= (health.queries?.max_concurrent_global ?? 99)} />
            <StatCard label="Global Limit"    value={health.queries?.max_concurrent_global ?? '—'} />
            <StatCard label="Per-User Limit"  value={health.queries?.per_user_limit ?? '—'} />
            <StatCard label="Queue Waiting"   value={health.queries?.queue_waiting ?? 0}
              warn={(health.queries?.queue_waiting ?? 0) > 0} />
            <StatCard label="Disk Free"
              value={`${health.disk?.free_gb ?? '—'} GB`}
              warn={health.disk?.warning}
              sub={`${health.disk?.used_pct ?? '—'}% used`} />
          </Stack>

          {/* Connection Health (Circuit Breakers) */}
          <Typography variant="h6" sx={{ mt: 3, mb: 1 }}>Connection Health</Typography>
          {circuitBreakers.length === 0 ? (
            <Typography variant="body2" color="text.secondary">No circuit breaker data yet</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {circuitBreakers.map((cb: any) => (
                <Chip
                  key={cb.connection_id}
                  label={`${cb.connection_name || `Conn #${cb.connection_id}`}: ${cb.state}`}
                  size="small"
                  color={cb.state === 'closed' ? 'success' : cb.state === 'open' ? 'error' : 'warning'}
                  variant="outlined"
                />
              ))}
            </Box>
          )}
        </>
      )}
    </Paper>
  );

  const renderWorkerPool = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading.pool && <LinearProgress sx={{ mb: 2 }} />}
      {poolStats && (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Total Workers" value={poolStats.total_workers ?? '—'} />
            <StatCard label="Active" value={poolStats.active_total ?? 0}
              warn={(poolStats.active_total ?? 0) >= (poolStats.total_workers ?? 40)} />
            <StatCard label="Queued" value={poolStats.queued_total ?? 0}
              warn={(poolStats.queued_total ?? 0) > 0} />
          </Stack>
          {poolStats.by_type && (
            <TableContainer sx={{ mb: 1 }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Type', 'Running', 'Queued', 'Max', 'Completed', 'Failed', 'Timeout', 'Avg Wait', 'Avg Run'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.entries(poolStats.by_type).map(([type, s]: any) => (
                    <TableRow key={type} hover>
                      <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{type}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        <Chip size="small" label={s.running} color={s.running > 0 ? 'primary' : 'default'}
                          sx={{ height: 20, fontSize: 11 }} />
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.queued > 0 ? <Chip size="small" label={s.queued} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.max_concurrent}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.completed}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.failed > 0 ? <Chip size="small" label={s.failed} color="error" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        {s.timeout > 0 ? <Chip size="small" label={s.timeout} color="warning" sx={{ height: 20, fontSize: 11 }} /> : 0}
                      </TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_wait_ms > 0 ? `${s.avg_wait_ms}ms` : '—'}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>{s.avg_run_ms > 0 ? `${(s.avg_run_ms / 1000).toFixed(1)}s` : '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          {poolTasks.length > 0 && (
            <>
              <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mt: 1 }}>
                Active Tasks ({poolTasks.length})
              </Typography>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      {['Type', 'Execution', 'User', 'Status', 'Duration', 'Action'].map(h => (
                        <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {poolTasks.map((t: any) => (
                      <TableRow key={t.task_id} hover>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.work_type}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', fontFamily: 'monospace' }}>
                          {t.execution_id ? t.execution_id.substring(0, 8) + '…' : '—'}
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{t.username}</TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          <StatusChip ok={t.status === 'running'} label={t.status} />
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          {t.started_at ? <LiveDuration seconds={Math.round((Date.now() / 1000) - t.started_at)} warn={false} /> : '—'}
                        </TableCell>
                        <TableCell sx={{ py: 0.5, px: 1 }}>
                          <IconButton size="small" color="error"
                            onClick={async () => {
                              try {
                                await authFetch(`${API_BASE}/api/admin/worker-pool/tasks/${t.task_id}/cancel`, { method: 'POST' });
                                loadSection('pool');
                              } catch {}
                            }}>
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          )}

          {/* ── Config Editor (collapsible) ── */}
          <Divider sx={{ my: 1.5 }} />
          <Box
            sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', gap: 0.5, py: 0.5 }}
            onClick={() => setPoolCfgOpen(o => !o)}
          >
            <SettingsIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ flex: 1 }}>
              Configure Limits
            </Typography>
            {poolCfgOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
          </Box>
          <Collapse in={poolCfgOpen}>
            {poolCfg ? (
              <Box sx={{ mt: 1 }}>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Type', 'Max Concurrent', 'Default Timeout (s)', 'Max Queue'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {['INTERACTIVE', 'REPORT', 'SCHEDULED', 'EXPORT', 'SYSTEM'].map(typeName => {
                        const prefix = typeName.toLowerCase();
                        return (
                          <TableRow key={typeName} hover>
                            <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>{typeName}</TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField
                                size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_max_concurrent`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_max_concurrent`, e.target.value)}
                                inputProps={{ min: 1, max: 100, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                              />
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField
                                size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_default_timeout`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_default_timeout`, e.target.value)}
                                inputProps={{ min: 10, style: { fontSize: 12, padding: '4px 8px', width: 72 } }}
                              />
                            </TableCell>
                            <TableCell sx={{ py: 0.5, px: 1 }}>
                              <TextField
                                size="small" type="number" variant="outlined"
                                value={poolCfgDraft[`${prefix}_max_queue`] ?? ''}
                                onChange={e => updateDraft(`${prefix}_max_queue`, e.target.value)}
                                inputProps={{ min: 1, max: 500, style: { fontSize: 12, padding: '4px 8px', width: 60 } }}
                              />
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 1.5 }}>
                  <Button size="small" variant="text" onClick={loadPoolConfig} disabled={poolCfgSaving}>
                    Reset
                  </Button>
                  <Button size="small" variant="contained" startIcon={poolCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
                    onClick={handlePoolCfgSave} disabled={poolCfgSaving}>
                    Save
                  </Button>
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  Changes apply immediately without server restart. Running tasks are not affected.
                </Typography>
              </Box>
            ) : (
              <LinearProgress sx={{ mt: 1 }} />
            )}
          </Collapse>
        </>
      )}
    </Paper>
  );

  const renderAppConfig = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {appCfgLoading && <LinearProgress sx={{ mb: 1 }} />}
      {appCfg && !appCfgLoading && (
        <Box>
          {/* ── Limits ── */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" gutterBottom>
            Streaming & Query Limits
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Setting</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Value</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {[
                  { key: 'max_stream_files', label: 'Max Stream Files', desc: 'Max S3 parquet files per streaming query', type: 'number' },
                  { key: 'stream_query_limit_max', label: 'Stream Row Limit (Max)', desc: 'Maximum rows for streaming queries', type: 'number' },
                  { key: 'stream_page_size_max', label: 'Stream Page Size (Max)', desc: 'Maximum page size for stream pagination', type: 'number' },
                  { key: 'stream_chart_top_n', label: 'Stream Chart Top N', desc: 'Max rows for streaming chart aggregation', type: 'number' },
                  { key: 'stream_chart_max_series', label: 'Stream Chart Max Series', desc: 'Max series in multi-series charts', type: 'number' },
                  { key: 'max_upload_size_mb', label: 'Max Upload Size (MB)', desc: 'Maximum file upload size in MB', type: 'number' },
                  { key: 'max_display_cols', label: 'Grid Default Columns', desc: 'Default visible columns in data grid (user can add/remove anytime)', type: 'number' },
                  { key: 'col_auto_project', label: 'Column Auto-Project', desc: 'Query builder auto-select threshold for wide tables', type: 'number' },
                  { key: 'default_query_limit', label: 'Default Query Limit', desc: 'Default row limit for queries', type: 'number' },
                  { key: 'duckdb_threads_per_query', label: 'DuckDB Threads/Query', desc: 'Max CPU threads per DuckDB query (0 = auto from CPU/concurrency)', type: 'number' },
                  { key: 'duckdb_memory_limit_mb', label: 'DuckDB Memory/Query (MB)', desc: 'Per-query DuckDB memory cap in MB (0 = unlimited)', type: 'number' },
                  { key: 'query_timeout_seconds', label: 'Query Timeout (sec)', desc: 'Max query execution time in seconds (0 = no limit)', type: 'number' },
                  { key: 'max_concurrent_per_user', label: 'Max Queries/User', desc: 'Max concurrent queries per user', type: 'number' },
                  { key: 'max_concurrent_global', label: 'Max Queries Global', desc: 'System-wide max concurrent queries', type: 'number' },
                  { key: 'streaming_default_on', label: 'Streaming Default On', desc: 'Enable streaming toggle by default', type: 'bool' },
                  { key: 'stream_bg_download_default', label: 'Background Download Default', desc: 'Enable background download by default', type: 'bool' },
                ].map(({ key, label, desc, type }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      {type === 'bool' ? (
                        <TextField
                          size="small" select variant="outlined"
                          value={appCfgDraft.limits?.[key] ?? false}
                          onChange={e => updateAppCfgDraft('limits', key, e.target.value === 'true')}
                          inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                          sx={{ minWidth: 80 }}
                        >
                          <MenuItem value="true">Yes</MenuItem>
                          <MenuItem value="false">No</MenuItem>
                        </TextField>
                      ) : (
                        <TextField
                          size="small" type="number" variant="outlined"
                          value={appCfgDraft.limits?.[key] ?? ''}
                          onChange={e => updateAppCfgDraft('limits', key, e.target.value)}
                          inputProps={{ min: 1, style: { fontSize: 12, padding: '4px 8px', width: 80 } }}
                        />
                      )}
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>{desc}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {/* ── Feature Toggles ── */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" sx={{ mt: 3 }} gutterBottom>
            Feature Toggles & Role Access
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Feature</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Value</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>Streaming Mode</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={appCfgDraft.features?.streaming_mode || 'all'}
                      onChange={e => updateAppCfgDraft('features', 'streaming_mode', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 140 }}
                    >
                      <MenuItem value="all">All (Stream + Download)</MenuItem>
                      <MenuItem value="stream_only">Stream Only</MenuItem>
                      <MenuItem value="download_only">Download Only</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>
                    Controls available data access modes
                  </TableCell>
                </TableRow>
                {[
                  { key: 'streaming_enabled_roles', label: 'Streaming Enabled', desc: 'Roles that can use S3 streaming' },
                  { key: 'export_enabled_roles', label: 'Export Enabled', desc: 'Roles that can export data' },
                  { key: 'sql_editor_enabled_roles', label: 'SQL Editor Enabled', desc: 'Roles that can use raw SQL editor' },
                  { key: 'scheduler_enabled_roles', label: 'Scheduler Enabled', desc: 'Roles that can create schedules' },
                  { key: 'connections_enabled_roles', label: 'Connections Enabled', desc: 'Roles that can manage connections' },
                  { key: 'upload_enabled_roles', label: 'Upload Enabled', desc: 'Roles that can upload files' },
                ].map(({ key, label, desc }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" variant="outlined"
                        value={appCfgDraft.features?.[key] ?? ''}
                        onChange={e => updateAppCfgDraft('features', key, e.target.value)}
                        placeholder="admin,analyst,viewer"
                        inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 160 } }}
                      />
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>Max Query Limit by Role</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" variant="outlined"
                      value={appCfgDraft.features?.max_query_limit_by_role ?? ''}
                      onChange={e => updateAppCfgDraft('features', 'max_query_limit_by_role', e.target.value)}
                      placeholder="viewer:1000,analyst:10000"
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 200 } }}
                    />
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>
                    Per-role row limits (0 = unlimited)
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          {/* ── S3 Result Storage ── */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" sx={{ mt: 3 }} gutterBottom>
            S3 Result Storage
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Setting</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Value</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>Enabled</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={String(appCfgDraft.s3_results?.enabled ?? false)}
                      onChange={e => updateAppCfgDraft('s3_results', 'enabled', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 80 }}>
                      <MenuItem value="true">Yes</MenuItem>
                      <MenuItem value="false">No</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>Enable S3 result storage (requires S3 connection)</TableCell>
                </TableRow>
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>Storage Mode</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={appCfgDraft.s3_results?.storage_mode || 'local'}
                      onChange={e => updateAppCfgDraft('s3_results', 'storage_mode', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 120 }}>
                      <MenuItem value="local">Local Only</MenuItem>
                      <MenuItem value="auto">Auto (S3 above threshold)</MenuItem>
                      <MenuItem value="s3">Always S3</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>Where to store query results: local disk, S3 above size threshold, or always S3</TableCell>
                </TableRow>
                {[
                  { key: 'size_threshold_mb', label: 'Size Threshold (MB)', desc: 'Files larger than this are uploaded to S3 (auto mode)', type: 'number' },
                  { key: 'prefix', label: 'S3 Key Prefix', desc: 'S3 key prefix for result files', type: 'text' },
                  { key: 'bucket_override', label: 'Bucket Override', desc: 'Use a different bucket for results (empty = default S3 bucket)', type: 'text' },
                ].map(({ key, label, desc, type }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField size="small" type={type} variant="outlined"
                        value={appCfgDraft.s3_results?.[key] ?? ''}
                        onChange={e => updateAppCfgDraft('s3_results', key, type === 'number' ? Number(e.target.value) : e.target.value)}
                        inputProps={{ ...(type === 'number' ? { min: 1 } : {}), style: { fontSize: 12, padding: '4px 8px', width: type === 'number' ? 80 : 160 } }}
                      />
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem' }}>Delete Local After Upload</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField size="small" select variant="outlined"
                      value={String(appCfgDraft.s3_results?.delete_local_after_upload ?? false)}
                      onChange={e => updateAppCfgDraft('s3_results', 'delete_local_after_upload', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }} sx={{ minWidth: 80 }}>
                      <MenuItem value="true">Yes</MenuItem>
                      <MenuItem value="false">No</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>Remove local parquet file after S3 upload to save disk space</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 2 }}>
            <Button size="small" variant="text" onClick={loadAppConfig} disabled={appCfgSaving}>
              Reset
            </Button>
            <Button size="small" variant="contained"
              startIcon={appCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
              onClick={handleAppCfgSave} disabled={appCfgSaving}>
              Save Configuration
            </Button>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Changes apply immediately without server restart. Persisted to config.json.
          </Typography>
        </Box>
      )}
      {!appCfg && !appCfgLoading && (
        <Typography variant="body2" color="text.secondary">Failed to load configuration.</Typography>
      )}
    </Paper>
  );

  const renderQueueConfig = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {queueCfgLoading && <LinearProgress sx={{ mb: 1 }} />}
      {queueCfg && !queueCfgLoading && (
        <Box>
          {/* ── Status Banner ── */}
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Backend" value={queueCfg.status?.backend || '—'} />
            <StatCard label="Connected" value={queueCfg.status?.connected ? 'Yes' : 'No'}
              warn={!queueCfg.status?.connected} />
            {queueCfg.status?.pending_tasks !== undefined && (
              <StatCard label="Pending Tasks" value={queueCfg.status.pending_tasks} />
            )}
            {queueCfg.status?.active_tasks !== undefined && (
              <StatCard label="Active Tasks" value={queueCfg.status.active_tasks} />
            )}
          </Stack>

          {/* ── Configuration ── */}
          <Typography variant="subtitle2" fontWeight={700} color="primary" gutterBottom>
            Queue Backend Settings
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Setting</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Value</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>Backend</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={queueCfgDraft.backend || 'sqlite'}
                      onChange={e => updateQueueDraft('backend', e.target.value)}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 120 }}
                    >
                      <MenuItem value="sqlite">SQLite (default)</MenuItem>
                      <MenuItem value="redis">Redis</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>
                    Task queue backend. Redis enables instant delivery, pub/sub events, and multi-worker scaling.
                  </TableCell>
                </TableRow>
                {[
                  { key: 'redis_url',       label: 'Redis URL',         desc: 'Redis connection URL (e.g. redis://redis:6379/0)',       placeholder: 'redis://localhost:6379/0' },
                  { key: 'redis_password',   label: 'Redis Password',    desc: 'Redis AUTH password (leave empty if none)',               placeholder: '' },
                  { key: 'key_prefix',       label: 'Key Prefix',        desc: 'Redis key namespace prefix (for multi-tenant)',           placeholder: 'qs' },
                ].map(({ key, label, desc, placeholder }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" variant="outlined"
                        type={key === 'redis_password' ? 'password' : 'text'}
                        value={queueCfgDraft[key] ?? ''}
                        onChange={e => updateQueueDraft(key, e.target.value)}
                        placeholder={placeholder}
                        inputProps={{ style: { fontSize: 12, padding: '4px 8px', width: 220 } }}
                      />
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>{desc}</TableCell>
                  </TableRow>
                ))}
                {[
                  { key: 'redis_db',       label: 'Redis DB',       desc: 'Redis database number (0-15)',   type: 'number' },
                  { key: 'task_ttl_hours',  label: 'Task TTL (hrs)', desc: 'Auto-expire completed tasks after N hours', type: 'number' },
                ].map(({ key, label, desc }) => (
                  <TableRow key={key} hover>
                    <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{label}</TableCell>
                    <TableCell sx={{ py: 0.5, px: 1 }}>
                      <TextField
                        size="small" type="number" variant="outlined"
                        value={queueCfgDraft[key] ?? ''}
                        onChange={e => updateQueueDraft(key, Number(e.target.value))}
                        inputProps={{ min: 0, style: { fontSize: 12, padding: '4px 8px', width: 80 } }}
                      />
                    </TableCell>
                    <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>{desc}</TableCell>
                  </TableRow>
                ))}
                <TableRow hover>
                  <TableCell sx={{ py: 0.5, px: 1, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>Redis SSL</TableCell>
                  <TableCell sx={{ py: 0.5, px: 1 }}>
                    <TextField
                      size="small" select variant="outlined"
                      value={queueCfgDraft.redis_ssl ? 'true' : 'false'}
                      onChange={e => updateQueueDraft('redis_ssl', e.target.value === 'true')}
                      inputProps={{ style: { fontSize: 12, padding: '4px 8px' } }}
                      sx={{ minWidth: 80 }}
                    >
                      <MenuItem value="false">No</MenuItem>
                      <MenuItem value="true">Yes</MenuItem>
                    </TextField>
                  </TableCell>
                  <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem', color: 'text.secondary' }}>
                    Use TLS/SSL for Redis connection (rediss://)
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          {/* ── Test Redis + Save buttons ── */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <Button size="small" variant="outlined" color="info"
                onClick={handleTestRedis}
                disabled={redisTestBusy}
                startIcon={redisTestBusy ? <CircularProgress size={14} /> : <HealthIcon />}
              >
                Test Redis
              </Button>
              {redisTestResult && (
                <Chip
                  size="small"
                  icon={redisTestResult.connected
                    ? <OkIcon sx={{ fontSize: '14px !important' }} />
                    : <ErrIcon sx={{ fontSize: '14px !important' }} />}
                  label={redisTestResult.connected
                    ? `Connected (v${redisTestResult.redis_version})`
                    : `Failed: ${redisTestResult.error}`}
                  color={redisTestResult.connected ? 'success' : 'error'}
                  variant="outlined"
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button size="small" variant="text" onClick={loadQueueConfig} disabled={queueCfgSaving}>
                Reset
              </Button>
              <Button size="small" variant="contained"
                startIcon={queueCfgSaving ? <CircularProgress size={14} /> : <SaveIcon />}
                onClick={handleQueueCfgSave} disabled={queueCfgSaving}>
                Save Queue Config
              </Button>
            </Box>
          </Box>
          <Alert severity="info" sx={{ mt: 1.5 }} variant="outlined">
            Switching backend between SQLite and Redis requires a <strong>server restart</strong> to take effect.
            Redis must be reachable when the server starts with <code>backend: "redis"</code>.
            If Redis is unavailable at startup, the system automatically falls back to SQLite.
          </Alert>
        </Box>
      )}
      {!queueCfg && !queueCfgLoading && (
        <Typography variant="body2" color="text.secondary">Failed to load queue configuration.</Typography>
      )}
    </Paper>
  );

  const renderScheduler = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {schedulerStatus ? (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Status"
              value={!schedulerStatus.initialized ? 'Not Init' : schedulerStatus.paused ? 'Paused' : 'Running'}
              warn={schedulerStatus.paused} />
            <StatCard label="Jobs" value={schedulerStatus.job_count ?? 0} />
          </Stack>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Button
              size="small" variant="contained"
              color={schedulerStatus.paused ? 'success' : 'warning'}
              startIcon={schedulerBusy ? <CircularProgress size={14} /> : schedulerStatus.paused ? <ActiveIcon /> : <PauseIcon />}
              onClick={handleSchedulerToggle}
              disabled={schedulerBusy || !schedulerStatus.initialized}
            >
              {schedulerStatus.paused ? 'Resume Scheduler' : 'Pause Scheduler'}
            </Button>
            <Typography variant="caption" color="text.secondary">
              {schedulerStatus.paused
                ? 'All scheduled jobs are paused. Running jobs will finish normally.'
                : 'Scheduler is active. Pause to stop new job triggers.'}
            </Typography>
          </Box>

          {schedulerStatus.jobs?.length > 0 && (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Job Name', 'Next Run', 'Status'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5, px: 1 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {schedulerStatus.jobs.map((j: any) => (
                    <TableRow key={j.id} hover>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.75rem' }}>{j.name}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1, fontSize: '0.72rem' }}>{j.next_run ? fmtDate(j.next_run) : '—'}</TableCell>
                      <TableCell sx={{ py: 0.5, px: 1 }}>
                        <Chip size="small" label={j.paused ? 'Paused' : 'Active'}
                          color={j.paused ? 'warning' : 'success'} variant="outlined"
                          sx={{ height: 20, fontSize: 11 }} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </>
      ) : (
        <Typography variant="body2" color="text.secondary">Loading scheduler status...</Typography>
      )}
    </Paper>
  );

  const renderUserManagement = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button size="small" variant="contained" onClick={() => { setAdLookup(null); setAdLookupError(''); setUserDlg({ open: true, mode: 'add', username: '', password: '', role: 'analyst' }); }}>
          + Add User
        </Button>
      </Box>
      {userMgmtLoading && <LinearProgress sx={{ mb: 1 }} />}
      {!userMgmtLoading && userList.length === 0 ? (
        <Typography variant="body2" color="text.secondary">No users configured (auth may be disabled)</Typography>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                {['User', 'Role', 'Actions'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {userList.map(u => (
                <TableRow key={u.username} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <Avatar sx={{ width: 22, height: 22, fontSize: 11, bgcolor: u.role === 'admin' ? theme.palette.error.light : u.role === 'analyst' ? theme.palette.primary.light : theme.palette.grey[400] }}>
                        {u.username[0].toUpperCase()}
                      </Avatar>
                      <Typography variant="body2">{u.username}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip size="small" label={u.role} color={u.role === 'admin' ? 'error' : u.role === 'analyst' ? 'primary' : 'default'} variant="outlined" sx={{ height: 20, fontSize: 11, fontWeight: 700, textTransform: 'capitalize' }} />
                  </TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => setUserDlg({ open: true, mode: 'edit', username: u.username, password: '', role: u.role })}>
                      <SettingsIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" color="error" onClick={() => handleDeleteUser(u.username)}>
                      <CancelIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );

  const renderUserActivity = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      {loading.userStats && <LinearProgress sx={{ mb: 2 }} />}
      {userStats.length === 0 && !loading.userStats ? (
        <Typography variant="body2" color="text.secondary">No user activity today</Typography>
      ) : (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                {['User', 'Active Now', 'Queries Today', 'Errors', 'Last Active'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.72rem' }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {userStats.map(u => (
                <TableRow key={u.username} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <Avatar sx={{ width: 22, height: 22, fontSize: 11,
                        bgcolor: theme.palette.primary.light }}>
                        {u.username[0].toUpperCase()}
                      </Avatar>
                      <Typography variant="body2">{u.username}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    {u.active_now > 0
                      ? <Chip size="small" label={u.active_now} color="primary" variant="outlined"
                          sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
                      : <Typography variant="body2" color="text.disabled">—</Typography>
                    }
                  </TableCell>
                  <TableCell sx={{ fontSize: '0.8rem' }}>{u.queries_today}</TableCell>
                  <TableCell>
                    {u.failed_today > 0
                      ? <Chip size="small" label={u.failed_today} color="error" variant="outlined"
                          sx={{ height: 20, fontSize: 11 }} />
                      : <Typography variant="body2" color="text.disabled">—</Typography>
                    }
                  </TableCell>
                  <TableCell sx={{ fontSize: '0.72rem', color: 'text.secondary', whiteSpace: 'nowrap' }}>
                    {fmtDate(u.last_seen)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );

  const renderStorage = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button size="small"
          startIcon={cleanupBusy ? <CircularProgress size={14} /> : <CleanupIcon />}
          variant="outlined" color="warning" onClick={handleCleanup} disabled={cleanupBusy}>
          Clean Up Now
        </Button>
      </Box>
      {loading.storage && <LinearProgress sx={{ mb: 2 }} />}
      {storage && (
        <>
          <Stack direction="row" spacing={2} mb={2} flexWrap="wrap" useFlexGap>
            {Object.entries(storage.directories || {}).map(([name, info]: [string, any]) => (
              <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <FolderIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                <Box>
                  <Typography variant="caption" color="text.secondary"
                    sx={{ textTransform: 'capitalize', display: 'block' }}>{name}</Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {fmtSize(info.size_bytes)}
                    <Typography component="span" variant="caption"
                      color="text.secondary" sx={{ ml: 0.5 }}>
                      {info.file_count} files
                    </Typography>
                  </Typography>
                </Box>
              </Box>
            ))}
          </Stack>
          {storage.disk && (
            <Box sx={{ mb: 1.5 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" color="text.secondary">Disk usage</Typography>
                <Typography variant="caption" color="text.secondary">
                  {fmtSize(storage.disk.used_gb * 1024 ** 3)} / {fmtSize(storage.disk.total_gb * 1024 ** 3)}
                </Typography>
              </Box>
              <LinearProgress variant="determinate" value={storage.disk.used_pct}
                color={storage.disk.used_pct > 85 ? 'error' : storage.disk.used_pct > 70 ? 'warning' : 'primary'}
                sx={{ height: 8, borderRadius: 4 }} />
            </Box>
          )}
          <Divider sx={{ my: 1.5 }} />
          <Typography variant="caption" color="text.secondary">
            Downloads expire after <strong>{storage.settings?.downloads_expiry_days}d</strong> ·
            Execution history kept <strong>{storage.settings?.execution_retention_days}d</strong> ·
            Cache limit <strong>{fmtMb(storage.settings?.max_cache_size_mb)}</strong> ·
            Downloads limit <strong>{fmtMb(storage.settings?.max_downloads_size_mb)}</strong>
          </Typography>
        </>
      )}
    </Paper>
  );

  const renderCache = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button size="small"
          startIcon={cacheBusy ? <CircularProgress size={14} /> : <ClearCacheIcon />}
          variant="outlined" color="error" onClick={handleClearCache} disabled={cacheBusy}>
          Clear Cache
        </Button>
      </Box>
      {loading.cache && <LinearProgress sx={{ mb: 2 }} />}
      {cache && (
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
          <StatCard label="Cached Results" value={cache.total_entries ?? cache.count ?? '—'} />
          <StatCard label="Cache Size"
            value={fmtSize((cache.total_size_bytes ?? cache.size_bytes) || 0)} />
          <StatCard label="Hit Rate"
            value={cache.hit_rate != null ? `${Math.round(cache.hit_rate * 100)}%` : '—'} />
        </Stack>
      )}
      {!loading.cache && !cache && (
        <Typography variant="body2" color="text.secondary">Cache stats unavailable</Typography>
      )}
    </Paper>
  );

  const renderAuditLog = () => (
    <Paper variant="outlined" sx={{ p: 2.5 }}>
      <Stack direction="row" spacing={1.5} mb={2}>
        <TextField
          size="small" placeholder="Filter by user"
          value={auditSearch}
          onChange={e => { setAuditSearch(e.target.value); setAuditPage(0); }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>,
            endAdornment: auditSearch
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setAuditSearch('')}>
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              : null,
          }}
          sx={{ width: 200 }}
        />
        <TextField
          size="small" placeholder="Filter by action"
          value={auditAction}
          onChange={e => { setAuditAction(e.target.value); setAuditPage(0); }}
          InputProps={{
            endAdornment: auditAction
              ? <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setAuditAction('')}>
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              : null,
          }}
          sx={{ width: 200 }}
        />
      </Stack>

      {loading.audit && <LinearProgress sx={{ mb: 1 }} />}
      <TableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              {['Timestamp', 'User', 'Action', 'Resource', 'IP'].map(h => (
                <TableCell key={h} sx={{ fontWeight: 700, fontSize: '0.75rem' }}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {auditLog.length === 0 && !loading.audit ? (
              <TableRow>
                <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  No audit entries found
                </TableCell>
              </TableRow>
            ) : auditLog.map((row, i) => (
              <TableRow key={i} hover>
                <TableCell sx={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                  {fmtDate(row.timestamp)}
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem' }}>{row.username || '—'}</TableCell>
                <TableCell>
                  <Chip size="small" label={row.action} variant="outlined"
                    sx={{ fontSize: '0.7rem', height: 20 }} />
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                  {row.resource_type
                    ? `${row.resource_type}${row.resource_id ? ` #${String(row.resource_id).substring(0, 8)}` : ''}`
                    : '—'}
                </TableCell>
                <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                  {row.ip_address || '—'}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={auditTotal > 0 ? auditTotal : auditLog.length}
        page={auditPage}
        rowsPerPage={AUDIT_PER_PAGE}
        rowsPerPageOptions={[AUDIT_PER_PAGE]}
        onPageChange={(_, p) => setAuditPage(p)}
      />
    </Paper>
  );

  // ── Renderer map ──
  const RENDERERS: Record<AdminSection, () => React.ReactNode> = {
    activeQueries:  renderActiveQueries,
    systemHealth:   renderSystemHealth,
    workerPool:     renderWorkerPool,
    appConfig:      renderAppConfig,
    queueConfig:    renderQueueConfig,
    scheduler:      renderScheduler,
    userManagement: renderUserManagement,
    userActivity:   renderUserActivity,
    storage:        renderStorage,
    cache:          renderCache,
    auditLog:       renderAuditLog,
    rlsPolicies:        () => <RLSAdminSection />,
    connectionProfiles: () => <ConnectionProfilesAdminSection />,
    workspaces:         () => <WorkspaceAdminSection />,
    auditCompliance:    () => <AuditComplianceAdminSection />,
    uiVisibility:       () => <UIVisibilityAdminSection />,
  };

  // Find current section label
  const currentLabel = ADMIN_SECTIONS.flatMap(g => g.items).find(i => i.id === activeSection)?.label ?? '';

  // ══════════════════════════════════════════════════════════════════════════
  // ── Render ────────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════
  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 64px)' }}>

      {/* ── Left nav sidebar ── */}
      <Box sx={{
        width: 220,
        flexShrink: 0,
        borderRight: 1,
        borderColor: 'divider',
        bgcolor: 'background.paper',
        overflowY: 'auto',
        py: 1,
      }}>
        {/* Mini header */}
        <Box sx={{ px: 2, py: 1.5, mb: 0.5 }}>
          <Typography variant="subtitle2" fontWeight={700}>Admin Panel</Typography>
        </Box>
        <Divider />

        {ADMIN_SECTIONS.map(group => (
          <Fragment key={group.group}>
            <Typography
              variant="overline"
              sx={{
                px: 2, pt: 2, pb: 0.5, display: 'block',
                color: 'text.disabled', fontSize: '0.6rem', letterSpacing: 1.2,
              }}
            >
              {group.group}
            </Typography>
            <List disablePadding>
              {group.items.map(item => (
                <ListItemButton
                  key={item.id}
                  selected={activeSection === item.id}
                  onClick={() => setActiveSection(item.id)}
                  sx={{
                    minHeight: 38,
                    px: 2,
                    py: 0.25,
                    '&.Mui-selected': {
                      bgcolor: 'action.selected',
                      borderRight: 3,
                      borderColor: 'primary.main',
                    },
                  }}
                >
                  <ListItemIcon sx={{
                    minWidth: 30,
                    color: activeSection === item.id ? 'primary.main' : 'text.secondary',
                  }}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    primaryTypographyProps={{
                      fontSize: '0.82rem',
                      fontWeight: activeSection === item.id ? 600 : 400,
                    }}
                  />
                  {/* Badge for active queries count */}
                  {item.id === 'activeQueries' && totalActive > 0 && (
                    <Chip size="small" label={totalActive} color="error"
                      sx={{ height: 18, fontSize: 10, fontWeight: 700, ml: 0.5 }} />
                  )}
                </ListItemButton>
              ))}
            </List>
          </Fragment>
        ))}
      </Box>

      {/* ── Right content panel ── */}
      <Box sx={{ flex: 1, overflow: 'auto', p: 3 }}>
        {/* Content header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
          <Typography variant="h5" fontWeight={700}>{currentLabel}</Typography>
          <Button variant="outlined" size="small" startIcon={<RefreshIcon />} onClick={handleRefresh}>
            Refresh
          </Button>
        </Box>

        {/* Active section content */}
        {RENDERERS[activeSection]?.()}
      </Box>

      {/* ── Cancel confirm dialog ── */}
      <Dialog open={Boolean(cancelTarget)} onClose={() => !cancelBusy && setCancelTarget(null)}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CancelIcon color="error" />
          Cancel Query
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to cancel the query running for{' '}
            <strong>{cancelTarget?.executed_by || 'guest'}</strong>?
            {cancelTarget?.duration_seconds >= WARN_SECS && (
              <><br /><br />
                <Typography component="span" color="warning.main" fontWeight={600}>
                  This query has been running for {fmtDuration(cancelTarget?.duration_seconds)}.
                </Typography>
              </>
            )}
          </DialogContentText>
          {cancelTarget && (
            <Box sx={{ mt: 2, p: 1.5, bgcolor: 'action.hover', borderRadius: 1, fontSize: '0.8rem' }}>
              <strong>ID:</strong> {cancelTarget.execution_id?.substring(0, 16)}…<br />
              <strong>Connection:</strong> {cancelTarget.connection_name || '—'}<br />
              <strong>Started:</strong> {fmtDate(cancelTarget.started_at)}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelTarget(null)} disabled={cancelBusy}>Keep Running</Button>
          <Button variant="contained" color="error" onClick={handleAdminCancel} disabled={cancelBusy}
            startIcon={cancelBusy ? <CircularProgress size={14} /> : <CancelIcon />}>
            Cancel Query
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Add / Edit User Dialog ── */}
      <Dialog open={userDlg.open} onClose={() => setUserDlg({ ...userDlg, open: false })} maxWidth="xs" fullWidth>
        <DialogTitle>{userDlg.mode === 'add' ? 'Add User' : `Edit User — ${userDlg.username}`}</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
          {userDlg.mode === 'add' && (
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField label={isAdMode ? 'Windows ID' : 'Username'} size="small" fullWidth value={userDlg.username}
                onChange={e => { setUserDlg({ ...userDlg, username: e.target.value }); setAdLookup(null); setAdLookupError(''); }}
                autoFocus
                onKeyDown={e => { if (isAdMode && e.key === 'Enter') { e.preventDefault(); handleAdLookup(); } }}
              />
              {isAdMode && (
                <Button size="small" variant="outlined" onClick={handleAdLookup}
                  disabled={!userDlg.username.trim() || adLookupLoading}
                  sx={{ minWidth: 90, whiteSpace: 'nowrap' }}>
                  {adLookupLoading ? <CircularProgress size={18} /> : 'Lookup'}
                </Button>
              )}
            </Box>
          )}

          {isAdMode && adLookup && (
            <Paper variant="outlined" sx={{ p: 1.5, bgcolor: 'success.50' }}>
              <Typography variant="body2" fontWeight={600}>{adLookup.display_name}</Typography>
              {adLookup.email && <Typography variant="caption" color="text.secondary">{adLookup.email}</Typography>}
              {adLookup.groups?.length > 0 && (
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  Groups: {adLookup.groups.slice(0, 5).join(', ')}{adLookup.groups.length > 5 ? ` (+${adLookup.groups.length - 5} more)` : ''}
                </Typography>
              )}
            </Paper>
          )}
          {isAdMode && adLookupError && (
            <Alert severity="error" sx={{ py: 0 }}>{adLookupError}</Alert>
          )}

          {!isAdMode && (
            <TextField label={userDlg.mode === 'add' ? 'Password' : 'New Password (leave blank to keep)'} size="small" fullWidth type="password"
              value={userDlg.password} onChange={e => setUserDlg({ ...userDlg, password: e.target.value })} />
          )}

          <TextField label="Role" size="small" fullWidth select value={userDlg.role}
            onChange={e => setUserDlg({ ...userDlg, role: e.target.value })}>
            <MenuItem value="admin">Admin</MenuItem>
            <MenuItem value="analyst">Analyst</MenuItem>
            <MenuItem value="viewer">Viewer</MenuItem>
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUserDlg({ ...userDlg, open: false })}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveUser}
            disabled={
              userDlg.mode === 'add' && (
                !userDlg.username.trim() ||
                (!isAdMode && !userDlg.password)
              )
            }>
            {userDlg.mode === 'add' ? 'Add User' : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default AdminPage;
