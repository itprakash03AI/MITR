"""
Iceberg table reader for S3.

Reads Apache Iceberg v1/v2 table metadata stored on S3 to discover the
active set of Parquet data files for a given table snapshot.

Flow:
  1. Scan S3 prefix for directories that contain a metadata/ subfolder
     with *.metadata.json files → those are Iceberg tables.
  2. Read the latest metadata.json to get current-snapshot-id.
  3. Follow the manifest-list (Avro) → manifest files (Avro) → data file paths.
  4. Return S3 keys for all ADDED/EXISTING Parquet data files.

Partition pruning (enterprise feature):
  Pass partition_filters=[{"col":"business_date","op":"equals","val":"2024-01-15"}]
  to get_iceberg_data_files().  The reader decodes per-manifest partition bounds
  from the Avro manifest-list and skips manifests (and their data files) that
  cannot possibly match the filter — dramatically reducing S3 API calls and
  latency for large tables.

Supported partition bound types:  string, date, int, long, float, double,
  timestamp (µs since epoch).

Requires: fastavro (for Avro manifest reading)
"""

from __future__ import annotations

import io
import json
import logging
import struct
from datetime import date, datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── S3 URI helpers ────────────────────────────────────────────────────────────

def _s3_uri_to_key(uri: str) -> str:
    """Convert s3://bucket/key  or  s3a://bucket/key  →  key only."""
    for scheme in ("s3a://", "s3n://", "s3://"):
        if uri.startswith(scheme):
            path = uri[len(scheme):]
            slash = path.find("/")
            return path[slash + 1:] if slash >= 0 else ""
    return uri  # already a bare key


def _read_s3_bytes(s3_client, bucket: str, key: str) -> bytes:
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    body = obj["Body"]
    try:
        return body.read()
    finally:
        body.close()


def _read_s3_json(s3_client, bucket: str, key: str) -> dict:
    return json.loads(_read_s3_bytes(s3_client, bucket, key))


def _read_avro(data: bytes) -> List[dict]:
    """Deserialise an Avro byte stream using fastavro."""
    try:
        import fastavro
        return list(fastavro.reader(io.BytesIO(data)))
    except ImportError:
        raise RuntimeError(
            "fastavro is required for Iceberg manifest reading. "
            "Install it with: pip install fastavro>=1.9.0"
        )


# ── Table detection ───────────────────────────────────────────────────────────

def is_iceberg_table(s3_client, bucket: str, prefix: str) -> bool:
    """Return True if the S3 prefix looks like an Iceberg table directory.

    Checks for a metadata/ subfolder containing Iceberg metadata files:
      - v1.metadata.json, 00000-xxx.metadata.json  (standard naming)
      - metadata.json  (simplified naming)
      - *.avro  (Avro manifest files used by some Iceberg writers)
    Also checks for a data/ subfolder as secondary confirmation.
    """
    meta_prefix = prefix.rstrip("/") + "/metadata/"
    try:
        resp = s3_client.list_objects_v2(
            Bucket=bucket, Prefix=meta_prefix, MaxKeys=30
        )
        for obj in resp.get("Contents", []):
            key = obj["Key"]
            basename = key.rsplit("/", 1)[-1].lower()
            # Standard: v1.metadata.json, 00001-uuid.metadata.json
            if basename.endswith(".metadata.json"):
                return True
            # Simplified: just metadata.json
            if basename == "metadata.json":
                return True
            # Avro manifest files (snap-*.avro, *.avro)
            if basename.endswith(".avro"):
                return True
    except Exception:
        pass
    return False


def list_iceberg_tables(
    s3_client, bucket: str, prefix: str = ""
) -> List[Dict[str, Any]]:
    """
    Scan one level of S3 prefix for Iceberg table directories.

    Args:
        s3_client: boto3 S3 client
        bucket:    S3 bucket name
        prefix:    S3 prefix to scan (warehouse path, e.g. "warehouse/db/")

    Returns:
        List of dicts: {name, prefix, type='iceberg_table', path}
    """
    paginator = s3_client.get_paginator("list_objects_v2")
    tables: List[Dict[str, Any]] = []

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]
                name = folder.rstrip("/").split("/")[-1]
                if is_iceberg_table(s3_client, bucket, folder):
                    tables.append({
                        "name":   name,
                        "prefix": folder,
                        "type":   "iceberg_table",
                        # virtual path consumed by the query builder
                        "path":   f"__iceberg__:{folder}",
                        "folder": prefix,
                    })
    except Exception as e:
        logger.error("Error scanning for Iceberg tables at %s: %s", prefix, e)
        raise

    logger.info("Found %d Iceberg tables under prefix '%s'", len(tables), prefix)
    return tables


# ── Partition spec + bound decoding ──────────────────────────────────────────

_EPOCH = date(1970, 1, 1)


def _decode_partition_value(raw: Any, iceberg_type: str) -> Any:
    """Decode a partition value that fastavro returns as a Python primitive.

    Unlike _decode_bound (which decodes raw bytes), fastavro already unpacks
    Avro data into Python ints/strings/etc.  But date columns come back as
    int (days since epoch) and timestamps as int (microseconds since epoch).
    This function converts them to human-readable strings.
    """
    if raw is None:
        return None
    if isinstance(raw, bytes):
        return _decode_bound(raw, iceberg_type)
    t = iceberg_type.lower()
    # Normalize transform types to their underlying semantics
    if t == "_transform_day":
        t = "date"
    elif t == "_transform_month":
        t = "_month"
    elif t == "_transform_year":
        t = "_year"
    elif t == "_transform_hour":
        t = "_hour"
    if isinstance(raw, int):
        if t == "date":
            try:
                return str(_EPOCH + timedelta(days=raw))
            except Exception:
                return str(raw)
        if t == "_month":
            try:
                year = 1970 + raw // 12
                month = 1 + raw % 12
                return f"{year:04d}-{month:02d}"
            except Exception:
                return str(raw)
        if t == "_year":
            return str(1970 + raw)
        if t == "_hour":
            try:
                dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(hours=raw)
                return dt.strftime("%Y-%m-%d %H:00")
            except Exception:
                return str(raw)
        if t in ("timestamp", "timestamptz", "timestamp_tz",
                 "timestamp with local time zone"):
            try:
                dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=raw)
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                return str(raw)
        if t == "time":
            try:
                total_secs = raw // 1_000_000
                h, rem = divmod(total_secs, 3600)
                m, s = divmod(rem, 60)
                return f"{h:02d}:{m:02d}:{s:02d}"
            except Exception:
                return str(raw)
    # String / already decoded — return as-is
    return raw


def _decode_bound(raw: Optional[bytes], iceberg_type: str) -> Any:
    """Decode an Iceberg partition bound byte array to a Python value.

    Returns None if raw is None / empty.
    """
    if not raw:
        return None
    try:
        t = iceberg_type.lower()
        # Normalize transform types to their underlying storage format
        if t == "_transform_day":
            t = "date"       # int32 days since epoch
        elif t == "_transform_month":
            t = "_month"     # int32 months since epoch
        elif t == "_transform_year":
            t = "_year"      # int32 years since 1970
        elif t == "_transform_hour":
            t = "_hour"      # int64 hours since epoch
        if t in ("string", "varchar", "char", "uuid"):
            return raw.decode("utf-8")
        if t == "boolean":
            return raw[0] != 0
        if t in ("int", "integer", "date", "_month", "_year"):
            val = struct.unpack_from("<i", raw)[0]
            if t == "date":
                return str(_EPOCH + timedelta(days=val))
            if t == "_month":
                year = 1970 + val // 12
                month = 1 + val % 12
                return f"{year:04d}-{month:02d}"
            if t == "_year":
                return str(1970 + val)
            return val
        if t in ("long", "bigint", "time", "timestamp", "timestamptz",
                 "timestamp_tz", "timestamp with local time zone", "_hour"):
            val = struct.unpack_from("<q", raw)[0]
            if t in ("timestamp", "timestamptz", "timestamp_tz",
                     "timestamp with local time zone"):
                # microseconds since epoch → ISO datetime
                try:
                    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=val)
                    return dt.isoformat()
                except Exception:
                    return str(val)
            if t == "_hour":
                try:
                    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(hours=val)
                    return dt.strftime("%Y-%m-%d %H:00")
                except Exception:
                    return str(val)
            return val
        if t == "float":
            return struct.unpack_from("<f", raw)[0]
        if t in ("double", "decimal"):
            return struct.unpack_from("<d", raw)[0]
        # Fallback: try utf-8
        return raw.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.debug("_decode_bound failed for type=%s raw=%r: %s", iceberg_type, raw, exc)
        return None


def _extract_partition_spec(metadata: dict) -> Dict[str, str]:
    """Return {partition_field_name: iceberg_type} from Iceberg metadata JSON.

    Handles both v1 (top-level "schema"/"partition-spec") and
    v2 (lists "schemas"/"partition-specs" with current IDs).
    """
    # Build field_id → type map from schema(s)
    field_type: Dict[int, str] = {}
    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    for schema in schemas:
        for field in schema.get("fields", []):
            fid = field.get("id") or field.get("field-id")
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                ftype = ftype.get("type", "string")
            if fid is not None:
                field_type[fid] = str(ftype)

    # Resolve active partition spec
    specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    default_spec_id = metadata.get("default-spec-id", 0)
    active_spec = next(
        (s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {}
    )

    result: Dict[str, str] = {}
    for pf in active_spec.get("fields", []):
        name      = pf.get("name", "")
        source_id = pf.get("source-id") or pf.get("source_id")
        transform = pf.get("transform", "identity")
        if not name:
            continue
        # Only identity-transformed fields have meaningful bounds we can compare
        if transform not in ("identity", "void"):
            # For bucket/truncate/year/month/day/hour transforms the bound type
            # differs — skip for now to avoid false pruning.
            if transform not in ("year", "month", "day", "hour"):
                result[name] = field_type.get(source_id, "string")
                continue
            # date-based transforms: bounds are ints (year/month/day/hour counts)
            # Register them but mark the type so the comparator knows.
            result[name] = f"_transform_{transform}"
            continue
        result[name] = field_type.get(source_id, "string")

    return result


# ── Partition filter evaluation ───────────────────────────────────────────────

def _manifest_matches_filters(
    manifest_entry: dict,
    partition_spec: Dict[str, str],
    filters: List[Dict[str, Any]],
) -> bool:
    """Return False only if we can *prove* no data file in this manifest satisfies
    all filters.  Returns True when uncertain (safe over-approximation).

    manifest_entry fields (from Avro manifest-list):
      partitions: list<{lower_bound: bytes, upper_bound: bytes, contains_null: bool}>
    """
    parts = manifest_entry.get("partitions")
    if not parts:
        return True   # no partition metadata → can't prune → keep manifest

    spec_fields = list(partition_spec.items())   # ordered: name, type

    for filt in filters:
        col = filt.get("col") or filt.get("column", "")
        op  = filt.get("op")  or filt.get("operator", "")
        val = filt.get("val") or filt.get("value", "")

        # Find index of this column in partition spec
        spec_idx = next(
            (i for i, (n, _) in enumerate(spec_fields) if n == col), None
        )
        if spec_idx is None or spec_idx >= len(parts):
            continue  # column not partitioned → can't prune on it

        ptype = spec_fields[spec_idx][1]
        pbounds = parts[spec_idx]
        lo_raw = pbounds.get("lower_bound")
        hi_raw = pbounds.get("upper_bound")
        has_null = pbounds.get("contains_null", False)

        lo = _decode_bound(lo_raw, ptype) if lo_raw else None
        hi = _decode_bound(hi_raw, ptype) if hi_raw else None

        if lo is None and hi is None:
            continue   # no bounds info → keep

        # Convert filter value to comparable type
        try:
            cval: Any = val
            if ptype in ("int", "integer") or ptype.startswith("_transform_"):
                cval = int(val)
            elif ptype in ("long", "bigint"):
                cval = int(val)
            elif ptype in ("float",):
                cval = float(val)
            elif ptype in ("double", "decimal"):
                cval = float(val)
        except (ValueError, TypeError):
            cval = str(val)

        # Apply operator check — if we can PROVE the manifest doesn't match, prune
        # Note: has_null doesn't affect comparison pruning — NULL never satisfies >, <, = etc.
        try:
            if op in ("equals", "eq", "=", "=="):
                if lo is not None and cval < lo:
                    return False
                if hi is not None and cval > hi:
                    return False
            elif op == "in" and isinstance(val, list):
                # For IN: prune if ALL values are outside the manifest bounds
                converted_vals = []
                for v in val:
                    try:
                        if ptype in ("int", "integer", "long", "bigint") or ptype.startswith("_transform_"):
                            converted_vals.append(int(v))
                        elif ptype in ("float", "double", "decimal"):
                            converted_vals.append(float(v))
                        else:
                            converted_vals.append(str(v))
                    except (ValueError, TypeError):
                        converted_vals.append(str(v))
                if lo is not None and hi is not None:
                    if all(cv < lo or cv > hi for cv in converted_vals):
                        return False
            elif op in ("not_equals", "ne", "!="):
                pass   # Can't prune safely on ≠
            elif op in ("gt", ">"):
                if hi is not None and cval >= hi:
                    return False
            elif op in ("gte", ">="):
                if hi is not None and cval > hi:
                    return False
            elif op in ("lt", "<"):
                if lo is not None and cval <= lo:
                    return False
            elif op in ("lte", "<="):
                if lo is not None and cval < lo:
                    return False
        except TypeError:
            pass  # incomparable types → keep

    return True   # manifest may contain matching rows


# ── Metadata + manifest traversal ────────────────────────────────────────────

def _latest_metadata_key(s3_client, bucket: str, meta_prefix: str) -> str:
    """Return the S3 key of the most-recently-modified *.metadata.json file.

    Uses paginator to handle metadata/ folders with >1000 files.
    """
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        candidates = []
        for page in paginator.paginate(Bucket=bucket, Prefix=meta_prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".metadata.json"):
                    candidates.append(obj)
    except Exception as exc:
        raise ValueError(
            f"Failed to list S3 objects under {meta_prefix}: {exc}"
        ) from exc
    if not candidates:
        raise ValueError(f"No Iceberg metadata JSON found under {meta_prefix}")
    return max(candidates, key=lambda x: x["LastModified"])["Key"]


def _batch_s3_metadata(
    s3_client, bucket: str, keys: List[str]
) -> Dict[str, Dict[str, Any]]:
    """Return {key: {size_bytes, last_modified}} for a list of S3 keys.

    Uses list_objects_v2 grouped by common prefix to minimise API calls instead
    of one head_object per file (which is O(N) round trips).
    """
    if not keys:
        return {}

    result: Dict[str, Dict[str, Any]] = {}

    # Group keys by their directory prefix (everything up to the last /)
    from collections import defaultdict
    prefix_map: Dict[str, List[str]] = defaultdict(list)
    for key in keys:
        slash = key.rfind("/")
        prefix = key[: slash + 1] if slash >= 0 else ""
        prefix_map[prefix].append(key)

    for prefix, prefix_keys in prefix_map.items():
        key_set = set(prefix_keys)
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    k = obj["Key"]
                    if k in key_set:
                        result[k] = {
                            "size_bytes":    obj["Size"],
                            "last_modified": obj["LastModified"].isoformat(),
                        }
        except Exception as exc:
            logger.warning("list_objects_v2 failed for prefix %s: %s", prefix, exc)
            # Fall back to individual HEAD for this batch
            for k in prefix_keys:
                try:
                    head = s3_client.head_object(Bucket=bucket, Key=k)
                    result[k] = {
                        "size_bytes":    head["ContentLength"],
                        "last_modified": head["LastModified"].isoformat(),
                    }
                except Exception:
                    result[k] = {"size_bytes": 0, "last_modified": ""}

    return result


def get_latest_partition_value(
    s3_client,
    bucket: str,
    table_prefix: str,
    *,
    metadata: Optional[dict] = None,
) -> Dict[str, str]:
    """Find the latest (max) partition value for date/timestamp partition columns.

    Efficiently reads only the manifest list (not individual manifests) to
    determine the max partition value from upper_bounds.

    Args:
        metadata: Pre-loaded Iceberg metadata dict.  When provided, skips
                  the S3 read for metadata.json (avoids duplicate fetches).

    Returns:
        {partition_column_name: latest_value_string}  e.g. {"business_date": "2024-03-15"}
    """
    if metadata is None:
        meta_prefix = table_prefix.rstrip("/") + "/metadata/"
        meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
        metadata = _read_s3_json(s3_client, bucket, meta_key)

    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        return {}

    snapshots = {
        s.get("snapshot-id"): s
        for s in metadata.get("snapshots", [])
        if s.get("snapshot-id") is not None
    }
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        return {}

    # Get partition spec
    partition_spec = _extract_partition_spec(metadata)
    if not partition_spec:
        return {}

    # Get ordered partition field names from active spec
    spec_fields = list(partition_spec.items())  # [(name, type), ...]

    # Only auto-filter date/timestamp columns with identity transform
    _DATE_TYPES = {"date", "timestamp", "timestamptz", "timestamp_tz",
                   "timestamp with local time zone"}
    date_indices: List[Tuple[int, str, str]] = []  # (index, name, type)
    for i, (name, ptype) in enumerate(spec_fields):
        if ptype.lower() in _DATE_TYPES:
            date_indices.append((i, name, ptype))

    if not date_indices:
        return {}

    # Read manifest list
    manifest_list_uri = snapshot.get("manifest-list")
    if not manifest_list_uri:
        return {}

    ml_key = _s3_uri_to_key(manifest_list_uri)
    try:
        manifest_list_data = _read_s3_bytes(s3_client, bucket, ml_key)
        manifests = _read_avro(manifest_list_data)
    except Exception:
        return {}

    # Scan manifest entries for max partition upper bounds
    max_values: Dict[str, str] = {}
    for manifest in manifests:
        # Only look at data manifests, not delete manifests
        content = manifest.get("content", 0)
        if content != 0:
            continue
        partitions = manifest.get("partitions") or []
        for idx, name, ptype in date_indices:
            if idx >= len(partitions):
                continue
            p_summary = partitions[idx]
            upper = p_summary.get("upper_bound")
            if upper is None:
                continue
            decoded = _decode_bound(upper, ptype)
            if decoded is None:
                continue
            decoded_str = str(decoded)
            # For timestamps, take only the date portion for partition comparison
            if ptype.lower() != "date" and "T" in decoded_str:
                decoded_str = decoded_str[:10]
            if name not in max_values or decoded_str > max_values[name]:
                max_values[name] = decoded_str

    if max_values:
        logger.info("Latest partition values for %s: %s", table_prefix, max_values)

    return max_values


def get_iceberg_data_files(
    s3_client,
    bucket: str,
    table_prefix: str,
    partition_filters: Optional[List[Dict[str, Any]]] = None,
    keys_only: bool = False,
    max_files: int = 0,
    *,
    metadata: Optional[dict] = None,
) -> List[Dict[str, Any]]:
    """
    Read Iceberg table metadata and return the active Parquet data files.

    Args:
        s3_client:         boto3 S3 client
        bucket:            S3 bucket name
        table_prefix:      S3 prefix of the Iceberg table root (ends with /)
        partition_filters: Optional list of filter dicts in adv_filters format
                           e.g. [{"col":"business_date","op":"equals","val":"2024-01-15"}]
                           Used to prune manifests via Iceberg partition bounds.
        keys_only:         If True, skip the expensive _batch_s3_metadata() call
                           and return entries with key/path only (for query execution).
        max_files:         If > 0, stop collecting files once this many are found.
                           Useful with LIMIT queries to avoid scanning all manifests.
        metadata:          Pre-loaded Iceberg metadata dict.  When provided, skips
                           the S3 read for metadata.json (avoids duplicate fetches).

    Returns:
        List of dicts: {key, name, path, size_bytes, last_modified, folder, type}
    """
    # ── Step 1: Read latest table metadata JSON ───────────────────────────────
    if metadata is None:
        meta_prefix = table_prefix.rstrip("/") + "/metadata/"
        meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
        metadata = _read_s3_json(s3_client, bucket, meta_key)
        meta_key_display = meta_key
    else:
        meta_key_display = "(cached)"
    logger.info("Iceberg metadata: %s (format-version %s)",
                meta_key_display, metadata.get("format-version", "?"))

    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        logger.warning("Table %s has no current snapshot — returning empty", table_prefix)
        return []

    snapshots = {s.get("snapshot-id"): s for s in metadata.get("snapshots", []) if s.get("snapshot-id") is not None}
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        raise ValueError(
            f"Snapshot {current_snapshot_id} not found in {meta_key}"
        )

    # ── Step 2: Parse partition spec (needed for pruning) ─────────────────────
    partition_spec: Dict[str, str] = {}
    use_pruning = bool(partition_filters)
    if use_pruning:
        try:
            partition_spec = _extract_partition_spec(metadata)
            logger.info(
                "Iceberg partition spec for %s: %s", table_prefix,
                {k: v for k, v in partition_spec.items()}
            )
        except Exception as exc:
            logger.warning("Could not parse partition spec — pruning disabled: %s", exc)
            use_pruning = False

    # ── Step 3: Read manifest list ────────────────────────────────────────────
    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        try:
            manifest_list_data = _read_s3_bytes(s3_client, bucket, ml_key)
            manifests = _read_avro(manifest_list_data)
        except Exception as exc:
            raise ValueError(
                f"Failed to read manifest list {ml_key}: {exc}"
            ) from exc
    else:
        manifests = snapshot.get("manifests", [])

    # ── Step 4: Prune manifests using partition bounds ─────────────────────────
    if use_pruning and partition_spec and partition_filters:
        total = len(manifests)
        manifests = [
            m for m in manifests
            if _manifest_matches_filters(m, partition_spec, partition_filters)
        ]
        pruned = total - len(manifests)
        if pruned:
            logger.info(
                "Iceberg partition pruning: skipped %d/%d manifests for table %s",
                pruned, total, table_prefix,
            )

    # ── Step 5: Read manifests in parallel and collect data file paths ────────
    # Resolve manifest paths first
    _manifest_paths: List[str] = []
    for manifest in manifests:
        manifest_path = (
            manifest.get("manifest_path")
            or manifest.get("manifest-path")
            or (manifest if isinstance(manifest, str) else None)
        )
        if manifest_path:
            _manifest_paths.append(_s3_uri_to_key(manifest_path))

    def _read_manifest(mk: str) -> list:
        """Read a single manifest file and return its Avro entries."""
        try:
            data = _read_s3_bytes(s3_client, bucket, mk)
            return _read_avro(data)
        except Exception as e:
            logger.warning("Could not read manifest %s: %s", mk, e)
            return []

    # Parallel read — up to 8 concurrent S3 fetches
    from concurrent.futures import ThreadPoolExecutor
    _PARALLEL = min(8, len(_manifest_paths)) or 1
    if len(_manifest_paths) > 1:
        with ThreadPoolExecutor(max_workers=_PARALLEL) as pool:
            _all_entries = list(pool.map(_read_manifest, _manifest_paths))
    else:
        _all_entries = [_read_manifest(mk) for mk in _manifest_paths]

    data_file_keys: List[str] = []
    _hit_limit = False
    for entries in _all_entries:
        if _hit_limit:
            break
        for entry in entries:
            # status: 0=EXISTING  1=ADDED  2=DELETED
            if entry.get("status") == 2:
                continue
            data_file = entry.get("data_file") or {}
            file_path  = data_file.get("file_path") or data_file.get("path", "")
            if not file_path.endswith(".parquet"):
                continue

            # ── Entry-level partition pruning ─────────────────────────
            if use_pruning and partition_filters and partition_spec:
                partition = data_file.get("partition") or {}
                skip_file = False
                for filt in partition_filters:
                    f_col = filt.get("col") or filt.get("column", "")
                    f_op  = filt.get("op")  or filt.get("operator", "")
                    f_val = filt.get("val") or filt.get("value", "")
                    if f_col not in partition_spec:
                        continue
                    raw_val = partition.get(f_col)
                    if raw_val is None:
                        continue
                    col_type = partition_spec[f_col]
                    decoded = _decode_partition_value(raw_val, col_type)
                    decoded_str = str(decoded) if decoded is not None else None

                    # IN operator — disjunctive (any value matches)
                    if f_op == "in" and isinstance(f_val, list):
                        if decoded_str is not None and decoded_str not in {str(v) for v in f_val}:
                            skip_file = True
                            break
                        continue

                    f_val_str = str(f_val)

                    if f_op in ("equals", "eq", "=", "=="):
                        if decoded_str != f_val_str:
                            skip_file = True; break
                    elif f_op in ("not_equals", "ne", "!="):
                        if decoded_str == f_val_str:
                            skip_file = True; break
                    elif f_op in ("gt", ">", "gte", ">=", "lt", "<", "lte", "<="):
                        try:
                            cmp_decoded = decoded
                            cmp_fval = f_val
                            if col_type.lower() in ("int", "integer", "long", "bigint"):
                                cmp_decoded = int(decoded_str) if decoded_str else None
                                cmp_fval = int(f_val_str)
                            elif col_type.lower() in ("float", "double", "decimal"):
                                cmp_decoded = float(decoded_str) if decoded_str else None
                                cmp_fval = float(f_val_str)
                            elif col_type.lower() in ("date", "timestamp", "timestamptz"):
                                cmp_decoded = decoded_str
                                cmp_fval = f_val_str
                            else:
                                cmp_decoded = decoded_str
                                cmp_fval = f_val_str
                            if cmp_decoded is not None:
                                if f_op in ("gt", ">") and cmp_decoded <= cmp_fval:
                                    skip_file = True; break
                                elif f_op in ("gte", ">=") and cmp_decoded < cmp_fval:
                                    skip_file = True; break
                                elif f_op in ("lt", "<") and cmp_decoded >= cmp_fval:
                                    skip_file = True; break
                                elif f_op in ("lte", "<=") and cmp_decoded > cmp_fval:
                                    skip_file = True; break
                        except (ValueError, TypeError):
                            pass
                if skip_file:
                    continue

            data_file_keys.append(_s3_uri_to_key(file_path))
            if max_files > 0 and len(data_file_keys) >= max_files:
                _hit_limit = True
                break

    logger.info("Iceberg table %s → %d data files after pruning (%d manifests read in parallel)%s",
                table_prefix, len(data_file_keys), len(_manifest_paths),
                f" (capped at {max_files})" if _hit_limit else "")

    # ── Step 6: Batch-fetch S3 metadata (replaces N×head_object) ─────────────
    # Skip this expensive step when caller only needs file paths (e.g. query execution)
    if keys_only:
        return [{"key": key, "path": key, "type": "parquet"} for key in data_file_keys]

    s3_meta = _batch_s3_metadata(s3_client, bucket, data_file_keys)

    result: List[Dict[str, Any]] = []
    for key in data_file_keys:
        meta = s3_meta.get(key, {})
        result.append({
            "key":           key,
            "name":          key.split("/")[-1],
            "path":          key,
            "size_bytes":    meta.get("size_bytes", 0),
            "last_modified": meta.get("last_modified", ""),
            "folder":        "/".join(key.split("/")[:-1]) + "/" if "/" in key else "",
            "type":          "parquet",
        })

    return result


def get_iceberg_partition_values(
    s3_client,
    bucket: str,
    table_prefix: str,
) -> Dict[str, Any]:
    """Extract distinct partition values from Iceberg manifest entries.

    Returns:
        {
            "partition_columns": [{"name": "businessdate", "type": "date", "transform": "identity"}],
            "values": {"businessdate": ["2024-01-01", "2024-01-02", ...]},
            "file_counts": {"businessdate": {"2024-01-01": 5, "2024-01-02": 3, ...}},
        }
    """
    meta_prefix = table_prefix.rstrip("/") + "/metadata/"
    meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
    metadata = _read_s3_json(s3_client, bucket, meta_key)

    # ── Get partition spec ────────────────────────────────────────────────────
    partition_spec = _extract_partition_spec(metadata)
    if not partition_spec:
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    # Build partition field index → (name, type) mapping
    spec_fields = list(partition_spec.items())  # ordered: [(name, type), ...]

    # Also get the field names for the schema (for source column resolution)
    specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    default_spec_id = metadata.get("default-spec-id", 0)
    active_spec = next(
        (s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {}
    )

    partition_columns = []
    field_id_to_name = {}
    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    for schema in schemas:
        for field in schema.get("fields", []):
            fid = field.get("id") or field.get("field-id")
            if fid is not None:
                field_id_to_name[fid] = field.get("name", "")

    for pf in active_spec.get("fields", []):
        src_id = pf.get("source-id") or pf.get("source_id")
        partition_columns.append({
            "name": pf.get("name", ""),
            "source_column": field_id_to_name.get(src_id, str(src_id)),
            "type": partition_spec.get(pf.get("name", ""), "string"),
            "transform": pf.get("transform", "identity"),
        })

    # ── Read manifests to collect partition values ────────────────────────────
    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}

    snapshots = {s.get("snapshot-id"): s for s in metadata.get("snapshots", []) if s.get("snapshot-id") is not None}
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}

    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        try:
            manifest_list_data = _read_s3_bytes(s3_client, bucket, ml_key)
            manifests = _read_avro(manifest_list_data)
        except Exception as exc:
            logger.error("Failed to read manifest list %s: %s", ml_key, exc)
            return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}
    else:
        manifests = snapshot.get("manifests", [])

    # ── FAST PATH: extract partition values from manifest-list summary ────────
    # Each manifest-list entry has a `partitions` field with per-column
    # {lower_bound, upper_bound} as BYTES.  For identity-transform partitions,
    # lower == upper means all files in that manifest share the same partition
    # value.  This avoids reading individual manifest files entirely —
    # only 2 S3 calls (metadata.json + manifest-list.avro) instead of 10+.

    values: Dict[str, set] = {name: set() for name, _ in spec_fields}
    file_counts: Dict[str, Dict[str, int]] = {name: {} for name, _ in spec_fields}
    record_counts: Dict[str, Dict[str, int]] = {name: {} for name, _ in spec_fields}
    # Partition combos — exact tuples for cascading selection in the UI.
    # Each combo is {col1: val1, col2: val2, ...} with file/record counts.
    _combo_map: Dict[tuple, Dict] = {}  # frozen-tuple → {cols + _files + _records}

    for manifest in manifests:
        parts_summary = manifest.get("partitions")
        n_added = manifest.get("added_data_files_count") or manifest.get("added_files_count") or 0
        n_existing = manifest.get("existing_data_files_count") or manifest.get("existing_files_count") or 0
        manifest_file_count = n_added + n_existing
        # Record counts available at manifest-list level
        n_added_rows = manifest.get("added_rows_count", 0) or 0
        n_existing_rows = manifest.get("existing_rows_count", 0) or 0
        manifest_record_count = n_added_rows + n_existing_rows

        combo: Dict[str, str] = {}
        if parts_summary:
            for idx, (col_name, col_type) in enumerate(spec_fields):
                if idx >= len(parts_summary):
                    continue
                pbound = parts_summary[idx]
                lo_raw = pbound.get("lower_bound")
                hi_raw = pbound.get("upper_bound")
                lo = _decode_bound(lo_raw, col_type) if lo_raw else None
                hi = _decode_bound(hi_raw, col_type) if hi_raw else None

                if lo is not None and hi is not None and lo == hi:
                    # Exact value — all files in this manifest share this partition value
                    str_val = str(lo)
                    values[col_name].add(str_val)
                    file_counts[col_name][str_val] = file_counts[col_name].get(str_val, 0) + max(manifest_file_count, 1)
                    record_counts[col_name][str_val] = record_counts[col_name].get(str_val, 0) + manifest_record_count
                    combo[col_name] = str_val
                elif lo is not None:
                    # Range — add both bounds as values (approximate but fast)
                    # Don't add to combo for this column (unknown exact value)
                    str_lo = str(lo)
                    values[col_name].add(str_lo)
                    file_counts[col_name][str_lo] = file_counts[col_name].get(str_lo, 0) + max(manifest_file_count // 2, 1)
                    record_counts[col_name][str_lo] = record_counts[col_name].get(str_lo, 0) + manifest_record_count // 2
                    if hi is not None and hi != lo:
                        str_hi = str(hi)
                        values[col_name].add(str_hi)
                        file_counts[col_name][str_hi] = file_counts[col_name].get(str_hi, 0) + max(manifest_file_count // 2, 1)
                        record_counts[col_name][str_hi] = record_counts[col_name].get(str_hi, 0) + manifest_record_count // 2

        # Record partial or complete combo — any manifest with at least one exact
        # partition column helps narrow cascading selection in the UI.
        # Columns absent from combo are treated as wildcards on the frontend.
        if len(combo) > 0:
            key = tuple(sorted(combo.items()))
            if key in _combo_map:
                _combo_map[key]["_files"] += max(manifest_file_count, 1)
                _combo_map[key]["_records"] += manifest_record_count
            else:
                _combo_map[key] = {**combo, "_files": max(manifest_file_count, 1), "_records": manifest_record_count}

    # If we found no values from summaries (older Iceberg format), fall back
    # to reading manifest files directly
    has_any_values = any(len(v) > 0 for v in values.values())
    if not has_any_values:
        logger.info("No partition summaries in manifest-list — falling back to manifest scan")
        from concurrent.futures import ThreadPoolExecutor, as_completed
        manifest_keys = []
        for manifest in manifests:
            mp = manifest.get("manifest_path") or manifest.get("manifest-path") or (manifest if isinstance(manifest, str) else None)
            if mp:
                manifest_keys.append(_s3_uri_to_key(mp))

        def _read_manifest(mk):
            data = _read_s3_bytes(s3_client, bucket, mk)
            return _read_avro(data)

        all_entries = []
        if manifest_keys:
            with ThreadPoolExecutor(max_workers=min(len(manifest_keys), 8)) as pool:
                future_to_key = {pool.submit(_read_manifest, mk): mk for mk in manifest_keys}
                for future in as_completed(future_to_key):
                    try:
                        all_entries.extend(future.result())
                    except Exception as e:
                        logger.warning("Could not read manifest for partition values: %s", e)

        for entry in all_entries:
            if entry.get("status") == 2:  # DELETED
                continue
            data_file = entry.get("data_file") or {}
            partition = data_file.get("partition") or {}
            entry_record_count = data_file.get("record_count", 0) or 0
            combo: Dict[str, str] = {}
            for idx, (col_name, col_type) in enumerate(spec_fields):
                raw_val = partition.get(col_name)
                if raw_val is None:
                    continue
                decoded = _decode_partition_value(raw_val, col_type)
                if decoded is not None:
                    str_val = str(decoded)
                    values[col_name].add(str_val)
                    file_counts[col_name][str_val] = file_counts[col_name].get(str_val, 0) + 1
                    record_counts[col_name][str_val] = record_counts[col_name].get(str_val, 0) + entry_record_count
                    combo[col_name] = str_val
            # Record combo from individual data file entry
            if len(combo) == len(spec_fields):
                key = tuple(sorted(combo.items()))
                if key in _combo_map:
                    _combo_map[key]["_files"] += 1
                    _combo_map[key]["_records"] += entry_record_count
                else:
                    _combo_map[key] = {**combo, "_files": 1, "_records": entry_record_count}

    # Sort values
    sorted_values = {}
    for name, vals in values.items():
        sorted_values[name] = sorted(vals)

    # Build combos list for cascading partition selection
    combos = list(_combo_map.values())

    return {
        "partition_columns": partition_columns,
        "values": sorted_values,
        "file_counts": {name: dict(sorted(counts.items())) for name, counts in file_counts.items()},
        "record_counts": {name: dict(sorted(counts.items())) for name, counts in record_counts.items()},
        "combos": combos,
    }
