"""
Natural Language to SQL — Pattern-based (Phase 48).

No external LLM required. Uses schema context + regex pattern matching
to generate SQL for common analytical query patterns.

Supported patterns:
  - "show/list/get all X"                    → SELECT * FROM X LIMIT 100
  - "count X" / "how many X"                → SELECT COUNT(*) FROM X
  - "top N X by Y"                           → SELECT ... ORDER BY Y DESC LIMIT N
  - "average/avg Y per/by X"                → SELECT X, AVG(Y) FROM ... GROUP BY X
  - "sum/total Y per/by X"                  → SELECT X, SUM(Y) FROM ... GROUP BY X
  - "X where Y is/= Z"                      → SELECT * FROM X WHERE Y = Z
  - "X between DATE1 and DATE2"             → SELECT * FROM X WHERE col BETWEEN ...
  - "X grouped by Y"                         → SELECT Y, COUNT(*) FROM X GROUP BY Y
  - "join X and Y on A = B"                 → SELECT * FROM X JOIN Y ON X.A = Y.B
  - "distinct values of Y in X"             → SELECT DISTINCT Y FROM X
  - "min/max Y in X"                         → SELECT MIN(Y), MAX(Y) FROM X
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple

logger = logging.getLogger(__name__)


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class NLToSQLResult:
    sql: str
    pattern_matched: str          # human-readable name of matched pattern
    confidence: float             # 0.0–1.0
    explanation: str              # what the query does
    warnings: List[str] = field(default_factory=list)
    alternatives: List[str] = field(default_factory=list)  # alt SQL variants


# ── Schema context ────────────────────────────────────────────────────────────

@dataclass
class SchemaContext:
    """Describes available tables/columns to aid SQL generation."""
    tables: List[str] = field(default_factory=list)             # table names
    columns: Dict[str, List[str]] = field(default_factory=dict) # table → [col, ...]
    connection_type: str = "duckdb"
    default_schema: Optional[str] = None


def _best_table_match(name: str, ctx: SchemaContext) -> Optional[str]:
    """Find closest table name match (case-insensitive, partial allowed)."""
    name_lower = name.lower().strip()
    # Exact match
    for t in ctx.tables:
        if t.lower() == name_lower:
            return t
    # Prefix / contains match
    for t in ctx.tables:
        if t.lower().startswith(name_lower) or name_lower in t.lower():
            return t
    # Pluralise / singularise naive
    for t in ctx.tables:
        tl = t.lower()
        if tl.rstrip('s') == name_lower.rstrip('s'):
            return t
    return name  # Return as-is if no match — user may know more than schema


def _best_column_match(col: str, table: str, ctx: SchemaContext) -> str:
    """Find best column name for a table."""
    col_lower = col.lower().strip()
    cols = ctx.columns.get(table, [])
    for c in cols:
        if c.lower() == col_lower:
            return c
    for c in cols:
        if c.lower().startswith(col_lower) or col_lower in c.lower():
            return c
    return col  # Return as-is


def _numeric_cols(table: str, ctx: SchemaContext) -> List[str]:
    """Heuristic: columns that look numeric by name."""
    numeric_hints = ('amount', 'total', 'count', 'sum', 'price', 'cost', 'revenue',
                     'value', 'qty', 'quantity', 'num', 'score', 'rate', 'pct', 'percent',
                     'size', 'bytes', 'duration', 'age', 'salary', 'fee', 'balance')
    cols = ctx.columns.get(table, [])
    return [c for c in cols if any(h in c.lower() for h in numeric_hints)]


def _date_cols(table: str, ctx: SchemaContext) -> List[str]:
    date_hints = ('date', 'time', 'at', 'created', 'updated', 'modified', 'timestamp', 'day', 'month', 'year')
    cols = ctx.columns.get(table, [])
    return [c for c in cols if any(h in c.lower() for h in date_hints)]


def _id_col(table: str, ctx: SchemaContext) -> Optional[str]:
    cols = ctx.columns.get(table, [])
    for c in cols:
        if c.lower() in ('id', f'{table.lower()}_id', 'pk'):
            return c
    return cols[0] if cols else None


def _qualify(table: str, ctx: SchemaContext) -> str:
    """Return schema-qualified table name if a default schema is set."""
    if ctx.default_schema and '.' not in table:
        return f"{ctx.default_schema}.{table}"
    return table


# ── Pattern matchers ──────────────────────────────────────────────────────────

def _match_count(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """count X / how many X / number of X"""
    m = re.search(r'(?:count|how many|number of)\s+([\w\s]+?)(?:\s+(?:where|in|with|that|$))', nl, re.I)
    if not m:
        m = re.search(r'(?:count|how many|number of)\s+([\w]+)', nl, re.I)
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT COUNT(*) AS total_count\nFROM {tq}",
            pattern_matched="count rows",
            confidence=0.85,
            explanation=f"Counts all rows in {table}.",
        )
    return None


def _match_top_n(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """top N X by Y [desc/asc]"""
    m = re.search(
        r'top\s+(\d+)\s+([\w\s]+?)\s+by\s+([\w_]+)(?:\s+(desc|asc))?',
        nl, re.I
    )
    if m:
        n = int(m.group(1))
        table = _best_table_match(m.group(2).strip(), ctx)
        order_col = _best_column_match(m.group(3).strip(), table, ctx)
        direction = (m.group(4) or 'desc').upper()
        tq = _qualify(table, ctx)
        cols = ctx.columns.get(table, [])
        select_cols = ', '.join(cols[:8]) if cols else '*'
        return NLToSQLResult(
            sql=(f"SELECT {select_cols}\nFROM {tq}\n"
                 f"ORDER BY {order_col} {direction}\nLIMIT {n}"),
            pattern_matched="top N by column",
            confidence=0.90,
            explanation=f"Returns top {n} rows from {table} ordered by {order_col} {direction}.",
        )
    return None


def _match_avg_per(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """average/avg Y per/by/for each X"""
    m = re.search(
        r'(?:average|avg|mean)\s+([\w_]+)\s+(?:per|by|for each|grouped by)\s+([\w_]+)\s+(?:in|from)?\s*([\w_]*)',
        nl, re.I
    )
    if m:
        metric = m.group(1).strip()
        group = m.group(2).strip()
        table_hint = m.group(3).strip()
        table = _best_table_match(table_hint or group, ctx)
        metric_col = _best_column_match(metric, table, ctx)
        group_col = _best_column_match(group, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group_col},\n"
                 f"       AVG({metric_col}) AS avg_{metric_col}\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group_col}\n"
                 f"ORDER BY avg_{metric_col} DESC"),
            pattern_matched="average per group",
            confidence=0.82,
            explanation=f"Average of {metric_col} grouped by {group_col} in {table}.",
        )
    return None


def _match_sum_per(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """sum/total Y per/by X"""
    m = re.search(
        r'(?:sum|total|summ?ari[sz]e)\s+(?:of\s+)?([\w_]+)\s+(?:per|by|for each|grouped by)\s+([\w_]+)\s+(?:in|from)?\s*([\w_]*)',
        nl, re.I
    )
    if m:
        metric = m.group(1).strip()
        group = m.group(2).strip()
        table_hint = m.group(3).strip()
        table = _best_table_match(table_hint or group, ctx)
        metric_col = _best_column_match(metric, table, ctx)
        group_col = _best_column_match(group, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group_col},\n"
                 f"       SUM({metric_col}) AS total_{metric_col}\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group_col}\n"
                 f"ORDER BY total_{metric_col} DESC"),
            pattern_matched="sum per group",
            confidence=0.82,
            explanation=f"Sum of {metric_col} grouped by {group_col} in {table}.",
        )
    return None


def _match_show_all(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """show/list/get all X  /  show me X"""
    m = re.search(r'(?:show|list|get|fetch|display|give me|show me)\s+(?:all|me|the)?\s*([\w\s]+)', nl, re.I)
    if m:
        table = _best_table_match(m.group(1).strip().split()[0], ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT *\nFROM {tq}\nLIMIT 100",
            pattern_matched="show all rows",
            confidence=0.70,
            explanation=f"Returns up to 100 rows from {table}.",
            warnings=["SELECT * used — consider specifying columns for better performance."],
        )
    return None


def _match_where_equals(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X where Y is/= Z  /  X with Y = Z"""
    m = re.search(
        r'([\w_]+)\s+(?:where|with|having)\s+([\w_]+)\s+(?:is|=|equals?|==)\s+["\']?([\w\s\-]+?)["\']?(?:\s|$)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        col = _best_column_match(m.group(2).strip(), table, ctx)
        val = m.group(3).strip()
        tq = _qualify(table, ctx)
        # Quote value unless it looks numeric
        quoted_val = val if re.match(r'^\d+(\.\d+)?$', val) else f"'{val}'"
        return NLToSQLResult(
            sql=f"SELECT *\nFROM {tq}\nWHERE {col} = {quoted_val}\nLIMIT 100",
            pattern_matched="filter equals",
            confidence=0.80,
            explanation=f"Rows from {table} where {col} equals {val}.",
        )
    return None


def _match_distinct(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """distinct values of Y in X  /  unique Y from X"""
    m = re.search(
        r'(?:distinct|unique)\s+(?:values?\s+of\s+)?([\w_]+)\s+(?:in|from)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        col = m.group(1).strip()
        table = _best_table_match(m.group(2).strip(), ctx)
        col = _best_column_match(col, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=f"SELECT DISTINCT {col}\nFROM {tq}\nORDER BY {col}",
            pattern_matched="distinct values",
            confidence=0.88,
            explanation=f"Unique values of {col} from {table}.",
        )
    return None


def _match_min_max(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """min/max/minimum/maximum Y in X"""
    m = re.search(
        r'(?:min(?:imum)?|max(?:imum)?)\s+(?:and\s+(?:max(?:imum)?|min(?:imum)?)\s+)?(?:of\s+)?([\w_]+)\s+(?:in|from)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        col = m.group(1).strip()
        table = _best_table_match(m.group(2).strip(), ctx)
        col = _best_column_match(col, table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT MIN({col}) AS min_{col},\n"
                 f"       MAX({col}) AS max_{col},\n"
                 f"       AVG({col}) AS avg_{col}\n"
                 f"FROM {tq}"),
            pattern_matched="min/max",
            confidence=0.85,
            explanation=f"Minimum, maximum, and average of {col} in {table}.",
        )
    return None


def _match_group_count(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X grouped by Y  /  count X by Y  /  breakdown of X by Y"""
    m = re.search(
        r'(?:count\s+)?([\w_]+)\s+(?:grouped by|by|breakdown by|breakdown of\s+[\w_]+\s+by)\s+([\w_]+)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        group = _best_column_match(m.group(2).strip(), table, ctx)
        tq = _qualify(table, ctx)
        return NLToSQLResult(
            sql=(f"SELECT {group},\n"
                 f"       COUNT(*) AS row_count\n"
                 f"FROM {tq}\n"
                 f"GROUP BY {group}\n"
                 f"ORDER BY row_count DESC"),
            pattern_matched="group by count",
            confidence=0.83,
            explanation=f"Row count per {group} in {table}.",
        )
    return None


def _match_between_dates(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """X between DATE1 and DATE2"""
    m = re.search(
        r'([\w_]+)\s+between\s+([\d\-/]+)\s+and\s+([\d\-/]+)',
        nl, re.I
    )
    if m:
        table = _best_table_match(m.group(1).strip(), ctx)
        date1 = m.group(2).replace('/', '-')
        date2 = m.group(3).replace('/', '-')
        tq = _qualify(table, ctx)
        date_col = (_date_cols(table, ctx) or ['date'])[0]
        return NLToSQLResult(
            sql=(f"SELECT *\nFROM {tq}\n"
                 f"WHERE {date_col} BETWEEN '{date1}' AND '{date2}'\n"
                 f"ORDER BY {date_col}\nLIMIT 1000"),
            pattern_matched="date range filter",
            confidence=0.80,
            explanation=f"Rows from {table} where {date_col} is between {date1} and {date2}.",
            warnings=[f"Assumed date column is '{date_col}'. Adjust if needed."],
        )
    return None


def _match_recent(nl: str, ctx: SchemaContext) -> Optional[NLToSQLResult]:
    """latest/recent/last N days X"""
    m = re.search(r'(?:latest|recent|last)\s+(\d+)\s+(?:days?|months?|weeks?)\s+(?:of\s+)?([\w_]+)', nl, re.I)
    unit_m = re.search(r'last\s+(\d+)\s+(days?|months?|weeks?)', nl, re.I)
    table_m = re.search(r'(?:for|of|from|in)\s+([\w_]+)', nl, re.I) or re.search(r'([\w_]+)\s+(?:in|from)\s+(?:last|past)', nl, re.I)
    if m:
        n = int(m.group(1))
        table = _best_table_match(m.group(2).strip(), ctx)
        unit = 'DAY'
        tq = _qualify(table, ctx)
        date_col = (_date_cols(table, ctx) or ['created_at'])[0]
        return NLToSQLResult(
            sql=(f"SELECT *\nFROM {tq}\n"
                 f"WHERE {date_col} >= CURRENT_DATE - INTERVAL '{n}' {unit}\n"
                 f"ORDER BY {date_col} DESC\nLIMIT 500"),
            pattern_matched="recent rows",
            confidence=0.78,
            explanation=f"Rows from {table} in the last {n} days.",
            warnings=[f"Assumed date column is '{date_col}'. Adjust if needed."],
        )
    return None


# ── Ordered pattern pipeline ──────────────────────────────────────────────────

_PATTERNS = [
    _match_top_n,
    _match_avg_per,
    _match_sum_per,
    _match_distinct,
    _match_min_max,
    _match_between_dates,
    _match_recent,
    _match_where_equals,
    _match_count,
    _match_group_count,
    _match_show_all,
]


# ── Public API ────────────────────────────────────────────────────────────────

def nl_to_sql(
    natural_language: str,
    schema_context: Optional[SchemaContext] = None,
) -> NLToSQLResult:
    """
    Convert a natural language question to SQL using pattern matching.

    Args:
        natural_language: Plain-English query description.
        schema_context: Available tables/columns for schema-aware generation.

    Returns:
        NLToSQLResult with generated SQL, or a fallback SELECT template.
    """
    nl = natural_language.strip()
    ctx = schema_context or SchemaContext()

    for pattern_fn in _PATTERNS:
        try:
            result = pattern_fn(nl, ctx)
            if result:
                return result
        except Exception as e:
            logger.debug("NL-to-SQL pattern %s failed: %s", pattern_fn.__name__, e)

    # Fallback — generic template using first available table
    table = ctx.tables[0] if ctx.tables else "your_table"
    tq = _qualify(table, ctx)
    return NLToSQLResult(
        sql=f"SELECT *\nFROM {tq}\nLIMIT 100",
        pattern_matched="fallback template",
        confidence=0.20,
        explanation="No specific pattern matched. Generated a basic SELECT template.",
        warnings=[
            "Could not parse the query. Try phrases like: "
            "'top 10 orders by revenue', 'count customers', "
            "'average salary by department'."
        ],
        alternatives=[
            f"SELECT COUNT(*) FROM {tq}",
            f"SELECT * FROM {tq} WHERE <condition> LIMIT 100",
        ],
    )


def result_to_dict(r: NLToSQLResult) -> Dict[str, Any]:
    return {
        "sql": r.sql,
        "pattern_matched": r.pattern_matched,
        "confidence": r.confidence,
        "explanation": r.explanation,
        "warnings": r.warnings,
        "alternatives": r.alternatives,
    }
