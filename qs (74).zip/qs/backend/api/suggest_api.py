"""
Suggest / Intelligence API (Phases 46, 47, 48)

Endpoints:
  GET  /api/suggest/tables          — ranked table suggestions (Phase 46)
  GET  /api/suggest/columns         — ranked column suggestions (Phase 46)
  GET  /api/suggest/top-tables      — most-used tables (Phase 46)
  GET  /api/suggest/schema          — column schema for a table (cache + usage stats)
  GET  /api/suggest/last-result     — schema + stats of last completed execution
  GET  /api/suggest/docs            — keyword search over user_guide + architecture HTML
  POST /api/analyze-query           — pre-execution rule analysis (Phase 47)
  POST /api/nl-to-sql               — pattern-based NL→SQL generation (Phase 48)
"""
from __future__ import annotations

import logging
import re as _re
from pathlib import Path as _Path
from html.parser import HTMLParser as _HTMLParser
from typing import List, Optional, Any, Dict, Tuple

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from api.deps import get_current_user, require_role

logger = logging.getLogger(__name__)
router = APIRouter()

# Injected from main.py _startup()
_db_manager = None


def set_suggest_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


# ── Phase 46 — Table / Column Suggestions ─────────────────────────────────────

@router.get("/api/suggest/tables")
async def suggest_tables(
    prefix: str = "",
    connection_id: Optional[int] = None,
    limit: int = 20,
    _user: dict = Depends(get_current_user),
):
    """Return tables ranked by historical usage frequency."""
    return _db_manager.get_table_suggestions(
        prefix=prefix, connection_id=connection_id, limit=min(limit, 50)
    )


@router.get("/api/suggest/columns")
async def suggest_columns(
    table_name: str = "",
    connection_id: Optional[int] = None,
    limit: int = 30,
    _user: dict = Depends(get_current_user),
):
    """Return columns for a table ranked by usage frequency."""
    return _db_manager.get_column_suggestions(
        table_name=table_name, connection_id=connection_id, limit=min(limit, 100)
    )


@router.get("/api/suggest/top-tables")
async def top_tables(
    connection_id: Optional[int] = None,
    limit: int = 50,
    _user: dict = Depends(get_current_user),
):
    """Return most-used tables overall."""
    return _db_manager.get_top_tables(connection_id=connection_id, limit=min(limit, 100))


# ── Phase 47 — Query Analysis ─────────────────────────────────────────────────

class AnalyzeQueryRequest(BaseModel):
    sql: str
    connection_type: str = "duckdb"
    partition_columns: List[str] = []


@router.post("/api/analyze-query")
async def analyze_query(body: AnalyzeQueryRequest, _user: dict = Depends(get_current_user)):
    """Analyze SQL for common anti-patterns and return warnings."""
    from core.query_analyzer import analyze_query as _analyze, warnings_to_dicts
    warnings = _analyze(
        sql=body.sql,
        connection_type=body.connection_type,
        partition_columns=body.partition_columns,
    )
    return {
        "warnings": warnings_to_dicts(warnings),
        "warning_count": len(warnings),
        "has_errors": any(w.severity == "error" for w in warnings),
    }


# ── Phase 48 — Natural Language to SQL ───────────────────────────────────────

class NLToSQLRequest(BaseModel):
    question: str
    connection_id: Optional[int] = None
    tables: List[str] = []                       # available table names
    columns: Dict[str, List[str]] = {}           # table → [col, ...]
    connection_type: str = "duckdb"
    default_schema: Optional[str] = None


@router.post("/api/nl-to-sql")
async def nl_to_sql(body: NLToSQLRequest, _user: dict = Depends(get_current_user)):
    """Convert a natural language question to SQL using pattern matching."""
    from core.nl_to_sql import nl_to_sql as _convert, SchemaContext, result_to_dict

    ctx = SchemaContext(
        tables=body.tables,
        columns=body.columns,
        connection_type=body.connection_type,
        default_schema=body.default_schema,
    )

    result = _convert(body.question, ctx)
    return result_to_dict(result)


@router.get("/api/suggest/schema")
async def suggest_schema(
    q: str = "",
    connection_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """
    Return column schema for a table name.
    Resolution order:
      1. Exact match in DB schema cache (fast, populated after schema browser opens)
      2. Column usage stats (populated after queries run against the table)
      3. Fuzzy/prefix table match → repeat steps 1–2 for best match
    """
    if not q:
        return {"table": "", "columns": [], "message": "Provide ?q=table_name"}

    # 1 — exact schema cache hit
    if connection_id:
        cached = _db_manager.get_schema_cache(connection_id, q)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            return {"table": q, "connection_id": connection_id, "source": "schema_cache", "columns": cols}

    # 2 — column usage stats (exact table name)
    col_stats = _db_manager.get_column_suggestions(table_name=q, connection_id=connection_id, limit=60)
    if col_stats:
        return {
            "table": q,
            "connection_id": col_stats[0].get("connection_id"),
            "source": "usage_stats",
            "columns": [
                {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
                for c in col_stats
            ],
        }

    # 3 — fuzzy prefix match
    matches = _db_manager.get_table_suggestions(prefix=q, connection_id=connection_id, limit=3)
    if not matches:
        return {
            "table": q, "columns": [],
            "message": f"No schema found for '{q}'. Open the schema browser for this table first, or run a query that references it.",
        }

    best = matches[0]
    best_name = best.get("object_name", q)
    best_conn  = best.get("connection_id")

    if best_conn:
        cached = _db_manager.get_schema_cache(best_conn, best_name)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
            return {"table": best_name, "connection_id": best_conn, "source": "schema_cache",
                    "columns": cols, "message": hint}

    col_stats = _db_manager.get_column_suggestions(table_name=best_name, connection_id=best_conn, limit=60)
    hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
    return {
        "table": best_name,
        "connection_id": best_conn,
        "source": "usage_stats",
        "message": hint,
        "columns": [
            {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
            for c in col_stats
        ],
    }


@router.get("/api/suggest/last-result")
async def last_result_info(_user: dict = Depends(get_current_user)):
    """
    Return schema and row count for the most recent completed execution.
    Reads the stored parquet output via DuckDB — no LLM required.
    """
    import duckdb as _duckdb
    import os as _os

    try:
        with _db_manager.get_session() as session:
            from core.database import QueryExecution as _QE
            row = (
                session.query(_QE)
                .filter(_QE.status == "completed", _QE.output_file.isnot(None))
                .order_by(_QE.started_at.desc())
                .first()
            )
            if not row:
                return {"found": False, "message": "No completed executions with result files found."}
            output_file = row.output_file
            execution_id = row.execution_id
            total_rows   = row.total_rows or 0
            started_at   = row.started_at.isoformat() if row.started_at else None
            sql_preview  = (row.sql or "")[:300]

        if not _os.path.exists(output_file):
            return {"found": False, "message": "Result file has been deleted from disk."}

        con = _duckdb.connect(":memory:")
        try:
            desc_rows = con.execute(
                f"DESCRIBE SELECT * FROM read_parquet('{output_file}') LIMIT 0"
            ).fetchall()
            columns = [{"name": r[0], "type": r[1]} for r in desc_rows]
        finally:
            con.close()

        return {
            "found": True,
            "execution_id": execution_id,
            "columns": columns,
            "total_rows": total_rows,
            "executed_at": started_at,
            "sql_preview": sql_preview,
        }
    except Exception as exc:
        logger.warning("last-result: %s", exc)
        return {"found": False, "message": str(exc)}


# ── Docs knowledge base ───────────────────────────────────────────────────────

# Module-level cache: list of {"heading", "text", "source", "keywords": set}
_docs_sections: Optional[List[Dict[str, Any]]] = None
_DOCS_STOPWORDS = {
    "the","a","an","is","are","was","were","be","been","being","have","has","had",
    "do","does","did","will","would","could","should","may","might","must","can",
    "to","of","in","on","at","by","for","with","from","and","or","not","this",
    "that","it","its","as","i","you","we","they","what","how","when","where",
    "which","who","all","any","if","so","but","more","also","use","using","used",
}

class _SectionParser(_HTMLParser):
    """Extract heading+body sections from HTML."""
    def __init__(self):
        super().__init__()
        self.sections: List[Dict[str, str]] = []
        self._heading = ""
        self._body: List[str] = []
        self._in_head = False
        self._in_script = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._in_script = True
        elif tag in ("h1", "h2", "h3", "h4"):
            self._flush()
            self._in_head = True

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._in_script = False
        elif tag in ("h1", "h2", "h3", "h4"):
            self._in_head = False

    def handle_data(self, data):
        if self._in_script:
            return
        data = data.strip()
        if not data:
            return
        if self._in_head:
            self._heading = data
        else:
            self._body.append(data)

    def _flush(self):
        text = " ".join(self._body).strip()
        # Remove CSS noise (lines with lots of { : ; })
        text = _re.sub(r'[^\s]+\s*:\s*[^;]+;', '', text)
        text = _re.sub(r'\s+', ' ', text).strip()
        if self._heading and len(text) > 20:
            self.sections.append({"heading": self._heading, "text": text[:800]})
        self._body = []


def _tokenize(text: str) -> set:
    """Extract lowercase tokens (3+ chars) including uppercase sigils like S3, SQL, CSV."""
    lc = text.lower()
    tokens = set(_re.findall(r'\b[a-z][a-z0-9]{2,}\b', lc))          # normal words
    # Also capture short uppercase acronyms from original: S3, SQL, CSV, API, LLM …
    tokens |= set(w.lower() for w in _re.findall(r'\b[A-Z][A-Z0-9]{1,4}\b', text))
    tokens -= _DOCS_STOPWORDS
    return tokens


def _load_docs() -> List[Dict[str, Any]]:
    global _docs_sections
    if _docs_sections is not None:
        return _docs_sections

    docs_root = _Path(__file__).parent.parent.parent  # c:/DEV/outputs
    files = [
        (docs_root / "user_guide.html",    "User Guide"),
        (docs_root / "ARCHITECTURE.html",  "Architecture"),
    ]
    sections: List[Dict[str, Any]] = []
    for path, source in files:
        if not path.exists():
            continue
        try:
            html = path.read_text(encoding="utf-8", errors="replace")
            parser = _SectionParser()
            parser.feed(html)
            for s in parser.sections:
                full_text = s["heading"] + " " + s["text"]
                kw = _tokenize(full_text)
                sections.append({
                    "heading": s["heading"],
                    "text": s["text"],
                    "source": source,
                    "keywords": kw,
                    "heading_tokens": _tokenize(s["heading"]),
                })
        except Exception as exc:
            logger.warning("docs: failed to load %s — %s", path, exc)

    _docs_sections = sections
    logger.info("Docs knowledge base loaded: %d sections", len(sections))
    return _docs_sections


def _search_docs(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """
    Score sections by token overlap, with boosts for:
      • heading match  (×4)
      • substring / prefix match in body text (×1.5)
    Returns top_k sections with score >= 1.
    """
    sections = _load_docs()
    q_tokens = _tokenize(query)
    if not q_tokens:
        return []

    query_lc = query.lower()

    scored = []
    for s in sections:
        heading_overlap = len(q_tokens & s["heading_tokens"])
        body_overlap    = len(q_tokens & s["keywords"])

        # Substring bonus: any query token appears as substring in full text
        full_lc = (s["heading"] + " " + s["text"]).lower()
        substr_bonus = sum(
            1 for t in q_tokens
            if len(t) >= 4 and t in full_lc and t not in s["keywords"]
        ) * 1.5

        score = heading_overlap * 4 + body_overlap + substr_bonus
        if score >= 1:
            scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    for score, s in scored[:top_k]:
        results.append({
            "heading": s["heading"],
            "excerpt": s["text"][:400] + ("…" if len(s["text"]) > 400 else ""),
            "source": s["source"],
            "score": round(score, 1),
        })
    return results


@router.get("/api/suggest/docs")
async def suggest_docs(
    q: str = "",
    _user: dict = Depends(get_current_user),
):
    """
    Keyword search over the QueryStudio user guide and architecture docs.
    Returns the top matching sections (heading + excerpt) — no LLM needed.
    """
    if not q or len(q.strip()) < 3:
        return {"results": [], "message": "Provide ?q=your+question"}

    results = _search_docs(q.strip(), top_k=3)
    return {
        "query": q,
        "results": results,
        "found": len(results) > 0,
    }


# ── Phase: Grid Data Query ────────────────────────────────────────────────────

_MAX_RE     = _re.compile(r'\bmax(?:imum)?\s+(?:of\s+)?(\w+)', _re.I)
_MIN_RE     = _re.compile(r'\bmin(?:imum)?\s+(?:of\s+)?(\w+)', _re.I)
_AVG_RE     = _re.compile(r'\b(?:avg|average|mean)\s+(?:of\s+)?(\w+)', _re.I)
_SUM_RE     = _re.compile(r'\bsum\s+(?:of\s+)?(\w+)', _re.I)
_TOPN_RE    = _re.compile(r'\btop\s+(\d+)\s+(?:rows?\s+)?(?:by\s+)?(\w+)', _re.I)
_DIST_RE    = _re.compile(r'\bdistinct(?:\s+values?)?\s+(?:of\s+)?(\w+)', _re.I)
_COUNTW_RE  = _re.compile(r'\bcount\s+where\s+(\w+)\s*(?:=|is|equals?)\s+["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_GROUPBY_RE = _re.compile(r'\b(?:count|group)\s+by\s+(\w+)', _re.I)
_FILTER_RE  = _re.compile(r'\b(?:show|where|filter|rows?\s+where)\s+(\w+)\s*(?:=|is|equals?)\s+["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_FIRSTN_RE  = _re.compile(r'\b(?:first|top)\s+(\d+)\b', _re.I)


class DataQueryRequest(BaseModel):
    question: str
    execution_id: str
    columns: List[str] = []


@router.post("/api/suggest/data-query")
async def data_query(body: DataQueryRequest, _user: dict = Depends(get_current_user)):
    """Run a natural-language aggregate query against a completed execution's parquet result."""
    import duckdb as _duckdb
    import os as _os

    try:
        with _db_manager.get_session() as session:
            from core.database import QueryExecution as _QE
            row = (
                session.query(_QE)
                .filter(_QE.execution_id == body.execution_id,
                        _QE.status == "completed",
                        _QE.output_file.isnot(None))
                .first()
            )
            if not row:
                return {"found": False, "message": "Execution not found or has no output file."}
            output_file = row.output_file
    except Exception as exc:
        return {"found": False, "message": str(exc)}

    if not _os.path.exists(output_file):
        return {"found": False, "message": "Result file has been deleted from disk."}

    q   = body.question.strip()
    ql  = q.lower()
    sp  = output_file.replace("'", "''")   # safe path for DuckDB string literal

    sql = None
    answer_prefix = ""

    if m := _MAX_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT MAX(\"{col}\") AS max_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Maximum of {col}"
    elif m := _MIN_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT MIN(\"{col}\") AS min_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Minimum of {col}"
    elif m := _AVG_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT ROUND(TRY_CAST(AVG(TRY_CAST(\"{col}\" AS DOUBLE)) AS DOUBLE), 4) AS avg_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Average of {col}"
    elif m := _SUM_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT SUM(\"{col}\") AS sum_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Sum of {col}"
    elif m := _TOPN_RE.search(ql):
        n, col = int(m.group(1)), m.group(2)
        n = min(n, 100)
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY \"{col}\" DESC NULLS LAST LIMIT {n}"
        answer_prefix = f"Top {n} by {col}"
    elif m := _DIST_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT DISTINCT \"{col}\" FROM read_parquet('{sp}') ORDER BY 1 LIMIT 100"
        answer_prefix = f"Distinct values of {col}"
    elif m := _COUNTW_RE.search(ql):
        col, val = m.group(1), m.group(2).strip()
        sql = f"SELECT COUNT(*) AS count FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}')"
        answer_prefix = f"Count where {col} = {val}"
    elif m := _GROUPBY_RE.search(ql):
        col = m.group(1)
        sql = f"SELECT \"{col}\", COUNT(*) AS count FROM read_parquet('{sp}') GROUP BY \"{col}\" ORDER BY count DESC LIMIT 50"
        answer_prefix = f"Count by {col}"
    elif m := _FILTER_RE.search(ql):
        col, val = m.group(1), m.group(2).strip()
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}') LIMIT 50"
        answer_prefix = f"Rows where {col} = {val}"
    elif _re.search(r'\bcount\b', ql):
        sql = f"SELECT COUNT(*) AS total_rows FROM read_parquet('{sp}')"
        answer_prefix = "Total row count"
    else:
        limit = 10
        if m2 := _FIRSTN_RE.search(ql):
            limit = min(int(m2.group(1)), 100)
        sql = f"SELECT * FROM read_parquet('{sp}') LIMIT {limit}"
        answer_prefix = f"Sample of {limit} rows"

    try:
        con = _duckdb.connect(":memory:")
        try:
            df = con.execute(sql).fetchdf()
            columns = list(df.columns)
            rows = df.to_dict(orient="records")
        finally:
            con.close()
        return {
            "found": True,
            "answer": answer_prefix,
            "sql": sql,
            "columns": columns,
            "rows": rows[:100],
            "row_count": len(rows),
        }
    except Exception as exc:
        logger.warning("data-query failed: %s | sql=%s", exc, sql)
        return {"found": False, "message": f"Query failed: {exc}", "sql": sql}


# ── NL Feedback (Learning Loop) ───────────────────────────────────────────────

class NLFeedbackRequest(BaseModel):
    question: str
    sql: str
    connection_type: str = "duckdb"
    tables_hint: Optional[str] = None
    rating: int = 1   # 1 = thumbs-up, -1 = thumbs-down


@router.post("/api/suggest/feedback")
async def save_nl_feedback(body: NLFeedbackRequest, _user: dict = Depends(get_current_user)):
    """Save user thumbs-up/down rating for a NL→SQL pair (learning loop)."""
    _db_manager.save_nl_feedback(
        question=body.question,
        sql=body.sql,
        connection_type=body.connection_type,
        tables_hint=body.tables_hint,
        rating=body.rating,
    )
    return {"saved": True, "rating": body.rating}


@router.get("/api/nl-to-sql/examples")
async def nl_to_sql_examples(_user: dict = Depends(get_current_user)):
    """Return example prompts that work well with the pattern-based engine."""
    return {
        "examples": [
            {"prompt": "top 10 customers by revenue",        "pattern": "top N by column"},
            {"prompt": "count orders",                        "pattern": "count rows"},
            {"prompt": "average salary by department",        "pattern": "average per group"},
            {"prompt": "total revenue by region",             "pattern": "sum per group"},
            {"prompt": "show all products",                   "pattern": "show all rows"},
            {"prompt": "orders where status is pending",      "pattern": "filter equals"},
            {"prompt": "distinct values of category in products", "pattern": "distinct values"},
            {"prompt": "min and max price in products",       "pattern": "min/max"},
            {"prompt": "orders grouped by status",            "pattern": "group by count"},
            {"prompt": "sales between 2026-01-01 and 2026-03-31", "pattern": "date range"},
            {"prompt": "recent 7 days of events",             "pattern": "recent rows"},
        ]
    }
