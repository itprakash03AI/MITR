"""
Data Lineage API (Phase 26 + Phase 49 table-level + Phase 51 column-level)

Endpoints:
  GET /api/lineage/connection/{id}
  GET /api/lineage/report/{id}
  GET /api/lineage/query/{id}
  GET /api/lineage/graph
  --- Phase 49 ---
  GET /api/lineage/table/{catalog}/{schema}/{table}
  GET /api/lineage/table/search
  GET /api/lineage/query/{id}/tables
  POST /api/lineage/reparse
  --- Phase 51 ---
  GET /api/lineage/query/{id}/columns    column lineage for a SQL query
  GET /api/lineage/column/impact         all queries consuming a specific column
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query as FastQuery

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None


def set_lineage_dependencies(db_manager):
    global _db_manager
    _db_manager = db_manager


def _require_db():
    if _db_manager is None:
        raise RuntimeError("Lineage API not initialised")
    return _db_manager


# ── Internal graph builders ──────────────────────────────────────────────────

def _build_connection_downstream(db, conn_id: int) -> Dict[str, Any]:
    """All entities downstream of a connection."""
    with db.get_session() as session:
        from core.database import (
            Connection, SqlSavedQuery, Report, MaterializedView,
            DashboardWidget, Dashboard, Schedule,
        )
        conn = session.query(Connection).filter(Connection.id == conn_id).first()
        if not conn:
            return {}

        downstream = []

        # MaterializedViews directly on this connection
        mvs = session.query(MaterializedView).filter(
            MaterializedView.connection_id == conn_id,
            MaterializedView.is_active == True,
        ).all()
        for mv in mvs:
            downstream.append({"type": "materialized_view", "id": mv.id, "name": mv.name, "downstream": []})

        # SqlSavedQueries on this connection (primary or secondary)
        from sqlalchemy import or_
        sqls = session.query(SqlSavedQuery).filter(
            or_(
                SqlSavedQuery.primary_connection_id == conn_id,
                SqlSavedQuery.secondary_connection_id == conn_id,
            ),
            SqlSavedQuery.is_active == True,
        ).all()
        for sq in sqls:
            sql_node = {"type": "sql_query", "id": sq.id, "name": sq.name, "downstream": []}
            sql_node["downstream"] = _sql_query_downstream(session, sq.id)
            downstream.append(sql_node)

        # Reports with direct connection_override_id pointing here
        override_reports = session.query(Report).filter(
            Report.connection_override_id == conn_id,
            Report.is_active == True,
        ).all()
        for r in override_reports:
            r_node = {"type": "report", "id": r.id, "name": r.name, "downstream": []}
            r_node["downstream"] = _report_downstream(session, r.id)
            downstream.append(r_node)

        return {
            "node": {"type": "connection", "id": conn.id, "name": conn.name},
            "upstream": [],
            "downstream": downstream,
        }


def _sql_query_downstream(session, sq_id: int) -> List[Dict[str, Any]]:
    from core.database import Report, DashboardWidget, Dashboard, Schedule
    result = []

    reports = session.query(Report).filter(
        Report.sql_saved_query_id == sq_id,
        Report.is_active == True,
    ).all()
    for r in reports:
        r_node = {"type": "report", "id": r.id, "name": r.name, "downstream": []}
        r_node["downstream"] = _report_downstream(session, r.id)
        result.append(r_node)

    widgets = session.query(DashboardWidget).filter(
        DashboardWidget.widget_type == "sql_query",
        DashboardWidget.source_id == sq_id,
    ).all()
    dash_ids = {w.dashboard_id for w in widgets}
    for did in dash_ids:
        dash = session.query(Dashboard).filter(Dashboard.id == did, Dashboard.is_active == True).first()
        if dash:
            result.append({"type": "dashboard", "id": dash.id, "name": dash.name, "downstream": []})

    scheds = session.query(Schedule).filter(
        Schedule.source_type == "sql_query",
        Schedule.source_id == sq_id,
        Schedule.is_active == True,
    ).all()
    for s in scheds:
        result.append({"type": "schedule", "id": s.id, "name": s.name, "downstream": []})

    return result


def _parquet_query_downstream(session, pq_id: int) -> List[Dict[str, Any]]:
    from core.database import Report, DashboardWidget, Dashboard, Schedule
    result = []

    reports = session.query(Report).filter(
        Report.saved_query_id == pq_id,
        Report.is_active == True,
    ).all()
    for r in reports:
        r_node = {"type": "report", "id": r.id, "name": r.name, "downstream": []}
        r_node["downstream"] = _report_downstream(session, r.id)
        result.append(r_node)

    widgets = session.query(DashboardWidget).filter(
        DashboardWidget.widget_type == "saved_query",
        DashboardWidget.source_id == pq_id,
    ).all()
    dash_ids = {w.dashboard_id for w in widgets}
    for did in dash_ids:
        dash = session.query(Dashboard).filter(Dashboard.id == did, Dashboard.is_active == True).first()
        if dash:
            result.append({"type": "dashboard", "id": dash.id, "name": dash.name, "downstream": []})

    scheds = session.query(Schedule).filter(
        Schedule.source_type == "saved_query",
        Schedule.source_id == pq_id,
        Schedule.is_active == True,
    ).all()
    for s in scheds:
        result.append({"type": "schedule", "id": s.id, "name": s.name, "downstream": []})

    return result


def _report_downstream(session, report_id: int) -> List[Dict[str, Any]]:
    from core.database import DashboardWidget, Dashboard, Schedule
    result = []

    widgets = session.query(DashboardWidget).filter(
        DashboardWidget.widget_type == "report",
        DashboardWidget.source_id == report_id,
    ).all()
    dash_ids = {w.dashboard_id for w in widgets}
    for did in dash_ids:
        dash = session.query(Dashboard).filter(Dashboard.id == did, Dashboard.is_active == True).first()
        if dash:
            result.append({"type": "dashboard", "id": dash.id, "name": dash.name, "downstream": []})

    scheds = session.query(Schedule).filter(
        Schedule.source_type == "report",
        Schedule.source_id == report_id,
        Schedule.is_active == True,
    ).all()
    for s in scheds:
        result.append({"type": "schedule", "id": s.id, "name": s.name, "downstream": []})

    return result


def _report_upstream(session, report: Any) -> List[Dict[str, Any]]:
    from core.database import SqlSavedQuery, SavedQuery, Connection
    upstream = []

    if report.sql_saved_query_id:
        sq = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == report.sql_saved_query_id).first()
        if sq:
            sq_node = {"type": "sql_query", "id": sq.id, "name": sq.name, "upstream": []}
            conn = session.query(Connection).filter(Connection.id == sq.primary_connection_id).first()
            if conn:
                sq_node["upstream"].append({"type": "connection", "id": conn.id, "name": conn.name, "upstream": []})
            upstream.append(sq_node)

    if report.saved_query_id:
        pq = session.query(SavedQuery).filter(SavedQuery.id == report.saved_query_id).first()
        if pq:
            upstream.append({"type": "parquet_query", "id": pq.id, "name": pq.name, "upstream": []})

    if report.connection_override_id:
        conn = session.query(Connection).filter(Connection.id == report.connection_override_id).first()
        if conn:
            upstream.append({"type": "connection", "id": conn.id, "name": f"{conn.name} (override)", "upstream": []})

    return upstream


# ── Endpoints (Phase 26 — entity-level) ─────────────────────────────────────

@router.get("/api/lineage/connection/{connection_id}")
def get_connection_lineage(connection_id: int):
    db = _require_db()
    result = _build_connection_downstream(db, connection_id)
    if not result:
        raise HTTPException(status_code=404, detail="Connection not found")
    return result


@router.get("/api/lineage/report/{report_id}")
def get_report_lineage(report_id: int):
    db = _require_db()
    with db.get_session() as session:
        from core.database import Report
        r = session.query(Report).filter(Report.id == report_id).first()
        if not r:
            raise HTTPException(status_code=404, detail="Report not found")
        return {
            "node": {"type": "report", "id": r.id, "name": r.name},
            "upstream": _report_upstream(session, r),
            "downstream": _report_downstream(session, r.id),
        }


@router.get("/api/lineage/query/{query_id}")
def get_query_lineage(query_id: int, type: str = FastQuery(default="sql")):
    db = _require_db()
    with db.get_session() as session:
        if type == "sql":
            from core.database import SqlSavedQuery, Connection
            sq = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not sq:
                raise HTTPException(status_code=404, detail="SQL query not found")
            upstream = []
            conn = session.query(Connection).filter(Connection.id == sq.primary_connection_id).first()
            if conn:
                upstream.append({"type": "connection", "id": conn.id, "name": conn.name, "upstream": []})
            if sq.secondary_connection_id:
                sc = session.query(Connection).filter(Connection.id == sq.secondary_connection_id).first()
                if sc:
                    upstream.append({"type": "connection", "id": sc.id, "name": f"{sc.name} (secondary)", "upstream": []})
            return {
                "node": {"type": "sql_query", "id": sq.id, "name": sq.name},
                "upstream": upstream,
                "downstream": _sql_query_downstream(session, sq.id),
            }
        else:
            from core.database import SavedQuery
            pq = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not pq:
                raise HTTPException(status_code=404, detail="Parquet query not found")
            return {
                "node": {"type": "parquet_query", "id": pq.id, "name": pq.name},
                "upstream": [],
                "downstream": _parquet_query_downstream(session, pq.id),
            }


@router.get("/api/lineage/graph")
def get_full_lineage_graph():
    """Return entire dependency graph as { nodes[], edges[] } — includes table nodes (Phase 49)."""
    db = _require_db()
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    seen_nodes: set = set()

    def add_node(ntype: str, nid: Any, name: str):
        key = f"{ntype}:{nid}"
        if key not in seen_nodes:
            seen_nodes.add(key)
            nodes.append({"id": key, "type": ntype, "label": name})
        return key

    with db.get_session() as session:
        from core.database import (
            Connection, SqlSavedQuery, SavedQuery, Report,
            MaterializedView, DashboardWidget, Dashboard, Schedule,
            TableLineageEntry,
        )
        from sqlalchemy import or_

        # Connections
        for c in session.query(Connection).filter(Connection.is_active == True).all():
            add_node("connection", c.id, c.name)

        # MaterializedViews → Connection
        for mv in session.query(MaterializedView).filter(MaterializedView.is_active == True).all():
            mk = add_node("materialized_view", mv.id, mv.name)
            ck = f"connection:{mv.connection_id}"
            if ck in seen_nodes:
                edges.append({"source": ck, "target": mk})

        # SqlSavedQueries → Connection(s)
        for sq in session.query(SqlSavedQuery).filter(SqlSavedQuery.is_active == True).all():
            sk = add_node("sql_query", sq.id, sq.name)
            ck = f"connection:{sq.primary_connection_id}"
            if ck in seen_nodes:
                edges.append({"source": ck, "target": sk})
            if sq.secondary_connection_id:
                ck2 = f"connection:{sq.secondary_connection_id}"
                if ck2 in seen_nodes:
                    edges.append({"source": ck2, "target": sk})

        # SavedQueries (no connection)
        for pq in session.query(SavedQuery).filter(SavedQuery.is_active == True).all():
            add_node("parquet_query", pq.id, pq.name)

        # Reports → SqlSavedQuery or SavedQuery
        for r in session.query(Report).filter(Report.is_active == True).all():
            rk = add_node("report", r.id, r.name)
            if r.sql_saved_query_id:
                sk = f"sql_query:{r.sql_saved_query_id}"
                if sk in seen_nodes:
                    edges.append({"source": sk, "target": rk})
            if r.saved_query_id:
                pk = f"parquet_query:{r.saved_query_id}"
                if pk in seen_nodes:
                    edges.append({"source": pk, "target": rk})

        # Dashboards
        for d in session.query(Dashboard).filter(Dashboard.is_active == True).all():
            dk = add_node("dashboard", d.id, d.name)
            for w in session.query(DashboardWidget).filter(DashboardWidget.dashboard_id == d.id).all():
                src_key = f"{w.widget_type.replace('saved_query','parquet_query')}:{w.source_id}"
                if src_key in seen_nodes:
                    edges.append({"source": src_key, "target": dk})

        # Schedules
        for s in session.query(Schedule).filter(Schedule.is_active == True).all():
            sk2 = add_node("schedule", s.id, s.name)
            src_key2 = f"{s.source_type.replace('saved_query','parquet_query')}:{s.source_id}"
            if src_key2 in seen_nodes:
                edges.append({"source": src_key2, "target": sk2})

        # ── Phase 49: Table-level nodes ──────────────────────────────────────
        table_entries = session.query(TableLineageEntry).all()
        # Deduplicate tables by FQN
        table_fqns: Dict[str, Dict] = {}
        for te in table_entries:
            fqn = _make_table_fqn(te.table_catalog, te.table_schema, te.table_name)
            if fqn not in table_fqns:
                table_fqns[fqn] = {
                    "catalog": te.table_catalog, "schema": te.table_schema,
                    "name": te.table_name, "connection_id": te.connection_id,
                }

        for fqn, info in table_fqns.items():
            tk = add_node("table", fqn, fqn)
            # Edge: connection → table (if connection known)
            if info["connection_id"]:
                ck = f"connection:{info['connection_id']}"
                if ck in seen_nodes:
                    edges.append({"source": ck, "target": tk})

        # Edges: table → query (table is read by a query)
        for te in table_entries:
            fqn = _make_table_fqn(te.table_catalog, te.table_schema, te.table_name)
            tk = f"table:{fqn}"
            qk = f"{te.query_type}:{te.query_id}"
            if tk in seen_nodes and qk in seen_nodes:
                edges.append({"source": tk, "target": qk})

    return {"nodes": nodes, "edges": edges}


# ── Phase 49: Table-level lineage endpoints ──────────────────────────────────

def _make_table_fqn(catalog: Optional[str], schema: Optional[str], table: str) -> str:
    parts = [p for p in [catalog, schema, table] if p]
    return ".".join(parts)


@router.get("/api/lineage/table/{catalog}/{schema}/{table}")
def get_table_impact(catalog: str, schema: str, table: str):
    """Impact analysis: given a physical table, what queries/reports/dashboards depend on it."""
    db = _require_db()
    entries = db.get_queries_for_table(catalog, schema, table)
    if not entries:
        return {"table": f"{catalog}.{schema}.{table}", "queries": [], "downstream_reports": [], "downstream_dashboards": []}

    # Collect downstream for each referencing query
    query_list = []
    downstream_reports = []
    downstream_dashboards = []
    seen_reports = set()
    seen_dashboards = set()

    with db.get_session() as session:
        from core.database import (
            SqlSavedQuery, SavedQuery, Report, DashboardWidget, Dashboard, Schedule,
        )

        for entry in entries:
            qt = entry["query_type"]
            qid = entry["query_id"]
            query_list.append({"query_type": qt, "query_id": qid, "access_type": entry["access_type"]})

            # Find downstream reports + dashboards
            if qt == "sql_query":
                sq = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == qid).first()
                if sq:
                    query_list[-1]["name"] = sq.name
                reports = session.query(Report).filter(
                    Report.sql_saved_query_id == qid, Report.is_active == True
                ).all()
            elif qt == "parquet_query":
                pq = session.query(SavedQuery).filter(SavedQuery.id == qid).first()
                if pq:
                    query_list[-1]["name"] = pq.name
                reports = session.query(Report).filter(
                    Report.saved_query_id == qid, Report.is_active == True
                ).all()
            else:
                reports = []

            for r in reports:
                if r.id not in seen_reports:
                    seen_reports.add(r.id)
                    downstream_reports.append({"id": r.id, "name": r.name})
                # Dashboards using this report
                widgets = session.query(DashboardWidget).filter(
                    DashboardWidget.widget_type == "report",
                    DashboardWidget.source_id == r.id,
                ).all()
                for w in widgets:
                    dash = session.query(Dashboard).filter(
                        Dashboard.id == w.dashboard_id, Dashboard.is_active == True
                    ).first()
                    if dash and dash.id not in seen_dashboards:
                        seen_dashboards.add(dash.id)
                        downstream_dashboards.append({"id": dash.id, "name": dash.name})

    return {
        "table": f"{catalog}.{schema}.{table}",
        "queries": query_list,
        "downstream_reports": downstream_reports,
        "downstream_dashboards": downstream_dashboards,
    }


@router.get("/api/lineage/table/search")
def search_table_lineage(q: str = FastQuery(default=""), limit: int = FastQuery(default=50)):
    """Search for tables by name/schema/catalog."""
    db = _require_db()
    if not q:
        return []
    return db.search_table_lineage(q, limit=limit)


@router.get("/api/lineage/query/{query_id}/tables")
def get_query_tables(query_id: int, type: str = FastQuery(default="sql")):
    """List physical tables referenced by a query."""
    db = _require_db()
    return db.get_table_lineage_for_query(type, query_id)


@router.post("/api/lineage/reparse")
def reparse_all_lineage():
    """Admin endpoint: re-extract table lineage for all saved SQL queries."""
    db = _require_db()
    from core.sql_lineage_parser import extract_and_store_lineage
    from core.config import lineage as _lineage_cfg

    max_batch = _lineage_cfg.max_reparse_batch
    succeeded = 0
    failed = 0
    errors = []

    with db.get_session() as session:
        from core.database import SqlSavedQuery, Connection
        queries = session.query(SqlSavedQuery).filter(
            SqlSavedQuery.is_active == True
        ).limit(max_batch).all()

        # Build connection type lookup
        conn_types = {}
        for c in session.query(Connection).all():
            conn_types[c.id] = c.type if hasattr(c, "type") else "duckdb"

        for sq in queries:
            try:
                conn_type = conn_types.get(sq.primary_connection_id, "duckdb")
                extract_and_store_lineage(
                    db, "sql_query", sq.id, sq.primary_sql,
                    connection_id=sq.primary_connection_id,
                    connection_type=conn_type,
                )
                succeeded += 1
            except Exception as e:
                failed += 1
                errors.append({"query_id": sq.id, "name": sq.name, "error": str(e)})

    return {"total": succeeded + failed, "succeeded": succeeded, "failed": failed, "errors": errors[:20]}


# ── Phase 51: Column-level lineage endpoints ──────────────────────────────────

@router.get("/api/lineage/query/{query_id}/columns")
async def get_query_column_lineage(query_id: int, query_type: str = "sql_query"):
    """Return column-level lineage entries for a SQL saved query."""
    db = _db_manager
    entries = db.get_column_lineage_for_query(query_type, query_id)
    return {"query_id": query_id, "query_type": query_type, "columns": entries, "count": len(entries)}


@router.get("/api/lineage/column/impact")
async def get_column_impact(table: str, column: str):
    """Return all queries that consume a specific source column.

    Query params: table=<table_name>&column=<col_name>
    """
    db = _db_manager
    entries = db.get_column_impact(table, column)
    return {
        "source_table": table,
        "source_column": column,
        "affected_queries": entries,
        "count": len(entries),
    }
