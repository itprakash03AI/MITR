"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

import json
import time as _time
import uuid
import logging
import traceback
from pathlib import Path
import asyncio
import os
import sys

# Note: faulthandler intentionally NOT enabled.
# DuckDB uses Structured Exception Handlers (SEH) on Windows; faulthandler's
# Vectored Exception Handler intercepts those and causes fatal crashes.
# Python-level crashes are caught by sys.excepthook / threading.excepthook.
# C-level crashes (segfaults) are isolated via subprocess execution (duckdb_subprocess.py).

# ══════════════════════════════════════════════════════════════════════════════
# FIRST: Set up logging + crash handler BEFORE any app imports.
# This ensures every error — including import failures — is captured.
# ══════════════════════════════════════════════════════════════════════════════
def _configure_logging():
    try:
        # Try to read log_format from config — but config may not be loadable yet
        from core.config import server as _srv
        use_json = _srv.log_format == "json"
    except Exception:
        use_json = True  # default to JSON if config not available

    if use_json:
        try:
            from pythonjsonlogger import jsonlogger
            handler = logging.StreamHandler()
            handler.setFormatter(jsonlogger.JsonFormatter(
                fmt="%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)d %(funcName)s",
                rename_fields={
                    "asctime": "timestamp", "levelname": "level", "name": "logger",
                    "pathname": "file", "lineno": "line", "funcName": "func",
                },
            ))
            logging.root.handlers = [handler]
            logging.root.setLevel(logging.INFO)
            return
        except ImportError:
            pass  # fall through to text format
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s [%(pathname)s:%(lineno)d]',
    )

_configure_logging()
logger = logging.getLogger(__name__)

# Global unhandled exception hook — log with full traceback before exit
def _global_exception_hook(exc_type, exc_value, exc_tb):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    logger.critical("Unhandled exception — backend crash", exc_info=(exc_type, exc_value, exc_tb))
    # Also print to stderr as fallback in case logger is broken
    traceback.print_exception(exc_type, exc_value, exc_tb, file=sys.stderr)

sys.excepthook = _global_exception_hook

# Thread exception hook — catches unhandled exceptions in thread-pool threads
def _thread_exception_hook(args):
    logger.critical("Unhandled exception in thread '%s'", args.thread.name if args.thread else "?", exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback, file=sys.stderr)

import threading
threading.excepthook = _thread_exception_hook

# Unraisable exception hook — catches errors Python can't propagate (GC, __del__, etc.)
def _unraisable_hook(unraisable):
    logger.critical("Unraisable exception in %s: %s", unraisable.object, unraisable.exc_value,
                    exc_info=(type(unraisable.exc_value), unraisable.exc_value, unraisable.exc_value.__traceback__) if unraisable.exc_value else True)

sys.unraisablehook = _unraisable_hook

# ══════════════════════════════════════════════════════════════════════════════
# Now safe to import app modules — any error will be logged with full traceback
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# Startup with step-by-step tracing — print() always works, even if logging is broken
# ══════════════════════════════════════════════════════════════════════════════
def _startup_step(label):
    """Print + log a startup step — print goes to stdout even if logger is broken."""
    print(f"[STARTUP] {label}", flush=True)
    logger.info("[STARTUP] %s", label)

try:
    _startup_step("1/12 Importing FastAPI + stdlib...")
    from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends, Header, Body, Query
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.gzip import GZipMiddleware
    from fastapi.responses import FileResponse
    from pydantic import BaseModel, Field
    from typing import List, Dict, Any, Optional, Tuple, Union
    from datetime import datetime, timedelta, timezone
    from concurrent.futures import ThreadPoolExecutor
    from dotenv import load_dotenv

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    _startup_step("2/12 Importing API routers...")
    from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
    from api.sql_query_api import router as sql_router, set_sql_dependencies
    from api.reports_api import router as reports_router, set_report_dependencies, set_reports_auth
    from api.schedules_api import router as schedules_router, set_schedule_dependencies, set_schedules_auth
    from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
    # Phase 23: Enterprise reporting (additive — no existing code modified)
    from api.catalog_api import router as catalog_router, set_catalog_dependencies
    from api.enterprise_reports_api import router as enterprise_router, set_enterprise_dependencies
    from api.pdf_export_api import router as pdf_router, set_pdf_dependencies
    from api.burst_api import router as burst_router, set_burst_dependencies
    from api.connection_profiles_api import router as profiles_router, set_profile_dependencies
    from api.workspaces_api import router as workspaces_router, set_workspace_dependencies
    from api.lineage_api import router as lineage_router, set_lineage_dependencies
    from api.embed_api import router as embed_router, set_embed_dependencies
    # Phase 29: Domain routers extracted from main.py
    from api.auth_api import router as auth_router, set_auth_dependencies
    from api.notifications_api import router as notifications_router, set_notification_dependencies
    from api.system_api import router as system_router, set_system_dependencies
    from api.admin_api import router as admin_router, set_admin_dependencies
    from api.connections_api import router as connections_router, set_connection_dependencies
    from api.queries_api import router as queries_router, set_query_dependencies
    from api.materialized_views_api import router as mv_router, set_mv_dependencies
    from api.local_tables_api import router as local_tables_router, set_local_table_dependencies
    import api.materialized_views_api as _mv_api_module
    # Phase 42: Arrow IPC response format
    from api.arrow_api import router as arrow_router, set_arrow_dependencies
    # Phases 46/47/48: Auto-suggest, query analysis, NL-to-SQL
    from api.suggest_api import router as suggest_router, set_suggest_dependencies

    # Phase 22F: GraphQL API (optional — requires strawberry-graphql)
    try:
        from api.graphql_api import get_graphql_router, set_graphql_dependencies
        _graphql_available = True
    except ImportError:
        _graphql_available = False

    load_dotenv()

    _startup_step("3/12 Importing parquet_engine_v2...")
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType, AggregationConfig

    _startup_step("4/12 Importing s3_storage...")
    from core.s3_storage import S3Config, build_s3_config, TokenExpiredError

    _startup_step("5/12 Importing database...")
    from core.database import DatabaseManager

    _startup_step("6/12 Importing websocket + connection manager...")
    from core.websocket_manager import WebSocketManager
    from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES

    _startup_step("7/12 Loading config...")
    from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg, limits as _limits_cfg, features as _features_cfg, materialized_views as _mv_cfg, local_tables as _lt_cfg

    _startup_step("8/12 Creating data directories...")
    _paths.data_dir.mkdir(parents=True, exist_ok=True)
    _paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _paths.upload_dir.mkdir(parents=True, exist_ok=True)
    Path(_mv_cfg.storage_dir).mkdir(parents=True, exist_ok=True)
    Path(_lt_cfg.storage_dir).mkdir(parents=True, exist_ok=True)

    _startup_step("9/12 Creating FastAPI app...")
    _DATA_DIR = _paths.data_dir
    _DB_URL   = _db_cfg.db_url

    _startup_step("10/12 Importing slowapi (rate limiter)...")
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded

    _startup_step("11/12 Importing prometheus_client...")
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

    _startup_step("12/12 All imports OK")

except Exception:
    print("[STARTUP] FATAL ERROR during startup:", flush=True)
    traceback.print_exc()
    traceback.print_exc(file=sys.stderr)
    logger.critical("FATAL: Startup failed", exc_info=True)
    sys.exit(1)

import re as _re
import atexit as _atexit

# Register atexit handler — catches silent process exits (e.g. DLL load failure, C-level crash)
def _atexit_handler():
    print("[ATEXIT] Backend process exiting", flush=True)
    try:
        logger.warning("[ATEXIT] Backend process exiting — check above for errors")
    except Exception:
        pass
    # Ensure thread pools don't block process exit
    try:
        query_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
    try:
        _streaming_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
_atexit.register(_atexit_handler)

# ── API versioning (22E) ──────────────────────────────────────────────────────
API_VERSION = "2.0.0"         # Semantic version exposed via header + endpoint
API_MAJOR   = "v2"            # URL prefix used in header (X-API-Version: v2)

# Initialize FastAPI app
app = FastAPI(
    title="QueryStudio API",
    description="Enterprise-grade analytics platform — S3, Iceberg, Snowflake, Trino, Databricks",
    version=API_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "auth",           "description": "Authentication — login, logout, session, OIDC/SAML"},
        {"name": "queries",        "description": "Saved queries, SQL editor, file browser, executions"},
        {"name": "connections",    "description": "Data source connections (S3, Snowflake, Trino, Databricks, Oracle, local)"},
        {"name": "reports",        "description": "Report builder — create, schedule, and share reports"},
        {"name": "dashboards",     "description": "Dashboard builder — compose multi-report dashboards"},
        {"name": "schedules",      "description": "Scheduled query / report execution"},
        {"name": "admin",          "description": "Admin — users, storage, audit log, compliance, cache"},
        {"name": "system",         "description": "Health, metrics, version"},
        {"name": "materialized-views", "description": "Materialized views — cached S3 data in local DuckDB"},
        {"name": "local-tables",   "description": "Local upload tables and table operations"},
        {"name": "lineage",        "description": "Data lineage graph"},
        {"name": "workspaces",     "description": "Workspace isolation (multi-tenant namespacing)"},
        {"name": "notifications",  "description": "In-app notification history"},
        {"name": "embed",          "description": "Embedded report tokens and rendering"},
        {"name": "graphql",        "description": "GraphQL API — Strawberry schema (optional)"},
    ],
)

# GZip compression (~70% payload reduction for JSON responses)
app.add_middleware(GZipMiddleware, minimum_size=1024)

# CORS middleware — origins/methods/headers driven by config.json / env vars
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_cfg.allow_origins,
    allow_credentials=True,
    allow_methods=_cors_cfg.allow_methods,
    allow_headers=_cors_cfg.allow_headers,
)

# Rate limiter setup
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

_prom_requests_total = Counter(
    "http_requests_total", "Total HTTP requests",
    ["method", "path_template", "status"],
)
_prom_request_duration = Histogram(
    "http_request_duration_seconds", "Request latency",
    ["method", "path_template"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30],
)
_prom_pool_active = Gauge("worker_pool_active_tasks", "Active tasks by type", ["work_type"])
_prom_pool_queued = Gauge("worker_pool_queued_tasks", "Queued tasks by type", ["work_type"])
_prom_websockets = Gauge("active_websocket_connections", "Active WebSocket connections")

# ── OpenTelemetry Tracing (21C) — optional, auto-disabled if not installed ──
def _setup_otel():
    """Configure OpenTelemetry if the SDK is installed and an endpoint is configured."""
    try:
        from core.config import server as _srv_cfg
        otel_endpoint = getattr(_srv_cfg, "otel_endpoint", "") or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "")
        if not otel_endpoint:
            return  # No endpoint configured — skip silently

        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

        resource = Resource.create({
            "service.name": os.environ.get("OTEL_SERVICE_NAME", "querystudio"),
            "service.version": "2.0.0",
        })
        provider = TracerProvider(resource=resource)
        exporter = OTLPSpanExporter(endpoint=otel_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor.instrument_app(app, tracer_provider=provider)
        logger.info("OpenTelemetry tracing enabled → %s", otel_endpoint)
    except ImportError:
        logger.debug("OpenTelemetry SDK not installed — tracing disabled")
    except Exception as exc:
        logger.warning("OpenTelemetry setup failed (non-fatal): %s", exc)

_setup_otel()

# Collapse UUIDs / numeric IDs in paths to prevent metric cardinality explosion
_UUID_RE = _re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", _re.I)
_NUMERIC_ID_RE = _re.compile(r"/\d+(?=/|$)")

def _normalize_metric_path(path: str) -> str:
    """Collapse /api/queries/abc-123-... → /api/queries/{id}"""
    path = _UUID_RE.sub("{id}", path)
    path = _NUMERIC_ID_RE.sub("/{id}", path)
    return path


# ── Middleware: security headers + request logging + Prometheus + origin check ─
@app.middleware("http")
async def _enterprise_middleware(request: Request, call_next):
    start = _time.time()
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])

    # ── Origin check (CSRF defense-in-depth) ──
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        origin = request.headers.get("origin") or request.headers.get("referer", "")
        allowed = _cors_cfg.allow_origins
        if allowed != ["*"] and origin:
            from urllib.parse import urlparse
            origin_host = urlparse(origin).netloc
            if origin_host and not any(origin_host in ao for ao in allowed):
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=403, content={"detail": "Origin not allowed"})

    try:
        response = await call_next(request)
    except BaseException as exc:
        # GLOBAL SAFETY NET — no endpoint crash should ever kill the backend.
        # Log the full traceback and return 500 instead of letting it propagate.
        duration_s = _time.time() - start
        logger.critical("Unhandled crash in %s %s: %s", request.method, request.url.path, exc, exc_info=True)
        from starlette.responses import JSONResponse as _JSONResp
        return _JSONResp(status_code=500, content={"detail": f"Internal server error: {type(exc).__name__}"})
    duration_s = _time.time() - start

    # ── Security headers ──
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "connect-src 'self' ws: wss:; "
        "font-src 'self' data:; "
        "object-src 'none'; "
        "frame-ancestors 'self'"
    )
    response.headers["X-Request-ID"] = request_id
    response.headers["X-API-Version"] = API_MAJOR

    # ── Request logging (structured JSON or text) ──
    path = request.url.path
    if path not in ("/health", "/metrics"):  # skip noisy health/metric polls
        logger.info("request", extra={
            "request_id": request_id,
            "method": request.method,
            "path": path,
            "status": response.status_code,
            "duration_ms": round(duration_s * 1000, 1),
            "client": request.client.host if request.client else None,
        })

    # ── Prometheus metrics ──
    path_tmpl = _normalize_metric_path(path)
    _prom_requests_total.labels(
        method=request.method, path_template=path_tmpl, status=response.status_code,
    ).inc()
    _prom_request_duration.labels(
        method=request.method, path_template=path_tmpl,
    ).observe(duration_s)

    return response


# Thread pool for CPU-bound query execution (heavy: COPY TO parquet, etc.)
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)

# Dedicated thread pool for lightweight operations: streaming, schema,
# file listing, metadata.  This is a SEPARATE pool from both query_executor
# and the WorkerPool so heavy background queries can never starve it.
# Sized for I/O-bound work (S3 HTTP calls, parquet footer reads).
_streaming_executor = ThreadPoolExecutor(
    max_workers=min(20, (os.cpu_count() or 4) * 2),
    thread_name_prefix="stream"
)

def _get_light_executor():
    """Return the dedicated streaming/metadata executor.

    Streaming pagination, schema discovery, file listing, metadata reads
    all go through this pool. It is completely isolated from the heavy
    query_executor and the WorkerPool, so it is never blocked by
    long-running background queries.
    """
    return _streaming_executor

# Notification poller asyncio task — set in _startup() when scheduler.mode = "external"
_notification_poller_task = None
# Executor poller asyncio task — set in _startup() when executor.mode = "external"
_executor_poller_task = None
app.include_router(data_grid_router,   tags=["queries"])
app.include_router(sql_router,          tags=["queries"])
app.include_router(reports_router,      tags=["reports"])
app.include_router(schedules_router,    tags=["schedules"])
app.include_router(dashboards_router,   tags=["dashboards"])
# Phase 23: Enterprise reporting routers (additive)
app.include_router(catalog_router,      tags=["reports"])
app.include_router(enterprise_router,   tags=["reports"])
app.include_router(pdf_router,          tags=["reports"])
app.include_router(burst_router,        tags=["reports"])
app.include_router(profiles_router,     tags=["queries"])
app.include_router(workspaces_router,   tags=["workspaces"])
app.include_router(lineage_router,      tags=["lineage"])
app.include_router(embed_router,        tags=["embed"])
# Phase 29: Domain routers
app.include_router(auth_router)
app.include_router(notifications_router)
app.include_router(system_router)
app.include_router(admin_router)
app.include_router(connections_router)
app.include_router(queries_router)
app.include_router(mv_router)
app.include_router(local_tables_router)
# Phase 42: Arrow IPC
app.include_router(arrow_router)
# Phases 46/47/48: Suggest, query analysis, NL-to-SQL
app.include_router(suggest_router, tags=["intelligence"])

# Phase 22F: GraphQL endpoint (optional — requires strawberry-graphql)
if _graphql_available:
    try:
        _gql_router = get_graphql_router()
        app.include_router(_gql_router, prefix="/graphql", tags=["graphql"])
        logger.info("GraphQL endpoint enabled at /graphql")
    except Exception as _gql_exc:
        logger.debug("GraphQL setup skipped: %s", _gql_exc)

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        auth_mode=os.getenv('S3_AUTH_MODE', 'keys'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        aws_profile=os.getenv('AWS_PROFILE'),
        role_arn=os.getenv('AWS_ROLE_ARN'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL'),
        ssl_verify=os.getenv('S3_SSL_VERIFY', 'true').lower() != 'false',
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# ── Notification logging helper ─────────────────────────────────────────────
def _log_ws_notification(event_type: str, recipient: str, title: str,
                         message: str = "", execution_id: str = None,
                         schedule_id: int = None, payload: dict = None):
    """Persist a WebSocket notification to DB for history / bell icon."""
    try:
        db_manager.log_notification(
            event_type=event_type,
            channel="websocket",
            recipient=recipient,
            status="sent",
            title=title,
            message=message,
            payload=payload,
            execution_id=execution_id,
            schedule_id=schedule_id,
        )
    except Exception as exc:
        logger.debug("Failed to log notification: %s", exc)


# Per-execution cancellation registry
import threading as _threading
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency tracking
_user_query_counts: dict = {}    # username → int (active query count)
_user_query_lock = _threading.Lock()

# In-flight query deduplication
# Maps cache_key → (primary_execution_id, asyncio.Event)
# asyncio is single-threaded for coroutines so plain dict ops between awaits are safe.
# Event is set when primary execution completes (success or failure).
_inflight_queries: dict = {}   # cache_key → (exec_id: str, event: asyncio.Event)

# Global concurrency gate — asyncio.Semaphore limits system-wide active queries.
# Queries exceeding the semaphore wait in a FIFO queue (up to max_queue_size).
import asyncio as _asyncio
_global_query_sem: _asyncio.Semaphore | None = None   # initialised at startup
_global_queue_count = 0
_global_queue_lock = _threading.Lock()

def _init_query_semaphore():
    global _global_query_sem
    _global_query_sem = _asyncio.Semaphore(_qe_cfg.max_concurrent_global)

@app.on_event("startup")
async def _startup_init_semaphore():
    _init_query_semaphore()


# ── Active Directory / Auth helpers ───────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    password: str


# ── Server-side session store (in-memory, TTL-based) ─────────────────────────
# Stores opaque tokens → user info so that AD/LDAP passwords are NEVER persisted
# or sent after the initial login.

# ── Session management — delegates to core/sessions.py (single source of truth) ──
from core.sessions import create_session as _core_create_session
from core.sessions import get_session as _core_get_session
from core.sessions import destroy_session as _core_destroy_session


def _create_session(user_info: dict) -> str:
    """Create a session token and store user info server-side."""
    return _core_create_session(user_info)


def _get_session(token: str) -> Optional[dict]:
    """Look up a session token. Returns user info or None if expired/missing."""
    return _core_get_session(token)


def _destroy_session(token: str):
    """Remove a session token (logout)."""
    _core_destroy_session(token)


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none"  → always returns a guest admin (no login required)
    - "Bearer <session_token>" → look up server-side session (preferred)
    - "Basic <base64>" → authenticate directly (fallback / backward compat)
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True,
                "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Prefer session tokens — no password stored or transmitted after login
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        user = _core_get_session(token)
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Fallback: Basic auth (used by legacy clients / API testing)
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _require_admin(user: dict = Depends(_get_current_user)) -> dict:
    """FastAPI dependency that enforces admin access on admin endpoints."""
    if _auth_cfg.type != "none" and not (user or {}).get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def _require_role(*allowed_roles: str):
    """Factory: returns a FastAPI dependency that checks user role."""
    def dep(user: dict = Depends(_get_current_user)) -> dict:
        if _auth_cfg.type == "none":
            return user  # dev mode — no restriction
        role = (user or {}).get("role", "viewer")
        if role not in allowed_roles:
            raise HTTPException(403, f"Requires role: {', '.join(allowed_roles)}")
        return user
    return dep


def _require_execute_access(
    request: Request,
    x_share_token: Optional[str] = Header(None),
    x_embed_token: Optional[str] = Header(None),
    _user: Optional[dict] = Depends(_get_current_user),
) -> dict:
    """Dependency for execute_query: allows access via normal auth OR a valid share/embed token.

    Used on /api/queries/execute so that shared-URL pages and embedded report
    pages can execute queries without requiring the viewer to be logged in.
    """
    if _auth_cfg.type == "none":
        return _user or {"username": "guest", "role": "admin", "is_admin": True}
    # Authenticated user with proper role
    if _user and _user.get("role") in ("admin", "analyst"):
        return _user
    # Share-token alternative — lets SharedQueryPage & SharedDashboardPage execute
    if x_share_token:
        try:
            # Check query share token first, then dashboard share token
            share = db_manager.get_share_by_token(x_share_token)
            if not share:
                share = db_manager.get_dashboard_share_by_token(x_share_token)
            if share and share.get("is_active"):
                return {
                    "username": f"shared:{x_share_token[:8]}",
                    "role": "analyst",
                    "is_admin": False,
                }
        except Exception:
            pass
    # Embed-token alternative — lets EmbeddedReportPage execute (Phase 27)
    if x_embed_token and db_manager:
        try:
            from datetime import datetime, timezone as _tz
            t = db_manager.get_embed_token(x_embed_token)
            if t and t.get("is_active"):
                expires = t.get("expires_at")
                if expires:
                    if isinstance(expires, str):
                        expires = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    if expires.tzinfo is None:
                        expires = expires.replace(tzinfo=_tz.utc)
                    if datetime.now(_tz.utc) <= expires:
                        return {
                            "username": f"embed:{x_embed_token[:8]}",
                            "role": "analyst",
                            "is_admin": False,
                        }
                else:
                    return {
                        "username": f"embed:{x_embed_token[:8]}",
                        "role": "analyst",
                        "is_admin": False,
                    }
        except Exception:
            pass
    raise HTTPException(status_code=403, detail="Authorization header required")


def _is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if the user owns this item or it's marked as shared."""
    if not user or user.get("is_admin"):
        return True  # admins see everything
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )


def _is_container_env() -> bool:
    """Detect if running inside Docker/OpenShift/Kubernetes."""
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


# Pydantic Models
class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cache strategy: auto = use cache if available; bypass = skip cache (no store);
    #                 refresh = skip cache lookup but store fresh result
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None
    # Async control fields
    wait: bool = False                     # Block until complete (external executor mode only)
    wait_timeout: int = Field(default=30, ge=1, le=300)  # Max seconds to wait
    callback_url: Optional[str] = None    # Webhook POST on completion/failure
    idempotency_key: Optional[str] = None  # Client-generated UUID to prevent duplicate submissions


_ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle)$"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# Helper functions
# build_s3_config is imported from core.s3_storage — single source of truth


def convert_query_config_to_engine(config: QueryConfigModel) -> QueryConfig:
    """Convert API model to engine QueryConfig"""
    joins = None
    if config.joins:
        joins = [
            JoinConfig(
                left_file=j.left_file,
                right_file=j.right_file,
                left_on=j.left_on,
                right_on=j.right_on,
                how=j.how,
                right_column_aliases=j.right_column_aliases or {},
            )
            for j in config.joins
        ]
    
    filters = None
    if config.filters:
        filters = [
            {
                "column": f.column,
                "operator": f.operator,
                "value": f.value
            }
            for f in config.filters
        ]
    
    order_by = None
    if config.order_by:
        order_by = [
            {
                "column": o.column,
                "direction": o.direction
            }
            for o in config.order_by
        ]
    
    aggregations = None
    if config.aggregations:
        aggregations = [
            AggregationConfig(column=a.column, function=a.function.upper(),
                              alias=a.alias, distinct=a.distinct)
            for a in config.aggregations
        ]

    having = None
    if config.having:
        having = [{"column": h.column, "function": h.function.upper(),
                   "operator": h.operator, "value": h.value}
                  for h in config.having]

    computed_columns = None
    if config.computed_columns:
        computed_columns = [{"expression": c.expression, "alias": c.alias}
                           for c in config.computed_columns]

    case_expressions = None
    if config.case_expressions:
        case_expressions = [
            {"when_clauses": [{"when_column": w.when_column, "when_operator": w.when_operator,
                               "when_value": w.when_value, "then_value": w.then_value}
                              for w in ce.when_clauses],
             "else_value": ce.else_value, "alias": ce.alias}
            for ce in config.case_expressions
        ]

    window_functions = None
    if config.window_functions:
        window_functions = [
            {"function": wf.function.upper(), "alias": wf.alias,
             "column": wf.column,
             "partition_by": wf.partition_by,
             "order_by": [{"column": o.column, "direction": o.direction}
                          for o in wf.order_by] if wf.order_by else None,
             "offset": wf.offset, "default_value": wf.default_value}
            for wf in config.window_functions
        ]

    return QueryConfig(
        files=config.files,
        joins=joins,
        filters=filters,
        columns=config.columns,
        limit=config.limit,
        offset=config.offset,
        order_by=order_by,
        group_by=config.group_by,
        aggregations=aggregations,
        distinct=config.distinct,
        having=having,
        filter_logic=config.filter_logic.upper(),
        computed_columns=computed_columns,
        case_expressions=case_expressions,
        column_aliases=config.column_aliases,
        window_functions=window_functions,
    )


# ── Iceberg data-file cache: L1 in-memory (5 min) + L2 SQLite (5 hours) ─────
# Avoids re-scanning S3 manifests.  L2 survives server restarts.
# Key: (connection_id, table_name, filters_hash)  →  (active_files, metadata, ts)
_ICE_FILE_CACHE: Dict[tuple, dict] = {}
_ICE_FILE_CACHE_TTL = 300       # L1: 5 minutes (in-memory hot cache)
_ICE_FILE_CACHE_L2_TTL = 18000  # L2: 5 hours (persistent SQLite cache)

def _ice_cache_key(connection_id, tname, partition_filters):
    import json as _json
    pf_str = _json.dumps(partition_filters, sort_keys=True, default=str) if partition_filters else ""
    return (connection_id, tname, pf_str)

def _ice_cache_get(key):
    # L1 check — fast in-memory
    entry = _ICE_FILE_CACHE.get(key)
    if entry and (_time.monotonic() - entry["ts"]) < _ICE_FILE_CACHE_TTL:
        return entry
    if entry:
        del _ICE_FILE_CACHE[key]

    # L2 check — persistent SQLite
    connection_id, table_name, filters_hash = key
    try:
        db_entry = db_manager.get_iceberg_file_cache(connection_id, table_name, filters_hash)
        if db_entry:
            updated = datetime.fromisoformat(db_entry["updated_at"]).replace(tzinfo=timezone.utc) \
                      if isinstance(db_entry["updated_at"], str) else db_entry["updated_at"]
            if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _ICE_FILE_CACHE_L2_TTL:
                # Promote to L1
                result = {"files": db_entry["file_list"], "metadata": None, "ts": _time.monotonic()}
                _ICE_FILE_CACHE[key] = result
                logger.debug("Iceberg file cache L2 hit: %s/%s (%d files)",
                             table_name, filters_hash[:30], len(db_entry["file_list"]))
                return result
    except Exception as exc:
        logger.warning("Iceberg file cache L2 read error: %s", exc)

    return None

def _ice_cache_set(key, active_files, metadata, record_count=0):
    # L1 store
    _ICE_FILE_CACHE[key] = {"files": active_files, "metadata": metadata, "ts": _time.monotonic(), "record_count": record_count}
    # Evict stale L1 entries (max 200)
    if len(_ICE_FILE_CACHE) > 200:
        now = _time.monotonic()
        stale = [k for k, v in _ICE_FILE_CACHE.items() if now - v["ts"] > _ICE_FILE_CACHE_TTL]
        for k in stale:
            _ICE_FILE_CACHE.pop(k, None)

    # L2 store — persistent SQLite
    connection_id, table_name, filters_hash = key
    try:
        db_manager.set_iceberg_file_cache(connection_id, table_name, filters_hash, active_files)
    except Exception as exc:
        logger.warning("Iceberg file cache L2 write error: %s", exc)


class _SQLCollector:
    """Fake DuckDB connection that records SQL instead of executing it.

    Used by _setup_registered_views(con=collector) to capture CREATE VIEW
    statements so they can be replayed in a crash-isolated subprocess.
    """
    def __init__(self):
        self.statements: list[str] = []

    def execute(self, sql: str):
        self.statements.append(sql)

    def close(self):
        pass


def _setup_registered_views(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
    con=None,
):
    """Set up DuckDB views for registered S3 tables and build query SQL.

    If *con* is provided (e.g. a _SQLCollector), it is used instead of
    creating a real DuckDB connection — this lets callers capture the
    generated SQL without touching DuckDB.

    Resolves __registered__:table_name → DuckDB views backed by:
      - Iceberg: read Iceberg manifests → read_parquet([active files])
      - Parquet: read_parquet('s3://bucket/prefix/**/*.parquet')
      - CSV: read_csv_auto('s3://bucket/prefix/**/*.csv')

    Returns (con, sql, auto_partition_info).
    Caller MUST close con in a finally block.
    """
    import duckdb as _ddb
    from api.data_grid_api import _duckdb_con_with_s3

    # Resolve table names from files
    table_map = {}  # name → table_def
    for t in registered_tables:
        table_map[t["name"]] = t

    # Collect ALL table references: primary files + join right_files
    _all_refs = list(query_config.files)
    if query_config.joins:
        for jc in query_config.joins:
            rf = jc.right_file if isinstance(jc.right_file, str) else jc.right_file.path
            if rf not in _all_refs:
                _all_refs.append(rf)

    resolved_names = []
    _mv_refs = []   # materialized view names to register
    _lt_refs = []   # local table names to register
    for f in _all_refs:
        fstr = f if isinstance(f, str) else f.path
        if fstr.startswith("__registered__:"):
            resolved_names.append(fstr.replace("__registered__:", ""))
        elif fstr.startswith("__materialized__:"):
            _mv_refs.append(fstr.replace("__materialized__:", ""))
        elif fstr.startswith("__local__:"):
            _lt_refs.append(fstr.replace("__local__:", ""))
        else:
            resolved_names.append(fstr)

    _step_t0 = _time.monotonic()

    def _log(msg: str, reset_timer: bool = True):
        nonlocal _step_t0
        elapsed = _time.monotonic() - _step_t0
        timed_msg = f"{msg} [{elapsed:.1f}s]" if elapsed > 0.1 else msg
        if progress_fn:
            progress_fn({"status": "processing", "log": timed_msg})
        logger.info(timed_msg)
        if reset_timer:
            _step_t0 = _time.monotonic()

    # Create DuckDB connection with S3 creds and register views
    _con_provided = con is not None
    if not _con_provided:
        _log("Connecting to S3 with DuckDB...")
        con = _duckdb_con_with_s3(conn_config, connection_id=connection_id)

    _auto_partition_applied = None

    # Register materialized views as local parquet VIEWs (if referenced)
    if _mv_refs:
        import glob as _gm
        for mv_name in _mv_refs:
            mv_rec = db_manager.get_materialized_view_by_name(mv_name)
            if mv_rec and mv_rec["status"] == "ready":
                mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_rec["id"]))
                pq_files = _gm.glob(os.path.join(mv_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    vname = "__mv__" + mv_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    _log(f"Registered MV '{mv_name}' ({len(pq_files)} local files)")

    # Register local tables as local parquet VIEWs (if referenced)
    if _lt_refs:
        import glob as _gm2
        for lt_name in _lt_refs:
            lt_rec = db_manager.get_local_table_by_name(lt_name)
            if lt_rec and lt_rec["status"] == "ready":
                lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_rec["id"]))
                pq_files = _gm2.glob(os.path.join(lt_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                    vname = "__lt__" + lt_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    _log(f"Registered local table '{lt_name}' ({len(pq_files)} local files)")
                    try:
                        db_manager.touch_local_table(lt_rec["id"])
                    except Exception:
                        pass

    for tname in resolved_names:
        tdef = table_map.get(tname)
        if not tdef:
            raise ValueError(
                f"Registered table '{tname}' not found. "
                f"Available tables: {', '.join(table_map.keys()) or '(none)'}"
            )
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        safe_name = tname.replace('"', '""')

        def _esc_sql(v: str) -> str:
            return v.replace("'", "''")

        if fmt == "iceberg":
            from core.iceberg_reader import (
                get_iceberg_data_files, get_latest_partition_value,
                _extract_partition_spec, _latest_metadata_key, _read_s3_json,
            )
            s3_client = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})

            # Convert query filters → Iceberg partition filters for manifest pruning
            partition_filters = None
            if query_config.filters:
                _OP_MAP = {
                    "equals": "equals", "eq": "equals", "=": "equals",
                    "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
                    "greater_than": "greater_than", "gt": "greater_than", ">": "greater_than",
                    "less_than": "less_than", "lt": "less_than", "<": "less_than",
                    "greater_equals": "greater_equals", "gte": "greater_equals", ">=": "greater_equals",
                    "less_equals": "less_equals", "lte": "less_equals", "<=": "less_equals",
                }
                partition_filters = []
                for flt in query_config.filters:
                    f_op = flt["operator"] if isinstance(flt, dict) else flt.operator
                    f_col = flt["column"] if isinstance(flt, dict) else flt.column
                    f_val = flt["value"] if isinstance(flt, dict) else flt.value
                    if f_op == "in" and isinstance(f_val, list) and len(f_val) > 0:
                        partition_filters.append({"col": f_col, "op": "in", "val": f_val})
                        continue
                    mapped_op = _OP_MAP.get(f_op)
                    if mapped_op and f_val is not None:
                        partition_filters.append({"col": f_col, "op": mapped_op, "val": f_val})
                if not partition_filters:
                    partition_filters = None

            # ── Check data-file cache BEFORE reading metadata ─────────
            _cache_key = _ice_cache_key(connection_id, tname, partition_filters)
            _cached = _ice_cache_get(_cache_key)
            if _cached:
                active_files = _cached["files"]
                _metadata = _cached["metadata"]
                _log(f"'{tname}': using cached file list ({len(active_files)} files, cache hit)")
            else:
                _log(f"Reading Iceberg metadata for '{tname}'...")

                # ── Read metadata ONCE — reused for partition spec, auto-partition, and data files
                _meta_prefix = tdef["s3_prefix"].rstrip("/") + "/metadata/"
                _meta_key = _latest_metadata_key(s3_client, bucket, _meta_prefix)
                _metadata = _read_s3_json(s3_client, bucket, _meta_key)

                # ── Auto-select latest partition when none specified ──────
                # Read partition spec to get column types
                _partition_col_types: Dict[str, str] = {}
                try:
                    _partition_col_types = _extract_partition_spec(_metadata)
                    _schemas = _metadata.get("schemas") or ([_metadata["schema"]] if "schema" in _metadata else [])
                    _field_id_to_name = {}
                    for _sch in _schemas:
                        for _sf in _sch.get("fields", []):
                            _fid = _sf.get("id") or _sf.get("field-id")
                            if _fid is not None:
                                _field_id_to_name[_fid] = _sf.get("name", "")
                    _specs = _metadata.get("partition-specs") or ([_metadata["partition-spec"]] if "partition-spec" in _metadata else [])
                    _def_spec_id = _metadata.get("default-spec-id", 0)
                    _active_spec = next((s for s in _specs if s.get("spec-id") == _def_spec_id), _specs[0] if _specs else {})
                    for _pf in _active_spec.get("fields", []):
                        _src_id = _pf.get("source-id") or _pf.get("source_id")
                        _src_name = _field_id_to_name.get(_src_id, "")
                        _pname = _pf.get("name", "")
                        if _pname in _partition_col_types and _src_name:
                            _partition_col_types[_src_name] = _partition_col_types[_pname]
                except Exception as _pe:
                    logger.warning("Could not read partition spec for type casting: %s", _pe)

                _has_partition_filter = False
                if query_config.filters:
                    _all_partition_names = set(_partition_col_types.keys())
                    _all_partition_names_lower = {n.lower() for n in _all_partition_names}
                    for _flt in query_config.filters:
                        _fc = _flt["column"] if isinstance(_flt, dict) else _flt.column
                        if _fc in _all_partition_names or _fc.lower() in _all_partition_names_lower:
                            _has_partition_filter = True
                            break

                if not _has_partition_filter and _partition_col_types:
                    try:
                        _latest = get_latest_partition_value(
                            s3_client, bucket, tdef["s3_prefix"], metadata=_metadata)
                        if _latest:
                            if partition_filters is None:
                                partition_filters = []
                            if query_config.filters is None:
                                query_config.filters = []
                            for _lp_col, _lp_val in _latest.items():
                                partition_filters.append({
                                    "col": _lp_col, "op": "equals", "val": _lp_val,
                                })
                                query_config.filters.append({
                                    "column": _lp_col, "operator": "eq", "value": _lp_val,
                                })
                            _auto_partition_applied = _latest
                            _log(f"Auto-selected latest partition: {', '.join(f'{k}={v}' for k, v in _latest.items())}")
                            # Recompute cache key with auto-partition filters
                            _cache_key = _ice_cache_key(connection_id, tname, partition_filters)
                            _cached = _ice_cache_get(_cache_key)
                            if _cached:
                                active_files = _cached["files"]
                                _log(f"'{tname}': using cached file list ({len(active_files)} files, cache hit after auto-partition)")
                    except Exception as _lpe:
                        logger.warning("Could not determine latest partition for '%s': %s", tname, _lpe)

                # Only scan manifests if we didn't get a cache hit
                if not _cached:
                    if partition_filters:
                        _pf_desc = ", ".join(f"{pf['col']}={pf['val']}" if pf['op'] == 'equals'
                                             else f"{pf['col']} {pf['op']} {pf['val']}"
                                             for pf in partition_filters)
                        _log(f"Scanning manifests for '{tname}' (filters: {_pf_desc})...")
                    else:
                        _log(f"Scanning manifests for '{tname}' (no partition filter — full scan)...")
                    data_file_entries = get_iceberg_data_files(
                        s3_client, bucket, tdef["s3_prefix"],
                        partition_filters=partition_filters,
                        keys_only=True,
                        metadata=_metadata,
                    )
                    active_files = [f"s3://{bucket}/{df['key']}" for df in data_file_entries]
                    _ice_record_count = sum(df.get("record_count", 0) for df in data_file_entries)
                    # Cache the result for subsequent queries
                    _ice_cache_set(_cache_key, active_files, _metadata, record_count=_ice_record_count)
            if not active_files:
                # No files match the partition combination — create an empty view
                # so the query returns 0 rows instead of raising an error.
                _log(f"'{tname}': 0 data files match the selected partition combination — query will return empty result")
                # Use the first parquet file from a full scan to get the schema,
                # then add WHERE FALSE to produce 0 rows.
                _all_files = get_iceberg_data_files(
                    s3_client, bucket, tdef["s3_prefix"],
                    partition_filters=None, keys_only=True, max_files=1,
                    metadata=_metadata,
                )
                if _all_files:
                    _schema_file = f"s3://{bucket}/{_all_files[0]['key']}"
                    con.execute(
                        f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet(\'{_esc_sql(_schema_file)}\', '
                        f'hive_partitioning=true) WHERE FALSE'
                    )
                else:
                    raise ValueError(f"No active data files found for Iceberg table '{tname}'")
            else:
                paths_sql = ", ".join(f"'{_esc_sql(p)}'" for p in active_files)
                _log(f"'{tname}': scanning {len(active_files)} data files")
                _view_sql = (
                    f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet([{paths_sql}], '
                    f'hive_partitioning=true, union_by_name=true)'
                )
                con.execute(_view_sql)

        elif fmt == "csv":
            uri = f"s3://{_esc_sql(bucket)}/{_esc_sql(prefix)}/**/*.csv"
            con.execute(f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_csv_auto(\'{uri}\')')
        else:  # parquet
            uri = f"s3://{_esc_sql(bucket)}/{_esc_sql(prefix)}/**/*.parquet"
            con.execute(
                f'CREATE OR REPLACE VIEW "{safe_name}" AS SELECT * FROM read_parquet(\'{uri}\', '
                f'hive_partitioning=true)'
            )
        _log(f"Registered DuckDB view '{tname}' (format={fmt})")

    # ── Cast date/timestamp filter values for SQL (AFTER all views are registered
    #    so partition pruning uses raw values, not SQL-cast literals) ──────────
    import re as _re
    _DATE_RE = _re.compile(r"^\d{4}-\d{2}-\d{2}$")
    _TS_RE   = _re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}")
    _ALREADY_CAST = _re.compile(
        r"^(DATE|TIMESTAMP|TIME|INTERVAL)\s+'", _re.IGNORECASE)

    def _auto_cast(v: str) -> str:
        if _ALREADY_CAST.match(v):
            return v
        if _DATE_RE.match(v):
            return f"DATE '{v}'"
        if _TS_RE.match(v):
            return f"TIMESTAMP '{v}'"
        return v

    if query_config.filters:
        for flt in query_config.filters:
            if isinstance(flt, dict):
                val = flt.get("value")
            else:
                val = flt.value
            if val is None:
                continue
            if isinstance(val, str):
                new_val = _auto_cast(val)
                if new_val != val:
                    if isinstance(flt, dict): flt["value"] = new_val
                    else: flt.value = new_val
                    f_col = flt["column"] if isinstance(flt, dict) else flt.column
                    logger.info("Cast filter: %s  %s → %s", f_col, val, new_val)
            elif isinstance(val, list):
                cast_vals = [_auto_cast(v) if isinstance(v, str) else v for v in val]
                if cast_vals != list(val):
                    if isinstance(flt, dict): flt["value"] = cast_vals
                    else: flt.value = cast_vals

    # ── Deduplicate filters (joins can cause same partition filter from both tables) ─
    if query_config.filters:
        _seen_filters = set()
        _deduped = []
        for flt in query_config.filters:
            f_col = flt["column"] if isinstance(flt, dict) else flt.column
            f_op  = flt["operator"] if isinstance(flt, dict) else flt.operator
            f_val = flt.get("value") if isinstance(flt, dict) else flt.value
            _fkey = (f_col, f_op, str(f_val))
            if _fkey not in _seen_filters:
                _seen_filters.add(_fkey)
                _deduped.append(flt)
        if len(_deduped) < len(query_config.filters):
            logger.info("Deduplicated filters: %d → %d", len(query_config.filters), len(_deduped))
            query_config.filters = _deduped

    # Append MV / local table view names so they appear in the FROM clause
    for mv_name in _mv_refs:
        resolved_names.append(f"__mv__{mv_name}")
    for lt_name in _lt_refs:
        resolved_names.append(f"__lt__{lt_name}")

    # Build FROM clause using view names
    def _q(n):
        """Quote a column/table name for DuckDB, escaping embedded double-quotes."""
        return '"' + str(n).replace('"', '""') + '"'

    if not resolved_names:
        raise ValueError("No tables selected for query")
    primary = resolved_names[0]
    if len(resolved_names) > 1 and not query_config.joins:
        union_parts = " UNION ALL ".join(f"SELECT * FROM {_q(n)}" for n in resolved_names)
        from_clause = f"({union_parts}) AS t0"
    else:
        from_clause = f"{_q(primary)} AS t0"

    if query_config.joins:
        for idx, jc in enumerate(query_config.joins, start=1):
            rt = jc.right_file if isinstance(jc.right_file, str) else jc.right_file.path
            if rt.startswith("__registered__:"):
                rt = rt.replace("__registered__:", "")
            alias = f"t{idx}"
            join_type = jc.how.upper()
            if join_type not in ("INNER", "LEFT", "RIGHT"):
                join_type = "FULL OUTER"
            on_parts = [
                f"t0.{_q(l)} = {alias}.{_q(r)}"
                for l, r in zip(jc.left_on, jc.right_on)
            ]
            from_clause += f"\n  {join_type} JOIN {_q(rt)} AS {alias} ON {' AND '.join(on_parts)}"

    # Build SQL using existing engine method
    sql = engine.build_query_sql(query_config, from_clause)
    _log("SQL built")
    logger.info("Registered table SQL:\n%s", sql)

    return con, sql, _auto_partition_applied


def _execute_registered_table_query(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
):
    """Execute a query against registered S3 tables, streaming results as Arrow tables."""
    import pyarrow as _pa

    con, sql, auto_part = _setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn)

    if auto_part:
        query_config._auto_partition = auto_part

    try:
        if progress_fn:
            progress_fn({"status": "processing", "log": "Executing SQL query on S3 data..."})

        _t0 = _time.monotonic()
        result = con.execute(sql)
        reader = result.fetch_record_batch(rows_per_batch=engine.chunk_size)
        total = 0
        for batch in reader:
            if len(batch) == 0:
                continue
            total += len(batch)
            elapsed = _time.monotonic() - _t0
            if progress_fn:
                progress_fn({"status": "processing",
                             "log": f"Streaming: {total:,} rows [{elapsed:.1f}s]"})
            yield _pa.Table.from_batches([batch])

        elapsed = _time.monotonic() - _t0
        if progress_fn:
            progress_fn({"status": "processing",
                         "log": f"Query returned {total:,} rows [{elapsed:.1f}s]"})
    finally:
        con.close()


def _execute_registered_table_copy_to(
    engine: "ParquetQueryEngine",
    query_config: "QueryConfig",
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    output_path: str,
    connection_id: int = None,
    progress_fn=None,
    cancel_event=None,
):
    """Execute registered table query using DuckDB COPY TO (fast path).

    Runs DuckDB in a **subprocess** for crash isolation — a C-level crash
    (access violation / segfault) in DuckDB only kills the child process,
    not the main backend.

    Falls back to in-process execution if subprocess mode fails for a
    non-crash reason (import error, etc.).
    """
    import pyarrow.parquet as _pq

    # ── Phase 1: Resolve files + build SQL (no DuckDB, safe) ──────────────
    collector = _SQLCollector()
    _, sql, auto_part = _setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn, con=collector)

    # Build KV metadata clause for auto_partition
    kv_meta = {}
    if auto_part:
        kv_meta["auto_partition"] = json.dumps(auto_part)
    kv_clause = ""
    if kv_meta:
        kv_pairs = ", ".join(f"'{k}': '{v}'" for k, v in kv_meta.items())
        kv_clause = f", KV_METADATA {{{kv_pairs}}}"

    setup_sql_str = ";\n".join(collector.statements)
    logger.info("COPY TO setup SQL (%d statements):\n%s", len(collector.statements), setup_sql_str[:2000])
    logger.info("COPY TO inner SQL:\n%s", sql)

    # ── Two-phase execution: preview + full download ─────────────────────
    result = _s3_full_copy(
        inner_sql=sql,
        output_path=output_path,
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql_str,
        connection_id=connection_id,
        progress_fn=progress_fn,
        timeout=600,
        kv_clause=kv_clause,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]

    # Write auto_partition to Parquet KV metadata (subprocess may not support KV_METADATA)
    if auto_part and os.path.exists(output_path):
        try:
            meta = _pq.read_metadata(output_path)
            if not meta.metadata or b"auto_partition" not in (meta.metadata or {}):
                tbl = _pq.read_table(output_path)
                existing = tbl.schema.metadata or {}
                existing[b"auto_partition"] = json.dumps(auto_part).encode()
                tbl = tbl.replace_schema_metadata(existing)
                _pq.write_table(tbl, output_path, compression="ZSTD")
                total_rows = len(tbl)
                file_size = os.path.getsize(output_path)
        except Exception as _meta_exc:
            logger.warning("Could not embed auto_partition metadata: %s", _meta_exc)

    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"COPY TO complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "status": "completed",
        "chunks_processed": 1,
    }



def _strip_sql_limit(sql: str) -> str:
    """Remove trailing LIMIT [N] [OFFSET N] from a SQL statement.

    Handles optional trailing semicolons and whitespace.
    Only strips the outermost LIMIT — inner subquery LIMITs are preserved.
    """
    import re
    # Strip trailing semicolons and whitespace first
    cleaned = sql.rstrip().rstrip(';').rstrip()
    return re.sub(
        r'\s+LIMIT\s+(\d+|ALL)(\s+OFFSET\s+\d+)?\s*$', '',
        cleaned, flags=re.IGNORECASE,
    )


def _s3_full_copy(
    inner_sql: str,
    output_path: str,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str = "",
    connection_id=None,
    progress_fn=None,
    timeout: int = 600,
    kv_clause: str = "",
) -> dict:
    """Download the full dataset from S3 — LIMIT is stripped so the cache
    always contains the complete result set.

    Any user-specified LIMIT is removed from the S3 download SQL.  The local
    parquet file will contain ALL matching rows.  LIMIT / pagination are
    applied locally when serving data to the DataGridViewer.
    """
    from core.duckdb_subprocess import run_duckdb_copy_to

    full_sql = _strip_sql_limit(inner_sql)
    safe_out = output_path.replace("\\", "/").replace("'", "''")

    if progress_fn:
        progress_fn({"status": "processing", "log": "Processing query from S3…"})

    copy_sql = (
        f"COPY ({full_sql}) TO '{safe_out}' "
        f"(FORMAT PARQUET, COMPRESSION ZSTD{kv_clause})"
    )
    result = run_duckdb_copy_to(
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql,
        copy_sql=copy_sql,
        output_path=output_path,
        connection_id=connection_id,
        timeout=timeout,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]
    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"Processing complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {"total_rows": total_rows, "file_size_bytes": file_size,
            "status": "completed", "chunks_processed": 1}


async def _join_inflight_query(shadow_id: str, cache_key: str,
                               event: "asyncio.Event", primary_id: str) -> None:
    """Wait for a primary execution to finish then serve its result to a shadow execution.

    Called as a background task when a duplicate query arrives while the
    identical query is already downloading from S3.  The shadow execution
    gets its own DB record and WS broadcast — users see their own execution
    in history — but no second S3 download is started.
    """
    try:
        await asyncio.wait_for(event.wait(), timeout=660)
    except asyncio.TimeoutError:
        logger.warning("[dedup] Shadow %s timed out waiting for primary %s", shadow_id[:8], primary_id[:8])
        db_manager.update_execution(shadow_id, status="failed",
                                    error_message="Timed out waiting for shared execution")
        await ws_manager.broadcast({
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Timed out waiting for shared execution",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        return

    # Primary finished — check if its output file exists
    output_file = _paths.downloads_dir / f"{primary_id}.parquet"
    if output_file.exists():
        try:
            file_size = output_file.stat().st_size
        except FileNotFoundError:
            file_size = 0
            output_file = None

    if output_file and output_file.exists():
        file_id = str(uuid.uuid4())
        # Carry over total_rows from primary so execution history shows correct count
        _primary_rec = db_manager.get_execution(primary_id) or {}
        db_manager.update_execution(shadow_id, status="completed",
                                    output_file=str(output_file),
                                    total_rows=_primary_rec.get("total_rows", 0),
                                    file_size_bytes=file_size)
        db_manager.create_download_file(
            file_id=file_id, execution_id=shadow_id,
            filename=f"result_{shadow_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=file_size,
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": shadow_id,
            "file_id": file_id,
            "shared_from": primary_id,
            "stats": {
                "total_rows": _primary_rec.get("total_rows", 0),
                "total_columns": _primary_rec.get("total_columns"),
                "duration_seconds": _primary_rec.get("duration_seconds"),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("[dedup] Shadow %s completed via primary %s (shared file)", shadow_id[:8], primary_id[:8])
    else:
        # Primary failed — inform shadow
        db_manager.update_execution(shadow_id, status="failed",
                                    error_message=f"Shared execution {primary_id[:8]} failed")
        await ws_manager.broadcast({
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Shared execution failed — please retry",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.warning("[dedup] Shadow %s failed because primary %s failed", shadow_id[:8], primary_id[:8])


def _run_base_data_local_query(
    base_parquet: Path, query_config: dict, output_path: Path,
) -> Optional[dict]:
    """Run a presentation-only SQL against an already-downloaded local parquet.

    The base_parquet contains rows matching the original FROM/WHERE/JOIN from
    a previous S3 download.  We only need SELECT / aggregation / GROUP BY /
    ORDER BY / LIMIT on top — no network round-trip.

    Returns {"total_rows": int, "file_size_bytes": int} on success, None on
    failure (e.g. missing columns in the cached file).
    """
    try:
        import duckdb as _ddb
    except ImportError:
        return None
    con = None
    try:
        con = _ddb.connect(database=":memory:")
        pq_path = str(base_parquet).replace("\\", "/")

        # ── Build presentation SQL ────────────────────────────────────
        _q = lambda c: '"' + str(c).replace('"', '""') + '"' if c != "*" else c
        select_parts: list[str] = []
        group_cols: list[str] = []

        aggs = query_config.get("aggregations") or []
        columns = query_config.get("columns") or []
        group_by = query_config.get("group_by") or []
        order_by = query_config.get("order_by") or []
        limit = query_config.get("limit")
        offset = query_config.get("offset", 0)
        distinct = query_config.get("distinct", False)
        computed = query_config.get("computed_columns") or []
        case_exprs = query_config.get("case_expressions") or []
        window_fns = query_config.get("window_functions") or []
        col_aliases = query_config.get("column_aliases") or {}

        if aggs:
            for col in group_by:
                group_cols.append(_q(col))
                select_parts.append(_q(col))
            for agg in aggs:
                fn = agg["function"].upper()
                acol = _q(agg["column"])
                alias = agg.get("alias", f"{fn}_{agg['column']}")
                select_parts.append(f'{fn}({acol}) AS "{alias}"')
        elif columns:
            for col in columns:
                alias = col_aliases.get(col)
                if alias:
                    select_parts.append(f'{_q(col)} AS "{alias}"')
                else:
                    select_parts.append(_q(col))
        else:
            select_parts.append("*")

        for cc in computed:
            expr = cc.get("expression", "")
            alias = cc.get("alias", "computed")
            # Block dangerous SQL patterns in computed expressions
            _expr_upper = expr.upper().replace(" ", "")
            _blocked = ("DROP", "TRUNCATE", "ALTER", "DELETE", "INSERT",
                        "UPDATE", "CREATE", "COPY", "ATTACH", "DETACH",
                        "EXECUTE", "CALL", "PRAGMA", "EXPORT", "IMPORT",
                        "LOAD", "INSTALL")
            _safe = True
            for _bk in _blocked:
                if _bk in _expr_upper:
                    logger.warning("Blocked dangerous computed expression: %s", expr[:100])
                    _safe = False
                    break
            if _safe and expr.strip():
                select_parts.append(f'({expr}) AS {_q(alias)}')

        for ce in case_exprs:
            alias = ce.get("alias", "case_result")
            whens = ce.get("when_clauses") or []
            parts = ["CASE"]
            for w in whens:
                parts.append(f"WHEN {w.get('condition','')} THEN {w.get('result','NULL')}")
            else_val = ce.get("else_result")
            if else_val is not None:
                parts.append(f"ELSE {else_val}")
            parts.append("END")
            select_parts.append(f'{" ".join(parts)} AS "{alias}"')

        for wf in window_fns:
            fn = wf.get("function", "ROW_NUMBER")
            wcol = wf.get("column", "")
            partition = wf.get("partition_by") or []
            worder = wf.get("order_by") or []
            alias = wf.get("alias", f"win_{fn}")
            fn_arg = f"({_q(wcol)})" if wcol else "()"
            over_parts = []
            if partition:
                over_parts.append("PARTITION BY " + ", ".join(_q(c) for c in partition))
            if worder:
                over_parts.append("ORDER BY " + ", ".join(
                    f'{_q(o["column"])} {o.get("direction","ASC").upper()}'
                    if isinstance(o, dict) else _q(o)
                    for o in worder
                ))
            select_parts.append(f'{fn}{fn_arg} OVER ({" ".join(over_parts)}) AS "{alias}"')

        distinct_kw = "DISTINCT " if distinct else ""
        sql = f"SELECT {distinct_kw}{', '.join(select_parts)}\nFROM read_parquet('{pq_path}')"

        if group_cols:
            sql += f"\nGROUP BY {', '.join(group_cols)}"

        # HAVING — sanitize operator and quote column to prevent injection
        _HAVING_OPS = {">", "<", ">=", "<=", "=", "!=", "<>"}
        having = query_config.get("having") or []
        if having:
            hparts = []
            for h in having:
                hcol = h.get("column", "")
                hop = h.get("operator", ">")
                hval = h.get("value", 0)
                # Validate operator against allowlist
                if hop not in _HAVING_OPS:
                    hop = ">"
                # Sanitize value — must be numeric
                try:
                    hval = float(hval)
                except (TypeError, ValueError):
                    hval = 0
                hparts.append(f"{_q(hcol)} {hop} {hval}")
            sql += f"\nHAVING {' AND '.join(hparts)}"

        if order_by:
            oparts = []
            for o in order_by:
                ocol = o["column"] if isinstance(o, dict) else o
                odir = o.get("direction", "ASC").upper() if isinstance(o, dict) else "ASC"
                oparts.append(f'{_q(ocol)} {odir}')
            sql += f"\nORDER BY {', '.join(oparts)}"

        if limit:
            sql += f"\nLIMIT {limit}"
            if offset:
                sql += f" OFFSET {offset}"

        # ── Execute and write result ─────────────────────────────────
        out_str = str(output_path).replace("\\", "/")
        copy_sql = f"COPY ({sql}) TO '{out_str}' (FORMAT PARQUET, COMPRESSION ZSTD)"
        con.execute(copy_sql)

        if not output_path.exists():
            return None
        file_size = output_path.stat().st_size
        # Read row count from the parquet metadata
        total_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet('{out_str}')"
        ).fetchone()[0]

        logger.info("[base_data_reuse] Local query OK: %d rows, %.1f MB from %s",
                     total_rows, file_size / 1024 / 1024, base_parquet.name)
        return {"total_rows": total_rows, "file_size_bytes": file_size}
    except Exception as exc:
        logger.debug("[base_data_reuse] Local query failed (will fall through to S3): %s", exc)
        # Clean up partial output
        try:
            output_path.unlink(missing_ok=True)
        except OSError:
            pass
        return None
    finally:
        if con:
            try:
                con.close()
            except Exception:
                pass


async def _run_query_and_signal(execution_id: str, query_config, query_id,
                                 active_engine, executed_by: str, raw_sql,
                                 cache_strategy: str, cache_key: Optional[str],
                                 query_config_dict: Optional[dict] = None) -> None:
    """Wrapper around execute_query_background that signals _inflight_queries on completion."""
    try:
        await execute_query_background(
            execution_id, query_config, query_id, active_engine,
            executed_by=executed_by, raw_sql=raw_sql, cache_strategy=cache_strategy,
            cache_key=cache_key, query_config_dict=query_config_dict,
        )
    finally:
        # Clear checkpoint — execution finished regardless of outcome (Phase 41)
        from core.checkpoint import mark_completed as _cp_done
        _cp_done(execution_id)
        if cache_key and cache_key in _inflight_queries:
            _, event = _inflight_queries.pop(cache_key, (None, None))
            if event:
                event.set()


async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest",
                                  raw_sql: Optional[str] = None,
                                  cache_strategy: str = "auto",
                                  cache_key: Optional[str] = None,
                                  query_config_dict: Optional[dict] = None):
    """Background task for query execution"""
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()
    run_engine = active_engine or engine

    try:

        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                db_manager.update_execution(
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            if is_terminal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0

            # Registered table path: resolve __registered__: → DuckDB views
            def _any_virtual(flist):
                return any(
                    (f if isinstance(f, str) else f.path).startswith(("__registered__:", "__materialized__:", "__local__:"))
                    for f in (flist or [])
                )
            _join_right = [j.right_file for j in (query_config.joins or [])] if query_config.joins else []
            _has_reg = _any_virtual(query_config.files) or _any_virtual(_join_right)

            # ── COPY TO fast path — bypass Python/pandas entirely ──────────
            # DuckDB streams from S3 directly to local Parquet (3-10x faster).
            # Skip for UNC paths (DuckDB can't handle \\server\share\...).
            if _has_reg and not str(output_file).startswith("\\\\"):
                try:
                    stats = _execute_registered_table_copy_to(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        str(output_file),
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        cancel_event=cancel_event,
                    )
                    _sync_progress({"status": "completed",
                                    "total_rows": stats["total_rows"],
                                    "file_size_bytes": stats["file_size_bytes"]})
                    return stats
                except Exception as _copy_err:
                    # Don't fall back to in-process DuckDB — same crash risk.
                    # Let the error propagate so the execution fails cleanly.
                    raise RuntimeError(f"S3 query failed: {_copy_err}") from _copy_err

            # ── Streaming path (fallback for registered tables, default for others)
            pq_writer = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                if _has_reg:
                    _query_gen = _execute_registered_table_query(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                    )
                elif raw_sql:
                    if run_engine._s3_conn_config:
                        # ── Raw SQL + S3: subprocess-isolated COPY TO ──
                        fh.close()  # close file handle — subprocess writes directly
                        _setup_stmts = []
                        if run_engine._registered_tables:
                            _esc = lambda v: v.replace("'", "''")
                            _rt_bucket = run_engine._s3_bucket
                            for _rt in run_engine._registered_tables:
                                _rt_name = _rt["name"].replace('"', '""')
                                _rt_fmt = _rt.get("format", "parquet")
                                _rt_prefix = _rt["s3_prefix"].rstrip("/")
                                if _rt_fmt == "iceberg":
                                    try:
                                        from core.iceberg_reader import get_iceberg_data_files
                                        _rt_s3 = _make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                        _rt_files = get_iceberg_data_files(_rt_s3, _rt_bucket, _rt["s3_prefix"], keys_only=True)
                                        if _rt_files:
                                            _rt_paths = ", ".join(f"'s3://{_esc(_rt_bucket)}/{_esc(f['key'])}'" for f in _rt_files)
                                            _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet([{_rt_paths}], hive_partitioning=true, union_by_name=true)')
                                    except Exception as _rte:
                                        logger.warning("Could not register Iceberg view '%s' for raw SQL: %s", _rt_name, _rte, exc_info=True)
                                elif _rt_fmt == "parquet":
                                    _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true)')
                                elif _rt_fmt == "csv":
                                    _setup_stmts.append(f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.csv\')')
                        # ── Two-phase: preview + full download ──
                        _tp_result = _s3_full_copy(
                            inner_sql=raw_sql,
                            output_path=str(output_file),
                            conn_config=run_engine._s3_conn_config,
                            registered_tables=run_engine._registered_tables or [],
                            bucket=run_engine._s3_bucket or "",
                            setup_sql=";\n".join(_setup_stmts),
                            connection_id=getattr(run_engine, '_s3_conn_id', None),
                            progress_fn=_sync_progress,
                            timeout=600,
                        )
                        total_rows = _tp_result["total_rows"]
                        file_size = _tp_result["file_size_bytes"]
                        _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                        return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                    else:
                        _query_gen = run_engine.execute_raw_duckdb_sql(raw_sql)
                elif run_engine._s3_conn_config:
                    # ── S3 non-registered files: two-phase (preview + full) ──
                    fh.close()  # close file handle — subprocess writes directly
                    _s3_sql = run_engine.get_duckdb_sql(query_config)
                    _tp_result = _s3_full_copy(
                        inner_sql=_s3_sql,
                        output_path=str(output_file),
                        conn_config=run_engine._s3_conn_config,
                        registered_tables=[],
                        bucket=getattr(run_engine, '_s3_bucket', "") or "",
                        setup_sql="",
                        connection_id=getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        timeout=600,
                    )
                    total_rows = _tp_result["total_rows"]
                    file_size = _tp_result["file_size_bytes"]
                    _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                    return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                elif run_engine._needs_duckdb(query_config):
                    _query_gen = run_engine.execute_duckdb_query(query_config)
                else:
                    _query_gen = run_engine.execute_query(query_config)
                # Detect wide-table auto-projection: when engine projected a
                # subset of columns, store the full list so the grid can offer
                # "Showing 50 of 937 columns — choose columns" UX.
                _all_source_cols = None
                if (not query_config.columns
                        and not query_config.aggregations
                        and query_config.files):
                    try:
                        _first = query_config.files[0]
                        _fp = _first if isinstance(_first, str) else _first.path
                        if not _fp.startswith("__registered__:") and hasattr(run_engine, 'get_file_schema'):
                            _sch = run_engine.get_file_schema(_fp)
                            _src_cols = [c["name"] for c in _sch.get("columns", [])]
                            if len(_src_cols) > 50:
                                _all_source_cols = _src_cols
                    except Exception as exc:
                        logger.warning("Recoverable error: %s", exc, exc_info=True)

                for chunk in _query_gen:
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    # Accept both pa.Table (from DuckDB streaming) and pd.DataFrame
                    if isinstance(chunk, _pa.Table):
                        table = chunk
                    else:
                        table = _pa.Table.from_pandas(chunk, preserve_index=False)
                    if pq_writer is None:
                        _sync_progress({"status": "processing", "log": f"Writing results ({len(table)} rows)..."})
                        # Embed all_columns metadata in Parquet file so the
                        # paginator can return it without extra lookups.
                        _pq_meta = table.schema.metadata or {}
                        if _all_source_cols is not None:
                            _pq_meta[b"all_columns"] = json.dumps(_all_source_cols).encode()
                        # Embed auto-partition info so frontend can show indicator
                        _auto_part = getattr(query_config, '_auto_partition', None)
                        if _auto_part:
                            _pq_meta[b"auto_partition"] = json.dumps(_auto_part).encode()
                        # Use replace_schema_metadata on the table itself so
                        # writer schema and table schema are identical.
                        table = table.replace_schema_metadata(_pq_meta)
                        _writer_schema = table.schema
                        pq_writer = _pq.ParquetWriter(fh, _writer_schema, compression="zstd")
                    else:
                        # Subsequent chunks may have a different schema (e.g.
                        # multi-file streaming with schema evolution).  Cast
                        # to the writer's schema so the write doesn't fail.
                        if table.schema != _writer_schema:
                            try:
                                table = table.cast(_writer_schema)
                            except Exception:
                                # If cast fails, unify: add missing cols as null,
                                # drop extra cols, reorder to match writer.
                                for field in _writer_schema:
                                    if field.name not in table.column_names:
                                        table = table.append_column(
                                            field, _pa.nulls(len(table), type=field.type))
                                table = table.select([f.name for f in _writer_schema])
                    pq_writer.write_table(table)
                    total_rows += len(table)
                    chunks_processed += 1
            finally:
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # Ensure an empty file exists for 0-row results so downstream
                # readers don't get a FileNotFoundError.
                if total_rows == 0 and not output_file.exists():
                    output_file.touch()
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_to_parquet,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({
                "type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        
        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, s3_config)
            if _s3_info:
                db_manager.update_execution(execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc)

        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        # TTL = 7 days so results persist for the full download-file lifetime.
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key, store_result, make_base_data_key
                _qc_dict = query_config_dict or (query_config.__dict__ if hasattr(query_config, '__dict__') else {})
                _ck = cache_key or make_cache_key(_qc_dict)
                if output_file.exists():
                    store_result(_ck, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                 ttl_seconds=7 * 24 * 3600)
                    # Also store a base-data cache entry so future queries with
                    # different SELECT/aggregations on the same FROM/WHERE/JOIN
                    # can reuse this downloaded parquet instead of re-fetching S3.
                    try:
                        _bk = make_base_data_key(_qc_dict)
                        store_result(_bk, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                     ttl_seconds=7 * 24 * 3600)
                    except Exception:
                        pass  # non-critical
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        _log_ws_notification(
            "execution_completed", executed_by or "guest",
            "Query Completed",
            f"{stats.get('total_rows', 0):,} rows",
            execution_id=execution_id,
        )

        logger.info(f"Query execution completed: {execution_id}")
        
    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        logger.error(f"Error executing query {execution_id}: {e}", exc_info=True)

        _err_code = "TOKEN_EXPIRED" if isinstance(e, TokenExpiredError) else None
        db_manager.update_execution(
            execution_id,
            status="failed",
            error_message=str(e)
        )
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass

        ws_msg = {
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if _err_code:
            ws_msg["error_code"] = _err_code
        await ws_manager.broadcast(ws_msg)
        _log_ws_notification(
            "execution_failed", executed_by or "guest",
            "Query Failed",
            str(e)[:300],
            execution_id=execution_id,
        )

    finally:
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_sql_connector_background(
    execution_id: str,
    connector,          # SqlConnector instance (already constructed)
    sql: str,           # complete SQL built by engine.build_query_sql()
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
):
    """Execute a query against a SQL connector (Trino/Starburst/Snowflake/Databricks/Oracle).
    Mirrors the structure of execute_query_background so the frontend receives
    the same WebSocket messages and can download results the same way.
    """
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        def _exec_sql(cancel_event=None):
            try:
                logger.info(f"SQL connector query [{execution_id}]:\n{sql}")
                result = connector.execute_query(sql)
                # result = {"columns": [{"name":..,"type":..}], "rows": [...], "total_rows": int}
                rows    = result.get("rows", [])
                col_defs = result.get("columns", [])
                col_names = [c["name"] for c in col_defs]
                df = _pd.DataFrame(rows, columns=col_names) if rows else _pd.DataFrame(columns=col_names)
                total_rows = len(df)
                output_file.parent.mkdir(parents=True, exist_ok=True)
                if total_rows > 0:
                    table = _pa.Table.from_pandas(df, preserve_index=False)
                    with open(str(output_file), "wb") as fh:
                        _pq.ParquetWriter(fh, table.schema, compression="zstd").write_table(table)
                else:
                    output_file.touch()
                file_size = output_file.stat().st_size
                return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
            finally:
                try:
                    connector.close()
                except Exception as exc:
                    logger.warning("Recoverable error: %s", exc, exc_info=True)

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_sql,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )
        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, s3_config)
            if _s3_info:
                db_manager.update_execution(execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc)

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key as _mk_ck, store_result as _store_res
                _ck = cache_key or _mk_ck(query_config_dict or {})
                if _ck and output_file.exists():
                    _store_res(_ck, output_file, query_config_dict or {},
                               row_count=stats.get("total_rows", 0), copy=False,
                               ttl_seconds=7 * 24 * 3600)
            except Exception as exc:
                logger.warning("Recoverable error caching SQL connector result: %s", exc, exc_info=True)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"SQL connector query completed: {execution_id} ({stats.get('total_rows',0)} rows)")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"SQL connector query cancelled: {execution_id}")
        current_exec = db_manager.get_execution(execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled", error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({"type": "execution_cancelled", "execution_id": execution_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat()})
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"SQL connector query failed {execution_id}: {e}", exc_info=True)
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                                    "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()})
    finally:
        # Clear checkpoint — execution finished (Phase 41)
        from core.checkpoint import mark_completed as _cp_done_sql
        _cp_done_sql(execution_id)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


async def execute_cross_query_background(
    execution_id: str,
    primary_engine,
    primary_config: QueryConfig,
    secondary_engine,
    secondary_config: QueryConfig,
    combine_mode: str,
    join_config: Optional[dict],
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
):
    """Background task for cross-connection (multi-source) query execution."""
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    from core.checkpoint import mark_started as _cp_started
    _cp_started(execution_id)
    _pool = get_pool()

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        async def _progress(data):
            await ws_manager.broadcast({
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            if data.get("status") in ("completed", "failed"):
                db_manager.update_execution(
                    execution_id,
                    status=data["status"],
                    total_rows=data.get("total_rows", 0),
                    chunks_processed=data.get("chunks_processed", 0),
                    output_file=str(output_file) if data.get("status") == "completed" else None,
                    file_size_bytes=data.get("file_size_bytes", 0),
                    error_message=data.get("error"),
                )

        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            if data.get("status") in ("completed", "failed") or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(_progress(data), loop)

        import pyarrow as _pa
        import pyarrow.parquet as _pq

        def _exec_cross(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)

            # ── Primary source ────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "primary",
                            "message": "Executing primary source query"})
            chunks_a = []
            for chunk in primary_engine.execute_query(primary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_a.append(chunk)
            df_a = _pd.concat(chunks_a, ignore_index=True) if chunks_a else _pd.DataFrame()

            # ── Secondary source ──────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "secondary",
                            "message": "Executing secondary source query"})
            chunks_b = []
            for chunk in secondary_engine.execute_query(secondary_config):
                if cancel_event.is_set():
                    raise InterruptedError("Execution cancelled by user")
                chunks_b.append(chunk)
            df_b = _pd.concat(chunks_b, ignore_index=True) if chunks_b else _pd.DataFrame()

            # ── Combine ───────────────────────────────────────────────────────
            _sync_progress({"status": "processing", "step": "combining",
                            "message": f"Combining via {combine_mode.upper()}"})
            if combine_mode == "union":
                df_result = _pd.concat([df_a, df_b], ignore_index=True, sort=False)
            elif combine_mode == "join":
                if not join_config:
                    raise ValueError("join_config required for join mode")
                how = join_config.get("how", "inner")
                left_on = join_config.get("left_on")
                right_on = join_config.get("right_on")
                suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
                if isinstance(left_on, str): left_on = [left_on]
                if isinstance(right_on, str): right_on = [right_on]
                if not left_on or not right_on:
                    raise ValueError("join_config must specify left_on and right_on")
                df_result = _pd.merge(df_a, df_b, how=how,
                                      left_on=left_on, right_on=right_on,
                                      suffixes=suffixes)
            else:
                raise ValueError(f"Unknown combine_mode '{combine_mode}'")

            # ── Save parquet ──────────────────────────────────────────────────
            fh = open(str(output_file), "wb")
            try:
                table = _pa.Table.from_pandas(df_result, preserve_index=False)
                writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                writer.write_table(table)
                writer.close()
            finally:
                fh.close()
            if df_result.empty and not output_file.exists():
                output_file.touch()

            total_rows = len(df_result)
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows,
                            "file_size_bytes": file_size, "chunks_processed": 2})
            return {"total_rows": total_rows, "chunks_processed": 2,
                    "file_size_bytes": file_size, "status": "completed"}

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_cross,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            db_manager.update_execution(execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await ws_manager.broadcast({"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        db_manager.update_execution(execution_id, status="processing")
        await ws_manager.broadcast({
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        stats = await asyncio.wrap_future(_wp_record.future)

        db_manager.update_execution(
            execution_id,
            status="completed",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        file_id = str(uuid.uuid4())
        db_manager.create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=f"cross_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
        )
        if query_id:
            db_manager.increment_execution_count(query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key as _mk_ck_x, store_result as _store_res_x
                _ck_x = cache_key or _mk_ck_x(query_config_dict or {})
                if _ck_x and output_file.exists():
                    _store_res_x(_ck_x, output_file, query_config_dict or {},
                                 row_count=stats.get("total_rows", 0), copy=False,
                                 ttl_seconds=7 * 24 * 3600)
            except Exception as exc:
                logger.warning("Recoverable error caching cross-query result: %s", exc, exc_info=True)

        await ws_manager.broadcast({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "combine_mode": combine_mode,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        logger.info(f"Cross-connection query completed: {execution_id} ({combine_mode})")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"Cross-connection query cancelled: {execution_id}")
        cur = db_manager.get_execution(execution_id)
        if cur and cur.get("status") not in ("cancelled",):
            db_manager.update_execution(execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        logger.error(f"Error in cross-connection query {execution_id}: {e}", exc_info=True)
        db_manager.update_execution(execution_id, status="failed", error_message=str(e))
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await ws_manager.broadcast({
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    finally:
        # Clear checkpoint — execution finished (Phase 41)
        from core.checkpoint import mark_completed as _cp_done_cross
        _cp_done_cross(execution_id)
        with _user_query_lock:
            _user_query_counts[executed_by] = max(0, _user_query_counts.get(executed_by, 0) - 1)


# ── Audit helper ──────────────────────────────────────────────────────────────

def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        db_manager.audit(username, action, resource_type=resource_type,
                         resource_id=resource_id, ip_address=ip,
                         user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


# ── SPA static file serving ───────────────────────────────────────────────────
_STATIC_CANDIDATES = [
    Path(__file__).resolve().parent / "static",          # Docker / production
    Path(__file__).resolve().parent.parent / "frontend" / "build",  # local dev
    Path(__file__).resolve().parent.parent / "frontend" / "dist",   # legacy Vite
]
_STATIC_DIR: Optional[Path] = next((p for p in _STATIC_CANDIDATES if p.is_dir()), None)

if _STATIC_DIR:
    from fastapi.staticfiles import StaticFiles
    # Mount /assets (hashed JS/CSS bundles) — short cache for CDN
    _assets = _STATIC_DIR / "assets"
    if _assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")
    logger.info("Serving built frontend from %s", _STATIC_DIR)
else:
    logger.info("No built frontend found — API-only mode")


def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest: oldest = mt
                    if newest is None or mt > newest: newest = mt
                except OSError as exc:
                    logger.debug("Recoverable error: %s", exc, exc_info=True)
    return {
        "path": str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb": round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent: Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue: Optional[int] = None
    report_max_concurrent: Optional[int] = None
    report_default_timeout: Optional[int] = None
    report_max_queue: Optional[int] = None
    scheduled_max_concurrent: Optional[int] = None
    scheduled_default_timeout: Optional[int] = None
    scheduled_max_queue: Optional[int] = None
    export_max_concurrent: Optional[int] = None
    export_default_timeout: Optional[int] = None
    export_max_queue: Optional[int] = None
    system_max_concurrent: Optional[int] = None
    system_default_timeout: Optional[int] = None
    system_max_queue: Optional[int] = None


class AppConfigUpdateRequest(BaseModel):
    limits: Optional[dict] = None
    features: Optional[dict] = None


class QueueConfigUpdateRequest(BaseModel):
    backend: Optional[str] = None
    redis_url: Optional[str] = None
    redis_password: Optional[str] = None
    redis_db: Optional[int] = None
    redis_ssl: Optional[bool] = None
    key_prefix: Optional[str] = None
    task_ttl_hours: Optional[int] = None


def _oldest_age_secs(tasks: list) -> float:
    """Return age in seconds of oldest task by created_at."""
    from datetime import datetime, timezone
    oldest = None
    for t in tasks:
        ca = t.get("created_at")
        if not ca:
            continue
        try:
            dt = datetime.fromisoformat(ca)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if oldest is None or dt < oldest:
                oldest = dt
        except Exception:
            pass
    if oldest is None:
        return 0.0
    now = datetime.now(timezone.utc)
    return (now - oldest).total_seconds()



# ── Batch Submit API (19H) ────────────────────────────────────────────────────

class BatchQueryItem(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    callback_url: Optional[str] = None
    priority: int = Field(default=5, ge=0, le=9)
    label: Optional[str] = None   # caller-defined label for tracking

class BatchSubmitRequest(BaseModel):
    queries: List[BatchQueryItem] = Field(..., min_length=1, max_length=50)

async def _scheduler_worker_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Proxy a request to the scheduler worker's internal HTTP API.

    Used when ``scheduler.mode = "external"`` — the scheduler runs in a
    separate process (``scheduler_worker.py``) and exposes a small FastAPI
    control API on ``scheduler.worker_host:scheduler.worker_port``.
    """
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")

_MAX_UPLOAD_SIZE = _limits_cfg.max_upload_size_bytes  # configurable via admin
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}


def _conn_upload_dir(connection_id: int) -> Path:
    """Get the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"

def _rewrite_registered_refs(sql: str, registered_tables: list) -> str:
    """Replace read_parquet('base/__registered__:name') with view name "name".

    ParquetQueryEngine.get_duckdb_sql() resolves registered tables to local
    paths like read_parquet('.../data/parquet/__registered__:fact_table').
    For S3 streaming we need the SQL to reference the DuckDB views created by
    _register_s3_views() instead.

    Also rewrites __materialized__:name references to the corresponding
    materialized view DuckDB views.
    """
    import re
    for tbl in (registered_tables or []):
        tname = tbl["name"]
        esc = re.escape(tname)
        tname_safe = '"' + tname.replace('"', '""') + '"'
        # Match read_parquet/read_csv_auto containing __registered__:name
        # Support both single-quoted and double-quoted paths
        for reader in ("read_parquet", "read_csv_auto"):
            sql = re.sub(
                rf"{reader}\('[^']*__registered__:{esc}'\)",
                tname_safe, sql,
            )
            sql = re.sub(
                rf'{reader}\("[^"]*__registered__:{esc}"\)',
                tname_safe, sql,
            )
    # Rewrite __materialized__:name references
    mv_pattern = re.compile(r"""(?:read_parquet|read_csv_auto)\(['"][^'"]*__materialized__:([^'"]+)['"]\)""")
    for match in mv_pattern.finditer(sql):
        mv_name = match.group(1)
        mv_view = '"__mv__' + mv_name.replace('"', '""') + '"'
        sql = sql.replace(match.group(0), mv_view)
    # Rewrite __local__:name references
    lt_pattern = re.compile(r"""(?:read_parquet|read_csv_auto)\(['"][^'"]*__local__:([^'"]+)['"]\)""")
    for match in lt_pattern.finditer(sql):
        lt_name = match.group(1)
        lt_view = '"__lt__' + lt_name.replace('"', '""') + '"'
        sql = sql.replace(match.group(0), lt_view)
    return sql


def _filter_iceberg_files_by_partitions(data_files, partition_filters):
    """Filter Iceberg data files by partition values found in S3 key paths.

    Each file key has hive-style paths like .../year=2024/month=01/file.parquet.
    Matches query filters against those partition segments.
    """
    if not partition_filters or not data_files:
        return data_files
    filtered = []
    for f in data_files:
        key = f["key"] if isinstance(f, dict) else f
        # Parse hive-style partition segments from path
        parts = {}
        for seg in key.split("/"):
            if "=" in seg:
                k, v = seg.split("=", 1)
                parts[k] = v
        match = True
        for pf in partition_filters:
            col = pf["col"]
            if col not in parts:
                continue  # not a partition column — skip (non-partition filters handled by SQL)
            fv = parts[col]
            op = pf["op"]
            val = pf["val"]
            if op == "equals" and str(fv) != str(val):
                match = False; break
            elif op == "not_equals" and str(fv) == str(val):
                match = False; break
            elif op == "in" and str(fv) not in [str(v) for v in val]:
                match = False; break
            elif op == "greater_than" and not (str(fv) > str(val)):
                match = False; break
            elif op == "less_than" and not (str(fv) < str(val)):
                match = False; break
            elif op == "greater_equals" and not (str(fv) >= str(val)):
                match = False; break
            elif op == "less_equals" and not (str(fv) <= str(val)):
                match = False; break
        if match:
            filtered.append(f)
    return filtered if filtered else data_files  # fallback to all if nothing matched


def _extract_partition_filters_from_query(query_config):
    """Extract partition filter dicts from a query config's filters list."""
    if not query_config or not hasattr(query_config, "filters") or not query_config.filters:
        return None
    _OP_MAP = {
        "equals": "equals", "eq": "equals", "=": "equals",
        "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
        "greater_than": "greater_than", "gt": "greater_than", ">": "greater_than",
        "less_than": "less_than", "lt": "less_than", "<": "less_than",
        "greater_equals": "greater_equals", "gte": "greater_equals", ">=": "greater_equals",
        "less_equals": "less_equals", "lte": "less_equals", "<=": "less_equals",
    }
    pf = []
    for flt in query_config.filters:
        f_op = flt["operator"] if isinstance(flt, dict) else flt.operator
        f_col = flt["column"] if isinstance(flt, dict) else flt.column
        f_val = flt["value"] if isinstance(flt, dict) else flt.value
        if f_op == "in" and isinstance(f_val, list) and len(f_val) > 0:
            pf.append({"col": f_col, "op": "in", "val": f_val})
        else:
            mapped = _OP_MAP.get(f_op)
            if mapped and f_val is not None:
                pf.append({"col": f_col, "op": mapped, "val": f_val})
    return pf or None


def _register_s3_views(con, registered_tables, bucket, connection_id, cfg,
                       referenced_tables=None, partition_filters=None):
    """Register S3 views in a DuckDB connection for registered tables.

    When `referenced_tables` is provided (set of table names), only those tables
    are registered — avoids scanning manifests for unreferenced Iceberg tables.
    Uses the L1/L2 Iceberg manifest cache to avoid redundant S3 reads.

    partition_filters: list of {col, op, val} dicts to prune Iceberg files
                       by partition values in S3 key paths.

    Returns: total record count from Iceberg manifests (0 if unavailable).
    """
    import time as _rv_t
    _esc = lambda v: v.replace("'", "''")
    _total_records = 0
    for tbl in (registered_tables or []):
        tname = tbl["name"]
        # Skip tables not referenced in the current query
        if referenced_tables and tname not in referenced_tables:
            continue
        tname_esc = tname.replace('"', '""')
        fmt = tbl.get("format", "parquet")
        prefix = tbl["s3_prefix"].rstrip("/")
        _rv0 = _rv_t.monotonic()
        if fmt == "iceberg":
            try:
                # Use L1/L2 manifest cache (same as _setup_registered_views)
                cache_key = _ice_cache_key(connection_id, tname, None)
                cached = _ice_cache_get(cache_key)
                if cached:
                    data_files = cached["files"]
                    _total_records += cached.get("record_count", 0)
                else:
                    from core.iceberg_reader import get_iceberg_data_files
                    s3_client = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                    data_files = get_iceberg_data_files(s3_client, bucket, tbl["s3_prefix"], keys_only=True)
                    _rc = sum(f.get("record_count", 0) for f in data_files if isinstance(f, dict))
                    _ice_cache_set(cache_key, data_files, None, record_count=_rc)
                    _total_records += _rc
                if data_files:
                    total_all = len(data_files)
                    # Prune files by partition filters (matches hive-style paths)
                    if partition_filters:
                        data_files = _filter_iceberg_files_by_partitions(data_files, partition_filters)
                    # Safety cap: if still too many files (no partition filter or wide filter),
                    # use last N to avoid DuckDB reading thousands of Parquet footers over S3.
                    _MAX_STREAM_FILES = _limits_cfg.max_stream_files
                    if len(data_files) > _MAX_STREAM_FILES:
                        logger.info("STREAM-DIAG: '%s' still has %d files after filter, capping to %d",
                                    tname, len(data_files), _MAX_STREAM_FILES)
                        data_files = data_files[-_MAX_STREAM_FILES:]
                    paths = ", ".join(f"'s3://{_esc(bucket)}/{_esc(f['key'])}'" for f in data_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet([{paths}], hive_partitioning=true)')
                    logger.info("STREAM-DIAG: Iceberg view '%s': %d/%d files after partition filter (%.2fs)",
                                tname, len(data_files), total_all, _rv_t.monotonic() - _rv0)
            except Exception as e:
                logger.warning("Stream: could not register Iceberg view '%s': %s", tname, e)
        elif fmt == "parquet":
            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.parquet\', hive_partitioning=true)')
        elif fmt == "csv":
            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.csv\')')

    # Register materialized views as local parquet VIEWs
    try:
        mv_list = db_manager.list_materialized_views(connection_id=connection_id)
        for mv in mv_list:
            if mv["status"] != "ready" or not mv.get("is_active", True):
                continue
            mv_name = mv["name"]
            if referenced_tables and mv_name not in referenced_tables:
                continue
            mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv["id"]))
            import glob as _glob_mod
            pq_files = _glob_mod.glob(os.path.join(mv_dir, "*.parquet"))
            if pq_files:
                paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                vname = "__mv__" + mv_name.replace('"', '""')
                con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                logger.info("Registered materialized view '%s' with %d local files", mv_name, len(pq_files))
    except Exception as e:
        logger.warning("Could not register materialized views: %s", e)

    # Register local tables as local parquet VIEWs
    try:
        import glob as _glob_mod2
        lt_list = db_manager.list_local_tables()
        for lt in lt_list:
            if lt["status"] != "ready" or not lt.get("is_active", True):
                continue
            lt_name = lt["name"]
            if referenced_tables and lt_name not in referenced_tables and f"__lt__{lt_name}" not in referenced_tables:
                continue
            lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt["id"]))
            pq_files = _glob_mod2.glob(os.path.join(lt_dir, "*.parquet"))
            if pq_files:
                paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
                vname = "__lt__" + lt_name.replace('"', '""')
                con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                logger.info("Registered local table '%s' with %d local files", lt_name, len(pq_files))
                # Touch last_accessed_at
                try:
                    db_manager.touch_local_table(lt["id"])
                except Exception:
                    pass
    except Exception as e:
        logger.warning("Could not register local tables: %s", e)

    return _total_records


def _jsonify_value(v):
    """Convert a single value to a JSON-safe type."""
    import decimal
    from datetime import datetime, date as _date_type
    if v is None:
        return None
    if isinstance(v, (datetime, _date_type)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (list, tuple)):
        return [_jsonify_value(x) for x in v]
    return v


def _jsonify_rows(rows: list):
    """In-place convert non-JSON-safe values in a list of dicts."""
    for row in rows:
        for k, v in row.items():
            row[k] = _jsonify_value(v)


# ─────────────────────────────────────────────────────────────────────────────
# S3 streaming helpers
# ─────────────────────────────────────────────────────────────────────────────

_S3_EXPIRED_PATTERNS = ('expiredtoken', 'expired token', 'requestexpired', 'token has expired',
                        'security token included in the request is expired',
                        'the provided token has expired')

def _is_s3_auth_error(exc: Exception) -> bool:
    """Detect expired / invalid AWS credentials from DuckDB httpfs or boto3 errors."""
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in _S3_EXPIRED_PATTERNS)

def _raise_if_s3_auth_error(exc: Exception):
    """Raise HTTP 401 with TOKEN_EXPIRED code if the exception is an AWS credential issue."""
    if _is_s3_auth_error(exc):
        raise HTTPException(
            status_code=401,
            detail={
                "message": "Your AWS session credentials have expired. Please update your connection with fresh credentials.",
                "error_code": "TOKEN_EXPIRED",
            },
        )

# POST /api/execute/stream  — DuckDB httpfs streaming (direct S3 query)
# ─────────────────────────────────────────────────────────────────────────────
class StreamQueryRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    limit: int = Field(default=500, ge=1, le=5000)

@app.post("/api/execute/stream")
async def stream_query(request: StreamQueryRequest, _user: dict = Depends(_get_current_user)):
    """Stream query results directly from S3 via DuckDB httpfs.

    Returns the first N rows (default 500) as JSON.  Ideal for:
      - Instant data preview while query processes in the background
      - Quick ad-hoc exploration of S3 tables
      - Validating query logic before committing to a full execution

    Works with both query_config (Query Builder) and raw_sql (SQL page).
    Only supports S3 / registered-table connections (local files already load fast).
    """
    import time as _t
    t0 = _t.monotonic()

    _effective_conn_id = request.connection_id
    if not _effective_conn_id and request.query_config:
        _effective_conn_id = request.query_config.connection_id
    if not _effective_conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required for streaming")

    conn = db_manager.get_connection_raw(_effective_conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn.get("connection_type")
    cfg = conn.get("config", {})
    if conn_type != "s3":
        raise HTTPException(status_code=400, detail="Streaming is only supported for S3 connections")

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        # ── Build inner SQL ──────────────────────────────────────────────
        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()

        if request.raw_sql:
            inner_sql = request.raw_sql
        elif request.query_config:
            engine_config = convert_query_config_to_engine(request.query_config)
            s3_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir),
                chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(cfg),
            )
            if registered_tables:
                s3_engine._registered_tables = registered_tables
                s3_engine._s3_conn_config = cfg
                s3_engine._s3_bucket = bucket
                s3_engine._s3_conn_id = _effective_conn_id
            inner_sql = s3_engine.get_duckdb_sql(engine_config)
            inner_sql = _rewrite_registered_refs(inner_sql, registered_tables)
        else:
            raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")

        # Strip any existing LIMIT and apply our streaming limit
        stripped_sql = _strip_sql_limit(inner_sql)
        stream_sql = f"SELECT * FROM ({stripped_sql}) _stream LIMIT {request.limit}"

        # ── Execute in DuckDB with httpfs ────────────────────────────────
        loop = asyncio.get_running_loop()

        def _run_stream():
            con = _duckdb_con_with_s3(cfg, connection_id=_effective_conn_id)
            try:
                # Only register tables actually referenced in the SQL
                _refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in stream_sql}
                _pf = _extract_partition_filters_from_query(request.query_config) if request.query_config else None
                _register_s3_views(con, registered_tables, bucket, _effective_conn_id, cfg, referenced_tables=_refs or None, partition_filters=_pf)
                result = con.execute(stream_sql)
                columns = [desc[0] for desc in result.description]
                rows = result.fetchall()
                return {"columns": columns, "rows": [list(r) for r in rows]}
            finally:
                con.close()

        try:
            data = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor(), _run_stream),
                timeout=600.0,  # 10 min — large S3 datasets need time
            )
        except asyncio.TimeoutError:
            logger.error("Stream query: timed out after 600s")
            raise HTTPException(status_code=504, detail="S3 streaming query timed out after 10 minutes")
        elapsed = _t.monotonic() - t0

        rows_safe = [[_jsonify_value(c) for c in row] for row in data["rows"]]

        logger.info("Stream query: rows=%d, cols=%d, elapsed=%.2fs",
                     len(rows_safe), len(data["columns"]), elapsed)
        return {
            "columns": data["columns"],
            "rows": rows_safe,
            "total_rows": len(rows_safe),
            "streaming": True,
            "limit": request.limit,
            "elapsed_seconds": round(elapsed, 2),
            "connection_id": _effective_conn_id,
        }
    except HTTPException:
        raise
    except Exception as e:
        _raise_if_s3_auth_error(e)
        logger.error("Stream query error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Streaming query failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/execute/stream/paginate — paginated S3 streaming via DuckDB httpfs
# ─────────────────────────────────────────────────────────────────────────────
class StreamPaginateRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=100, ge=1, le=5000)
    sort_column: Optional[str] = None
    sort_direction: str = Field(default="asc")
    adv_filters: Optional[str] = None
    columns: Optional[str] = None


# ── Streaming DuckDB connection helper ─────────────────────────────────────────
# Each page request gets its own short-lived DuckDB connection.
# Iceberg manifests are served from L1/L2 cache (_ice_cache_get) so view
# registration is cheap (no S3 reads after the first hit).
# This avoids thread-safety issues, lock contention, and connection eviction
# races that plagued the previous _STREAM_CON_CACHE approach.


# ── Lightweight column discovery for S3 streaming ────────────────────────────
class StreamSchemaRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    sample_rows: int = Field(default=100, ge=0, le=1000)


@app.post("/api/execute/stream/schema")
async def stream_schema(request: StreamSchemaRequest, _user: dict = Depends(_get_current_user)):
    """Lightweight column discovery for S3 streaming.

    Returns column names, types, and empty-column flags so the frontend
    can show a column selector before streaming starts.  Runs on the
    lightweight executor — never blocked by heavy background queries.
    """
    import time as _t
    t0 = _t.monotonic()

    # ── Resolve connection (same logic as stream_paginate) ─────────────
    _effective_conn_id = request.connection_id
    if not _effective_conn_id and request.query_config:
        _effective_conn_id = request.query_config.connection_id
    if not _effective_conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required")

    conn = db_manager.get_connection_raw(_effective_conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support streaming schema")
    cfg = conn.get("config", {})

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        # ── Build inner SQL ────────────────────────────────────────────
        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()

        if request.raw_sql:
            inner_sql = request.raw_sql
        elif request.query_config:
            engine_config = convert_query_config_to_engine(request.query_config)
            s3_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir),
                chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(cfg),
            )
            if registered_tables:
                s3_engine._registered_tables = registered_tables
                s3_engine._s3_conn_config = cfg
                s3_engine._s3_bucket = bucket
                s3_engine._s3_conn_id = _effective_conn_id
            inner_sql = s3_engine.get_duckdb_sql(engine_config)
            inner_sql = _rewrite_registered_refs(inner_sql, registered_tables)
        else:
            raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")

        stripped_sql = _strip_sql_limit(inner_sql)

        loop = asyncio.get_running_loop()
        _refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in stripped_sql}

        _pf_schema = _extract_partition_filters_from_query(request.query_config) if request.query_config else None
        def _run_schema():
            con = _duckdb_con_with_s3(cfg, connection_id=_effective_conn_id)
            try:
                _register_s3_views(con, registered_tables, bucket, _effective_conn_id, cfg,
                                   referenced_tables=_refs or None, partition_filters=_pf_schema)

                # Step 1: Schema via LIMIT 0 (reads parquet footer only — fast)
                schema_result = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                columns = [{"name": desc[0], "type": desc[1]} for desc in schema_result.description]

                # Step 2: Sample to detect empty columns
                empty_set = set()
                if request.sample_rows > 0 and len(columns) > 0:
                    try:
                        sample_sql = f"SELECT * FROM ({stripped_sql}) _sample LIMIT {request.sample_rows}"
                        sample_result = con.execute(sample_sql)
                        sample_rows = sample_result.fetchall()
                        if sample_rows:
                            col_names = [desc[0] for desc in sample_result.description]
                            for i, cname in enumerate(col_names):
                                if all(row[i] is None for row in sample_rows):
                                    empty_set.add(cname)
                    except Exception as e:
                        logger.warning("Stream schema: empty detection failed: %s", e)

                for col in columns:
                    col["empty"] = col["name"] in empty_set

                # Step 3: Estimate total rows (parquet metadata — usually fast)
                estimated_rows = -1
                try:
                    count_result = con.execute(f"SELECT COUNT(*) FROM ({stripped_sql}) _c")
                    estimated_rows = int(count_result.fetchone()[0])
                except Exception:
                    pass

                return {"columns": columns, "total_columns": len(columns), "estimated_rows": estimated_rows}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor(), _run_schema),
            timeout=60.0,
        )
        result["elapsed_seconds"] = round(_t.monotonic() - t0, 2)
        logger.info("Stream schema: %d columns, %d estimated rows, %.2fs",
                     result["total_columns"], result["estimated_rows"], result["elapsed_seconds"])
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Schema discovery timed out after 60 seconds")
    except HTTPException:
        raise
    except Exception as e:
        _raise_if_s3_auth_error(e)
        logger.error("Stream schema error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema discovery failed: {str(e)}")


@app.post("/api/execute/stream/paginate")
async def stream_paginate(request: StreamPaginateRequest, http_request: Request = None, _user: dict = Depends(_get_current_user)):
    """Paginated query results directly from S3 via DuckDB httpfs.

    Returns data in the same format as GET /api/executions/{id}/results
    so DataGridViewer can consume it identically.
    """
    import time as _t
    t0 = _t.monotonic()

    # ── Resolve connection ────────────────────────────────────────────────
    _effective_conn_id = request.connection_id
    if not _effective_conn_id and request.query_config:
        _effective_conn_id = request.query_config.connection_id
    if not _effective_conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required for streaming pagination")

    conn = db_manager.get_connection_raw(_effective_conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn.get("connection_type")
    cfg = conn.get("config", {})
    if conn_type != "s3":
        raise HTTPException(status_code=400, detail="Streaming pagination only supported for S3 connections")

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _build_where

        # ── Build inner SQL ───────────────────────────────────────────────
        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()

        if request.raw_sql:
            inner_sql = request.raw_sql
        elif request.query_config:
            engine_config = convert_query_config_to_engine(request.query_config)
            s3_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir),
                chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(cfg),
            )
            if registered_tables:
                s3_engine._registered_tables = registered_tables
                s3_engine._s3_conn_config = cfg
                s3_engine._s3_bucket = bucket
                s3_engine._s3_conn_id = _effective_conn_id
            inner_sql = s3_engine.get_duckdb_sql(engine_config)
            inner_sql = _rewrite_registered_refs(inner_sql, registered_tables)
            if engine_config.joins:
                logger.info("Stream paginate: JOIN query detected, tables=%d, sql_preview=%.200s",
                            1 + len(engine_config.joins), inner_sql)
        else:
            raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")

        stripped_sql = _strip_sql_limit(inner_sql)

        # ── Execute paginated query in thread pool ────────────────────────
        loop = asyncio.get_running_loop()

        # Extract table names referenced in the SQL for selective view registration
        _refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in stripped_sql}

        def _run_paginated():
            import time as _pt
            _p0 = _pt.monotonic()
            logger.info("STREAM-DIAG: _run_paginated START (conn=%s, refs=%s)", _effective_conn_id, _refs)
            # Fresh connection per request — cheap to create, no lock contention.
            # Iceberg manifests come from L1/L2 cache so view registration is fast.
            con = _duckdb_con_with_s3(cfg, connection_id=_effective_conn_id)
            logger.info("STREAM-DIAG: DuckDB connection ready (%.2fs)", _pt.monotonic() - _p0)
            try:
                _p1 = _pt.monotonic()
                _pf_pag = _extract_partition_filters_from_query(request.query_config) if request.query_config else None
                _iceberg_total = _register_s3_views(con, registered_tables, bucket, _effective_conn_id, cfg,
                                   referenced_tables=_refs or None, partition_filters=_pf_pag)
                logger.info("STREAM-DIAG: views registered (%.2fs), iceberg_records=%d", _pt.monotonic() - _p1, _iceberg_total)

                # ── Execute the query as-is with pagination ──────────────
                def _sq(n):
                    return '"' + str(n).replace('"', '""') + '"'

                # Build WHERE clause from adv_filters (grid-level filters)
                where_clause = ""
                where_params = []
                if request.adv_filters:
                    # Need valid columns for filter validation
                    _schema_r = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                    _valid = [desc[0] for desc in _schema_r.description]
                    where_clause, where_params = _build_where(request.adv_filters, _valid)

                # Build ORDER BY
                order_clause = ""
                if request.sort_column:
                    direction = "ASC" if request.sort_direction == "asc" else "DESC"
                    order_clause = f' ORDER BY {_sq(request.sort_column)} {direction}'

                offset = (request.page - 1) * request.page_size
                data_sql = f"SELECT * FROM ({stripped_sql}) _s{where_clause}{order_clause} LIMIT {request.page_size} OFFSET {offset}"

                _p4 = _pt.monotonic()
                logger.info("STREAM-DIAG: page=%d, offset=%d, SQL=%.300s", request.page, offset, data_sql)
                result = con.execute(data_sql, where_params) if where_params else con.execute(data_sql)
                all_columns = [desc[0] for desc in result.description]
                raw_rows = result.fetchall()

                columns = all_columns
                rows = [dict(zip(columns, row)) for row in raw_rows] if raw_rows else []
                logger.info("STREAM-DIAG: OK, %d rows, %d/%d cols (%.2fs)",
                            len(raw_rows), len(columns), len(all_columns), _pt.monotonic() - _p4)

                # ── Total rows from Iceberg metadata (no S3 scan needed) ─────
                rows_returned = len(raw_rows)
                if rows_returned < request.page_size:
                    # Last page — exact total
                    total_rows = (request.page - 1) * request.page_size + rows_returned
                elif _iceberg_total > 0:
                    # Use record count from Iceberg manifests (instant, from cache)
                    total_rows = _iceberg_total
                else:
                    total_rows = -1  # unknown (non-Iceberg or no metadata)
                filtered_rows = total_rows
                logger.info("STREAM-DIAG: total_rows=%d (iceberg_metadata=%d)", total_rows, _iceberg_total)

                total_pages = max(1, (filtered_rows + request.page_size - 1) // request.page_size) if filtered_rows > 0 else -1

                import time as _et
                return {
                    "columns": columns,
                    "rows": rows,
                    "total_rows": total_rows,
                    "filtered_rows": filtered_rows,
                    "page": request.page,
                    "page_size": request.page_size,
                    "total_pages": total_pages,
                    "streaming": True,
                    "elapsed_seconds": round(_et.monotonic() - _p0, 3),
                }
            finally:
                con.close()

        # Check if client already disconnected (StrictMode abort or network drop)
        if http_request and await http_request.is_disconnected():
            logger.info("Stream paginate: client disconnected before execution, skipping")
            return {"columns": [], "rows": [], "total_rows": 0, "page": 1, "page_size": request.page_size, "total_pages": 0}

        # Run with timeout to prevent hung connections
        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor(), _run_paginated),
                timeout=600.0,  # 10 min — large S3 datasets need time
            )
        except asyncio.TimeoutError:
            logger.error("Stream paginate: timed out after 600s for page=%d", request.page)
            raise HTTPException(status_code=504, detail="S3 query timed out after 10 minutes")
        _jsonify_rows(result["rows"])

        elapsed = _t.monotonic() - t0
        logger.info("Stream paginate: page=%d, rows=%d, cols=%d, elapsed=%.2fs",
                     request.page, len(result["rows"]), len(result.get("columns", [])), elapsed)
        return result

    except HTTPException:
        raise
    except Exception as e:
        _raise_if_s3_auth_error(e)
        logger.error("Stream paginate error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Streaming pagination failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/execute/stream/chart-data — Chart aggregation on full S3 dataset
# POST /api/execute/stream/pivot-data — Pivot aggregation on full S3 dataset
# ─────────────────────────────────────────────────────────────────────────────

class StreamChartRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    x_col: str
    y_col: str
    agg: str = "sum"
    top_n: int = 50
    series_col: Optional[str] = None
    max_series: int = 10


@app.post("/api/execute/stream/chart-data")
async def stream_chart_data(request: StreamChartRequest, _user: dict = Depends(_get_current_user)):
    """Chart aggregation directly from S3 — runs GROUP BY on the full dataset."""
    import time as _t
    t0 = _t.monotonic()

    _effective_conn_id = request.connection_id
    if not _effective_conn_id and request.query_config:
        _effective_conn_id = request.query_config.connection_id
    if not _effective_conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required")

    conn = db_manager.get_connection_raw(_effective_conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Streaming chart only supported for S3 connections")
    cfg = conn.get("config", {})

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()

        if request.raw_sql:
            inner_sql = request.raw_sql
        elif request.query_config:
            engine_config = convert_query_config_to_engine(request.query_config)
            s3_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir),
                chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(cfg),
            )
            if registered_tables:
                s3_engine._registered_tables = registered_tables
                s3_engine._s3_conn_config = cfg
                s3_engine._s3_bucket = bucket
                s3_engine._s3_conn_id = _effective_conn_id
            inner_sql = s3_engine.get_duckdb_sql(engine_config)
            inner_sql = _rewrite_registered_refs(inner_sql, registered_tables)
        else:
            raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")

        stripped_sql = _strip_sql_limit(inner_sql)
        _refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in stripped_sql}
        _pf = _extract_partition_filters_from_query(request.query_config) if request.query_config else None

        loop = asyncio.get_running_loop()

        def _run_chart():
            con = _duckdb_con_with_s3(cfg, connection_id=_effective_conn_id)
            try:
                _register_s3_views(con, registered_tables, bucket, _effective_conn_id, cfg,
                                   referenced_tables=_refs or None, partition_filters=_pf)

                source = f"({stripped_sql}) _src"
                agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(request.agg, "SUM")
                # Clamp to admin-configured limits
                _eff_top_n = min(request.top_n, _limits_cfg.stream_chart_top_n) if request.top_n else _limits_cfg.stream_chart_top_n
                _eff_max_series = min(request.max_series, _limits_cfg.stream_chart_max_series) if request.max_series else _limits_cfg.stream_chart_max_series

                if request.series_col:
                    # Multi-series chart
                    top_series_sql = f"""
                        SELECT COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)'),
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS total
                        FROM {source} GROUP BY 1 ORDER BY total DESC NULLS LAST LIMIT {_eff_max_series}
                    """
                    top_series = [str(r[0]) for r in con.execute(top_series_sql).fetchall()]

                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)') AS series,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value
                        FROM {source} GROUP BY 1, 2
                    """
                    import pandas as pd
                    raw_df = con.execute(agg_sql).fetchdf()
                    raw_df.columns = ["label", "series", "value"]
                    raw_df = raw_df[raw_df["series"].isin(top_series)]
                    pivot = raw_df.pivot_table(index="label", columns="series", values="value", aggfunc="sum")
                    pivot = pivot.head(_eff_top_n)
                    grand_total = float(pivot.values[~pd.isna(pivot.values)].sum()) if pivot.size > 0 else 0.0
                    data = []
                    for label in pivot.index:
                        row_dict = {"label": str(label)}
                        for s in top_series:
                            v = pivot.loc[label, s] if s in pivot.columns else None
                            row_dict[s] = None if (v is None or pd.isna(v)) else float(v)
                        data.append(row_dict)
                    return {"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "series_col": request.series_col, "series": top_series, "multi": True,
                            "grand_total": grand_total, "data": data}
                else:
                    # Single-series chart
                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value,
                               COUNT(*) AS cnt
                        FROM {source} GROUP BY {_q(request.x_col)}
                        ORDER BY value DESC NULLS LAST LIMIT {_eff_top_n}
                    """
                    rows = con.execute(agg_sql).fetchall()
                    grand_total = sum(r[1] for r in rows if r[1] is not None)
                    data = [{"label": str(r[0]), "value": float(r[1]) if r[1] is not None else 0, "count": int(r[2])} for r in rows]
                    return {"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "multi": False, "grand_total": grand_total, "data": data}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor(), _run_chart),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(_t.monotonic() - t0, 3)
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Chart query timed out")
    except HTTPException:
        raise
    except Exception as e:
        _raise_if_s3_auth_error(e)
        logger.error("Stream chart error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Stream chart failed: {str(e)}")


class StreamPivotRequest(BaseModel):
    query_config: Optional[QueryConfigModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    row_fields: str          # comma-separated
    values: str              # JSON array
    col_field: Optional[str] = None
    top_n: int = 50


@app.post("/api/execute/stream/pivot-data")
async def stream_pivot_data(request: StreamPivotRequest, _user: dict = Depends(_get_current_user)):
    """Pivot aggregation directly from S3 — runs GROUP BY on the full dataset."""
    import time as _t
    t0 = _t.monotonic()

    _effective_conn_id = request.connection_id
    if not _effective_conn_id and request.query_config:
        _effective_conn_id = request.query_config.connection_id
    if not _effective_conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required")

    conn = db_manager.get_connection_raw(_effective_conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Streaming pivot only supported for S3 connections")
    cfg = conn.get("config", {})

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q, _AGG_MAP

        registered_tables = cfg.get("registered_tables", [])
        bucket = (cfg.get("bucket_name") or "").strip()

        if request.raw_sql:
            inner_sql = request.raw_sql
        elif request.query_config:
            engine_config = convert_query_config_to_engine(request.query_config)
            s3_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir),
                chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(cfg),
            )
            if registered_tables:
                s3_engine._registered_tables = registered_tables
                s3_engine._s3_conn_config = cfg
                s3_engine._s3_bucket = bucket
                s3_engine._s3_conn_id = _effective_conn_id
            inner_sql = s3_engine.get_duckdb_sql(engine_config)
            inner_sql = _rewrite_registered_refs(inner_sql, registered_tables)
        else:
            raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")

        stripped_sql = _strip_sql_limit(inner_sql)
        _refs = {t["name"] for t in (registered_tables or []) if f'"{t["name"]}"' in stripped_sql}
        _pf = _extract_partition_filters_from_query(request.query_config) if request.query_config else None

        row_fields = [f.strip() for f in request.row_fields.split(",") if f.strip()]
        values = json.loads(request.values)
        loop = asyncio.get_running_loop()

        def _run_pivot():
            con = _duckdb_con_with_s3(cfg, connection_id=_effective_conn_id)
            try:
                _register_s3_views(con, registered_tables, bucket, _effective_conn_id, cfg,
                                   referenced_tables=_refs or None, partition_filters=_pf)

                source = f"({stripped_sql}) _src"

                # Build aggregation expressions
                agg_exprs = []
                agg_aliases = []
                for i, v in enumerate(values):
                    alias = f"val_{i}"
                    fn = v["function"]
                    col = v.get("column", "*")
                    if fn == "count_rows":
                        agg_exprs.append(f"COUNT(*) AS {alias}")
                    elif fn == "count_distinct":
                        agg_exprs.append(f'COUNT(DISTINCT {_q(col)}) AS {alias}')
                    else:
                        sql_fn = _AGG_MAP.get(fn, "SUM")
                        agg_exprs.append(f'{sql_fn}(TRY_CAST({_q(col)} AS DOUBLE)) AS {alias}')
                    agg_aliases.append(alias)

                if not request.col_field:
                    # Simple pivot: GROUP BY row_fields
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    sql = f"SELECT {group_cols}, {', '.join(agg_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} ORDER BY {agg_aliases[0]} DESC NULLS LAST LIMIT {request.top_n}"
                    rows = con.execute(sql).fetchall()
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    # Grand totals
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows:
                        d = {}
                        for j, rf in enumerate(row_fields):
                            d[rf] = str(row[j]) if row[j] is not None else "(blank)"
                        for j, alias in enumerate(agg_aliases):
                            d[alias] = float(row[len(row_fields) + j]) if row[len(row_fields) + j] is not None else 0
                        result_rows.append(d)
                    return {"row_fields": row_fields, "col_field": None, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": [],
                            "grand_totals": grand_totals}
                else:
                    # Cross-tab pivot
                    col_vals_sql = f"SELECT DISTINCT CAST({_q(request.col_field)} AS VARCHAR) FROM {source} ORDER BY 1 LIMIT 20"
                    col_values = [str(r[0]) for r in con.execute(col_vals_sql).fetchall() if r[0] is not None]
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    # Build cross-tab aggregates
                    ct_exprs = []
                    for cv in col_values:
                        cv_esc = cv.replace("'", "''")
                        for i, v in enumerate(values):
                            fn = v["function"]
                            col = v.get("column", "*")
                            alias = f"val_{i}__{cv.replace(' ', '_')}"
                            if fn == "count_rows":
                                ct_exprs.append(f"COUNT(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN 1 END) AS \"{alias}\"")
                            else:
                                sql_fn = _AGG_MAP.get(fn, "SUM")
                                ct_exprs.append(f"{sql_fn}(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN TRY_CAST({_q(col)} AS DOUBLE) END) AS \"{alias}\"")
                    sql = f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT {request.top_n}"
                    rows_data = con.execute(sql).fetchall()
                    desc = [d[0] for d in con.execute(sql + " LIMIT 0").description] if not rows_data else [d[0] for d in con.execute(f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT 0").description]
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows_data:
                        d = {desc[j]: (str(row[j]) if j < len(row_fields) else (float(row[j]) if row[j] is not None else 0)) for j in range(len(row))}
                        result_rows.append(d)
                    return {"row_fields": row_fields, "col_field": request.col_field, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": col_values,
                            "grand_totals": grand_totals}
            finally:
                con.close()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor(), _run_pivot),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(_t.monotonic() - t0, 3)
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Pivot query timed out")
    except HTTPException:
        raise
    except Exception as e:
        _raise_if_s3_auth_error(e)
        logger.error("Stream pivot error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Stream pivot failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/execute/estimate  — lightweight row / file count before execution
# ─────────────────────────────────────────────────────────────────────────────
class EstimateRequest(BaseModel):
    query_config: QueryConfigModel
    connection_id: Optional[int] = None

@app.post("/api/execute/estimate")
async def estimate_query(request: EstimateRequest, _user: dict = Depends(_get_current_user)):
    """Return estimated row count and file count without executing the full query."""
    try:
        query_config_model = request.query_config
        _effective_conn_id = request.connection_id or query_config_model.connection_id

        if not query_config_model.files:
            return {"estimated_rows": 0, "estimated_files": 0}

        # ── Registered tables — return file count only (can't COUNT without views) ──
        _file_paths = [
            (f if isinstance(f, str) else (f.path if hasattr(f, 'path') else ''))
            for f in query_config_model.files
        ]
        _has_registered = any(p.startswith("__registered__:") for p in _file_paths)
        if _has_registered:
            return {
                "estimated_rows": -1,
                "estimated_files": len(query_config_model.files),
                "note": "Row estimation not available for registered tables",
            }

        # MV / local table — return stored row count directly (instant, no S3 needed)
        _has_mv = any(p.startswith("__materialized__:") for p in _file_paths)
        _has_lt = any(p.startswith("__local__:") for p in _file_paths)
        if _has_mv or _has_lt:
            total_rows = 0
            for p in _file_paths:
                if p.startswith("__materialized__:"):
                    mv_name = p.replace("__materialized__:", "")
                    mv_rec = db_manager.get_materialized_view_by_name(mv_name)
                    if mv_rec:
                        total_rows += mv_rec.get("row_count", 0)
                elif p.startswith("__local__:"):
                    lt_name = p.replace("__local__:", "")
                    lt_rec = db_manager.get_local_table_by_name(lt_name)
                    if lt_rec:
                        total_rows += lt_rec.get("row_count", 0)
            return {
                "estimated_rows": total_rows,
                "estimated_files": len(query_config_model.files),
            }

        # Resolve connection
        conn_record = None
        _conn_type = None
        _cfg = {}
        if _effective_conn_id:
            conn_record = db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})

        # ── SQL connector path (Trino, Snowflake, Databricks, Oracle) ──
        if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
            table_ref = query_config_model.files[0] if query_config_model.files else None
            if not table_ref:
                return {"estimated_rows": -1, "estimated_files": 0}

            # Build filter-only query, then wrap with COUNT(*)
            estimate_model = query_config_model.model_copy(update={
                "limit": None, "offset": 0, "aggregations": None,
                "group_by": None, "order_by": None, "columns": None,
            })
            try:
                from core.date_resolver import resolve_filter_dates
                if estimate_model.filters:
                    resolved = resolve_filter_dates(estimate_model.filters)
                    estimate_model = estimate_model.model_copy(update={"filters": resolved})
            except Exception:
                pass

            engine_config = convert_query_config_to_engine(estimate_model)
            full_sql = engine.build_query_sql(engine_config, table_ref)

            # Replace SELECT ... FROM with SELECT COUNT(*) FROM
            from_idx = full_sql.upper().find("\nFROM ")
            if from_idx == -1:
                from_idx = full_sql.upper().find(" FROM ")
            if from_idx == -1:
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:]

            # Execute via connector (runs on the actual database)
            try:
                sql_connector = get_connector(_conn_type, _cfg)
                result = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: sql_connector.execute_query(count_sql, limit=None)
                )
                rows = result.get("rows", [])
                if rows:
                    # Column name may be 'cnt', 'CNT', etc. depending on DB dialect
                    row = {k.lower(): v for k, v in rows[0].items()}
                    estimated_rows = row.get("cnt", 0)
                else:
                    estimated_rows = 0
            except Exception as exc:
                logger.warning("SQL connector estimate failed (%s): %s", _conn_type, exc)
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            return {
                "estimated_rows": estimated_rows,
                "estimated_files": len(query_config_model.files),
            }

        # ── Parquet path (local / S3) ──
        active_engine = engine
        if _conn_type == 'local':
            local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
            active_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
        elif _conn_type == 's3':
            active_engine = ParquetQueryEngine(
                base_path=str(_paths.parquet_dir), chunk_size=_qe_cfg.chunk_size,
                s3_config=build_s3_config(_cfg),
            )

        # Build filter-only query
        estimate_model = query_config_model.model_copy(update={
            "limit": None, "offset": 0, "aggregations": None,
            "group_by": None, "order_by": None, "columns": None,
        })
        try:
            from core.date_resolver import resolve_filter_dates
            if estimate_model.filters:
                resolved = resolve_filter_dates(estimate_model.filters)
                estimate_model = estimate_model.model_copy(update={"filters": resolved})
        except Exception:
            pass

        engine_config = convert_query_config_to_engine(estimate_model)
        from_clause = active_engine._build_duckdb_from_clause(engine_config)
        full_sql = active_engine.build_query_sql(engine_config, from_clause)

        from_idx = full_sql.upper().find("\nFROM ")
        if from_idx == -1:
            from_idx = full_sql.upper().find(" FROM ")
        count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:] if from_idx != -1 else None

        estimated_rows = 0
        if count_sql:
            from api.data_grid_api import _duckdb_con_with_s3
            if _conn_type == 's3':
                con = _duckdb_con_with_s3(_cfg, connection_id=_effective_conn_id)
            else:
                import duckdb
                con = duckdb.connect(database=":memory:")
            try:
                result = con.execute(count_sql).fetchone()
                estimated_rows = result[0] if result else 0
            finally:
                con.close()

        return {
            "estimated_rows": estimated_rows,
            "estimated_files": len(query_config_model.files),
        }
    except Exception as e:
        logger.error("Estimate error: %s", e, exc_info=True)
        return {"estimated_rows": -1, "estimated_files": len(request.query_config.files or []),
                "error": str(e)}


@app.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, background_tasks: BackgroundTasks, _user: dict = Depends(_require_execute_access)):
    """Execute a query (saved or ad-hoc)"""
    try:
        if request.query_config:
            # Client passes an explicit (possibly parameterised) query config — use it.
            # query_id may also be set for audit/tracking purposes; that is fine.
            query_config_model = request.query_config
        elif request.query_id:
            saved_query = db_manager.get_query(request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
        elif request.raw_sql:
            # SQL editor mode — no visual query config needed
            query_config_model = QueryConfigModel(files=[])
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id, query_config, or raw_sql must be provided"
            )

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except Exception:
            pass   # non-fatal — proceed with original filters

        # ── Phase 47: Pre-execution query analysis ────────────────────────────
        _query_warnings = []
        try:
            from core.query_analyzer import analyze_query as _analyze_q, warnings_to_dicts as _wtd
            _sql_to_analyze = request.raw_sql or ""
            _pre_conn_type = "duckdb"
            _pre_conn_id = request.connection_id or query_config_model.connection_id
            if _pre_conn_id:
                _pre_conn = db_manager.get_connection_raw(_pre_conn_id)
                if _pre_conn:
                    _pre_conn_type = _pre_conn.get('connection_type', 'duckdb')
                    # Fetch partition columns for the first queried table
                    _pre_table = (query_config_model.files or [''])[0]
                    _pre_partitions = []
                    try:
                        _pre_partitions = [
                            p.get('column', '') for p in
                            db_manager.get_connection_partitions(_pre_conn_id, _pre_table)
                            if p.get('column')
                        ]
                    except Exception:
                        pass
            if _sql_to_analyze:
                _query_warnings = _wtd(_analyze_q(_sql_to_analyze, _pre_conn_type, _pre_partitions))
        except Exception:
            pass  # non-fatal

        # ── Phase 46: Record table/file usage for auto-suggest ────────────────
        try:
            _usage_conn_id = request.connection_id or query_config_model.connection_id
            for _f in (query_config_model.files or []):
                _fname = str(_f)
                if not _fname.startswith('__'):
                    import os as _os
                    _tname = _os.path.splitext(_os.path.basename(_fname))[0]
                    db_manager.record_usage("table", _tname, connection_id=_usage_conn_id)
        except Exception:
            pass  # non-fatal

        # Resolve engine based on connection type
        # Explicit request.connection_id takes priority; fall back to connection_id stored in saved query
        _effective_conn_id = request.connection_id or query_config_model.connection_id
        active_engine = engine
        _uses_registered = False
        if _effective_conn_id:
            conn_record = db_manager.get_connection_raw(_effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})
                if _conn_type == 'local':
                    local_path = str(_normalize_path(_cfg.get('base_path', './data/parquet')))
                    active_engine = ParquetQueryEngine(
                        base_path=local_path,
                        chunk_size=_qe_cfg.chunk_size,
                    )
                elif _conn_type == 's3':
                    active_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(_cfg),
                    )
                    # Check if query uses registered/materialized/local tables (virtual path prefix)
                    def _has_virtual_prefix(paths):
                        return any(
                            f.startswith("__registered__:") or f.startswith("__materialized__:") or f.startswith("__local__:")
                            for f in (paths or [])
                        )
                    _join_files = [
                        j.right_file if isinstance(j.right_file, str) else j.right_file
                        for j in (query_config_model.joins or [])
                    ] if query_config_model.joins else []
                    _uses_registered = (
                        _has_virtual_prefix(query_config_model.files or [])
                        or _has_virtual_prefix(_join_files)
                    )
                    if _uses_registered:
                        active_engine._registered_tables = _cfg.get("registered_tables", [])
                        active_engine._s3_conn_config = _cfg
                        active_engine._s3_bucket = _cfg["bucket_name"]
                        active_engine._s3_conn_id = _effective_conn_id
                elif _conn_type in SQL_CONNECTOR_TYPES:
                    # ── SQL connector execution path ──────────────────────────
                    # Build SQL from the query config and dispatch to the connector.
                    # Bypass parquet validation — there are no local files to check.
                    sql_connector = get_connector(_conn_type, _cfg)
                    if request.raw_sql:
                        sql_str = request.raw_sql
                    else:
                        engine_config = convert_query_config_to_engine(query_config_model)
                        table_ref = query_config_model.files[0] if query_config_model.files else None
                        if not table_ref:
                            raise HTTPException(status_code=400, detail="No table specified in query config")
                        sql_str = engine.build_query_sql(engine_config, table_ref)

                    # ── SQL connector cache check ─────────────────────────────
                    _sql_qc_dict = query_config_model.model_dump()
                    # Include raw_sql in key so manually typed SQL is keyed separately
                    if request.raw_sql:
                        _sql_qc_dict["_raw_sql"] = request.raw_sql
                    _sql_qc_dict["_conn_type"] = _conn_type
                    from core.query_cache import make_cache_key as _mk_sql_ck, get_cached_result as _get_sql_cached
                    _sql_cache_key = _mk_sql_ck(_sql_qc_dict)
                    if request.cache_strategy == "auto":
                        _sql_cached_path = _get_sql_cached(_sql_cache_key)
                        if _sql_cached_path:
                            try:
                                _sql_cached_size = _sql_cached_path.stat().st_size
                            except FileNotFoundError:
                                from core.query_cache import invalidate as _sql_cache_inv
                                _sql_cache_inv(_sql_cache_key)
                                _sql_cached_path = None
                        if _sql_cached_path:
                            _c_file_size = _sql_cached_path.stat().st_size
                            _c_stats = {}
                            try:
                                import pyarrow.parquet as _pq_c
                                _c_pf = _pq_c.ParquetFile(str(_sql_cached_path))
                                _c_stats = {"total_rows": _c_pf.metadata.num_rows,
                                            "total_columns": _c_pf.metadata.num_columns}
                            except Exception:
                                pass
                            _c_exec_id = str(uuid.uuid4())
                            _c_file_id = str(uuid.uuid4())
                            db_manager.create_execution(
                                execution_id=_c_exec_id,
                                query_id=request.query_id,
                                query_config=_sql_qc_dict,
                                executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                            )
                            db_manager.update_execution(_c_exec_id, status="completed",
                                                        output_file=str(_sql_cached_path),
                                                        total_rows=_c_stats.get("total_rows", 0),
                                                        file_size_bytes=_c_file_size)
                            db_manager.create_download_file(
                                file_id=_c_file_id, execution_id=_c_exec_id,
                                filename=f"cached_result_{_c_exec_id}.parquet",
                                file_path=str(_sql_cached_path),
                                file_size_bytes=_c_file_size,
                                expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                            )
                            await ws_manager.broadcast({
                                "type": "execution_completed", "execution_id": _c_exec_id,
                                "file_id": _c_file_id, "cache_hit": True,
                                "stats": _c_stats,
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                            })
                            return {
                                "execution_id": _c_exec_id, "status": "completed",
                                "cache_hit": True, "file_id": _c_file_id,
                                "message": "Served from cache",
                            }

                    _username = _user.get("username", "guest") if _user else "guest"
                    with _user_query_lock:
                        _active = _user_query_counts.get(_username, 0)
                        if _active >= _qe_cfg.max_concurrent_per_user:
                            raise HTTPException(
                                status_code=429,
                                detail=f"Too many concurrent queries ({_active} running)."
                            )
                        _user_query_counts[_username] = _active + 1
                    try:
                        execution_id = str(uuid.uuid4())
                        # Record checkpoint intent (Phase 41)
                        from core.checkpoint import record_intent as _record_intent_sql
                        _record_intent_sql(execution_id, query_config_model.model_dump(),
                                           executed_by=request.executed_by or _username,
                                           query_id=request.query_id)
                        execution = db_manager.create_execution(
                            execution_id=execution_id,
                            query_id=request.query_id,
                            query_config=query_config_model.model_dump(),
                            executed_by=request.executed_by or _username
                        )
                        _task = asyncio.create_task(
                            execute_sql_connector_background(
                                execution_id, sql_connector, sql_str,
                                query_id=request.query_id, executed_by=_username,
                                cache_key=_sql_cache_key,
                                cache_strategy=request.cache_strategy or "auto",
                                query_config_dict=_sql_qc_dict,
                            )
                        )
                        pass  # pool tracks the task
                    except Exception:
                        with _user_query_lock:
                            _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                        raise
                    _audit(_user, "execute_sql_connector_query", None, "execution", execution_id,
                           {"conn_type": _conn_type, "table": table_ref, "query_id": request.query_id})
                    logger.info(f"SQL connector query started: {execution_id} ({_conn_type}:{table_ref})")
                    return {
                        "execution_id": execution_id,
                        "status": "pending",
                        "started_at": execution["started_at"],
                        "message": f"SQL connector query started ({_conn_type})"
                    }

        # Also treat MV/local table refs as "registered" (skip file validation, use _setup_registered_views)
        if not _uses_registered:
            _all_file_paths = list(query_config_model.files or [])
            if any(str(f).startswith("__materialized__:") or str(f).startswith("__local__:") for f in _all_file_paths):
                _uses_registered = True
                # Ensure engine has the required attributes for _execute_registered_table_*
                if not hasattr(active_engine, '_registered_tables') or not active_engine._registered_tables:
                    active_engine._registered_tables = []
                if not hasattr(active_engine, '_s3_conn_config') or not active_engine._s3_conn_config:
                    active_engine._s3_conn_config = {}
                if not hasattr(active_engine, '_s3_bucket'):
                    active_engine._s3_bucket = ""
                if not hasattr(active_engine, '_s3_conn_id'):
                    active_engine._s3_conn_id = _effective_conn_id

        engine_config = convert_query_config_to_engine(query_config_model)

        # ── Cross-connection join / union path ────────────────────────────────
        if request.secondary_connection_id and request.secondary_query_config:
            # Validate secondary connection exists
            sec_conn_record = db_manager.get_connection_raw(request.secondary_connection_id)
            if not sec_conn_record:
                raise HTTPException(
                    status_code=404,
                    detail=f"Secondary connection {request.secondary_connection_id} not found"
                )

            # Validate secondary query config is parseable
            try:
                sec_qc_model = QueryConfigModel(**request.secondary_query_config)
            except Exception as _pve:
                raise HTTPException(status_code=400,
                                    detail=f"Invalid secondary_query_config: {_pve}")

            # Validate join_config present when mode=join
            if request.combine_mode == "join":
                _jc = request.join_config or {}
                if not _jc.get("left_on") or not _jc.get("right_on"):
                    raise HTTPException(
                        status_code=400,
                        detail="join_config with left_on and right_on is required when combine_mode='join'"
                    )

            # Resolve secondary engine
            secondary_engine = engine
            _sc_type = sec_conn_record.get('connection_type')
            _sc_cfg = sec_conn_record.get('config', {})
            if _sc_type == 'local':
                _sc_path = str(_normalize_path(_sc_cfg.get('base_path', './data/parquet')))
                secondary_engine = ParquetQueryEngine(
                    base_path=_sc_path,
                    chunk_size=_qe_cfg.chunk_size,
                )
            elif _sc_type == 's3':
                secondary_engine = ParquetQueryEngine(
                    base_path=str(_paths.parquet_dir),
                    chunk_size=_qe_cfg.chunk_size,
                    s3_config=build_s3_config(_sc_cfg),
                )

            secondary_config = convert_query_config_to_engine(sec_qc_model)

            # ── Cross-query cache check ───────────────────────────────────────
            _cross_qc_dict = {
                "primary": query_config_model.model_dump(),
                "secondary": sec_qc_model.model_dump(),
                "combine_mode": request.combine_mode,
                "join_config": request.join_config,
            }
            from core.query_cache import make_cache_key as _mk_cx_ck, get_cached_result as _get_cx_cached
            _cross_cache_key = _mk_cx_ck(_cross_qc_dict)
            if request.cache_strategy == "auto":
                _cx_cached_path = _get_cx_cached(_cross_cache_key)
                if _cx_cached_path:
                    try:
                        _cx_cached_size = _cx_cached_path.stat().st_size
                    except FileNotFoundError:
                        from core.query_cache import invalidate as _cx_inv
                        _cx_inv(_cross_cache_key)
                        _cx_cached_path = None
                if _cx_cached_path:
                    _cx_file_size = _cx_cached_path.stat().st_size
                    _cx_stats = {}
                    try:
                        import pyarrow.parquet as _pq_cx
                        _cx_pf = _pq_cx.ParquetFile(str(_cx_cached_path))
                        _cx_stats = {"total_rows": _cx_pf.metadata.num_rows,
                                     "total_columns": _cx_pf.metadata.num_columns}
                    except Exception:
                        pass
                    _cx_exec_id = str(uuid.uuid4())
                    _cx_file_id = str(uuid.uuid4())
                    db_manager.create_execution(
                        execution_id=_cx_exec_id,
                        query_id=request.query_id,
                        query_config=query_config_model.model_dump(),
                        executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                    )
                    db_manager.update_execution(_cx_exec_id, status="completed",
                                                output_file=str(_cx_cached_path),
                                                total_rows=_cx_stats.get("total_rows", 0),
                                                file_size_bytes=_cx_file_size)
                    db_manager.create_download_file(
                        file_id=_cx_file_id, execution_id=_cx_exec_id,
                        filename=f"cached_result_{_cx_exec_id}.parquet",
                        file_path=str(_cx_cached_path),
                        file_size_bytes=_cx_file_size,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                    )
                    await ws_manager.broadcast({
                        "type": "execution_completed", "execution_id": _cx_exec_id,
                        "file_id": _cx_file_id, "cache_hit": True,
                        "stats": _cx_stats, "combine_mode": request.combine_mode,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    return {
                        "execution_id": _cx_exec_id, "status": "completed",
                        "cache_hit": True, "file_id": _cx_file_id,
                        "message": "Served from cache",
                    }

            _username = _user.get("username", "guest") if _user else "guest"
            _max_per_user = _qe_cfg.max_concurrent_per_user
            with _user_query_lock:
                _active = _user_query_counts.get(_username, 0)
                if _active >= _max_per_user:
                    raise HTTPException(
                        status_code=429,
                        detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                               "Wait for one to complete or cancel it first."
                    )
                _user_query_counts[_username] = _active + 1

            # Guard: decrement counter if task setup fails after increment
            try:
                execution_id = str(uuid.uuid4())
                # Record checkpoint intent (Phase 41)
                from core.checkpoint import record_intent as _record_intent_cross
                _record_intent_cross(execution_id, query_config_model.model_dump(),
                                     executed_by=request.executed_by or _username,
                                     query_id=request.query_id)
                execution = db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by or _username
                )
                _task = asyncio.create_task(
                    execute_cross_query_background(
                        execution_id,
                        active_engine,
                        engine_config,
                        secondary_engine,
                        secondary_config,
                        combine_mode=request.combine_mode,
                        join_config=request.join_config,
                        query_id=request.query_id,
                        executed_by=_username,
                        cache_key=_cross_cache_key,
                        cache_strategy=request.cache_strategy or "auto",
                        query_config_dict=_cross_qc_dict,
                    )
                )
                pass  # pool tracks the task
            except Exception:
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
                raise

            _audit(_user, "execute_cross_query", None, "execution", execution_id,
                   {"query_id": request.query_id,
                    "primary_connection_id": request.connection_id,
                    "secondary_connection_id": request.secondary_connection_id,
                    "combine_mode": request.combine_mode})
            logger.info(f"Cross-connection query started: {execution_id} ({request.combine_mode})")

            return {
                "execution_id": execution_id,
                "status": "pending",
                "started_at": execution["started_at"],
                "is_cross_connection": True,
                "combine_mode": request.combine_mode,
                "message": f"Cross-connection {request.combine_mode.upper()} query started"
            }

        # ── Single-source path (original) ─────────────────────────────────────
        # Skip file-level validation for registered tables — they use virtual
        # paths (__registered__:name) that don't exist on disk / S3.
        if not _uses_registered:
            # Run validate_query off the event loop — it reads file schemas from disk
            # and can take 100 ms – 2 s per file, which would stall all other requests.
            _loop = asyncio.get_running_loop()
            validation = await _loop.run_in_executor(
                _get_light_executor(), active_engine.validate_query, engine_config
            )
            if not validation["valid"]:
                raise HTTPException(
                    status_code=400,
                    detail={"message": "Invalid query configuration", "errors": validation["errors"]}
                )

        # ── Query result cache check ──────────────────────────────────────────
        # Check cache for ALL query types (including S3/connection queries).
        # Skipped when cache_strategy is 'bypass' or 'refresh'.
        if request.cache_strategy == "auto":
            from core.query_cache import make_cache_key, get_cached_result, invalidate as _cache_invalidate
            _cache_key = make_cache_key(query_config_model.model_dump())
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                try:
                    _cached_size = _cached_path.stat().st_size   # Guard: file may vanish between lookup and here
                except FileNotFoundError:
                    # File deleted externally between cache lookup and now — evict stale record, fall through
                    logger.warning("[query_cache] Cached file gone before serve: %s", _cached_path)
                    _cache_invalidate(_cache_key)
                    _cached_path = None

            if _cached_path:
                # Read stats first so we can persist total_rows in the execution record
                _cache_stats = {}
                try:
                    import pyarrow.parquet as _pq_s
                    _pf = _pq_s.ParquetFile(str(_cached_path))
                    _cache_stats = {"total_rows": _pf.metadata.num_rows, "total_columns": _pf.metadata.num_columns}
                except Exception:
                    pass
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                db_manager.create_execution(
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                db_manager.update_execution(execution_id, status="completed",
                                            output_file=str(_cached_path),
                                            total_rows=_cache_stats.get("total_rows", 0),
                                            file_size_bytes=_cached_size)
                db_manager.create_download_file(
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_size,
                    expires_at=datetime.now(timezone.utc) + timedelta(days=1),
                )
                await ws_manager.broadcast({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "stats": _cache_stats,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # ── Base-data reuse: query local parquet instead of re-downloading ────
        # If the exact cache missed but the same base data (FROM/WHERE/JOIN) is
        # already on disk from a previous S3 download, run the new SELECT /
        # aggregation / ORDER BY locally via DuckDB — zero network round-trip.
        if request.cache_strategy in ("auto", "refresh"):
            try:
                from core.query_cache import make_base_data_key, get_cached_result as _get_base, store_result as _store_base
                _qcd_base = query_config_model.model_dump()
                _base_key = make_base_data_key(_qcd_base)
                _base_path = _get_base(_base_key)
                if _base_path and _base_path.exists():
                    _bd_exec_id = str(uuid.uuid4())
                    _bd_output = _paths.downloads_dir / f"{_bd_exec_id}.parquet"
                    _loop_bd = asyncio.get_running_loop()
                    _bd_result = await _loop_bd.run_in_executor(
                        query_executor,
                        _run_base_data_local_query,
                        _base_path, _qcd_base, _bd_output,
                    )
                    if _bd_result and _bd_output.exists():
                        _bd_file_id = str(uuid.uuid4())
                        db_manager.create_execution(
                            execution_id=_bd_exec_id,
                            query_id=request.query_id,
                            query_config=_qcd_base,
                            executed_by=request.executed_by,
                        )
                        db_manager.update_execution(
                            _bd_exec_id, status="completed",
                            output_file=str(_bd_output),
                            total_rows=_bd_result["total_rows"],
                            file_size_bytes=_bd_result["file_size_bytes"],
                        )
                        db_manager.create_download_file(
                            file_id=_bd_file_id, execution_id=_bd_exec_id,
                            filename=f"query_result_{_bd_exec_id}.parquet",
                            file_path=str(_bd_output),
                            file_size_bytes=_bd_result["file_size_bytes"],
                            expires_at=datetime.now(timezone.utc) + timedelta(days=7),
                        )
                        # Store exact cache entry so next identical query is an instant hit
                        try:
                            from core.query_cache import make_cache_key as _mkck_bd, store_result as _store_exact
                            _exact_key = _mkck_bd(_qcd_base)
                            _store_exact(_exact_key, _bd_output, _qcd_base,
                                         row_count=_bd_result["total_rows"], copy=False)
                        except Exception:
                            pass
                        await ws_manager.broadcast({
                            "type": "execution_completed", "execution_id": _bd_exec_id,
                            "file_id": _bd_file_id, "cache_hit": True, "base_data_reuse": True,
                            "stats": {
                                "total_rows": _bd_result.get("total_rows"),
                                "total_columns": _bd_result.get("total_columns"),
                                "duration_seconds": _bd_result.get("duration_seconds"),
                            },
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        })
                        return {
                            "execution_id": _bd_exec_id, "status": "completed",
                            "cache_hit": True, "base_data_reuse": True,
                            "file_id": _bd_file_id,
                            "message": "Served from local base-data cache (no S3 download)",
                        }
            except Exception as _bd_exc:
                logger.debug("[base_data_reuse] Check failed, falling through: %s", _bd_exc)

        # ── In-flight deduplication ──────────────────────────────────────────────
        # If an identical query (same cache_key) is already running, create a
        # shadow execution that waits for the primary instead of starting a
        # duplicate transfer.  Each user gets their own execution record;
        # only one network transfer / query happens.
        # asyncio is single-threaded between awaits so the check+register is atomic.
        _dedup_cache_key: Optional[str] = None
        _query_config_dict = query_config_model.model_dump()
        from core.query_cache import make_cache_key as _mkck_dedup
        _dedup_cache_key = _mkck_dedup(_query_config_dict)

        if _dedup_cache_key in _inflight_queries:
            _primary_id, _inflight_event = _inflight_queries[_dedup_cache_key]
            _username_dedup = _user.get("username", "guest") if _user else "guest"
            shadow_id = str(uuid.uuid4())
            db_manager.create_execution(
                execution_id=shadow_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username_dedup,
            )
            asyncio.create_task(
                _join_inflight_query(shadow_id, _dedup_cache_key, _inflight_event, _primary_id)
            )
            logger.info("[dedup] %s joined in-flight %s (key=%s...)",
                        shadow_id[:8], _primary_id[:8], _dedup_cache_key[:8])
            return {
                "execution_id": shadow_id,
                "status": "pending",
                "message": "Query already running — result will be shared",
            }

        # Per-user rate limit (cross-process via Redis when available) — 22B
        _username = _user.get("username", "guest") if _user else "guest"
        try:
            from core.rate_limiter import check_rate_limit, RateLimitExceededError as _RLE
            check_rate_limit("execute", _username, limit=60, window_seconds=60)
        except _RLE as _rle:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: max 60 query submissions per minute. "
                       f"Retry after {_rle.retry_after}s.",
                headers={"Retry-After": str(_rle.retry_after)},
            )
        except Exception:
            pass  # rate limiter must never block queries

        # Per-user concurrent query limit
        _max_per_user = _qe_cfg.max_concurrent_per_user
        with _user_query_lock:
            _active = _user_query_counts.get(_username, 0)
            if _active >= _max_per_user:
                raise HTTPException(
                    status_code=429,
                    detail=f"Too many concurrent queries. You have {_active} running (max {_max_per_user}). "
                           "Wait for one to complete or cancel it first."
                )
            _user_query_counts[_username] = _active + 1

        # ── Idempotency check ─────────────────────────────────────────────
        if request.idempotency_key:
            from core.execution_state import check_idempotency, register_idempotency
            _existing_exec_id = check_idempotency(request.idempotency_key)
            if _existing_exec_id:
                _existing = db_manager.get_execution(_existing_exec_id)
                if _existing:
                    return {
                        "execution_id": _existing_exec_id,
                        "status": _existing.get("status", "pending"),
                        "started_at": _existing.get("started_at"),
                        "message": "Duplicate request — returning existing execution",
                        "idempotent": True,
                    }

        # Guard: decrement counter if task setup fails after increment
        try:
            execution_id = str(uuid.uuid4())
            if request.idempotency_key:
                from core.execution_state import register_idempotency
                register_idempotency(request.idempotency_key, execution_id)

            # Record checkpoint intent BEFORE execution starts (Phase 41)
            from core.checkpoint import record_intent as _record_intent, mark_started as _mark_started, mark_completed as _mark_completed
            _record_intent(execution_id, query_config_model.model_dump(),
                           executed_by=request.executed_by or _username,
                           query_id=request.query_id)

            execution = db_manager.create_execution(
                execution_id=execution_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username
            )

            # ── External executor mode: enqueue and return immediately ─────
            from core.config import executor as _exec_cfg
            if _exec_cfg.mode == "external":
                from core.queue_backend import get_task_queue
                get_task_queue().enqueue_task(
                    task_id=str(uuid.uuid4()),
                    task_type="parquet_query",
                    payload={
                        "execution_id": execution_id,
                        "query_config": query_config_model.model_dump(),
                        "connection_id": _effective_conn_id,
                        "executed_by": _username,
                        "raw_sql": request.raw_sql,
                        "cache_strategy": request.cache_strategy,
                        "callback_url": request.callback_url or "",
                    },
                    execution_id=execution_id,
                    created_by=_username,
                    priority=0,
                )
                with _user_query_lock:
                    _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)

                # ── Wait mode: poll until done or timeout ─────────────────
                if request.wait:
                    _deadline = asyncio.get_event_loop().time() + request.wait_timeout
                    while asyncio.get_event_loop().time() < _deadline:
                        await asyncio.sleep(0.5)
                        _exec_rec = db_manager.get_execution(execution_id)
                        if _exec_rec and _exec_rec.get("status") not in ("pending", "processing"):
                            return _exec_rec
                    # Timed out — return current state
                    _exec_rec = db_manager.get_execution(execution_id)
                    return _exec_rec or {
                        "execution_id": execution_id,
                        "status": "pending",
                        "message": f"Still processing after {request.wait_timeout}s timeout",
                    }

                return {
                    "execution_id": execution_id,
                    "status": "pending",
                    "started_at": execution["started_at"],
                    "message": "Query enqueued for external execution",
                }

            # Register as primary in-flight BEFORE starting the task (no await between)
            if _dedup_cache_key:
                _inflight_queries[_dedup_cache_key] = (execution_id, asyncio.Event())

            # Use _run_query_and_signal so _inflight_queries is cleaned up on completion.
            _task = asyncio.create_task(
                _run_query_and_signal(
                    execution_id,
                    engine_config,
                    request.query_id,
                    active_engine,
                    executed_by=_username,
                    raw_sql=request.raw_sql,
                    cache_strategy=request.cache_strategy,
                    cache_key=_dedup_cache_key,
                    query_config_dict=_query_config_dict,
                )
            )
            pass  # pool tracks the task
        except Exception:
            if _dedup_cache_key:
                _inflight_queries.pop(_dedup_cache_key, None)
            with _user_query_lock:
                _user_query_counts[_username] = max(0, _user_query_counts.get(_username, 0) - 1)
            raise

        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started",
            "query_warnings": _query_warnings,
        }

    except HTTPException:
        raise
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED"})
    except Exception as e:
        logger.error(f"Error executing query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigModel] = None
    change_note:  Optional[str] = None
class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None
class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


class _SubjectExportRequest(BaseModel):
    username: str

class _UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"


def _update_config_users(username: str, password: Optional[str], role: Optional[str], action: str):
    """Persist user change to config.json and reload config in-memory.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    import json as _json
    config_file = Path(__file__).resolve().parent / "config.json"
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = _json.load(f)

    auth_section = cfg.setdefault("auth", {})

    # Parse current local_users and user_roles
    raw_users = auth_section.get("local_users", "")
    users_dict = {}
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            users_dict[u.strip()] = p.strip()

    raw_roles = auth_section.get("user_roles", "")
    roles_dict = {}
    for pair in raw_roles.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, r = pair.split(":", 1)
            roles_dict[u.strip().lower()] = r.strip().lower()

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    auth_section["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
    auth_section["user_roles"] = ",".join(f"{u}:{r}" for u, r in roles_dict.items())

    with open(config_file, "w", encoding="utf-8") as f:
        _json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Reload in-memory config
    from core import config as _config_mod
    _config_mod.reload()
    logger.info("Config reloaded after user %s: %s", action, username)




class CacheInvalidateSourceRequest(BaseModel):
    table_name:    Optional[str] = None   # registered table name (e.g. "orders")
    file_prefix:   Optional[str] = None   # S3/local prefix (e.g. "data/orders/")
    connection_id: Optional[int] = None   # invalidate all queries for a connection


# ─────────────────────────────────────────────────────────────────────────────

def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # Try the cached handler first — same client the file browser uses
    if conn_id is not None:
        try:
            handler = conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler and cache it to avoid leaking clients
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        # Cache in connection manager so subsequent calls reuse it
        if conn_id is not None:
            try:
                conn_manager._s3_handlers[conn_id] = handler
            except Exception:
                pass
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise


# ── Registered Tables (Enterprise S3 Table Registry) ─────────────────────

class RegisteredTableModel(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""


def _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix):
    """Fetch schema from S3 — Iceberg reads metadata JSON, Parquet/CSV uses DuckDB DESCRIBE."""
    logger.info("Loading schema from S3 for table '%s' (format=%s)", table_name, fmt)
    if fmt == "iceberg":
        from core.iceberg_reader import _latest_metadata_key, _read_s3_json
        s3 = _make_s3_client_for_conn(conn_raw)
        meta_prefix = table_def["s3_prefix"].rstrip("/") + "/metadata/"
        try:
            meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
            metadata = _read_s3_json(s3, bucket, meta_key)
        except Exception as e:
            logger.error("Failed to read Iceberg metadata for %s: %s", table_name, e, exc_info=True)
            raise ValueError(f"Cannot read Iceberg metadata: {e}")

        # Extract schema from metadata JSON
        schemas_list = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
        current_schema_id = metadata.get("current-schema-id", 0)
        schema_obj = next((s for s in schemas_list if s.get("schema-id") == current_schema_id), schemas_list[0] if schemas_list else {})
        columns = []
        for field in schema_obj.get("fields", []):
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                ftype = ftype.get("type", "struct")
            columns.append({
                "name": field.get("name", ""),
                "type": str(ftype),
                "nullable": not field.get("required", False),
                "field_id": field.get("id") or field.get("field-id"),
            })

        # Extract partition spec
        specs = metadata.get("partition-specs") or ([metadata["partition-spec"]] if "partition-spec" in metadata else [])
        default_spec_id = metadata.get("default-spec-id", 0)
        active_spec = next((s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {})
        field_names = {f.get("id") or f.get("field-id"): f.get("name", "") for f in schema_obj.get("fields", [])}
        partition_spec = []
        for pf in active_spec.get("fields", []):
            src_id = pf.get("source-id") or pf.get("source_id")
            partition_spec.append({
                "name": pf.get("name", ""),
                "transform": pf.get("transform", "identity"),
                "source_column": field_names.get(src_id, str(src_id)),
            })

        # Snapshot info
        current_snap_id = metadata.get("current-snapshot-id")
        snapshots = metadata.get("snapshots", [])
        snap = next((s for s in snapshots if s.get("snapshot-id") == current_snap_id), None) if current_snap_id else None

        summary = snap.get("summary", {}) if snap else {}
        data_file_count = int(summary.get("total-data-files", 0))
        total_records = int(summary.get("total-records", 0))

        return {
            "table_name": table_name,
            "format": "iceberg",
            "s3_prefix": table_def["s3_prefix"],
            "columns": columns,
            "num_rows": total_records,
            "data_file_count": data_file_count,
            "partition_spec": partition_spec,
            "snapshot_id": current_snap_id,
            "format_version": metadata.get("format-version", 1),
        }
    else:
        # Parquet or CSV — use DuckDB DESCRIBE with S3 glob
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(config, connection_id=connection_id)
        try:
            if fmt == "csv":
                src = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
            else:
                src = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
            cols_raw = con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()
            row_count = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
            return {
                "table_name": table_name,
                "format": fmt,
                "s3_prefix": table_def["s3_prefix"],
                "columns": [
                    {"name": c[0], "type": c[1], "nullable": True}
                    for c in cols_raw
                ],
                "num_rows": row_count,
            }
        finally:
            con.close()
import threading as _threading
_schema_cache: Dict[str, Tuple[float, dict]] = {}
_schema_cache_lock = _threading.Lock()
_SCHEMA_L1_TTL = 600   # 10 minutes


def _schema_cache_get(key: str):
    import time as _time
    with _schema_cache_lock:
        if key in _schema_cache:
            ts, result = _schema_cache[key]
            if _time.time() - ts < _SCHEMA_L1_TTL:
                return result
    return None


def _schema_cache_set(key: str, result: dict):
    import time as _time
    with _schema_cache_lock:
        if len(_schema_cache) > 200:
            oldest = min(_schema_cache, key=lambda k: _schema_cache[k][0])
            del _schema_cache[oldest]
        _schema_cache[key] = (_time.time(), result)


# ── Partition cache: L1 in-memory (5 min) + L2 SQLite (5 hours) ──────────────
_partition_cache: Dict[str, Tuple[float, dict]] = {}
_partition_cache_lock = _threading.Lock()
_PARTITION_L1_TTL = 300      # 5 minutes — hot in-memory cache
_PARTITION_L2_TTL = 18000    # 5 hours — persistent SQLite cache
_PARTITION_CACHE_MAX = 100   # max L1 entries


def _partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns (hit, result)."""
    import time as _time
    with _partition_cache_lock:
        if cache_key in _partition_cache:
            ts, result = _partition_cache[cache_key]
            if _time.time() - ts < _PARTITION_L1_TTL:
                return True, result
    return False, None


def _partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    import time as _time
    with _partition_cache_lock:
        if len(_partition_cache) >= _PARTITION_CACHE_MAX:
            oldest = min(_partition_cache, key=lambda k: _partition_cache[k][0])
            del _partition_cache[oldest]
        _partition_cache[cache_key] = (_time.time(), result)


def _partition_l2_get(connection_id: int, table_name: str, scan_type: str):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = db_manager.get_partition_cache(connection_id, table_name, scan_type)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _PARTITION_L2_TTL:
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def _partition_store(connection_id: int, table_name: str, scan_type: str,
                     cache_key: str, result: dict):
    """Store in both L1 + L2.  Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    _partition_l1_set(cache_key, stamped)
    db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped)


@app.on_event("startup")
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    loop = asyncio.get_running_loop()
    # Phase 29: initialise unified auth dependency (api/deps.py)
    from api.deps import init_deps as _init_deps
    _init_deps(_auth_cfg, db_manager)
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=_auth_cfg)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_reports_auth(_auth_cfg)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_schedules_auth(_auth_cfg)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Phase 23: Enterprise reporting wiring
    try:
        from core.email_service import EmailService as _EmailSvc
        _esvc = _EmailSvc()
    except Exception:
        _esvc = None

    set_catalog_dependencies(db_manager, _auth_cfg)
    set_enterprise_dependencies(db_manager, _auth_cfg, email_service=_esvc)

    # PDF export: provide a sync execute function from reports_api
    def _pdf_execute_fn(report_id, param_values, username, limit=10000):
        from api.reports_api import _execute_report_sync
        return _execute_report_sync(report_id, param_values, username, limit=limit)

    set_pdf_dependencies(db_manager, _auth_cfg, _pdf_execute_fn)
    set_burst_dependencies(db_manager, _auth_cfg, _pdf_execute_fn, email_service=_esvc)
    set_profile_dependencies(db_manager, _auth_cfg)
    set_workspace_dependencies(db_manager, _auth_cfg)
    db_manager.ensure_default_workspace()
    set_lineage_dependencies(db_manager)
    set_embed_dependencies(db_manager, _auth_cfg)
    set_suggest_dependencies(db_manager)

    # Phase 29: wire domain routers
    from core.execution_state import set_global_sem as _set_sem
    _set_sem(_global_query_sem)
    set_auth_dependencies(limiter, _auth_cfg)
    set_notification_dependencies(db_manager)
    set_system_dependencies(db_manager, engine, _paths, _qe_cfg,
                             prom_pool_active=_prom_pool_active,
                             prom_pool_queued=_prom_pool_queued)
    set_admin_dependencies(db_manager, engine, _paths, _qe_cfg, _auth_cfg, ws_manager)
    set_connection_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg, _lt_cfg)
    set_query_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg,
                           _qe_cfg, _limits_cfg, _features_cfg, ws_manager=ws_manager)
    set_mv_dependencies(db_manager, engine, conn_manager, ws_manager, _mv_cfg)
    set_local_table_dependencies(db_manager, engine, ws_manager, _lt_cfg, _mv_cfg, _paths,
                                  light_executor=_get_light_executor())
    # Provide the _register_s3_views function to mv_router (defined at module level below)
    _mv_api_module._register_s3_views = _register_s3_views

    # Phase 42: Arrow IPC
    set_arrow_dependencies(db_manager, _auth_cfg)

    # Phase 22F: Wire GraphQL dependencies
    if _graphql_available:
        try:
            set_graphql_dependencies(db_manager, _auth_cfg)
        except Exception as _gql_exc:
            logger.debug("GraphQL dependency wiring skipped: %s", _gql_exc)

    # Initialise unified worker pool
    from core.config import worker_pool as _wp_cfg
    from core.worker_pool import init_pool
    init_pool(
        total_workers=_wp_cfg.total_workers,
        type_configs=_wp_cfg.build_type_configs(),
        drain_timeout=_wp_cfg.drain_timeout_seconds,
    )

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # ── Circuit breaker initialisation ───────────────────────────────────
    from core.circuit_breaker import init_circuit_breaker, set_broadcast_fn as cb_set_broadcast
    from core.config import circuit_breaker as _cb_cfg
    init_circuit_breaker(
        enabled=_cb_cfg.enabled,
        failure_threshold=_cb_cfg.failure_threshold,
        cooldown_seconds=_cb_cfg.cooldown_seconds,
    )

    def _cb_ws_broadcast(payload):
        """Sync broadcast helper for circuit breaker (called from thread-locked code)."""
        asyncio.run_coroutine_threadsafe(ws_manager.broadcast(payload), loop)

    cb_set_broadcast(_cb_ws_broadcast)

    # ── Anomaly detection initialisation (Phase 38) ──────────────────────
    from core.anomaly_detector import init_anomaly_detector
    from core.config import anomaly_detection as _anom_cfg
    init_anomaly_detector(
        enabled=_anom_cfg.enabled,
        z_score_threshold=_anom_cfg.z_score_threshold,
        min_history_runs=_anom_cfg.min_history_runs,
        window_size=_anom_cfg.window_size,
    )

    # ── Connection pool initialisation (Phase 40) ─────────────────────────
    from core.connection_pool import init_connection_pool
    from core.config import connection_pool as _pool_cfg
    init_connection_pool(
        enabled=_pool_cfg.enabled,
        max_size=_pool_cfg.max_size,
        idle_timeout_seconds=_pool_cfg.idle_timeout_seconds,
    )

    # ── Checkpoint recovery (Phase 41) ────────────────────────────────────
    from core.checkpoint import init_checkpoint, recover_incomplete
    init_checkpoint(db_manager)
    _recovered = recover_incomplete()
    if _recovered:
        logger.info("Checkpoint: recovered %d orphaned executions", _recovered)

    # ── Queue backend initialisation ─────────────────────────────────────
    from core.queue_backend import init_queue_backend
    init_queue_backend(db_manager)
    logger.info("Queue backend initialised")

    # ── Scheduler initialisation (mode-dependent) ──────────────────────────
    from core.config import scheduler as _sched_cfg
    import threading as _threading

    if _sched_cfg.mode == "external":
        # External mode: scheduler runs in scheduler_worker.py.
        # Start a notification poller/subscriber to relay WS notifications.
        from core.config import queue as _queue_cfg
        global _notification_poller_task
        if _queue_cfg.backend == "redis":
            from core.notification_poller import run_notification_subscriber
            from core.queue_backend import get_notification_queue
            _notification_poller_task = asyncio.create_task(
                run_notification_subscriber(get_notification_queue(), ws_manager)
            )
            logger.info("Scheduler mode=external — notification subscriber started (Redis pub/sub)")
        else:
            from core.notification_poller import run_notification_poller
            _notification_poller_task = asyncio.create_task(
                run_notification_poller(
                    db_manager.SessionLocal,
                    ws_manager,
                    interval=_sched_cfg.notification_poll_interval,
                )
            )
            logger.info("Scheduler mode=external — notification poller started (%.1fs interval)",
                         _sched_cfg.notification_poll_interval)
    else:
        # Embedded mode (default): start APScheduler in-process, same as before.
        from core.scheduler import init_scheduler, set_broadcast_fn

        def _ws_broadcast(payload):
            asyncio.run_coroutine_threadsafe(ws_manager.broadcast(payload), loop)

        set_broadcast_fn(_ws_broadcast)

        def _start_scheduler():
            try:
                init_scheduler(db_manager, db_url=_DB_URL)
            except Exception as exc:
                logger.error("APScheduler startup failed (non-fatal): %s", exc, exc_info=True)

        _threading.Thread(target=_start_scheduler, daemon=True).start()

    # ── Executor poller (external mode only) ──────────────────────────────
    from core.config import executor as _exec_cfg
    if _exec_cfg.mode == "external":
        from core.config import queue as _queue_cfg2
        global _executor_poller_task
        if _queue_cfg2.backend == "redis":
            from core.executor_poller import run_executor_subscriber
            from core.queue_backend import get_task_queue
            _executor_poller_task = asyncio.create_task(
                run_executor_subscriber(get_task_queue(), ws_manager)
            )
            logger.info("Executor mode=external — subscriber started (Redis pub/sub)")
        else:
            from core.executor_poller import run_executor_poller
            _executor_poller_task = asyncio.create_task(
                run_executor_poller(db_manager, ws_manager, _exec_cfg.notification_poll_interval)
            )
            logger.info("Executor mode=external — poller started (%.1fs interval)",
                         _exec_cfg.notification_poll_interval)

    # ── WebSocket heartbeat (detect dead connections) ─────────────────────
    await ws_manager.start_heartbeat(interval=30)
    logger.info("WebSocket heartbeat started (30s interval)")

    # Mark any executions stuck in "running" state as failed.
    # These are orphaned by a previous server crash or forced restart.
    try:
        stuck = db_manager.list_executions(status="running", limit=1000, offset=0)
        for ex in stuck:
            db_manager.update_execution(
                ex["execution_id"],
                status="failed",
                error_message="Server restarted while execution was in progress",
            )
        if stuck:
            logger.warning(
                "Startup: marked %d orphaned 'running' execution(s) as failed", len(stuck)
            )
    except Exception as _e:
        logger.warning("Startup: orphan execution cleanup failed: %s", _e)

    # Auto-migrate plain-text passwords → PBKDF2 hashes
    if _auth_cfg.type == "local":
        _migrate_plaintext_passwords()


def _migrate_plaintext_passwords():
    """One-time migration: hash any plain-text passwords found in config.json."""
    import json as _json
    from core.ad_auth import hash_password as _hash_pw, _PBKDF2_PREFIX

    config_file = Path(__file__).resolve().parent / "config.json"
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = _json.load(f)
    except Exception:
        return

    raw_users = cfg.get("auth", {}).get("local_users", "")
    if not raw_users:
        return

    users_dict = {}
    migrated_count = 0
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            u, p = u.strip(), p.strip()
            if not p.startswith(_PBKDF2_PREFIX):
                users_dict[u] = _hash_pw(p)
                migrated_count += 1
            else:
                users_dict[u] = p

    if migrated_count > 0:
        cfg["auth"]["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
        with open(config_file, "w", encoding="utf-8") as f:
            _json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Reload in-memory config
        from core import config as _config_mod
        _config_mod._file_cfg = _config_mod._load_file()
        _config_mod._merged = _config_mod._deep_merge(_config_mod._DEFAULTS, _config_mod._file_cfg)
        _config_mod._cfg = _config_mod._apply_env(_config_mod._merged)
        logger.info("Migrated %d plain-text password(s) to PBKDF2 hashes", migrated_count)


@app.on_event("shutdown")
async def _shutdown():
    logger.info("Shutdown: draining %d in-flight queries (5 s grace)…", len(_running_tasks))
    # Signal all threads to stop at next chunk boundary
    for _ev in list(_cancellation_flags.values()):
        _ev.set()
    # Cancel all asyncio tasks
    _pending = [t for t in _running_tasks.values() if not t.done()]
    for t in _pending:
        t.cancel()
    if _pending:
        await asyncio.gather(*_pending, return_exceptions=True)

    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "embedded":
        from core.scheduler import shutdown_scheduler
        shutdown_scheduler()
    else:
        # External mode — cancel the notification poller task
        if _notification_poller_task and not _notification_poller_task.done():
            _notification_poller_task.cancel()

    # Cancel executor poller if running (external mode)
    if _executor_poller_task and not _executor_poller_task.done():
        _executor_poller_task.cancel()

    # Stop WebSocket heartbeat
    await ws_manager.stop_heartbeat()

    # Don't wait=True — it blocks forever if threads hold locks
    query_executor.shutdown(wait=False, cancel_futures=True)
    _streaming_executor.shutdown(wait=False, cancel_futures=True)

    # Shut down the unified worker pool
    from core.worker_pool import get_pool
    try:
        await get_pool().shutdown()
    except RuntimeError:
        pass  # pool not initialised (tests, etc.)


# ── Forced exit on Ctrl+C ──────────────────────────────────────────────────
# On Windows, uvicorn sometimes can't cleanly terminate threads (DuckDB
# connections, APScheduler, etc.). After the first SIGINT the graceful
# shutdown runs; a second SIGINT (or 5 s timeout) force-kills the process.
import signal as _signal

_SIGINT_COUNT = 0

def _force_exit_handler(signum, frame):
    global _SIGINT_COUNT
    _SIGINT_COUNT += 1
    if _SIGINT_COUNT == 1:
        print("\n[SHUTDOWN] Ctrl+C — stopping server…", flush=True)
        # Give uvicorn 3 seconds to drain, then force-exit cleanly.
        # Don't raise KeyboardInterrupt — it causes noisy asyncio tracebacks.
        def _delayed_exit():
            import time; time.sleep(3)
            print("[SHUTDOWN] Done.", flush=True)
            os._exit(0)
        _threading.Thread(target=_delayed_exit, daemon=True).start()
    else:
        print("[SHUTDOWN] Force exit!", flush=True)
        os._exit(1)

if sys.platform == "win32":
    _signal.signal(_signal.SIGINT, _force_exit_handler)
    try:
        _signal.signal(_signal.SIGBREAK, _force_exit_handler)
    except (AttributeError, OSError):
        pass
else:
    # Linux/Docker: handle SIGTERM (sent by `docker stop`, k8s pod termination)
    _signal.signal(_signal.SIGINT, _force_exit_handler)
    _signal.signal(_signal.SIGTERM, _force_exit_handler)


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        logger.warning("WebSocket connection closed unexpectedly: %s", e)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    await _handle_ws(websocket)


# ── Materialized Views ─────────────────────────────────────────────────────────

class MaterializedViewCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    connection_id: int
    table_name: str
    table_format: str = "parquet"
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None

class MaterializedViewUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    is_active: Optional[bool] = None


def _refresh_materialized_view_sync(mv_id: int):
    """Core refresh logic — downloads S3 data to local parquet files."""
    import time as _t
    import shutil
    import pyarrow as pa
    import pyarrow.parquet as pq

    mv = db_manager.get_materialized_view(mv_id)
    if not mv:
        logger.error("MV refresh: view %d not found", mv_id)
        return

    db_manager.update_materialized_view(mv_id, status="refreshing", last_error=None)
    _start = _t.monotonic()

    try:
        # Load connection
        conn = db_manager.get_connection(mv["connection_id"])
        if not conn:
            raise ValueError(f"Connection {mv['connection_id']} not found")
        cfg = conn["config"]
        bucket = cfg.get("bucket_name", "")

        # Get registered tables for this connection
        registered_tables = cfg.get("registered_tables", [])
        target_table = None
        for rt in registered_tables:
            if rt["name"] == mv["table_name"]:
                target_table = rt
                break
        if not target_table:
            raise ValueError(f"Registered table '{mv['table_name']}' not found in connection")

        # Open DuckDB connection with S3 credentials
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg)

        # Register only the target table
        _register_s3_views(con, [target_table], bucket, mv["connection_id"], cfg,
                          referenced_tables={mv["table_name"]})

        # Build query
        tname_safe = '"' + mv["table_name"].replace('"', '""') + '"'
        sql = f"SELECT * FROM {tname_safe}"
        where_parts = []

        # Apply partition filter
        pf = mv.get("partition_filter")
        if pf and pf.get("date_col"):
            date_col = pf["date_col"].replace('"', '""')
            if pf.get("from"):
                where_parts.append(f'"{date_col}" >= \'{pf["from"]}\'')
            if pf.get("to"):
                where_parts.append(f'"{date_col}" <= \'{pf["to"]}\'')

        # Apply query filter
        if mv.get("query_filter"):
            where_parts.append(f"({mv['query_filter']})")

        if where_parts:
            sql += " WHERE " + " AND ".join(where_parts)

        logger.info("MV refresh %d '%s': SQL = %s", mv_id, mv["name"], sql[:500])

        # Execute and write to local parquet
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
        # Clear old data
        if os.path.exists(mv_dir):
            shutil.rmtree(mv_dir)
        os.makedirs(mv_dir, exist_ok=True)

        chunk_size = _mv_cfg.chunk_size
        result = con.execute(sql)
        total_rows = 0
        file_idx = 0
        total_size = 0

        while True:
            batch = result.fetchmany(chunk_size)
            if not batch:
                break
            # Convert to pyarrow
            cols = [desc[0] for desc in result.description]
            table = pa.table({col: [row[i] for row in batch] for i, col in enumerate(cols)})
            out_path = os.path.join(mv_dir, f"part_{file_idx:04d}.parquet")
            pq.write_table(table, out_path, compression="snappy")
            total_rows += len(batch)
            total_size += os.path.getsize(out_path)
            file_idx += 1

        con.close()

        elapsed = _t.monotonic() - _start
        db_manager.update_materialized_view(mv_id,
            status="ready",
            row_count=total_rows,
            file_count=file_idx,
            size_bytes=total_size,
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
            last_error=None,
        )
        logger.info("MV refresh %d '%s': %d rows, %d files, %.1f MB in %.1fs",
                    mv_id, mv["name"], total_rows, file_idx, total_size / 1048576, elapsed)

        # WebSocket notification
        try:
            ws_manager.broadcast_sync({
                "type": "materialized_view_refreshed",
                "mv_id": mv_id,
                "name": mv["name"],
                "row_count": total_rows,
                "size_bytes": total_size,
            })
        except Exception:
            pass

    except Exception as e:
        elapsed = _t.monotonic() - _start
        logger.error("MV refresh %d failed after %.1fs: %s", mv_id, elapsed, e, exc_info=True)
        db_manager.update_materialized_view(mv_id,
            status="failed",
            last_error=str(e),
            last_refresh_at=datetime.now(timezone.utc),
            last_refresh_duration=round(elapsed, 2),
        )
        try:
            ws_manager.broadcast_sync({
                "type": "materialized_view_failed",
                "mv_id": mv_id,
                "name": mv.get("name", ""),
                "error": str(e)[:500],
            })
        except Exception:
            pass


def _setup_mv_schedule(mv_id: int, schedule_config: dict, mv_name: str = ""):
    """Register or update APScheduler job for MV auto-refresh."""
    from core.scheduler import _build_trigger
    import uuid as _uuid
    # Get global scheduler
    try:
        from core.scheduler import _scheduler
        if not _scheduler or not _scheduler.running:
            logger.warning("Scheduler not running — MV schedule not set for %d", mv_id)
            return None
    except Exception:
        return None

    job_id = f"mv_{mv_id}_{_uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_config)
    _scheduler.add_job(
        func=_refresh_materialized_view_sync,
        trigger=trigger,
        id=job_id,
        args=[mv_id],
        name=f"MV: {mv_name or mv_id}",
        replace_existing=True,
    )
    job = _scheduler.get_job(job_id)
    next_run = job.next_run_time if job else None
    db_manager.update_materialized_view(mv_id, apscheduler_job_id=job_id,
                                         next_refresh_at=next_run)
    return job_id


def _remove_mv_schedule(job_id: str):
    """Remove APScheduler job for MV."""
    try:
        from core.scheduler import _scheduler
        if _scheduler and job_id and _scheduler.get_job(job_id):
            _scheduler.remove_job(job_id)
    except Exception:
        pass

class LocalTableCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10

class LocalTableUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    visibility: Optional[str] = None
    auto_discard_days: Optional[int] = None
    is_active: Optional[bool] = None

class LocalTablePromoteModel(BaseModel):
    file_id: str
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


def _promote_download_sync(lt_id: int, source_path: str):
    """Copy a download parquet file into local table storage and read metadata."""
    import shutil
    import pyarrow.parquet as _pq

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)

    try:
        # Copy parquet file (don't move — keeps download intact)
        dest = os.path.join(lt_dir, "data.parquet")
        shutil.copy2(source_path, dest)

        # Read schema + metadata
        pf = _pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for i, field in enumerate(pf.schema_arrow):
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        from datetime import datetime, timezone
        db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d promoted successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table promote failed for %d: %s", lt_id, e)
        db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass


def _upload_file_to_local_table_sync(lt_id: int, temp_path: str, original_filename: str):
    """Convert uploaded file (CSV/Excel/JSON/Parquet) to local parquet."""
    import shutil
    import duckdb as _ddb

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)
    dest = os.path.join(lt_dir, "data.parquet")
    ext = os.path.splitext(original_filename)[1].lower()

    try:
        if ext == ".parquet":
            shutil.copy2(temp_path, dest)
        else:
            con = _ddb.connect()
            try:
                temp_fixed = temp_path.replace("\\", "/")
                dest_fixed = dest.replace("\\", "/")
                if ext in (".csv", ".tsv", ".txt"):
                    con.execute(f"COPY (SELECT * FROM read_csv_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                elif ext in (".xlsx", ".xls"):
                    # Try DuckDB spatial extension for Excel
                    try:
                        con.execute("INSTALL spatial; LOAD spatial;")
                        con.execute(f"COPY (SELECT * FROM st_read('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                    except Exception:
                        # Fallback to pandas
                        import pandas as pd
                        df = pd.read_excel(temp_path)
                        df.to_parquet(dest, index=False)
                elif ext == ".json":
                    con.execute(f"COPY (SELECT * FROM read_json_auto('{temp_fixed}')) TO '{dest_fixed}' (FORMAT PARQUET)")
                else:
                    raise ValueError(f"Unsupported file type: {ext}")
            finally:
                con.close()

        # Read final parquet metadata
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = []
        for field in pf.schema_arrow:
            schema_cols.append({"name": field.name, "type": str(field.type), "nullable": field.nullable})

        from datetime import datetime, timezone
        db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d uploaded successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            ws_manager.broadcast_sync({"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count})
        except Exception:
            pass
    except Exception as e:
        logger.error("Local table upload failed for %d: %s", lt_id, e)
        db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            ws_manager.broadcast_sync({"type": "local_table_failed", "id": lt_id, "error": str(e)})
        except Exception:
            pass
    finally:
        # Cleanup temp file
        try:
            os.unlink(temp_path)
        except Exception:
            pass


def _cleanup_expired_local_tables():
    """Auto-discard public local tables unused beyond their auto_discard_days."""
    import shutil
    expired = db_manager.list_expired_local_tables()
    count = 0
    for lt in expired:
        try:
            lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt["id"]))
            if os.path.isdir(lt_dir):
                shutil.rmtree(lt_dir)
            db_manager.delete_local_table(lt["id"])
            count += 1
            logger.info("Auto-discarded local table %d (%s) — unused for %d+ days",
                        lt["id"], lt["name"], lt["auto_discard_days"])
        except Exception as e:
            logger.warning("Failed to discard local table %d: %s", lt["id"], e)
    if count > 0:
        try:
            ws_manager.broadcast_sync({"type": "local_tables_cleanup", "discarded_count": count})
        except Exception:
            pass
        logger.info("Auto-discard cleaned up %d expired local tables", count)

def _resolve_table_duckdb_sql(table_path: str, connection_id: int = None) -> tuple:
    """Resolve a table_path to a DuckDB-compatible FROM clause + optional DuckDB connection.

    Returns (from_clause: str, con: duckdb.Connection | None, needs_close: bool).
    If con is returned, caller must close it.
    """
    import duckdb as _ddb

    if table_path.startswith("__materialized__:"):
        mv_name = table_path.replace("__materialized__:", "")
        mv_rec = db_manager.get_materialized_view_by_name(mv_name)
        if not mv_rec or mv_rec["status"] != "ready":
            raise ValueError(f"Materialized view '{mv_name}' not found or not ready")
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_rec["id"]))
        import glob as _gm
        pq_files = _gm.glob(os.path.join(mv_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for MV '{mv_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__local__:"):
        lt_name = table_path.replace("__local__:", "")
        lt_rec = db_manager.get_local_table_by_name(lt_name)
        if not lt_rec or lt_rec["status"] != "ready":
            raise ValueError(f"Local table '{lt_name}' not found or not ready")
        lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_rec["id"]))
        import glob as _gm2
        pq_files = _gm2.glob(os.path.join(lt_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for local table '{lt_name}'")
        paths_str = ", ".join(f"'{p.replace(chr(92), '/')}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__registered__:"):
        reg_name = table_path.replace("__registered__:", "")
        if not connection_id:
            raise ValueError("connection_id required for registered table preview")
        conn_record = db_manager.get_connection_raw(connection_id)
        if not conn_record:
            raise ValueError(f"Connection {connection_id} not found")
        cfg = conn_record.get("config", {})
        registered_tables = cfg.get("registered_tables", [])
        tdef = None
        for t in registered_tables:
            if t["name"] == reg_name:
                tdef = t
                break
        if not tdef:
            raise ValueError(f"Registered table '{reg_name}' not found in connection")
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg, connection_id=connection_id)
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        bucket = cfg["bucket_name"]
        if fmt == "iceberg":
            from_clause = f"iceberg_scan('s3://{bucket}/{prefix}')"
        elif fmt == "csv":
            from_clause = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
        else:
            from_clause = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
        return from_clause, con, True

    # Raw file path — local parquet or csv
    norm = table_path.replace("\\", "/")
    if norm.lower().endswith(".csv"):
        return f"read_csv_auto('{norm}')", None, False
    return f"read_parquet('{norm}', hive_partitioning=true)", None, False
if _STATIC_DIR:
    @app.get("/", include_in_schema=False)
    async def _spa_root():
        return FileResponse(str(_STATIC_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def _spa_catch_all(full_path: str):
        return FileResponse(str(_STATIC_DIR / "index.html"))
else:
    @app.get("/")
    async def _api_root():
        return {
            "name": "QueryStudio API",
            "version": API_VERSION,
            "api_version": API_MAJOR,
            "status": "operational",
            "note": "Build the frontend (`npm run build` in frontend/) to enable SPA serving.",
        }


def run_server(host=None, port=None, workers=None, log_level=None):
    """Start the FastAPI webserver.  Called by ``querystudio`` CLI."""
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    uvicorn.run(
        app,
        host=host or _server_cfg.host,
        port=port or _server_cfg.port,
        log_level=log_level or _server_cfg.log_level,
        workers=workers or _server_cfg.workers,
    )


if __name__ == "__main__":
    run_server()
