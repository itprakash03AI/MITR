// @ts-nocheck
/**
 * AssistantContext — shares the current page's connection/schema context
 * with GlobalAssistantPanel so it can produce smarter NL→SQL and schema
 * answers without needing an LLM.
 *
 * Usage (in any page component):
 *   const { setAssistantCtx } = useAssistantContext();
 *   useEffect(() => { setAssistantCtx({ connectionId: 3, tables: ['orders', 'customers'] }); }, []);
 */
import React, { createContext, useContext, useState } from 'react';

export interface AssistantCtxValue {
  connectionId?: number;
  connectionType?: string;   // e.g. 'duckdb', 'snowflake', 'trino'
  tables: string[];
  columns: Record<string, string[]>;   // table → column list
  pageName?: string;                   // e.g. 'sql', 'query-builder'
  // Active result grid context (set by DataGridViewer when results load)
  executionId?: string;
  resultColumns?: string[];            // column names from the current grid result
  setAssistantCtx: (update: Partial<Omit<AssistantCtxValue, 'setAssistantCtx'>>) => void;
}

const AssistantContext = createContext<AssistantCtxValue>({
  tables: [],
  columns: {},
  setAssistantCtx: () => {},
});

export const AssistantContextProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<Omit<AssistantCtxValue, 'setAssistantCtx'>>({
    tables: [],
    columns: {},
  });
  return (
    <AssistantContext.Provider
      value={{
        ...state,
        setAssistantCtx: (update) => setState(prev => ({ ...prev, ...update })),
      }}
    >
      {children}
    </AssistantContext.Provider>
  );
};

export const useAssistantContext = () => useContext(AssistantContext);
