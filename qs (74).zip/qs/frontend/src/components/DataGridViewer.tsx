import React, { useState, useEffect, useRef, useMemo, useCallback, memo } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Box, Typography, Button, Paper, IconButton, Tooltip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TableSortLabel,
  TextField, MenuItem, Select, Menu, ToggleButtonGroup, ToggleButton,
  CircularProgress, LinearProgress, Alert, Chip, Divider, Skeleton,
  FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions,
  Checkbox, InputAdornment, Popover, Autocomplete, Stack,
} from '@mui/material';
import {
  Download as DownloadIcon, Close as CloseIcon, Refresh as RefreshIcon,
  FilterList as FilterIcon, TableChart as TableIcon, BarChart as ChartIcon,
  PivotTableChart as PivotIcon, FirstPage, LastPage, NavigateBefore, NavigateNext,
  InsertDriveFile as CsvIcon, TableView as ExcelIcon, DataObject as JsonIcon,
  Add as AddIcon, Delete as DeleteIcon,
  ViewColumn as ColumnsIcon, PushPin as PinIcon, Search as SearchIcon,
  InfoOutlined as InfoIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell, ScatterChart, Scatter, ZAxis,
  XAxis, YAxis, CartesianGrid, Tooltip as RTooltip,
  Legend, ResponsiveContainer,
  ComposedChart,
} from 'recharts';
import { getAuthHeader } from '../context/AuthContext';
import { useAppSettings } from '../context/AppSettingsContext';
import { useAssistantContext } from '../context/AssistantContext';
import { toBackendQueryConfig } from '../services/api';
import { classifyColumns, suggestChart, suggestPivot, generatePivotPresets, PivotPreset } from '../services/columnIntelligence';

const _authHeaders = () => { const h = getAuthHeader(); return h ? { Authorization: h } : {}; };

const API_BASE_URL = import.meta.env.VITE_API_URL || '';
const FROZEN_COL_WIDTH = 160;
const DEFAULT_MAX_VIS_COLS = 50;   // fallback if admin config unavailable

// ─────────────────────────────────────────────────────────────
// Number formatting
// ─────────────────────────────────────────────────────────────
const SCIENTIFIC_RE = /^-?[\d.]+[eE][+-]?\d+$/;

const fmtNum = (v) => {
  if (v == null || (typeof v === 'number' && isNaN(v))) return '—';
  const num = typeof v === 'string' ? parseFloat(v) : v;
  if (isNaN(num)) return String(v);
  const isNeg = num < 0;
  const abs   = Math.abs(num);
  const fmt   = Number.isInteger(abs) && abs < 1e15
    ? abs.toLocaleString()
    : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return isNeg ? `(${fmt})` : fmt;
};

// Pre-defined style objects (defined ONCE outside the component) so that
// formatValue never allocates new objects on the hot render path.
const _S = {
  null: { color: '#9e9e9e', fontStyle: 'italic', fontSize: 11, letterSpacing: '0.02em' },
  boolT: { color: '#2e7d32', fontWeight: 700, fontSize: 11 },
  boolF: { color: '#757575', fontWeight: 600, fontSize: 11 },
  neg:   { color: '#d32f2f', fontVariantNumeric: 'tabular-nums' },
  pos:   { fontVariantNumeric: 'tabular-nums' },
};

// Pure function — no React hooks, no MUI components — safe to call inside a
// tight map() on every cell without React overhead per invocation.
const formatValue = (value) => {
  if (value === null || value === undefined)
    return <span style={_S.null}>NULL</span>;
  if (typeof value === 'boolean')
    return <span style={value ? _S.boolT : _S.boolF}>{value ? 'TRUE' : 'FALSE'}</span>;

  let numVal = typeof value === 'number' ? value : null;
  if (numVal === null && typeof value === 'string' && SCIENTIFIC_RE.test(value.trim())) {
    const p = parseFloat(value.trim());
    if (!isNaN(p)) numVal = p;
  }
  if (numVal !== null) {
    const isNeg = numVal < 0;
    const abs   = Math.abs(numVal);
    const fmt   = Number.isInteger(abs) && abs < 1e15
      ? abs.toLocaleString()
      : abs.toLocaleString(undefined, { maximumFractionDigits: 4 });
    if (isNeg)
      return <span style={_S.neg}>({fmt})</span>;
    return <span style={_S.pos}>{fmt}</span>;
  }
  return value.toString();
};

// ─────────────────────────────────────────────────────────────
// Advanced AND/OR Filter Builder
// ─────────────────────────────────────────────────────────────
const OPERATORS = [
  { value: 'contains',     label: 'Contains' },
  { value: 'not_contains', label: 'Does not contain' },
  { value: 'equals',       label: 'Equals' },
  { value: 'not_equals',   label: 'Not equals' },
  { value: 'starts_with',  label: 'Starts with' },
  { value: 'ends_with',    label: 'Ends with' },
  { value: 'gt',           label: '>' },
  { value: 'gte',          label: '>=' },
  { value: 'lt',           label: '<' },
  { value: 'lte',          label: '<=' },
  { value: 'is_null',      label: 'Is null' },
  { value: 'is_not_null',  label: 'Is not null' },
];

const NO_VALUE_OPS = new Set(['is_null', 'is_not_null']);

const FilterBuilder = ({ columns, value, onChange }) => {
  const { conjunction = 'AND', conditions = [] } = value || {};

  const setConjunction = (c) => onChange({ conjunction: c, conditions });

  const setCondition = (idx, patch) => {
    const next = conditions.map((c, i) => i === idx ? { ...c, ...patch } : c);
    onChange({ conjunction, conditions: next });
  };

  const addCondition = () => onChange({
    conjunction,
    conditions: [...conditions, { col: columns[0] || '', op: 'contains', val: '' }],
  });

  const removeCondition = (idx) => {
    const next = conditions.filter((_, i) => i !== idx);
    onChange({ conjunction, conditions: next });
  };

  return (
    <Box sx={{ px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
        <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mr: 0.5 }}>
          FILTER
        </Typography>
        <ToggleButtonGroup
          value={conjunction} exclusive
          onChange={(_, v) => v && setConjunction(v)}
          size="small"
          sx={{ '& .MuiToggleButton-root': { px: 1.5, py: 0.25, fontSize: 12, fontWeight: 700, minWidth: 44 } }}
        >
          <ToggleButton value="AND">AND</ToggleButton>
          <ToggleButton value="OR">OR</ToggleButton>
        </ToggleButtonGroup>
        <Button size="small" startIcon={<AddIcon sx={{ fontSize: 14 }} />} onClick={addCondition}
          sx={{ fontSize: 12, textTransform: 'none' }}>
          Add condition
        </Button>
        {conditions.length > 0 && (
          <Button size="small" color="error" sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}
            onClick={() => onChange({ conjunction, conditions: [] })}>
            Clear all
          </Button>
        )}
      </Box>

      {conditions.length === 0 && (
        <Typography variant="caption" color="text.disabled" sx={{ pl: 0.5 }}>
          No filters — showing all rows
        </Typography>
      )}

      {conditions.map((cond, idx) => (
        <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.75, flexWrap: 'wrap' }}>
          {idx > 0 && (
            <Chip label={conjunction} size="small" variant="outlined" color="primary"
              sx={{ height: 22, fontSize: 11, fontWeight: 700, minWidth: 36 }} />
          )}
          {idx === 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ minWidth: 36, textAlign: 'center' }}>
              WHERE
            </Typography>
          )}

          <Autocomplete
            size="small"
            options={columns}
            value={columns.includes(cond.col) ? cond.col : (columns[0] || '')}
            onChange={(_, v) => setCondition(idx, { col: v ?? '' })}
            disableClearable
            renderInput={(params) => <TextField {...params} size="small"
              sx={{ '& .MuiInputBase-root': { fontSize: 13 } }} />}
            ListboxProps={{ sx: { maxHeight: 260, '& .MuiAutocomplete-option': { fontSize: 13 } } }}
            sx={{ minWidth: 160 }}
          />

          <FormControl size="small" sx={{ minWidth: 160 }}>
            <Select value={cond.op} onChange={e => setCondition(idx, { op: e.target.value })}
              sx={{ fontSize: 13 }}>
              {OPERATORS.map(o => <MenuItem key={o.value} value={o.value} sx={{ fontSize: 13 }}>{o.label}</MenuItem>)}
            </Select>
          </FormControl>

          {!NO_VALUE_OPS.has(cond.op) && (
            <TextField
              size="small" placeholder="value…" value={cond.val}
              onChange={e => setCondition(idx, { val: e.target.value })}
              onKeyDown={e => e.key === 'Enter' && e.currentTarget.blur()}
              sx={{ minWidth: 160, '& input': { fontSize: 13 } }}
            />
          )}

          <Tooltip title="Remove condition">
            <IconButton size="small" onClick={() => removeCondition(idx)} sx={{ color: 'text.disabled' }}>
              <DeleteIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>
      ))}
    </Box>
  );
};

// ─────────────────────────────────────────────────────────────
// ChartConfig sidebar
// ─────────────────────────────────────────────────────────────
const CHART_TYPES = [
  { value: 'bar', label: 'Bar' },
  { value: 'stacked_bar', label: 'Stacked Bar' },
  { value: 'grouped_bar', label: 'Grouped Bar' },
  { value: 'line', label: 'Line' },
  { value: 'multi_line', label: 'Multi-Line' },
  { value: 'area', label: 'Area' },
  { value: 'stacked_area', label: 'Stacked Area' },
  { value: 'combo', label: 'Combo (Bar+Line)' },
  { value: 'pie', label: 'Pie' },
  { value: 'scatter', label: 'Scatter' },
];

interface ChartConfigProps {
  cols: string[];
  chartType?: string;
  setChartType?: (v: string) => void;
  xCol: string;
  setXCol: (v: string) => void;
  yCol: string;
  setYCol: (v: string) => void;
  agg: string;
  setAgg: (v: string) => void;
  topN: number;
  setTopN: (v: number) => void;
  seriesCol: string;
  setSeriesCol: (v: string) => void;
  onRefresh: () => void;
  xLabel?: string;
  yLabel?: string;
  renderLabel?: string;
  hideChartType?: boolean;
}

/** Searchable single-select column picker (Autocomplete) */
const ColPicker = ({ options, value, onChange, label, allowNone, nonePlaceholder, sx: sxProp }: {
  options: string[]; value: string; onChange: (v: string) => void; label: string;
  allowNone?: boolean; nonePlaceholder?: string; sx?: any;
}) => {
  // When allowNone, treat empty string as "none" selection
  const opts = allowNone ? ['', ...options] : options;
  return (
    <Autocomplete
      size="small"
      options={opts}
      value={opts.includes(value) ? value : (allowNone ? '' : (options[0] || ''))}
      onChange={(_, v) => onChange(v ?? '')}
      getOptionLabel={(o) => o === '' ? (nonePlaceholder || '(None)') : o}
      renderInput={(params) => <TextField {...params} label={label} size="small"
        sx={{ '& .MuiInputBase-root': { fontSize: 13 } }} />}
      sx={{ minWidth: 120, ...sxProp }}
      disableClearable={!allowNone}
      ListboxProps={{ sx: { maxHeight: 260, '& .MuiAutocomplete-option': { fontSize: 13 } } }}
    />
  );
};

const ChartConfig = ({
  cols, chartType, setChartType, xCol, setXCol, yCol, setYCol,
  agg, setAgg, topN, setTopN, seriesCol, setSeriesCol, onRefresh,
  xLabel, yLabel, renderLabel, hideChartType,
}: ChartConfigProps) => (
  <Box sx={{ width: 220, flexShrink: 0, p: 2, borderRight: 1, borderColor: 'divider', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
    {!hideChartType && (
      <TextField select label="Chart type" size="small" value={chartType} onChange={e => setChartType?.(e.target.value)}>
        {CHART_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
      </TextField>
    )}
    <ColPicker options={cols} value={xCol} onChange={setXCol} label={xLabel || 'X-axis / Group By'} />
    <ColPicker options={cols} value={yCol} onChange={setYCol} label={yLabel || 'Y-axis / Value'} />
    <ColPicker options={cols} value={seriesCol} onChange={setSeriesCol}
      label="Series / Break By" allowNone nonePlaceholder="(None — single series)" />
    <TextField select label="Aggregation" size="small" value={agg} onChange={e => setAgg(e.target.value)}>
      {['sum','avg','count','max','min'].map(a => <MenuItem key={a} value={a}>{a.toUpperCase()}</MenuItem>)}
    </TextField>
    <TextField select label="Top N" size="small" value={topN} onChange={e => setTopN(+e.target.value)}>
      {[10,20,50,100,200].map(n => <MenuItem key={n} value={n}>Top {n}</MenuItem>)}
    </TextField>
    <Button variant="contained" size="small" onClick={onRefresh}>{renderLabel || 'Render'}</Button>
  </Box>
);

// ─────────────────────────────────────────────────────────────
// Chart helpers
// ─────────────────────────────────────────────────────────────
const CHART_COLORS = [
  '#2563EB','#DC2626','#059669','#D97706','#7C3AED','#DB2777',
  '#0891B2','#65A30D','#EA580C','#4F46E5','#0D9488','#C026D3',
  '#B91C1C','#15803D','#1D4ED8','#A16207','#6D28D9','#BE185D',
  '#0E7490','#4D7C0F',
];

const fmtAxisNum = (v: any): string => {
  const n = Number(v);
  if (v == null || isNaN(n)) return '';
  const abs = Math.abs(n), sign = n < 0 ? '-' : '';
  if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(1)}B`;
  if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(1)}K`;
  return `${sign}${Number.isInteger(abs) ? abs : abs.toFixed(2)}`;
};

const ChartTooltipContent = ({ active, payload, agg, yCol }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  return (
    <Paper elevation={6} sx={{ p: 1.5, maxWidth: 280, border: '1px solid', borderColor: 'divider' }}>
      <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, wordBreak: 'break-word' }}>{d?.label}</Typography>
      <Typography variant="caption" display="block">{(agg || '').toUpperCase()} {yCol}: <strong>{fmtNum(d?.value)}</strong></Typography>
      <Typography variant="caption" display="block" color="text.secondary">Count: {(d?.count ?? 0).toLocaleString()}</Typography>
      <Typography variant="caption" display="block" color="text.secondary">Share: {d?.pct}%</Typography>
    </Paper>
  );
};

const PieTooltipContent = ({ active, payload, agg, yCol }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  return (
    <Paper elevation={6} sx={{ p: 1.5, maxWidth: 280, border: '1px solid', borderColor: 'divider' }}>
      <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, wordBreak: 'break-word' }}>{d?.label}</Typography>
      <Typography variant="caption" display="block">{(agg || '').toUpperCase()} {yCol}: <strong>{fmtNum(d?.value)}</strong></Typography>
      <Typography variant="caption" display="block" color="text.secondary">Count: {(d?.count ?? 0).toLocaleString()}</Typography>
      <Typography variant="caption" display="block" color="text.secondary">Share: {d?.pct}%</Typography>
    </Paper>
  );
};

const MultiSeriesTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((s: number, p: any) => s + (p.value || 0), 0);
  return (
    <Paper elevation={6} sx={{ p: 1.5, maxWidth: 320, border: '1px solid', borderColor: 'divider' }}>
      <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, wordBreak: 'break-word' }}>{label}</Typography>
      {payload.map((p: any, i: number) => (
        <Box key={i} sx={{ display: 'flex', gap: 1, alignItems: 'center', mb: 0.25 }}>
          <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: p.color, flexShrink: 0 }} />
          <Typography variant="caption">{p.name}: <strong>{fmtNum(p.value)}</strong></Typography>
        </Box>
      ))}
      <Divider sx={{ my: 0.5 }} />
      <Typography variant="caption"><strong>Total: {fmtNum(total)}</strong></Typography>
    </Paper>
  );
};

// ─────────────────────────────────────────────────────────────
// ChartRenderer — Recharts-powered with axes, tooltips, legends
// ─────────────────────────────────────────────────────────────
const ChartRenderer = ({ data, type }: { data: any; type: string }) => {
  if (!data?.data?.length)
    return <Typography color="text.secondary" sx={{ p: 4, textAlign: 'center' }}>No data — configure columns and click Render</Typography>;

  const agg  = data.agg  || 'sum';
  const yCol = data.y_col || 'value';
  const xCol = data.x_col || 'label';
  const isMulti = data.multi && data.series?.length > 0;
  const series: string[] = data.series || [];
  const items = data.data.map((d: any) => ({
    ...d,
    shortLabel: d.label != null && String(d.label).length > 18 ? String(d.label).slice(0, 17) + '…' : String(d.label ?? ''),
  }));

  const seriesName = `${agg.toUpperCase()}(${yCol})`;
  const commonMargin = { top: 16, right: 32, left: 16, bottom: 90 };
  const tooltipEl = <ChartTooltipContent agg={agg} yCol={yCol} />;
  const multiTooltip = <MultiSeriesTooltip />;

  const xAxisProps: any = {
    dataKey: 'shortLabel',
    tick: { fontSize: 11 },
    angle: -38,
    textAnchor: 'end',
    height: 90,
    interval: 0,
    label: { value: xCol, position: 'insideBottom', offset: -4, fontSize: 12, fill: '#666' },
  };
  const yAxisProps: any = {
    tickFormatter: fmtAxisNum,
    tick: { fontSize: 11 },
    width: 72,
    label: { value: isMulti ? yCol : seriesName, angle: -90, position: 'insideLeft', offset: 14, fontSize: 12, fill: '#666' },
  };

  const footer = (
    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', px: 2, pb: 1 }}>
      {data.groups} groups · {Number(data.total_rows).toLocaleString()} total rows
      {isMulti && ` · ${series.length} series`}
      {' '}· Grand total: <strong>{fmtNum(data.grand_total)}</strong>
    </Typography>
  );

  /* ── Stacked Bar (multi-series) ── */
  if (type === 'stacked_bar' && isMulti) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <BarChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={multiTooltip} cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
          <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          {series.map((s, i) => (
            <Bar key={s} dataKey={s} stackId="a" fill={CHART_COLORS[i % CHART_COLORS.length]}
              radius={i === series.length - 1 ? [3,3,0,0] : [0,0,0,0]}
              isAnimationActive animationDuration={800} animationBegin={i * 100} />
          ))}
        </BarChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Grouped Bar (multi-series) ── */
  if (type === 'grouped_bar' && isMulti) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <BarChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={multiTooltip} cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
          <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          {series.map((s, i) => (
            <Bar key={s} dataKey={s} fill={CHART_COLORS[i % CHART_COLORS.length]}
              radius={[3,3,0,0]} maxBarSize={40}
              isAnimationActive animationDuration={800} animationBegin={i * 100} />
          ))}
        </BarChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Multi-Line (multi-series) ── */
  if (type === 'multi_line' && isMulti) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <LineChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={multiTooltip} />
          <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          {series.map((s, i) => (
            <Line key={s} dataKey={s} type="monotone" stroke={CHART_COLORS[i % CHART_COLORS.length]}
              strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 6 }}
              isAnimationActive animationDuration={1000} animationBegin={i * 150} />
          ))}
        </LineChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Stacked Area (multi-series) ── */
  if (type === 'stacked_area' && isMulti) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <AreaChart data={items} margin={commonMargin}>
          <defs>
            {series.map((s, i) => (
              <linearGradient key={s} id={`msGrad_${i}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={CHART_COLORS[i % CHART_COLORS.length]} stopOpacity={0.3} />
                <stop offset="95%" stopColor={CHART_COLORS[i % CHART_COLORS.length]} stopOpacity={0.05} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={multiTooltip} />
          <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          {series.map((s, i) => (
            <Area key={s} dataKey={s} type="monotone" stackId="a"
              stroke={CHART_COLORS[i % CHART_COLORS.length]} fill={`url(#msGrad_${i})`}
              strokeWidth={2} isAnimationActive animationDuration={800} animationBegin={i * 100} />
          ))}
        </AreaChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Combo: Bar+Line (multi-series) — first series as bars, rest as lines ── */
  if (type === 'combo' && isMulti) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <ComposedChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={multiTooltip} />
          <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Bar key={series[0]} dataKey={series[0]} fill={CHART_COLORS[0]} radius={[3,3,0,0]} maxBarSize={50} opacity={0.85}
            isAnimationActive animationDuration={800} />
          {series.slice(1).map((s, i) => (
            <Line key={s} dataKey={s} type="monotone" stroke={CHART_COLORS[(i + 1) % CHART_COLORS.length]}
              strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 6 }}
              isAnimationActive animationDuration={1000} animationBegin={(i + 1) * 150} />
          ))}
        </ComposedChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Bar (single-series) ── */
  if (type === 'bar' || ((type === 'stacked_bar' || type === 'grouped_bar' || type === 'combo') && !isMulti)) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <BarChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Bar dataKey="value" name={seriesName} radius={[3, 3, 0, 0]} maxBarSize={60}
            isAnimationActive animationDuration={600}>
            {items.map((_: any, i: number) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Line (single-series) ── */
  if (type === 'line' || (type === 'multi_line' && !isMulti)) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <LineChart data={items} margin={commonMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Line dataKey="value" name={seriesName} type="monotone" stroke={CHART_COLORS[0]}
            strokeWidth={2} dot={{ r: 4, fill: CHART_COLORS[0], strokeWidth: 0 }} activeDot={{ r: 6 }}
            isAnimationActive animationDuration={800} />
        </LineChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Area (single-series) ── */
  if (type === 'area' || (type === 'stacked_area' && !isMulti)) return (
    <Box sx={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height={420}>
        <AreaChart data={items} margin={commonMargin}>
          <defs>
            <linearGradient id="chartAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={CHART_COLORS[0]} stopOpacity={0.25} />
              <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0.03} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <RTooltip content={tooltipEl} />
          <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
          <Area dataKey="value" name={seriesName} type="monotone"
            stroke={CHART_COLORS[0]} fill="url(#chartAreaGrad)"
            strokeWidth={2} dot={{ r: 3, fill: CHART_COLORS[0], strokeWidth: 0 }} activeDot={{ r: 5 }}
            isAnimationActive animationDuration={800} />
        </AreaChart>
      </ResponsiveContainer>
      {footer}
    </Box>
  );

  /* ── Scatter (dot plot — category X, numeric Y) ── */
  if (type === 'scatter') {
    const scatterData = items.map((d: any, i: number) => ({ ...d, x: i, y: d.value }));
    return (
      <Box sx={{ width: '100%' }}>
        <ResponsiveContainer width="100%" height={420}>
          <ScatterChart margin={commonMargin}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="x" type="number" domain={[- 0.5, items.length - 0.5]}
              tick={false} height={90}
              label={{ value: xCol, position: 'insideBottom', offset: -4, fontSize: 12, fill: '#666' }} />
            <YAxis dataKey="y" tickFormatter={fmtAxisNum} tick={{ fontSize: 11 }} width={72}
              label={{ value: seriesName, angle: -90, position: 'insideLeft', offset: 14, fontSize: 12, fill: '#666' }} />
            <ZAxis range={[60, 60]} />
            <RTooltip content={tooltipEl} cursor={{ strokeDasharray: '3 3' }} />
            <Legend formatter={() => seriesName} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
            <Scatter name={seriesName} data={scatterData} fill={CHART_COLORS[0]} fillOpacity={0.8}
              isAnimationActive animationDuration={600} />
          </ScatterChart>
        </ResponsiveContainer>
        {/* Custom X tick labels since XAxis uses numeric indices */}
        <Box sx={{ display: 'flex', overflow: 'auto', pl: '88px', pr: '32px', gap: 0 }}>
          {items.map((d: any, i: number) => (
            <Typography key={i} variant="caption" sx={{ flex: 1, textAlign: 'center', transform: 'rotate(-38deg)', transformOrigin: 'top center', whiteSpace: 'nowrap', fontSize: 10, color: 'text.secondary', minWidth: 0 }} title={d.label}>
              {d.shortLabel}
            </Typography>
          ))}
        </Box>
        {footer}
      </Box>
    );
  }

  /* ── Pie ── */
  if (type === 'pie') {
    const pieTip = <PieTooltipContent agg={agg} yCol={yCol} />;
    const renderPctLabel = ({ pct, cx, cy, midAngle, innerRadius, outerRadius }: any) => {
      if (pct < 3) return null;
      const RADIAN = Math.PI / 180;
      const radius = innerRadius + (outerRadius - innerRadius) * 0.6;
      const x = cx + radius * Math.cos(-midAngle * RADIAN);
      const y = cy + radius * Math.sin(-midAngle * RADIAN);
      return <text x={x} y={y} fill="#fff" textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight={600}>{pct}%</text>;
    };
    return (
      <Box sx={{ width: '100%' }}>
        <ResponsiveContainer width="100%" height={440}>
          <PieChart>
            <Pie data={items} dataKey="value" nameKey="label"
              cx="50%" cy="45%" outerRadius={150}
              labelLine={false} label={renderPctLabel}
              isAnimationActive animationDuration={600} animationEasing="ease-out">
              {items.map((_: any, i: number) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Pie>
            <RTooltip content={pieTip} />
            <Legend
              formatter={(_v: any, entry: any) => (
                <span style={{ fontSize: 12, color: '#444' }} title={entry?.payload?.label}>{
                  entry?.payload?.label?.length > 30 ? entry.payload.label.slice(0, 29) + '…' : entry?.payload?.label
                }</span>
              )}
              wrapperStyle={{ maxHeight: 120, overflowY: 'auto' }}
            />
          </PieChart>
        </ResponsiveContainer>
        {footer}
      </Box>
    );
  }

  return null;
};

// ─────────────────────────────────────────────────────────────
// VirtualRow — memoized so unchanged rows skip re-render on scroll
// ─────────────────────────────────────────────────────────────
interface VirtualRowProps {
  virtualRow: { index: number; key: string | number; start: number; size: number; [key: string]: any };
  row: Record<string, unknown>;
  rowBg: string;
  startRow: number;
  tableCols: string[];
  pinnedIdxMap: Map<string, number>;
  pinnedVisible: string[];
  refreshing: boolean;
  measureRef: (el: HTMLTableRowElement | null) => void;
}

const VirtualRow = memo(function VirtualRow({
  virtualRow, row, rowBg, startRow, tableCols, pinnedIdxMap, pinnedVisible, refreshing, measureRef,
}: VirtualRowProps) {
  const idx = virtualRow.index;
  const [copiedCol, setCopiedCol] = useState<string | null>(null);

  const handleCellClick = useCallback((col: string, value: unknown) => {
    const text = value === null || value === undefined ? '' : String(value);
    navigator.clipboard.writeText(text).then(() => {
      setCopiedCol(col);
      setTimeout(() => setCopiedCol(null), 900);
    }).catch(() => {});
  }, []);
  return (
    <TableRow
      key={virtualRow.key}
      data-index={idx}
      ref={measureRef}
      hover
      sx={{ opacity: refreshing ? 0.6 : 1, transition: 'opacity 0.15s' }}
    >
      {/* Row number cell */}
      <TableCell sx={{
        color: 'text.secondary', textAlign: 'center', fontVariantNumeric: 'tabular-nums',
        ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 2, bgcolor: rowBg, boxShadow: 'inset -1px 0 0 #e2e8f0' } : {}),
      }}>
        {startRow + idx}
      </TableCell>

      {tableCols.map((col) => {
        const pi = pinnedIdxMap.get(col);
        const isPinned = pi !== undefined;
        const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
        const copied = copiedCol === col;
        return (
          <TableCell
            key={col}
            onClick={() => handleCellClick(col, row[col])}
            title="Click to copy"
            sx={{
              whiteSpace: 'nowrap',
              maxWidth: isPinned ? FROZEN_COL_WIDTH : 300,
              overflow: 'hidden', textOverflow: 'ellipsis',
              cursor: 'pointer',
              transition: 'background-color 0.15s',
              bgcolor: copied ? 'success.light' : undefined,
              ...(isPinned ? {
                position: 'sticky',
                left: 56 + pi * FROZEN_COL_WIDTH,
                zIndex: 2,
                bgcolor: copied ? 'success.light' : rowBg,
                minWidth: FROZEN_COL_WIDTH,
                ...(isLastPinned
                  ? { boxShadow: '3px 0 6px rgba(0,0,0,0.12)' }
                  : { boxShadow: 'inset -1px 0 0 #e2e8f0' }),
              } : {}),
            }}
          >
            {copied ? <span style={{ color: '#2e7d32', fontWeight: 700, fontSize: 11 }}>✓ copied</span> : formatValue(row[col])}
          </TableCell>
        );
      })}
    </TableRow>
  );
});

// ─────────────────────────────────────────────────────────────
// DataGridViewer
// ─────────────────────────────────────────────────────────────
interface StreamingSource {
  queryConfig?: any;
  rawSql?: string;
  connectionId: number;
  columns?: string[];  // User-selected columns for streaming
}

interface DataGridViewerProps {
  executionId?: string;
  fileId?: string;
  filePath?: string;
  connectionId?: string;
  partitionColumns?: string[];
  embedded?: boolean;
  title?: string;
  onClose?: () => void;
  streamingSource?: StreamingSource;
  cacheHit?: boolean;
}

const DataGridViewer = ({
  executionId,
  fileId,
  filePath,
  connectionId,
  partitionColumns = [],
  embedded = false,
  title,
  onClose,
  streamingSource,
  cacheHit,
}: DataGridViewerProps) => {
  const appSettings = useAppSettings();
  const maxVisCols = appSettings.limits.max_display_cols || DEFAULT_MAX_VIS_COLS;
  const { setAssistantCtx } = useAssistantContext();
  const sourceType = streamingSource ? 'streaming' : executionId ? 'execution' : fileId ? 'fileId' : filePath ? 'filePath' : null;
  const isStreaming = sourceType === 'streaming';

  const buildDataUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/results?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/preview?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/data?${params}`;
    }
    return null;
  };

  const buildChartUrl = (params) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/chart-data?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/chart-data?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/chart-data?${params}`;
    }
    return null;
  };

  // ── Table state ──────────────────────────────────────────
  const [data,       setData]       = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [painting,   setPainting]   = useState(false);  // true while browser paints heavy DOM
  const [error,      setError]      = useState(null);
  const [page,       setPage]       = useState(1);
  const [pageSize,   setPageSize]   = useState(100);
  const [totalRows,  setTotalRows]  = useState(0);
  const [sortColumn,    setSortColumn]    = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');

  // ── Column visibility & pinning ──────────────────────────
  // pinnedCols: array of col names (in pin order, left-to-right)
  // visibleCols: null = all visible, Set<string> = explicit visible subset
  const [pinnedCols,   setPinnedCols]   = useState([]);
  const [visibleCols,  setVisibleCols]  = useState(null);
  const [showColPanel, setShowColPanel] = useState(false);
  const [colSearch,    setColSearch]    = useState('');

  // ── Wide-table column projection ─────────────────────────
  // When backend auto-projects (>50 cols), it returns all_columns metadata
  const [allSourceColumns, setAllSourceColumns] = useState<string[] | null>(null);
  const [columnProjection, setColumnProjection] = useState(false);
  const [autoPartition, setAutoPartition] = useState<Record<string, string> | null>(null);

  // ── Column stats panel ───────────────────────────────────
  const [statsCol,    setStatsCol]    = useState<string | null>(null);
  const [statsData,   setStatsData]   = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  // ── Filters ──────────────────────────────────────────────
  const [showFilters,   setShowFilters]   = useState(false);
  const [advFilter,     setAdvFilter]     = useState({ conjunction: 'AND', conditions: [] });
  const [appliedFilter, setAppliedFilter] = useState(null);

  // ── View ─────────────────────────────────────────────────
  const [viewMode,       setViewMode]       = useState('table');
  const [exportMsg,      setExportMsg]      = useState(null);
  const [exportAnchorEl, setExportAnchorEl] = useState(null);

  // ── Chart / Pivot ─────────────────────────────────────────
  const [chartType,      setChartType]      = useState('bar');
  const [chartXCol,      setChartXCol]      = useState('');
  const [chartYCol,      setChartYCol]      = useState('');
  const [chartAgg,       setChartAgg]       = useState('sum');
  const [chartTopN,      setChartTopN]      = useState(20);
  const [chartSeriesCol, setChartSeriesCol] = useState('');
  const [chartData,      setChartData]      = useState(null);
  const [chartLoading,   setChartLoading]   = useState(false);
  const [chartError,     setChartError]     = useState(null);

  // ── Pivot (Excel-style) ─────────────────────────────────────
  const [pivotRowFields,  setPivotRowFields]  = useState<string[]>([]);
  const [pivotColField,   setPivotColField]   = useState<string>('');
  const [pivotValues,     setPivotValues]     = useState<{column: string; function: string}[]>([{column: '', function: 'sum'}]);
  const [pivotTopN,       setPivotTopN]       = useState(200);
  const [pivotData,       setPivotData]       = useState<any>(null);
  const [pivotLoading,    setPivotLoading]    = useState(false);
  const [pivotError,      setPivotError]      = useState<string | null>(null);
  const [pivotPresets,    setPivotPresets]    = useState<PivotPreset[]>([]);

  const abortRef          = useRef(null);
  const loadGenRef        = useRef(0);      // dedup: incremented per fetch, stale responses ignored
  const hasDataRef        = useRef(false);  // true after first successful load for current source
  const colsInitRef       = useRef(false);  // true after auto-col-init for current source
  const executionFetchRef = useRef<string | null>(null); // dedup StrictMode: tracks in-flight fetch for any source type
  const [retryCounter, setRetryCounter] = useState(0); // bump to force re-fetch
  // Keep partition columns in a ref so auto-init can read the latest value
  // without adding it to the effect's dep array (which would re-run on every partition change)
  const partitionColsRef  = useRef<string[]>(partitionColumns);
  useEffect(() => { partitionColsRef.current = partitionColumns; }, [partitionColumns]);
  const tableContainerRef = useRef(null);   // scrolling container for row virtualizer
  const chartContainerRef = useRef<HTMLDivElement>(null);
  // Prefetch cache: key → page data. Keyed by page+sort+filter+pageSize so stale
  // entries are never served after the user changes query params.
  const prefetchCacheRef   = useRef<Map<string, any>>(new Map());
  // In-flight set: keys currently being fetched in the background.
  // Prevents duplicate prefetch requests when multiple renders fire before one resolves.
  const prefetchInflightRef = useRef<Set<string>>(new Set());

  // ── Release temp result file when switching to a NEW execution ──────────────
  // Only fires when executionId changes from one non-null value to another.
  // We do NOT delete on unmount — the server's 30-min cleanup job handles that.
  // This avoids the race where React re-renders/remounts delete the file before
  // the grid has a chance to load it.
  const prevExecutionIdRef = useRef<string | undefined>(undefined);
  useEffect(() => {
    const old = prevExecutionIdRef.current;
    prevExecutionIdRef.current = executionId;
    if (old && executionId && old !== executionId) {
      // Switched to a different result — release the old temp file
      fetch(`${API_BASE_URL}/api/executions/${old}/results`, { method: 'DELETE', headers: _authHeaders() }).catch(() => {});
    }
  }, [executionId]); // eslint-disable-line

  // ── Sync active result grid to AssistantContext ───────────
  // Lets the assistant answer "max of revenue" etc. against the loaded grid.
  useEffect(() => {
    if (executionId && data?.columns?.length) {
      setAssistantCtx({ executionId, resultColumns: data.columns });
    }
  }, [executionId, data?.columns]); // eslint-disable-line

  // ── Reset on source change ───────────────────────────────
  const prevStreamingRef = useRef(streamingSource);
  useEffect(() => {
    const wasStreaming = prevStreamingRef.current;
    prevStreamingRef.current = streamingSource;

    // Seamless streaming → local transition: preserve page/sort/filter,
    // just clear prefetch cache so next fetch uses the local file.
    if (wasStreaming && !streamingSource && executionId) {
      prefetchCacheRef.current.clear();
      prefetchInflightRef.current.clear();
      hasDataRef.current = false;
      colsInitRef.current = false;
      setData(null);
      setLoading(true);
      setRefreshing(false);
      return;
    }

    // Full reset for all other source changes
    hasDataRef.current  = false;
    colsInitRef.current = false;
    prefetchCacheRef.current.clear();
    prefetchInflightRef.current.clear();
    setData(null); setError(null); setPage(1);
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setSortColumn(null); setChartData(null);
    setViewMode('table'); setLoading(true); setRefreshing(false);
    setPinnedCols([]); setVisibleCols(null); setColSearch('');
    setChartXCol(''); setChartYCol(''); setChartSeriesCol('');
    setAllSourceColumns(null); setColumnProjection(false); setAutoPartition(null);
  }, [executionId, fileId, filePath, connectionId, streamingSource]); // eslint-disable-line

  // ── Auto-init columns on first data load ─────────────────
  // Soft defaults (user can always override via the Columns panel):
  //   1. Fully empty columns are hidden initially
  //   2. Partition columns are auto-pinned (appear frozen on left)
  //   3. Visible set capped at maxVisCols (partition pins always included)
  useEffect(() => {
    if (!data?.columns || colsInitRef.current) return;
    colsInitRef.current = true;
    const c: string[] = data.columns;
    const rows: any[] = data.rows || [];

    // 1. Detect fully empty columns in the current page (only if there are rows)
    const emptyCols = new Set<string>(
      rows.length > 0
        ? c.filter(col => rows.every(row => row[col] == null || row[col] === ''))
        : []
    );

    // 2. Auto-pin partition columns that exist in the result and are non-empty
    const partCols = partitionColsRef.current;
    const partLower = new Set(partCols.map(p => p.toLowerCase()));
    const autoPin = c
      .filter(col => partLower.has(col.toLowerCase()) && !emptyCols.has(col))
      .slice(0, 4);   // cap at 4 frozen cols
    if (autoPin.length > 0) setPinnedCols(autoPin);

    // 3. Build visible set: non-empty columns, capped at admin-configured limit
    //    Partition pins are always included even if beyond the cap.
    const nonEmpty = c.filter(col => !emptyCols.has(col));
    if (nonEmpty.length > maxVisCols) {
      // Cap: show first maxVisCols columns + ensure pinned cols are always included
      const first = new Set(nonEmpty.slice(0, maxVisCols));
      autoPin.forEach(p => first.add(p));
      setVisibleCols(first);
    } else if (emptyCols.size > 0) {
      setVisibleCols(new Set(nonEmpty));
    }

    // Smart auto-pick: classify columns by type, then suggest chart & pivot defaults
    const base = nonEmpty.length > 0 ? nonEmpty : c;
    const classified = classifyColumns(base, rows);

    if (!chartXCol) {
      const cs = suggestChart(classified);
      setChartType(cs.chartType);
      setChartXCol(cs.xCol);
      setChartYCol(cs.yCol);
      setChartSeriesCol(cs.seriesCol);
      setChartAgg(cs.agg);
    }

    // Auto-pick pivot defaults (only if not already set)
    if (pivotRowFields.length === 0) {
      const ps = suggestPivot(classified);
      if (ps.rowFields.length > 0) setPivotRowFields(ps.rowFields);
      if (ps.colField) setPivotColField(ps.colField);
      if (ps.values.length > 0 && ps.values[0].column) setPivotValues(ps.values);
    }
    // Generate named preset configurations for Smart Suggestions panel
    setPivotPresets(generatePivotPresets(classified));
  }, [data]); // eslint-disable-line

  // ── Load page ─────────────────────────────────────────────
  // Streaming: server-side pagination (page/pageSize changes fetch from S3),
  //            client-side sort/filter (instant, no round trip).
  // Normal:    server-side pagination + sort/filter.
  useEffect(() => {
    if (!isStreaming) {
      executionFetchRef.current = null;
    }
  }, [isStreaming]);

  useEffect(() => {
    if (!sourceType) return;

    // StrictMode dedup: prevent double-mount from firing duplicate requests.
    // For streaming: dedup key excludes sort/filter (handled client-side).
    // For normal: dedup key includes everything (server handles all).
    const _filterKey = appliedFilter?.conditions?.length ? JSON.stringify(appliedFilter) : '';
    const dedupKey = isStreaming
      ? `stream|${streamingSource?.connectionId}|${streamingSource?.rawSql || ''}|${JSON.stringify(streamingSource?.queryConfig || '')}|${page}|${pageSize}`
      : `${sourceType}|${executionId || fileId || filePath || ''}|${page}|${pageSize}|${sortColumn || ''}|${sortDirection}|${_filterKey}`;
    if (executionFetchRef.current === dedupKey) return;
    executionFetchRef.current = dedupKey;

    if (abortRef.current) abortRef.current.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    const gen = ++loadGenRef.current;  // dedup: ignore responses from stale requests

    // Stable cache key — encodes every query dimension
    const filterStr  = appliedFilter?.conditions?.length ? JSON.stringify(appliedFilter) : '';
    const cacheKey   = (p: number) => `${p}|${pageSize}|${sortColumn||''}|${sortDirection}|${filterStr}`;

    // Unified fetch — streaming uses POST, others use GET
    const fetchPage = async (p: number): Promise<any> => {
      if (sourceType === 'streaming' && streamingSource) {
        const body: any = {
          connection_id: streamingSource.connectionId,
          page: p,
          page_size: pageSize,
        };
        if (streamingSource.rawSql) body.raw_sql = streamingSource.rawSql;
        if (streamingSource.queryConfig) body.query_config = toBackendQueryConfig(streamingSource.queryConfig);
        if (streamingSource.columns?.length) body.columns = streamingSource.columns.join(',');
        const res = await fetch(`${API_BASE_URL}/api/execute/stream/paginate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ..._authHeaders() },
          body: JSON.stringify(body),
          signal: ac.signal,
        });
        if (!res.ok) {
          const detail = await res.json().catch(() => ({}));
          const d = detail?.detail;
          const msg = typeof d === 'object' && d?.message ? d.message : (typeof d === 'string' ? d : `HTTP ${res.status}`);
          const err: any = new Error(msg);
          if (typeof d === 'object' && d?.error_code) err.errorCode = d.error_code;
          throw err;
        }
        return res.json();
      }
      // Existing GET-based fetch for execution/fileId/filePath
      const params = new URLSearchParams({ page: String(p), page_size: String(pageSize) });
      if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
      if (appliedFilter?.conditions?.length) params.append('adv_filters', filterStr);
      const url = buildDataUrl(params);
      if (!url) throw new Error('No data source configured');
      const res = await fetch(url, { signal: ac.signal, headers: _authHeaders() });
      if (!res.ok) {
        const detail = await res.json().catch(() => ({}));
        throw new Error(detail?.detail || `HTTP ${res.status}`);
      }
      return res.json();
    };

    // Background prefetch helper — fires and forgets; never touches React state.
    // DISABLED for streaming sources — each S3 prefetch creates a full httpfs
    // connection costing 2-5s of S3 round trips; prefetching would exhaust
    // connection pools and stall the primary request.
    // Staggered by 100ms to avoid saturating browser connection limit (6 per origin).
    let _prefetchDelay = 0;
    const prefetchPage = (p: number, totalPages: number) => {
      if (isStreaming) return;  // skip prefetch for S3 streaming
      if (p < 1 || (totalPages > 0 && p > totalPages)) return;
      const k = cacheKey(p);
      if (prefetchCacheRef.current.has(k)) return;
      if (prefetchInflightRef.current.has(k)) return;
      prefetchInflightRef.current.add(k);
      _prefetchDelay += 100;
      const delay = _prefetchDelay;
      setTimeout(() => {
        if (ac.signal.aborted) { prefetchInflightRef.current.delete(k); return; }
        fetchPage(p)
          .then(d => {
            prefetchInflightRef.current.delete(k);
            if (d && !ac.signal.aborted) prefetchCacheRef.current.set(k, d);
          })
          .catch(() => { prefetchInflightRef.current.delete(k); });
      }, delay);
    };

    // Serve from prefetch cache — instant page switch, no spinner
    const cached = prefetchCacheRef.current.get(cacheKey(page));
    if (cached) {
      setData(cached);
      setTotalRows(cached.total_rows);
      hasDataRef.current = true;
      setError(null);
      setLoading(false);
      setRefreshing(false);
      if (tableContainerRef.current) tableContainerRef.current.scrollTop = 0;
      const tp = cached.total_pages > 0 ? cached.total_pages : page + 2;
      prefetchPage(page + 1, tp);
      prefetchPage(page + 2, tp);
      prefetchPage(page - 1, tp);
      prefetchPage(page - 2, tp);
      return () => { ac.abort(); };
    }

    if (hasDataRef.current) setRefreshing(true);
    else setLoading(true);

    const run = async () => {
      let aborted = false;
      const t0 = performance.now();
      try {
        const result = await fetchPage(page);
        const elapsed = ((performance.now() - t0) / 1000).toFixed(2);
        console.debug(`[DataGrid] page=${page} rows=${result?.rows?.length ?? 0} cols=${result?.columns?.length ?? 0} ${elapsed}s${isStreaming ? ' (streaming)' : ''}`);

        // Dedup: if a newer request was fired while this one was in-flight, discard
        if (gen !== loadGenRef.current) { aborted = true; return; }

        // Cache this page and evict if cache grows too large
        prefetchCacheRef.current.set(cacheKey(page), result);
        if (prefetchCacheRef.current.size > 25) {
          prefetchCacheRef.current.delete(prefetchCacheRef.current.keys().next().value);
        }

        setData(result);
        setTotalRows(result.total_rows);
        hasDataRef.current = true;
        setError(null);
        if (tableContainerRef.current) tableContainerRef.current.scrollTop = 0;

        // Capture wide-table column projection metadata (first page only)
        if (result.column_projection_applied && result.all_columns) {
          setAllSourceColumns(result.all_columns);
          setColumnProjection(true);
        }
        // Capture auto-partition metadata
        if (result.auto_partition) {
          setAutoPartition(result.auto_partition);
        }

        // Eagerly prefetch next and previous pages in background
        const tp = result.total_pages > 0 ? result.total_pages : page + 2;
        prefetchPage(page + 1, tp);
        prefetchPage(page + 2, tp);
        prefetchPage(page - 1, tp);
        prefetchPage(page - 2, tp);
      } catch (_e) {
        const err = _e as any;
        if (err.name === 'AbortError') { aborted = true; return; }
        setError(err.errorCode === 'TOKEN_EXPIRED'
          ? 'AWS session expired — please update your connection credentials and re-execute.'
          : err.message);
      } finally {
        if (!aborted) {
          // Keep spinner visible during DOM paint: set painting=true, clear
          // loading/refreshing.  The painting flag is cleared after the browser
          // finishes layout+paint (via double-rAF in a separate effect).
          setPainting(true);
          setLoading(false); setRefreshing(false);
        }
      }
    };

    run();
    return () => {
      ac.abort();
      // Clear dedup ref on unmount so StrictMode remount can refetch.
      // The aborted fetch from mount-1 never reaches the backend (browser cancels it),
      // so mount-2 starts the only real request.
      executionFetchRef.current = null;
    };
  }, [executionId, fileId, filePath, connectionId, streamingSource, page, pageSize, sortColumn, sortDirection, appliedFilter, retryCounter]); // eslint-disable-line

  // Clear the "painting" flag after the browser has finished layout + paint.
  // Double requestAnimationFrame ensures we wait past the next compositing frame.
  useEffect(() => {
    if (!painting) return;
    let cancelled = false;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (!cancelled) setPainting(false);
      });
    });
    return () => { cancelled = true; };
  }, [painting]);

  // ── Derive cols/rows early — useCallback below depends on `cols` ─────────
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const cols = useMemo(() => data?.columns || [], [data]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const rawRows = useMemo(() => data?.rows    || [], [data]);

  // During streaming: apply sort/filter client-side on loaded page (no S3 round trips).
  // For downloaded execution results the normal server-side path handles it,
  // but if the data is already loaded (fileId / filePath previews) this also
  // provides instant client-side sort/filter.
  const rows = useMemo(() => {
    if (!isStreaming || rawRows.length === 0) return rawRows;
    let filtered = rawRows;
    if (appliedFilter?.conditions?.length) {
      filtered = filtered.filter(row => {
        const results = appliedFilter.conditions.map(cond => {
          const val = String(row[cond.col] ?? '').toLowerCase();
          const target = String(cond.val ?? '').toLowerCase();
          switch (cond.op) {
            case 'contains':     return val.includes(target);
            case 'not_contains': return !val.includes(target);
            case 'equals':       return val === target;
            case 'not_equals':   return val !== target;
            case 'starts_with':  return val.startsWith(target);
            case 'ends_with':    return val.endsWith(target);
            case 'gt':           return Number(row[cond.col]) > Number(cond.val);
            case 'gte':          return Number(row[cond.col]) >= Number(cond.val);
            case 'lt':           return Number(row[cond.col]) < Number(cond.val);
            case 'lte':          return Number(row[cond.col]) <= Number(cond.val);
            case 'is_null':      return row[cond.col] == null || row[cond.col] === '';
            case 'is_not_null':  return row[cond.col] != null && row[cond.col] !== '';
            default:             return true;
          }
        });
        return appliedFilter.conjunction === 'AND' ? results.every(Boolean) : results.some(Boolean);
      });
    }
    if (sortColumn) {
      const dir = sortDirection === 'asc' ? 1 : -1;
      filtered = [...filtered].sort((a, b) => {
        const av = a[sortColumn], bv = b[sortColumn];
        if (av == null && bv == null) return 0;
        if (av == null) return dir;
        if (bv == null) return -dir;
        if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
        return String(av).localeCompare(String(bv)) * dir;
      });
    }
    return filtered;
  }, [rawRows, isStreaming, sortColumn, sortDirection, appliedFilter]);

  // Full column list for chart/pivot pickers (includes columns beyond auto-projection)
  const allCols = useMemo(
    () => allSourceColumns && allSourceColumns.length > 0 ? allSourceColumns : cols,
    [allSourceColumns, cols],
  );

  // ── Filter helpers ────────────────────────────────────────
  const handleApplyFilters = useCallback(() => {
    setAppliedFilter({ ...advFilter });
    setPage(1);
  }, [advFilter]);

  const handleClearFilters = useCallback(() => {
    setAdvFilter({ conjunction: 'AND', conditions: [] });
    setAppliedFilter(null);
    setPage(1);
  }, []);

  // ── View helpers ──────────────────────────────────────────
  const handleViewModeChange = useCallback((_, val) => {
    if (!val) return;
    setViewMode(val);
    // Keep chart/pivot data cached — only re-fetch when user clicks "Render" or config changes
  }, []);

  const handleSort = useCallback((col) => {
    if (sortColumn === col) setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortColumn(col); setSortDirection('asc'); }
    if (!isStreaming) setPage(1);
  }, [sortColumn, isStreaming]);

  // ── Column visibility helpers ─────────────────────────────
  const toggleColVisibility = useCallback((col, checked) => {
    setVisibleCols(prev => {
      const next = prev === null ? new Set(cols) : new Set(prev);
      if (checked) next.add(col);
      else next.delete(col);
      return next.size === cols.length ? null : next;
    });
  }, [cols]);

  const togglePinCol = useCallback((col) => {
    setPinnedCols(prev =>
      prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]
    );
  }, []);

  // ── Column stats loader ───────────────────────────────────
  const openColStats = useCallback(async (col: string) => {
    if (!executionId) return;
    setStatsCol(col);
    setStatsData(null);
    setStatsLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/executions/${executionId}/stats`, { headers: _authHeaders() });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const colStat = data.columns?.find((c: any) => c.name === col) || null;
      setStatsData(colStat ? { ...colStat, total_rows: data.total_rows } : null);
    } catch {
      setStatsData(null);
    } finally {
      setStatsLoading(false);
    }
  }, [executionId]);

  // ── Chart loader ──────────────────────────────────────────
  const loadChartData = async () => {
    if (!chartXCol || !chartYCol) return;
    setChartLoading(true); setChartError(null);
    try {
      let res: Response;
      if (isStreaming && streamingSource) {
        // Streaming: POST to stream chart endpoint with full query config
        const body: any = {
          connection_id: streamingSource.connectionId,
          x_col: chartXCol, y_col: chartYCol, agg: chartAgg, top_n: chartTopN,
        };
        if (chartSeriesCol) body.series_col = chartSeriesCol;
        if (streamingSource.rawSql) body.raw_sql = streamingSource.rawSql;
        if (streamingSource.queryConfig) body.query_config = toBackendQueryConfig(streamingSource.queryConfig);
        res = await fetch(`${API_BASE_URL}/api/execute/stream/chart-data`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ..._authHeaders() },
          body: JSON.stringify(body),
        });
      } else {
        const params = new URLSearchParams({ x_col: chartXCol, y_col: chartYCol, agg: chartAgg, top_n: String(chartTopN) });
        if (chartSeriesCol) params.append('series_col', chartSeriesCol);
        const url = buildChartUrl(params);
        if (!url) throw new Error('Chart data not available for this source');
        res = await fetch(url, { headers: _authHeaders() });
      }
      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try { const e = await res.json(); const d = e.detail; msg = typeof d === 'object' && d?.message ? d.message : (typeof d === 'string' ? d : msg); } catch {}
        throw new Error(msg);
      }
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) throw new Error('Server returned non-JSON response — is the backend running?');
      setChartData(await res.json());
    } catch (_e) {
      setChartError((_e as Error).message);
    } finally {
      setChartLoading(false);
    }
  };

  // ── Pivot loader ────────────────────────────────────────────
  const buildPivotUrl = (params: URLSearchParams) => {
    if (sourceType === 'execution') return `${API_BASE_URL}/api/executions/${executionId}/pivot-data?${params}`;
    if (sourceType === 'fileId')    return `${API_BASE_URL}/api/downloads/${fileId}/pivot-data?${params}`;
    if (sourceType === 'filePath') {
      params.append('file_path', filePath);
      if (connectionId) params.append('connection_id', connectionId);
      return `${API_BASE_URL}/api/files/pivot-data?${params}`;
    }
    return null;
  };

  const loadPivotData = async () => {
    const validValues = pivotValues.filter(v => v.column || v.function === 'count_rows');
    if (pivotRowFields.length === 0 || validValues.length === 0) return;
    setPivotLoading(true); setPivotError(null);
    try {
      let res: Response;
      if (isStreaming && streamingSource) {
        // Streaming: POST to stream pivot endpoint with full query config
        const body: any = {
          connection_id: streamingSource.connectionId,
          row_fields: pivotRowFields.join(','),
          values: JSON.stringify(validValues),
          top_n: pivotTopN,
        };
        if (pivotColField) body.col_field = pivotColField;
        if (streamingSource.rawSql) body.raw_sql = streamingSource.rawSql;
        if (streamingSource.queryConfig) body.query_config = toBackendQueryConfig(streamingSource.queryConfig);
        res = await fetch(`${API_BASE_URL}/api/execute/stream/pivot-data`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ..._authHeaders() },
          body: JSON.stringify(body),
        });
      } else {
        const params = new URLSearchParams({
          row_fields: pivotRowFields.join(','),
          values: JSON.stringify(validValues),
          top_n: String(pivotTopN),
        });
        if (pivotColField) params.set('col_field', pivotColField);
        const url = buildPivotUrl(params);
        if (!url) throw new Error('Pivot not available for this source');
        res = await fetch(url, { headers: _authHeaders() });
      }
      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try { const e = await res.json(); const d = e.detail; msg = typeof d === 'object' && d?.message ? d.message : (typeof d === 'string' ? d : msg); } catch {}
        throw new Error(msg);
      }
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) throw new Error('Server returned non-JSON response — is the backend running?');
      setPivotData(await res.json());
    } catch (_e) {
      setPivotError((_e as Error).message);
    } finally {
      setPivotLoading(false);
    }
  };

  // ── Chart PNG export ──────────────────────────────────────
  const exportChartPng = useCallback(() => {
    const container = chartContainerRef.current;
    if (!container) return;
    const svg = container.querySelector('svg');
    if (!svg) return;
    const { width, height } = svg.getBoundingClientRect();
    const serialized = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([serialized], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * 2; canvas.height = height * 2;
      const ctx = canvas.getContext('2d')!;
      ctx.scale(2, 2);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `chart_${chartXCol}_vs_${chartYCol}.png`;
      a.click();
    };
    img.src = url;
  }, [chartXCol, chartYCol]);

  // ── Export helpers ────────────────────────────────────────
  const exportBackground = async (format) => {
    setExportAnchorEl(null);
    setExportMsg(`Starting ${format.toUpperCase()} export…`);
    try {
      const res = await fetch(`${API_BASE_URL}/api/executions/${executionId}/export?format=${format}`, { method: 'POST', headers: _authHeaders() });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const result = await res.json();
      setExportMsg(result.message);
      setTimeout(() => setExportMsg(null), 6000);
    } catch (_e) {
      const err = _e as Error;
      setExportMsg(`Export failed: ${err.message}`);
      setTimeout(() => setExportMsg(null), 5000);
    }
  };
  const downloadFile = () => window.open(`${API_BASE_URL}/api/downloads/${fileId}/download`, '_blank');

  // ── Derived values ────────────────────────────────────────
  const isUnknownTotal = totalRows === -1;
  const effectiveTotal = isUnknownTotal ? (page * pageSize + 1) : (data?.filtered_rows ?? totalRows);
  const totalPages = isUnknownTotal ? page + 1 : Math.max(1, Math.ceil(effectiveTotal / pageSize));
  const startRow   = rows.length > 0 ? (page - 1) * pageSize + 1 : 0;
  const endRow     = isUnknownTotal
    ? startRow + (rows.length || 0) - 1
    : Math.min(page * pageSize, effectiveTotal);
  const activeFilters = appliedFilter?.conditions?.length || 0;

  // Memoize every derived column array so they are stable between renders
  // that don't change col/visibility/pin state (e.g. scroll, pagination).
  const displayCols = useMemo(
    () => visibleCols === null ? cols : cols.filter(c => visibleCols.has(c)),
    [cols, visibleCols],
  );
  const pinnedVisible = useMemo(
    () => pinnedCols.filter(c => displayCols.includes(c)),
    [pinnedCols, displayCols],
  );
  const pinnedSet = useMemo(() => new Set(pinnedVisible), [pinnedVisible]);
  const nonPinnedVis = useMemo(
    () => displayCols.filter(c => !pinnedSet.has(c)),
    [displayCols, pinnedSet],
  );
  const tableCols = useMemo(
    () => [...pinnedVisible, ...nonPinnedVis],
    [pinnedVisible, nonPinnedVis],
  );
  // Map from col name → pin index for O(1) lookup during render
  const pinnedIdxMap = useMemo(
    () => new Map(pinnedVisible.map((c, i) => [c, i])),
    [pinnedVisible],
  );

  // Column picker search
  const colSearchLower = colSearch.toLowerCase();
  const filteredColList = useMemo(
    () => colSearchLower ? cols.filter(c => c.toLowerCase().includes(colSearchLower)) : cols,
    [cols, colSearchLower],
  );

  const headerTitle = title || (
    sourceType === 'execution' ? 'Query Results' :
    sourceType === 'streaming' ? 'Query Results' :
    sourceType === 'fileId'   ? (data?.filename || 'File Preview') :
    sourceType === 'filePath' ? (data?.filename || filePath?.split('/').pop() || 'File Preview') :
    'Preview'
  );

  // ── Row virtualizer (renders only visible rows for large pages) ─
  // Hook must be called before any early returns (React rules of hooks).
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 33,  // MUI Table size="small" row ~33px
    overscan: 10,
  });
  const virtualRows       = rowVirtualizer.getVirtualItems();
  const totalVirtualHeight = rowVirtualizer.getTotalSize();
  const vPaddingTop    = virtualRows.length > 0 ? (virtualRows[0]?.start ?? 0) : 0;
  const vPaddingBottom = virtualRows.length > 0
    ? totalVirtualHeight - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0;

  // ── Initial load — enterprise skeleton placeholder ──────
  if (loading && !data) {
    const Wrap: React.ElementType = embedded ? Box : Paper;
    const skelCols = 8;
    const skelRows = 12;
    /* deterministic widths so they don't re-randomize on each render */
    const colWidths = [72, 95, 60, 110, 85, 68, 100, 78];
    return (
      <Wrap sx={{
        display: 'flex', flexDirection: 'column', height: '100%', minHeight: 200,
        overflow: 'hidden', position: 'relative',
        '@keyframes shimmer': {
          '0%':   { backgroundPosition: '-600px 0' },
          '100%': { backgroundPosition: '600px 0' },
        },
        '@keyframes fadeInUp': {
          from: { opacity: 0, transform: 'translateY(12px)' },
          to:   { opacity: 1, transform: 'translateY(0)' },
        },
        '@keyframes pulseRing': {
          '0%':   { transform: 'scale(0.85)', opacity: 0.5 },
          '50%':  { transform: 'scale(1.15)', opacity: 0.15 },
          '100%': { transform: 'scale(0.85)', opacity: 0.5 },
        },
      }}>
        {/* Top progress bar */}
        <LinearProgress sx={{ height: 3, borderRadius: 0 }} />

        {/* Skeleton toolbar */}
        <Box sx={{ display: 'flex', gap: 1.5, px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider', alignItems: 'center' }}>
          <Skeleton variant="rounded" width={110} height={30} sx={{ bgcolor: 'grey.100' }} />
          <Skeleton variant="rounded" width={80}  height={30} sx={{ bgcolor: 'grey.100' }} />
          <Skeleton variant="rounded" width={90}  height={30} sx={{ bgcolor: 'grey.100' }} />
          <Box sx={{ flex: 1 }} />
          <Skeleton variant="rounded" width={100} height={30} sx={{ bgcolor: 'grey.100' }} />
          <Skeleton variant="circular" width={30} height={30} sx={{ bgcolor: 'grey.100' }} />
          <Skeleton variant="circular" width={30} height={30} sx={{ bgcolor: 'grey.100' }} />
        </Box>

        {/* Skeleton table header */}
        <Box sx={{
          display: 'flex', alignItems: 'center', px: 0, py: 0,
          bgcolor: 'grey.50', borderBottom: '2px solid', borderColor: 'divider',
        }}>
          {/* Row # header */}
          <Box sx={{ width: 52, minWidth: 52, px: 1.5, py: 1.2 }}>
            <Skeleton variant="rounded" width={28} height={14} sx={{ bgcolor: 'grey.200' }} />
          </Box>
          {Array.from({ length: skelCols }).map((_, i) => (
            <Box key={i} sx={{ flex: 1, px: 1.5, py: 1.2, borderLeft: '1px solid', borderColor: 'divider' }}>
              <Skeleton variant="rounded" width={colWidths[i]} height={14} sx={{ bgcolor: 'grey.200' }} />
            </Box>
          ))}
        </Box>

        {/* Skeleton data rows */}
        {Array.from({ length: skelRows }).map((_, i) => (
          <Box key={i} sx={{
            display: 'flex', alignItems: 'center', px: 0,
            borderBottom: '1px solid', borderColor: 'divider',
            bgcolor: i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.015)',
            animation: 'fadeInUp 0.4s ease-out both',
            animationDelay: `${i * 40}ms`,
          }}>
            {/* Row number */}
            <Box sx={{ width: 52, minWidth: 52, px: 1.5, py: 1 }}>
              <Skeleton variant="text" width={20} height={14} sx={{ bgcolor: 'grey.100' }} />
            </Box>
            {Array.from({ length: skelCols }).map((_, j) => (
              <Box key={j} sx={{ flex: 1, px: 1.5, py: 1, borderLeft: '1px solid', borderColor: 'divider' }}>
                <Skeleton
                  variant="text" height={14}
                  width={`${colWidths[(i + j) % colWidths.length] + (i * 7 + j * 13) % 30}%`}
                  sx={{
                    maxWidth: '90%', bgcolor: 'grey.100',
                    background: 'linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 37%, #f0f0f0 63%)',
                    backgroundSize: '600px 100%',
                    animation: 'shimmer 1.6s ease-in-out infinite',
                    animationDelay: `${(i * 50 + j * 80) % 400}ms`,
                  }}
                />
              </Box>
            ))}
          </Box>
        ))}

        {/* Bottom fade gradient */}
        <Box sx={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: 80,
          background: 'linear-gradient(transparent, rgba(255,255,255,0.95))',
          pointerEvents: 'none',
        }} />

        {/* Center loading card */}
        <Box sx={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          pointerEvents: 'none',
        }}>
          <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            bgcolor: 'rgba(255,255,255,0.97)', borderRadius: 3,
            px: 5, py: 3.5, boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            border: '1px solid', borderColor: 'divider',
            animation: 'fadeInUp 0.5s ease-out both',
            animationDelay: '150ms',
            position: 'relative',
          }}>
            {/* Pulse ring behind spinner */}
            <Box sx={{
              position: 'absolute', top: 22, width: 52, height: 52,
              borderRadius: '50%', border: '2px solid', borderColor: 'primary.main',
              animation: 'pulseRing 2s ease-in-out infinite',
              opacity: 0.3,
            }} />
            <CircularProgress size={40} thickness={3.5} sx={{ color: 'primary.main' }} />
            <Typography variant="subtitle2" fontWeight={600} color="text.primary" letterSpacing={0.3}>
              Preparing data
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ mt: -1.5 }}>
              Fetching and processing results…
            </Typography>
          </Box>
        </Box>
      </Wrap>
    );
  }

  if (error && !data) {
    const Wrap: React.ElementType = embedded ? Box : Paper;
    const retryFetch = () => {
      setError(null);
      executionFetchRef.current = null;
      hasDataRef.current = false;
      setLoading(true);
      setRetryCounter(c => c + 1); // triggers useEffect re-run
    };
    return (
      <Wrap sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 200, ...(embedded ? {} : { p: 4 }) }}>
        <Alert severity="error" sx={{ mb: 2, width: '100%', maxWidth: 520 }}>
          <Typography variant="subtitle2" fontWeight="bold">
            {isStreaming ? 'S3 Preview Error' : 'Preview Error'}
          </Typography>
          <Typography variant="body2" sx={{ mt: 0.5 }}>{error}</Typography>
          {isStreaming && (
            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
              The background query is still processing. Results will be available when it completes.
            </Typography>
          )}
        </Alert>
        <Box sx={{ display: 'flex', gap: 1.5 }}>
          <Button variant="contained" size="small" onClick={retryFetch}>
            Retry
          </Button>
          {!embedded && <Button variant="outlined" size="small" onClick={onClose}>Close</Button>}
        </Box>
      </Wrap>
    );
  }

  const Wrapper: React.ElementType = embedded ? Box : Paper;

  return (
    <Wrapper sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* ── Header (non-embedded only) ───────────────────── */}
      {!embedded && (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.5, borderBottom: 1, borderColor: 'divider' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Typography variant="h6">{headerTitle}</Typography>
            {isStreaming && (
              <Chip label="Streaming" size="small" color="info" variant="outlined" sx={{ height: 22, fontSize: 11, fontWeight: 600 }} />
            )}
            {cacheHit && (
              <Chip label="Cached" size="small" color="success" variant="outlined"
                sx={{ ml: 1, height: 22, fontSize: 11 }} />
            )}
            <Typography variant="body2" color="text.secondary">
              {refreshing ? 'Refreshing…' : isUnknownTotal
                ? `${startRow.toLocaleString()}–${endRow.toLocaleString()} rows (counting…)`
                : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${totalRows.toLocaleString()} rows`}
            </Typography>
          </Box>
          {onClose && (
            <Tooltip title="Close"><IconButton onClick={onClose} size="small"><CloseIcon /></IconButton></Tooltip>
          )}
        </Box>
      )}

      {exportMsg && (
        <Alert severity={exportMsg.includes('failed') ? 'error' : exportMsg.includes('Starting') ? 'info' : 'success'}
          sx={{ borderRadius: 0 }} onClose={() => setExportMsg(null)}>
          {exportMsg}
        </Alert>
      )}

      {/* ── Toolbar ──────────────────────────────────────── */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderBottom: 1, borderColor: 'divider', flexWrap: 'wrap', gap: 1, flexShrink: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {embedded && (
            <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
              {refreshing ? (
                <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.75 }}>
                  <CircularProgress size={12} /> Updating…
                </Box>
              ) : isUnknownTotal
                ? `${startRow.toLocaleString()}–${endRow.toLocaleString()} rows (counting…)`
                : `${startRow.toLocaleString()}–${endRow.toLocaleString()} of ${effectiveTotal.toLocaleString()} rows`}
              {activeFilters > 0 && (
                <Chip label={`${activeFilters} filter${activeFilters > 1 ? 's' : ''}`} size="small" color="primary"
                  variant="outlined" sx={{ ml: 1, height: 18, fontSize: 11 }} onDelete={handleClearFilters} />
              )}
            </Typography>
          )}

          <ToggleButtonGroup value={viewMode} exclusive onChange={handleViewModeChange} size="small">
            <ToggleButton value="table"><Tooltip title="Table"><TableIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Table</ToggleButton>
            <ToggleButton value="chart"><Tooltip title="Chart"><ChartIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Chart</ToggleButton>
            <ToggleButton value="pivot"><Tooltip title="Pivot"><PivotIcon sx={{ mr: 0.5, fontSize: 18 }} /></Tooltip>Pivot</ToggleButton>
          </ToggleButtonGroup>

          {viewMode === 'table' && (
            <Button
              variant={showFilters ? 'contained' : 'outlined'}
              size="small" startIcon={<FilterIcon />}
              onClick={() => setShowFilters(v => !v)}
              color={activeFilters > 0 ? 'primary' : 'inherit'}
            >
              Filters{activeFilters > 0 ? ` (${activeFilters})` : ''}
            </Button>
          )}

          {viewMode === 'table' && cols.length > 0 && (
            <Button
              variant="outlined"
              size="small"
              startIcon={<ColumnsIcon />}
              onClick={() => setShowColPanel(true)}
              color={pinnedCols.length > 0 || visibleCols !== null || columnProjection ? 'primary' : 'inherit'}
            >
              Columns ({displayCols.length}{displayCols.length !== cols.length ? `/${cols.length}` : ''}
              {columnProjection && allSourceColumns ? ` of ${allSourceColumns.length}` : ''})
              {pinnedCols.length > 0 && ` · ${pinnedCols.length} pinned`}
            </Button>
          )}
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TextField select size="small" value={pageSize} onChange={e => { setPageSize(+e.target.value); setPage(1); }}
            sx={{ minWidth: 110 }}>
            {[50, 100, 250, 500, 1000].map(n => <MenuItem key={n} value={n}>{n} rows</MenuItem>)}
          </TextField>

          {sourceType === 'execution' && (
            <>
              <Button variant="outlined" size="small" startIcon={<DownloadIcon />}
                onClick={e => setExportAnchorEl(e.currentTarget)}>Export</Button>
              <Menu anchorEl={exportAnchorEl} open={Boolean(exportAnchorEl)} onClose={() => setExportAnchorEl(null)}>
                <MenuItem onClick={() => exportBackground('csv')}><CsvIcon sx={{ mr: 1, fontSize: 20 }} />CSV</MenuItem>
                <MenuItem onClick={() => exportBackground('excel')}><ExcelIcon sx={{ mr: 1, fontSize: 20 }} />Excel</MenuItem>
                <MenuItem onClick={() => exportBackground('json')}><JsonIcon sx={{ mr: 1, fontSize: 20 }} />JSON</MenuItem>
              </Menu>
            </>
          )}
          {sourceType === 'fileId' && (
            <Button variant="outlined" size="small" startIcon={<DownloadIcon />} onClick={downloadFile}>Download</Button>
          )}
        </Box>
      </Box>

      {/* ── TABLE VIEW ───────────────────────────────────── */}
      {viewMode === 'table' && (
        <>
          {showFilters && (
            <>
              <FilterBuilder columns={allCols} value={advFilter} onChange={setAdvFilter} />
              <Box sx={{ display: 'flex', gap: 1, px: 2, py: 1, borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50', flexShrink: 0 }}>
                <Button
                  size="small" variant="contained" onClick={handleApplyFilters}
                  disabled={advFilter.conditions.length === 0}
                  sx={{ fontSize: 12, textTransform: 'none' }}
                >
                  Apply Filters
                </Button>
                {activeFilters > 0 && (
                  <Button size="small" variant="outlined" onClick={handleClearFilters}
                    sx={{ fontSize: 12, textTransform: 'none' }}>
                    Clear Applied
                  </Button>
                )}
              </Box>
            </>
          )}

          {/* Wide-table column projection banner */}
          {columnProjection && allSourceColumns && (
            <Box sx={{
              display: 'flex', alignItems: 'center', gap: 1,
              px: 1.5, py: 0.5, bgcolor: '#eff6ff', borderBottom: '1px solid #bfdbfe',
            }}>
              <ColumnsIcon sx={{ fontSize: 14, color: '#2563eb' }} />
              <Typography sx={{ fontSize: 12, color: '#1e40af', fontWeight: 500 }}>
                Showing {cols.length} of {allSourceColumns.length} columns (auto-optimized for performance).
                Select specific columns in the query builder and re-execute to see different columns.
              </Typography>
            </Box>
          )}

          {/* Auto-partition filter banner */}
          {autoPartition && (
            <Box sx={{
              display: 'flex', alignItems: 'center', gap: 1,
              px: 1.5, py: 0.5, bgcolor: '#f0fdf4', borderBottom: '1px solid #bbf7d0',
            }}>
              <InfoIcon sx={{ fontSize: 14, color: '#16a34a' }} />
              <Typography sx={{ fontSize: 12, color: '#166534', fontWeight: 500 }}>
                Showing latest partition ({Object.entries(autoPartition).map(([k, v]) => `${k} = ${v}`).join(', ')}).
                Add a partition filter in the query builder to select a different date range.
              </Typography>
            </Box>
          )}

          {(refreshing || painting) && <LinearProgress sx={{ height: 3, borderRadius: 0 }} />}

          <TableContainer ref={tableContainerRef} sx={{ flex: 1, overflow: 'auto', position: 'relative' }}>
            {(refreshing || painting) && (
              <Box sx={{
                position: 'absolute', inset: 0, zIndex: 10,
                bgcolor: 'rgba(255,255,255,0.55)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                pointerEvents: 'none', backdropFilter: 'blur(2px)',
                transition: 'opacity 0.2s ease',
              }}>
                <Box sx={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1.5,
                  bgcolor: 'rgba(255,255,255,0.97)', border: '1px solid', borderColor: 'divider',
                  borderRadius: 2.5, px: 4, py: 2.5,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                }}>
                  <CircularProgress size={28} thickness={4} sx={{ color: 'primary.main' }} />
                  <Typography variant="body2" color="text.secondary" fontWeight={500} letterSpacing={0.2}>
                    {refreshing ? `Loading page ${page}…` : 'Rendering…'}
                  </Typography>
                </Box>
              </Box>
            )}

            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {/* Row number header */}
                  <TableCell sx={{
                    fontWeight: 700, bgcolor: '#00aeef', color: '#fff', width: 56,
                    textAlign: 'center', textTransform: 'uppercase', fontSize: 11,
                    border: '1px solid rgba(255,255,255,0.25)',
                    ...(pinnedVisible.length > 0 ? { position: 'sticky', left: 0, zIndex: 5, boxShadow: 'inset -1px 0 0 rgba(255,255,255,0.3)' } : {}),
                  }}>
                    #
                  </TableCell>

                  {tableCols.map((col) => {
                    const pi = pinnedIdxMap.get(col);
                    const isPinned = pi !== undefined;
                    const isLastPinned = isPinned && pi === pinnedVisible.length - 1;
                    return (
                      <TableCell key={col}
                        sortDirection={sortColumn === col ? sortDirection as 'asc' | 'desc' : false}
                        sx={{
                          fontWeight: 700, bgcolor: '#00aeef', color: '#fff',
                          whiteSpace: 'nowrap', textTransform: 'uppercase', fontSize: 11,
                          border: '1px solid rgba(255,255,255,0.25)',
                          // Show the pin button on hover of this header cell
                          '&:hover .col-pin-btn': { opacity: 1 },
                          '& .MuiTableSortLabel-root': { color: '#fff !important' },
                          '& .MuiTableSortLabel-root:hover': { color: '#e0f7ff !important' },
                          '& .MuiTableSortLabel-icon': { color: '#fff !important' },
                          ...(isPinned ? {
                            position: 'sticky',
                            left: 56 + pi * FROZEN_COL_WIDTH,
                            zIndex: 4,
                            minWidth: FROZEN_COL_WIDTH,
                            ...(isLastPinned
                              ? { boxShadow: '3px 0 6px rgba(0,0,0,0.15)' }
                              : { boxShadow: 'inset -1px 0 0 rgba(255,255,255,0.3)' }),
                          } : {}),
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
                          <TableSortLabel
                            active={sortColumn === col}
                            direction={sortColumn === col ? sortDirection as 'asc' | 'desc' : 'asc'}
                            onClick={() => handleSort(col)}
                            sx={{ color: '#fff', '& .MuiTableSortLabel-icon': { color: '#fff' } }}
                          >
                            {col}
                          </TableSortLabel>
                          {/* Pin / freeze icon — always visible when pinned, hover-only otherwise */}
                          <Tooltip title={isPinned ? 'Unfreeze column' : 'Freeze column (pin left)'} placement="top">
                            <IconButton
                              className="col-pin-btn"
                              size="small"
                              onClick={(e) => { e.stopPropagation(); togglePinCol(col); }}
                              sx={{
                                p: 0.25,
                                opacity: isPinned ? 1 : 0,
                                transition: 'opacity 0.15s',
                                color: isPinned ? '#e0f7ff' : 'rgba(255,255,255,0.7)',
                                '&:hover': { bgcolor: 'rgba(255,255,255,0.15)' },
                              }}
                            >
                              <PinIcon sx={{ fontSize: 12, transform: isPinned ? 'none' : 'rotate(45deg)' }} />
                            </IconButton>
                          </Tooltip>
                          {/* Column stats icon — shown on header hover, only for execution sources */}
                          {executionId && (
                            <Tooltip title="Column statistics" placement="top">
                              <IconButton
                                className="col-pin-btn"
                                size="small"
                                onClick={(e) => { e.stopPropagation(); openColStats(col); }}
                                sx={{ p: 0.25, opacity: 0, transition: 'opacity 0.15s', color: 'rgba(255,255,255,0.85)', '&:hover': { bgcolor: 'rgba(255,255,255,0.15)' } }}
                              >
                                <InfoIcon sx={{ fontSize: 12 }} />
                              </IconButton>
                            </Tooltip>
                          )}
                        </Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              </TableHead>

              <TableBody>
                {/* Top spacer — keeps scroll thumb positioned correctly */}
                {vPaddingTop > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingTop, p: 0, border: 0 }} /></TableRow>
                )}

                {virtualRows.map((virtualRow) => {
                  const idx  = virtualRow.index;
                  const row  = rows[idx];
                  const rowBg = idx % 2 === 0 ? 'grey.50' : 'background.paper';
                  return (
                    <VirtualRow
                      key={virtualRow.key}
                      virtualRow={virtualRow as VirtualRowProps['virtualRow']}
                      row={row}
                      rowBg={rowBg}
                      startRow={startRow}
                      tableCols={tableCols}
                      pinnedIdxMap={pinnedIdxMap}
                      pinnedVisible={pinnedVisible}
                      refreshing={refreshing}
                      measureRef={rowVirtualizer.measureElement}
                    />
                  );
                })}

                {/* Bottom spacer */}
                {vPaddingBottom > 0 && (
                  <TableRow><TableCell colSpan={tableCols.length + 1} sx={{ height: vPaddingBottom, p: 0, border: 0 }} /></TableRow>
                )}

                {/* Empty state — only show when NOT loading or refreshing */}
                {rows.length === 0 && !loading && !refreshing && (
                  <TableRow>
                    <TableCell colSpan={tableCols.length + 1} sx={{ textAlign: 'center', py: 6, color: 'text.disabled' }}>
                      No rows match the current filters
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination */}
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1, borderTop: 1, borderColor: 'divider', flexShrink: 0 }}>
            <Typography variant="body2" color="text.secondary">
              {isStreaming && (
                <Chip label="S3 Streaming" size="small" color="info" variant="outlined"
                  sx={{ mr: 1, height: 20, fontSize: 10, fontWeight: 700 }} />
              )}
              {isUnknownTotal
                ? `${rows.length.toLocaleString()} rows loaded`
                : `${(data?.filtered_rows ?? totalRows).toLocaleString()} row${(data?.filtered_rows ?? totalRows) !== 1 ? 's' : ''}`}
              {activeFilters > 0 && totalRows !== (data?.filtered_rows ?? totalRows)
                ? ` (filtered from ${totalRows.toLocaleString()})`
                : ''}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Tooltip title="First page">
                <span><IconButton size="small" onClick={() => setPage(1)} disabled={page === 1 || refreshing}><FirstPage /></IconButton></span>
              </Tooltip>
              <Tooltip title="Previous page">
                <span><IconButton size="small" onClick={() => setPage(p => p - 1)} disabled={page === 1 || refreshing}><NavigateBefore /></IconButton></span>
              </Tooltip>
              <Typography variant="body2" sx={{ mx: 1, minWidth: 80, textAlign: 'center', display: 'flex', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                {refreshing && <CircularProgress size={12} />}
                {isUnknownTotal ? `Page ${page} / …` : `Page ${page} / ${totalPages}`}
              </Typography>
              <Tooltip title="Next page">
                <span><IconButton size="small" onClick={() => setPage(p => p + 1)} disabled={(!isUnknownTotal && page >= totalPages) || refreshing}><NavigateNext /></IconButton></span>
              </Tooltip>
              <Tooltip title="Last page">
                <span><IconButton size="small" onClick={() => setPage(totalPages)} disabled={isUnknownTotal || page >= totalPages || refreshing}><LastPage /></IconButton></span>
              </Tooltip>
            </Box>
          </Box>
        </>
      )}

      {/* ── CHART VIEW ───────────────────────────────────── */}
      {viewMode === 'chart' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <ChartConfig cols={allCols} chartType={chartType} setChartType={setChartType}
            xCol={chartXCol} setXCol={setChartXCol} yCol={chartYCol} setYCol={setChartYCol}
            agg={chartAgg} setAgg={setChartAgg} topN={chartTopN} setTopN={setChartTopN}
            seriesCol={chartSeriesCol} setSeriesCol={setChartSeriesCol}
            onRefresh={loadChartData} renderLabel="Render Chart" />
          <Box sx={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', p: 2 }}>
            {chartLoading && <Box sx={{ textAlign: 'center' }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Aggregating {totalRows.toLocaleString()} rows…</Typography></Box>}
            {chartError && <Alert severity="error" sx={{ width: '100%' }}>{chartError}</Alert>}
            {!chartLoading && !chartError && chartData && (
              <>
                <Box sx={{ alignSelf: 'flex-end', mb: 1 }}>
                  <Tooltip title="Export chart as PNG">
                    <Button size="small" variant="outlined" startIcon={<DownloadIcon />} onClick={exportChartPng}>
                      PNG
                    </Button>
                  </Tooltip>
                </Box>
                <Box ref={chartContainerRef} sx={{ width: '100%' }}>
                  <ChartRenderer data={chartData} type={chartType} />
                </Box>
              </>
            )}
            {!chartLoading && !chartError && !chartData && (
              <Box sx={{ textAlign: 'center' }}>
                <ChartIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                <Typography variant="body1" color="text.secondary">Configure settings on the left, then click <strong>Render Chart</strong></Typography>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── PIVOT VIEW (Excel-style) ──────────────────────── */}
      {viewMode === 'pivot' && (
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          {/* ── Pivot Config Sidebar ──────────────────── */}
          <Box sx={{ width: 260, flexShrink: 0, p: 1.5, borderRight: 1, borderColor: 'divider', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 1.5 }}>

            {/* ✨ Smart Suggestions */}
            {pivotPresets.length > 0 && (
              <Box>
                <Typography variant="caption" sx={{ fontWeight: 700, color: 'primary.main', textTransform: 'uppercase', letterSpacing: 0.5, fontSize: 10, mb: 0.75, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  ✨ Smart Suggestions
                </Typography>
                <Stack spacing={0.5}>
                  {pivotPresets.map((preset, i) => (
                    <Paper
                      key={i}
                      variant="outlined"
                      sx={{
                        p: '5px 8px',
                        cursor: 'pointer',
                        borderColor: 'divider',
                        '&:hover': { bgcolor: 'action.hover', borderColor: 'primary.main' },
                        transition: 'all 0.15s',
                      }}
                      onClick={() => {
                        setPivotRowFields(preset.rowFields);
                        setPivotColField(preset.colField);
                        setPivotValues(preset.values.length > 0 ? preset.values : [{ column: '', function: 'count_rows' }]);
                      }}
                    >
                      <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        {preset.icon} {preset.label}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem', display: 'block', mt: 0.1 }}>
                        {preset.description}
                      </Typography>
                    </Paper>
                  ))}
                </Stack>
                <Divider sx={{ mt: 1 }} />
              </Box>
            )}

            {/* Row Fields */}
            <Box>
              <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 0.5, fontSize: 10, mb: 0.5, display: 'block' }}>
                Row Fields (Group By)
              </Typography>
              <Autocomplete
                multiple size="small"
                options={allCols}
                value={pivotRowFields}
                onChange={(_, v) => setPivotRowFields(v)}
                renderInput={(params) => <TextField {...params} placeholder="Select row fields…" size="small" />}
                renderTags={(vals, getTagProps) => vals.map((v, i) => (
                  <Chip {...getTagProps({ index: i })} key={v} label={v} size="small"
                    sx={{ height: 20, fontSize: 10, fontWeight: 600, bgcolor: '#e0f2fe', color: '#0369a1', '& .MuiChip-deleteIcon': { fontSize: 14 } }} />
                ))}
                sx={{ '& .MuiInputBase-root': { minHeight: 32, fontSize: 12 } }}
              />
            </Box>

            {/* Column Field (cross-tab) */}
            <Box>
              <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 0.5, fontSize: 10, mb: 0.5, display: 'block' }}>
                Column Field (Cross-Tab)
              </Typography>
              <ColPicker options={allCols} value={pivotColField} onChange={setPivotColField}
                label="" allowNone nonePlaceholder="None" sx={{ '& .MuiInputBase-root': { fontSize: 12 } }} />
              <Typography variant="caption" sx={{ fontSize: 9, color: 'text.disabled', mt: 0.25, display: 'block' }}>
                Creates columns for each unique value
              </Typography>
            </Box>

            {/* Value Fields */}
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 0.5, fontSize: 10 }}>
                  Values
                </Typography>
                <IconButton size="small" onClick={() => setPivotValues(prev => [...prev, { column: '', function: 'sum' }])}
                  sx={{ p: 0.25 }}>
                  <AddIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </Box>
              {pivotValues.map((pv, idx) => (
                <Box key={idx} sx={{ display: 'flex', gap: 0.5, mb: 0.75, alignItems: 'center' }}>
                  <TextField select size="small" value={pv.function}
                    onChange={e => setPivotValues(prev => prev.map((v, i) => i === idx ? { ...v, function: e.target.value } : v))}
                    sx={{ width: 100, flexShrink: 0, '& .MuiInputBase-root': { fontSize: 11 } }}>
                    {[
                      { value: 'sum', label: 'SUM' },
                      { value: 'avg', label: 'AVG' },
                      { value: 'count', label: 'COUNT' },
                      { value: 'count_distinct', label: 'DISTINCT' },
                      { value: 'max', label: 'MAX' },
                      { value: 'min', label: 'MIN' },
                      { value: 'median', label: 'MEDIAN' },
                      { value: 'stddev', label: 'STDDEV' },
                      { value: 'variance', label: 'VAR' },
                      { value: 'count_rows', label: 'COUNT(*)' },
                    ].map(a => <MenuItem key={a.value} value={a.value}>{a.label}</MenuItem>)}
                  </TextField>
                  {pv.function !== 'count_rows' && (
                    <ColPicker options={allCols} value={pv.column} label=""
                      onChange={(v) => setPivotValues(prev => prev.map((pval, i) => i === idx ? { ...pval, column: v } : pval))}
                      sx={{ flex: 1, '& .MuiInputBase-root': { fontSize: 11 } }} />
                  )}
                  {pivotValues.length > 1 && (
                    <IconButton size="small" onClick={() => setPivotValues(prev => prev.filter((_, i) => i !== idx))}
                      sx={{ p: 0.25, color: 'error.main' }}>
                      <DeleteIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  )}
                </Box>
              ))}
            </Box>

            {/* Top N */}
            <TextField select size="small" label="Max Rows" value={pivotTopN}
              onChange={e => setPivotTopN(+e.target.value)}
              sx={{ '& .MuiInputBase-root': { fontSize: 12 } }}>
              {[50, 100, 200, 500, 1000, 2000, 5000].map(n => <MenuItem key={n} value={n}>{n}</MenuItem>)}
            </TextField>

            <Button variant="contained" size="small" onClick={loadPivotData}
              disabled={pivotRowFields.length === 0 || pivotValues.every(v => !v.column && v.function !== 'count_rows')}
              sx={{ fontWeight: 700 }}>
              Render Pivot
            </Button>
          </Box>

          {/* ── Pivot Result ──────────────────────────── */}
          <Box sx={{ flex: 1, overflow: 'auto', p: 2 }}>
            {pivotLoading && <Box sx={{ textAlign: 'center', mt: 4 }}><CircularProgress size={48} sx={{ mb: 1 }} /><Typography variant="body2" color="text.secondary">Building pivot…</Typography></Box>}
            {pivotError && <Alert severity="error" sx={{ mb: 2 }}>{pivotError}</Alert>}
            {!pivotLoading && !pivotError && pivotData && (() => {
              const pv = pivotData;
              const valLabels = (pv.values || []).map((v: any, i: number) => {
                const fn = v.function === 'count_rows' ? 'COUNT(*)' : `${(v.function || 'sum').toUpperCase()}(${v.column})`;
                return { key: `val_${i}`, label: fn };
              });
              const hasCrossTab = !!pv.col_field && pv.col_values?.length > 0;

              return (
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5, flexWrap: 'wrap' }}>
                    <PivotIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                    <Typography variant="subtitle2">
                      {pv.total_rows?.toLocaleString()} rows
                      {hasCrossTab && <> — cross-tab by <strong>{pv.col_field}</strong> ({pv.col_values.length} values)</>}
                    </Typography>
                    <Chip size="small" label={`${pv.rows?.length || 0} groups`} sx={{ fontSize: 10, height: 20 }} />
                  </Box>

                  <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 'calc(100vh - 200px)' }}>
                    <Table size="small" stickyHeader sx={{ '& td, & th': { fontSize: 11, py: 0.5, px: 1 } }}>
                      <TableHead>
                        {hasCrossTab ? (
                          <>
                            {/* Top header row: row fields + col values spanning */}
                            <TableRow>
                              {pv.row_fields.map((rf: string) => (
                                <TableCell key={rf} rowSpan={2} sx={{ fontWeight: 700, bgcolor: '#f1f5f9', borderRight: '1px solid #e2e8f0', position: 'sticky', top: 0, zIndex: 3 }}>
                                  {rf}
                                </TableCell>
                              ))}
                              {pv.col_values.map((cv: string) => (
                                <TableCell key={cv} colSpan={valLabels.length} align="center"
                                  sx={{ fontWeight: 700, bgcolor: '#e0f2fe', borderRight: '1px solid #bae6fd', borderBottom: '1px solid #bae6fd', position: 'sticky', top: 0, zIndex: 2 }}>
                                  {cv}
                                </TableCell>
                              ))}
                              <TableCell colSpan={valLabels.length} align="center"
                                sx={{ fontWeight: 700, bgcolor: '#fef3c7', borderRight: '1px solid #fde68a', position: 'sticky', top: 0, zIndex: 2 }}>
                                Total
                              </TableCell>
                              <TableCell rowSpan={2} sx={{ fontWeight: 700, bgcolor: '#f1f5f9', position: 'sticky', top: 0, zIndex: 3, textAlign: 'right' }}>
                                Count
                              </TableCell>
                            </TableRow>
                            {/* Sub header row: value labels under each col value */}
                            <TableRow>
                              {pv.col_values.map((cv: string) =>
                                valLabels.map((vl: any) => (
                                  <TableCell key={`${cv}_${vl.key}`} align="right"
                                    sx={{ fontWeight: 600, bgcolor: '#f0f9ff', fontSize: 9, borderRight: '1px solid #e2e8f0', position: 'sticky', top: 28, zIndex: 2 }}>
                                    {vl.label}
                                  </TableCell>
                                ))
                              )}
                              {valLabels.map((vl: any) => (
                                <TableCell key={`total_${vl.key}`} align="right"
                                  sx={{ fontWeight: 600, bgcolor: '#fffbeb', fontSize: 9, borderRight: '1px solid #fde68a', position: 'sticky', top: 28, zIndex: 2 }}>
                                  {vl.label}
                                </TableCell>
                              ))}
                            </TableRow>
                          </>
                        ) : (
                          <TableRow>
                            {pv.row_fields.map((rf: string) => (
                              <TableCell key={rf} sx={{ fontWeight: 700, bgcolor: '#f1f5f9' }}>{rf}</TableCell>
                            ))}
                            {valLabels.map((vl: any) => (
                              <TableCell key={vl.key} align="right" sx={{ fontWeight: 700, bgcolor: '#f1f5f9' }}>{vl.label}</TableCell>
                            ))}
                            <TableCell align="right" sx={{ fontWeight: 700, bgcolor: '#f1f5f9' }}>Count</TableCell>
                          </TableRow>
                        )}
                      </TableHead>
                      <TableBody>
                        {(pv.rows || []).map((row: any, ri: number) => (
                          <TableRow key={ri} hover sx={{ '&:nth-of-type(even)': { bgcolor: '#fafbfc' } }}>
                            {pv.row_fields.map((rf: string) => (
                              <TableCell key={rf} sx={{ fontWeight: 600, borderRight: '1px solid #f1f5f9', whiteSpace: 'nowrap' }}>
                                {row[rf]}
                              </TableCell>
                            ))}
                            {hasCrossTab ? (
                              <>
                                {pv.col_values.map((cv: string) =>
                                  valLabels.map((vl: any) => {
                                    const val = row._cells?.[cv]?.[vl.key];
                                    return (
                                      <TableCell key={`${cv}_${vl.key}`} align="right"
                                        sx={{ fontVariantNumeric: 'tabular-nums', borderRight: '1px solid #f1f5f9' }}>
                                        {val != null ? fmtNum(val) : '—'}
                                      </TableCell>
                                    );
                                  })
                                )}
                                {valLabels.map((vl: any) => {
                                  const val = row._totals?.[vl.key];
                                  return (
                                    <TableCell key={`total_${vl.key}`} align="right"
                                      sx={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums', bgcolor: '#fffbeb', borderRight: '1px solid #fde68a' }}>
                                      {val != null ? fmtNum(val) : '—'}
                                    </TableCell>
                                  );
                                })}
                              </>
                            ) : (
                              valLabels.map((vl: any) => {
                                const val = row._values?.[vl.key];
                                return (
                                  <TableCell key={vl.key} align="right" sx={{ fontVariantNumeric: 'tabular-nums' }}>
                                    {val != null ? fmtNum(val) : '—'}
                                  </TableCell>
                                );
                              })
                            )}
                            <TableCell align="right" sx={{ fontVariantNumeric: 'tabular-nums', color: 'text.secondary' }}>
                              {(row._count || 0).toLocaleString()}
                            </TableCell>
                          </TableRow>
                        ))}
                        {/* Grand total row */}
                        {pv.grand_totals && (
                          <TableRow sx={{ bgcolor: '#f8fafc', borderTop: '2px solid #94a3b8' }}>
                            <TableCell colSpan={pv.row_fields.length} sx={{ fontWeight: 800, fontSize: 11 }}>Grand Total</TableCell>
                            {hasCrossTab ? (
                              <>
                                {pv.col_values.map((cv: string) =>
                                  valLabels.map((vl: any) => {
                                    const val = pv.grand_totals._cells?.[cv]?.[vl.key];
                                    return (
                                      <TableCell key={`gt_${cv}_${vl.key}`} align="right"
                                        sx={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums', borderRight: '1px solid #f1f5f9' }}>
                                        {val != null ? fmtNum(val) : '—'}
                                      </TableCell>
                                    );
                                  })
                                )}
                                {valLabels.map((vl: any) => {
                                  const val = pv.grand_totals._totals?.[vl.key];
                                  return (
                                    <TableCell key={`gt_total_${vl.key}`} align="right"
                                      sx={{ fontWeight: 800, fontVariantNumeric: 'tabular-nums', bgcolor: '#fef3c7' }}>
                                      {val != null ? fmtNum(val) : '—'}
                                    </TableCell>
                                  );
                                })}
                              </>
                            ) : (
                              valLabels.map((vl: any) => {
                                const val = pv.grand_totals[vl.key];
                                return (
                                  <TableCell key={`gt_${vl.key}`} align="right" sx={{ fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>
                                    {val != null ? fmtNum(val) : '—'}
                                  </TableCell>
                                );
                              })
                            )}
                            <TableCell align="right" sx={{ fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>
                              {(pv.grand_totals._count || pv.grand_totals?._totals?._count || pv.total_rows || 0).toLocaleString()}
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              );
            })()}
            {!pivotLoading && !pivotError && !pivotData && (
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                <Box sx={{ textAlign: 'center' }}>
                  <PivotIcon sx={{ fontSize: 72, opacity: 0.1, color: 'text.secondary', display: 'block', mx: 'auto', mb: 2 }} />
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 1 }}>
                    Configure your pivot like Excel
                  </Typography>
                  <Typography variant="caption" color="text.disabled">
                    Drag columns to Row Fields, set Column Field for cross-tabs, add Value fields with different aggregation functions
                  </Typography>
                </Box>
              </Box>
            )}
          </Box>
        </Box>
      )}

      {/* ── Column Picker Dialog ──────────────────────────── */}
      <Dialog
        open={showColPanel}
        onClose={() => { setShowColPanel(false); setColSearch(''); }}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { maxHeight: '80vh' } }}
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6">Columns</Typography>
            <Typography variant="caption" color="text.secondary">
              {displayCols.length} visible · {pinnedCols.length} pinned · {cols.length} loaded
              {columnProjection && allSourceColumns ? ` · ${allSourceColumns.length} in source` : ''}
            </Typography>
          </Box>
          {columnProjection && allSourceColumns && (
            <Typography variant="caption" sx={{ color: '#2563eb', display: 'block', mt: 0.5 }}>
              Only {cols.length} of {allSourceColumns.length} columns were fetched.
              Use the query builder column selector to choose specific columns, then re-execute.
            </Typography>
          )}
        </DialogTitle>

        <DialogContent sx={{ pt: 0 }}>
          <TextField
            size="small" fullWidth placeholder="Search columns…" value={colSearch}
            onChange={e => setColSearch(e.target.value)} autoFocus
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment> }}
            sx={{ mb: 1.5 }}
          />

          <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
            <Button size="small" variant="outlined"
              onClick={() => setVisibleCols(null)}
              sx={{ fontSize: 12, textTransform: 'none' }}>
              Show all
            </Button>
            {cols.length > maxVisCols && (
              <Button size="small" variant="outlined"
                onClick={() => setVisibleCols(new Set(cols.slice(0, maxVisCols)))}
                sx={{ fontSize: 12, textTransform: 'none' }}>
                First {maxVisCols}
              </Button>
            )}
            <Button size="small" variant="outlined" color="error"
              onClick={() => setPinnedCols([])}
              disabled={pinnedCols.length === 0}
              sx={{ fontSize: 12, textTransform: 'none', ml: 'auto' }}>
              Unpin all
            </Button>
          </Box>

          <Box sx={{ overflow: 'auto', maxHeight: 380 }}>
            {filteredColList.map(col => {
              const isVisible = visibleCols === null || visibleCols.has(col);
              const isPinned  = pinnedCols.includes(col);
              return (
                <Box key={col} sx={{
                  display: 'flex', alignItems: 'center', gap: 0.5,
                  py: 0.25, px: 0.5, borderRadius: 1,
                  '&:hover': { bgcolor: 'action.hover' },
                }}>
                  <Checkbox
                    checked={isVisible} size="small"
                    onChange={e => toggleColVisibility(col, e.target.checked)}
                    sx={{ p: 0.5 }}
                  />
                  <Typography variant="body2" title={col}
                    sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {col}
                  </Typography>
                  {isPinned && (
                    <Chip label="pinned" size="small" color="primary" variant="filled"
                      sx={{ height: 16, fontSize: 10, mr: 0.5, '& .MuiChip-label': { px: 0.75 } }} />
                  )}
                  <Tooltip title={isPinned ? 'Unpin' : 'Pin to left'}>
                    <IconButton size="small" onClick={() => togglePinCol(col)}
                      sx={{ color: isPinned ? 'primary.main' : 'text.disabled', p: 0.5 }}>
                      <PinIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </Tooltip>
                </Box>
              );
            })}
            {filteredColList.length === 0 && (
              <Typography variant="body2" color="text.disabled" sx={{ textAlign: 'center', py: 3 }}>
                No columns match "{colSearch}"
              </Typography>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => { setShowColPanel(false); setColSearch(''); }} variant="contained" size="small">
            Done
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Column Stats Dialog ───────────────────────────── */}
      <Dialog
        open={statsCol !== null}
        onClose={() => { setStatsCol(null); setStatsData(null); }}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" sx={{ fontFamily: 'monospace', fontSize: 15 }}>{statsCol}</Typography>
            <IconButton size="small" onClick={() => { setStatsCol(null); setStatsData(null); }}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <Typography variant="caption" color="text.secondary">Column Statistics</Typography>
        </DialogTitle>
        <DialogContent>
          {statsLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}><CircularProgress size={28} /></Box>}
          {!statsLoading && !statsData && <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>No stats available</Typography>}
          {!statsLoading && statsData && (() => {
            const s = statsData;
            const nullPct = s.total_rows > 0 ? ((s.null_count / s.total_rows) * 100).toFixed(1) : '0.0';
            const fillPct = s.total_rows > 0 ? (((s.total_rows - s.null_count) / s.total_rows) * 100) : 0;
            return (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
                  {[
                    ['Type', s.type],
                    ['Total Rows', fmtNum(s.total_rows)],
                    ['Null Count', `${fmtNum(s.null_count)} (${nullPct}%)`],
                    ['Unique Values', fmtNum(s.unique_count)],
                    ...(s.min !== undefined ? [
                      ['Min', fmtNum(s.min)],
                      ['Max', fmtNum(s.max)],
                      ['Mean', fmtNum(s.mean)],
                    ] : []),
                  ].map(([label, val]) => (
                    <Paper key={label as string} variant="outlined" sx={{ p: 1, borderRadius: 1 }}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>{label}</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>{val}</Typography>
                    </Paper>
                  ))}
                </Box>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" color="text.secondary">Fill rate</Typography>
                    <Typography variant="caption" color="text.secondary">{fillPct.toFixed(1)}%</Typography>
                  </Box>
                  <Box sx={{ height: 8, bgcolor: 'grey.200', borderRadius: 1, overflow: 'hidden' }}>
                    <Box sx={{ height: '100%', width: `${fillPct}%`, bgcolor: fillPct > 90 ? 'success.main' : fillPct > 50 ? 'warning.main' : 'error.main', borderRadius: 1 }} />
                  </Box>
                </Box>
              </Box>
            );
          })()}
        </DialogContent>
      </Dialog>

    </Wrapper>
  );
};

export default DataGridViewer;
