// @ts-nocheck
/**
 * GlobalAssistantPanel — unified pattern-based assistant (no LLM).
 *
 * Intents (auto-detected from input):
 *   nl2sql   — natural-language → SQL generation (11 patterns, backend)
 *   analyze  — SQL anti-pattern / lint analysis
 *   schema   — column list for a table (schema cache + usage stats)
 *   data     — last execution result schema + row count
 *   tables   — most-used tables ranking
 *   help     — built-in feature guide
 *
 * Context-aware: reads AssistantContext so pages can register their current
 * connection/tables — improves NL→SQL when schema is known.
 *
 * "Use this SQL" stores SQL in sessionStorage → SqlQueryPage / QueryBuilder
 * reads it on mount.
 */
import React, { useState, useRef, useEffect } from 'react';
import {
  Box, Typography, TextField, IconButton, Paper, Chip, Stack, Divider,
  Alert, CircularProgress, Tooltip, Button,
} from '@mui/material';
import {
  Send as SendIcon,
  ContentCopy as CopyIcon,
  PlayArrow as UseIcon,
  AutoAwesome as MagicIcon,
  LightbulbOutlined as TipIcon,
  TableChart as TableIcon,
  Terminal as SqlIcon,
  BugReport as AnalyzeIcon,
  HelpOutline as HelpIcon,
  Schema as SchemaIcon,
  DataObject as DataIcon,
  MenuBook as DocsIcon,
  GridOn as GridIcon,
  ThumbUp as ThumbUpIcon,
  ThumbDown as ThumbDownIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useAssistantContext } from '../context/AssistantContext';

// ── Types ─────────────────────────────────────────────────────────────────────

type IntentKind = 'nl2sql' | 'analyze' | 'schema' | 'data' | 'tables' | 'help' | 'greet' | 'docs' | 'griddata';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  intent?: IntentKind;
  // NL→SQL
  sql?: string;
  confidence?: number;
  pattern?: string;
  explanation?: string;
  alternatives?: string[];
  warnings?: string[];
  // Analysis
  analysisWarnings?: any[];
  // Schema / data
  schemaResult?: any;
  dataResult?: any;
  // Docs
  docsResults?: any[];
  // Tables
  tables?: any[];
  // Grid data query
  gridResult?: any;
  // Feedback state for nl2sql messages
  feedbackGiven?: 1 | -1 | null;
}

// ── Intent detection ──────────────────────────────────────────────────────────

const SQL_KEYWORDS     = /\b(select|from|where|join|group\s+by|order\s+by|having|insert|update|delete|create|drop|with\s+\w+\s+as)\b/i;
const ANALYZE_TRIGGERS = /^(analyze|check|review|lint|validate|fix|why|what.s wrong|issues with|problems with)/i;
const TABLE_TRIGGERS   = /\b(what table|which table|show table|top table|list table|available table|suggest table|find table|tables? (for|in|about|to use))\b/i;
const SCHEMA_TRIGGERS  = /\b(what columns?|describe|schema of|columns? (in|of|for)|fields? (in|of|for)|structure of|tell me about table)\b/i;
const DATA_TRIGGERS    = /\b(last result|last query result|my last (result|query)|recent result|summarize result|result summary|what.s in (my )?(last|recent) (result|data))\b/i;
const HELP_TRIGGERS    = /^(help|\?|what can you do|capabilities|features|how (do|can) (i|you)|commands|examples)$/i;
const GREET_TRIGGERS   = /^(hi|hello|hey|howdy|hola|good (morning|afternoon|evening)|what.?s up|sup|yo|greetings|morning|evening|afternoon)[\s!?.]*$/i;
const DOCS_TRIGGERS      = /^(how (do|can|to)|what (is|are|does)|explain|tell me (about|how)|show me how|what.?s the|how does|can i|does it support|is there|walk me through|guide|tutorial|document)/i;
const GRIDDATA_TRIGGERS  = /\b(max(imum)?|min(imum)?|avg|average|mean|sum|total|count (where|by)|group by|top \d+|distinct( values?)?|first \d+|rows? where|filter|show where)\b/i;

const GREET_REPLIES = [
  "Hey! Ready to help with your data. Try 'top 10 orders by revenue' or 'columns in customers'.",
  "Hi there! What data question can I answer for you today?",
  "Hello! I can generate SQL, browse your schema, or analyze queries — just ask.",
  "Hey! Great to see you. Ask me anything about your data.",
  "Hi! Whether it's SQL, schema, or analysis — I've got you covered.",
];

function detectIntent(input: string, hasGrid = false): IntentKind {
  const q = input.trim();
  if (GREET_TRIGGERS.test(q))   return 'greet';
  if (HELP_TRIGGERS.test(q))    return 'help';
  if (DATA_TRIGGERS.test(q))    return 'data';
  if (SCHEMA_TRIGGERS.test(q))  return 'schema';
  if (TABLE_TRIGGERS.test(q))   return 'tables';
  if (ANALYZE_TRIGGERS.test(q) || SQL_KEYWORDS.test(q)) return 'analyze';
  // Grid data queries — only when a result grid is loaded
  if (hasGrid && GRIDDATA_TRIGGERS.test(q)) return 'griddata';
  // Questions about features/architecture → docs search
  if (DOCS_TRIGGERS.test(q))    return 'docs';
  return 'nl2sql';
}

/** Extract table name from a schema question. */
function extractTableFromSchema(q: string): string {
  const patterns = [
    /(?:describe|schema of|structure of|tell me about table)\s+(\S+)/i,
    /(?:columns?|fields?)\s+(?:in|of|for)\s+(\S+)/i,
    /(?:what columns? (?:does|in|of))\s+(\S+)/i,
  ];
  for (const p of patterns) {
    const m = q.match(p);
    if (m) return m[1].replace(/[?.,;:!]$/, '');
  }
  // Last word fallback
  const words = q.trim().split(/\s+/);
  return words[words.length - 1].replace(/[?.,;:!]$/, '');
}

// ── Examples ──────────────────────────────────────────────────────────────────

const EXAMPLES = [
  { label: 'top 10 orders by revenue',         intent: 'nl2sql'   as IntentKind, icon: <SqlIcon    sx={{ fontSize: 13 }} /> },
  { label: 'count orders by status',           intent: 'nl2sql'   as IntentKind, icon: <SqlIcon    sx={{ fontSize: 13 }} /> },
  { label: 'analyze SELECT * FROM orders',     intent: 'analyze'  as IntentKind, icon: <AnalyzeIcon sx={{ fontSize: 13 }} /> },
  { label: 'columns in customers',             intent: 'schema'   as IntentKind, icon: <SchemaIcon  sx={{ fontSize: 13 }} /> },
  { label: 'what tables are available',        intent: 'tables'   as IntentKind, icon: <TableIcon   sx={{ fontSize: 13 }} /> },
  { label: 'last result',                      intent: 'data'     as IntentKind, icon: <DataIcon    sx={{ fontSize: 13 }} /> },
  { label: 'max of revenue (grid)',            intent: 'griddata' as IntentKind, icon: <GridIcon    sx={{ fontSize: 13 }} /> },
  { label: 'count by status (grid)',           intent: 'griddata' as IntentKind, icon: <GridIcon    sx={{ fontSize: 13 }} /> },
  { label: 'how do I create a materialized view', intent: 'docs'  as IntentKind, icon: <DocsIcon   sx={{ fontSize: 13 }} /> },
  { label: 'what is the circuit breaker?',     intent: 'docs'     as IntentKind, icon: <DocsIcon   sx={{ fontSize: 13 }} /> },
  { label: 'help',                             intent: 'help'     as IntentKind, icon: <HelpIcon    sx={{ fontSize: 13 }} /> },
];

const HELP_TEXT = `**QueryStudio Assistant** — pattern-based, no AI required

**Generate SQL** from plain English:
• "top 10 customers by revenue"
• "average salary by department"
• "orders where status is pending and amount > 100"
• "sales between 2025-01-01 and 2025-12-31"

**Analyze SQL** for issues:
• "analyze SELECT * FROM big_table"
• "check: SELECT a, b FROM t JOIN u"

**Schema lookup** — see columns for any table:
• "columns in orders"
• "describe customers"
• "schema of products"

**Last result** — inspect your most recent query output:
• "last result"
• "what's in my last result?"

**Grid data queries** — ask questions about the data currently shown in the grid:
• "max of revenue"
• "count by status"
• "top 5 by amount"
• "distinct values of category"
• "sum of quantity"
• "rows where country = US"

**Find tables** by usage rank:
• "what tables are available?"

**Feature docs & how-to** — ask in plain English:
• "how do I create a materialized view?"
• "what is the circuit breaker?"
• "how does lineage work?"
• "can I export to PDF?"
• "explain S3 live streaming"

**Tips:**
• The assistant knows your current connection — NL→SQL uses your schema
• "Use in SQL Editor" opens the query ready to run
• Works on every page — no need to leave what you're doing
`;

const SEV_COLOUR = { error: 'error', warning: 'warning', info: 'info' } as const;

// ── Component ─────────────────────────────────────────────────────────────────

interface GlobalAssistantPanelProps {
  onClose?: () => void;
}

const GlobalAssistantPanel: React.FC<GlobalAssistantPanelProps> = ({ onClose }) => {
  const navigate    = useNavigate();
  const assistCtx   = useAssistantContext();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput]       = useState('');
  const [loading, setLoading]   = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Send ──────────────────────────────────────────────────────────────────

  const handleSend = async (raw?: string) => {
    const q = (raw ?? input).trim();
    if (!q) return;
    setInput('');
    const msgId  = Date.now().toString();
    const intent = detectIntent(q, !!assistCtx.executionId);
    setMessages(prev => [...prev, { id: msgId + '_u', role: 'user', content: q, intent }]);
    setLoading(true);

    try {
      // ── Greet ─────────────────────────────────────────────────────────────
      if (intent === 'greet') {
        const reply = GREET_REPLIES[Math.floor(Math.random() * GREET_REPLIES.length)];
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'greet', content: reply }]);
        return;
      }

      // ── Help ──────────────────────────────────────────────────────────────
      if (intent === 'help') {
        setMessages(prev => [...prev, { id: msgId + '_a', role: 'assistant', intent: 'help', content: HELP_TEXT }]);
        return;
      }

      // ── Table list ────────────────────────────────────────────────────────
      if (intent === 'tables') {
        const r = await (api as any).getTopTables(assistCtx.connectionId);
        const tables = (r?.tables || r || []).slice(0, 12);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'tables',
          content: tables.length
            ? `Found ${tables.length} most-used tables:`
            : 'No table usage data yet. Run some queries first.',
          tables,
        }]);
        return;
      }

      // ── Schema lookup ─────────────────────────────────────────────────────
      if (intent === 'schema') {
        const tableName = extractTableFromSchema(q);
        const r = await (api as any).getSuggestSchema(tableName, assistCtx.connectionId);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'schema',
          content: r.columns?.length
            ? `${r.table} — ${r.columns.length} column${r.columns.length !== 1 ? 's' : ''}${r.source === 'usage_stats' ? ' (from usage history)' : ''}`
            : (r.message || `No schema found for "${tableName}".`),
          schemaResult: r,
        }]);
        return;
      }

      // ── Last result ───────────────────────────────────────────────────────
      if (intent === 'data') {
        const r = await (api as any).getLastResultInfo();
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'data',
          content: r.found
            ? `Last result: ${r.total_rows?.toLocaleString() || '?'} rows, ${r.columns?.length || '?'} columns`
            : (r.message || 'No result data found.'),
          dataResult: r,
        }]);
        return;
      }

      // ── Analyze ───────────────────────────────────────────────────────────
      if (intent === 'analyze') {
        const sql = q.replace(/^(analyze|check|review|lint|validate|fix):?\s*/i, '').trim();
        if (!sql || sql.length < 5) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'analyze',
            content: 'Include the SQL to analyze, e.g.: analyze SELECT * FROM my_table',
          }]);
          return;
        }
        const r = await (api as any).analyzeQuery(sql, assistCtx.connectionType || 'duckdb', []);
        const warns = r?.warnings || [];
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'analyze',
          content: warns.length
            ? `Found ${warns.length} issue${warns.length > 1 ? 's' : ''}:`
            : '✅ No issues detected — query looks clean.',
          analysisWarnings: warns,
          sql,
        }]);
        return;
      }

      // ── Docs / feature questions ──────────────────────────────────────────
      if (intent === 'docs') {
        const r = await (api as any).getSuggestDocs(q);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'docs',
          content: r.found
            ? `Found ${r.results.length} relevant section${r.results.length !== 1 ? 's' : ''} in the docs:`
            : "Hmm, I didn't find a specific match in the docs. Try rephrasing, or type 'help' for a feature overview.",
          docsResults: r.results || [],
        }]);
        return;
      }

      // ── Grid data query ───────────────────────────────────────────────────
      if (intent === 'griddata') {
        const r = await (api as any).dataQuery(assistCtx.executionId, q, assistCtx.resultColumns || []);
        setMessages(prev => [...prev, {
          id: msgId + '_a', role: 'assistant', intent: 'griddata',
          content: r.found
            ? `${r.answer}:`
            : (r.message || "Couldn't run that query on the current grid."),
          gridResult: r,
        }]);
        return;
      }

      // ── NL → SQL (default) ────────────────────────────────────────────────
      const r = await (api as any).nlToSql({
        question: q,
        connection_id: assistCtx.connectionId,
        tables: assistCtx.tables,
        columns: assistCtx.columns,
        connection_type: assistCtx.connectionType || 'duckdb',
      });

      // Low confidence — try docs before showing a bad SQL template
      if ((r.confidence || 0) < 0.25) {
        const docsR = await (api as any).getSuggestDocs(q);
        if (docsR.found && docsR.results?.length > 0) {
          setMessages(prev => [...prev, {
            id: msgId + '_a', role: 'assistant', intent: 'docs',
            content: `I couldn't generate SQL for that, but here's what the docs say:`,
            docsResults: docsR.results,
          }]);
          return;
        }
      }

      setMessages(prev => [...prev, {
        id: msgId + '_a', role: 'assistant', intent: 'nl2sql',
        content: r.explanation || 'SQL generated.',
        sql: r.sql, confidence: r.confidence, pattern: r.pattern_matched,
        warnings: r.warnings || [], alternatives: r.alternatives || [],
      }]);

    } catch (e: any) {
      const raw = e?.message || '';
      // HTML response → endpoint doesn't exist in running server (needs restart)
      const needsRestart = raw.includes('DOCTYPE') || raw.includes('token \'<\'') || raw.includes("token '<'");
      setMessages(prev => [...prev, {
        id: msgId + '_e', role: 'assistant', intent,
        content: needsRestart
          ? "The backend needs a restart to pick up new features. Ask your admin to restart the QueryStudio server, then try again."
          : `Error: ${raw || 'Request failed.'}`,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleUseSql = (sql: string) => {
    sessionStorage.setItem('nl_sql_pending', sql);
    navigate('/sql');
    onClose?.();
  };

  const copyToClipboard = (text: string) => navigator.clipboard.writeText(text).catch(() => {});

  const handleFeedback = (msgId: string, msg: Message, rating: 1 | -1) => {
    setMessages(prev => prev.map(m => m.id === msgId ? { ...m, feedbackGiven: rating } : m));
    if (msg.sql) {
      (api as any).saveNlFeedback(
        msg.content, msg.sql, rating,
        assistCtx.connectionType || 'duckdb',
        assistCtx.tables?.slice(0, 5).join(',') || undefined,
      ).catch(() => {});
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const contextChip = (assistCtx.connectionId != null || assistCtx.executionId) && (
    <Stack direction="row" spacing={0.4} flexWrap="wrap">
      {assistCtx.connectionId != null && (
        <Chip size="small"
          label={`conn #${assistCtx.connectionId}${assistCtx.pageName ? ` · ${assistCtx.pageName}` : ''}`}
          sx={{ height: 16, fontSize: '0.62rem', bgcolor: 'action.selected' }} />
      )}
      {assistCtx.executionId && (
        <Chip size="small" icon={<GridIcon sx={{ fontSize: 10 }} />}
          label={`${assistCtx.resultColumns?.length || '?'} cols loaded`}
          color="info" variant="outlined"
          sx={{ height: 16, fontSize: '0.62rem' }} />
      )}
    </Stack>
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* Header */}
      <Box sx={{ px: 2, py: 1, borderBottom: 1, borderColor: 'divider',
                 display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'background.paper', flexShrink: 0 }}>
        <MagicIcon sx={{ color: 'secondary.main', fontSize: 18 }} />
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="subtitle2" fontWeight={700} lineHeight={1.2}>QueryStudio Assistant</Typography>
          <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap">
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.66rem' }}>
              SQL · Schema · Analyze · Tables
            </Typography>
            {contextChip}
          </Stack>
        </Box>
      </Box>

      {/* Messages */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1.5, py: 1,
                 display: 'flex', flexDirection: 'column', gap: 1.25 }}>

        {/* Empty-state examples */}
        {messages.length === 0 && (
          <Box sx={{ mt: 0.5 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.25, fontSize: '0.8rem' }}>
              Ask about your data — generate SQL, browse schema, analyze queries:
            </Typography>
            <Stack spacing={0.5}>
              {EXAMPLES.map((ex, i) => (
                <Chip key={i} icon={ex.icon} label={ex.label} size="small" variant="outlined"
                  sx={{ cursor: 'pointer', justifyContent: 'flex-start', fontSize: '0.73rem', height: 26 }}
                  onClick={() => handleSend(ex.label)} />
              ))}
            </Stack>
          </Box>
        )}

        {/* Message list */}
        {messages.map(msg => (
          <Box key={msg.id} sx={{ display: 'flex', flexDirection: 'column',
                                  alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>

            {/* User bubble */}
            {msg.role === 'user' && (
              <Paper elevation={0} sx={{
                px: 1.5, py: 0.75, bgcolor: 'secondary.main', color: 'secondary.contrastText',
                borderRadius: '12px 12px 2px 12px', maxWidth: '88%',
              }}>
                <Typography variant="body2" sx={{ fontSize: '0.82rem' }}>{msg.content}</Typography>
              </Paper>
            )}

            {/* Assistant response */}
            {msg.role === 'assistant' && (
              <Box sx={{ maxWidth: '100%', width: '100%' }}>

                <Typography variant="body2" color="text.secondary"
                  sx={{ mb: 0.5, fontSize: '0.79rem', whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </Typography>

                {/* ── NL→SQL ── */}
                {msg.intent === 'nl2sql' && msg.sql && (
                  <>
                    {msg.confidence != null && (
                      <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mb: 0.5 }}>
                        <Chip label={`${Math.round(msg.confidence * 100)}% match`} size="small"
                          color={msg.confidence >= 0.8 ? 'success' : msg.confidence >= 0.5 ? 'warning' : 'error'}
                          sx={{ height: 18, fontSize: '0.68rem' }} />
                        {msg.pattern && (
                          <Chip label={msg.pattern} size="small" variant="outlined"
                            sx={{ height: 18, fontSize: '0.68rem' }} />
                        )}
                      </Stack>
                    )}
                    <SqlBlock sql={msg.sql} onUse={handleUseSql} onCopy={copyToClipboard} />
                    {msg.warnings && msg.warnings.length > 0 && (
                      <Alert severity="warning" icon={<TipIcon fontSize="small" />}
                        sx={{ mt: 0.75, py: 0.25, fontSize: '0.73rem' }}>
                        {msg.warnings.join(' ')}
                      </Alert>
                    )}
                    {msg.alternatives && msg.alternatives.length > 0 && (
                      <Box sx={{ mt: 0.5 }}>
                        <Typography variant="caption" color="text.secondary">Alternatives:</Typography>
                        {msg.alternatives.map((alt, i) => (
                          <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.25 }}>
                            <Box component="code" sx={{ fontSize: '0.7rem', color: 'text.secondary', flex: 1, fontFamily: 'monospace' }}>{alt}</Box>
                            <Tooltip title="Use this">
                              <IconButton size="small" onClick={() => handleUseSql(alt)}>
                                <UseIcon sx={{ fontSize: 12 }} />
                              </IconButton>
                            </Tooltip>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </>
                )}

                {/* ── Analyze ── */}
                {msg.intent === 'analyze' && msg.analysisWarnings && msg.analysisWarnings.length > 0 && (
                  <Stack spacing={0.5} sx={{ mt: 0.5 }}>
                    {msg.analysisWarnings.map((w: any, i: number) => (
                      <Alert key={i} severity={SEV_COLOUR[w.severity] ?? 'info'}
                        sx={{ py: 0.25, '& .MuiAlert-message': { fontSize: '0.73rem' } }}>
                        <strong>{w.code}</strong> — {w.message}
                        {w.suggestion && (
                          <Typography variant="caption" color="text.secondary" display="block">
                            💡 {w.suggestion}
                          </Typography>
                        )}
                      </Alert>
                    ))}
                    {msg.sql && (
                      <Box sx={{ mt: 0.5 }}>
                        <SqlBlock sql={msg.sql} onUse={handleUseSql} onCopy={copyToClipboard} />
                      </Box>
                    )}
                  </Stack>
                )}

                {/* ── Schema ── */}
                {msg.intent === 'schema' && msg.schemaResult && msg.schemaResult.columns?.length > 0 && (
                  <SchemaTable result={msg.schemaResult} onUseSql={handleUseSql} />
                )}

                {/* ── Last result / data ── */}
                {msg.intent === 'data' && msg.dataResult?.found && (
                  <DataResultPanel result={msg.dataResult} onUseSql={handleUseSql} />
                )}

                {/* ── Grid data ── */}
                {msg.intent === 'griddata' && msg.gridResult?.found && (
                  <GridDataResultPanel result={msg.gridResult} />
                )}
                {msg.intent === 'griddata' && !msg.gridResult?.found && msg.gridResult?.message && (
                  <Alert severity="info" sx={{ mt: 0.5, py: 0.25, fontSize: '0.73rem' }}>
                    {msg.gridResult.message}
                    {msg.gridResult.sql && (
                      <Box component="pre" sx={{ mt: 0.4, fontFamily: 'monospace', fontSize: '0.65rem', color: 'text.secondary', whiteSpace: 'pre-wrap', m: 0 }}>
                        {msg.gridResult.sql}
                      </Box>
                    )}
                  </Alert>
                )}

                {/* ── Docs ── */}
                {(msg.intent === 'docs' || msg.intent === 'nl2sql') && msg.docsResults && msg.docsResults.length > 0 && (
                  <DocsResultPanel results={msg.docsResults} />
                )}

                {/* ── NL→SQL feedback ── */}
                {msg.intent === 'nl2sql' && msg.sql && (
                  <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mt: 0.5 }}>
                    <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.65rem' }}>
                      Helpful?
                    </Typography>
                    <Tooltip title="Thumbs up — save as a good example">
                      <IconButton size="small" sx={{ p: 0.25 }}
                        color={msg.feedbackGiven === 1 ? 'success' : 'default'}
                        onClick={() => handleFeedback(msg.id, msg, 1)}>
                        <ThumbUpIcon sx={{ fontSize: 12 }} />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Thumbs down — mark as incorrect">
                      <IconButton size="small" sx={{ p: 0.25 }}
                        color={msg.feedbackGiven === -1 ? 'error' : 'default'}
                        onClick={() => handleFeedback(msg.id, msg, -1)}>
                        <ThumbDownIcon sx={{ fontSize: 12 }} />
                      </IconButton>
                    </Tooltip>
                    {msg.feedbackGiven != null && (
                      <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.63rem' }}>
                        {msg.feedbackGiven === 1 ? 'Thanks! Saved as a good example.' : 'Noted. Thanks for the feedback.'}
                      </Typography>
                    )}
                  </Stack>
                )}

                {/* ── Table suggestions ── */}
                {msg.intent === 'tables' && msg.tables && msg.tables.length > 0 && (
                  <Stack spacing={0.25} sx={{ mt: 0.5 }}>
                    {msg.tables.map((t: any, i: number) => {
                      const name = t.table_name || t.object_name || t;
                      return (
                        <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                          <TableIcon sx={{ fontSize: 12, color: 'text.secondary' }} />
                          <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: '0.73rem', flex: 1 }}>
                            {name}
                          </Typography>
                          {t.use_count && (
                            <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.65rem' }}>
                              ×{t.use_count}
                            </Typography>
                          )}
                          <Tooltip title="Describe this table">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              onClick={() => handleSend(`columns in ${name}`)}>
                              <SchemaIcon sx={{ fontSize: 11 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Generate SELECT">
                            <IconButton size="small" sx={{ p: 0.25 }}
                              onClick={() => handleSend(`show all ${name}`)}>
                              <SqlIcon sx={{ fontSize: 11 }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      );
                    })}
                  </Stack>
                )}

              </Box>
            )}
          </Box>
        ))}

        {loading && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CircularProgress size={13} />
            <Typography variant="caption" color="text.secondary">Processing…</Typography>
          </Box>
        )}
        <div ref={bottomRef} />
      </Box>

      <Divider />

      {/* Input */}
      <Box sx={{ px: 1.5, py: 1, display: 'flex', gap: 0.75, alignItems: 'flex-end',
                 bgcolor: 'background.paper', flexShrink: 0 }}>
        <TextField
          multiline maxRows={3} fullWidth size="small"
          placeholder="SQL, schema, analyze, tables, last result…"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
          sx={{ '& .MuiInputBase-root': { fontSize: '0.8rem' } }}
        />
        <IconButton color="secondary" onClick={() => handleSend()} disabled={!input.trim() || loading}
          sx={{ mb: 0.25, flexShrink: 0 }}>
          <SendIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </Box>
    </Box>
  );
};

// ── Sub-components ────────────────────────────────────────────────────────────

const SqlBlock = ({ sql, onUse, onCopy }: { sql: string; onUse: (s: string) => void; onCopy: (s: string) => void }) => (
  <Paper variant="outlined" sx={{ p: 1, bgcolor: 'grey.50', borderRadius: 1 }}>
    <Box component="pre" sx={{ m: 0, fontFamily: 'monospace', fontSize: '0.75rem',
      whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: 'text.primary', lineHeight: 1.55 }}>
      {sql}
    </Box>
    <Stack direction="row" spacing={0.5} sx={{ mt: 0.75 }}>
      <Button size="small" variant="contained" color="secondary"
        startIcon={<UseIcon sx={{ fontSize: 13 }} />}
        sx={{ fontSize: '0.7rem', py: 0.25, px: 1 }}
        onClick={() => onUse(sql)}>
        Use in SQL Editor
      </Button>
      <Tooltip title="Copy SQL">
        <IconButton size="small" onClick={() => onCopy(sql)}>
          <CopyIcon sx={{ fontSize: 13 }} />
        </IconButton>
      </Tooltip>
    </Stack>
  </Paper>
);

const SchemaTable = ({ result, onUseSql }: { result: any; onUseSql: (sql: string) => void }) => {
  const cols: any[] = result.columns || [];
  const selectSql   = `SELECT\n  ${cols.map((c: any) => c.name).join(',\n  ')}\nFROM ${result.table}\nLIMIT 100`;
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1 }}>
      {result.message && (
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, fontStyle: 'italic' }}>
          {result.message}
        </Typography>
      )}
      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {['Column', 'Type', ...(cols[0]?.use_count != null ? ['Uses'] : [])].map(h => (
              <Box component="th" key={h} sx={{ textAlign: 'left', pb: 0.25, color: 'text.secondary',
                fontWeight: 600, borderBottom: '1px solid', borderColor: 'divider', pr: 1 }}>
                {h}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {cols.slice(0, 30).map((c: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              <Box component="td" sx={{ fontFamily: 'monospace', py: 0.15, pr: 1, color: 'primary.main', fontSize: '0.71rem' }}>
                {c.name}
              </Box>
              <Box component="td" sx={{ color: 'text.secondary', pr: 1, fontSize: '0.68rem' }}>
                {c.type || '—'}
              </Box>
              {c.use_count != null && (
                <Box component="td" sx={{ color: 'text.disabled', fontSize: '0.65rem' }}>
                  ×{c.use_count}
                </Box>
              )}
            </Box>
          ))}
          {cols.length > 30 && (
            <Box component="tr">
              <Box component="td" colSpan={3} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {cols.length - 30} more
              </Box>
            </Box>
          )}
        </Box>
      </Box>
      <Button size="small" variant="outlined" color="secondary"
        startIcon={<UseIcon sx={{ fontSize: 12 }} />}
        sx={{ mt: 0.75, fontSize: '0.68rem', py: 0.2 }}
        onClick={() => onUseSql(selectSql)}>
        SELECT all columns
      </Button>
    </Paper>
  );
};

const DataResultPanel = ({ result, onUseSql }: { result: any; onUseSql: (sql: string) => void }) => {
  const cols: any[] = result.columns || [];
  const execAt = result.executed_at ? new Date(result.executed_at).toLocaleString() : '—';
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1 }}>
      <Stack direction="row" spacing={1} sx={{ mb: 0.75 }} flexWrap="wrap">
        <Chip label={`${(result.total_rows || 0).toLocaleString()} rows`} size="small"
          color="info" sx={{ height: 18, fontSize: '0.68rem' }} />
        <Chip label={`${cols.length} cols`} size="small" variant="outlined"
          sx={{ height: 18, fontSize: '0.68rem' }} />
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.67rem', alignSelf: 'center' }}>
          {execAt}
        </Typography>
      </Stack>
      {result.sql_preview && (
        <Box component="pre" sx={{ m: 0, mb: 0.75, fontFamily: 'monospace', fontSize: '0.68rem',
          color: 'text.secondary', whiteSpace: 'pre-wrap', wordBreak: 'break-all',
          bgcolor: 'grey.50', p: 0.75, borderRadius: 0.5, border: '1px solid', borderColor: 'divider' }}>
          {result.sql_preview}{result.sql_preview.length >= 300 ? '…' : ''}
        </Box>
      )}
      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {['Column', 'Type'].map(h => (
              <Box component="th" key={h} sx={{ textAlign: 'left', pb: 0.25, color: 'text.secondary',
                fontWeight: 600, borderBottom: '1px solid', borderColor: 'divider', pr: 1 }}>
                {h}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {cols.slice(0, 20).map((c: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              <Box component="td" sx={{ fontFamily: 'monospace', py: 0.15, pr: 1, color: 'primary.main', fontSize: '0.71rem' }}>
                {c.name}
              </Box>
              <Box component="td" sx={{ color: 'text.secondary', fontSize: '0.68rem' }}>
                {c.type || '—'}
              </Box>
            </Box>
          ))}
          {cols.length > 20 && (
            <Box component="tr">
              <Box component="td" colSpan={2} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {cols.length - 20} more columns
              </Box>
            </Box>
          )}
        </Box>
      </Box>
      {result.sql_preview && (
        <Button size="small" variant="outlined" color="secondary"
          startIcon={<UseIcon sx={{ fontSize: 12 }} />}
          sx={{ mt: 0.75, fontSize: '0.68rem', py: 0.2 }}
          onClick={() => onUseSql(result.sql_preview)}>
          Re-run this query
        </Button>
      )}
    </Paper>
  );
};

const DocsResultPanel = ({ results }: { results: any[] }) => (
  <Stack spacing={0.75} sx={{ mt: 0.75 }}>
    {results.map((r: any, i: number) => (
      <Paper key={i} variant="outlined" sx={{ p: 1, borderRadius: 1, borderLeft: '3px solid', borderLeftColor: 'primary.main' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.4 }}>
          <DocsIcon sx={{ fontSize: 12, color: 'primary.main' }} />
          <Typography variant="caption" fontWeight={700} sx={{ fontSize: '0.73rem', color: 'primary.main' }}>
            {r.heading}
          </Typography>
          <Typography variant="caption" color="text.disabled" sx={{ fontSize: '0.62rem', ml: 'auto' }}>
            {r.source}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.72rem', lineHeight: 1.5 }}>
          {r.excerpt}
        </Typography>
      </Paper>
    ))}
  </Stack>
);

const GridDataResultPanel = ({ result }: { result: any }) => {
  const cols: string[]  = result.columns || [];
  const rows: any[]     = result.rows || [];
  if (!rows.length) return (
    <Alert severity="info" sx={{ mt: 0.5, py: 0.25, fontSize: '0.73rem' }}>
      Query returned no rows.
    </Alert>
  );
  return (
    <Paper variant="outlined" sx={{ mt: 0.75, p: 1, borderRadius: 1, overflowX: 'auto' }}>
      <Stack direction="row" spacing={0.5} sx={{ mb: 0.75 }} alignItems="center">
        <GridIcon sx={{ fontSize: 12, color: 'info.main' }} />
        <Typography variant="caption" sx={{ fontSize: '0.7rem', color: 'info.main', fontWeight: 600 }}>
          {result.row_count} row{result.row_count !== 1 ? 's' : ''}
        </Typography>
      </Stack>
      <Box component="table" sx={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
        <Box component="thead">
          <Box component="tr">
            {cols.map(c => (
              <Box component="th" key={c} sx={{ textAlign: 'left', pb: 0.25, pr: 1,
                color: 'text.secondary', fontWeight: 600,
                borderBottom: '1px solid', borderColor: 'divider', whiteSpace: 'nowrap' }}>
                {c}
              </Box>
            ))}
          </Box>
        </Box>
        <Box component="tbody">
          {rows.slice(0, 20).map((row: any, i: number) => (
            <Box component="tr" key={i} sx={{ '&:hover': { bgcolor: 'action.hover' } }}>
              {cols.map(c => (
                <Box component="td" key={c} sx={{ py: 0.15, pr: 1, fontFamily: 'monospace', fontSize: '0.71rem', whiteSpace: 'nowrap' }}>
                  {row[c] == null ? <span style={{ color: '#aaa' }}>null</span> : String(row[c])}
                </Box>
              ))}
            </Box>
          ))}
          {rows.length > 20 && (
            <Box component="tr">
              <Box component="td" colSpan={cols.length} sx={{ color: 'text.disabled', fontSize: '0.65rem', pt: 0.25 }}>
                … and {rows.length - 20} more rows
              </Box>
            </Box>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default GlobalAssistantPanel;
