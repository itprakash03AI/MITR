"""
Enterprise Parquet Query Engine with S3 Support
Memory-efficient processing for large-scale parquet files from local and S3 storage
"""

import pyarrow.parquet as pq
import pyarrow.compute as pc
import pyarrow as pa
import pyarrow.csv as pacsv  # type: ignore[import]
import pandas as pd
from typing import List, Dict, Any, Optional, Generator, Union
from pathlib import Path
import logging
import re
import time
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from enum import Enum

from core.s3_storage import S3StorageHandler, S3Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class StorageType(Enum):
    """Storage type enumeration"""
    LOCAL = "local"
    S3 = "s3"


@dataclass
class FileReference:
    """Reference to a parquet file in local or S3 storage"""
    path: str
    storage_type: StorageType
    s3_bucket: Optional[str] = None
    
    def __str__(self):
        if self.storage_type == StorageType.S3:
            return f"s3://{self.s3_bucket}/{self.path}"
        return self.path


@dataclass
class JoinConfig:
    """Configuration for joining parquet files"""
    left_file: Union[str, FileReference]
    right_file: Union[str, FileReference]
    left_on: List[str]
    right_on: List[str]
    how: str = 'inner'  # inner, left, right, outer


@dataclass
class AggregationConfig:
    """Single aggregation: SUM(amount) AS total_amount"""
    column: str
    function: str   # SUM, AVG, COUNT, MIN, MAX
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


@dataclass
class HavingConfig:
    """HAVING clause: HAVING SUM(amount) > 1000"""
    column: str
    function: str   # SUM, AVG, COUNT, MIN, MAX
    operator: str   # eq, ne, gt, gte, lt, lte
    value: Any = None


@dataclass
class ComputedColumnConfig:
    """Computed column: (price * quantity) AS total"""
    expression: str
    alias: str


@dataclass
class CaseWhenClause:
    """Single WHEN condition"""
    when_column: str
    when_operator: str
    when_value: Any
    then_value: str


@dataclass
class CaseExpressionConfig:
    """CASE WHEN ... THEN ... ELSE ... END AS alias"""
    when_clauses: List[CaseWhenClause]
    else_value: Optional[str] = None
    alias: str = "case_result"


@dataclass
class WindowFunctionConfig:
    """Window function: ROW_NUMBER() OVER (PARTITION BY x ORDER BY y)"""
    function: str  # ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD, SUM, AVG, COUNT, MIN, MAX
    alias: str = "window_result"
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[Dict[str, str]]] = None
    offset: Optional[int] = None       # for LAG/LEAD
    default_value: Optional[str] = None # for LAG/LEAD


@dataclass
class QueryConfig:
    """Configuration for query execution"""
    files: List[Union[str, FileReference]]
    joins: Optional[List[JoinConfig]] = None
    filters: Optional[List[Dict[str, Any]]] = None
    columns: Optional[List[str]] = None
    limit: Optional[int] = None
    offset: int = 0
    order_by: Optional[List[Dict[str, str]]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List['AggregationConfig']] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[Dict[str, Any]]] = None
    filter_logic: str = "AND"  # "AND" or "OR"
    computed_columns: Optional[List[Dict[str, str]]] = None
    case_expressions: Optional[List[Dict[str, Any]]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[Dict[str, Any]]] = None


class ParquetQueryEngine:
    """
    Enterprise-grade Parquet Query Engine with S3 support
    Supports both local and S3 storage with memory-efficient operations
    """
    
    def __init__(self, base_path: str = "./data/parquet", 
                 chunk_size: int = 100000,
                 s3_config: Optional[S3Config] = None):
        """
        Initialize the Parquet Query Engine
        
        Args:
            base_path: Base directory for local parquet files
            chunk_size: Number of rows to process at a time
            s3_config: Optional S3 configuration
        """
        self.base_path = Path(base_path)
        self.chunk_size = chunk_size
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize S3 handler if config provided
        self.s3_handler = None
        if s3_config:
            try:
                self.s3_handler = S3StorageHandler(s3_config)
                logger.info("S3 storage handler initialized")
            except Exception as e:
                logger.error(f"Failed to initialize S3 handler: {e}")
        
        logger.info(f"ParquetQueryEngine initialized with base_path: {self.base_path}")
    
    def set_s3_config(self, s3_config: S3Config):
        """
        Set or update S3 configuration
        
        Args:
            s3_config: S3 configuration
        """
        try:
            self.s3_handler = S3StorageHandler(s3_config)
            logger.info("S3 configuration updated")
        except Exception as e:
            logger.error(f"Failed to set S3 config: {e}")
            raise
    
    def list_s3_folders(self, prefix: str = "") -> List[Dict[str, Any]]:
        """
        List folders in S3 bucket
        
        Args:
            prefix: Prefix to filter folders
            
        Returns:
            List of folder information
        """
        if not self.s3_handler:
            raise ValueError("S3 handler not configured")
        
        return self.s3_handler.list_folders(prefix)
    
    def list_s3_files(self, folder_path: str = "") -> List[Dict[str, Any]]:
        """
        List parquet files in S3 folder
        
        Args:
            folder_path: S3 folder path
            
        Returns:
            List of file information
        """
        if not self.s3_handler:
            raise ValueError("S3 handler not configured")
        
        files = self.s3_handler.list_parquet_files(folder_path)
        
        # Add storage type and schema info
        for file in files:
            file['storage_type'] = 's3'
            try:
                schema = self.s3_handler.get_file_schema(file['key'])
                file['num_rows'] = schema.get('num_rows', 0)
                file['num_columns'] = len(schema.get('columns', []))
                file['columns'] = schema.get('columns', [])
            except Exception as e:
                logger.warning(f"Could not get schema for {file['key']}: {e}")
        
        return files
    
    def list_local_files(self) -> List[Dict[str, Any]]:
        """
        List all available local parquet files with metadata
        
        Returns:
            List of file information dictionaries
        """
        files = []
        for file_path in self.base_path.rglob("*.parquet"):
            try:
                parquet_file = pq.ParquetFile(file_path)
                metadata = parquet_file.metadata
                schema = parquet_file.schema_arrow
                
                files.append({
                    "name": file_path.name,
                    "path": str(file_path.relative_to(self.base_path)),
                    "size_bytes": file_path.stat().st_size,
                    "num_rows": metadata.num_rows,
                    "num_columns": len(schema),
                    "storage_type": "local",
                    "columns": [
                        {
                            "name": field.name,
                            "type": str(field.type)
                        }
                        for field in schema
                    ]
                })
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                continue
        
        return files
    
    def list_files(self, storage_type: Optional[str] = None, 
                   s3_folder: str = "") -> List[Dict[str, Any]]:
        """
        List all available parquet files from local and/or S3 storage
        
        Args:
            storage_type: Filter by storage type ('local', 's3', or None for both)
            s3_folder: S3 folder path if listing S3 files
            
        Returns:
            Combined list of files from all sources
        """
        all_files = []
        
        # List local files
        if storage_type is None or storage_type == 'local':
            all_files.extend(self.list_local_files())
        
        # List S3 files
        if (storage_type is None or storage_type == 's3') and self.s3_handler:
            try:
                all_files.extend(self.list_s3_files(s3_folder))
            except Exception as e:
                logger.error(f"Error listing S3 files: {e}")
        
        return all_files
    
    def get_file_schema(self, file_ref: Union[str, FileReference]) -> Dict[str, Any]:
        """
        Get detailed schema information for a parquet file
        
        Args:
            file_ref: File reference (path string or FileReference object)
            
        Returns:
            Schema information dictionary
        """
        # Convert string to FileReference if needed
        if isinstance(file_ref, str):
            if file_ref.startswith('s3://'):
                # Parse S3 URL
                parts = file_ref[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                file_ref = FileReference(key, StorageType.S3, bucket)
            else:
                file_ref = FileReference(file_ref, StorageType.LOCAL)
        
        # Get schema based on storage type
        if file_ref.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            return self.s3_handler.get_file_schema(file_ref.path)
        else:
            # Local file
            full_path = self.base_path / file_ref.path
            if not full_path.exists():
                raise FileNotFoundError(f"File not found: {file_ref.path}")
            
            parquet_file = pq.ParquetFile(full_path)
            schema = parquet_file.schema_arrow
            
            return {
                "file": file_ref.path,
                "storage_type": "local",
                "columns": [
                    {
                        "name": field.name,
                        "type": str(field.type),
                        "nullable": field.nullable
                    }
                    for field in schema
                ],
                "num_rows": parquet_file.metadata.num_rows
            }
    
    @staticmethod
    def _bare_column(qualified: str, schema_names: list) -> str:
        """Strip a 'filename.ext.' prefix from a column name if needed.

        The frontend sends filters as 'accounts.parquet.account_id' but the
        PyArrow table schema only contains bare names like 'account_id'.
        Resolution order:
          1. exact match (most common, no-op)
          2. strip known file-extension prefix  (e.g. 'accounts.parquet.')
          3. take everything after the last '.'  (fallback)
        """
        if qualified in schema_names:
            return qualified
        import re
        m = re.search(r'\.\w+\.(.*)', qualified)  # .parquet. .csv. .json. etc.
        if m and m.group(1) in schema_names:
            return m.group(1)
        last = qualified.rsplit(".", 1)[-1]
        return last if last in schema_names else qualified

    def _apply_filters(self, table: pa.Table, filters: List[Dict[str, Any]]) -> pa.Table:
        """
        Apply filters to a PyArrow table

        Args:
            table: PyArrow table
            filters: List of filter conditions

        Returns:
            Filtered table
        """
        if not filters:
            return table

        schema_names = table.schema.names
        mask = None

        for filter_condition in filters:
            column   = self._bare_column(filter_condition["column"], schema_names)
            operator = filter_condition["operator"]
            value    = filter_condition["value"]

            if column not in schema_names:
                logger.warning(f"Filter column '{filter_condition['column']}' not in schema, skipping")
                continue

            # Convert value to appropriate Arrow scalar, coercing type if needed
            col_type = table.schema.field(column).type
            def _scalar(v):
                try:
                    return pa.scalar(v, type=col_type)
                except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
                    # Fallback: cast the column to string for comparison
                    return pa.scalar(str(v))

            if operator in ("eq", "ne", "gt", "gte", "lt", "lte"):
                try:
                    scalar_val = _scalar(value)
                    cmp_col = table[column]
                    if operator == "eq":
                        condition = pc.equal(cmp_col, scalar_val)
                    elif operator == "ne":
                        condition = pc.not_equal(cmp_col, scalar_val)
                    elif operator == "gt":
                        condition = pc.greater(cmp_col, scalar_val)
                    elif operator == "gte":
                        condition = pc.greater_equal(cmp_col, scalar_val)
                    elif operator == "lt":
                        condition = pc.less(cmp_col, scalar_val)
                    elif operator == "lte":
                        condition = pc.less_equal(cmp_col, scalar_val)
                except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
                    # If type coercion still fails, cast column to string and compare
                    str_col = pc.cast(table[column], pa.string())
                    condition = pc.equal(str_col, pa.scalar(str(value)))
            elif operator == "in":
                condition = pc.is_in(table[column], pa.array(value))
            elif operator == "not_in":
                condition = pc.invert(pc.is_in(table[column], pa.array(value)))
            elif operator == "contains":
                condition = pc.match_substring(
                    pc.cast(table[column], pa.string()), str(value), ignore_case=True)
            elif operator == "not_contains":
                condition = pc.invert(pc.match_substring(
                    pc.cast(table[column], pa.string()), str(value), ignore_case=True))
            elif operator == "is_null":
                condition = pc.is_null(table[column])
            elif operator == "is_not_null":
                condition = pc.is_valid(table[column])
            elif operator == "between":
                vals = value if isinstance(value, list) else [value, value]
                low_s = _scalar(vals[0])
                high_s = _scalar(vals[1])
                condition = pc.and_(
                    pc.greater_equal(table[column], low_s),
                    pc.less_equal(table[column], high_s),
                )
            else:
                raise ValueError(f"Unsupported operator: {operator}")

            if mask is None:
                mask = condition
            else:
                mask = pc.and_(mask, condition)

        return table.filter(mask)
    
    def _read_parquet_chunked(self, file_ref: Union[str, FileReference], 
                              columns: Optional[List[str]] = None) -> Generator[pa.Table, None, None]:
        """
        Read parquet file in chunks for memory efficiency
        
        Args:
            file_ref: File reference
            columns: Optional list of columns to read
            
        Yields:
            PyArrow table chunks
        """
        # Convert string to FileReference if needed
        if isinstance(file_ref, str):
            if file_ref.startswith('s3://'):
                parts = file_ref[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                file_ref = FileReference(key, StorageType.S3, bucket)
            else:
                file_ref = FileReference(file_ref, StorageType.LOCAL)
        
        if file_ref.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            
            for chunk in self.s3_handler.read_parquet_chunked(
                file_ref.path, self.chunk_size, columns
            ):
                yield chunk
        else:
            # Local file
            full_path = self.base_path / file_ref.path
            parquet_file = pq.ParquetFile(full_path)
            
            for batch in parquet_file.iter_batches(batch_size=self.chunk_size, columns=columns):
                yield pa.Table.from_batches([batch])
    
    def execute_query(self, query_config: QueryConfig) -> Generator[pd.DataFrame, None, None]:
        """
        Execute a query with joins, filters, and projections
        Memory-efficient streaming implementation for large datasets
        
        Args:
            query_config: Query configuration object
            
        Yields:
            Pandas DataFrame chunks
        """
        logger.info(f"Executing query with config: {query_config}")
        
        if not query_config.files:
            raise ValueError("At least one file must be specified")

        # Determine columns to read
        read_columns = query_config.columns if query_config.columns else None

        # Stream all files — each file's chunks are processed independently so
        # schemas may differ across files (missing columns are skipped gracefully).
        for file_ref in query_config.files:
            logger.info(f"Reading file: {file_ref}")

            for chunk_idx, table_chunk in enumerate(self._read_parquet_chunked(file_ref, read_columns)):
                logger.info(f"Processing chunk {chunk_idx}, rows: {len(table_chunk)}")

                # Apply filters
                if query_config.filters:
                    table_chunk = self._apply_filters(table_chunk, query_config.filters)
                    if len(table_chunk) == 0:
                        continue

                # Perform joins if specified
                if query_config.joins:
                    for join_config in query_config.joins:
                        table_chunk = self._perform_join(table_chunk, join_config)
                        if len(table_chunk) == 0:
                            break

                # Apply column selection
                if query_config.columns:
                    available_cols = [col for col in query_config.columns if col in table_chunk.column_names]
                    table_chunk = table_chunk.select(available_cols)

                # Apply ordering (per-chunk; for global ordering use a single-file query)
                if query_config.order_by:
                    table_chunk = self._apply_sorting(table_chunk, query_config.order_by)

                # Convert to pandas and yield
                if len(table_chunk) > 0:
                    yield table_chunk.to_pandas()
    
    def _perform_join(self, left_table: pa.Table, join_config: JoinConfig) -> pa.Table:
        """
        Perform join operation between tables
        
        Args:
            left_table: Left table
            join_config: Join configuration
            
        Returns:
            Joined table
        """
        # Read the right file
        right_file = join_config.right_file
        
        # For simplicity, read entire right table (consider chunking for very large files)
        if isinstance(right_file, str):
            if right_file.startswith('s3://'):
                parts = right_file[5:].split('/', 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ''
                right_file = FileReference(key, StorageType.S3, bucket)
            else:
                right_file = FileReference(right_file, StorageType.LOCAL)
        
        if right_file.storage_type == StorageType.S3:
            if not self.s3_handler:
                raise ValueError("S3 handler not configured")
            right_table = self.s3_handler.read_parquet(right_file.path)
        else:
            right_path = self.base_path / right_file.path
            right_table = pq.read_table(right_path)
        
        # Convert to pandas for join
        left_df = left_table.to_pandas()
        right_df = right_table.to_pandas()
        
        # Perform join
        merged_df = left_df.merge(
            right_df,
            left_on=join_config.left_on,
            right_on=join_config.right_on,
            how=join_config.how,
            suffixes=('', '_right')
        )
        
        return pa.Table.from_pandas(merged_df)
    
    def _apply_sorting(self, table: pa.Table, order_by: List[Dict[str, str]]) -> pa.Table:
        """
        Apply sorting to table
        
        Args:
            table: PyArrow table
            order_by: List of sort specifications
            
        Returns:
            Sorted table
        """
        df = table.to_pandas()
        
        sort_columns = [item["column"] for item in order_by]
        sort_ascending = [item.get("direction", "asc") == "asc" for item in order_by]
        
        df = df.sort_values(by=sort_columns, ascending=sort_ascending)
        
        return pa.Table.from_pandas(df)
    
    # ── DuckDB-powered advanced SQL execution ──────────────────────────────
    _VALID_AGG_FUNCS = {"SUM", "AVG", "COUNT", "MIN", "MAX"}
    _VALID_WINDOW_FUNCS = {"ROW_NUMBER", "RANK", "DENSE_RANK", "LAG", "LEAD",
                           "SUM", "AVG", "COUNT", "MIN", "MAX"}
    _NUMERIC_ARROW_TYPES = {
        pa.int8(), pa.int16(), pa.int32(), pa.int64(),
        pa.uint8(), pa.uint16(), pa.uint32(), pa.uint64(),
        pa.float16(), pa.float32(), pa.float64(),
    }
    # Dangerous SQL keywords blocked in free-form expressions
    _BLOCKED_EXPR_WORDS = {"DROP", "INSERT", "UPDATE", "DELETE", "ALTER", "CREATE",
                           "TRUNCATE", "EXEC", "EXECUTE", "GRANT", "REVOKE"}

    @staticmethod
    def _is_numeric_type(arrow_type) -> bool:
        return (
            arrow_type in ParquetQueryEngine._NUMERIC_ARROW_TYPES
            or pa.types.is_decimal(arrow_type)
        )

    @staticmethod
    def _sanitize_expression(expr: str) -> str:
        """Basic sanitisation for free-form expressions (computed columns, CASE values)."""
        if ";" in expr or "--" in expr:
            raise ValueError(f"Invalid expression (contains forbidden characters): {expr}")
        tokens = expr.upper().split()
        for t in tokens:
            bare = t.strip("()")
            if bare in ParquetQueryEngine._BLOCKED_EXPR_WORDS:
                raise ValueError(f"Blocked keyword '{bare}' in expression: {expr}")
        return expr

    def _resolve_to_posix(self, file_ref: Union[str, 'FileReference']) -> str:
        """Resolve a file reference to a POSIX path string for DuckDB."""
        if isinstance(file_ref, str):
            if file_ref.startswith('s3://'):
                return file_ref
            return (self.base_path / file_ref).as_posix()
        if file_ref.storage_type == StorageType.S3:
            return f"s3://{file_ref.s3_bucket}/{file_ref.path}"
        return (self.base_path / file_ref.path).as_posix()

    @staticmethod
    def _duckdb_read_fn(path: str) -> str:
        """Return the correct DuckDB reader call for a file path.

        .csv / .txt → read_csv_auto('...')
        everything else → read_parquet('...')
        """
        low = path.lower()
        if low.endswith('.csv') or low.endswith('.txt'):
            return f"read_csv_auto('{path}')"
        return f"read_parquet('{path}')"

    def _needs_duckdb(self, query_config: QueryConfig) -> bool:
        """Determine if this query must use the DuckDB execution path."""
        # Non-parquet files (CSV/TXT) can only be read by DuckDB, not PyArrow
        has_non_parquet = any(
            not (f if isinstance(f, str) else f.path).lower().endswith('.parquet')
            for f in query_config.files
        )
        return bool(
            has_non_parquet
            or query_config.aggregations
            or query_config.distinct
            or query_config.having
            or query_config.computed_columns
            or query_config.case_expressions
            or query_config.window_functions
            or (query_config.filter_logic and query_config.filter_logic.upper() == "OR")
        )

    def _build_where(self, filters: List[Dict[str, Any]], filter_logic: str = "AND") -> tuple:
        """Build WHERE clause and params list from filters."""
        def _q(name: str) -> str:
            return f'"{name}"'

        def _col(raw: str) -> str:
            """Strip table qualifier — frontend sends 'table.col', DuckDB needs 'col'."""
            return _q(raw.rsplit(".", 1)[-1] if "." in raw else raw)

        conditions: List[str] = []
        params: list = []
        for f in filters:
            col = _col(f["column"])
            op = f["operator"]
            val = f.get("value")
            if op == "eq":
                conditions.append(f"{col} = ?"); params.append(val)
            elif op == "ne":
                conditions.append(f"{col} != ?"); params.append(val)
            elif op == "gt":
                conditions.append(f"{col} > ?"); params.append(val)
            elif op == "gte":
                conditions.append(f"{col} >= ?"); params.append(val)
            elif op == "lt":
                conditions.append(f"{col} < ?"); params.append(val)
            elif op == "lte":
                conditions.append(f"{col} <= ?"); params.append(val)
            elif op == "contains":
                conditions.append(f"{col} ILIKE ?"); params.append(f"%{val}%")
            elif op == "not_contains":
                conditions.append(f"{col} NOT ILIKE ?"); params.append(f"%{val}%")
            elif op == "in":
                vals = val if isinstance(val, list) else [val]
                placeholders = ", ".join("?" for _ in vals)
                conditions.append(f"{col} IN ({placeholders})"); params.extend(vals)
            elif op == "not_in":
                vals = val if isinstance(val, list) else [val]
                placeholders = ", ".join("?" for _ in vals)
                conditions.append(f"{col} NOT IN ({placeholders})"); params.extend(vals)
            elif op == "between":
                vals = val if isinstance(val, list) else [val, val]
                conditions.append(f"{col} BETWEEN ? AND ?"); params.extend(vals[:2])
            elif op == "is_null":
                conditions.append(f"{col} IS NULL")
            elif op == "is_not_null":
                conditions.append(f"{col} IS NOT NULL")
        combiner = f" {filter_logic.upper()} "
        where_sql = ("WHERE " + combiner.join(conditions)) if conditions else ""
        return where_sql, params

    @staticmethod
    def _literal(val) -> str:
        """Format a Python value as an inline SQL literal (safe for single-value types)."""
        if val is None:
            return "NULL"
        if isinstance(val, bool):
            return "TRUE" if val else "FALSE"
        if isinstance(val, (int, float)):
            return str(val)
        s = str(val)
        # Pass SQL type-prefix literals through unchanged:
        # date '2025-06-30', timestamp '2025-01-01', time '12:00:00', interval '1' DAY
        if re.match(r"^(date|timestamp|time|interval)\s*'", s, re.IGNORECASE):
            return s
        return "'" + s.replace("'", "''") + "'"

    def build_query_sql(self, query_config: QueryConfig, from_clause: str) -> str:
        """Build a complete SQL string with inlined literal values.

        Unlike execute_duckdb_query (which uses DuckDB param binding), this
        returns a plain SQL string suitable for any SQL connector
        (Trino, Starburst, Snowflake, Databricks, Oracle).

        Args:
            query_config: Query configuration (columns, filters, aggregations, etc.)
            from_clause:  FROM target — e.g. 'catalog.schema.table' or '"schema"."table"'.
                          Do NOT include the keyword 'FROM'.
        Returns:
            Complete SQL string ready to pass to connector.execute_query().
        """
        def _q(name: str) -> str:
            return f'"{name}"'
        _lit = self._literal

        # ── SELECT ────────────────────────────────────────────────────────────
        select_parts: List[str] = []
        group_cols = query_config.group_by or []

        if query_config.aggregations:
            for col in group_cols:
                alias = (query_config.column_aliases or {}).get(col)
                select_parts.append(f"{_q(col)} AS {_q(alias)}" if alias else _q(col))
            for agg in query_config.aggregations:
                fn = agg.function.upper()
                alias = agg.alias or f"{fn.lower()}_{agg.column}"
                if fn == "COUNT" and agg.distinct:
                    select_parts.append(f"COUNT(DISTINCT {_q(agg.column)}) AS {_q(alias)}")
                else:
                    select_parts.append(f"{fn}({_q(agg.column)}) AS {_q(alias)}")
        else:
            if query_config.columns:
                for col in query_config.columns:
                    alias = (query_config.column_aliases or {}).get(col)
                    select_parts.append(f"{_q(col)} AS {_q(alias)}" if alias else _q(col))
            else:
                select_parts.append("*")

        if query_config.computed_columns:
            for cc in query_config.computed_columns:
                expr = self._sanitize_expression(cc["expression"])
                select_parts.append(f"({expr}) AS {_q(cc['alias'])}")

        if query_config.case_expressions:
            op_map = {"eq": "=", "ne": "!=", "gt": ">", "gte": ">=",
                      "lt": "<", "lte": "<=", "in": "IN",
                      "is_null": "IS NULL", "is_not_null": "IS NOT NULL"}
            for ce in query_config.case_expressions:
                case_sql = "CASE"
                for clause in ce["when_clauses"]:
                    col = _q(clause["when_column"])
                    op_key = clause["when_operator"]
                    op = op_map.get(op_key, "=")
                    if op_key in ("is_null", "is_not_null"):
                        case_sql += f" WHEN {col} {op} THEN {_lit(clause['then_value'])}"
                    else:
                        case_sql += (f" WHEN {col} {op} {_lit(clause.get('when_value', ''))}"
                                     f" THEN {_lit(clause['then_value'])}")
                else_val = ce.get("else_value")
                if else_val is not None and else_val != "":
                    case_sql += f" ELSE {_lit(else_val)}"
                case_sql += f" END AS {_q(ce['alias'])}"
                select_parts.append(case_sql)

        if query_config.window_functions:
            for wf in query_config.window_functions:
                fn = wf["function"].upper()
                partition = ("PARTITION BY " + ", ".join(_q(c) for c in wf["partition_by"])
                             if wf.get("partition_by") else "")
                order = ("ORDER BY " + ", ".join(
                             f'{_q(o["column"])} {o.get("direction","ASC").upper()}'
                             for o in wf["order_by"])
                         if wf.get("order_by") else "")
                over_clause = "OVER (" + " ".join(p for p in [partition, order] if p) + ")"
                if fn in ("ROW_NUMBER", "RANK", "DENSE_RANK"):
                    select_parts.append(f"{fn}() {over_clause} AS {_q(wf['alias'])}")
                elif fn in ("LAG", "LEAD"):
                    col_ref = _q(wf["column"]) if wf.get("column") else "''"
                    off = wf.get("offset", 1)
                    dflt = wf.get("default_value")
                    if dflt is not None:
                        select_parts.append(f"{fn}({col_ref}, {off}, {_lit(dflt)}) {over_clause} AS {_q(wf['alias'])}")
                    else:
                        select_parts.append(f"{fn}({col_ref}, {off}) {over_clause} AS {_q(wf['alias'])}")
                else:
                    col_ref = _q(wf["column"]) if wf.get("column") else "*"
                    select_parts.append(f"{fn}({col_ref}) {over_clause} AS {_q(wf['alias'])}")

        if not select_parts:
            select_parts.append("*")

        distinct_kw = "DISTINCT " if query_config.distinct else ""

        # ── WHERE ─────────────────────────────────────────────────────────────
        def _qcol(raw: str) -> str:
            """Quote column ref, stripping any table qualifier (frontend sends 'table.col')."""
            return _q(raw.rsplit(".", 1)[-1] if "." in raw else raw)

        where_clause = ""
        if query_config.filters:
            logic = (query_config.filter_logic or "AND").upper()
            conditions: List[str] = []
            for f in query_config.filters:
                col = _qcol(f["column"])
                op  = f["operator"]
                val = f.get("value")
                if op == "eq":           conditions.append(f"{col} = {_lit(val)}")
                elif op == "ne":         conditions.append(f"{col} != {_lit(val)}")
                elif op == "gt":         conditions.append(f"{col} > {_lit(val)}")
                elif op == "gte":        conditions.append(f"{col} >= {_lit(val)}")
                elif op == "lt":         conditions.append(f"{col} < {_lit(val)}")
                elif op == "lte":        conditions.append(f"{col} <= {_lit(val)}")
                elif op == "contains":
                    escaped = str(val).replace("'", "''")
                    conditions.append(f"{col} LIKE '%{escaped}%'")
                elif op == "not_contains":
                    escaped = str(val).replace("'", "''")
                    conditions.append(f"{col} NOT LIKE '%{escaped}%'")
                elif op == "in":
                    vals = val if isinstance(val, list) else [val]
                    conditions.append(f"{col} IN ({', '.join(_lit(v) for v in vals)})")
                elif op == "not_in":
                    vals = val if isinstance(val, list) else [val]
                    conditions.append(f"{col} NOT IN ({', '.join(_lit(v) for v in vals)})")
                elif op == "between":
                    vals = val if isinstance(val, list) else [val, val]
                    conditions.append(f"{col} BETWEEN {_lit(vals[0])} AND {_lit(vals[1])}")
                elif op == "is_null":    conditions.append(f"{col} IS NULL")
                elif op == "is_not_null": conditions.append(f"{col} IS NOT NULL")
            if conditions:
                where_clause = "WHERE " + f" {logic} ".join(conditions)

        # ── GROUP BY / HAVING / ORDER BY / LIMIT ──────────────────────────────
        group_clause = ("GROUP BY " + ", ".join(_q(c) for c in group_cols)) if group_cols else ""

        having_clause = ""
        if query_config.having:
            h_op_map = {"eq": "=", "ne": "!=", "gt": ">", "gte": ">=", "lt": "<", "lte": "<="}
            h_parts = [
                f"{'%s(%s)' % (h['function'].upper(), _q(h['column'])) if h.get('function') else _q(h['column'])}"
                f" {h_op_map.get(h['operator'], '=')} {_lit(h['value'])}"
                for h in query_config.having
            ]
            having_clause = "HAVING " + " AND ".join(h_parts)

        order_clause = ""
        if query_config.order_by:
            order_clause = "ORDER BY " + ", ".join(
                f'{_q(o["column"])} {o.get("direction", "ASC").upper()}'
                for o in query_config.order_by)

        limit_clause = f"LIMIT {query_config.limit}" if query_config.limit else ""
        if query_config.offset:
            limit_clause = (limit_clause or "LIMIT ALL") + f" OFFSET {query_config.offset}"

        sql_parts = [f"SELECT {distinct_kw}{', '.join(select_parts)}", f"FROM {from_clause}"]
        for clause in [where_clause, group_clause, having_clause, order_clause, limit_clause]:
            if clause:
                sql_parts.append(clause)
        return "\n".join(sql_parts)

    def _build_duckdb_from_clause(self, query_config: QueryConfig) -> str:
        """Build the DuckDB FROM clause using the correct reader per file type."""
        def _q(name: str) -> str:
            return f'"{name}"'

        primary_path = self._resolve_to_posix(query_config.files[0])
        all_paths = [self._resolve_to_posix(f) for f in query_config.files]

        if len(all_paths) > 1 and not query_config.joins:
            # Multiple files of the same type → list syntax
            if all(p.lower().endswith(('.csv', '.txt')) for p in all_paths):
                paths_list = ", ".join(f"'{p}'" for p in all_paths)
                from_clause = f"read_csv_auto([{paths_list}], union_by_name=true) AS t0"
            else:
                paths_list = ", ".join(f"'{p}'" for p in all_paths)
                from_clause = f"read_parquet([{paths_list}], union_by_name=true) AS t0"
        else:
            from_clause = f"{self._duckdb_read_fn(primary_path)} AS t0"

        if query_config.joins:
            for idx, jc in enumerate(query_config.joins, start=1):
                rp = self._resolve_to_posix(jc.right_file)
                alias = f"t{idx}"
                join_type = jc.how.upper()
                if join_type not in ("INNER", "LEFT", "RIGHT"):
                    join_type = "FULL OUTER"
                on_parts = [
                    f"t0.{_q(l)} = {alias}.{_q(r)}"
                    for l, r in zip(jc.left_on, jc.right_on)
                ]
                from_clause += (f"\n  {join_type} JOIN {self._duckdb_read_fn(rp)} AS {alias}"
                                f" ON {' AND '.join(on_parts)}")
        return from_clause

    def get_duckdb_sql(self, query_config: QueryConfig) -> str:
        """Return the full DuckDB SQL for a query config with inlined literals.
        Use this to populate the SQL editor — the result is directly executable in DuckDB."""
        return self.build_query_sql(query_config, self._build_duckdb_from_clause(query_config))

    def execute_raw_duckdb_sql(self, sql: str) -> Generator[pd.DataFrame, None, None]:
        """Execute a raw SQL string in DuckDB (no parameter binding — inline literals only)."""
        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB is required. pip install duckdb")
        con = duckdb.connect()
        try:
            result_df = con.execute(sql).fetchdf()
            if len(result_df) > 0:
                yield result_df
        finally:
            con.close()

    def execute_duckdb_query(self, query_config: QueryConfig) -> Generator[pd.DataFrame, None, None]:
        """Execute any advanced SQL query using DuckDB.

        Handles: aggregations, DISTINCT, HAVING, OR logic, computed columns,
        CASE WHEN, window functions, column aliases, and all filter operators.
        Falls back to execute_query when no advanced feature is needed.
        """
        if not self._needs_duckdb(query_config):
            yield from self.execute_query(query_config)
            return

        try:
            import duckdb
        except ImportError:
            raise RuntimeError("DuckDB is required for advanced queries. pip install duckdb")

        def _q(name: str) -> str:
            return f'"{name}"'

        # ── Validate aggregation functions ───────────────────────────────
        if query_config.aggregations:
            for agg in query_config.aggregations:
                fn = agg.function.upper()
                if fn not in self._VALID_AGG_FUNCS:
                    raise ValueError(f"Invalid aggregation function: {fn}")

        # ── Schema introspection for type validation ─────────────────────
        primary_path = self._resolve_to_posix(query_config.files[0])
        pf_schema = pq.read_schema(primary_path)
        col_type_map: Dict[str, pa.DataType] = {f.name: f.type for f in pf_schema}
        if query_config.joins:
            for jc in query_config.joins:
                rp = self._resolve_to_posix(jc.right_file)
                try:
                    rs = pq.read_schema(rp)
                    for f in rs:
                        if f.name not in col_type_map:
                            col_type_map[f.name] = f.type
                except Exception:
                    pass

        # Validate SUM/AVG on numeric columns only
        if query_config.aggregations:
            for agg in query_config.aggregations:
                fn = agg.function.upper()
                if fn in ("SUM", "AVG") and agg.column in col_type_map:
                    if not self._is_numeric_type(col_type_map[agg.column]):
                        raise ValueError(
                            f"{fn}(\"{agg.column}\") is invalid — column type is "
                            f"{col_type_map[agg.column]}, but {fn} requires a numeric column."
                        )

        # ── FROM clause ──────────────────────────────────────────────────
        all_paths = [self._resolve_to_posix(f) for f in query_config.files]
        if len(all_paths) > 1 and not query_config.joins:
            if all(p.lower().endswith(('.csv', '.txt')) for p in all_paths):
                paths_list = ", ".join(f"'{p}'" for p in all_paths)
                from_clause = f"read_csv_auto([{paths_list}], union_by_name=true) AS t0"
            else:
                paths_list = ", ".join(f"'{p}'" for p in all_paths)
                from_clause = f"read_parquet([{paths_list}], union_by_name=true) AS t0"
        else:
            from_clause = f"{self._duckdb_read_fn(primary_path)} AS t0"
        if query_config.joins:
            for idx, jc in enumerate(query_config.joins, start=1):
                rp = self._resolve_to_posix(jc.right_file)
                alias = f"t{idx}"
                join_type = jc.how.upper()
                if join_type not in ("INNER", "LEFT", "RIGHT"):
                    join_type = "FULL OUTER"
                on_parts = [
                    f"t0.{_q(l)} = {alias}.{_q(r)}"
                    for l, r in zip(jc.left_on, jc.right_on)
                ]
                from_clause += (f"\n  {join_type} JOIN {self._duckdb_read_fn(rp)} AS {alias}"
                                f" ON {' AND '.join(on_parts)}")

        # ── SELECT clause ────────────────────────────────────────────────
        select_parts: List[str] = []
        params: list = []
        group_cols = query_config.group_by or []

        if query_config.aggregations:
            # GROUP BY columns first
            for col in group_cols:
                alias = (query_config.column_aliases or {}).get(col)
                select_parts.append(f"{_q(col)} AS {_q(alias)}" if alias else _q(col))
            # Aggregation expressions
            for agg in query_config.aggregations:
                fn = agg.function.upper()
                alias = agg.alias or f"{fn.lower()}_{agg.column}"
                if fn == "COUNT" and agg.distinct:
                    select_parts.append(f"COUNT(DISTINCT {_q(agg.column)}) AS {_q(alias)}")
                else:
                    select_parts.append(f"{fn}({_q(agg.column)}) AS {_q(alias)}")
        else:
            # No aggregations — plain columns
            if query_config.columns:
                for col in query_config.columns:
                    alias = (query_config.column_aliases or {}).get(col)
                    select_parts.append(f"{_q(col)} AS {_q(alias)}" if alias else _q(col))
            else:
                # ── Wide-table column projection ──────────────────────────
                # When user hasn't selected columns and the table has >50 cols,
                # auto-project first 50 so DuckDB reads only those column chunks
                # from Parquet — can be 10-20x faster for very wide tables.
                _MAX_DEFAULT_COLS = 50
                _all_col_names = [f.name for f in pf_schema]
                if len(_all_col_names) > _MAX_DEFAULT_COLS and not query_config.joins:
                    _projected = _all_col_names[:_MAX_DEFAULT_COLS]
                    for col in _projected:
                        select_parts.append(_q(col))
                    logger.info(
                        "Wide table (%d cols) — auto-projecting first %d columns. "
                        "User can select specific columns to change.",
                        len(_all_col_names), _MAX_DEFAULT_COLS,
                    )
                else:
                    select_parts.append("*")

        # Computed columns
        if query_config.computed_columns:
            for cc in query_config.computed_columns:
                expr = self._sanitize_expression(cc["expression"])
                select_parts.append(f"({expr}) AS {_q(cc['alias'])}")

        # CASE WHEN expressions
        if query_config.case_expressions:
            op_map = {"eq": "=", "ne": "!=", "gt": ">", "gte": ">=",
                      "lt": "<", "lte": "<=", "in": "IN", "is_null": "IS NULL",
                      "is_not_null": "IS NOT NULL"}
            for ce in query_config.case_expressions:
                case_sql = "CASE"
                for clause in ce["when_clauses"]:
                    col = _q(clause["when_column"])
                    op_key = clause["when_operator"]
                    op = op_map.get(op_key, "=")
                    if op_key in ("is_null", "is_not_null"):
                        case_sql += f" WHEN {col} {op} THEN ?"
                        params.append(clause["then_value"])
                    else:
                        case_sql += f" WHEN {col} {op} ? THEN ?"
                        params.append(clause.get("when_value", ""))
                        params.append(clause["then_value"])
                else_val = ce.get("else_value")
                if else_val is not None and else_val != "":
                    case_sql += f" ELSE ?"; params.append(else_val)
                case_sql += f" END AS {_q(ce['alias'])}"
                select_parts.append(case_sql)

        # Window functions
        if query_config.window_functions:
            for wf in query_config.window_functions:
                fn = wf["function"].upper()
                if fn not in self._VALID_WINDOW_FUNCS:
                    raise ValueError(f"Invalid window function: {fn}")
                partition = ""
                if wf.get("partition_by"):
                    partition = "PARTITION BY " + ", ".join(_q(c) for c in wf["partition_by"])
                order = ""
                if wf.get("order_by"):
                    order = "ORDER BY " + ", ".join(
                        f'{_q(o["column"])} {o.get("direction", "ASC").upper()}'
                        for o in wf["order_by"])
                over_parts = " ".join(p for p in [partition, order] if p)
                over_clause = f"OVER ({over_parts})"
                if fn in ("ROW_NUMBER", "RANK", "DENSE_RANK"):
                    select_parts.append(f"{fn}() {over_clause} AS {_q(wf['alias'])}")
                elif fn in ("LAG", "LEAD"):
                    col_ref = _q(wf["column"]) if wf.get("column") else "''"
                    off = wf.get("offset", 1)
                    dflt = wf.get("default_value")
                    if dflt is not None:
                        select_parts.append(f"{fn}({col_ref}, {off}, ?) {over_clause} AS {_q(wf['alias'])}")
                        params.append(dflt)
                    else:
                        select_parts.append(f"{fn}({col_ref}, {off}) {over_clause} AS {_q(wf['alias'])}")
                else:
                    col_ref = _q(wf["column"]) if wf.get("column") else "*"
                    select_parts.append(f"{fn}({col_ref}) {over_clause} AS {_q(wf['alias'])}")

        if not select_parts:
            select_parts.append("*")

        # ── DISTINCT ─────────────────────────────────────────────────────
        distinct_kw = "DISTINCT " if query_config.distinct else ""

        # ── WHERE clause ─────────────────────────────────────────────────
        where_clause = ""
        if query_config.filters:
            logic = (query_config.filter_logic or "AND").upper()
            where_clause, w_params = self._build_where(query_config.filters, logic)
            params.extend(w_params)

        # ── GROUP BY clause ──────────────────────────────────────────────
        group_clause = ""
        if group_cols:
            group_clause = "GROUP BY " + ", ".join(_q(c) for c in group_cols)

        # ── HAVING clause ────────────────────────────────────────────────
        having_clause = ""
        if query_config.having:
            h_parts = []
            h_op_map = {"eq": "=", "ne": "!=", "gt": ">", "gte": ">=", "lt": "<", "lte": "<="}
            for h in query_config.having:
                fn = h.get("function", "").upper()
                col_ref = f"{fn}({_q(h['column'])})" if fn else _q(h["column"])
                op = h_op_map.get(h["operator"], "=")
                h_parts.append(f"{col_ref} {op} ?")
                params.append(h["value"])
            having_clause = "HAVING " + " AND ".join(h_parts)

        # ── ORDER BY clause ──────────────────────────────────────────────
        order_clause = ""
        if query_config.order_by:
            parts = [f'{_q(o["column"])} {o.get("direction", "ASC").upper()}'
                     for o in query_config.order_by]
            order_clause = "ORDER BY " + ", ".join(parts)

        # ── LIMIT clause ─────────────────────────────────────────────────
        limit_clause = f"LIMIT {query_config.limit}" if query_config.limit else ""

        # ── Assemble SQL ─────────────────────────────────────────────────
        sql_parts = [
            f"SELECT {distinct_kw}{', '.join(select_parts)}",
            f"FROM {from_clause}",
        ]
        if where_clause:
            sql_parts.append(where_clause)
        if group_clause:
            sql_parts.append(group_clause)
        if having_clause:
            sql_parts.append(having_clause)
        if order_clause:
            sql_parts.append(order_clause)
        if limit_clause:
            sql_parts.append(limit_clause)

        sql = "\n".join(sql_parts)
        logger.info(f"DuckDB SQL:\n{sql}")

        con = duckdb.connect()
        try:
            result_df = con.execute(sql, params).fetchdf()
            if len(result_df) > 0:
                yield result_df
        finally:
            con.close()

    # Keep old name as alias for backward compatibility
    execute_aggregate_query = execute_duckdb_query

    def execute_query_to_csv(self, query_config: QueryConfig, output_path: str,
                            progress_callback: Optional[callable] = None) -> Dict[str, Any]:
        """
        Execute query and save results to CSV with streaming
        
        Args:
            query_config: Query configuration
            output_path: Path to save CSV file
            progress_callback: Optional callback for progress updates
            
        Returns:
            Execution statistics
        """
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        total_rows = 0
        chunk_count = 0
        writer = None

        try:
            for chunk_df in self.execute_query(query_config):
                # Use PyArrow's C++ CSV writer — releases the GIL during I/O so
                # the asyncio event loop stays responsive while chunks are written.
                table = pa.Table.from_pandas(chunk_df, preserve_index=False)
                if writer is None:
                    writer = pacsv.CSVWriter(str(output_file), table.schema)
                writer.write(table)
                time.sleep(0)  # yield GIL between chunks so asyncio event loop stays alive

                total_rows += len(chunk_df)
                chunk_count += 1

                if progress_callback:
                    progress_callback({
                        "chunk": chunk_count,
                        "total_rows": total_rows,
                        "status": "processing"
                    })

                logger.info(f"Written chunk {chunk_count}, total rows: {total_rows}")
            
            if writer is not None:
                writer.close()
            elif not output_file.exists():
                output_file.touch()  # empty result — create file so readers don't 404

            stats = {
                "total_rows": total_rows,
                "chunks_processed": chunk_count,
                "output_file": str(output_file),
                "file_size_bytes": output_file.stat().st_size if output_file.exists() else 0,
                "status": "completed"
            }

            if progress_callback:
                progress_callback(stats)

            logger.info(f"Query execution completed: {stats}")
            return stats

        except Exception as e:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass
            logger.error(f"Error executing query: {e}")
            if progress_callback:
                progress_callback({
                    "status": "failed",
                    "error": str(e)
                })
            raise
    
    def generate_query_id(self, query_config: QueryConfig) -> str:
        """
        Generate unique ID for a query
        
        Args:
            query_config: Query configuration
            
        Returns:
            Unique query ID
        """
        query_str = json.dumps(query_config.__dict__, sort_keys=True, default=str)
        return hashlib.md5(query_str.encode()).hexdigest()
    
    def validate_query(self, query_config: QueryConfig) -> Dict[str, Any]:
        """
        Validate query configuration
        
        Args:
            query_config: Query configuration to validate
            
        Returns:
            Validation result with errors if any
        """
        errors = []
        warnings = []
        
        # Check if files exist
        for file in query_config.files:
            try:
                self.get_file_schema(file)
            except Exception as e:
                errors.append(f"File not found or inaccessible: {file} - {str(e)}")
        
        # Validate join configurations
        if query_config.joins:
            for join in query_config.joins:
                try:
                    self.get_file_schema(join.right_file)
                except Exception as e:
                    errors.append(f"Join file not found: {join.right_file} - {str(e)}")
        
        # Validate columns if specified
        if query_config.columns and query_config.files:
            try:
                schema = self.get_file_schema(query_config.files[0])
                available_cols = {col["name"] for col in schema["columns"]}
                
                for col in query_config.columns:
                    if col not in available_cols:
                        warnings.append(f"Column '{col}' not found in primary file")
            except Exception as e:
                warnings.append(f"Could not validate columns: {str(e)}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
