import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeContextProvider } from './context/ThemeContext';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Layout from './components/Layout';
import LoginPage from './components/LoginPage';
import QueryTabManager from './components/QueryTabManager';
import SavedQueries from './components/SavedQueries';
import Downloads from './components/Downloads';
import ExecutionHistory from './components/ExecutionHistory';
import ReportPage from './components/ReportPage';
import ConnectionManager from './components/ConnectionManager';
import SqlQueryPage from './components/SqlQueryPage';
import ReportsManagerPage from './components/ReportsManagerPage';
import ReportConnectorsPage from './components/ReportConnectorsPage';
import SchedulesPage from './components/SchedulesPage';
import FilePreviewPage from './components/FilePreviewPage';
import DashboardPage from './components/DashboardPage';
import SharedQueryPage from './components/SharedQueryPage';
import SharedDashboardPage from './components/SharedDashboardPage';
import EmbeddedReportPage from './components/EmbeddedReportPage';
import SharedBusinessReportPage from './components/SharedBusinessReportPage';
import EmbeddedBusinessReportPage from './components/EmbeddedBusinessReportPage';
import MaterializedViewsPage from './components/MaterializedViewsPage';
import LocalTablesPage from './components/LocalTablesPage';
import ErrorBoundary from './components/ErrorBoundary';

// Lazy-loaded heavy pages — split into separate chunks to reduce initial bundle size
const AdminPage = lazy(() => import('./components/AdminPage'));
const LineagePage = lazy(() => import('./components/LineagePage'));
const ReportCatalogPage = lazy(() => import('./components/ReportCatalogPage'));
const DatasetManagerPage = lazy(() => import('./components/DatasetManagerPage'));
const DatasetQueryPanel = lazy(() => import('./components/DatasetQueryPanel'));
const BusinessReportBuilder = lazy(() => import('./components/BusinessReportBuilder'));
const BusinessReportViewer = lazy(() => import('./components/BusinessReportViewer'));
const ReportsListPage = lazy(() => import('./components/ReportsListPage'));
const BusinessPortalPage = lazy(() => import('./components/BusinessPortalPage'));
import { WebSocketProvider } from './context/WebSocketContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppSettingsProvider } from './context/AppSettingsContext';
import { WorkspaceProvider } from './context/WorkspaceContext';
import { AssistantContextProvider } from './context/AssistantContext';
import { UIVisibilityProvider, useComponentVisible } from './context/UIVisibilityContext';
import NotificationCenter from './components/NotificationCenter';
import './App.css';

// Shown to logged-in AD users who lack the required role
const AccessDenied = () => {
  const { user, logout } = useAuth();
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 2 }}>
      <LockOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
      <Typography variant="h5" fontWeight={600}>Access Denied</Typography>
      <Typography color="text.secondary">
        Your account (<strong>{user?.display_name || user?.username}</strong>) does not have permission to access QueryStudio.
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Contact your administrator to be added to an authorised AD group.
      </Typography>
      <Button variant="outlined" onClick={logout}>Sign Out</Button>
    </Box>
  );
};

// Role guard — restricts route access based on RBAC role
const RoleGuard = ({ roles, children }: { roles: string[], children: React.ReactNode }) => {
  const { user, authEnabled } = useAuth();
  if (!authEnabled) return <>{children}</>;
  const role = (user as any)?.role || 'viewer';
  if (!roles.includes(role)) return <AccessDenied />;
  return <>{children}</>;
};

// Component visibility guard — hides routes disabled by admin for the current role
const ComponentDisabledGuard = ({ componentKey, children }: { componentKey: string, children: React.ReactNode }) => {
  const visible = useComponentVisible(componentKey);
  if (!visible) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 2 }}>
        <LockOutlinedIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
        <Typography variant="h6" color="text.secondary">This feature is not available for your role.</Typography>
      </Box>
    );
  }
  return <>{children}</>;
};

const AppRoutes = () => {
  const { authEnabled, user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Auth enabled but not logged in → login screen
  if (authEnabled && !user) {
    return <LoginPage />;
  }

  return (
    <AppSettingsProvider>
    <UIVisibilityProvider>
    <AssistantContextProvider>
    <WorkspaceProvider>
    <WebSocketProvider>
      <NotificationProvider>
        <Layout>
          <NotificationCenter />
          <ErrorBoundary resetKey={location.pathname}>
            <Suspense fallback={<Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress /></Box>}>
              <Routes>
                <Route path="/connections"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="connections"><ConnectionManager /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/materialized-views" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="materialized_views"><MaterializedViewsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/local-tables"       element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="local_tables"><LocalTablesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/lineage"            element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="lineage"><LineagePage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/datasets"          element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="semantic_layer"><DatasetManagerPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/datasets/:id/query" element={<ComponentDisabledGuard componentKey="federation"><DatasetQueryPanel /></ComponentDisabledGuard>} />
                <Route path="/business-reports"        element={<ComponentDisabledGuard componentKey="business_reports"><ReportsListPage /></ComponentDisabledGuard>} />
                <Route path="/business-reports/new"    element={<ComponentDisabledGuard componentKey="business_reports"><BusinessReportBuilder /></ComponentDisabledGuard>} />
                <Route path="/business-reports/:id"    element={<ComponentDisabledGuard componentKey="business_reports"><BusinessReportViewer /></ComponentDisabledGuard>} />
                <Route path="/business-reports/:id/edit" element={<ComponentDisabledGuard componentKey="business_reports"><BusinessReportBuilder /></ComponentDisabledGuard>} />
                <Route path="/"                  element={<ComponentDisabledGuard componentKey="business_portal"><BusinessPortalPage /></ComponentDisabledGuard>} />
                <Route path="/query-builder"     element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="query_builder"><QueryTabManager /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/reports"           element={<ComponentDisabledGuard componentKey="reports"><ReportPage /></ComponentDisabledGuard>} />
                <Route path="/reports/:reportId" element={<ComponentDisabledGuard componentKey="reports"><ReportPage /></ComponentDisabledGuard>} />
                <Route path="/saved-queries"     element={<ComponentDisabledGuard componentKey="saved_queries"><SavedQueries /></ComponentDisabledGuard>} />
                <Route path="/executions"        element={<ComponentDisabledGuard componentKey="executions"><ExecutionHistory /></ComponentDisabledGuard>} />
                <Route path="/downloads"         element={<ComponentDisabledGuard componentKey="downloads"><Downloads /></ComponentDisabledGuard>} />
                <Route path="/sql"               element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="sql_editor"><SqlQueryPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/report-manager"    element={<ComponentDisabledGuard componentKey="reports"><ReportsManagerPage /></ComponentDisabledGuard>} />
                <Route path="/report-catalog"    element={<ComponentDisabledGuard componentKey="report_catalog"><ReportCatalogPage /></ComponentDisabledGuard>} />
                <Route path="/report-connectors" element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="report_connectors"><ReportConnectorsPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/schedules"         element={<RoleGuard roles={['admin','analyst']}><ComponentDisabledGuard componentKey="schedules"><SchedulesPage /></ComponentDisabledGuard></RoleGuard>} />
                <Route path="/file-preview"      element={<FilePreviewPage />} />
                <Route path="/dashboards"        element={<ComponentDisabledGuard componentKey="dashboards"><DashboardPage /></ComponentDisabledGuard>} />
                <Route path="/admin"             element={<RoleGuard roles={['admin']}><ComponentDisabledGuard componentKey="admin"><AdminPage /></ComponentDisabledGuard></RoleGuard>} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </Layout>
      </NotificationProvider>
    </WebSocketProvider>
    </WorkspaceProvider>
    </AssistantContextProvider>
    </UIVisibilityProvider>
    </AppSettingsProvider>
  );
};

function App() {
  return (
    <ThemeContextProvider>
      <Router>
        {/* Public routes — no auth required */}
        <Routes>
          <Route path="/shared/:token" element={<SharedQueryPage />} />
          <Route path="/shared-dashboard/:token" element={<SharedDashboardPage />} />
          <Route path="/shared-business-report/:token" element={<SharedBusinessReportPage />} />
          <Route path="/embed/:token" element={<EmbeddedReportPage />} />
          <Route path="/embedded-business-report/:token" element={<EmbeddedBusinessReportPage />} />
          <Route path="/*" element={
            <AuthProvider>
              <AppRoutes />
            </AuthProvider>
          } />
        </Routes>
      </Router>
    </ThemeContextProvider>
  );
}

export default App;
