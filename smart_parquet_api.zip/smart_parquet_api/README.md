# Smart Parquet Query API

Enterprise-grade, config-driven FastAPI for querying **Parquet files** on **local disk** or **Amazon S3** using **DuckDB** as the embedded analytical engine.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                         Client (HTTP)                            │
└────────────────────────────┬─────────────────────────────────────┘
                             │
┌────────────────────────────▼─────────────────────────────────────┐
│                      FastAPI Application                         │
│                                                                  │
│  ┌──────────────┐   ┌──────────────────┐   ┌─────────────────┐  │
│  │ Admin Router │   │  Dynamic Router   │   │  Middleware      │  │
│  │ /api/admin/* │   │  /api/query/*     │   │  GZip, CORS,    │  │
│  │ health       │   │  (auto-generated  │   │  Request-ID,    │  │
│  │ endpoints    │   │   from YAML)      │   │  API-Key        │  │
│  │ cache        │   └────────┬─────────┘   └─────────────────┘  │
│  └──────────────┘            │                                   │
│                              │                                   │
│  ┌───────────────────────────▼──────────────────────────────┐   │
│  │              QueryExecutor (async + thread pool)          │   │
│  │  • Pagination  • TTL Cache  • Timeout  • EXPLAIN          │   │
│  └───────────────────────────┬──────────────────────────────┘   │
│                              │                                   │
│  ┌───────────────────────────▼──────────────────────────────┐   │
│  │              DuckDB Connection Pool (N threads)            │   │
│  │  • httpfs (S3)   • snappy/zstd Parquet  • vectorised       │   │
│  └───────────┬─────────────────────────┬────────────────────┘   │
└──────────────┼─────────────────────────┼────────────────────────┘
               │                         │
    ┌──────────▼──────┐       ┌──────────▼──────────┐
    │  Local Parquet  │       │   S3 / MinIO         │
    │  ./data/*.parq  │       │   s3://bucket/path   │
    └─────────────────┘       └─────────────────────┘
```

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Generate sample Parquet data

```bash
python scripts/generate_sample_data.py
```

This creates **3 Parquet files** in `data/`:

| File | Columns | Rows | Size |
|------|---------|------|------|
| `tb_accounts.parquet` | ~1000 | 5,000 | ~15 MB |
| `tb_transactions.parquet` | ~1000 | 5,000 | ~20 MB |
| `tb_balances.parquet` | ~1000 | 5,000 | ~18 MB |

### 3. Configure (optional)

```bash
cp .env.example .env
# Edit .env for your S3 credentials, memory limits, etc.
```

### 4. Start the API

```bash
python -m app.main
# → http://localhost:8000
# → http://localhost:8000/docs   (Swagger UI)
```

### 5. Run tests

```bash
pytest tests/test_api.py -v
```

---

## Docker

```bash
# Generate data first
python scripts/generate_sample_data.py

# Start API + MinIO (S3-compatible)
docker-compose up --build

# API:      http://localhost:8000/docs
# MinIO:    http://localhost:9001  (minioadmin / minioadmin)
```

---

## API Reference

All endpoints support:
- `page=1` — page number (1-indexed)
- `pageSize=1000` — rows per page (max 50,000)
- `cache=true` — use cached results
- `explain=true` — return DuckDB query plan

### Response format

```json
{
  "meta": {
    "query_id": "a3f1b2c4",
    "columns": ["account_id", "account_name", ...],
    "total_rows": 12500,
    "page": 1,
    "page_size": 1000,
    "total_pages": 13,
    "execution_ms": 142.5,
    "cached": false
  },
  "data": [
    { "account_id": "ACC-000001", "account_name": "Cash", ... },
    ...
  ]
}
```

### Auto-generated Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/query/trial-balance/full-join` | 3-way JOIN → 200 columns |
| GET | `/api/query/trial-balance/summary` | Aggregated by account/period |
| GET | `/api/query/trial-balance/audit-trail` | UNION ALL across all 3 files |
| GET | `/api/query/trial-balance/unreconciled` | Unreconciled items |
| GET | `/api/query/trial-balance/pl-rollup` | P&L by entity/period |
| GET | `/api/query/trial-balance/balance-sheet` | Balance sheet snapshot |
| GET | `/api/query/trial-balance/intercompany` | Intercompany analysis |
| GET | `/api/query/trial-balance/ytd` | YTD performance |
| GET | `/api/query/trial-balance/cost-centre` | Cost centre drill-down |

### Admin Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/admin/health` | Health check |
| GET | `/api/admin/endpoints` | List all registered endpoints |
| GET | `/api/admin/cache` | Cache statistics |
| DELETE | `/api/admin/cache` | Clear all cached results |

---

## Adding New Endpoints

Edit `config/queries.yaml` — no code changes needed:

```yaml
endpoints:
  - id: my_new_report
    path: /reports/my-report
    method: GET
    tags: [reports]
    summary: "My Custom Report"
    sources:
      source1:
        type: local             # or s3
        path: data/my_file.parquet
      source2:
        type: s3
        path: s3://my-bucket/data/other.parquet
    parameters:
      - name: year
        type: integer
        required: false
        default: 2024
        description: "Filter year"
    query: |
      SELECT *
      FROM read_parquet('{source1}') AS a
      JOIN read_parquet('{source2}') AS b ON a.id = b.id
      WHERE a.year = {year}
    pagination: true
    cache: true
```

Restart the API → the new endpoint is live at `/api/query/reports/my-report`.

---

## S3 Configuration

In `.env`:

```bash
S3_ENABLED=true
S3_BUCKET=my-data-lake
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
```

In `queries.yaml` — use `s3://` paths:

```yaml
sources:
  my_table:
    type: s3
    path: s3://my-data-lake/warehouse/my_table.parquet
```

**DuckDB httpfs** handles the S3 authentication transparently, including:
- Standard AWS credentials chain
- IAM instance roles (no keys needed on EC2/ECS)
- MinIO / LocalStack via `S3_ENDPOINT_URL`
- Glob patterns: `s3://bucket/year=2024/**/*.parquet`

---

## Performance Notes

| Scenario | Guidance |
|----------|----------|
| Files < 1 GB | DuckDB reads entire file; very fast |
| Files 1–50 GB | Enable column pruning (DuckDB does this automatically) |
| Files > 50 GB | Partition by year/month at the S3 level; use glob patterns |
| Many concurrent users | Increase `DUCKDB_THREADS` and `WORKERS` |
| Repeated queries | `CACHE_ENABLED=true` eliminates redundant scans |
| Memory pressure | Set `DUCKDB_MEMORY_LIMIT` and `DUCKDB_TEMP_DIR` for spill-to-disk |

---

## Project Structure

```
smart_parquet_api/
├── app/
│   ├── main.py                # FastAPI app factory + lifespan
│   ├── api/
│   │   ├── models.py          # Pydantic request/response schemas
│   │   └── router.py          # Dynamic endpoint generator
│   └── core/
│       ├── settings.py        # Pydantic-settings (env vars)
│       ├── logging.py         # Structured logging (structlog)
│       ├── database.py        # DuckDB connection pool
│       ├── config_loader.py   # YAML config → EndpointRegistry
│       └── query_executor.py  # Async query runner + cache
├── config/
│   └── queries.yaml           # ← Define ALL endpoints here
├── data/
│   ├── tb_accounts.parquet
│   ├── tb_transactions.parquet
│   └── tb_balances.parquet
├── scripts/
│   └── generate_sample_data.py
├── tests/
│   └── test_api.py
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```
