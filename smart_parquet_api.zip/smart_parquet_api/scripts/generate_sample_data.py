#!/usr/bin/env python3
# ============================================================
# scripts/generate_sample_data.py
# Generates 3 trial balance Parquet files (1000 cols, 5000 rows each)
# ============================================================
"""
Trial Balance schema:
  tb_accounts.parquet      — Chart of accounts master
  tb_transactions.parquet  — Journal entries / transactions
  tb_balances.parquet      — Period-end balance aggregates

All three share account_id as the join key.
Each file has ~1000 columns covering:
  - Core dimensions   (~20 cols)
  - Amounts / metrics (~100 cols per currency pair)
  - Extended metadata (~880 flexible attribute cols)
"""
import os
import sys
import random
import string
from pathlib import Path
from datetime import date, timedelta, datetime

import pandas as pd
import numpy as np

# ── Output directory ──────────────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

ROWS = 5_000          # rows per file
SEED = 42
rng  = np.random.default_rng(SEED)
random.seed(SEED)

FISCAL_YEARS  = [2022, 2023, 2024]
PERIODS       = list(range(1, 13))          # 1-12
CURRENCIES    = ["USD", "EUR", "GBP", "JPY", "INR"]
ACCOUNT_TYPES = ["Asset", "Liability", "Equity", "Revenue", "Expense"]
COST_CENTRES  = [f"CC{i:04d}" for i in range(1, 51)]
SEGMENTS      = ["SEG_A", "SEG_B", "SEG_C", "SEG_D"]
ENTITIES      = [f"ENT_{c}" for c in ["US", "UK", "DE", "JP", "IN", "SG", "AU"]]
LEDGERS       = ["PRIMARY", "SECONDARY", "STAT", "MGMT"]


def rand_account_ids(n):
    return [f"ACC-{i:06d}" for i in rng.integers(1, 10_001, size=n)]


def rand_dates(n, start="2022-01-01", end="2024-12-31"):
    s = pd.Timestamp(start).value // 10**9
    e = pd.Timestamp(end).value // 10**9
    ts = rng.integers(s, e, size=n)
    return pd.to_datetime(ts, unit="s").normalize()


def amount_cols(prefix: str, n_pairs: int = 20) -> dict:
    """Generate debit/credit/net/balance columns per currency pair."""
    cols = {}
    for i in range(n_pairs):
        tag = f"{prefix}_{i:02d}"
        debits  = rng.uniform(0, 1_000_000, ROWS).round(2)
        credits = rng.uniform(0, 1_000_000, ROWS).round(2)
        cols[f"debit_{tag}"]         = debits
        cols[f"credit_{tag}"]        = credits
        cols[f"net_{tag}"]           = (debits - credits).round(2)
        cols[f"opening_bal_{tag}"]   = rng.uniform(-500_000, 500_000, ROWS).round(2)
        cols[f"closing_bal_{tag}"]   = (cols[f"opening_bal_{tag}"] + cols[f"net_{tag}"]).round(2)
    return cols


def flag_cols(n: int, prefix: str) -> dict:
    return {f"{prefix}_flag_{i:03d}": rng.choice([True, False], ROWS) for i in range(n)}


def code_cols(n: int, prefix: str, length: int = 6) -> dict:
    pool = [f"{prefix}{''.join(random.choices(string.ascii_uppercase, k=length))}" for _ in range(200)]
    return {f"{prefix}_code_{i:03d}": rng.choice(pool, ROWS) for i in range(n)}


def numeric_cols(n: int, prefix: str) -> dict:
    return {f"{prefix}_metric_{i:03d}": rng.uniform(-1e6, 1e6, ROWS).round(4) for i in range(n)}


# ─────────────────────────────────────────────────────────────────────────────
# tb_accounts  (~1000 columns)
# ─────────────────────────────────────────────────────────────────────────────
def build_accounts() -> pd.DataFrame:
    print("  Building tb_accounts …")
    account_ids = [f"ACC-{i:06d}" for i in range(1, ROWS + 1)]

    core = {
        "account_id":          account_ids,                                         # PK / join key
        "account_code":        [f"GL{i:07d}" for i in range(1, ROWS + 1)],
        "account_name":        [f"Account Name {i}" for i in range(1, ROWS + 1)],
        "account_type":        rng.choice(ACCOUNT_TYPES, ROWS),
        "account_subtype":     rng.choice(["Current", "Non-Current", "Operating", "Non-Operating"], ROWS),
        "currency":            rng.choice(CURRENCIES, ROWS),
        "entity":              rng.choice(ENTITIES, ROWS),
        "cost_centre":         rng.choice(COST_CENTRES, ROWS),
        "segment":             rng.choice(SEGMENTS, ROWS),
        "ledger":              rng.choice(LEDGERS, ROWS),
        "is_active":           rng.choice([True, False], ROWS, p=[0.9, 0.1]),
        "is_control_account":  rng.choice([True, False], ROWS, p=[0.1, 0.9]),
        "parent_account_id":   [f"ACC-{i:06d}" if i > 0 else None for i in rng.integers(0, 500, ROWS)],
        "hierarchy_level":     rng.integers(1, 6, ROWS),
        "created_date":        rand_dates(ROWS, "2015-01-01", "2022-01-01"),
        "last_modified_date":  rand_dates(ROWS, "2022-01-01", "2024-12-31"),
        "ifrs_classification": rng.choice(["IAS1", "IAS7", "IFRS9", "IFRS15", "IFRS16"], ROWS),
        "gaap_classification": rng.choice(["ASC205", "ASC230", "ASC310", "ASC606", "ASC842"], ROWS),
        "tax_code":            rng.choice(["TX00", "TX05", "TX10", "TX15", "TX20", "TX_EXEMPT"], ROWS),
        "intercompany_flag":   rng.choice([True, False], ROWS, p=[0.2, 0.8]),
    }

    # ~500 attribute/classification columns
    attrs = {}
    attrs.update(code_cols(80,  "acct",    length=5))   # 80 code cols
    attrs.update(flag_cols(100, "acct"))                  # 100 bool flags
    attrs.update(numeric_cols(80, "acct"))                # 80 numeric attrs
    attrs.update({f"acct_desc_{i:03d}": [f"Description {i}-{j}" for j in range(ROWS)]
                  for i in range(200)})                   # 200 text cols
    # Add remaining to reach 1000
    attrs.update(numeric_cols(40, "acct_ext"))            # 40 extra numerics

    df = pd.DataFrame({**core, **attrs})
    print(f"    → {len(df.columns)} columns, {len(df):,} rows")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# tb_transactions  (~1000 columns)
# ─────────────────────────────────────────────────────────────────────────────
def build_transactions() -> pd.DataFrame:
    print("  Building tb_transactions …")
    account_ids = [f"ACC-{i:06d}" for i in rng.integers(1, ROWS + 1, ROWS)]

    core = {
        "transaction_id":      [f"TXN-{i:08d}" for i in range(1, ROWS + 1)],      # PK
        "account_id":          account_ids,                                          # FK → accounts
        "journal_id":          [f"JE-{i:07d}" for i in rng.integers(1, 50_001, ROWS)],
        "posting_date":        rand_dates(ROWS),
        "value_date":          rand_dates(ROWS),
        "fiscal_year":         rng.choice(FISCAL_YEARS, ROWS),
        "period":              rng.choice(PERIODS, ROWS),
        "source_system":       rng.choice(["SAP", "Oracle", "NetSuite", "JDE", "Workday"], ROWS),
        "transaction_type":    rng.choice(["Manual", "System", "Reversal", "Accrual", "Reclassification"], ROWS),
        "status":              rng.choice(["Posted", "Draft", "Reversed", "Pending"], ROWS, p=[0.8, 0.05, 0.1, 0.05]),
        "entered_by":          [f"USER{rng.integers(1, 1000):04d}" for _ in range(ROWS)],
        "approved_by":         [f"MGR{rng.integers(1, 100):03d}" for _ in range(ROWS)],
        "cost_centre":         rng.choice(COST_CENTRES, ROWS),
        "entity":              rng.choice(ENTITIES, ROWS),
        "currency":            rng.choice(CURRENCIES, ROWS),
        "base_currency":       ["USD"] * ROWS,
        "exchange_rate":       rng.uniform(0.7, 150.0, ROWS).round(6),
        "debit_amount":        rng.uniform(0, 5_000_000, ROWS).round(2),
        "credit_amount":       rng.uniform(0, 5_000_000, ROWS).round(2),
        "description":         [f"Transaction description {i}" for i in range(ROWS)],
        "reference":           [f"REF-{i:09d}" for i in rng.integers(1, 999_999_999, ROWS)],
    }

    ext = {}
    ext.update(amount_cols("txn", n_pairs=50))   # 50×5 = 250 amount cols
    ext.update(code_cols(100, "txn", length=6))  # 100 code cols
    ext.update(flag_cols(100, "txn"))             # 100 flags
    ext.update(numeric_cols(100, "txn"))          # 100 numerics
    # fill to 1000
    ext.update({f"txn_text_{i:03d}": [f"Note {i}-{j}" for j in range(ROWS)]
                for i in range(80)})

    df = pd.DataFrame({**core, **ext})
    print(f"    → {len(df.columns)} columns, {len(df):,} rows")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# tb_balances  (~1000 columns)
# ─────────────────────────────────────────────────────────────────────────────
def build_balances() -> pd.DataFrame:
    print("  Building tb_balances …")
    account_ids = [f"ACC-{i:06d}" for i in rng.integers(1, ROWS + 1, ROWS)]

    core = {
        "balance_id":          [f"BAL-{i:08d}" for i in range(1, ROWS + 1)],      # PK
        "account_id":          account_ids,                                          # FK → accounts
        "fiscal_year":         rng.choice(FISCAL_YEARS, ROWS),
        "period":              rng.choice(PERIODS, ROWS),
        "entity":              rng.choice(ENTITIES, ROWS),
        "cost_centre":         rng.choice(COST_CENTRES, ROWS),
        "currency":            rng.choice(CURRENCIES, ROWS),
        "ledger":              rng.choice(LEDGERS, ROWS),
        "segment":             rng.choice(SEGMENTS, ROWS),
        "opening_balance":     rng.uniform(-10_000_000, 10_000_000, ROWS).round(2),
        "period_debits":       rng.uniform(0, 5_000_000, ROWS).round(2),
        "period_credits":      rng.uniform(0, 5_000_000, ROWS).round(2),
        "closing_balance":     rng.uniform(-10_000_000, 10_000_000, ROWS).round(2),
        "ytd_debits":          rng.uniform(0, 50_000_000, ROWS).round(2),
        "ytd_credits":         rng.uniform(0, 50_000_000, ROWS).round(2),
        "budget_amount":       rng.uniform(-10_000_000, 10_000_000, ROWS).round(2),
        "variance":            rng.uniform(-5_000_000, 5_000_000, ROWS).round(2),
        "variance_pct":        rng.uniform(-100, 100, ROWS).round(4),
        "last_reconciled":     rand_dates(ROWS, "2022-01-01", "2024-12-31"),
        "is_reconciled":       rng.choice([True, False], ROWS, p=[0.7, 0.3]),
    }

    ext = {}
    ext.update(amount_cols("bal", n_pairs=50))   # 50×5 = 250 cols
    ext.update(code_cols(100, "bal", length=6))
    ext.update(flag_cols(150, "bal"))
    ext.update(numeric_cols(150, "bal"))
    ext.update({f"bal_note_{i:03d}": [f"Balance note {i}-{j}" for j in range(ROWS)]
                for i in range(80)})

    df = pd.DataFrame({**core, **ext})
    print(f"    → {len(df.columns)} columns, {len(df):,} rows")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Write Parquet
# ─────────────────────────────────────────────────────────────────────────────
def write_parquet(df: pd.DataFrame, name: str) -> Path:
    path = DATA_DIR / f"{name}.parquet"
    df.to_parquet(path, index=False, engine="pyarrow", compression="snappy")
    size_mb = path.stat().st_size / 1024 / 1024
    print(f"    ✓ Written: {path}  ({size_mb:.1f} MB)")
    return path


def main():
    print(f"\n{'='*60}")
    print(f"  Generating sample Trial Balance Parquet files")
    print(f"  Output directory: {DATA_DIR}")
    print(f"  Rows per file: {ROWS:,}")
    print(f"{'='*60}\n")

    dfs = {
        "tb_accounts":      build_accounts(),
        "tb_transactions":  build_transactions(),
        "tb_balances":      build_balances(),
    }

    print("\nWriting Parquet files …")
    for name, df in dfs.items():
        write_parquet(df, name)

    print(f"\n✅ Done! 3 Parquet files ready in {DATA_DIR}\n")

    # Print column counts
    for name, df in dfs.items():
        print(f"  {name}: {len(df.columns)} columns, {len(df):,} rows")


if __name__ == "__main__":
    main()
