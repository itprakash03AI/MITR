#!/usr/bin/env python3
# ============================================================
# tests/test_api.py — Integration tests (pytest + httpx)
# ============================================================
"""
Run: pytest tests/test_api.py -v

Prerequisites:
  1. Generate sample data:   python scripts/generate_sample_data.py
  2. Start the API:          python -m app.main
"""
import asyncio
import pytest
import httpx

BASE_URL = "http://localhost:8000"


@pytest.fixture(scope="session")
def client():
    return httpx.Client(base_url=BASE_URL, timeout=60)


# ── Admin endpoints ──────────────────────────────────────────

def test_health(client):
    r = client.get("/api/admin/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    print(f"  Pool size: {body['pool_size']}")


def test_list_endpoints(client):
    r = client.get("/api/admin/endpoints")
    assert r.status_code == 200
    body = r.json()
    assert body["total"] >= 9
    print(f"  Registered endpoints: {body['total']}")
    for ep in body["endpoints"]:
        print(f"    {ep['method']:4s} {ep['path']}")


def test_cache_stats(client):
    r = client.get("/api/admin/cache")
    assert r.status_code == 200


# ── Trial Balance endpoints ───────────────────────────────────

def test_full_join(client):
    r = client.get(
        "/api/query/trial-balance/full-join",
        params={"fiscal_year": 2024, "pageSize": 100, "page": 1},
    )
    assert r.status_code == 200
    body = r.json()
    assert "meta" in body
    assert "data" in body
    assert body["meta"]["total_rows"] > 0
    assert len(body["data"]) <= 100
    # Verify 200-column output
    sample = body["data"][0]
    assert "account_id" in sample
    assert "transaction_id" in sample
    assert "balance_id" in sample
    assert "budget_utilisation_pct" in sample
    print(f"  full_join: {body['meta']['total_rows']:,} rows, "
          f"{len(sample)} columns, {body['meta']['execution_ms']:.0f}ms")


def test_full_join_entity_filter(client):
    r = client.get(
        "/api/query/trial-balance/full-join",
        params={"fiscal_year": 2024, "entity": "ENT_US", "pageSize": 50},
    )
    assert r.status_code == 200


def test_summary(client):
    r = client.get(
        "/api/query/trial-balance/summary",
        params={"fiscal_year": 2024, "pageSize": 200},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["meta"]["total_rows"] > 0
    print(f"  summary: {body['meta']['total_rows']:,} rows")


def test_audit_trail(client):
    r = client.get(
        "/api/query/trial-balance/audit-trail",
        params={"fiscal_year": 2024, "pageSize": 500},
    )
    assert r.status_code == 200
    body = r.json()
    data = body["data"]
    record_types = {row["record_type"] for row in data}
    # Should have all 3 types
    assert "TRANSACTION" in record_types or "BALANCE" in record_types
    print(f"  audit_trail: {body['meta']['total_rows']:,} rows, types={record_types}")


def test_unreconciled(client):
    r = client.get(
        "/api/query/trial-balance/unreconciled",
        params={"fiscal_year": 2024, "min_variance": 100},
    )
    assert r.status_code == 200
    body = r.json()
    # All returned rows should have is_reconciled = false
    for row in body["data"]:
        assert row["is_reconciled"] is False
    print(f"  unreconciled: {body['meta']['total_rows']:,} rows")


def test_pl_rollup(client):
    r = client.get(
        "/api/query/trial-balance/pl-rollup",
        params={"fiscal_year": 2024},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["meta"]["total_rows"] > 0
    print(f"  pl_rollup: {body['meta']['total_rows']:,} rows")


def test_balance_sheet(client):
    r = client.get(
        "/api/query/trial-balance/balance-sheet",
        params={"fiscal_year": 2024, "period": 12},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["meta"]["total_rows"] > 0
    print(f"  balance_sheet: {body['meta']['total_rows']:,} rows")


def test_intercompany(client):
    r = client.get(
        "/api/query/trial-balance/intercompany",
        params={"fiscal_year": 2024},
    )
    assert r.status_code == 200
    body = r.json()
    print(f"  intercompany: {body['meta']['total_rows']:,} rows")


def test_ytd(client):
    r = client.get(
        "/api/query/trial-balance/ytd",
        params={"fiscal_year": 2024, "up_to_period": 6},
    )
    assert r.status_code == 200
    body = r.json()
    print(f"  ytd: {body['meta']['total_rows']:,} rows")


def test_cost_centre(client):
    r = client.get(
        "/api/query/trial-balance/cost-centre",
        params={"fiscal_year": 2024, "cost_centre": "CC0001"},
    )
    assert r.status_code == 200
    body = r.json()
    print(f"  cost_centre CC0001: {body['meta']['total_rows']:,} rows")


# ── Caching test ─────────────────────────────────────────────

def test_cache_hit(client):
    params = {"fiscal_year": 2024, "pageSize": 10}
    r1 = client.get("/api/query/trial-balance/summary", params=params)
    r2 = client.get("/api/query/trial-balance/summary", params=params)
    assert r1.status_code == 200
    assert r2.status_code == 200
    b1 = r1.json()
    b2 = r2.json()
    assert b2["meta"]["cached"] is True
    print(f"  Cache: first={b1['meta']['execution_ms']:.0f}ms, "
          f"cached={b2['meta']['execution_ms']:.0f}ms")


# ── EXPLAIN test ──────────────────────────────────────────────

def test_explain(client):
    r = client.get(
        "/api/query/trial-balance/summary",
        params={"explain": True},
    )
    assert r.status_code == 200
    body = r.json()
    assert "plan" in body
    print(f"  explain: {len(body['plan'])} chars")


# ── Pagination test ───────────────────────────────────────────

def test_pagination(client):
    p1 = client.get(
        "/api/query/trial-balance/audit-trail",
        params={"fiscal_year": 2024, "pageSize": 10, "page": 1},
    ).json()
    p2 = client.get(
        "/api/query/trial-balance/audit-trail",
        params={"fiscal_year": 2024, "pageSize": 10, "page": 2},
    ).json()
    assert p1["meta"]["page"] == 1
    assert p2["meta"]["page"] == 2
    # Different data on each page
    ids1 = {str(r) for r in p1["data"]}
    ids2 = {str(r) for r in p2["data"]}
    assert ids1 != ids2
    print(f"  Pagination OK: page1={len(p1['data'])} rows, page2={len(p2['data'])} rows")


# ── Error handling ────────────────────────────────────────────

def test_invalid_endpoint(client):
    r = client.get("/api/query/does-not-exist")
    assert r.status_code == 404


if __name__ == "__main__":
    # Quick manual run without pytest
    c = httpx.Client(base_url=BASE_URL, timeout=60)
    print("Running quick smoke test …\n")
    for fn_name, fn in list(globals().items()):
        if fn_name.startswith("test_") and callable(fn):
            try:
                fn(c)
                print(f"✅ {fn_name}")
            except Exception as e:
                print(f"❌ {fn_name}: {e}")
