# ============================================================
# app/api/router.py — Dynamic endpoint generation from registry
# ============================================================
"""
For each EndpointSpec in the registry we programmatically create
a FastAPI route so that queries.yaml drives the API surface.

GET  endpoints get query params auto-generated from ParamSpec.
POST endpoints accept a QueryRequest body.
"""
import inspect
from typing import Any, Dict, List, Optional, get_type_hints

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from fastapi.responses import StreamingResponse
import json
import structlog

from app.core.config_loader import EndpointSpec, ParamSpec, registry
from app.core.database import DuckDBPool, get_db_pool
from app.core.query_executor import QueryExecutor, result_cache
from app.core.settings import settings
from app.api.models import (
    ErrorResponse,
    ExplainResponse,
    QueryRequest,
    QueryResponse,
)

logger = structlog.get_logger()


# ── Admin / meta router ──────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/api/admin", tags=["admin"])


@admin_router.get("/health")
async def health(pool: DuckDBPool = Depends(get_db_pool)):
    return {
        "status": "ok",
        "version": settings.app_version,
        "pool_size": settings.duckdb_threads,
        "cache_entries": result_cache.size,
        "s3_enabled": settings.s3_enabled,
    }


@admin_router.get("/endpoints")
async def list_endpoints():
    eps = registry.all()
    return {
        "total": len(eps),
        "endpoints": [
            {
                "id": ep.id,
                "path": f"/api/query{ep.path}",
                "method": ep.method,
                "tags": ep.tags,
                "summary": ep.summary,
                "parameters": [
                    {
                        "name": p.name,
                        "type": p.param_type,
                        "required": p.required,
                        "default": p.default,
                    }
                    for p in ep.parameters
                ],
                "sources": {
                    k: {"type": v.source_type, "path": v.resolved_path}
                    for k, v in ep.sources.items()
                },
            }
            for ep in eps
        ],
    }


@admin_router.delete("/cache")
async def clear_cache():
    result_cache.clear()
    return {"message": "Cache cleared", "entries": 0}


@admin_router.get("/cache")
async def cache_stats():
    return {"entries": result_cache.size}


# ── Dynamic query router ──────────────────────────────────────────────────────
query_router = APIRouter(prefix="/api/query", tags=["queries"])


def _build_handler(ep: EndpointSpec):
    """
    Factory: returns a FastAPI handler function tailored for `ep`.

    We dynamically build the signature so that FastAPI can inspect it
    for query-parameter binding and OpenAPI schema generation.
    """

    async def _handler(
        request: Request,
        page: int = Query(default=1, ge=1, description="Page number"),
        page_size: int = Query(
            default=settings.default_page_size,
            ge=1,
            le=settings.max_page_size,
            alias="pageSize",
            description="Rows per page",
        ),
        cache: bool = Query(default=ep.cache, description="Use cache"),
        explain: bool = Query(default=False, description="Return query plan"),
        pool: DuckDBPool = Depends(get_db_pool),
        **user_params,
    ):
        executor = QueryExecutor(pool)

        # Merge query string params captured in **user_params
        param_values: Dict[str, Any] = dict(user_params)

        try:
            sql = ep.render_query(param_values)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))

        logger.info("request_received", endpoint=ep.id, page=page, page_size=page_size)

        if explain:
            plan = await executor.explain(sql)
            return ExplainResponse(query_id=ep.id, plan=plan)

        if ep.stream:
            async def _stream_gen():
                async for chunk in executor.stream(sql):
                    for row in chunk:
                        yield json.dumps(row) + "\n"

            return StreamingResponse(
                _stream_gen(), media_type="application/x-ndjson"
            )

        try:
            result = await executor.execute(
                sql,
                page=page,
                page_size=page_size,
                cache=cache,
                cache_ttl=ep.cache_ttl,
            )
        except TimeoutError:
            raise HTTPException(status_code=504, detail="Query timed out")
        except Exception as exc:
            logger.error("query_failed", endpoint=ep.id, error=str(exc))
            raise HTTPException(status_code=500, detail=str(exc))

        return result.to_dict()

    # ── Dynamically inject per-endpoint query params into the signature ──────
    # FastAPI reads inspect.signature() to build query params + OpenAPI docs.
    existing_params = list(inspect.signature(_handler).parameters.values())

    # Build new params for each EndpointSpec parameter
    ep_params = []
    for p_spec in ep.parameters:
        default = Query(
            default=p_spec.default if not p_spec.required else ...,
            description=p_spec.description,
            **({"enum": p_spec.enum} if p_spec.enum else {}),
        )
        ep_params.append(
            inspect.Parameter(
                name=p_spec.name,
                kind=inspect.Parameter.KEYWORD_ONLY,
                default=default,
                annotation=Optional[p_spec.python_type] if not p_spec.required else p_spec.python_type,
            )
        )

    # Insert ep_params before **user_params (last positional)
    new_params = existing_params[:-1] + ep_params + [existing_params[-1]]
    _handler.__signature__ = inspect.Signature(new_params)
    _handler.__name__ = f"endpoint_{ep.id}"
    _handler.__doc__ = ep.description or ep.summary

    return _handler


def register_all_endpoints(app_router: APIRouter) -> None:
    """
    Called once at startup — iterates registry and mounts all endpoints.
    """
    for ep in registry.all():
        handler = _build_handler(ep)
        app_router.add_api_route(
            path=ep.path,
            endpoint=handler,
            methods=[ep.method],
            summary=ep.summary,
            description=ep.description,
            tags=ep.tags,
            response_model=None,   # dict response (flexible schema)
        )
        logger.info("route_mounted", method=ep.method, path=f"/api/query{ep.path}")
