# ============================================================
# app/core/settings.py — Enterprise configuration via env vars
# ============================================================
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
from pathlib import Path
import os


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────
    app_name: str = "Smart Parquet Query API"
    app_version: str = "1.0.0"
    debug: bool = False
    log_level: str = "INFO"

    # ── Server ───────────────────────────────────────────────
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4

    # ── DuckDB ───────────────────────────────────────────────
    duckdb_threads: int = 8
    duckdb_memory_limit: str = "4GB"       # e.g. "8GB", "16GB"
    duckdb_temp_dir: str = "/tmp/duckdb"
    query_timeout_seconds: int = 300

    # ── Storage: Local ───────────────────────────────────────
    local_data_dir: str = str(Path(__file__).parent.parent.parent / "data")

    # ── Storage: S3 ──────────────────────────────────────────
    s3_enabled: bool = False
    s3_bucket: str = ""
    s3_region: str = "us-east-1"
    s3_endpoint_url: Optional[str] = None   # for MinIO / LocalStack
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None

    # ── Config paths ─────────────────────────────────────────
    queries_config_path: str = str(Path(__file__).parent.parent.parent / "config" / "queries.yaml")

    # ── Pagination ───────────────────────────────────────────
    default_page_size: int = 1000
    max_page_size: int = 50_000

    # ── Cache ────────────────────────────────────────────────
    cache_enabled: bool = True
    cache_ttl_seconds: int = 300

    # ── Auth (optional) ──────────────────────────────────────
    api_key_enabled: bool = False
    api_key: Optional[str] = None

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
