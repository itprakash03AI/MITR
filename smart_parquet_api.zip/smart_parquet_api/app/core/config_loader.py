# ============================================================
# app/core/config_loader.py — Config-driven endpoint registry
# ============================================================
"""
Loads queries.yaml and builds an internal registry of all
API endpoints plus their SQL templates and metadata.

Config file schema (queries.yaml):
──────────────────────────────────
endpoints:
  - id: trial_balance_summary          # unique, becomes URL path
    path: /trial-balance/summary       # override path (optional)
    method: GET                        # GET | POST (default GET)
    tags: [trial-balance]              # OpenAPI tags
    summary: "Summarised trial balance"
    description: "Returns …"
    sources:                           # named data sources used in query
      tb_accounts:
        type: local                    # local | s3
        path: data/tb_accounts.parquet
      tb_transactions:
        type: s3
        path: s3://my-bucket/tb/transactions.parquet
    parameters:                        # query string / body params injected as ?param
      - name: fiscal_year
        type: integer
        required: false
        default: 2024
        description: "Fiscal year filter"
    query: |                           # DuckDB SQL — use {source_name} for paths
      SELECT …
      FROM read_parquet('{tb_accounts}') AS a
      JOIN read_parquet('{tb_transactions}') AS t …
      WHERE t.fiscal_year = {fiscal_year}
    pagination: true                   # enable limit/offset
    cache: true                        # enable result caching
    cache_ttl: 60                      # seconds (override global)
"""
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml
import structlog

from app.core.settings import settings

logger = structlog.get_logger()

# ── Data models (plain dicts — avoids circular Pydantic imports) ─────────────

class SourceSpec:
    __slots__ = ("name", "source_type", "raw_path", "resolved_path")

    def __init__(self, name: str, cfg: Dict[str, Any]):
        self.name = name
        self.source_type: str = cfg.get("type", "local")   # local | s3
        self.raw_path: str = cfg["path"]
        self.resolved_path: str = self._resolve()

    def _resolve(self) -> str:
        if self.source_type == "s3":
            # Already absolute s3:// path
            return self.raw_path
        # Local — resolve relative to project root
        p = Path(self.raw_path)
        if not p.is_absolute():
            p = Path(settings.local_data_dir).parent / self.raw_path
        return str(p.resolve())

    def __repr__(self):
        return f"<Source {self.name} [{self.source_type}] → {self.resolved_path}>"


class ParamSpec:
    __slots__ = ("name", "param_type", "required", "default", "description", "enum")

    TYPE_MAP = {"integer": int, "float": float, "boolean": bool, "string": str}

    def __init__(self, cfg: Dict[str, Any]):
        self.name: str = cfg["name"]
        self.param_type: str = cfg.get("type", "string")
        self.required: bool = cfg.get("required", False)
        self.default: Any = cfg.get("default")
        self.description: str = cfg.get("description", "")
        self.enum: Optional[List] = cfg.get("enum")

    @property
    def python_type(self):
        return self.TYPE_MAP.get(self.param_type, str)


class EndpointSpec:
    def __init__(self, cfg: Dict[str, Any]):
        self.id: str = cfg["id"]
        self.path: str = cfg.get("path", f"/{self.id.replace('_', '-')}")
        self.method: str = cfg.get("method", "GET").upper()
        self.tags: List[str] = cfg.get("tags", ["queries"])
        self.summary: str = cfg.get("summary", self.id)
        self.description: str = cfg.get("description", "")
        self.pagination: bool = cfg.get("pagination", True)
        self.cache: bool = cfg.get("cache", settings.cache_enabled)
        self.cache_ttl: int = cfg.get("cache_ttl", settings.cache_ttl_seconds)
        self.stream: bool = cfg.get("stream", False)

        # Sources
        raw_sources: Dict[str, Any] = cfg.get("sources", {})
        self.sources: Dict[str, SourceSpec] = {
            k: SourceSpec(k, v) for k, v in raw_sources.items()
        }

        # Params
        self.parameters: List[ParamSpec] = [
            ParamSpec(p) for p in cfg.get("parameters", [])
        ]

        # SQL template (raw — will be rendered at query time)
        self.query_template: str = cfg["query"].strip()

    def render_query(self, param_values: Dict[str, Any]) -> str:
        """
        Substitute {source_name} → resolved paths
        and {param_name} → user-supplied values in the SQL template.
        """
        ctx: Dict[str, Any] = {}

        # Inject source paths
        for name, src in self.sources.items():
            ctx[name] = src.resolved_path

        # Inject parameters (with type coercion + SQL-injection protection)
        for p in self.parameters:
            val = param_values.get(p.name, p.default)
            if val is None and p.required:
                raise ValueError(f"Required parameter '{p.name}' is missing")
            ctx[p.name] = _safe_value(val, p.param_type)

        return self.query_template.format(**ctx)


def _safe_value(val: Any, type_hint: str) -> Any:
    """Coerce + escape for safe SQL injection into DuckDB."""
    if val is None:
        return "NULL"
    if type_hint in ("integer", "float"):
        # Numeric — no quoting needed
        return val
    if type_hint == "boolean":
        return "true" if val else "false"
    # String — escape single quotes
    return str(val).replace("'", "''")


# ── Registry ─────────────────────────────────────────────────────────────────

class EndpointRegistry:
    def __init__(self):
        self._endpoints: Dict[str, EndpointSpec] = {}

    def load(self, path: Optional[str] = None) -> None:
        config_path = Path(path or settings.queries_config_path)
        if not config_path.exists():
            raise FileNotFoundError(f"Queries config not found: {config_path}")

        with open(config_path) as f:
            raw = yaml.safe_load(f)

        for ep_cfg in raw.get("endpoints", []):
            ep = EndpointSpec(ep_cfg)
            self._endpoints[ep.id] = ep
            logger.info("endpoint_registered", id=ep.id, path=ep.path, method=ep.method)

        logger.info("registry_loaded", total=len(self._endpoints))

    def get(self, endpoint_id: str) -> Optional[EndpointSpec]:
        return self._endpoints.get(endpoint_id)

    def all(self) -> List[EndpointSpec]:
        return list(self._endpoints.values())


# Singleton
registry = EndpointRegistry()
