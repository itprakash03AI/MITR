import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { useWebSocket } from './WebSocketContext';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  data?: unknown;
  timestamp?: string;
}

export type AddNotificationInput = Omit<Notification, 'id' | 'timestamp'> & { timestamp?: string };

interface NotificationContextValue {
  notifications: Notification[];
  addNotification: (notification: AddNotificationInput) => void;
  removeNotification: (id: number) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextValue | null>(null);

export const useNotifications = (): NotificationContextValue => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { addListener } = useWebSocket();

  const addNotification = useCallback((notification: AddNotificationInput) => {
    const id = Date.now() + Math.random();
    const newNotification: Notification = {
      id,
      ...notification,
      timestamp: notification.timestamp || new Date().toISOString(),
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 50));

    if (notification.type !== 'error') {
      setTimeout(() => removeNotification(id), 5000);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const removeNotification = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  useEffect(() => {
    const COMPONENT_HANDLED = new Set([
      'pong', 'connection_established',
      'execution_started', 'execution_progress',
      'execution_completed', 'execution_failed',
    ]);

    const removeListener = addListener((message) => {
      if (message.type && !COMPONENT_HANDLED.has(message.type)) {
        const getType = (t: string): Notification['type'] => {
          if (t.includes('completed')) return 'success';
          if (t.includes('failed') || t.includes('error')) return 'error';
          return 'info';
        };
        const titles: Record<string, string> = {
          download_ready: 'Download Ready',
          export_completed: 'Export Complete',
          schedule_completed: 'Schedule Completed',
          schedule_failed: 'Schedule Failed',
        };
        addNotification({
          type: getType(message.type),
          title: titles[message.type] || 'Notification',
          message: (message.message as string) || message.type,
          data: message,
          timestamp: (message.timestamp as string) || new Date().toISOString(),
        });
      }
    });

    return () => removeListener();
  }, [addListener, addNotification]);

  return (
    <NotificationContext.Provider value={{ notifications, addNotification, removeNotification, clearAll }}>
      {children}
    </NotificationContext.Provider>
  );
};
