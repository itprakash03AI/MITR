"""
Query Result Cache — disk-backed parquet cache with configurable TTL.

Cache key:   sha256 of canonical JSON (sorted keys) of query_config dict.
Cache store: data/cache/ directory — one .parquet file per unique query.
DB metadata: query_result_cache table tracks path + expiry.

Resolution: cache hit → serve instantly (zero DuckDB execution).
Miss:       execute normally → write result → store in cache for next time.

File deduplication: store_result() no longer copies the result file into cache/
by default (copy=False). The cache entry simply points to the same file in
downloads/.  The eviction path (cleanup_expired / enforce_size_limit) only
physically removes files that live *inside* the cache dir; download files are
managed by the download cleanup job independently.
"""
from __future__ import annotations

import hashlib
import json
import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_DEFAULT_TTL = 3600   # seconds (1 hour)
_db_manager  = None
_cache_dir: Optional[Path] = None
_ttl_seconds: int = _DEFAULT_TTL
_enabled: bool = True


def init_query_cache(db_manager, cache_dir: Path, ttl_seconds: int = _DEFAULT_TTL,
                     enabled: bool = True) -> None:
    global _db_manager, _cache_dir, _ttl_seconds, _enabled
    _db_manager  = db_manager
    _cache_dir   = Path(cache_dir)
    _ttl_seconds = ttl_seconds
    _enabled     = enabled
    _cache_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[query_cache] Initialised — dir=%s ttl=%ds enabled=%s",
                _cache_dir, _ttl_seconds, _enabled)


def make_cache_key(query_config: dict) -> str:
    """Stable sha256 hash of query config — order-independent."""
    canonical = json.dumps(query_config, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()


def get_cached_result(cache_key: str) -> Optional[Path]:
    """Return path to cached parquet if hit + not expired, else None."""
    if not _enabled or _db_manager is None:
        return None
    try:
        entry = _db_manager.get_cache_entry(cache_key)
        if not entry:
            return None
        # Check expiry
        expires_str = entry.get("expires_at")
        if expires_str:
            try:
                exp = datetime.fromisoformat(expires_str)
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp < datetime.now(timezone.utc):
                    _evict(cache_key, entry.get("file_path"))
                    return None
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "query_cache", exc, exc_info=True)
        fp = Path(entry["file_path"])
        if not fp.exists():
            _db_manager.delete_cache_entry(cache_key)
            return None
        logger.debug("[query_cache] HIT  key=%s", cache_key[:12])
        return fp
    except Exception as exc:
        logger.warning("[query_cache] get error: %s", exc)
        return None


def store_result(cache_key: str, source_parquet: Path, query_config: dict,
                 row_count: int = 0, ttl_seconds: Optional[int] = None,
                 copy: bool = False) -> Optional[Path]:
    """Register source_parquet as a cache entry.

    When copy=False (default) the cache entry simply points to source_parquet
    in-place — no file copy is made, halving disk I/O and storage usage.
    The physical file is owned by the download-file lifecycle; cache eviction
    only removes the DB record in this mode.

    When copy=True a separate cache copy is written to cache_dir (legacy
    behaviour, needed when the source file may be deleted before the cache TTL
    expires independently of the download expiry).
    """
    if not _enabled or _db_manager is None or _cache_dir is None:
        return None
    try:
        ttl = ttl_seconds if ttl_seconds is not None else _ttl_seconds
        if copy:
            dest = _cache_dir / f"{cache_key}.parquet"
            shutil.copy2(str(source_parquet), str(dest))
        else:
            dest = source_parquet          # point at existing file — no copy
        size    = dest.stat().st_size
        expires = datetime.now(timezone.utc) + timedelta(seconds=ttl)
        _db_manager.set_cache_entry(
            cache_key=cache_key,
            file_path=str(dest),
            row_count=row_count,
            file_size_bytes=size,
            expires_at=expires,
            query_config=query_config,
        )
        logger.debug("[query_cache] STORED key=%s size=%d ttl=%ds copy=%s",
                     cache_key[:12], size, ttl, copy)
        return dest
    except Exception as exc:
        logger.warning("[query_cache] store error: %s", exc)
        return None


def invalidate(cache_key: str) -> None:
    """Manually evict a single cache entry."""
    if _db_manager is None:
        return
    try:
        entry = _db_manager.get_cache_entry(cache_key)
        if entry:
            _evict(cache_key, entry.get("file_path"))
    except Exception as exc:
        logging.getLogger(__name__).warning("%s failed: %s", "query_cache", exc, exc_info=True)


def invalidate_by_source(table_name: Optional[str] = None,
                         file_prefix: Optional[str] = None,
                         connection_id: Optional[int] = None) -> int:
    """Evict cache entries that reference a specific source table / file prefix.

    Called by the /api/cache/invalidate-source endpoint when upstream data
    changes (e.g. Kafka ingestion event).  Scans stored query_config JSON —
    no need to know the cache key in advance.

    Matching logic (any match triggers eviction):
      table_name    — query_config.files contains '__registered__:<table_name>'
      file_prefix   — any file in query_config.files starts with file_prefix
      connection_id — query_config.connection_id == connection_id

    Returns the number of entries evicted.
    """
    if _db_manager is None:
        return 0
    try:
        entries = _db_manager.list_cache_entries() or []
        evicted = 0
        for entry in entries:
            qc = entry.get("query_config") or {}
            files = qc.get("files") or []
            matched = False
            if table_name:
                matched = any(
                    (f if isinstance(f, str) else str(f)).startswith(f"__registered__:{table_name}")
                    for f in files
                )
            if not matched and file_prefix:
                matched = any(
                    (f if isinstance(f, str) else str(f)).startswith(file_prefix)
                    for f in files
                )
            if not matched and connection_id is not None:
                matched = qc.get("connection_id") == connection_id
            if matched:
                _evict(entry["cache_key"], entry.get("file_path"))
                evicted += 1
        if evicted:
            logger.info("[query_cache] Invalidated %d entries (table=%s prefix=%s conn=%s)",
                        evicted, table_name, file_prefix, connection_id)
        return evicted
    except Exception as exc:
        logger.warning("[query_cache] invalidate_by_source error: %s", exc)
        return 0


def cleanup_expired() -> int:
    """Delete expired cache entries — called by APScheduler every 30 min."""
    if _db_manager is None:
        return 0
    try:
        deleted = _db_manager.delete_expired_cache_entries()
        # Also sweep orphaned .parquet files not tracked in DB
        if _cache_dir and _cache_dir.exists():
            known = {e.get("file_path", "") for e in (_db_manager.list_cache_entries() or [])}
            for f in _cache_dir.glob("*.parquet"):
                if str(f) not in known:
                    try:
                        f.unlink(missing_ok=True)
                    except OSError:
                        pass
        logger.info("[query_cache] Cleanup: removed %d expired entries", deleted)
        return deleted
    except Exception as exc:
        logger.warning("[query_cache] cleanup error: %s", exc)
        return 0


def get_stats() -> dict:
    """Return cache statistics for the /api/cache/stats endpoint."""
    if _db_manager is None:
        return {"enabled": False, "entry_count": 0, "total_size_bytes": 0}
    try:
        entries = _db_manager.list_cache_entries()
        total_size = sum(e.get("file_size_bytes", 0) for e in entries)
        # Count expired separately
        now = datetime.now(timezone.utc)
        expired = sum(
            1 for e in entries
            if e.get("expires_at") and
            datetime.fromisoformat(e["expires_at"]).replace(tzinfo=timezone.utc) < now
        )
        return {
            "enabled":          _enabled,
            "entry_count":      len(entries),
            "valid_count":      len(entries) - expired,
            "expired_count":    expired,
            "total_size_bytes": total_size,
            "total_size_mb":    round(total_size / 1024 / 1024, 2),
            "ttl_seconds":      _ttl_seconds,
            "cache_dir":        str(_cache_dir),
        }
    except Exception:
        return {"enabled": _enabled, "entry_count": 0, "total_size_bytes": 0}


def enforce_size_limit(max_size_mb: int) -> int:
    """LRU-evict cache entries until total size is under max_size_mb.

    Only evicts entries whose file lives inside _cache_dir (copy=True entries).
    Entries pointing to downloads/ files are evicted DB-only (the download
    cleanup job manages those files).

    Returns the number of MB freed.
    """
    if _db_manager is None or _cache_dir is None or max_size_mb <= 0:
        return 0
    try:
        entries = _db_manager.list_cache_entries()
        total_bytes = sum(e.get("file_size_bytes", 0) for e in entries)
        max_bytes   = max_size_mb * 1024 * 1024
        if total_bytes <= max_bytes:
            return 0
        # Sort oldest-first (LRU proxy: earliest expires_at ≈ was cached longest ago)
        entries_sorted = sorted(
            entries,
            key=lambda e: e.get("expires_at") or "0000",
        )
        freed = 0
        for entry in entries_sorted:
            if total_bytes <= max_bytes:
                break
            size = entry.get("file_size_bytes", 0)
            _evict(entry["cache_key"], entry.get("file_path"))
            total_bytes -= size
            freed       += size
        freed_mb = freed // (1024 * 1024)
        if freed_mb:
            logger.info("[query_cache] Size enforcement freed %d MB", freed_mb)
        return freed_mb
    except Exception as exc:
        logger.warning("[query_cache] enforce_size_limit error: %s", exc)
        return 0


def _evict(cache_key: str, file_path: Optional[str]) -> None:
    try:
        _db_manager.delete_cache_entry(cache_key)
    except Exception as exc:
        logging.getLogger(__name__).warning("%s failed: %s", "query_cache", exc, exc_info=True)
    if file_path:
        try:
            fp = Path(file_path)
            # Only physically delete if the file lives in the cache dir.
            # Files in downloads/ are managed by the download cleanup job.
            if _cache_dir and fp.parent.resolve() == _cache_dir.resolve():
                fp.unlink(missing_ok=True)
        except OSError as exc:
            logging.getLogger(__name__).debug("%s failed: %s", "query_cache", exc, exc_info=True)
